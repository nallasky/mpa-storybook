# -*- coding:utf-8 -*-
import sqlite3

# Step 1: Create Person.DB
conn = sqlite3.connect('Person.db')

cur = conn.cursor()

cur.execute('create table person (Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, Name TEXT, age TEXT)')
conn.commit()


# Step 2: Insert initial data
data = [
    ('Dominica', '14'),
    ('Ruri', '13'),
    ('Ruo', '9'),
]

# Step 3: Get inserted data and print
cur.executemany('insert into person (Name, age) values (?, ?)', data)
conn.commit()

cur.execute('select * from person')
for row in cur:
    print('{}의 나이는 {} 입니다.'.format(row[1], row[2]))

