# -*- coding:utf-8 -*-
from functools import reduce


def Result(x, y):
    return x if x > y else y


lst = [100, 90, 80, 200]
ret = reduce(lambda pre, nex: Result(pre, nex), lst, 0)
print(ret)
