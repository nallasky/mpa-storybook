import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Empty } from 'antd';
import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import * as step from '../../../lib/api/Define/etc';
import * as sg from '../../UI/molecules/Visualization/styleGroup';
import SettingGraph from '../../UI/molecules/SettingGraph';
const ContentsForm = () => {};

const PreviewForm = () => {
  const {
    visualStepInfo,
    ruleStepConfig,
    updateVisualInfo,
  } = useRuleSettingInfo();
  const [dataInfo, setDataInfo] = useState({
    disp_order: [],
    disp_graph: [],
    row: {},
    items: [],
  });

  useEffect(() => {
    const configData = ruleStepConfig.find(
      (item) => item.step === step.E_STEP_5,
    );
    setDataInfo({
      disp_order: configData?.data?.disp_order ?? [],
      disp_graph: configData?.data?.disp_graph ?? [],
      row: configData?.data?.row ?? {},
    });
  }, []);

  const ApplyFunc = (info, graph_type) => {
    const tmp = { ...visualStepInfo };
    tmp.items = visualStepInfo.items.map((obj) => {
      return obj.title === graph_type
        ? {
            ...obj,
            x_range_max: info.maxX,
            x_range_min: info.minX,
            y_range_max: info.maxY,
            y_range_min: info.minY,
          }
        : obj;
    });
    updateVisualInfo(tmp);
  };
  const getArr = (row, key) => {
    return Object.entries(row)
      .filter(([, obj]) => obj['No.'] !== 'ALL')
      .map(([, item]) => item[key]);
  };
  useEffect(() => {
    console.log('[useEffect]visualStepInfo', visualStepInfo);
  }, [visualStepInfo]);

  if ((visualStepInfo.items?.length ?? 0) === 0) return <></>;
  return (
    <div css={sg.graphWrapper}>
      <div
        css={
          Object.keys(visualStepInfo.items).length > 0
            ? sg.graphBodyStyle
            : sg.emptyWrapper
        }
      >
        {Object.keys(visualStepInfo.items).length > 0 ? (
          visualStepInfo.items.map((k, i) => {
            return k.type.length && k.x_axis.length && k.y_axis.length ? (
              <div key={i}>
                <SettingGraph
                  data={{
                    graphType: k.type,
                    x: getArr(dataInfo.row, k.x_axis),
                    y: getArr(dataInfo.row, k.y_axis),
                    z: k.z_axis !== '' ? getArr(dataInfo.row, k.z_axis) : [],
                    currentFilter: visualStepInfo.items,
                  }}
                  onApply={(e) => ApplyFunc(e, k.title)}
                  title={k.title}
                />
              </div>
            ) : (
              <></>
            );
          })
        ) : (
          <Empty />
        )}
      </div>
    </div>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const Step6_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step6_Setting.propTypes = {
  children: PropTypes.node,
};
Step6_Setting.contents = ContentsForm;
Step6_Setting.preview = PreviewForm;

export default Step6_Setting;
