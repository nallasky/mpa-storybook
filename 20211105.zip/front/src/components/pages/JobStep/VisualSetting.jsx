import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import React, { useEffect, useState } from 'react';
import { Collapse, Table, Button } from 'antd';
import { SettingFilled } from '@ant-design/icons';
import { MSG_PREVIOUS_TABLE } from '../../../lib/api/Define/Message';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { E_STEP_ANALYSIS } from '../../../lib/api/Define/etc';
import GraphManagement from '../../UI/organisms/GraphManagement/GraphManagement';

const { Panel } = Collapse;

const tableWrapper = css`
  margin: 10px;
  display: flex;
  justify-content: center;
  & table {
    font-size: 14px;
    &:first-of-type > thead > tr > th {
      background: #f0f5ff;
    }
  }
`;

const VisualSetting = ({ data }) => {
  const { ruleStepConfig } = useRuleSettingInfo();
  const [isOpen, setIsOpen] = useState(false);
  const [config, setConfig] = useState(null);
  const { analysis_header, analysis_data } = data;

  useEffect(() => {
    console.log('[STEP6]data: ', data);
    const configData =
      ruleStepConfig.find((item) => item.step === E_STEP_ANALYSIS)?.data ?? {};

    setConfig({
      row: configData?.row ?? {},
    });
  }, []);

  if (config === null) return <></>;
  return (
    <>
      <div css={{ maxWidth: '85%', minWidth: '75%', paddingBottom: '0.9rem' }}>
        <Collapse defaultActiveKey={[1]}>
          <Panel header={MSG_PREVIOUS_TABLE} key="1">
            <div css={tableWrapper}>
              {analysis_header !== undefined ? (
                <Table
                  bordered
                  pagination={false}
                  columns={analysis_header}
                  dataSource={analysis_data ?? []}
                  size="middle"
                  rowKey="key"
                  scroll={{ x: 'max-content' }}
                />
              ) : (
                <></>
              )}
            </div>
          </Panel>
        </Collapse>
      </div>
      <div css={{ width: '100%' }}>
        <Button
          icon={<SettingFilled />}
          shape="round"
          type="primary"
          onClick={() => setIsOpen(true)}
        >
          User Graph Management
        </Button>
      </div>
      <GraphManagement closer={() => setIsOpen(false)} isOpen={isOpen} />
    </>
  );
};

VisualSetting.propTypes = {
  data: PropTypes.object,
};
export default VisualSetting;
