import React, { useState, useRef, useEffect } from 'react';
import { Form, Select, Button, Radio, Input } from 'antd';
import PropTypes from 'prop-types';
import Plotly from 'plotly.js-dist';
import styled from '@emotion/styled';
import AceEditor from 'react-ace';
import 'ace-builds/src-noconflict/mode-javascript';
import 'ace-builds/src-noconflict/theme-tomorrow';
import { CSSTransition } from 'react-transition-group';
import * as Dummy from './dummyData.js';
import * as SG from './styleGroup';
import { displayNotification } from '../../../pages/JobAnalysis/functionGroup';
import useRuleSettingInfo from '../../../../hooks/useRuleSettingInfo';

const { Option } = Select;
const { Item } = Form;
const { Group } = Radio;
const defaultScript = `function renderGraph(Plotly, element, params) {

}`;
const { xData, yData, zData } = Dummy;
const defaultErrorMsg = `
  There is a problem with the setting.
  Please check the settings again.
`;
const typeRegex = /^([a-zA-Z])$|^([a-zA-Z])[a-zA-Z0-9_]{0,18}([a-zA-Z])$/;
const StyledEditor = styled.div`
  margin-top: 10px;
  * {
    font-family: consolas;
    line-height: 1;
  }
`;
const GraphManagement = ({ closer, isOpen }) => {
  const { visualStepInfo, updateVisualInfo } = useRuleSettingInfo();
  const [errorMsg, setErrorMsg] = useState('');
  const [mode, setMode] = useState('1');
  const [addType, setAddType] = useState('');
  const [editType, setEditType] = useState('');
  const [addScript, setAddScript] = useState(defaultScript);
  const [editScript, setEditScript] = useState('');
  const [addData, setAddData] = useState({
    x: '0',
    y: [],
    z: '0',
  });
  const [editData, setEditData] = useState({
    x: '0',
    y: [],
    z: '0',
  });
  const [isPreview, setIsPreview] = useState(false);
  const graphArea = useRef();

  const changeData = (key, v) => {
    let newData = {};
    if (mode === '1') {
      if (key === 'type') {
        setAddType(v);
      } else if (key === 'script') {
        setAddScript(v);
      } else {
        newData = addData;
        newData[key] = v;
        setAddData(Object.assign({}, newData));
      }
    } else {
      if (key === 'type') {
        setEditType(v);
      } else if (key === 'script') {
        setEditScript(v);
      } else {
        newData = editData;
        newData[key] = v;
        setEditData(Object.assign({}, newData));
      }
    }
  };

  const renderGraph = () => {
    try {
      const currentData = mode === '1' ? addData : editData;
      const currentScript = mode === '1' ? addScript : editScript;
      const newFunc = new Function('return ' + currentScript)();
      const tmpObj = {};

      if (currentData.y.length > 0) {
        currentData.y.reduce((acc, v) => {
          acc[v] = yData[v];
          return acc;
        }, tmpObj);
      }

      const params = {
        x: currentData.x === '0' ? [] : xData[currentData.x],
        y: tmpObj,
        z: currentData.z === '0' ? [] : zData[currentData.z],
        title: 'Example',
        range: {
          x: [],
          y: [],
          z: [],
        },
      };
      newFunc(Plotly, graphArea.current, params);
      setErrorMsg('');
      setIsPreview(true);
    } catch (e) {
      setErrorMsg(defaultErrorMsg);
    }
  };

  const disablePreview = () => {
    const currentData = mode === '1' ? addData : editData;
    const currentScript = mode === '1' ? addScript : editScript;
    const currentType = mode === '1' ? 'add' : editType;

    return (
      (currentData.x === '0' &&
        currentData.y.length === 0 &&
        currentData.z === '0') ||
      currentScript === defaultScript ||
      currentType === ''
    );
  };

  const apply = () => {
    let message = '',
      description = '',
      tmpGraphType = [...visualStepInfo.function_graph_type],
      tmpGraphList = [...visualStepInfo.graph_list];

    switch (mode) {
      case '1':
      default:
        if (
          graphArea.current.getElementsByClassName('plot-container').length ===
          0
        ) {
          description =
            'The graph has not been drawn yet. Please save again after the graph is drawn.';
        } else if (!isPreview) {
          description =
            'Save is not executed because the graph has not been changed.';
        } else if (
          !typeRegex.test(addType) ||
          visualStepInfo.graph_list?.find((v) => v.name === addType) !==
            undefined
        ) {
          description =
            'The graph type is not correct or it is already registered. Please re-enter.';
        } else {
          tmpGraphType.push({
            id: null,
            name: addType,
            script: addScript,
            type: 'user',
          });
          tmpGraphList.push({
            name: addType,
            type: 'user',
          });
        }

        if (description !== '') {
          message = 'Save failed';
        }
        break;

      case '2':
        if (
          editScript ===
          visualStepInfo.function_graph_type.find((v) => v.name === editType)
        ) {
          description =
            'Save is not executed because the script has not been changed.';
        } else if (!isPreview) {
          description =
            'Save is not executed because the graph has not been changed.';
        } else if (
          graphArea.current.getElementsByClassName('plot-container').length ===
          0
        ) {
          description =
            'The graph has not been drawn yet. Please save again after the graph is drawn.';
        } else {
          tmpGraphType = tmpGraphType.map((v) => {
            if (v.name === editType) {
              return {
                ...v,
                script: editScript,
              };
            } else {
              return v;
            }
          });
        }

        if (description !== '') {
          message = 'Save failed';
        }
        break;

      case '3':
        if (editType === '') {
          message = 'Delete failed';
          description =
            'There is no graph type selected. Please select the graph type to delete.';
        } else {
          tmpGraphType = tmpGraphType.filter((v) => v.name !== editType);
          tmpGraphList = tmpGraphList.filter((v) => v.name !== editType);
        }
        break;
    }

    if (message !== '') {
      displayNotification({
        message: message,
        description: description,
        duration: 3,
        style: { borderLeft: '8px solid red' },
      });
    } else {
      if (mode === '2') {
        updateVisualInfo({
          ...visualStepInfo,
          function_graph_type: tmpGraphType,
        });
      } else {
        updateVisualInfo({
          ...visualStepInfo,
          function_graph_type: tmpGraphType,
          graph_list: tmpGraphList,
        });
      }

      displayNotification({
        message: mode !== '3' ? 'Save completed' : 'Delete Completed',
        description:
          mode !== '3'
            ? 'Graph saving has been successfully completed.'
            : 'Graph deletion has been successfully completed.',
        duration: 3,
        style: { borderLeft: '8px solid green' },
      });

      if (mode === '1') {
        setAddType('');
        setAddScript(defaultScript);
        graphArea.current.removeAttribute('class');
        graphArea.current.firstChild.remove();
      }

      setIsPreview(false);
    }
  };

  const closeManagement = () => {
    closer();
    setErrorMsg('');
    setMode('1');
    setAddType('');
    setEditType('');
    setAddScript(defaultScript);
    setEditScript('');
    setAddData({
      x: '0',
      y: [],
      z: '0',
    });
    setEditData({
      x: '0',
      y: [],
      z: '0',
    });
    setIsPreview(false);
  };

  useEffect(() => {
    renderGraph();
  }, [graphArea, errorMsg]);

  return (
    <CSSTransition in={isOpen} classNames="modal" unmountOnExit timeout={100}>
      <>
        <div css={SG.backgroundStyle} />
        <div css={SG.mainStyle}>
          <div>
            <div>User Graph Management</div>
            <div>
              <Button onClick={closeManagement}>Close</Button>
              <Button type="primary" onClick={apply}>
                {mode === '3' ? 'Delete' : 'Save'}
              </Button>
            </div>
          </div>
          <div>
            <div>
              <Form labelAlign="left">
                <Item label="Mode">
                  <Group onChange={(e) => setMode(e.target.value)} value={mode}>
                    <Radio value="1">Add</Radio>
                    <Radio
                      value="2"
                      disabled={
                        visualStepInfo.graph_list.find(
                          (v) => v.type === 'user',
                        ) === undefined
                      }
                    >
                      Edit
                    </Radio>
                    <Radio
                      value="3"
                      disabled={
                        visualStepInfo.graph_list.find(
                          (v) => v.type === 'user',
                        ) === undefined
                      }
                    >
                      Delete
                    </Radio>
                  </Group>
                </Item>
                <SideMenu
                  mode={mode}
                  type={mode === '1' ? addType : editType}
                  values={mode === '1' ? addData : editData}
                  options={{
                    type: visualStepInfo.graph_list,
                    x: xData,
                    y: yData,
                    z: zData,
                  }}
                  changeFunc={changeData}
                />
                <Item>
                  <StyledEditor>
                    <AceEditor
                      mode="javascript"
                      theme="tomorrow"
                      width="100%"
                      showGutter
                      highlightActiveLine
                      value={mode === '1' ? addScript : editScript}
                      onChange={(v) => changeData('script', v)}
                      cursorStart={0}
                      setOptions={{
                        tabSize: 2,
                        showPrintMargin: false,
                        showLineNumbers: true,
                        useWorker: false,
                      }}
                    />
                  </StyledEditor>
                </Item>
              </Form>
            </div>
            <div>
              <Button
                type="primary"
                onClick={renderGraph}
                disabled={disablePreview()}
              >
                Preview
              </Button>
              <div ref={graphArea}>{errorMsg.length > 0 ? errorMsg : ''}</div>
            </div>
          </div>
        </div>
      </>
    </CSSTransition>
  );
};

GraphManagement.propTypes = {
  closer: PropTypes.func.isRequired,
  isOpen: PropTypes.bool.isRequired,
};

const SideMenu = ({ mode, type, values, options, changeFunc }) => {
  return (
    <>
      <Item label="Graph Type">
        {mode !== '1' ? (
          <Select value={type} onChange={(v) => changeFunc('type', v)}>
            {options.type.map((v) => {
              if (v.type !== 'system') {
                return (
                  <Option value={v.name} key={v.name}>
                    {v.name}
                  </Option>
                );
              }
            })}
          </Select>
        ) : (
          <Input
            value={type}
            onChange={(e) => changeFunc('type', e.target.value)}
            maxLength={20}
          />
        )}
      </Item>
      <Item label="Axis(X)">
        <Select value={values.x} onChange={(v) => changeFunc('x', v)}>
          <Option value="0">None</Option>
          {Object.keys(options.x).map((v) => {
            return (
              <Option value={v} key={v}>
                {v}
              </Option>
            );
          })}
        </Select>
      </Item>
      <Item label="Axis(Y)">
        <Select
          mode="multiple"
          value={values.y}
          onChange={(v) => changeFunc('y', v)}
        >
          {Object.keys(options.y).map((v) => {
            return (
              <Option value={v} key={v}>
                {v}
              </Option>
            );
          })}
        </Select>
      </Item>
      <Item label="Axis(Z)">
        <Select value={values.z} onChange={(v) => changeFunc('z', v)}>
          <Option value="0">None</Option>
          {Object.keys(options.z).map((v) => {
            return (
              <Option value={v} key={v}>
                {v}
              </Option>
            );
          })}
        </Select>
      </Item>
    </>
  );
};
SideMenu.propTypes = {
  mode: PropTypes.string.isRequired,
  type: PropTypes.string.isRequired,
  values: PropTypes.object.isRequired,
  options: PropTypes.object.isRequired,
  changeFunc: PropTypes.func.isRequired,
};

export default GraphManagement;
