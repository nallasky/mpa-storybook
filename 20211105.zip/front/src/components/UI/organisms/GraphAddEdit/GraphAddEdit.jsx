import React, { useRef } from 'react';
import { Form, Select, Button, Input, DatePicker } from 'antd';
import { CSSTransition } from 'react-transition-group';
import PropTypes from 'prop-types';
import * as SG from './styleGroup';
import { backgroundStyle } from '../GraphManagement/styleGroup';
import useRuleSettingInfo from '../../../../hooks/useRuleSettingInfo';
import * as Dummy from './../GraphManagement/dummyData';

const { Option } = Select;
const { Item } = Form;
const { RangePicker } = DatePicker;

const { xData, yData, zData } = Dummy;

const GraphAddEdit = ({ closer, isOpen, mode }) => {
  const { visualStepInfo } = useRuleSettingInfo();
  const graphArea = useRef();

  console.log(visualStepInfo);

  return (
    <CSSTransition in={isOpen} classNames="modal" unmountOnExit timeout={100}>
      <>
        <div
          css={backgroundStyle}
          onClick={closer}
          onKeyDown={closer}
          role="button"
          tabIndex="0"
        />
        <div css={SG.mainStyle}>
          <div>
            <div>{mode === 'add' ? 'Add Graph' : 'Edit Graph'}</div>
            <div>
              <Button onClick={closer}>Close</Button>
              <Button type="primary">{mode === 'add' ? 'Add' : 'Save'}</Button>
            </div>
          </div>
          <div>
            <div>
              <Form labelAlign="left">
                <Item label="Graph Type">
                  <Select mode="multiple">
                    {visualStepInfo.graph_list.map((v) => {
                      return (
                        <Option value={v.name} key={v.name}>
                          {v.name}
                        </Option>
                      );
                    })}
                  </Select>
                </Item>
                <Item label="Axis(X)">
                  <Select>
                    <Option value="0">None</Option>
                    {Object.keys(xData).map((v) => {
                      return (
                        <Option value={v} key={v}>
                          {v}
                        </Option>
                      );
                    })}
                  </Select>
                </Item>
                <Item label="Axis(Y)">
                  <Select mode="multiple">
                    {Object.keys(yData).map((v) => {
                      return (
                        <Option value={v} key={v}>
                          {v}
                        </Option>
                      );
                    })}
                  </Select>
                </Item>
                <Item label="Axis(Z)">
                  <Select>
                    <Option value="0">None</Option>
                    {Object.keys(zData).map((v) => {
                      return (
                        <Option value={v} key={v}>
                          {v}
                        </Option>
                      );
                    })}
                  </Select>
                </Item>
                <Item label="Title">
                  <Input />
                </Item>
                <Item label="X Range">
                  <RangePicker
                    showTime
                    allowClear={false}
                    style={{ width: '100%' }}
                  />
                </Item>
                <Item label="Y Range">
                  <div className="multi-input">
                    <Input />
                    <Input />
                  </div>
                </Item>
                <Item label="Z Range">
                  <div className="multi-input">
                    <Input />
                    <Input />
                  </div>
                </Item>
              </Form>
            </div>
            <div>
              <div ref={graphArea} />
            </div>
          </div>
        </div>
      </>
    </CSSTransition>
  );
};

GraphAddEdit.propTypes = {
  closer: PropTypes.func.isRequired,
  isOpen: PropTypes.bool.isRequired,
  mode: PropTypes.string,
};
GraphAddEdit.defaultProps = {
  mode: 'add',
};

export default GraphAddEdit;
