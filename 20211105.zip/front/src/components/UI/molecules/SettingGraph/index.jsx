export { default } from './SettingGraph';
