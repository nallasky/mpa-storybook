import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { Select, Empty } from 'antd';
import Graph from '../../atoms/Graph';
import useAnalysisInfo from '../../../../hooks/useAnalysisInfo';

const { Option } = Select;

const contentWrapper = css`
  width: 100%;
  & > div + div {
    margin-top: 1rem;
  }
`;
const graphWrapper = css`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: auto;
  gap: 1rem;
  width: 100%;
`;
const optionWrapper = css`
  display: flex;
  justify-content: space-between;
  & > div {
    display: flex;
    align-items: center;
    & > span > span {
      color: red;
    }
  }
`;
const emptyWrapper = css`
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const FocusGraph = React.memo(({ data, graphKey }) => {
  const { summary, detail, graphData } = data;
  const { xOption, xValue, yOption, yValue } = graphData;
  const {
    SummarySubItem,
    DetailYAxis,
    SummaryYAxis,
    setYAxisValue,
    DetailOptions,
  } = useAnalysisInfo();
  const sourceData = summary !== undefined ? summary : detail;
  const divStr = summary !== undefined ? 'summary' : 'detail';
  const [xAxisValue, setXAxisValue] = useState(0);
  const [infoX, setInfoX] = useState([]);
  const [graphType, setGraphType] = useState('bar');
  const yAxisValue = summary !== undefined ? SummaryYAxis : DetailYAxis;

  const createXdata = (xKey) => {
    const labelKey =
      SummarySubItem.selected === 'period'
        ? 'period'
        : SummarySubItem.subItem.selected;
    const isDetail = detail !== undefined;
    const tempData = [];

    Object.keys(sourceData).map((key) => {
      if (
        sourceData[key]['index'] !== 'ALL' &&
        (!isDetail ||
          (isDetail && DetailOptions.includes(sourceData[key][labelKey])))
      ) {
        tempData.push(sourceData[key][xKey]);
      }
    });

    setInfoX(tempData.filter((v, i) => tempData.indexOf(v) === i));
  };

  const changeXoption = (v) => {
    const { label } = xOption.find((option) => option.value === v);

    if (label === undefined) return;

    setXAxisValue(v);
    createXdata(label);
  };

  const filteringGraph = (values) => {
    let result = [];
    const exceptZero = values.filter((value) => value !== 0);

    if (
      !yAxisValue.includes(0) &&
      (values.includes(0) || exceptZero.length === yOption.length - 1)
    ) {
      yOption.map((option) => {
        result.push(option.value);
      });
    } else {
      result = yAxisValue.includes(0) && !values.includes(0) ? [] : exceptZero;
    }

    setYAxisValue(divStr, result);
  };

  useEffect(() => {
    createXdata(graphKey);
  }, [graphKey, data, DetailOptions]);

  useEffect(() => {
    setXAxisValue(xValue);
    setYAxisValue(divStr, yValue);
  }, [xValue, yValue]);

  return (
    <div css={contentWrapper}>
      <div css={optionWrapper}>
        <div>
          <span>
            <span>*</span> Graph Type:
          </span>
          <Select
            value={graphType}
            style={{ marginLeft: '1rem' }}
            onChange={setGraphType}
          >
            <Option value="bar">Bar</Option>
            <Option value="scatter">Line</Option>
          </Select>
        </div>
        <div>
          <span>
            <span>*</span> Axis (X):
          </span>
          <Select
            value={xAxisValue}
            options={xOption}
            style={{ marginLeft: '1rem' }}
            onChange={changeXoption}
          />
        </div>
        <div>
          <span>
            <span>*</span> Axis (Y):
          </span>
          <Select
            mode="multiple"
            maxTagCount="responsive"
            style={{ marginLeft: '1rem', width: '300px' }}
            value={yAxisValue}
            options={yOption}
            onChange={filteringGraph}
            placeholder="Select option"
          />
        </div>
      </div>
      <div css={yAxisValue.length > 0 ? graphWrapper : emptyWrapper}>
        {yAxisValue.length > 0 ? (
          yOption.map((option, index) => {
            if (index === 0 || !yAxisValue.includes(option.value)) return '';

            const infoY = [];

            Object.keys(sourceData).map((key) => {
              infoY.push(sourceData[key][option.label]);
            });

            if (infoY.length !== 0) {
              return (
                <div id={`${divStr}_graph_${option.value}`} key={index}>
                  <Graph
                    plotProps={{
                      data: [{ type: graphType, x: infoX, y: infoY }],
                      layout: {
                        width: 570,
                        height: 360,
                        autosize: true,
                        title: option.label,
                        xaxis: {
                          tickmode: 'auto',
                          nticks: infoX.length,
                        },
                      },
                      config: {
                        modeBarButtonsToRemove: [
                          'pan2d',
                          'pan3d',
                          'zoom2d',
                          'zoom3d',
                          'lasso2d',
                          'select2d',
                          'hoverClosestCartesian',
                          'hoverCompareCartesian',
                          'autoScale2d',
                          'autoScale3d',
                          'toggleSpikelines',
                        ],
                        displaylogo: false,
                      },
                    }}
                  />
                </div>
              );
            } else {
              return '';
            }
          })
        ) : (
          <Empty />
        )}
      </div>
    </div>
  );
});

FocusGraph.displayName = 'FocusGraph';
FocusGraph.propTypes = {
  data: PropTypes.object.isRequired,
  graphKey: PropTypes.string.isRequired,
};

export default FocusGraph;
