import os
import datetime
import time
from copy import deepcopy
from multiprocessing import Process, Manager
import pandas as pd
from flask import json
import numpy as np

from dao.dao_analysis_items import DAOAnalysisItems
from dao.dao_base import DAOBaseClass
from config import app_config
import convert as lc

from common.utils.response import ResponseForm
from common.utils import calculator, preprocessing

LOG_NAME = 'PLATEAUTOFOCUSCOMPENSATION'


class AnalysisService:
    def __init__(self):
        pass

    def __del__(self):
        print('__del__', __class__)

    # def get_list(self, log_name, job_id, one_period, adj_period, list_group):
    #
    #     # dao_afc = DAOAfc()
    #
    #     try:
    #         dao = self.get_dao(log_name)
    #         cnt = dao.load_data_by_id(job_id=job_id)
    #         if cnt == 0:
    #             return ResponseForm(res=False, msg='There is no Log Data. You might have wrong id.')
    #
    #         # 1st Period の開始時刻とログの最後の時刻を取得
    #         first_log_time = dao.get_log_time_min()
    #
    #         # 期間指定がある場合
    #         start_time = calculator.period_start_datetime(first_log_time, one_period, adj_period)
    #
    #         job_list = dao.get_divided_list(one_period, start_time, list_group)
    #
    #         job_info_contained = dao.get_job_info_contained()
    #         return ResponseForm(res=True, data=(job_list, job_info_contained))
    #
    #     except Exception as e:
    #         return ResponseForm(res=False, msg=str(e))

    # def get_summary(self, log_name, job_id, **args):
    #     try:
    #         dao_pickup_items = DAOAnalysisItems(log_name=log_name)
    #         columns_str = dao_pickup_items.get_columns_comma_separated()
    #         if columns_str is not None:
    #             dao = self.get_dao(log_name)
    #             dao.load_data(job_id=job_id, **args)
    #
    #             summary_result = None
    #             all_merge_df = None
    #
    #             if args['group_by'] == 'column':
    #                 group = args['group_value']
    #             else:
    #                 group = args['group_by']
    #
    #             cell_form_list = dao_pickup_items.get_unique_cell_formula_list()
    #
    #             for cell_form in cell_form_list:
    #                 cell_column_list = dao_pickup_items.get_column_list(cell_form=cell_form)
    #                 split_cell_form_list = cell_form.split('.')
    #                 cell_df = dao.get_df()
    #
    #                 for formula in split_cell_form_list:
    #                     cell_df = calculator.calc_formula(formula, cell_df, cell_column_list, group)
    #
    #                 all_form_list = dao_pickup_items.get_unique_all_formula_list(cell_form=cell_form)
    #
    #                 for all_form in all_form_list:
    #                     all_column_list = dao_pickup_items.get_column_list(cell_form=cell_form,
    #                                                                        all_form=all_form)
    #                     split_all_form_list = all_form.split('.')
    #                     all_summary_df = deepcopy(cell_df)
    #
    #                     for formula in split_all_form_list:
    #                         all_summary_df = calculator.calc_formula(formula, all_summary_df, all_column_list)
    #
    #                     if isinstance(all_summary_df, pd.Series):
    #                         df = pd.DataFrame(all_summary_df, columns=['ALL']).T
    #                         if all_merge_df is None:
    #                             all_merge_df = df
    #                         else:
    #                             all_merge_df = pd.concat([all_merge_df, df], axis=1)
    #
    #                 disp_str_dict = dao_pickup_items.get_disp_str_dict(col_list=cell_column_list, cell_form=cell_form)
    #                 if isinstance(cell_df, pd.Series):
    #                     cell_df = pd.DataFrame(cell_df).T
    #
    #                 cell_df.rename(columns=disp_str_dict, inplace=True)
    #                 if all_merge_df is not None:
    #                     all_merge_df.rename(columns=disp_str_dict, inplace=True)
    #
    #                 if summary_result is None:
    #                     summary_result = cell_df
    #                 else:
    #                     summary_result = summary_result.reset_index().merge(cell_df.reset_index(), how='left').set_index('index')
    #
    #             if summary_result is not None:
    #                 if args['jobname'] is not None:
    #                     summary_result['device'] = args['jobname'].split('/')[0]
    #                     summary_result['process'] = args['jobname'].split('/')[1]
    #
    #                     disp_str_dict = {'device': 'Device', 'process': 'Process'}
    #                     summary_result.rename(columns=disp_str_dict, inplace=True)
    #
    #                 if group == 'period':
    #                     # cell_df = dao.get_df()
    #                     # cell_df['log_time'] = cell_df['period']
    #                     # cell_df = cell_df.groupby('log_time', sort=False)['period'].min()
    #                     # cell_df = calculator.calc_formula('min', cell_df, 'period', 'log_time')
    #                     cell_df = None
    #                     disp_str_dict['period'] = 'Date'
    #                 else:
    #                     cell_df = dao.get_df()
    #                     cell_df = calculator.calc_formula('min', cell_df, 'log_time', group)
    #                     disp_str_dict = dao_pickup_items.get_disp_str_dict(col_list=[group])
    #                     disp_str_dict['log_time'] = 'Date'
    #
    #                 if cell_df is not None:
    #                     if isinstance(cell_df, pd.Series):
    #                         cell_df = pd.DataFrame(cell_df).T
    #
    #                     summary_result = summary_result.reset_index().merge(cell_df.reset_index(), how='left').set_index('index')
    #
    #                 summary_result.reset_index(inplace=True)
    #                 summary_result['index'] = summary_result['index'] + 1
    #                 disp_str_dict['index'] = 'No.'
    #
    #                 if all_merge_df is not None:
    #                     all_merge_df.reset_index(inplace=True)
    #                     summary_result = pd.concat([summary_result, all_merge_df])
    #                     summary_result.reset_index(inplace=True, drop=True)
    #
    #                 summary_result.rename(columns=disp_str_dict, inplace=True)
    #
    #                 disp_order = dao_pickup_items.sort_by_disp_order(summary_result.columns)
    #                 disp_graph = dao_pickup_items.get_disp_srt_vs_disp_graph_f_dict(summary_result.columns)
    #                 rtn_dict = {'disp_order': disp_order, 'disp_graph_f': disp_graph,
    #                             'summary': summary_result.to_dict(orient='index')}
    #                 return ResponseForm(res=True, data=rtn_dict)
    #             else:
    #                 return ResponseForm(res=False, msg='There is nothing to summary.')
    #         else:
    #             return ResponseForm(res=False, msg='There is no Pickup Items.')
    #     except Exception as e:
    #         return ResponseForm(res=False, msg=str(e))

    def get_analysis(self, func_id, rid, **args):
        try:
            dao_base = DAOBaseClass(table_name='analysis.function')
            func_dict = dao_base.fetch_one(args={'select': 'log_name, show_org', 'where': f'id={func_id}'})
            if func_dict is None:
                return ResponseForm(res=False, msg='no matching function id.')

            log_name = func_dict['log_name']
            show_org = func_dict['show_org']

            dao_convert = self.get_convert_dao(log_name)
            len = dao_convert.load_data(rid=rid, **args['filter'])
            if len == 0:
                return ResponseForm(res=False, msg='Nothing to Analysis.')
            convert_df = dao_convert.get_df()

            if show_org:
                resp_form = self.get_options(func_id, rid)
                if not resp_form.res:
                    return ResponseForm(res=False, msg=resp_form.msg)

                options = resp_form.data

                selected_period = [args['filter']['log_time']['start'], args['filter']['log_time']['end']]
                options['period']['selected'] = selected_period

                for item in options['filter']:
                    item['selected'] = args['filter'][item['target']]

                disp_order = convert_df.columns.values.tolist()
                if 'log_time' in disp_order:
                    disp_order.remove('log_time')
                    disp_order.insert(0, 'log_time')

                disp_graph = []
                for col in convert_df.columns:
                    try:
                        convert_df[col].astype({col: np.float})
                        disp_graph.append(col)
                    except Exception:
                        pass

                ret = dict()
                ret['option'] = options
                ret['data'] = {'disp_order': disp_order,
                               'disp_graph': disp_graph,
                               'row': convert_df.to_dict(orient='index')
                               }

                return ResponseForm(res=True, data=ret)
            else:
                aggregation_type = args['aggregation']['type']
                aggregation_val = args['aggregation']['val']
                # if aggregation_type == 'period':
                #     convert_df = preprocessing.divide_by_stats_period(convert_df, args['filter']['log_time']['start'],
                #                                                       aggregation_val)

                resp_form = self.exec_analysis(src_df=convert_df, func_id=func_id, **args)
                if not resp_form.res:
                    return resp_form
                else:
                    df_result = resp_form.data
                    ########### GET Options #############
                    resp_form = self.get_options(func_id, rid)
                    if not resp_form.res:
                        return ResponseForm(res=False, msg=resp_form.msg)

                    options = resp_form.data

                    selected_period = [args['filter']['log_time']['start'], args['filter']['log_time']['end']]
                    options['period']['selected'] = selected_period

                    for item in options['filter']:
                        if item['target'] in args['filter']:
                            item['selected'] = args['filter'][item['target']]
                        else:
                            item['selected'] = None

                    resp_form = self.get_aggregation_default(func_id)
                    if not resp_form.res:
                        return ResponseForm(res=False, msg=resp_form.msg)

                    aggregation = resp_form.data['aggregation']
                    aggregation['selected'] = aggregation_type
                    if aggregation_type in aggregation['subItem']:
                        aggregation['subItem'][aggregation_type]['selected'] = aggregation_val
                    # for key, val in aggregation.items():
                    #     options[key] = val
                    options['aggregation'] = aggregation
                    ######################################
                    df_result['option'] = options
                    return ResponseForm(res=True, data=df_result)

        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_analysis_preview(self, df, **kwargs):
        filter_list = kwargs['filter_default']
        aggregation = kwargs['aggregation_default']

        if kwargs['show_org']:
            for filter in filter_list:
                if len(filter['val']) > 0:
                    df = df[df[filter['key']].isin(filter['val'])]
            df.reset_index(drop=True, inplace=True)

            disp_order = df.columns.values.tolist()
            if 'log_time' in disp_order:
                disp_order.remove('log_time')
                disp_order.insert(0, 'log_time')

            disp_graph = []
            for col in df.columns:
                try:
                    df[col].astype({col: np.float})
                    disp_graph.append(col)
                except Exception:
                    pass

            data = dict()
            data['data'] = {'disp_order': disp_order, 'disp_graph': disp_graph, 'row': df.to_dict(orient='index')}
            return ResponseForm(res=True, data=data)
        else:
            for filter in filter_list:
                if len(filter['val']) > 0:
                    df = df[df[filter['key']].isin(filter['val'])]
            df.reset_index(drop=True, inplace=True)

            if len(df) == 0:
                df = df.astype(float)
            else:
                df = df.astype({'log_time': 'datetime64'})

            analysis_items = kwargs['items']

            analysis_items_df = pd.DataFrame(analysis_items)

            args = {'filter': filter_list, 'aggregation': aggregation}
            return self.exec_analysis(src_df=df, item_df=analysis_items_df, **args)

    def exec_analysis(self, src_df=None, func_id=None, item_df=None, **args):
        if func_id is not None:
            dao_analysis_items = DAOAnalysisItems(func_id=func_id)
        else:
            dao_analysis_items = DAOAnalysisItems(df=item_df)

        analysis_result = None
        total_merge_df = None

        aggregation_type = args['aggregation']['type']
        aggregation_val = args['aggregation']['val']

        if aggregation_type == 'column':
            group = aggregation_val
        elif aggregation_type == 'period':
            group = aggregation_type
            if len(src_df) == 0:
                src_df['period'] = None
            else:
                log_start = str(src_df['log_time'].min())
                src_df = preprocessing.divide_by_stats_period(src_df, log_start, aggregation_val)
        else:
            group = None

        group_analysis_list = dao_analysis_items.get_analysis_list_by_order()

        for item in group_analysis_list:
            group_analysis = item['group_analysis']
            group_analysis_type = item['group_analysis_type']
            # group_column_list = dao_analysis_items.get_column_list(group_analysis=group_analysis)
            try:
                group_df = self.exec_calculate(group_analysis, group_analysis_type, src_df, [item['source_col']], group)
                if isinstance(group_df, pd.Series):
                    group_df = pd.DataFrame(group_df).T
                elif isinstance(group_df, (np.int64, np.float64)):
                    group_df = pd.DataFrame({item['source_col']: [group_df]})

                disp_str_dict = {item['source_col']: item['title']}
                cp_group_df = deepcopy(group_df)
                group_df.rename(columns=disp_str_dict, inplace=True)

                if analysis_result is None:
                    analysis_result = group_df
                else:
                    analysis_result = analysis_result.reset_index().merge(group_df.reset_index(),
                                                                          how='left').set_index('index')

                total_analysis = item['total_analysis']
                total_analysis_type = item['total_analysis_type']
                # total_column_list = dao_analysis_items.get_column_list(group_analysis=group_analysis,
                #                                                         total_analysis=total_analysis)
                total_df = self.exec_calculate(total_analysis, total_analysis_type, cp_group_df, [item['source_col']])
                if isinstance(total_df, pd.Series):
                    total_df = pd.DataFrame(total_df, columns=['ALL']).T
                elif isinstance(total_df, (np.int64, np.float64)):
                    total_df = pd.DataFrame({item['source_col']: total_df}, index=['ALL'])

                if total_merge_df is None:
                    total_merge_df = total_df
                else:
                    total_merge_df = pd.concat([total_merge_df, total_df], axis=1)

                if total_merge_df is not None:
                    total_merge_df.rename(columns=disp_str_dict, inplace=True)

            except Exception as e:
                print(str(e))
                continue

        if analysis_result is not None:
            if group == 'period':
                cell_df = None
                # disp_str_dict['period'] = 'Date'
            else:
                cell_df = deepcopy(src_df)
                cell_df = calculator.calc_formula('min', cell_df, 'log_time', group)
                if isinstance(cell_df, pd.Series):
                    cell_df = pd.DataFrame(cell_df).T
                elif isinstance(cell_df, pd._libs.tslibs.timestamps.Timestamp):
                    cell_df = pd.DataFrame({'log_time': [cell_df]})

                analysis_result = analysis_result.reset_index().merge(cell_df.reset_index(),
                                                                      how='left').set_index('index')

                # disp_str_dict = dao_analysis_items.get_disp_str_dict(col_list=[group])
                # disp_str_dict['log_time'] = 'Date'

            # if cell_df is not None:
            #     if isinstance(cell_df, pd.Series):
            #         cell_df = pd.DataFrame(cell_df).T
            #
            #     analysis_result = analysis_result.reset_index().merge(cell_df.reset_index(),
            #                                                           how='left').set_index('index')

            analysis_result.reset_index(inplace=True)
            analysis_result['index'] = analysis_result['index'] + 1
            disp_str_dict = {'index': 'No.'}

            if total_merge_df is not None:
                total_merge_df.reset_index(inplace=True)
                analysis_result = pd.concat([analysis_result, total_merge_df])
                analysis_result.reset_index(inplace=True, drop=True)

            analysis_result.rename(columns=disp_str_dict, inplace=True)

            disp_order = dao_analysis_items.sort_by_disp_order(analysis_result.columns, group)
            disp_graph = []
            for col in analysis_result.columns:
                try:
                    analysis_result[col].astype({col: np.float})
                    disp_graph.append(col)
                except Exception:
                    pass

            rtn_dict = {'data': {'disp_order': disp_order,
                                 'disp_graph': disp_graph,
                                 'row': analysis_result.to_dict(orient='index')
                                 }
                        }
            return ResponseForm(res=True, data=rtn_dict)
        else:
            return ResponseForm(res=False, msg='There is nothing to summary.')


    # def exec_analysis(self, src_df=None, func_id=None, item_df=None, **args):
    #     if func_id is not None:
    #         dao_analysis_items = DAOAnalysisItems(func_id=func_id)
    #     else:
    #         dao_analysis_items = DAOAnalysisItems(df=item_df)
    #
    #     columns_str = dao_analysis_items.get_columns_comma_separated()
    #     if columns_str is not None:
    #         analysis_result = None
    #         total_merge_df = None
    #
    #         aggregation_type = args['aggregation']['type']
    #         aggregation_val = args['aggregation']['val']
    #
    #         if aggregation_type == 'column':
    #             group = aggregation_val
    #         elif aggregation_type == 'period':
    #             group = aggregation_type
    #             log_start = str(src_df['log_time'].min())
    #             src_df = preprocessing.divide_by_stats_period(src_df, log_start, aggregation_val)
    #         else:
    #             group = None
    #
    #         group_analysis_list = dao_analysis_items.get_seq_group_analysis_list()
    #
    #         for item in group_analysis_list:
    #             group_analysis = item['group_analysis']
    #             group_analysis_type = item['group_analysis_type']
    #             group_column_list = dao_analysis_items.get_column_list(group_analysis=group_analysis)
    #             group_df = self.exec_calculate(group_analysis, group_analysis_type, src_df, group_column_list, group)
    #             if isinstance(group_df, pd.Series):
    #                 group_df = pd.DataFrame(group_df).T
    #
    #             total_analysis_list = dao_analysis_items.get_seq_total_analysis_list(group_analysis=group_analysis)
    #             for total_item in total_analysis_list:
    #                 total_analysis = total_item['total_analysis']
    #                 total_analysis_type = total_item['total_analysis_type']
    #                 total_column_list = dao_analysis_items.get_column_list(group_analysis=group_analysis,
    #                                                                         total_analysis=total_analysis)
    #                 total_df = self.exec_calculate(total_analysis, total_analysis_type, group_df, total_column_list)
    #                 if isinstance(total_df, pd.Series):
    #                     total_df = pd.DataFrame(total_df, columns=['ALL']).T
    #
    #                 if total_merge_df is None:
    #                     total_merge_df = total_df
    #                 else:
    #                     total_merge_df = pd.concat([total_merge_df, total_df], axis=1)
    #
    #             disp_str_dict = dao_analysis_items.get_disp_str_dict(col_list=group_column_list,
    #                                                                  group_analysis=group_analysis)
    #             group_df.rename(columns=disp_str_dict, inplace=True)
    #             if total_merge_df is not None:
    #                 total_merge_df.rename(columns=disp_str_dict, inplace=True)
    #
    #             if analysis_result is None:
    #                 analysis_result = group_df
    #             else:
    #                 analysis_result = analysis_result.reset_index().merge(group_df.reset_index(),
    #                                                                       how='left').set_index('index')
    #
    #         if analysis_result is not None:
    #             if group == 'period':
    #                 cell_df = None
    #                 # disp_str_dict['period'] = 'Date'
    #             else:
    #                 cell_df = deepcopy(src_df)
    #                 cell_df = calculator.calc_formula('min', cell_df, 'log_time', group)
    #                 disp_str_dict = dao_analysis_items.get_disp_str_dict(col_list=[group])
    #                 # disp_str_dict['log_time'] = 'Date'
    #
    #             if cell_df is not None:
    #                 if isinstance(cell_df, pd.Series):
    #                     cell_df = pd.DataFrame(cell_df).T
    #
    #                 analysis_result = analysis_result.reset_index().merge(cell_df.reset_index(),
    #                                                                       how='left').set_index('index')
    #
    #             analysis_result.reset_index(inplace=True)
    #             analysis_result['index'] = analysis_result['index'] + 1
    #             disp_str_dict['index'] = 'No.'
    #
    #             if total_merge_df is not None:
    #                 total_merge_df.reset_index(inplace=True)
    #                 analysis_result = pd.concat([analysis_result, total_merge_df])
    #                 analysis_result.reset_index(inplace=True, drop=True)
    #
    #             analysis_result.rename(columns=disp_str_dict, inplace=True)
    #
    #             disp_order = dao_analysis_items.sort_by_disp_order(analysis_result.columns, group)
    #             disp_graph = []
    #             for col in analysis_result.columns:
    #                 try:
    #                     analysis_result[col].astype({col: np.float})
    #                     disp_graph.append(col)
    #                 except Exception:
    #                     pass
    #
    #             rtn_dict = {'data': {'disp_order': disp_order,
    #                                  'disp_graph': disp_graph,
    #                                  'row': analysis_result.to_dict(orient='index')
    #                                  }
    #                         }
    #             return ResponseForm(res=True, data=rtn_dict)
    #         else:
    #             return ResponseForm(res=False, msg='There is nothing to summary.')
    #     else:
    #         return ResponseForm(res=False, msg='There is no Analysis Item.')

    def exec_calculate(self, formula, type, df, col_list, group=None):
        out_df = deepcopy(df)
        if type == 'sequential':
            formula_list = formula.split('.')
            for form in formula_list:
                out_df = calculator.calc_formula(form, out_df, col_list, group)
        elif type == 'custom':
            out_df = calculator.calc_formula(formula, out_df, col_list, group, custom=True)
        else:
            out_df = calculator.calc_formula(formula, out_df, col_list, group)

        return out_df

    def get_convert_dao(self, log_name):
        dao = DAOBaseClass(table_name='cnvbase.log_define_master')
        row = dao.fetch_one(args={'select': 'table_name', 'where': f"log_name='{log_name}'"})

        return DAOBaseClass(table_name='convert.{}'.format(row['table_name']))

    # todo DB에서 그룹핑이 가능한 컬럼 정보를 참조하도록 구성 변경 필요
    def get_group_avail_columns(self, log_name):
        if log_name == 'PLATEAUTOFOCUSCOMPENSATION':
            return ['lot_id']
        elif log_name == 'LiPSFocus':
            return []
        elif log_name == 'TiltMeasurementLog':
            return []
        elif log_name == 'MountPressLog':
            return []
        elif log_name == 'PRESCANCOMPENSATIONMONITOR':
            return ['lot_id']

    # todo DB에서 필터링 가능한 컬럼 정보를 참조하도록 구성 변경 필요
    def get_filter_key_value(self, log_name):
        if log_name == 'PLATEAUTOFOCUSCOMPENSATION':
            return {'key': [], 'value': []}
        elif log_name == 'LiPSFocus':
            return {'key': [], 'value': []}
        elif log_name == 'TiltMeasurementLog':
            return {'key': [], 'value': []}
        elif log_name == 'MountPressLog':
            return {'key': ['status'], 'value': [{'status': ['Job']}]}
        elif log_name == 'PRESCANCOMPENSATIONMONITOR':
            return {'key': [], 'value': []}

    def get_detail(self, func_id, rid, **args):
        try:
            # dao_pickup_items = DAOAnalysisItems(log_name=log_name)
            dao_base = DAOBaseClass(table_name='analysis.function')
            func_dict = dao_base.fetch_one(args={'select': 'log_name', 'where': f'id={func_id}'})
            if func_dict is None:
                return ResponseForm(res=False, msg='no matching function id.')

            log_name = func_dict['log_name']

            dao_convert = self.get_convert_dao(log_name)
            len = dao_convert.load_data(rid=rid, **args['filter'])
            if len == 0:
                return ResponseForm(res=False, msg='Nothing to Analysis.')

            convert_df = dao_convert.get_df()

            dao_analysis_items = DAOAnalysisItems(func_id=func_id)
            columns_str = dao_analysis_items.get_columns_comma_separated()
            if columns_str is not None:
                columns = dao_analysis_items.get_column_list()

                aggregation_type = args['aggregation']['type']
                aggregation_val = args['aggregation']['val']
                selected = args['aggregation']['selected']

                if aggregation_type == 'column':
                    column = aggregation_val
                    convert_df = convert_df.astype({column: str})
                    df = convert_df[convert_df[column].isin(selected)]
                elif aggregation_type == 'period':
                    column = 'period'
                    aggregation_val = aggregation_val
                    log_start = str(convert_df['log_time'].min())
                    convert_df = preprocessing.divide_by_stats_period(convert_df, log_start, aggregation_val)
                    df = convert_df[convert_df[column].isin(selected)]
                else:
                    df = convert_df
                    column = None

                if 'process' in df.columns:
                    columns.append('process')

                if 'device' in df.columns:
                    columns.append('device')

                if 'log_time' in df.columns:
                    columns.append('log_time')

                if column is not None and column not in columns:
                    columns.append(column)

                df = df[columns]

                # column_list = dao_pickup_items.get_column_list()
                # disp_str_dict = dao_pickup_items.get_detail_disp_str_dict(col_list=column_list)
                # df.rename(columns=disp_str_dict, inplace=True)

                df.reset_index(inplace=True, drop=True)
                df.reset_index(inplace=True)
                df['index'] = df['index'] + 1
                disp_order = dao_analysis_items.sort_by_column_order(df.columns, column)
                disp_graph = []
                for col in df.columns:
                    try:
                        df[col].astype({col: np.float})
                        disp_graph.append(col)
                    except Exception:
                        pass
                if 'index' in disp_graph:
                    disp_graph.remove('index')

                ########### SET Options #############
                filter_list = []
                if aggregation_type != 'all':
                    filter_option = dict()
                    filter_option['target'] = column
                    filter_option['title'] = column
                    filter_option['type'] = 'select'
                    filter_option['mode'] = 'plural'
                    filter_option['selected'] = selected
                    filter_option['options'] = selected
                    filter_list.append(filter_option)
                ######################################

                rtn_dict = {
                    'data': {
                        'disp_order': disp_order,
                        'disp_graph': disp_graph,
                        'row': df.to_dict(orient='index')
                    },
                    'option': {
                        'filter': filter_list
                    }
                }

                return ResponseForm(res=True, data=rtn_dict)
            else:
                return ResponseForm(res=False, msg='There is no Analysis Items.')
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_show_org(self, func_id):
        dao_func = DAOBaseClass(table_name='analysis.function')
        row = dao_func.fetch_one(args={'select': 'show_org', 'where': f"id='{func_id}'"})
        if row is None:
            return ResponseForm(res=False, msg='No matching func_id')

        return ResponseForm(res=True, data=dict(row))

    def get_options(self, func_id, rid):
        try:
            resp_form = self.get_log_name(func_id)
            if not resp_form.res:
                return resp_form

            log_name = resp_form.data

            resp_form = self.get_table_name(log_name)
            if not resp_form.res:
                return resp_form

            table_name = resp_form.data

            dao_convert = DAOBaseClass(table_name=f'convert.{table_name}')
            resp_form = dao_convert.get_log_period(where={'request_id': rid})
            if not resp_form.res:
                return ResponseForm(res=False, msg=resp_form.msg)

            data = dict()
            data['period'] = {**resp_form.data, 'selected': []}

            dao_convert.load_data(rid=rid)
            log_df = dao_convert.get_df()
            if len(log_df) == 0:
                return ResponseForm(res=False, msg='Log Data Empty.')

            dao_filter_default = DAOBaseClass(table_name='analysis.filter_default')
            df_filter_default = dao_filter_default.fetch_all(args={'where': f"func_id='{func_id}'"})

            filter_list = []
            for key in df_filter_default['key'].unique().tolist():
                filter = dict()

                filter['target'] = key
                filter['title'] = key
                filter['type'] = 'select'
                filter['mode'] = 'plural'
                selected_list = df_filter_default[df_filter_default['key'] == key]['val'].tolist()
                selected_list = [_ for _ in selected_list if _ is not None]
                filter['selected'] = selected_list
                filter['options'] = log_df[key].unique().tolist()

                filter_list.append(filter)

            # for i in range(len(df_filter_default)):
            #     filter = dict()
            #     key = df_filter_default['key'][i]
            #     val = df_filter_default['val'][i]
            #
            #     filter['target'] = key
            #     filter['title'] = key
            #     filter['type'] = 'select'
            #     filter['mode'] = 'plural'
            #     filter['selected'] = [str(_) for _ in val.split(sep=',')]
            #     filter['options'] = log_df[key].unique().tolist()
            #
            #     filter_list.append(filter)

            data['filter'] = filter_list

            return ResponseForm(res=True, data=data)
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_aggregation_default(self, func_id):
        try:
            resp_form = self.get_log_name(func_id)
            if not resp_form.res:
                return resp_form

            log_name = resp_form.data

            resp_form = self.get_table_name(log_name)
            if not resp_form.res:
                return resp_form

            table_name = resp_form.data

            dao_aggregation_default = DAOBaseClass(table_name='analysis.aggregation_default')
            dict_aggregation_default = dao_aggregation_default.fetch_one(args={'where': f"func_id='{func_id}'"})

            resp_form = self.get_aggreg_form()
            if not resp_form.res:
                return ResponseForm(res=False, msg='get json form file fail.')

            aggreg_form = resp_form.data

            dao_aggregation_type = DAOBaseClass(table_name='public.aggregation_type')
            df_aggregation_type = dao_aggregation_type.fetch_all()
            aggregation_type_list = df_aggregation_type['type'].tolist()

            aggreg_form['options'] = aggregation_type_list
            if dict_aggregation_default is None:
                aggreg_form['selected'] = 'all'
            else:
                aggreg_form['selected'] = dict_aggregation_default['type']

            for key, val in aggreg_form['subItem'].items():
                if dict_aggregation_default is not None:
                    if key == dict_aggregation_default['type']:
                        val['selected'] = dict_aggregation_default['val']
                        # aggreg_form['selected'] = key

                if key == 'column':
                    df_column_info = dao_aggregation_default.get_column_info(table=f'convert.{table_name}')
                    df_column_info = df_column_info[~(df_column_info['column_name'].isin(app_config.COLUMN_OMIT_LIST))]
                    df_column_info.reset_index(inplace=True, drop=True)
                    col_options = []
                    for i in range(len(df_column_info)):
                        column_type = df_column_info['data_type'][i]
                        if column_type in [lc.const.data_type_text, lc.const.data_type_bool, 'character varying', lc.const.data_type_int, lc.const.data_type_float]:
                            col_options.append(df_column_info['column_name'][i])
                    val['options'] = col_options

            data = dict()
            data['aggregation'] = aggreg_form
            return ResponseForm(res=True, data=data)
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_visualization_default(self, func_id):
        try:
            visualization = self.get_visualization_info(func_id)

            return ResponseForm(res=True, data={'visualization': visualization})
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_aggreg_form(self):
        try:
            with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_JSON_OPT_AGGREG_FORM), 'r') as f:
                json_data = json.load(f)

            return ResponseForm(res=True, data=json_data)

        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_log_name(self, func_id):
        dao_func = DAOBaseClass(table_name='analysis.function')
        func_df = dao_func.fetch_all(args={'where': f"id='{func_id}'"})
        if len(func_df) == 0:
            return ResponseForm(res=False, msg='No matching func_id')

        return ResponseForm(res=True, data=func_df['log_name'][0])

    def get_table_name(self, log_name):
        dao_log_define = DAOBaseClass(table_name='cnvbase.log_define_master')
        log_define = dao_log_define.fetch_all(args={'where': f"log_name='{log_name}'"})
        if len(log_define) == 0:
            return ResponseForm(res=False, msg='No matching log_name')

        return ResponseForm(res=True, data=log_define['table_name'][0])

    def get_visualization_info(self, func_id):
        visualization = dict()

        dao_graph_type = DAOBaseClass(table_name='public.graph_type')
        df_graph_type = dao_graph_type.fetch_all()
        graph_type_list = []
        for i in range(len(df_graph_type)):
            item = dict()
            item['type'] = df_graph_type['type'][i]
            item['z_axis'] = df_graph_type['z_axis'][i]
            graph_type_list.append(item)

        visualization['graph_type'] = graph_type_list

        dao_visualization = DAOBaseClass(table_name='analysis.visualization_default')
        df_visualization = dao_visualization.fetch_all(args={'where': f"func_id='{func_id}'"})

        items = []
        for i in range(len(df_visualization)):
            item = dict()
            item['title'] = df_visualization['title'][i]
            item['type'] = [str(_) for _ in df_visualization['type'][i].split(sep=',')]
            item['x_axis'] = df_visualization['x_axis'][i]
            item['y_axis'] = df_visualization['y_axis'][i]
            item['z_axis'] = df_visualization['z_axis'][i]
            item['x_range_max'] = df_visualization['x_range_max'][i]
            item['x_range_min'] = df_visualization['x_range_min'][i]
            item['y_range_max'] = df_visualization['y_range_max'][i]
            item['y_range_min'] = df_visualization['y_range_min'][i]
            item['z_range_max'] = df_visualization['z_range_max'][i]
            item['z_range_min'] = df_visualization['z_range_min'][i]

            items.append(item)

        visualization['items'] = items

        return visualization