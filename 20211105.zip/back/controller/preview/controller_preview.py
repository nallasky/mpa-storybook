import logging
import pandas as pd
import numpy as np
from io import StringIO
import datetime
import os
import importlib
import inspect

from flask import request, json
from flask_restx import Resource, Namespace
import requests
from werkzeug.datastructures import FileStorage
from config import app_config
from common.utils.response import make_json_response, ResponseForm
from dao import get_dbinfo
from dao.dao_management_setting import DAOMGMTSetting
from dao.dao_base import DAOBaseClass
import convert as lc
from service.analysis.service_analysis import AnalysisService
from service.resources.service_resources import ResourcesService

logger = logging.getLogger(app_config.LOG)

PREVIEW = Namespace(name='PREVIEW', description='機能追加STEP別画面のPreview機能用API。')


@PREVIEW.route('/samplelog')
class SampleLog(Resource):
    parser = PREVIEW.parser()
    parser.add_argument('files', type=FileStorage, location='files', help='FILE名')
    parser.add_argument('script_file', type=FileStorage, location='files', help='Script File')
    parser.add_argument('source', required=True, type=str, help='local or remote')
    parser.add_argument('equipment_name', type=str, help='Equipment Name')
    parser.add_argument('table_name', type=str, help='Table Name')
    parser.add_argument('start', type=str, help='Get Sample Log from Start')
    parser.add_argument('end', type=str, help='Log Name')
    parser.add_argument('sql', type=str, help='SQL Query')
    parser.add_argument('use_script', type=bool, help='use_script on/off')
    parser.add_argument('db_id', type=int, help='Database ID')
    parser.add_argument('func_id', type=int, help='Fucntion ID')

    @PREVIEW.expect(parser)
    @PREVIEW.response(200, 'Success')
    @PREVIEW.response(400, 'Bad Request')
    def post(self):
        """
        機能追加STEP2画面のPreview機能対応。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        logger.debug(f'args : {args}')

        f = args['files']
        script = args['script_file']
        source = args['source']
        equipment_name = args['equipment_name']
        table_name = args['table_name']
        start = args['start']
        end = args['end']
        sql = args['sql']
        db_id = args['db_id']
        use_script = args['use_script']
        func_id = args['func_id']

        _number_of_lines = app_config.SAMPLE_LINES

        try:
            if not os.path.exists(app_config.TEMP_PATH):
                os.mkdir(app_config.TEMP_PATH)

            if source == 'local':
                file_path = os.path.join(app_config.TEMP_PATH, f.filename)
                f.save(file_path)

                if use_script:
                    resp_form = self.run_preprocess_script(file_path, script)
                    if not resp_form.res:
                        return make_json_response(status=400, msg=resp_form.msg)
                    file_path = resp_form.data

                f = open(file_path, mode='r', encoding='utf-8')

                data = f.readlines()
                col_max = 0
                cnt = 0
                for line in data:
                    # col_num = len(line.decode('utf-8').split(','))
                    col_num = len(line.split(','))
                    if col_max < col_num:
                        col_max = col_num
                    cnt += 1
                    if cnt >= _number_of_lines:
                        break

                f.seek(0)
                df = pd.read_csv(f, header=None, index_col=False, nrows=_number_of_lines,
                                 skipinitialspace=True, names=range(col_max))
                df.columns = df.columns + 1
                df.index = df.index + 1
                df = df.apply(lambda x: x.str.strip() if x.dtypes == object else x)
                data = df.to_dict(orient='index')
                columns = [str(column) for column in df.columns]
                rtn = {'result': True, 'data': {'disp_order': columns, 'row': data}}

                return make_json_response(**rtn)
            elif source == 'remote' or source == 'sql':
                dao_mgmt = DAOMGMTSetting()
                df = dao_mgmt.fetch_all(args={'where': f"target = 'remote' and id = {db_id}"})

                if len(df) == 0:
                    return make_json_response(status=400, msg='Cannot find any matching db id')

                # connection check
                conf = df.iloc[0].to_dict()
                conf['user'] = conf.pop('username')

                dao_remote = DAOBaseClass(**conf)
                resp_form = dao_remote.connection_check()
                if not resp_form.res:
                    logger.debug(f'connection check failed : {resp_form.msg}')
                    return make_json_response(status=400, msg=resp_form.msg)

                if source == 'remote':
                    filter = {'equipment_name': equipment_name, 'log_time': {'start': start, 'end': end}}
                    log_count = dao_remote.load_data(table=table_name, **filter)
                    if not log_count:
                        return make_json_response(status=400, msg='There is no matchin log data.')

                    df = dao_remote.get_df()
                    file_path = os.path.join(app_config.TEMP_PATH, 'remote.csv')
                else:
                    df = dao_remote.read_sql(query=sql)
                    if len(df) == 0:
                        return make_json_response(status=400, msg='There is no matchin log data.')

                    file_path = os.path.join(app_config.TEMP_PATH, 'sql.csv')

                df.to_csv(file_path, header=True, index=False)

                if use_script:
                    resp_form = self.run_preprocess_script(file_path, script)
                    if not resp_form.res:
                        return make_json_response(status=400, msg=resp_form.msg)
                    file_path = resp_form.data

                df = pd.read_csv(file_path, header=0, index_col=False, nrows=_number_of_lines, skipinitialspace=True)

                src_col_list = []
                filter_key_list = []
                for col in df.columns:
                    if df[col].dtypes == object or df[col].dtypes == np.int64:
                        filter_key_list.append(col)
                    if df[col].dtypes == np.int64 or df[col].dtypes == float:
                        src_col_list.append(col)

                df.index = df.index + 1
                columns = [str(column) for column in df.columns]
                if 'log_time' in columns:
                    columns.remove('log_time')
                    columns.insert(0, 'log_time')

                data = df.to_dict(orient='index')

                options = dict()

                resource_service = ResourcesService()
                resp_form = resource_service.get_analysis_info(func_id=func_id)
                if resp_form.res:
                    options['analysis'] = resp_form.data

                resp_form = resource_service.get_visualization_info(func_id=func_id)
                if resp_form.res:
                    options['visualization'] = resp_form.data

                rtn = {'result': True,
                       'data': {
                           'disp_order': columns,
                           'src_col_list': src_col_list,
                           'filter_key_list': filter_key_list,
                           'row': data
                       },
                       **options
                       }

                return make_json_response(**rtn)
            else:
                return make_json_response(status=400, msg='Wrong source type.')

        except Exception as e:
            logger.debug(str(e))
            return make_json_response(status=400, msg=str(e))

    def run_preprocess_script(self, file_path, script):
        try:
            if script.filename.count('.') > 1:
                return ResponseForm(res=False, msg="Don't use '.' character for script file name")

            now = datetime.datetime.now()
            # folder = now.strftime("request_%Y%m%d_%H%M%S%f")
            folder = 'preprocess'
            script_file_path = os.path.join(app_config.SCRIPT_PATH, folder)
            if not os.path.exists(script_file_path):
                os.mkdir(script_file_path)

            script.save(os.path.join(script_file_path, script.filename))

            mod_name = '.'.join([app_config.SCRIPT_PATH, folder, script.filename.split(sep='.')[0]])
            mod = importlib.import_module(mod_name)

            class_list = inspect.getmembers(mod, inspect.isclass)
            class_name_list = [cls[0] for cls in class_list]
            if 'PreprocessScript' not in class_name_list:
                return ResponseForm(res=False, msg='PreprocessScript CLASS is not exist.')

            cls = getattr(mod, 'PreprocessScript')
            func_list = inspect.getmembers(cls, inspect.isfunction)
            func_name_list = [func[0] for func in func_list]

            fixed_func_list = ['run']
            for func in fixed_func_list:
                if func not in func_name_list:
                    return ResponseForm(res=False, msg=f'Function {func} is not exist.')

            obj = cls()
            file_path = obj.run(file_path)
            return ResponseForm(res=True, data=file_path)

        except Exception as e:
            logger.debug(str(e))
            return ResponseForm(res=False, msg=str(e))


@PREVIEW.route('/convert')
class PreviewConvert(Resource):
    parser = PREVIEW.parser()
    parser.add_argument('data', type=dict, location='json', required=True, help='Sample Data')
    parser.add_argument('convert', type=dict, location='json', required=True, help='convert rule info')

    @PREVIEW.expect(parser)
    @PREVIEW.response(200, 'Success')
    @PREVIEW.response(400, 'Bad Request')
    def post(self):
        """
        Get Convert Preview Data
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        logger.debug(f'data : {args["data"]}')
        logger.debug(f'convert : {args["convert"]}')

        try:
            lc_instance = lc.convert.LogConvert()
            config = get_dbinfo()
            lc_instance.set_db_config(**config)
            config['schema'] = 'convert'
            lc_instance.set_convert_db(**config)

            convert = args['convert']
            err = dict()
            disp_order = []
            form_list = []
            src_col_list = []
            filter_key_list = []
            err_exist = False
            for key in convert.keys():
                val = convert[key]
                err[key] = []
                for form in val:
                    form['type'] = key
                    form['rule_id'] = 0
                    if 'row_index' in form and form['row_index'] is not None:
                        form['row_index'] = int(form['row_index'])

                    if 'col_index' in form and form['col_index'] is not None:
                        form['col_index'] = int(form['col_index'])

                    disp_order.append(form['output_column'])

                    if form['data_type'] in [lc.const.data_type_int, lc.const.data_type_float]:
                        src_col_list.append(form['output_column'])

                    if form['data_type'] in [lc.const.data_type_text, lc.const.data_type_varchar_10,
                                               lc.const.data_type_varchar_30, lc.const.data_type_varchar_50,
                                               lc.const.data_type_int, lc.const.data_type_float]:
                        filter_key_list.append(form['output_column'])

                    form_list.append(form)

            item_df = pd.DataFrame(form_list)
            item_df['coef'] = item_df['coef'].replace({'': 0, np.nan: 0})
            item_df = item_df.astype({'coef': float})
            item_df = item_df.replace({np.nan: None})
            for _, item in item_df.iterrows():
                report = lc_instance.test_rule_item(item, item_df.drop(_))
                if len(report) > 0:
                    err[item['type']].append({'index': item['index'], 'msg': report})
                    err_exist = True

            if err_exist:
                data = dict()
                data['result'] = False
                data['err'] = err
                return make_json_response(**data)

            if args['data'] is None or len(args['data']) == 0:
                data = dict()
                data['result'] = True
                data['data'] = {'disp_order': disp_order,
                                'src_col_list': src_col_list,
                                'filter_key_list': filter_key_list,
                                'row': None}
                return make_json_response(**data)
            else:
                lines = []
                data = args['data']
                for i in range(1, len(data['row'])+1):
                    for key, val in data['row'][str(i)].items():
                        if val is None:
                            data['row'][str(i)][key] = ''

                for i in range(1, len(data['row']) + 1):
                    # line = ','.join([str(item) for item in data['row'][str(i)].values()])
                    # lines.append(line)
                    lines.append(data['row'][str(i)])

                input_df = pd.DataFrame(lines)
                df_preview = lc_instance.create_convert_preview_df(input_df, item_df)

                # df_preview = lc_instance.create_convert_preview(lines, form_list)
                if df_preview is not None:
                    df_preview.index = df_preview.index + 1
                    data = {'disp_order': df_preview.columns.values.tolist(),
                            'src_col_list': src_col_list,
                            'filter_key_list': filter_key_list,
                            'row': df_preview.to_dict(orient='index')}
                    rtn = {'result': True, 'data': data}
                    return make_json_response(**rtn)
                else:
                    return make_json_response(status=400, msg='Convert Failure.')
        except Exception as e:
            logger.debug(str(e))
            return make_json_response(status=400, msg=str(e))


@PREVIEW.route('/converted')
class PreviewConverted(Resource):
    parser = PREVIEW.parser()
    parser.add_argument('data', type=dict, location='json', required=True, help='Sample Data')
    parser.add_argument('log_name', type=str, location='json', required=True, help='Log Name')

    @PREVIEW.expect(parser)
    @PREVIEW.response(200, 'Success')
    @PREVIEW.response(400, 'Bad Request')
    def post(self):
        """
        Get Converted Preview Data when select existed log_name.
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        try:
            lc_instance = lc.convert.LogConvert()
            config = get_dbinfo()
            lc_instance.set_db_config(**config)
            config['schema'] = 'convert'
            lc_instance.set_convert_db(**config)
            lc_instance.set_extra_pkey(['request_id'])

            log_name = args['log_name']

            dao_calc_type = DAOBaseClass(table_name='public.calc_type')
            dao_aggregation_type = DAOBaseClass(table_name='public.aggregation_type')
            dao_graph_type = DAOBaseClass(table_name='public.graph_type')

            df_calc_type = dao_calc_type.fetch_all()
            df_aggregation_type = dao_aggregation_type.fetch_all()
            df_graph_type = dao_graph_type.fetch_all()

            calc_type_list = df_calc_type['type'].tolist()
            aggregation_type_list = df_aggregation_type['type'].tolist()

            graph_type_list = []
            for i in range(len(df_graph_type)):
                item = dict()
                item['type'] = df_graph_type['type'][i]
                item['z_axis'] = df_graph_type['z_axis'][i]
                graph_type_list.append(item)

            options = dict()
            options['analysis'] = {'calc_type': calc_type_list,
                                   'aggregation_type': aggregation_type_list}
            options['visualization'] = {'graph_type': graph_type_list}

            if args['data'] is None or len(args['data']) == 0:
                analysis = AnalysisService()
                resp_form = analysis.get_table_name(log_name)
                if not resp_form.res:
                    return make_json_response(status=400, msg='Please execute function at least once.')

                table_name = resp_form.data

                dao_base = DAOBaseClass()

                df_column_info = dao_base.get_column_info(table=f'convert.{table_name}')
                df_column_info = df_column_info[
                    ~(df_column_info['column_name'].isin(app_config.COLUMN_OMIT_LIST))]
                df_column_info.reset_index(inplace=True, drop=True)

                src_col_list = []
                filter_key_list = []
                for i in range(len(df_column_info)):
                    column_type = df_column_info['data_type'][i]
                    if column_type in [lc.const.data_type_int, lc.const.data_type_float]:
                        src_col_list.append(df_column_info['column_name'][i])
                    if column_type in [lc.const.data_type_text, lc.const.data_type_bool, 'character varying', lc.const.data_type_int, lc.const.data_type_float]:
                        filter_key_list.append(df_column_info['column_name'][i])

                columns = df_column_info['column_name'].tolist()

                rtn = {'result': True,
                       'data':
                           {'disp_order': columns,
                            'src_col_list': src_col_list,
                            'filter_key_list': filter_key_list,
                            'row': None
                            },
                       **options
                       }

                return make_json_response(**rtn)
            else:
                data = args['data']

                for i in range(1, len(data['row']) + 1):
                    for key, val in data['row'][str(i)].items():
                        if val is None:
                            data['row'][str(i)][key] = ''

                lines = []
                for i in range(1, len(data['row']) + 1):
                    # line = ','.join([str(item) for item in data['row'][str(i)].values()])
                    # lines.append(line)
                    lines.append(data['row'][str(i)])

                df = pd.DataFrame(lines)

                out_path = os.path.join(app_config.TEMP_PATH, 'temp.csv')
                if not os.path.exists(app_config.TEMP_PATH):
                    os.mkdir(app_config.TEMP_PATH)

                df.to_csv(out_path, header=False, index=False)
                df_out = lc_instance.convert(log_name=log_name,
                                             file=out_path,
                                             request_id='',
                                             equipment_name='',
                                             insert_db=False)

                for col in app_config.COLUMN_OMIT_LIST:
                    if col in df_out.columns:
                        df_out.drop(col, axis=1, inplace=True)

                filter_key_list = []
                src_col_list = []
                for col in df_out.columns:
                    if df_out[col].dtypes == object or df_out[col].dtypes == np.int64:
                        filter_key_list.append(col)
                    if df_out[col].dtypes == np.int64 or df_out[col].dtypes == float:
                        src_col_list.append(col)

                df_out.reset_index(drop=True, inplace=True)
                df_out.index = df_out.index + 1
                columns = [str(column) for column in df_out.columns]

                data = df_out.to_dict(orient='index')

                rtn = {'result': True,
                       'data':
                           {'disp_order': columns,
                            'src_col_list': src_col_list,
                            'filter_key_list': filter_key_list,
                            'row': data
                            },
                       **options
                       }

                return make_json_response(**rtn)

        except Exception as e:
            logger.debug(str(e))
            return make_json_response(status=400, msg=str(e))


@PREVIEW.route('/filter')
class PreviewFilter(Resource):
    parser = PREVIEW.parser()
    parser.add_argument('data', type=dict, location='json', required=True, help='Sample Converted Data')
    parser.add_argument('filter', type=dict, location='json', required=True, help='filter info')

    @PREVIEW.expect(parser)
    @PREVIEW.response(200, 'Success')
    @PREVIEW.response(400, 'Bad Request')
    def post(self):
        """
        Get Filtered Preview Data
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        try:
            lc_instance = lc.convert.LogConvert()
            config = get_dbinfo()
            lc_instance.set_db_config(**config)
            config['schema'] = 'convert'
            lc_instance.set_convert_db(**config)

            data = args['data']
            filter = args['filter']['items']

            data_df = pd.DataFrame([], columns=data['disp_order'])
            for i in range(1, len(data['row']) + 1):
                data_df = data_df.append(data['row'][str(i)], ignore_index=True)

            filtered_df = lc_instance.create_filter_preview(data_df, filter)

            filtered_df.reset_index(drop=True, inplace=True)
            filtered_df.index = filtered_df.index + 1

            data = {'disp_order': filtered_df.columns.values.tolist(),
                    'row': filtered_df.to_dict(orient='index')}
            rtn = {'result': True, 'data': data}
            return make_json_response(**rtn)
        except Exception as e:
            logger.debug(str(e))
            return make_json_response(status=400, msg=str(e))


@PREVIEW.route('/analysis')
class PreviewAnalysis(Resource):
    parser = PREVIEW.parser()

    @PREVIEW.expect(parser)
    @PREVIEW.response(200, 'Success')
    @PREVIEW.response(400, 'Bad Request')
    def post(self):
        """
        Get Analysis Result Preview
        """
        with open(os.path.join('test/validation_json', 'dummy_analysis_preview.json'), 'r') as f:
            json_data = json.load(f)

        return make_json_response(**json_data)

# @PREVIEW.route('/analysis')
# class PreviewAnalysis(Resource):
#     parser = PREVIEW.parser()
#     parser.add_argument('data', type=dict, location='json', required=True, help='Sample Converted Data')
#     parser.add_argument('analysis', type=dict, location='json', required=True, help='Analysis info')
#
#     @PREVIEW.expect(parser)
#     @PREVIEW.response(200, 'Success')
#     @PREVIEW.response(400, 'Bad Request')
#     def post(self):
#         """
#         Get Analysis Result Preview
#         """
#         logger.info(str(request))
#
#         args = self.parser.parse_args()
#
#         try:
#             data = args['data']
#             analysis_args = args['analysis']
#
#             data_df = pd.DataFrame([], columns=data['disp_order'])
#
#             if data['row'] is not None:
#                 for i in range(1, len(data['row']) + 1):
#                     data_df = data_df.append(data['row'][str(i)], ignore_index=True)
#
#             analysis = AnalysisService()
#             resp_form = analysis.get_analysis_preview(data_df, **analysis_args)
#             if not resp_form.res:
#                 return make_json_response(status=400, msg=resp_form.msg)
#
#             return make_json_response(**resp_form.data)
#         except Exception as e:
#             logger.debug(str(e))
#             return make_json_response(status=400, msg=str(e))