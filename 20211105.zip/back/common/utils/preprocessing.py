import pandas.tseries.offsets as t_offsets
import datetime


def creanup_log_list_by_job(log_df):
    """
    Job単位に仕分けたログファイルから不要なデータを取り除く

    - 同一PlateのStep情報に重複がある場合、後に登場したものを残し、それ以外を削除
    - 先頭PlateのStep情報がそのJobのステップ数に満たなければ捨てる

    :param dataframe log_df: 操作対象(直接書き換えます)
    :return:
    """
    if len(log_df) == 0:
        return

    drop_list = []
    last_glass_id = ''
    got_shot_no = []
    for index in reversed(range(log_df.shape[0])):
        glass_id = log_df.iloc[index]['glass_id']
        shot_no = log_df.iloc[index]['step_no']
        if last_glass_id != glass_id:
            got_shot_no.clear()
            last_glass_id = glass_id
        if shot_no in got_shot_no:
            # 重複を登録
            drop_list.append(index)
        else:
            got_shot_no.append(shot_no)

    if len(drop_list) != 0:
        # 行を削除
        log_df.drop(drop_list, errors='ignore', inplace=True)
        log_df.reset_index(drop=True, inplace=True)


def creanup_log_list_by_term(log_df, valid_interval_minutes):
    """
    時間順に並ぶログから不要なデータを取り除く

    :param pd.DataFrame log_df: 時間順に並んだログデータ
    :param valid_interval_minutes:
    :return:
    """
    if valid_interval_minutes is None:
        return log_df

    valid_interval_minutes = int(valid_interval_minutes)

    # やることは無いのでそのまま返す
    if valid_interval_minutes <= 0:
        return log_df

    # 次ログから valid_interval_minutes 以上離れたデータだけ抽出する
    interval_minutes = t_offsets.DateOffset(minutes=valid_interval_minutes)
    log_df = log_df[(log_df['log_time'] + interval_minutes) <= log_df['log_time'].shift(-1)].reset_index(drop=True)
    return log_df


def get_divided_list(all_df, one_period, start_period_datetime, last_log_datetime, list_group):
    one_period_unit = one_period[-1]
    one_period_val = int(one_period[0:-1])

    list_by_period = []
    period_len = t_offsets.DateOffset(months=one_period_val if one_period_unit == 'm' else 0,
                                      days=one_period_val if one_period_unit == 'd' else 0,
                                      hours=one_period_val if one_period_unit == 'h' else 0)
    period_st = start_period_datetime
    period_ed = period_st + period_len
    while period_st <= last_log_datetime:
        cur_period_dict = {}
        cur_df = all_df[(period_st <= all_df['log_time']) & (all_df['log_time'] < period_ed)]
        if len(cur_df) > 0:
            cur_period_dict['start'] = period_st
            cur_period_dict['end'] = period_ed - t_offsets.DateOffset(seconds=1)

            if list_group == 'job':
                cur_period_job_list = []
                for name, group_df in cur_df.groupby(['device', 'process']):
                    job_name = name[0] + '/' + name[1]
                    cur_period_job_list.append(job_name)

                cur_period_dict['job_list'] = cur_period_job_list

            list_by_period.append(cur_period_dict)

        period_st = period_ed
        period_ed = period_st + period_len

    return list_by_period


def divide_by_stats_period(log_df, start, stats_period):
    if stats_period is None:
        return log_df

    stats_period_unit = stats_period[-1].lower()
    stats_period_val = int(stats_period[0:-1])

    start = datetime.datetime.strptime(start, '%Y-%m-%d %H:%M:%S')
    log_df['period'] = start

    if stats_period_val <= 0:
        return log_df

    if stats_period_unit not in ['m', 'd', 'h']:
        return log_df

    interval_period = t_offsets.DateOffset(months=stats_period_val if stats_period_unit == 'm' else 0,
                                      days=stats_period_val if stats_period_unit == 'd' else 0,
                                      hours=stats_period_val if stats_period_unit == 'h' else 0)

    # 最終データのタイムスタンプ
    last_log_time = log_df.iloc[log_df.shape[0] - 1]['log_time']

    # 順繰りに仕分けして行く
    st = start
    ed = st + interval_period
    while st <= last_log_time:
        log_df.loc[
            (st <= log_df.log_time) &
            (log_df.log_time < ed),
            'period'] = st
        st = ed
        ed = st + interval_period

    return log_df
