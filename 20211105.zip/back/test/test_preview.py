import pytest
import json
import os
import shutil

from flaskapp.mpa_analysis_tool import create_app
from config.unit_test_config import *
from dao import get_db_config

URL = 'http://localhost:5000'


@pytest.fixture
def api():
    config_file = '../config/unit_test_config.py'
    app = create_app(config_file)
    app.config['TESTING'] = True
    api = app.test_client()

    return api

def test_preview_step2_local(api):
    files = []
    filepath = 'test/sample_log'
    filename = '20210901_TEST.txt'
    shutil.copy(os.path.join(filepath, filename), filename)

    files.append(open(filename, 'rb'))

    script_file_path = 'resource/script'
    script_file_name = 'preprocess.py'
    shutil.copy(os.path.join(script_file_path, script_file_name), script_file_name)
    script_file = [open(script_file_name, 'rb')]

    params = {
        'source': 'local',
        'use_script': True
    }

    # response = api.post(URL+'/api/converter/file', files=files)
    response = api.post(URL + '/api/preview/samplelog', data={'files': files, 'script_file': script_file}, query_string=params)
    resp_body = json.loads(response.data)
    print(resp_body)

    assert response.status_code == 200


def test_preview_step2_remote(api):
    files = []
    filepath = 'test/sample_log'
    filename = '20210901_TEST.txt'
    shutil.copy(os.path.join(filepath, filename), filename)

    files.append(open(filename, 'rb'))

    script_file_path = 'resource/script'
    script_file_name = 'preprocess.py'
    shutil.copy(os.path.join(script_file_path, script_file_name), script_file_name)
    script_file = [open(script_file_name, 'rb')]

    params = {
        'source': 'remote',
        'use_script': True,
        'equipment_name': 'BSOT_Fab1_MPA_2',
        'table_name': 'adc_measurement',
        'db_id': 19,
        'start': '2019-05-21 12:25:35',
        'end': '2019-05-22 12:25:35'
    }

    # response = api.post(URL+'/api/converter/file', files=files)
    response = api.post(URL + '/api/preview/samplelog', data={'files': files, 'script_file': script_file}, query_string=params)
    resp_body = json.loads(response.data)
    print(resp_body)

    assert response.status_code == 200


def test_preview_step2_sql(api):
    files = []
    filepath = 'test/sample_log'
    filename = '20210901_TEST.txt'
    shutil.copy(os.path.join(filepath, filename), filename)

    files.append(open(filename, 'rb'))

    script_file_path = 'resource/script'
    script_file_name = 'preprocess.py'
    shutil.copy(os.path.join(script_file_path, script_file_name), script_file_name)
    script_file = [open(script_file_name, 'rb')]

    params = {
        'source': 'sql',
        'use_script': True,
        'db_id': 19,
        'sql': "select * from adc_measurement where log_time >= '2019-05-21 12:25:35' and log_time <= '2019-05-22 12:25:35'"
               " and equipment_name='BSOT_Fab1_MPA_2'"
    }

    # response = api.post(URL+'/api/converter/file', files=files)
    response = api.post(URL + '/api/preview/samplelog', data={'files': files, 'script_file': script_file}, query_string=params)
    resp_body = json.loads(response.data)
    print(resp_body)

    assert response.status_code == 200