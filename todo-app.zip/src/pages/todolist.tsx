import { TodoListHeader, TodoListItems } from '@/components/todolist'
import { Toaster } from '@/components/shadcn/sonner.tsx'


const TodoListPage = () => {
  return (
    <main className="flex flex-col w-full min-h-screen">
      <TodoListHeader />
      <TodoListItems />
      <Toaster position="top-center" style={{ fontFamily: 'Pretendard' }} />
    </main>
  )
}

export default TodoListPage