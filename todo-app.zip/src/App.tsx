import { DialogProvider } from '@/lib/dialog/dialog-provider'
import { GlobalDialog } from '@/lib/dialog/global-dialog'
import { ToDoListHeader } from '@/components/todolist'


import './App.css'

function App() {

  return (
    <DialogProvider>
      <main className="w-full space-y-8">
        <ToDoListHeader />
      </main>
      <GlobalDialog />
    </DialogProvider>
  )
}

export default App
