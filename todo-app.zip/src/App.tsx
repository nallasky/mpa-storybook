import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Toaster } from '@/components/shadcn/sonner'

import { ToDoListHeader } from '@/components/todolist'
import ToDoListItems from '@/components/todolist/todolist-items'
import { TodoListProvider } from '@/lib/context/todolist-context-provider'

import './App.css'

const queryClient = new QueryClient()

function App() {

  return (
    <QueryClientProvider client={queryClient}>
      <TodoListProvider>
        <main className="flex flex-col w-full min-h-screen">
          <ToDoListHeader />
          <ToDoListItems />
          <Toaster position="top-center" style={{ fontFamily: 'Pretendard' }} />
        </main>
      </TodoListProvider>
    </QueryClientProvider>
  )
}

export default App
