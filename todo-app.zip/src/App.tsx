import { QueryClient, QueryClientProvider } from '@tanstack/react-query'

import TodoListPage from '@/pages/todolist'
import { TodoListProvider } from '@/lib/context/todolist-context-provider'

import './App.css'

const queryClient = new QueryClient()

function App() {

  return (
    <QueryClientProvider client={queryClient}>
      <TodoListProvider>
        <TodoListPage />
      </TodoListProvider>
    </QueryClientProvider>
  )
}

export default App
