import { ToDoListHeader } from '@/components/todolist'

import './App.css'

function App() {

  return (
    <main className="w-full space-y-8">
      <ToDoListHeader />
    </main>
  )
}

export default App
