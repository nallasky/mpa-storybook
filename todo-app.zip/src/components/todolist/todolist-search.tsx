import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/shadcn/button"
import { Input } from "@/components/shadcn/input"
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/shadcn/form"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/shadcn/popover"
import { Calendar } from "@/components/shadcn/calendar"
import { CalendarIcon } from "lucide-react"
import { cn } from "@/lib/shadcn/utils"
import { format } from "date-fns"
import { Search } from 'lucide-react'

const formSchema = z.object({
  title: z.string(),
  deadline: z.number().nullable()
})

export function ToDoListSearch() {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: '',
      deadline: null,
    }
  })

  const onSubmit: (data: z.infer<typeof formSchema>) => void = (data) => {
    console.log(data)
  }

  return (
    <Form {...form}>
      <h3 className="text-xl font-bold text-left mb-4">검색</h3>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <div className="flex flex-col sm:flex-row gap-4">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem className="flex-1 min-w-0 w-full">
                <FormLabel>할 일</FormLabel>
                <FormControl>
                  <Input
                    className="text-sm md:text-sm"
                    placeholder="할 일을 입력 해 주세요."
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="deadline"
            render={({ field }) => (
              <FormItem className="flex-1 min-w-0 w-full">
                <FormLabel>마감일</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !field.value && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4 opacity-50" />
                      {field.value ? format(new Date(field.value), "yyyy-MM-dd") : <span>날짜를 입력 해 주세요.</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={field.value ? new Date(field.value) : undefined}
                      onSelect={(date) => {
                        field.onChange(date ? date.getTime() : undefined)
                      }}
                      disabled={(date) => {
                        const today = new Date()
                        const selectedDate = new Date(date);

                        return selectedDate.setHours(0, 0, 0, 0) < today.setHours(0, 0, 0, 0);
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <Button type="submit" className="w-full mt-4 cursor-pointer">
          <Search /> 검색 시작
        </Button>
      </form>
    </Form>
  )
}