import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'

import { Button } from '@/components/shadcn/button'
import { toast } from 'sonner'

import TodoListCommonFormDialog from '@/components/todolist/todolist-common-form-dialog'
import { TodoListCommonForm } from '@/types/todolist'
import { usePostToDo } from '@/lib/query/query'

const TodoListHeader = () => {
  const queryClient = useQueryClient()

  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const { mutate } = usePostToDo({
    onSuccess: () => {
      queryClient.refetchQueries({ queryKey: ['get-todos'] })
      toast('스케쥴 등록에 성공했습니다.')
    },
    onError: (e) => {
      console.log(e)
      toast('스케쥴 등록에 실패했습니다.')
    },
    onSettled: () => setIsDialogOpen(false)
  })

  const onSubmit = async ({ text, deadline }: TodoListCommonForm) => {
    mutate({ text, deadline, done: false })
  }

  return (
    <header className="w-full sticky top-0 bg-white z-50 flex items-center justify-between pt-8 pb-8 mb-0">
      <h1 className="text-3xl font-bold">To-Do-App</h1>
      <Button className="cursor-pointer" onClick={() => setIsDialogOpen(true)}>
        스케쥴 등록
      </Button>
      <TodoListCommonFormDialog
        title="스케쥴 등록"
        open={isDialogOpen}
        onOpenChange={() => setIsDialogOpen(false)}
        onSubmit={onSubmit}
        buttonText="등록"
      />
    </header>
  )
}

export default TodoListHeader