import { Button } from '@/components/shadcn/button'
import { Separator } from '@/components/shadcn/separator'
import { Card, CardContent } from '@/components/shadcn/card'
import { Checkbox } from '@/components/shadcn/checkbox'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/shadcn/tooltip'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/shadcn/dialog'
import { Plus, Check, NotebookPen, Trash2 } from 'lucide-react'

import type { TGlobalDialogProps } from '@/lib/dialog/dialog-context'
import { ToDoListSearch } from './todolist-search'
import { useDialog } from '@/lib/dialog/use-dialog'

export default function ToDoListHeader() {
  const { openDialog } = useDialog()

  const onClickAddButton = () => {
    openDialog('test-dialog', {
      Component: TestDialog
    })
  }

  return (
    <>
      <header className="w-full flex items-center justify-between">
        <h1 className="text-3xl font-bold">To-Do-App</h1>
        <Button className="cursor-pointer" onClick={onClickAddButton}>
          <Plus /> 할 일 추가
        </Button>
      </header>
      <Separator />
      <section>
        <ToDoListSearch />
      </section>
      <Separator />
      <section>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold text-left">등록된 할 일 리스트</h3>
          <span className="text-sm font-bold">2개 중 0개 선택</span>
        </div>
        <ul className="border-t border-t-gray-200">
          <li>
            <Card className="shadow-none rounded-none border-0 border-b border-b-gray-200">
              <CardContent className="h-20 flex items-center gap-x-6">
                <div className="pl-2 pr-2">
                  <Checkbox className="cursor-pointer" onCheckedChange={(value) => console.log(value)} />
                </div>
                <div className="grow shrink text-left">
                  <p>상태</p>
                  <p>기간</p>
                  <p>할일</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-x-4 gap-y-2">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="outline" className="rounded-full w-6 h-6 cursor-pointer">
                          <Check className="scale-75" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>완료</p>
                      </TooltipContent>
                    </Tooltip>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="outline" className="rounded-full w-6 h-6 cursor-pointer">
                          <NotebookPen className="scale-75" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>수정</p>
                      </TooltipContent>
                    </Tooltip>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="outline" className="rounded-full w-6 h-6 cursor-pointer">
                          <Trash2 className="scale-75" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>삭제</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </CardContent>
            </Card>
          </li>
          <li>
            <Card className="shadow-none rounded-none border-0 border-b border-b-gray-200">
              <CardContent className="h-20 flex items-center gap-x-6">
                <div className="pl-2 pr-2">
                  <Checkbox className="cursor-pointer" />
                </div>
                <div className="grow shrink text-left">
                  <p>상태</p>
                  <p>기간</p>
                  <p>할일</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-x-4 gap-y-1">
                  <Button variant="outline" className="rounded-full w-6 h-6 cursor-pointer">
                    <Check className="scale-75" />
                  </Button>
                  <Button variant="outline" className="rounded-full w-6 h-6 cursor-pointer">
                    <NotebookPen className="scale-75" />
                  </Button>
                  <Button variant="outline" className="rounded-full w-6 h-6 cursor-pointer">
                    <Trash2 className="scale-75" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </li>
        </ul>
      </section>
    </>
  )
}

function TestDialog({ onClose, open = true }: TGlobalDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Are you absolutely sure?</DialogTitle>
          <DialogDescription>
            This action cannot be undone. This will permanently delete your account
            and remove your data from our servers.
          </DialogDescription>
        </DialogHeader>
      </DialogContent>
    </Dialog>
  )
}