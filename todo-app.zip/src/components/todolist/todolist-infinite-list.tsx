import {
  useEffect,
  useState,
  useRef,
  useCallback,
  useMemo,
} from "react";

import TodoListItemCard from "./todolist-item-card";
import { ToDo } from "@/types/api";

type TodoListInfiniteListProps = {
  items: ToDo[],
  itemHeight: number,
  onReachEnd: () => void,
  isLoadEnd: boolean,
  buffer?: number
}

const TodoListInfiniteList = ({
  items,
  itemHeight,
  onReachEnd,
  isLoadEnd,
  buffer = 5
}: TodoListInfiniteListProps) => {
  const [scrollY, setScrollY] = useState(window.scrollY)
  const [visibleCount, setVisibleCount] = useState(() =>
    Math.ceil(window.innerHeight / itemHeight)
  )

  const sentinelRef = useRef<HTMLLIElement | null>(null);
  const tickingRef = useRef(false);

  const totalHeight = items.length * itemHeight;

  const startIndex = Math.max(0, Math.floor(scrollY / itemHeight) - buffer);
  const endIndex = Math.min(
    items.length,
    startIndex + visibleCount + buffer * 2
  );

  const visibleItems = useMemo(() => {
    return items.slice(startIndex, endIndex);
  }, [items, startIndex, endIndex]);

  const handleIntersect = useCallback(
    (entries: IntersectionObserverEntry[]) => {
      const entry = entries[0];
      if (entry.isIntersecting && !isLoadEnd) {
        onReachEnd()
      }
    },
    [onReachEnd, isLoadEnd]
  );

  useEffect(() => {
    const handleScroll = () => {
      if (!tickingRef.current) {
        requestAnimationFrame(() => {
          setScrollY(window.scrollY);
          tickingRef.current = false;
        });
        tickingRef.current = true;
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      const count = Math.ceil(window.innerHeight / itemHeight);
      setVisibleCount(count);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [itemHeight]);

  useEffect(() => {
    if (!sentinelRef.current) return;
    const observer = new IntersectionObserver(handleIntersect, {
      root: null,
      rootMargin: "197px",
    });
    observer.observe(sentinelRef.current);
    return () => observer.disconnect();
  }, [handleIntersect]);

  return (
    <ul style={{ position: "relative", minHeight: totalHeight }}>
      {visibleItems.map((item, i) => {
        const index = startIndex + i;
        const top = index * itemHeight;

        return (
          <li
            key={item.id}
            style={{
              position: "absolute",
              top,
              left: 0,
              right: 0,
              height: itemHeight,
            }}
          >
            <TodoListItemCard data={item} />
          </li>
        );
      })}
      <li
        ref={sentinelRef}
        style={{
          position: "absolute",
          top: totalHeight - 1,
          height: "1px",
          width: "100%",
        }}
      />
    </ul>
  );
}

export default TodoListInfiniteList