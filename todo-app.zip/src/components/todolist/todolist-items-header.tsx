import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Toggle } from '@/components/shadcn/toggle'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/shadcn/select'
import { Button } from '@/components/shadcn/button'
import { toast } from 'sonner'

import { useTodoList } from '@/lib/hooks/use-todolist'
import { useDeleteToDo } from '@/lib/query/query'
import { ToDo } from '@/types/api'
import TodoListCommonFormDialog from './todolist-common-form-dialog'
import { TodoListCommonForm } from '@/types/todolist'

const TodoListItemsHeader = ({ items }: { items: ToDo[] }) => {
  const queryClient = useQueryClient()
  const { checkedTodos, todoSearchInfo, setCheckTodosAll, setTodoSearchInfo } = useTodoList()


  const [todoSortType, setTodoSortType] = useState('id')
  const [isSearchDialogOpen, setIsSearchDialogOpen] = useState(false)

  const { mutateAsync } = useDeleteToDo()

  const onSubmit = (data: Omit<TodoListCommonForm, 'id'>) => {
    const savedData = {
      text: data.text ?? '',
      deadline: data.deadline
    }

    setTodoSearchInfo(savedData)
    localStorage.setItem('search', JSON.stringify(savedData))
    setIsSearchDialogOpen(false)
  }

  const handleDeleteTodoAll = async () => {
    const successedResults: ToDo['id'][] = []
    const failedResults: ToDo['id'][] = []

    const deletePromises = checkedTodos.map((id) =>
      mutateAsync(id).then(
        () => successedResults.push(id),
        () => failedResults.push(id)
      )
    )

    await Promise.allSettled(deletePromises)

    toast(`스케쥴 삭제 결과: 성공 ${successedResults.length}개, 실패: ${failedResults.length}`)

    if (successedResults.length > 0) {
      queryClient.refetchQueries({ queryKey: ['get-todos'] })
      setCheckTodosAll(checkedTodos.filter((id) => !successedResults.find((fetchId) => fetchId === id)))
    }
  }

  const handleAllTodeSelect = (isChecked: boolean) => {
    const newTodosCheckedList = isChecked ? items.map(({ id }) => id) : []
    setCheckTodosAll(newTodosCheckedList)
  }

  const selectedTodosCount = checkedTodos.length
  const registeredTodosCount = items.length
  const isEmptyTodos = items.length === 0

  return (
    <div className="sticky top-[100px] mb-0 bg-white border-b pb-4 z-50">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-bold text-left">등록된 스케쥴</h3>
        <span className="text-sm font-bold">{`${registeredTodosCount}개 중 ${selectedTodosCount}개 선택`}</span>
      </div>
      <div className="flex justify-between items-center mt-4">
        <div className="flex gap-x-2">
          <Toggle
            variant="outline"
            className="cursor-pointer"
            pressed={!isEmptyTodos && registeredTodosCount === selectedTodosCount}
            disabled={isEmptyTodos}
            onPressedChange={handleAllTodeSelect}
          >
            전체 선택
          </Toggle>
          <Button
            variant="outline"
            className="cursor-pointer"
            disabled={checkedTodos.length === 0}
            onClick={handleDeleteTodoAll}
          >
            삭제
          </Button>
          <Button
            variant="outline"
            className="cursor-pointer"
            onClick={() => setIsSearchDialogOpen(true)}
          >
            스케쥴 검색
          </Button>
        </div>
        <div>
          <Select
            value={todoSortType}
            disabled={isEmptyTodos}
            onValueChange={(value) => setTodoSortType(value)}
          >
            <SelectTrigger className="w-[110px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="deadline">마감일 순</SelectItem>
              <SelectItem value="id">등록 순</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <TodoListCommonFormDialog
        open={isSearchDialogOpen}
        title="스케쥴 검색"
        buttonText="검색 시작"
        onSubmit={onSubmit}
        onOpenChange={() => setIsSearchDialogOpen(false)}
        searchValues={todoSearchInfo}
        validate={false}
        type="search"
      />
    </div>
  )
}

export default TodoListItemsHeader