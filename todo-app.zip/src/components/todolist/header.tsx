import { Button } from '@/components/shadcn/button'
import { Bell } from 'lucide-react'

import { TodoForm } from '@/components/todolist/todo-form'

export default function ToDoListHeader() {
  return (
    <>
      <header className="w-full flex items-center justify-between border-b border-gray-200 pb-4">
        <h1 className="text-3xl font-bold">To-Do-List</h1>
        <div className="relative flex flex-col items-center w-16">
          <Button variant="ghost" size="icon" className="rounded-full w-12 h-12 cursor-pointer">
            <Bell className="scale-200" />
          </Button>
          <span
            className="absolute top-1 right-3 -mt-1 -mr-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-xs text-white"
            role="status"
            aria-label="마감 임박 할 일 갯수"
          >
            3
          </span>
          <p className="text-sm mt-1">마감 임박</p>
        </div>
      </header>
      <section>
        <TodoForm onSubmit={() => console.log('!!!')} />
      </section>
    </>
  )
}