import { useEffect, useState, useMemo, useCallback } from 'react'

import { toast } from 'sonner'
import { useTodoList } from '@/lib/hooks/use-todolist'
import { usePutToDo, useGetTodos, useDeleteToDo } from '@/lib/query/query'
import { TodoListCommonForm } from '@/types/todolist'
import TodoListInfiniteList from './todolist-infinite-list'
import TodoListCommonFormDialog from './todolist-common-form-dialog'
import TodoListItemsHeader from './todolist-items-header'
import { ToDo } from '@/types/api'
import { TODO_REQUEST_INITIAL_STATE} from '@/lib/context/todolist-context'
import { isCloseToDeadline } from '@/lib/util/util'

const findExpiringTodos = (data: ToDo[]) => {
  return data.find(({ deadline, done }) => {
    if (done) {
      return false
    }
    return isCloseToDeadline(deadline)
  })
}

const filteringTodos = (searchInfo: Omit<TodoListCommonForm, 'done'> | undefined, todos: ToDo[]) => {
  if (searchInfo === undefined || todos.length === 0) {
    return todos
  }

  return todos.filter(({ text, deadline }) => {
    if (searchInfo.text === '' && !searchInfo.deadline) {
      return true
    }

    if (searchInfo.text !== '' && !text.includes(searchInfo.text)) {
      return false
    }

    return !(searchInfo.deadline && searchInfo.deadline !== deadline);
  })
}

const TodoListItems = () => {
  const { todoRequestInfo, todoSearchInfo, todoSortType, setTodoSearchInfo, setTodoRequestInfo } = useTodoList()

  const { id, type } = todoRequestInfo

  const [isEditDialogOpen, setIsDialogOpen] = useState(false)
  const [sliceEndIndex, setSliceEndIndex] = useState(10)

  const { data: registeredTodos = [], refetch: refetchTodos } = useGetTodos()
  const { mutate: mutatePutToDo } = usePutToDo({
    onSuccess: () => {
      const toastMessage = type === 'edit' ? '스케쥴이 수정되었습니다.' : '스케쥴 완료 상태가 변경되었습니다.'
      toast(toastMessage)
      refetchTodos()
    },
    onError: (e) => {
      console.log(e)
      const toastMessage = type === 'edit' ? '스케쥴 수정에 실패하였습니다' : '스케쥴 완료 상태 변경에 실패하였습니다.'
      toast(toastMessage)
    },
    onSettled: () => {
      if (type === 'edit') {
        setIsDialogOpen(false)
      }
      setTodoRequestInfo(TODO_REQUEST_INITIAL_STATE)
    }
  })
  const { mutate: mutateDeleteTodo } = useDeleteToDo({
    onSuccess: () => {
      toast('스케쥴이 삭제되었습니다.')
      refetchTodos()
    },
    onError: (e) => {
      console.log(e)
      toast('스케쥴 삭제에 실패하였습니다.')
    },
    onSettled: () => {
      setTodoRequestInfo(TODO_REQUEST_INITIAL_STATE)
    }
  })

  const filteredTodos = useMemo(() => {
    return filteringTodos(todoSearchInfo, registeredTodos)
  }, [registeredTodos, todoSearchInfo])

  const slicedTodoItems = useMemo(() => {
    const beforeSortTodos = filteredTodos.slice(0, sliceEndIndex)
    return beforeSortTodos.sort((a, b) => {
      if (todoSortType === 'deadline') {
        return a[todoSortType] - b[todoSortType]
      }
      return b[todoSortType] - a[todoSortType]
    })
  }, [filteredTodos, sliceEndIndex, todoSortType])

  const loadMoreRegisteredTodos = () => {
    setSliceEndIndex((prev) => prev + 5)
  }

  const closeDialog = () => {
    setIsDialogOpen(false)
    setTodoRequestInfo(TODO_REQUEST_INITIAL_STATE)
  }

  const onSubmitEdit = ({ text, deadline, done }: TodoListCommonForm) => {
    mutatePutToDo({
      id: id as number,
      done: done === '1',
      text,
      deadline
    })
  }

  const handleTodoComplete = useCallback((changeId: ToDo['id'] | undefined) => {
    if (changeId === undefined) {
      return
    }

    const getTodoInfo = registeredTodos.find(({ id }) => id === changeId)

    mutatePutToDo({
      id: changeId,
      done: !getTodoInfo!.done,
      text: getTodoInfo!.text,
      deadline: getTodoInfo!.deadline
    })
  }, [registeredTodos, mutatePutToDo])

  const handleTodoDelete = useCallback((deleteId: ToDo['id'] | undefined) => {
    if (deleteId === undefined) {
      return
    }
    mutateDeleteTodo(deleteId)
  }, [mutateDeleteTodo])

  useEffect(() => {
    const savedSearchValue = localStorage.getItem('search')

    if (savedSearchValue !== null) {
      setTodoSearchInfo(JSON.parse(savedSearchValue))
    }
  }, [])

  useEffect(() => {
    if (type === null) {
      return
    }

    switch(type) {
      case 'edit':
        setIsDialogOpen(true)
        break
      case 'complete':
        handleTodoComplete(id)
        break
      case 'delete':
        handleTodoDelete(id)
        break
      default:
        console.error('unknown request type')
    }
  }, [type, id, handleTodoDelete, handleTodoComplete])

  useEffect(() => {
    if (findExpiringTodos(registeredTodos)) {
      setTimeout(() => {
        toast("일정 마감에 임박한 스케쥴이 있습니다. 검색을 해제하고 마감일 순으로 정렬해 주세요.")
      }, 1000)
    }
  }, [registeredTodos])

  const isLoadEnd = (slicedTodoItems.length === 0 || filteredTodos.length === 0) || slicedTodoItems.length === filteredTodos.length

  return (
    <section className="relative">
      <TodoListItemsHeader items={filteredTodos} />
      <TodoListInfiniteList
        items={slicedTodoItems}
        itemHeight={129}
        onReachEnd={loadMoreRegisteredTodos}
        isLoadEnd={isLoadEnd}
      />
      <TodoListCommonFormDialog
        open={isEditDialogOpen}
        title="스케쥴 수정"
        buttonText="수정 완료"
        onSubmit={onSubmitEdit}
        onOpenChange={closeDialog}
        editingId={type === 'edit' ? id : undefined}
        type="edit"
      />
    </section>
  )
}

export default TodoListItems