import { useEffect, useState, useMemo, useCallback } from 'react'

import { toast } from 'sonner'
import { useTodoList } from '@/lib/hooks/use-todolist'
import { usePutToDo, useGetTodos, useDeleteToDo } from '@/lib/query/query'
import { TodoListCommonForm } from '@/types/todolist'
import TodoListInfiniteList from './todolist-infinite-list'
import TodoListCommonFormDialog from './todolist-common-form-dialog'
import TodoListItemsHeader from './todolist-items-header'
import { ToDo } from '@/types/api'

const filteringTodos = (searchInfo: Omit<TodoListCommonForm, 'done'> | undefined, todos: ToDo[]) => {
  if (searchInfo === undefined || todos.length === 0) {
    return todos
  }

  console.log('searchInfo', searchInfo)

  return todos.filter(({ text, deadline }) => {
    console.log(deadline)
    if (searchInfo.text === '' && !searchInfo.deadline) {
      console.log('1')
      return true
    }

    if (searchInfo.text !== '' && !text.includes(searchInfo.text)) {
      console.log(text)
      console.log('2')
      return false
    }

    if (searchInfo.deadline && searchInfo.deadline !== deadline) {
      console.log('3')
      return false
    }

    return true
  })
}

const ToDoListItems = () => {
  const {
    todoIdToEdit,
    todoIdToDelete,
    todoIdToComplete,
    todoSearchInfo,
    setTodoIdToEdit,
    setTodoIdToDelete,
    setTodoIdToComplete,
    setTodoSearchInfo
  } = useTodoList()

  const [isEditDialogOpen, setIsDialogOpen] = useState(false)
  const [sliceEndIndex, setSliceEndIndex] = useState(10)

  const { data: registeredTodos = [], refetch: refetchTodos } = useGetTodos()
  const { mutate: mutatePutToDo } = usePutToDo({
    onSuccess: () => {
      const toastMessage = todoIdToEdit !== undefined ? '스케쥴이 수정되었습니다.' : '스케쥴 완료 상태가 변경되었습니다.'
      toast(toastMessage)
      refetchTodos()
    },
    onError: (e) => {
      console.log(e)
      const toastMessage = todoIdToEdit !== undefined ? '스케쥴 수정에 실패하였습니다' : '스케쥴 완료 상태 변경에 실패하였습니다.'
      toast(toastMessage)
    },
    onSettled: () => {
      if (todoIdToEdit !== undefined) {
        closeDialog()
        return
      }
      setTodoIdToComplete(undefined)
    }
  })
  const { mutate: mutateDeleteTodo } = useDeleteToDo({
    onSuccess: () => {
      toast('스케쥴이 삭제되었습니다.')
      refetchTodos()
    },
    onError: (e) => {
      console.log(e)
      toast('스케쥴 삭제에 실패하였습니다.')
    },
    onSettled: () => {
      setTodoIdToDelete(undefined)
    }
  })

  console.log(todoSearchInfo)

  const slicedTodoItems = useMemo(() => {
    const beforeFilteringTodos = registeredTodos.length < sliceEndIndex
      ? registeredTodos
      : registeredTodos.slice(0, sliceEndIndex)

    return filteringTodos(todoSearchInfo, beforeFilteringTodos)
  }, [registeredTodos, sliceEndIndex, todoSearchInfo])

  const fullFilteringItems = useMemo(() => {
    return filteringTodos(todoSearchInfo, registeredTodos)
  }, [registeredTodos, todoSearchInfo])

  const loadMoreRegisteredTodos = () => {
    setSliceEndIndex((prev) => prev + 5)
  }

  const closeDialog = () => {
    setIsDialogOpen(false)
    setTodoIdToEdit(undefined)
  }

  const onSubmitEdit = ({ text, deadline, done }: TodoListCommonForm) => {
    mutatePutToDo({
      id: todoIdToEdit as number,
      done: done === '1',
      text,
      deadline
    })
  }

  const handleTodoComplete = useCallback((changeId: ToDo['id'] | undefined) => {
    if (changeId === undefined) {
      return
    }

    const getTodoInfo = registeredTodos.find(({ id }) => id === changeId)

    mutatePutToDo({
      id: changeId,
      done: !getTodoInfo!.done,
      text: getTodoInfo!.text,
      deadline: getTodoInfo!.deadline
    })
  }, [registeredTodos, mutatePutToDo])

  const handleTodoDelete = useCallback((deleteId: ToDo['id'] | undefined) => {
    if (deleteId === undefined) {
      return
    }
    mutateDeleteTodo(deleteId)
  }, [mutateDeleteTodo])

  useEffect(() => {
    if (!todoIdToEdit) {
      return
    }
    setIsDialogOpen(true)
  }, [todoIdToEdit])

  useEffect(() => {
    handleTodoComplete(todoIdToComplete)
  }, [todoIdToComplete, handleTodoComplete])

  useEffect(() => {
    handleTodoDelete(todoIdToDelete)
  }, [todoIdToDelete, handleTodoDelete])

  useEffect(() => {
    const savedSearchValue = localStorage.getItem('search')

    if (savedSearchValue !== null) {
      setTodoSearchInfo(JSON.parse(savedSearchValue))
    }
  }, [])

  const isLoadEnd = (slicedTodoItems.length === 0 || fullFilteringItems.length === 0) || slicedTodoItems.length === fullFilteringItems.length

  return (
    <section className="relative">
      <TodoListItemsHeader items={fullFilteringItems} />
      <TodoListInfiniteList
        items={slicedTodoItems}
        itemHeight={129}
        onReachEnd={loadMoreRegisteredTodos}
        isLoadEnd={isLoadEnd}
      />
      <TodoListCommonFormDialog
        open={isEditDialogOpen}
        title="스케쥴 수정"
        buttonText="수정 완료"
        onSubmit={onSubmitEdit}
        onOpenChange={closeDialog}
        editingId={todoIdToEdit}
        type="edit"
      />
    </section>
  )
}

export default ToDoListItems