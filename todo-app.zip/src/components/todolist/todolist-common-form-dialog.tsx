import { useEffect } from "react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/shadcn/button"
import { Input } from "@/components/shadcn/input"
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/shadcn/form"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/shadcn/dialog"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/shadcn/popover"
import { RadioGroup, RadioGroupItem } from "@/components/shadcn/radio-group"
import { Calendar } from "@/components/shadcn/calendar"
import { CalendarIcon, X } from "lucide-react"
import { cn } from "@/lib/shadcn/utils"
import { format } from "date-fns"

import { useGetTodo } from "@/lib/query/query"
import { ToDo } from "@/types/api"
import { TodoListCommonForm } from "@/types/todolist"

const formSchema = z.object({
  text: z.string().min(1, "스케쥴 내용은 반드시 입력되어야 합니다."),
  deadline: z.number({ required_error: "완료일은 반드시 입력되어야 합니다." }),
  done: z.string()
})

type TodoListCommonFormProps = {
  open: boolean,
  title: string,
  buttonText: string,
  onOpenChange: () => void,
  onSubmit: (data: z.infer<typeof formSchema>) => void,
  validate?: boolean
  editingId?: ToDo['id'],
  searchValues?: Omit<TodoListCommonForm, 'done'>
  type?: string
}

const TodoListCommonFormDialog = ({
  open,
  title,
  buttonText,
  onOpenChange,
  onSubmit,
  validate = true,
  editingId = undefined,
  searchValues,
  type = 'add'
}: TodoListCommonFormProps) => {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: validate ? zodResolver(formSchema) : undefined,
    defaultValues: type === 'add' ? {
      text: '',
      done: '0',
      deadline: undefined
    } : undefined
  })

  const { data } = useGetTodo(editingId)

  const isDisableRadioGroup = editingId === undefined

  const onFormSubmit = (data: z.infer<typeof formSchema>) => {
    onSubmit(data)
    setTimeout(() => {
      form.reset()
    }, 300)
  }

  useEffect(() => {
    if (data && type === 'edit') {
      form.reset({
        text: data.text,
        deadline: data.deadline,
        done: data.done ? '1' : '0'
      }, {
        keepValues: false,
        keepDefaultValues: false
      })
    }
  }, [data, type, form])

  useEffect(() => {
    if (searchValues !== undefined && type === 'search') {
      form.reset(
        { ...searchValues },
        {
          keepValues: false,
          keepDefaultValues: false
        }
      )
    }
  }, [searchValues, form, type])

  return (
    <Dialog
      open={open}
      onOpenChange={onOpenChange}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription />
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onFormSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="text"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>스케쥴 내용</FormLabel>
                  <FormControl>
                    <Input placeholder="스케쥴 내용을 입력 해 주세요." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="deadline"
              render={({ field }) => (
                <FormItem className="flex flex-col relative">
                  <FormLabel>완료일</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4 opacity-50" />
                          {field.value ? format(new Date(field.value), "yyyy-MM-dd") : <span>완료일을 입력 해 주세요.</span>}
                          {field.value && (
                            <Button
                              type="button"
                              variant="ghost"
                              className="absolute right-2 top-[28px] text-muted-foreground w-6 h-6 z-1"
                              onClick={(e) => {
                                e.stopPropagation()
                                field.onChange(null)
                              }}
                            >
                              <X size={16} />
                            </Button>
                          )}
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={field.value ? new Date(field.value) : undefined}
                        onSelect={(date) => {
                          field.onChange(date ? date.getTime() : undefined)
                        }}
                        disabled={(date) => {
                          const today = new Date()
                          const selectedDate = new Date(date);
                          return selectedDate.setHours(0, 0, 0, 0) < today.setHours(0, 0, 0, 0);
                        }}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            {type !== 'search' && (
              <FormField
                control={form.control}
                name="done"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>스케쥴 진행 상태</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        value={field.value}
                        className="flex gap-x-6 mt-1"
                      >
                        <FormItem className="flex items-center">
                          <FormControl>
                            <RadioGroupItem value="0" disabled={isDisableRadioGroup} />
                          </FormControl>
                          <FormLabel className="font-normal">
                            진행 중
                          </FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center">
                          <FormControl>
                            <RadioGroupItem value="1" disabled={isDisableRadioGroup} />
                          </FormControl>
                          <FormLabel className="font-normal">
                            완료
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            <Button type="submit" className="w-full">{buttonText}</Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}

export default TodoListCommonFormDialog