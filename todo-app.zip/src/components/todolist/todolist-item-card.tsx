import { Card, CardContent } from "@/components/shadcn/card"
import { Checkbox } from "@/components/shadcn/checkbox"
import { Badge } from "@/components/shadcn/badge"
import { Button } from "@/components/shadcn/button"
import { Timer, NotebookPen } from "lucide-react"
import { format, differenceInDays } from "date-fns"
import { ko } from 'date-fns/locale'

import { useTodoList } from "@/lib/hooks/use-todolist"
import { ToDo } from "@/types/api"
import { TodoRequestInfo } from '@/types/todolist'

type SelectBadgeInfo = (deadline: ToDo['deadline'], done: ToDo['done']) => [string, string]

const selectBadgeInfo: SelectBadgeInfo = (deadline, done) => {
  if (done) {
    return ['bg-green-600', '완료']
  }

  const today = new Date().setHours(0, 0, 0, 0)
  const convertTodayTimestamp = new Date(today).getTime()
  const daysDifference = differenceInDays(deadline, convertTodayTimestamp)

  if (daysDifference > 3) {
    return ['bg-black', '진행 중']
  }

  if (daysDifference > 0) {
    return ['bg-red-600', `일정 마감 ${daysDifference}일 전`]
  }

  return ['bg-red-600', `일정 경과`]
}

const convertFormatDeadline = (deadline: ToDo['deadline']) => {
  return format(deadline, "yyyy년 M월 d일", { locale: ko })
}

type TodoListItemCardProps = {
  data: ToDo,
}

const TodoListItemCard = ({ data }: TodoListItemCardProps) => {
  const { checkedTodos, setCheckTodos, setTodoRequestInfo } = useTodoList()

  const [badgeColor, badgeText] = selectBadgeInfo(data.deadline, data.done)

  const handleCommonClick = (type: TodoRequestInfo['type']) => {
    setTodoRequestInfo({ id: data.id, type })
  }

  return (
    <Card className="shadow-none rounded-none border-0 border-b border-b-gray-200 p-0">
      <CardContent className="h-32 flex items-center gap-x-6">
        <div className="pl-2 pr-2">
          <Checkbox
            className="cursor-pointer"
            checked={!!checkedTodos.find((id) => id === data.id)}
            onCheckedChange={(checked) => {
              setCheckTodos(data.id, checked as boolean)
            }}
          />
        </div>
        <div className="grow shrink text-left">
          <p>
            <Badge className={badgeColor}>{badgeText}</Badge>
          </p>
          <p className="flex items-center gap-x-2 mt-2 mb-2">
            <Timer />
            <span className="text-sm">{`${convertFormatDeadline(data.deadline)}까지`}</span>
          </p>
          <p className="flex items-center gap-x-2">
            <NotebookPen />
            <span className="text-sm">{data.text}</span>
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-x-4 gap-y-2">
          <Button
            variant="outline"
            className="rounded-full w-8 h-8 cursor-pointer"
            onClick={() => handleCommonClick('complete')}
          >
            <span className="text-xs">완료</span>
          </Button>
          <Button
            variant="outline"
            className="rounded-full w-8 h-8 cursor-pointer"
            onClick={() => handleCommonClick('edit')}
          >
            <span className="text-xs">수정</span>
          </Button>
          <Button
            variant="outline"
            className="rounded-full w-8 h-8 cursor-pointer"
            onClick={() => handleCommonClick('delete')}
          >
            <span className="text-xs">삭제</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export default TodoListItemCard