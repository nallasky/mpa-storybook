import { useContext } from "react";

import { TodoListContext } from "@/lib/context/todolist-context";

export const useTodoList = () => {
  const context = useContext(TodoListContext)

  if (context === undefined) {
    throw new Error('useTodoList must be used within a TodoListContextProvider');
  }

  return context
}