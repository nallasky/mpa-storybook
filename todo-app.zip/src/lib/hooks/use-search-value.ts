import { useState, useEffect } from "react"

import { TodoListCommonForm } from "@/types/todolist"


export const useSearchValue = () => {
  const [innerSearchValues, setInnerSearchValues] = useState<Omit<TodoListCommonForm, 'done'> | undefined>(undefined)

  const getAndSaveSearchValue = () => {
    const savedSearchValue = localStorage.getItem('search')
    setInnerSearchValues(savedSearchValue === null ? undefined : JSON.parse(savedSearchValue))
  }

  const setSearchValues: (data: Omit<TodoListCommonForm, 'done'>) => void = (data) => {
    localStorage.setItem('search', JSON.stringify(data))
    setInnerSearchValues(data)
  }

  useEffect(() => {
    getAndSaveSearchValue()
  }, [])

  return { searchValues: innerSearchValues, setSearchValues }
}