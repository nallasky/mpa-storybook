import { differenceInDays } from 'date-fns'

export const isCloseToDeadline = (deadline: number) => {
  const today = new Date().setHours(0, 0, 0, 0)
  const convertTodayTimestamp = new Date(today).getTime()
  return differenceInDays(deadline, convertTodayTimestamp) <= 3
}