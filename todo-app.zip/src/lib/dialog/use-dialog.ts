import { useContext } from "react";

import { DialogContext } from "@/lib/dialog/dialog-context";

export const useDialog = () => {
  const { openDialog, closeDialog } = useContext(DialogContext)
  return { openDialog, closeDialog }
}