import React, { useContext, Fragment } from "react";
import ReactDOM from "react-dom"

import { DialogContext } from "@/lib/dialog/dialog-context";

export const GlobalDialog: React.FC = () => {
  const { openedDialogs, closeDialog } = useContext(DialogContext)
  const dialogsMapToArray = Array.from(openedDialogs)

  if (dialogsMapToArray.length === 0) {
    return;
  }

  console.log(dialogsMapToArray)

  return ReactDOM.createPortal(
    <Fragment>
      {dialogsMapToArray.map(([key, dialog]) => {
        const { Component, props = {} } = dialog
        return (
          <Component
            key={key}
            onClose={() => closeDialog(key)}
            {...props as object}
          />
        )
      })}
    </Fragment>,
    document.body
  )
}