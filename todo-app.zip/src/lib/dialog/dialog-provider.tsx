import React, { useState } from "react";
import type { ReactNode } from "react";

import { DialogContext } from "@/lib/dialog/dialog-context";
import type { TGlobalDialogContextState } from "@/lib/dialog/dialog-context";

export const DialogProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [openedDialogs, setOpenedDialogs] = useState<TGlobalDialogContextState['openedDialogs']>(new Map())

  const openDialog: TGlobalDialogContextState['openDialog'] = (key, dialog) => {
    setOpenedDialogs((prevDialogs) => {
      const { Component, props = {} } = dialog
      return new Map(prevDialogs).set(key, {
        Component,
        props: { ...props, open: true }
      })
    });
  }

  const closeDialog: TGlobalDialogContextState['closeDialog'] = (key: string) => {
    setOpenedDialogs((prevDialogs) => {
      const findDialog = prevDialogs.get(key)

      if (findDialog) {
        prevDialogs.set(key, {
          ...findDialog,
          props: {
            ...findDialog.props,
            open: false
          }
        })
      }

      return new Map(prevDialogs)
    })

    setTimeout(() => {
      setOpenedDialogs(prevDialogs => {
        const updatedDialogs = new Map(prevDialogs);
        updatedDialogs.delete(key);
        return updatedDialogs;
      })
    }, 300)
  }

  return (
    <DialogContext.Provider value={{ openedDialogs, openDialog, closeDialog }}>
      {children}
    </DialogContext.Provider>
  )
}
