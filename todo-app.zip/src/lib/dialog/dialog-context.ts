import { createContext } from "react";
import type { FunctionComponent } from "react";

import type { DialogProps } from "@radix-ui/react-dialog";

export type TGlobalDialogProps<T = unknown> = T & DialogProps & {
  onClose: () => void;
};

export type TGlobalDialogObject<T = unknown> = {
  Component: FunctionComponent<TGlobalDialogProps<T>>;
  props?: T;
};

export type TGlobalDialogContextState = {
  openedDialogs: Map<string, TGlobalDialogObject<object>>;
  openDialog: (key: string, modal: TGlobalDialogObject<object>) => void;
  closeDialog: (key: string) => void;
};

export const DialogContext = createContext<TGlobalDialogContextState>({
  openedDialogs: new Map<string, TGlobalDialogObject<object>>,
  openDialog: () => {},
  closeDialog: () => {}
});