import axios from 'axios'
import { useQuery, useMutation } from '@tanstack/react-query'

import type { AxiosError } from 'axios'
import type { QueryKey, UseMutationOptions, UseQueryOptions } from '@tanstack/react-query'

import type { APIResponse, ToDo, ToDoRequest } from '@/types/api'

const API_PREFIX = 'api'

type UseCommonGetQueryProps<T> = {
  url: string,
  fallbackData: T,
  options: Omit<UseQueryOptions<T, AxiosError>, 'queryFn'>
}

const useCommonGetQuery = <ResponseData>({
  url,
  fallbackData,
  options
}: UseCommonGetQueryProps<ResponseData>) => {
  const queryFn = async () => {
    const { data } = await axios.get<APIResponse<ResponseData>>(url);
    return data?.data ?? fallbackData;
  };

  return useQuery({
    ...options,
    queryFn,
  });
};

export const useGetTodos = () => {
  return useCommonGetQuery<ToDo[]>({
    url: `${API_PREFIX}/todos`,
    fallbackData: [],
    options: {
      queryKey: ['get-todos'],
      refetchOnWindowFocus: true,
      initialData: [],
    }
  })
}

export const useGetTodo = (id: ToDo['id'] | undefined) => {
  return useCommonGetQuery<ToDo | undefined>({
    url: `${API_PREFIX}/todos/${id}`,
    fallbackData: undefined,
    options: {
      queryKey: ['get-todo'],
      enabled: id !== undefined,
    }
  })
}

export const usePutToDo = (
  options?: UseMutationOptions<unknown, AxiosError, ToDo, QueryKey>
) => {
  const mutationFn = async (todo: ToDo) => {
    const { id, ...requestData } = todo
    const { data } = await axios.put<APIResponse<ToDo | undefined>>(
      `${API_PREFIX}/todos/${id}`,
      requestData
    )
    return data.data
  }

  return useMutation({
    ...options,
    mutationKey: ['put-todo'],
    mutationFn,
  })
}

export const usePostToDo = (
  options?: UseMutationOptions<unknown, AxiosError, ToDoRequest, QueryKey>
) => {
  const mutationFn = async (todo: ToDoRequest) => {
    const { data } = await axios.post<APIResponse<ToDo>>(
      `${API_PREFIX}/todos`,
      todo
    )
    return data.data
  }

  return useMutation({
    ...options,
    mutationKey: ['post-todo'],
    mutationFn,
  })
}

export const useDeleteToDo = (
  options?: UseMutationOptions<unknown, AxiosError, ToDo['id'], QueryKey>
) => {
  const mutationFn = async (id: ToDo['id']) => {
    const { data } = await axios.delete<APIResponse<undefined>>(`${API_PREFIX}/todos/${id}`)
    return data.code
  }

  return useMutation({
    ...options,
    mutationKey: ['delete-todo'],
    mutationFn,
  })
}