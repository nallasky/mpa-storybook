import React, { ReactNode, useState } from "react";

import { TodoListContext, TODO_REQUEST_INITIAL_STATE } from "./todolist-context";
import { TodoListContextState } from "@/types/todolist";

export const TodoListProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [checkedTodos, setCheckedTodos] = useState<TodoListContextState['checkedTodos']>([])
  const [todoRequestInfo, setTodoRequestInfo] = useState<TodoListContextState['todoRequestInfo']>(TODO_REQUEST_INITIAL_STATE);
  const [todoSearchInfo, setTodoSearchInfo] = useState<TodoListContextState['todoSearchInfo']>(undefined)
  const [todoSortType, setTodoSortType] = useState<TodoListContextState['todoSortType']>('id')

  const handleChangeCheckTodos: TodoListContextState['setCheckTodos'] = (id, isChecked) => {
    setCheckedTodos((prev) => {
      if (isChecked) {
        return [...prev, id]
      }
      return prev.filter((todoId) => todoId !== id)
    })
  }

  const handleChangeCheckTodosAll: TodoListContextState['setCheckTodosAll'] = (todos) => {
    setCheckedTodos(todos)
  }

  const handleChangeTodoRequestInfo: TodoListContextState['setTodoRequestInfo'] = (data) => {
    setTodoRequestInfo(data)
  }

  const handleChangeTodoSearchInfo: TodoListContextState['setTodoSearchInfo'] = (data) => {
    setTodoSearchInfo(data)
  }

  const handleChangeTodoSortType: TodoListContextState['setTodoSortType'] = (type) => {
    setTodoSortType(type)
  }

  const providerValues = {
    checkedTodos,
    todoRequestInfo,
    todoSearchInfo,
    todoSortType,
    setCheckTodos: handleChangeCheckTodos,
    setCheckTodosAll: handleChangeCheckTodosAll,
    setTodoRequestInfo: handleChangeTodoRequestInfo,
    setTodoSearchInfo: handleChangeTodoSearchInfo,
    setTodoSortType: handleChangeTodoSortType
  }

  return (
    <TodoListContext.Provider value={providerValues}>
      {children}
    </TodoListContext.Provider>
  )
}