import React, { ReactNode, useState } from "react";

import { TodoListContext } from "./todolist-context";
import { TodoListContextState } from "@/types/todolist";

export const TodoListProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [checkedTodos, setCheckedTodos] = useState<TodoListContextState['checkedTodos']>([])
  const [todoIdToEdit, setTodoIdToEdit] = useState<TodoListContextState['todoIdToEdit']>(undefined);
  const [todoIdToDelete, setTodoIdToDelete] = useState<TodoListContextState['todoIdToDelete']>(undefined);
  const [todoIdToComplete, setTodoIdToComplete] = useState<TodoListContextState['todoIdToComplete']>(undefined);
  const [todoSearchInfo, setTodoSearchInfo] = useState<TodoListContextState['todoSearchInfo']>(undefined)

  const handleChangeCheckTodos: TodoListContextState['setCheckTodos'] = (id, isChecked) => {
    setCheckedTodos((prev) => {
      if (isChecked) {
        return [...prev, id]
      }
      return prev.filter((todoId) => todoId !== id)
    })
  }

  const handleChangeCheckTodosAll: TodoListContextState['setCheckTodosAll'] = (todos) => {
    setCheckedTodos(todos)
  }

  const handleChangeTodoIdToEdit: TodoListContextState['setTodoIdToEdit'] = (id) => {
    setTodoIdToEdit(id)
  }

  const handleChangeTodoIdToDelete: TodoListContextState['setTodoIdToDelete'] = (id) => {
    setTodoIdToDelete(id)
  }

  const handleChangeTodoIdToComplete: TodoListContextState['setTodoIdToComplete'] = (id) => {
    setTodoIdToComplete(id)
  }

  const handleChangeTodoSearchInfo: TodoListContextState['setTodoSearchInfo'] = (data) => {
    setTodoSearchInfo(data)
  }

  const providerValues = {
    checkedTodos,
    todoIdToEdit,
    todoIdToDelete,
    todoIdToComplete,
    todoSearchInfo,
    setCheckTodos: handleChangeCheckTodos,
    setCheckTodosAll: handleChangeCheckTodosAll,
    setTodoIdToEdit: handleChangeTodoIdToEdit,
    setTodoIdToDelete: handleChangeTodoIdToDelete,
    setTodoIdToComplete: handleChangeTodoIdToComplete,
    setTodoSearchInfo: handleChangeTodoSearchInfo
  }

  return (
    <TodoListContext.Provider value={providerValues}>
      {children}
    </TodoListContext.Provider>
  )
}