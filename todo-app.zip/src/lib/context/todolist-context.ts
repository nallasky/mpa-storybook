import { createContext } from "react";

import { TodoListContextState } from "@/types/todolist";

export const TodoListContext = createContext<TodoListContextState | undefined>(undefined)