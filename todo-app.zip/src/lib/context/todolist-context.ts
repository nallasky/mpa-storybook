import { createContext } from "react";

import { TodoListContextState } from "@/types/todolist";

export const TODO_REQUEST_INITIAL_STATE: TodoListContextState['todoRequestInfo'] = {
  id: undefined,
  type: null
}

export const TodoListContext = createContext<TodoListContextState | undefined>(undefined)