import { ToDo } from "./api"

export type TodoListCommonForm = {
  text: string,
  deadline: number,
  done: string,
}

export type TodoListContextState = {
  checkedTodos: ToDo['id'][],
  todoIdToEdit: ToDo['id'] | undefined,
  todoIdToDelete: ToDo['id'] | undefined,
  todoIdToComplete: ToDo['id'] | undefined,
  todoSearchInfo: Omit<TodoListCommonForm, 'done'> | undefined,
  setCheckTodos: (id: ToDo['id'], isChecked: boolean) => void,
  setCheckTodosAll: (todos: ToDo['id'][]) => void,
  setTodoIdToEdit: (id: ToDo['id'] | undefined) => void,
  setTodoIdToDelete: (id: ToDo['id'] | undefined) => void
  setTodoIdToComplete: (id: ToDo['id'] | undefined) => void
  setTodoSearchInfo: (data: Omit<TodoListCommonForm, 'done'>) => void
}