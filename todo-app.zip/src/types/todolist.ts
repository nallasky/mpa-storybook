import { ToDo } from "./api"

export type TodoListCommonForm = {
  text: string,
  deadline: number,
  done: string,
}

export type TodoRequestInfo = {
  id: ToDo['id'] | undefined,
  type: 'edit' | 'delete' | 'complete' | null
}

export type TodoSortType = 'id' | 'deadline'

export type TodoListContextState = {
  checkedTodos: ToDo['id'][],
  todoRequestInfo: TodoRequestInfo,
  todoSearchInfo: Omit<TodoListCommonForm, 'done'> | undefined,
  todoSortType: TodoSortType
  setCheckTodos: (id: ToDo['id'], isChecked: boolean) => void,
  setCheckTodosAll: (todos: ToDo['id'][]) => void,
  setTodoRequestInfo: (data: TodoRequestInfo) => void,
  setTodoSearchInfo: (data: Omit<TodoListCommonForm, 'done'> | undefined) => void
  setTodoSortType: (type: TodoSortType) => void
}