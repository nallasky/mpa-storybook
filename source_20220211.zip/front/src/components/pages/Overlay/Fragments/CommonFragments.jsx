import React, { useEffect, useState } from 'react';
import {
  Button,
  DatePicker,
  Input,
  InputNumber,
  Radio,
  Select,
  Switch,
  Upload,
  Divider,
  TreeSelect,
  Space,
} from 'antd';
import {
  CloudDownloadOutlined,
  DownOutlined,
  InboxOutlined,
  PlayCircleOutlined,
  TableOutlined,
  UploadOutlined,
  DotChartOutlined,
  BarChartOutlined,
  AlignLeftOutlined,
  PlusCircleOutlined,
} from '@ant-design/icons';
import PropTypes from 'prop-types';
import * as SG from './styleGroup';
import { CorrectionExpoTable } from './CorrectionFragments';

export const SelectSource = ({ mode }) => {
  const [from, setFrom] = useState('1');

  return (
    <div css={SG.componentStyle} className="stretch">
      <div css={SG.componentTitleStyle}>Select Source</div>
      <div css={SG.contentWrapperStyle}>
        <div css={SG.contentStyle} className="full-width">
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">From</span>
            <Select
              value={from}
              style={{ width: '100%' }}
              onChange={(v) => setFrom(v)}
            >
              <Select.Option value="1">Local</Select.Option>
              <Select.Option value="2">Remote</Select.Option>
            </Select>
          </div>
          {from === '1' ? (
            <div css={SG.contentItemStyle} className="upload column-2">
              <span className="label">Log Files</span>
              {mode === 'measurement' ? (
                <Upload.Dragger>
                  <p className="ant-upload-drag-icon">
                    <InboxOutlined />
                  </p>
                  <p className="ant-upload-text">
                    Click or drag file to this area to upload
                  </p>
                </Upload.Dragger>
              ) : (
                <Upload className="full-width">
                  <Button icon={<UploadOutlined />}>Upload zip only</Button>
                </Upload>
              )}
            </div>
          ) : (
            <div css={SG.contentItemStyle} className="column-2">
              <span className="label">DB From</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">cras_db@10.1.xxx.xxx</Select.Option>
                <Select.Option value="2">cras_db2@10.1.xxx.xxx</Select.Option>
              </Select>
            </div>
          )}
        </div>
      </div>
      {from === '1' ? (
        <div className="source-button-wrapper">
          <button css={SG.antdButtonStyle} className="white">
            Load Start
          </button>
        </div>
      ) : (
        ''
      )}
    </div>
  );
};
SelectSource.propTypes = {
  mode: PropTypes.string,
};
SelectSource.defaultProps = {
  mode: 'measurement',
};

const diffData = [
  {
    title: 'ALL',
    value: '0',
    key: '0',
    children: [
      {
        title: 'Normal Lot ID',
        value: '0-0',
        key: '0-0',
        children: [
          {
            title: '1',
            value: '0-0-0',
            key: '0-0-0',
          },
          {
            title: '2',
            value: '0-0-1',
            key: '0-0-1',
          },
          {
            title: '3',
            value: '0-0-2',
            key: '0-0-2',
          },
          {
            title: '4',
            value: '0-0-3',
            key: '0-0-3',
          },
          {
            title: '5',
            value: '0-0-4',
            key: '0-0-4',
          },
        ],
      },
    ],
  },
];

const lotIdData = [
  {
    title: 'ALL',
    value: '0',
    key: '0',
    children: [
      {
        title: 'Normal Lot ID',
        value: '0-0',
        key: '0-0',
        children: [
          {
            title: 'AAA001',
            value: '0-0-0',
            key: '0-0-0',
          },
          {
            title: 'AAA002',
            value: '0-0-1',
            key: '0-0-1',
          },
          {
            title: 'AAA003',
            value: '0-0-2',
            key: '0-0-2',
          },
          {
            title: 'AAA004',
            value: '0-0-3',
            key: '0-0-3',
          },
          {
            title: 'AAA005',
            value: '0-0-4',
            key: '0-0-4',
          },
        ],
      },
      {
        title: 'Pseudo Lot ID',
        value: '0-1',
        key: '0-1',
        children: [
          {
            title: 'LOTID_2021-08-06-1',
            value: '0-1-0',
            key: '0-1-0',
          },
          {
            title: 'LOTID_2021-08-06-2',
            value: '0-1-1',
            key: '0-1-1',
          },
          {
            title: 'LOTID_2021-08-06-3',
            value: '0-1-2',
            key: '0-1-2',
          },
          {
            title: 'LOTID_2021-08-06-4',
            value: '0-1-3',
            key: '0-1-3',
          },
          {
            title: 'LOTID_2021-08-06-5',
            value: '0-1-4',
            key: '0-1-4',
          },
        ],
      },
    ],
  },
];

const sCorrectionData = [
  {
    title: 'ALL',
    value: '0',
    key: '0',
    children: [
      {
        title: 'DR',
        value: '0-0',
        key: '0-0',
        children: [
          {
            title: 'bdc x',
            value: '0-0-0',
            key: '0-0-0',
          },
          {
            title: 'sdc dr',
            value: '0-0-1',
            key: '0-0-1',
          },
          {
            title: 'adc dr',
            value: '0-0-2',
            key: '0-0-2',
          },
          {
            title: 'yaw dr',
            value: '0-0-3',
            key: '0-0-3',
          },
          {
            title: 'auto dr',
            value: '0-0-4',
            key: '0-0-4',
          },
          {
            title: 'bar rotation',
            value: '0-0-5',
            key: '0-0-5',
          },
        ],
      },
      {
        title: 'MY',
        value: '0-1',
        key: '0-1',
        children: [
          {
            title: 'bdc y',
            value: '0-1-0',
            key: '0-1-0',
          },
          {
            title: 'sdc my',
            value: '0-1-1',
            key: '0-1-1',
          },
          {
            title: 'adc my',
            value: '0-1-2',
            key: '0-1-2',
          },
          {
            title: 'yaw my',
            value: '0-1-3',
            key: '0-1-3',
          },
          {
            title: 'mag x shift y',
            value: '0-1-4',
            key: '0-1-4',
          },
        ],
      },
      {
        title: 'YAW',
        value: '0-2',
        key: '0-2',
        children: [
          {
            title: 'sdc yaw',
            value: '0-2-0',
            key: '0-2-0',
          },
          {
            title: 'adc yaw',
            value: '0-2-1',
            key: '0-2-1',
          },
          {
            title: 'bdc t',
            value: '0-2-2',
            key: '0-2-2',
          },
        ],
      },
    ],
  },
];

const aCorrectionData = [
  {
    title: 'ALL',
    value: '0',
    key: '0',
    children: [
      {
        title: 'bdc x',
        value: '0-0',
        key: '0-0',
      },
      {
        title: 'sdc dr',
        value: '0-1',
        key: '0-1',
      },
      {
        title: 'adc dr',
        value: '0-2',
        key: '0-2',
      },
      {
        title: 'yaw dr',
        value: '0-3',
        key: '0-3',
      },
      {
        title: 'auto dr',
        value: '0-4',
        key: '0-4',
      },
      {
        title: 'bar rotation',
        value: '0-5',
        key: '0-5',
      },
    ],
  },
];

export const SelectTarget = ({ mode }) => {
  return (
    <div css={SG.componentStyle}>
      <div css={SG.componentTitleStyle}>Select Target</div>
      <div css={SG.contentWrapperStyle} className="mg-bottom">
        <div css={SG.contentStyle}>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Fab</span>
            <Select
              defaultValue="1"
              style={{ width: '100%' }}
              dropdownRender={(menu) => (
                <div>
                  <div css={SG.customSelectStyle}>
                    <Input type="text" style={{ width: '100%' }} />
                    <div className="button">
                      <PlusCircleOutlined />
                    </div>
                  </div>
                  <Divider style={{ margin: '4px 0' }} />
                  {menu}
                </div>
              )}
            >
              <Select.Option value="1">Fab1600</Select.Option>
              <Select.Option value="2">Fab1700</Select.Option>
            </Select>
          </div>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Equipment</span>
            <Select defaultValue="1" style={{ width: '100%' }}>
              <Select.Option value="1">Tool1600_1</Select.Option>
              <Select.Option value="2">Tool1700_1</Select.Option>
            </Select>
          </div>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Period</span>
            <DatePicker.RangePicker
              style={{ width: '100%' }}
              inputReadOnly
              allowClear={false}
            />
          </div>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Job</span>
            <Select defaultValue="1" style={{ width: '100%' }}>
              <Select.Option value="1">Job1</Select.Option>
              <Select.Option value="2">Job2</Select.Option>
            </Select>
          </div>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Lot ID</span>
            <TreeSelect
              treeData={lotIdData}
              showCheckedStrategy={TreeSelect.SHOW_CHILD}
              style={{ width: '100%' }}
              maxTagCount="responsive"
              treeCheckable
              treeDefaultExpandAll
            />
          </div>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Mean Deviation Diff.</span>
            <TreeSelect
              treeData={diffData}
              showCheckedStrategy={TreeSelect.SHOW_CHILD}
              style={{ width: '100%' }}
              maxTagCount="responsive"
              treeCheckable
              treeDefaultExpandAll
            />
          </div>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">AE Correction</span>
            <Select defaultValue="1" style={{ width: '100%' }}>
              <Select.Option value="1">Off</Select.Option>
              <Select.Option value="2">On</Select.Option>
            </Select>
          </div>
          {mode !== 'measurement' ? (
            <>
              <div css={SG.contentItemStyle} className="column-2">
                <span className="label">Stage Correction</span>
                <TreeSelect
                  treeData={sCorrectionData}
                  showCheckedStrategy={TreeSelect.SHOW_CHILD}
                  style={{ width: '100%' }}
                  maxTagCount="responsive"
                  treeCheckable
                  treeDefaultExpandAll
                />
              </div>
              <div css={SG.contentItemStyle} className="column-2">
                <span className="label">ADC Correction</span>
                <TreeSelect
                  treeData={aCorrectionData}
                  showCheckedStrategy={TreeSelect.SHOW_CHILD}
                  style={{ width: '100%' }}
                  maxTagCount="responsive"
                  treeCheckable
                  treeDefaultExpandAll
                  dropdownRender={(menu) => (
                    <div>
                      <div style={{ padding: '8px' }}>
                        <Radio.Group defaultValue="1">
                          <Space direction="vertical">
                            <Radio value="1">ADC Measurement</Radio>
                            <Radio value="2">ADC Offset</Radio>
                            <Radio value="3">ADC Measurement + Offset</Radio>
                          </Space>
                        </Radio.Group>
                      </div>
                      {menu}
                    </div>
                  )}
                />
              </div>
            </>
          ) : (
            ''
          )}
        </div>
        <div css={SG.customButtonStyle} className="absolute">
          <PlayCircleOutlined />
          <span>Start</span>
        </div>
      </div>
    </div>
  );
};
SelectTarget.propTypes = {
  mode: PropTypes.string,
};
SelectTarget.defaultProps = {
  mode: 'measurement',
};

const SettingAccordion = ({ title, children, defaultValue }) => {
  const [isCollapsed, setIsCollapsed] = useState(defaultValue);

  return (
    <div css={SG.accordionStyle} className={isCollapsed ? 'collapsed' : ''}>
      <div
        onClick={() => setIsCollapsed(!isCollapsed)}
        onKeyDown={undefined}
        role="button"
        tabIndex="-1"
      >
        <span className="title">{title}</span>
        <DownOutlined />
      </div>
      <div>
        <div className="contents">{children}</div>
      </div>
    </div>
  );
};
SettingAccordion.displayName = 'OverlaySettingAccordion';
SettingAccordion.propTypes = {
  title: PropTypes.string,
  children: PropTypes.node.isRequired,
  defaultValue: PropTypes.bool,
};
SettingAccordion.defaultProps = {
  defaultValue: true,
};

const CustomRadioGroup = ({
  options,
  name,
  className,
  changeFunc,
  currentChecked,
}) => {
  return (
    <div css={SG.radioGroupStyle}>
      {options.map((v, i) => {
        return (
          <label htmlFor={v.id} key={i} className={className}>
            <input
              type="radio"
              name={name}
              id={v.id}
              checked={v.id === currentChecked}
              onChange={() => changeFunc(v.id)}
            />
            <div className={`button ${className}`}>
              {v.icon ? v.icon : ''}
              {v.title}
            </div>
          </label>
        );
      })}
    </div>
  );
};
CustomRadioGroup.propTypes = {
  options: PropTypes.array.isRequired,
  name: PropTypes.string.isRequired,
  className: PropTypes.string,
  changeFunc: PropTypes.func.isRequired,
  currentChecked: PropTypes.string.isRequired,
};

const CommonCpVsTable = () => {
  return (
    <div className="table-wrapper">
      <table css={SG.tableStyle}>
        <thead>
          <tr>
            <th>SHOT</th>
            <th>CP1</th>
            <th>CP2</th>
            <th>CP3</th>
            <th>VS1</th>
            <th>VS2</th>
            <th>VS3</th>
            <th>DISPLAY</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Job1</Select.Option>
                <Select.Option value="2">Job2</Select.Option>
              </Select>
            </td>
          </tr>
          <tr>
            <td>2</td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Job1</Select.Option>
                <Select.Option value="2">Job2</Select.Option>
              </Select>
            </td>
          </tr>
          <tr>
            <td>3</td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Job1</Select.Option>
                <Select.Option value="2">Job2</Select.Option>
              </Select>
            </td>
          </tr>
          <tr>
            <td>4</td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Job1</Select.Option>
                <Select.Option value="2">Job2</Select.Option>
              </Select>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

const OffsetSetting = () => {
  return (
    <SettingAccordion title="Offset X/Y" defaultValue={false}>
      <div css={SG.settingContentStyle}>
        <div className="content">
          <div css={SG.contentItemStyle} className="column-3">
            <div className="switch-wrapper" />
            <span className="title">Offset X</span>
            <span className="title">Offset Y</span>
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 1</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 2</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 3</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 4</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 5</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 6</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
        </div>
      </div>
    </SettingAccordion>
  );
};

const CpVpOption = () => {
  return (
    <>
      <div css={SG.contentItemStyle} className="column-3">
        <span className="label">Preset</span>
        <Select defaultValue="1" style={{ width: '100%' }}>
          <Select.Option value="1">Job1</Select.Option>
          <Select.Option value="2">Job2</Select.Option>
        </Select>
        <div className="preset-setting">
          <Input placeholder="Enter preset name." />
          <button css={SG.antdButtonStyle} className="blue">
            Save Preset
          </button>
        </div>
      </div>
      <div css={SG.contentItemStyle} className="column-3">
        <span className="label">CP/VS</span>
        <Radio.Group value="1" className="radio-cp-vs">
          <Radio value="1">Set CP/VS for each shot</Radio>
          <Radio value="2">Reflect the CP/VS of shot1 on all shots</Radio>
        </Radio.Group>
      </div>
    </>
  );
};

const CpVsMeasurement = () => {
  return (
    <>
      <CpVpOption />
      <CommonCpVsTable />
      <div css={SG.contentItemStyle} className="column-3">
        <span className="label">Job data file</span>
        <Upload>
          <Button icon={<UploadOutlined />}>Load</Button>
        </Upload>
      </div>
    </>
  );
};

const CpVsSetting = ({ mode }) => {
  const [tab, setTab] = useState('measurement');
  const [tmpArray, setTmpArray] = useState([]);

  const createDummyData = () => {
    const tmpBuf = [];

    for (let i = 0; i < 6; i++) {
      const flag = i < 3;
      tmpBuf.push({
        shot: {
          id: i + 1,
          mode: flag ? 'manual' : 'auto',
        },
        cp1: {
          checked: flag,
          value: '-600.000000',
        },
        'cp12`': {
          checked: !flag,
          value: '-450.000000',
        },
        'cp1`': {
          checked: flag,
          value: '-300.000000',
        },
        'cp21`': {
          checked: !flag,
          value: '-150.000000',
        },
        cp2: {
          checked: flag,
          value: '0.000000',
        },
        'cp23`': {
          checked: !flag,
          value: '150.000000',
        },
        'cp3`': {
          checked: flag,
          value: '300.000000',
        },
        'cp32`': {
          checked: !flag,
          value: '450.000000',
        },
        cp3: {
          checked: flag,
          value: '600.000000',
        },
      });
    }

    setTmpArray(tmpBuf);
  };

  useEffect(() => {
    createDummyData();
  }, []);

  return (
    <SettingAccordion title="CP / VS">
      <div
        css={SG.settingContentStyle}
        className={mode !== 'measurement' ? 'full-width' : ''}
      >
        <div className="content">
          {mode === 'measurement' ? (
            <CpVsMeasurement />
          ) : (
            <>
              <div className="radio-wrapper">
                <CustomRadioGroup
                  changeFunc={(v) => setTab(v)}
                  currentChecked={tab}
                  options={[
                    {
                      id: 'measurement',
                      title: 'ADC Measurement',
                      icon: undefined,
                    },
                    {
                      id: 'comp-exposure',
                      title: 'Correction component of exposure',
                      icon: undefined,
                    },
                  ]}
                  name="cp-vs-option"
                  className="cp-vs"
                />
              </div>
              <div
                css={SG.settingContentStyle}
                className={
                  'tab ' + (tab === 'measurement' ? '' : 'correction-cp-vs')
                }
              >
                {tab === 'measurement' ? (
                  <CpVsMeasurement />
                ) : (
                  <div>
                    <CpVpOption />
                    <div className="table-wrapper">
                      <CorrectionExpoTable
                        rows={tmpArray}
                        columns={tmpArray[0]}
                      />
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </SettingAccordion>
  );
};
CpVsSetting.propTypes = {
  mode: PropTypes.string,
};
CpVsSetting.defaultProps = {
  mode: 'measurement',
};

const EtcSetting = ({ mode }) => {
  return (
    <SettingAccordion title="Etc.">
      <div css={SG.settingContentStyle} className="etc">
        <div className="content">
          <div css={SG.contentItemStyle} className="etc">
            <span className="label">Display Map</span>
            <div>
              <InputNumber />
              <span className="margin-lr">~</span>
              <InputNumber />
            </div>
          </div>
          <div css={SG.contentItemStyle} className="etc">
            <span className="label">Number of Columns to Display</span>
            <InputNumber />
          </div>
          <div css={SG.contentItemStyle} className="etc">
            <span className="label">Div</span>
            <div className="tx-right">
              <span className="margin-r">Upper Row</span>
              <Input style={{ width: '40%' }} />
            </div>
          </div>
          <div css={SG.contentItemStyle} className="etc">
            <span className="label">Plate Size</span>
            <div className="tx-right">
              <span className="margin-r">Size_X</span>
              <Input style={{ width: '30%' }} />
              <span className="margin-lr">Size_Y</span>
              <Input style={{ width: '30%' }} />
            </div>
          </div>
          {mode === 'measurement' ? (
            <div css={SG.contentItemStyle} className="etc">
              <span className="label">Map Show Data</span>
              <Switch defaultChecked />
            </div>
          ) : (
            ''
          )}
        </div>
      </div>
    </SettingAccordion>
  );
};
EtcSetting.propTypes = {
  mode: PropTypes.string,
};
EtcSetting.defaultProps = {
  mode: 'measurement',
};

export const SelectResult = ({ mode }) => {
  const [resultType, setResultType] = useState(
    mode === 'measurement' ? 'map' : 'img',
  );

  return (
    <div css={SG.componentStyle} className="span">
      <div css={SG.controlStyle}>
        <CustomRadioGroup
          changeFunc={(v) => setResultType(v)}
          currentChecked={resultType}
          options={
            mode === 'measurement'
              ? [
                  {
                    id: 'map',
                    title: 'Map',
                    icon: <TableOutlined />,
                  },
                  {
                    id: 'variation',
                    title: 'Variation',
                    icon: <DotChartOutlined />,
                  },
                  {
                    id: 'reproducibility',
                    title: 'Reproducibility',
                    icon: <BarChartOutlined />,
                  },
                  {
                    id: 'anova',
                    title: 'Anova',
                    icon: <AlignLeftOutlined />,
                  },
                ]
              : [
                  {
                    id: 'img',
                    title: 'Correction Image Map',
                    icon: <TableOutlined />,
                  },
                  {
                    id: 'comp',
                    title: 'Correction Component Map',
                    icon: <TableOutlined />,
                  },
                ]
          }
          name="result-type"
        />
        <div css={SG.customButtonStyle}>
          <CloudDownloadOutlined />
          <span>Download</span>
        </div>
      </div>
      <div css={SG.settingStyle}>
        <div className="header">
          <span>Map Setting</span>
          <div>
            <button css={SG.antdButtonStyle} className="blue">
              Apply
            </button>
          </div>
        </div>
        <div className="main">
          <OffsetSetting />
          <CpVsSetting mode={mode} />
          <EtcSetting mode={mode} />
        </div>
      </div>
      <div css={SG.resultStyle}>result</div>
    </div>
  );
};
SelectResult.propTypes = {
  mode: PropTypes.string,
};
SelectResult.defaultProps = {
  mode: 'measurement',
};
