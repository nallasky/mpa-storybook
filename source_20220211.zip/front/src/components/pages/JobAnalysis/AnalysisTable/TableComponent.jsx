import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import ReactTable from '../../../UI/atoms/Table/ReactTable';

const AnalysisTableComponent = ({ tableOrder, tableData, type }) => {
  const columnData = useMemo(() => tableOrder, [JSON.stringify(tableOrder)]);
  const rowData = useMemo(() => tableData, [JSON.stringify(tableData)]);

  return (
    <ReactTable
      columns={columnData}
      data={rowData}
      disableSelectRows={type !== 'analysis'}
    />
  );
};

AnalysisTableComponent.displayName = 'TableComponent';
AnalysisTableComponent.propTypes = {
  tableOrder: PropTypes.array.isRequired,
  tableData: PropTypes.array.isRequired,
  type: PropTypes.string.isRequired,
};

export default AnalysisTableComponent;
