import Plotly from 'plotly.js-dist';

const filterAxisData = (rows, key, type) => {
  const arr = [];

  if (type === 'step') {
    const getReduceValue = (rows, key_name, key, array) => {
      const result = Object.values(rows).reduce((acc, v) => {
        if (
          (v['No.'] === undefined || v['No.'] !== 'ALL') &&
          (v['period'] === undefined || v['period'] !== 'NaT') &&
          (v['log_time'] === undefined || v['log_time'] !== 'NaT') &&
          v[key]
        ) {
          acc.push(v[key]);
        }
        return acc;
      }, array);
      return key_name === undefined ? result : { [key_name]: result };
    };
    if (key ?? false) {
      if (Array.isArray(rows)) {
        Array.isArray(key)
          ? rows.map((row) =>
              getReduceValue(row?.[key[0]] ?? row, key.join('/'), key[1], arr),
            )
          : rows.map((row) =>
              Object.entries(row).forEach(([i, j]) =>
                getReduceValue(j, `${i}/${j}`, key, arr),
              ),
            );
      } else {
        getReduceValue(rows, undefined, key, arr);
      }
    }
  } else {
    const rowName = key.match(/[/]/) ? key.split('/') : '';
    const currentRow = rowName !== '' ? rows[rowName[0]] : rows;
    const currentKey = rowName !== '' ? rows[rowName[1]] : key;

    Object.values(currentRow).reduce((acc, v) => {
      if (
        (v['No.'] === undefined || v['No.'] !== 'ALL') &&
        (v['period'] === undefined || v['period'] !== 'NaT') &&
        (v['log_time'] === undefined || v['log_time'] !== 'NaT') &&
        v[currentKey]
      ) {
        acc.push(v[currentKey]);
      }
      return acc;
    }, arr);
  }

  return arr;
};

export const createAxisData = (rows, keys, type) => {
  const tmpObj = {};

  if (keys.y.length > 0 && Object.keys(rows).length > 0) {
    keys.y.reduce((acc, v) => {
      acc[v] = filterAxisData(rows, v, type);
      return acc;
    }, tmpObj);
  }

  return {
    xaxisData:
      keys.x !== '0' &&
      keys.x !== '' &&
      keys.x !== null &&
      Object.keys(rows).length > 0
        ? filterAxisData(rows, keys.x, type)
        : [],
    yaxisData: tmpObj,
    zaxisData:
      keys.z !== '0' &&
      keys.z !== '' &&
      keys.z !== null &&
      Object.keys(rows).length > 0
        ? filterAxisData(rows, keys.z, type)
        : [],
  };
};

export const drawGraph = (rows, items, ref, type) => {
  items.forEach((v, i) => {
    const currentInfo = ref.graph_list.find((z) => z.name === v.type[0]);
    const currentScript = ref.function_graph_type.find((x) => {
      return currentInfo.type === 'user'
        ? x.name === currentInfo.name
        : x.type === currentInfo.type;
    }).script;
    const newFunc = new Function('return ' + currentScript)();
    const { xaxisData, yaxisData, zaxisData } = createAxisData(
      rows,
      {
        x: v.x_axis,
        y: v.y_axis,
        z: v.z_axis,
      },
      type,
    );

    const params = {
      type: v.type,
      x: xaxisData,
      y: yaxisData,
      z: zaxisData,
      title: v.title,
      range: {
        x: v.x_range_min !== '' ? [v.x_range_min, v.x_range_max] : [],
        y: v.y_range_min !== '' ? [v.y_range_min, v.y_range_max] : [],
        z: v.z_range_min !== '' ? [v.z_range_min, v.z_range_max] : [],
      },
    };
    newFunc(Plotly, document.getElementById(`${type}_graph_${i}`), params);
  });
};
