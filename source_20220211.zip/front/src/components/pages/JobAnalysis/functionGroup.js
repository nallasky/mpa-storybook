import { notification } from 'antd';
import { jsonToCSV } from '../../../lib/util/plotly-test';
import Plotly from 'plotly.js';

export const getTableData = (row, column) => {
  const jsonArr = [];
  Object.keys(row).reduce((accMain, v) => {
    const tmpObj = {};
    column.reduce((accSub, i) => {
      Object.assign(accSub, { [i]: row[v][i] });
      return accSub;
    }, tmpObj);
    accMain.push(tmpObj);
    return accMain;
  }, jsonArr);
  return jsonToCSV(jsonArr);
};

export const createGraphImage = async () => {
  const imgArr = [];
  const components = document.querySelectorAll('div[class^="js-plotly-plot"]');

  for (let i = 0; i < components.length; i++) {
    const data = components[i];
    const title = components[i].querySelector('text[class^="gtitle"]')
      .innerHTML;
    const nameHeader = components[i].id.split('_')[0];

    await Plotly.toImage(data, {
      format: 'png',
      filename: `graph_${title}_${i}`,
    }).then((url) => {
      imgArr.push({
        url: url,
        filename: `${nameHeader}.${title}_${i}.png`,
      });
    });
  }

  return imgArr;
};

export const displayNotification = (args) => {
  notification.open(args);
};

export const createGraphItems = (data) => {
  const newItems = [];

  if (data.items.length > 0) {
    data.items.reduce((acc, v) => {
      const graphType = data.graph_list.find((z) => z.name === v.type[0]);
      const graphInfo = data.function_graph_type.find((x) => {
        return graphType.type === 'user'
          ? x.name === graphType.name
          : x.type === graphType.type;
      });

      v['script_info'] = {
        script: graphInfo.script,
        type: graphInfo.type,
      };

      acc.push(v);
      return acc;
    }, newItems);
  }

  return newItems;
};

export const checkInnerData = (data) => {
  let i = 0,
    isSingle = false;

  while (i < Object.values(data).length) {
    if (Array.isArray(Object.values(data)[i])) {
      isSingle = true;
      break;
    }
    i++;
  }
  return isSingle;
};

export const createAnalysisData = (type, data, key) => {
  if (data === undefined || Object.keys(data).length === 0) return {};

  if (type.match(/multi/)) {
    const tmpData = {};

    if (!checkInnerData(data)) {
      data.forEach((v) => {
        tmpData[Object.keys(v)[0]] = v[Object.keys(v)[0]][key];
      });
      return tmpData;
    }
  }
  return data[key];
};
