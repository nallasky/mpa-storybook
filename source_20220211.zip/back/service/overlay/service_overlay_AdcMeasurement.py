import os
import logging
import pandas as pd
import numpy as np
import traceback

from service.overlay.service_overlay_base import ServiceOverlayBase
from service.converter.convert_process import ConvertProcess
from common.utils.response import ResponseForm
from config import app_config
from dao.dao_file import FileDao
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from controller.converter.converter import create_request_id

logger = logging.getLogger(app_config.LOG)


class ServiceAdcMeasurement(ServiceOverlayBase):
    log_name = 'ADCMEASUREMENT'

    # 計測値の変数名
    meas_x_rl_ivalue = [['p1_xr', 'p1_xl'],
                        ['p2_xr', 'p2_xl'],
                        ['p3_xr', 'p3_xl']]

    meas_y_rl_ivalue = [['p1_yr', 'p1_yl'],
                        ['p2_yr', 'p2_yl'],
                        ['p3_yr', 'p3_yl']]

    cp_ivalue = ['cp1','cp2','cp3']

    vs_ivalue = ['vs1','vs2','vs3']

    # plate倍率/回転成分は 1000 倍で表示する
    plate_rot_coef = 1.0e3
    plate_mag_coef = 1.0e3

    def __init__(self):
        super().__init__()

        self.root_path = app_config.root_path
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.log_name
        }

    def file_check(self, files):
        """

        :param files: [files]
        :return: {'log_name': [fids]}
        """

        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        if not os.path.exists(self.root_path):
            os.mkdir(self.root_path)

        # Save files and Insert file info into cnvset.file table
        data = dict()
        data[self.log_name] = list()

        for file in files:
            filename = file.filename
            f = None
            file_index = 1
            while f is None or os.path.exists(f):
                _filename = f'{file_index}____{filename}'
                f = os.path.join(self.root_path, _filename)
                file_index += 1
            file.save(f)
            fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))
            if fid is None:
                logger.error('failed to store file info')
                return ResponseForm(res=False, msg='failed to store file info')

            data[self.log_name].append(fid)

        """
        {
            'ADCMEASUREMENT': [fids]
        }
        """
        return ResponseForm(res=True, data=data)

    def convert(self, logs):
        """

        :param logs: { 'log_name': [fids] }
        :return:
        """

        # Create Request ID
        self.form['id'] = create_request_id()

        self.form['file'] = ','.join([str(_) for _ in logs[self.log_name]])

        # Insert Job info into cnvset.job
        io = DAOJob.instance()
        try:
            io.insert_job(**self.form)
        except Exception as e:
            logger.error('failed to insert job')
            return ResponseForm(res=False, msg=str(e))

        # Create sub processor to convert log
        dao = DAOBaseClass(table_name='analysis.local_info')
        row = dao.fetch_one(args={'select': 'func_id', 'where': f"log_name = '{self.log_name}'"})
        if row is None:
            return ResponseForm(res=False, msg=f'Cannot find {self.log_name} function.')

        func_id = row['func_id']
        cnv_proc = ConvertProcess(self.form['id'], func_id)
        cnv_proc.start()

        return ResponseForm(res=True, data=self.form['id'])

    def create_map(self, log_data):
        """
        MAPを作成するためのデータを生成
        param log_data : ファイル及びDBから取得したデータ[Pandas DataFrame]
        return Map_data : Plotly Carpet TypeのGraph作成用座標データ[Dict]
        """

        try:
            map_data = dict()
            # lot_idリスt作成
            # データからlot_idリスt作成
            lot_id = log_data['lot_id'].unique()
            for lot_index in lot_id:
                # 対象LotIDのデータ抽出
                lot_temp = log_data[log_data['lot_id'] == lot_index]
                # Plateリスト作成
                plate_list = log_data['plate'].unique()
                plate = {}
                for plate_index in plate_list:
                    # 対象Plateのデータ抽出
                    plate_temp = lot_temp[lot_temp['plate'] == plate_index]
                    # 対象PlateのGlass名を抽出
                    glass_name = plate_temp['glass_id'].unique()
                    # Shotリスト作成
                    shot_list = plate_temp['step'].unique()
                    shot = {}
                    for shot_index in shot_list:
                        # 対象Shotのデータ抽出
                        shot_temp = plate_temp[plate_temp['step'] == shot_index]
                        # MAP作成用座標を計算
                        base, measurement = self.shot_pos_calc(shot_temp)
                        # Shot別のデータをDict形式で保存
                        shot[int(shot_index)] = {"base": base, "measurement": measurement}
                    # Glass名とPlate別のでーたをDict形式で保存
                    plate[int(plate_index)] = {"glass_num": glass_name[0], "shot": shot}
                # LotID別のデータをDict形式で保存
                map_data[lot_index] = plate
            return ResponseForm(res=True, data=map_data)

        except Exception as e:
            logger.error('failed to create map')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def shot_pos_calc(self, shot_info):
        """
        Shotデータから基本格子、ズレ格子の座標を演算
        param shot_info : 対象ShotのLogData [Pandas DataFrame]
        return base : 基本格子の各Shot別計測点の座標 [DICT]
        retun measurement :各Shot別計測点の計測値 [DICT]
        """

        try:
            # LogicalPositionX,Yを㎜単位で変更
            x_pos = shot_info['logicalposition_x'].values[0]
            y_pos = shot_info['logicalposition_y'].values[0]
            # MAP座標名リストを生成
            pos_list = ['P1L', 'P1R', 'P2L', 'P2R', 'P3L', 'P3R']
            # DataFrameの各ズレのColumn名リスト生成
            dx_list = ['p1_xl', 'p1_xr', 'p2_xl', 'p2_xr', 'p3_xl', 'p3_xr']
            dy_list = ['p1_yl', 'p1_yr', 'p2_yl', 'p2_yr', 'p3_yl', 'p3_yr']
            base = {}
            measurement = {}
            # ShotのCP/VS情報を㎜単位で変更してリスト生成
            vs_list = [shot_info['vs1'].values[0], shot_info['vs2'].values[0], shot_info['vs3'].values[0]]
            cp_list = [shot_info['cp1'].values[0], shot_info['cp2'].values[0], shot_info['cp3'].values[0]]

            for index in range(len(pos_list)):
                cpvs_index = int(index/2)
                # 右側のCP座標:logical_position_x - vs/2
                # 左側のCP座標:logical_position_x + vs/2
                if index % 2 == 0:
                    x = x_pos - vs_list[cpvs_index] / 2
                else:
                    x = x_pos + vs_list[cpvs_index] / 2

                y = y_pos + cp_list[cpvs_index]

                base[pos_list[index]] = {"x": x * app_config.NM_TO_MM, "y": y * app_config.NM_TO_MM}

                measurement[pos_list[index]] = {"x": shot_info[dx_list[index]].values[0] * app_config.NM_TO_MM,
                                                "y": shot_info[dy_list[index]].values[0] * app_config.NM_TO_MM}
            return base, measurement

        except Exception as e:
            logger.error('failed to shot_pos_calc')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def mean_deviation(self, log_data, selected_plate_list):
        """
        選択されたPlateの各Shot別計測値び平均を算出して、log各計測値の平均差分を演算する。
        param log_data : logデータ[Pandas Dataframe]
        param selected_plate_list : 選択されたPlateのList[List]
        return log_data : 平均差分演算値が適用されたLogデータ
        """

        try:
            measurement_list = ["p1_xl", "p1_yl", "p1_xr", "p1_yr", "p2_xl", "p2_yl",
                         "p2_yr", "p2_xr", "p3_xl", "p3_yl", "p3_xr", "p3_yr"]
            temp_data = log_data[log_data['plate'].isin(selected_plate_list)].get((["step"] + measurement_list))
            average_data = temp_data.groupby(['step']).mean().reset_index(drop=True)
            data = log_data.get(['plate', 'step'] + measurement_list)
            result_list = pd.DataFrame()
            grp_list = data.groupby('plate')
            for index, grp in grp_list:
                average_data = average_data.set_index(grp.index, drop=True)
                temp = grp.sub(average_data, axis=1, fill_value=0)
                result_list = pd.concat([result_list, temp])
            result_list.drop(columns=['plate', 'step'], inplace=True)
            log_data.drop(columns=measurement_list, inplace=True)
            log_data = pd.concat([log_data, result_list], axis=1)
            return log_data

        except Exception as e:
            logger.error('failed to mean_deviation')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def calc_plate_component(self, df):
        """
        Plate倍率/回転成分を求める
        Plate成分を除去した各点計測値を求める

        return_value[<GlassID>]['plate']
        -> [Sx, Sy, m, Θ] を取得できます。
        return_value[<GlassID>]['meas'][<shot_index(0->)]
        -> 'IMes1XR' ～ 'IMes3YL' を Key に Plate 成分を除去した値を取得できます。

        :param dataframe df: ログデータ
        :return: ロットの結果
        """
        plate_component = dict()
        for glassid in df['glass_id'].unique():
            try:
                plate_data = {shot_no: df[(df.glass_id == glassid) & (df.step == shot_no)]
                              for shot_no in df['step']}
            except:
                print('Skip:_calc_plate_component():GlassID={0} is illegal steps.'.format(glassid))
                continue
            # print('[_calc_plate_component] plate data', plate_data)

            model_list = list()
            for shot_no in df['step'].unique():
                for meas_index in range(3):
                    for rl_index in range(2):
                        # c_x, c_y は [mm] なので [um] に変換して計算する
                        c_x, c_y = self._calc_meas_pos(plate_data, shot_no, meas_index, rl_index)
                        model_list.append([1, 0, c_x * 1.0e3, -c_y * 1.0e3,
                                           self._get_shot_value(plate_data,
                                                                shot_no,
                                                                self.meas_x_rl_ivalue[meas_index][rl_index])])
                        model_list.append([0, 1, c_y * 1.0e3, c_x * 1.0e3,
                                           self._get_shot_value(plate_data,
                                                                shot_no,
                                                                self.meas_y_rl_ivalue[meas_index][rl_index])])

            model = pd.DataFrame(model_list,
                                 columns=['a', 'b', 'c', 'd', 'meas'])

            # 正規方程式を解く
            # - m_a: 行列A, m_d: 計測値
            model = model.reset_index(drop=True)
            m_a = model[['a', 'b', 'c', 'd']]
            m_d = model[['meas']]
            ata = m_a.T.dot(m_a)
            inv_ata = np.linalg.inv(ata)
            inv_ata_at = inv_ata.dot(m_a.T)
            result = inv_ata_at.dot(m_d)

            # Plate倍率/回転成分登録
            # - 結果は Sx(Shift X):result[0][0],,
            #         Sy(Shift Y):result[1][0],
            #         m(Mag):result[2][0] * self.plate_mag_coef,
            #         Θ(Rot):result[3][0] * self.plate_rot_coef の順
            plate_component[glassid] = {'mag': result[2][0] * self.plate_mag_coef,
                                        'rot': result[3][0] * self.plate_rot_coef}

            # print('[_calc_plate_component] plate_component[', glassid, ']', plate_component[glassid])

        return plate_component

    def _calc_meas_pos(self, plate_data, shot_no, meas_index, rl_index):
        """
        Shot1P2位置からの計測相対位置算出 [mm]

        :param plate_data:
        :param int shot_no: ショット番号(1-)
        :param int meas_index: 計測位置 0:P1, 1:P2, 2:P3
        :param int rl_index: 左右位置 0:R, 1:L
        :rtype: (float, float)
        :return: 算出相対座標[mm]
        """

        logical_x1 = self._get_shot_value(plate_data, 1, 'logicalposition_x')
        logical_y1 = self._get_shot_value(plate_data, 1, 'logicalposition_y')
        logical_x = self._get_shot_value(plate_data, shot_no, 'logicalposition_x')
        logical_y = self._get_shot_value(plate_data, shot_no, 'logicalposition_y')
        vs_pos = self._get_shot_value(plate_data, shot_no, self.vs_ivalue)
        cp_list = self._get_shot_value(plate_data, shot_no, self.cp_ivalue)
        if rl_index == 0:
            # R
            x = (logical_x + vs_pos[meas_index] / 2.0) - logical_x1
        else:
            # L
            x = (logical_x - vs_pos[meas_index] / 2.0) - logical_x1
        y = (logical_y + cp_list[meas_index] - cp_list[1]) - logical_y1
        # print('x :',x)
        # print('Y :',y)
        return x, y

    def _get_shot_value(self, plate_data, shot_no, ivalue):
        """
        plate_data から shot_no の ivalue 値を取り出す

        :param plate_data:
        :param shot_no:
        :param ivalue:
        :return:
        """
        return plate_data[shot_no][ivalue].values[0]

    def calc_base_position(self, df_data):

        io_list = ['plate', 'step', 'logicalposition_x', 'logicalposition_y', 'cp1', 'cp2', 'cp3', 'vs1', 'vs2', 'vs3']
        io_data = df_data[io_list]
        for idx in io_data.index:
            # 一つのショットごとに持って来て計算
            ishot = io_data.loc[idx]
            logipos_x = ishot['logicalposition_x']
            logipos_y = ishot['logicalposition_y']
            io_data.loc[io_data.index == idx, 'bs_p1xr'] = logipos_x - (ishot['vs1'] / 2)
            io_data.loc[io_data.index == idx, 'bs_p1yr'] = logipos_y + ishot['cp1']
            io_data.loc[io_data.index == idx, 'bs_p1xl'] = logipos_x + (ishot['vs1'] / 2)
            io_data.loc[io_data.index == idx, 'bs_p1yl'] = logipos_y + ishot['cp1']
            io_data.loc[io_data.index == idx, 'bs_p2xr'] = logipos_x - (ishot['vs2'] / 2)
            io_data.loc[io_data.index == idx, 'bs_p2yr'] = logipos_y + ishot['cp2']
            io_data.loc[io_data.index == idx, 'bs_p2xl'] = logipos_x + (ishot['vs2'] / 2)
            io_data.loc[io_data.index == idx, 'bs_p2yl'] = logipos_y + ishot['cp2']
            io_data.loc[io_data.index == idx, 'bs_p3xr'] = logipos_x - (ishot['vs3'] / 2)
            io_data.loc[io_data.index == idx, 'bs_p3yr'] = logipos_y + ishot['cp3']
            io_data.loc[io_data.index == idx, 'bs_p3xl'] = logipos_x + (ishot['vs3'] / 2)
            io_data.loc[io_data.index == idx, 'bs_p3yl'] = logipos_y + ishot['cp3']

        return io_data

    def get_auto_xy_offset(self, df_data):

        # 結果データフレーム
        calc_df = pd.DataFrame()
        # 基本計測店位置を計算する。 (X1L, X1R, Y1L, Y1R...)
        df_data = self.calc_base_position(df_data)

        # 計算結果保存 Column 追加
        df_data['x'] = 0
        df_data['y'] = 0

        # 計測する考慮しないで CP 位置だけ利用して位置計算
        # 各プレートごとにショットあまり Offsetが計算されなければならない
        for i_plate in df_data.index:
            # 各プレート単位で DataFrame 取得
            target_plate = df_data[df_data['plate'] == i_plate]

            # Y軸基準で整列
            grp_df = target_plate.sort_values(by='logicalposition_y', ascending=True)

            # 以前行きと現在行義沈着を計算
            diff_v = grp_df['logicalposition_y'].diff()

            # グリッド一軒の大きさの 2倍(100mm)の沈着は皆 0で見做す。
            diff_v[(diff_v < app_config.GRP_THREASHOLD) | np.isnan(diff_v)] = 0
            grp_df['v_grp'] = diff_v.cumsum()  # 累積寄せ算。 (default = row )

            # グループの手順
            group = grp_df.groupby('v_grp')

            # 計算された p1,p2,p3中に最大値/最小値求め
            bound_max = group[['bs_p1yl', 'bs_p2yl', 'bs_p3yl']].apply(lambda x: np.nanmax(x.values))
            bound_min = group[['bs_p1yl', 'bs_p2yl', 'bs_p3yl']].apply(lambda x: np.nanmin(x.values))

            # DataFrameで変換
            bound_max = pd.DataFrame(bound_max)
            bound_min = pd.DataFrame(bound_min)

            # グループの個数を確認
            grp_list = grp_df['v_grp'].unique().tolist()
            grp_num = len(grp_list)

            # Y祝意オフセット計算
            for idy in range(grp_num - 1):
                if bound_min.loc[grp_list[idy + 1]].values[0] <= bound_max.loc[grp_list[idy]].values[0]:
                    diff = bound_min.loc[grp_list[idy + 1]].values[0] - bound_max.loc[grp_list[idy]].values[0]
                    diff = np.abs(diff)  # 自動計算オフセットは次の shotでから落とすから増加しならなければならない。

                    # 二番目グループのすべての Y軸にオ
                    target_grp_val = grp_list[idy + 1]
                    grp_df.loc[grp_df['v_grp'] == target_grp_val, 'y'] = diff

            # X祝意オフセット計算(グループ別)
            for idx in range(grp_num):
                target_grp_val = grp_list[idx]
                # グループ内で X軸方向に昇順整列
                grp_shot_list = grp_df[grp_df['v_grp'] == target_grp_val].sort_values(by=['logicalposition_x'],
                                                                                      ascending=True)
                step_list = grp_shot_list['step'].tolist()

                for sid in range(len(step_list) - 1):
                    # shotの x位置の中で xrの最大値、xlの最小値を X祝意基準にする。
                    next_xr_min = grp_shot_list[grp_shot_list['step'] == step_list[sid + 1]][[
                        'bs_p1xr', 'bs_p2xr', 'bs_p3xr']].min(axis=1)
                    curr_xl_max = grp_shot_list[grp_shot_list['step'] == step_list[sid]][[
                        'bs_p1xl', 'bs_p2xl', 'bs_p3xl']].max(axis=1)
                    if next_xr_min.values[0] <= curr_xl_max.values[0]:
                        diff = next_xr_min.values[0] - curr_xl_max.values[0]
                        diff = np.abs(diff)
                        grp_df.loc[(grp_df['v_grp'] == target_grp_val) & (grp_df['step'] == step_list[sid + 1]),
                                   'x'] = diff
                    else:
                        pass
            # 各 Plateあまり取得した offset データを結合。
            calc_df = pd.concat([calc_df, grp_df.sort_index()])

        # オフセットデータで最大値を取得して代表オフセットで設定
        offset_table = calc_df.groupby(by='step')['x', 'y'].max().fillna(0)
        calc_data = {"offset": offset_table.to_dict('index')}

        return calc_data

    def create_reproducibility_data(self, df_data):

        pos_x_list = ['p1_xl', 'p1_xr', 'p2_xl', 'p2_xr', 'p3_xl', 'p3_xr']
        pos_y_list = ['p1_yl', 'p1_yr', 'p2_yl', 'p2_yr', 'p3_yl', 'p3_yr']
        filterlist = ['plate', 'step'] + pos_y_list + pos_x_list

        # 必要な Columnsデータだけ持って来る。
        target_data = df_data[filterlist]
        shot_list = target_data['step'].unique().tolist()
        np.sort(shot_list)  # 昇順で整列

        # 各シャッビョルでグループ化して演算準備
        grped_shot = target_data.groupby(by='step')

        # 標準偏差計算 -> 3σ値段計算
        std_deviation = grped_shot.std() * 3
        # 小数点 3桁まで取得
        std_deviation = np.round(std_deviation, 3)

        label_list = []
        x_dataset_list = []
        y_dataset_list = []

        # 軸ラベル文字列作成
        for sn in shot_list:
            label_list.append(f'S{sn}P1(L)')
            label_list.append(f'S{sn}P1(R)')
            label_list.append(f'S{sn}P2(L)')
            label_list.append(f'S{sn}P2(R)')
            label_list.append(f'S{sn}P3(L)')
            label_list.append(f'S{sn}P3(R)')

            x_dataset_list += std_deviation.loc[sn, pos_x_list].tolist()
            y_dataset_list += std_deviation.loc[sn, pos_y_list].tolist()

        # 結果を保存する DataFrame 生成
        calc_data = pd.DataFrame(None, columns=label_list, index=['x', 'y'])
        calc_data.loc['x'] = x_dataset_list
        calc_data.loc['y'] = y_dataset_list
        res_data = calc_data.to_dict('index')

        return res_data

    def get_calc_anova_table(self, df_data):
        df_src = df_data.copy(deep=True)

        # 1プレートあたりのショット数を調べる
        shot_num = int(df_src['step'].max())
        # ログ内のプレート数を調べる
        # 複数ロット含まれる可能性があるのでPlate番号が連番になるよう振り直す。
        plate_num = 0
        ishot_list = df_src['step'].tolist()
        iplate_dst_list = list()
        for ishot in ishot_list:
            if ishot == 1:
                plate_num += 1
            iplate_dst_list.append(plate_num)
        df_src['plate'] = iplate_dst_list

        #fixme - Shot_position 가져와야 함. (shot_position_lit : 198line )

        pos_x_list = ['p1_xl', 'p1_xr', 'p2_xl', 'p2_xr', 'p3_xl', 'p3_xr']
        pos_y_list = ['p1_yl', 'p1_yr', 'p2_yl', 'p2_yr', 'p3_yl', 'p3_yr']
        filterlist = ['plate', 'step'] + pos_y_list + pos_x_list

        # DataFrameをDict化
        dict_src = df_src[
            ['plate', 'step',
             'p1_xl', 'p1_xr', 'p1_yl', 'p1_yr',
             'p2_xl', 'p2_xr', 'p2_yl', 'p2_yr',
             'p3_xl', 'p3_xr', 'p3_yl', 'p3_yr']
        ].set_index(['plate', 'step'], drop=True)

        # dict_src = dict_src.to_dict('')
        dst_list = list()

        self.calc_base_position(df_data)










        # デフォルト値
        default_val = {
            # VS幅[mm]
            'vs': 750.0,
            # スリット円弧半径[mm]
            'radius': 455.0
        }

        # Matrix基本列名
        base_col = {
            'x': ['X', 'DR_Upper', 'DR_Lower', 'MX', 'MX_Upper', 'MX_Lower'],
            'y': ['Y', 'MY_Upper', 'MY_Lower', 'T', 'Yaw_Upper', 'Yaw_Lower']
        }

        # 統計データ算出用データフレーム
        stat_df = pd.DataFrame(
            columns=['plate', 'shot', 'Ox', 'Oy', 'x', 'yd', 'y', 'dx', 'dy'])

        # 前処理、Feedbackデータから統計データ計算用データフレーム作成
        # Ox, Oy : [mm], dx, dy : [um]

    def ae_correction(self, log_data, mode, display_settings):
        """
        LogデータのShit/Rotate/Mag成分を求めて、Logデータの計測値で適用
        :param log_data: logデータ[Pandas Dataframe]
        :param mode: ae補正モード[０：Shift/Rotate Correction(mode 0), 1: Shift/Rotate/Mag Correction(mode 1)]
        :param display_settings: Shot別のDisplay設定　[list]
        　　　　　　　　　　　　　　　# 0 = P1&P2&P3 = [0, 1, 2]
                                # 1 = P1&P2 = [0, 1]
                                # 2 = P2&P3 = [1, 2]
                                # 3 = P2ONLY = [1]
                                # 4 = Non = []
        :return: log_data: ae補正を適用された data
        """
        # Display設定別
        display_settings_conv = {0: [0, 1, 2], 1: [0, 1], 2: [1, 2], 3: [1], 4: []}
        # logデータ中計測値のColumn名
        measurement_list = [["p1_xr", "p1_yr", "p1_xl", "p1_yl"], ["p2_yr", "p2_xr", "p2_xl", "p2_yl"],
                            ["p3_xr", "p3_yr", "p3_xl", "p3_yl"]]
        # default CP/VS
        default_cp_vs = [[-520000, 0, 520000], [750000, 750000, 750000]]

        try:
            # ae補正値を保存するためのDataFrameを生成
            ae_df = pd.DataFrame(columns=measurement_list[0] + measurement_list[1] + measurement_list[2])
            lotid_df = pd.DataFrame(columns=measurement_list[0] + measurement_list[1] + measurement_list[2])
            plate_df = pd.DataFrame(columns=measurement_list[0] + measurement_list[1] + measurement_list[2])

            # 　lotidのリストを抽出
            lotid_list = log_data['lot_id'].unique()

            for lot_index in lotid_list:
                # 対象lotidのデータを抽出
                lotid_data = log_data[log_data['lot_id'] == lot_index]
                # Plateリストを抽出
                plate_list = lotid_data['plate'].unique()

                for plate_index in plate_list:
                    # 対象Plateのデータを抽出
                    plate_data = lotid_data[lotid_data['plate'] == plate_index]
                    # Shotリストを抽出
                    shot_list = plate_data['step'].unique()
                    # MatrixAとMatrixを生成用List定義
                    matrix_a_list = []
                    matrix_d_list = []

                    for shot_index in shot_list:
                        # 対象Shotのデータを抽出
                        shot_data = plate_data[plate_data['step'] == shot_index]
                        # LogがらLogical Positionを抽出
                        pos_x = shot_data["logicalposition_x"].values[0]
                        pos_y = shot_data["logicalposition_y"].values[0]
                        # Display Settingからae補正対象を選ぶ為のIndex
                        shot_display_settings = display_settings_conv[display_settings[shot_index - 1]]

                        for display_index in shot_display_settings:
                            # ae補正モードが[mode0]時のMatrixA生成用データ処理
                            if mode == 0:
                                vs_data = [shot_data['vs1'].values[0], shot_data['vs2'].values[0],
                                           shot_data['vs3'].values[0]]
                                cp_data = [shot_data['cp1'].values[0], shot_data['cp2'].values[0],
                                           shot_data['cp3'].values[0]]
                                matrix_a_list.append([1, 0, -(pos_y + cp_data[display_index])])
                                matrix_a_list.append([0, 1, pos_x + vs_data[display_index] / 2])
                                matrix_a_list.append([1, 0, -(pos_y + cp_data[display_index])])
                                matrix_a_list.append([0, 1, pos_x - vs_data[display_index] / 2])
                            # ae補正モードが[mode1]時のMatrixA生成用データ処理
                            else:
                                cp_data = default_cp_vs[0]
                                vs_data = default_cp_vs[1]
                                matrix_a_list.append(
                                    [1, 0, pos_x + vs_data[display_index] / 2, - (pos_y + cp_data[display_index])])
                                matrix_a_list.append(
                                    [0, 1, pos_y + cp_data[display_index], pos_x + vs_data[display_index] / 2])
                                matrix_a_list.append(
                                    [1, 0, pos_x - vs_data[display_index] / 2, - (pos_y + cp_data[display_index])])
                                matrix_a_list.append(
                                    [0, 1, pos_y + cp_data[display_index], pos_x - vs_data[display_index] / 2])

                            # MatrixD生成用データ処理
                            measurement_data_temp = shot_data.get(measurement_list[display_index])
                            matrix_d_list.append(measurement_data_temp[measurement_list[display_index][0]].values[0])
                            matrix_d_list.append(measurement_data_temp[measurement_list[display_index][1]].values[0])
                            matrix_d_list.append(measurement_data_temp[measurement_list[display_index][2]].values[0])
                            matrix_d_list.append(measurement_data_temp[measurement_list[display_index][3]].values[0])

                    # Matrix_A生成
                    matrix_a = np.array(matrix_a_list)
                    # Matrix_D生成
                    matrix_d = np.array(matrix_d_list)
                    # Matrix_Aのrowとcolumnを置換してMatrixATを生成
                    matrix_at = np.transpose(matrix_a)
                    # MatrixAとMatrixATを演算してMatrixAT_Aを生成
                    matrix_at_a = np.matmul(matrix_at, matrix_a)
                    # MatrixAT_Aの逆MatrixのMatrixAT_A_Inverseを生成
                    matrix_at_a_inverse = np.linalg.inv(matrix_at_a)
                    # MatrixAT_A_InverseとMatrixATを演算してMatrixAT_A_Inverse_ATを生成
                    matrix_at_a_inverse_at = np.matmul(matrix_at_a_inverse, matrix_at)
                    # MatrixAT_A_Inverse_ATとMatrixDを演算してMatrixB_HATを生成
                    matrix_b_hat = np.matmul(matrix_at_a_inverse_at, matrix_d)
                    # MatrixAT_AとMatrixAT_B_HATを演算してMatrixAB_HATを生成
                    matrix_ab_hat = np.matmul(matrix_a, matrix_b_hat)
                    # MatrixDとMatrixAB_HATを演算してMatrixAT_D_HATを生成
                    matrix_d_hat = np.subtract(matrix_d, matrix_ab_hat)

                    # MatrixDのデータをLogの計測値で置換するため、MartrixをDisplaySettingに従ってデータを割る
                    slice_start_pos = 0
                    plate_ae_data = []
                    for replace_index in shot_list:
                        # DisPlaySettingがP1＆P2＆P3の時、計測値のデータ数が12なので、データをListで追加する
                        if display_settings[replace_index - 1] == 0:
                            temp_matrix = matrix_d_hat[slice_start_pos:slice_start_pos + 12]
                            plate_ae_data.append(temp_matrix)
                            slice_start_pos = slice_start_pos + 12
                        # DisPlaySettingがP1＆P2の時、計測値のデータ数が8なので、足りないデータはLogの計測値を使用
                        elif display_settings[replace_index - 1] == 1:
                            temp_matrix = matrix_d_hat[slice_start_pos:slice_start_pos + 8]
                            data = (plate_data[plate_data['step'] == replace_index].get(measurement_list[2])).to_numpy()
                            com_matrix = np.append(temp_matrix, data)
                            plate_ae_data.append(com_matrix)
                            slice_start_pos = slice_start_pos + 8
                        # DisPlaySettingP2＆P3の時、計測値のデータ数が8なので、足りないデータはLogの計測値を使用
                        elif display_settings[replace_index - 1] == 2:
                            temp_matrix = matrix_d_hat[slice_start_pos:slice_start_pos + 8]
                            data = (plate_data[plate_data['step'] == replace_index].get(measurement_list[0])).to_numpy()
                            com_matrix = np.append(data, temp_matrix, )
                            plate_ae_data.append(com_matrix)
                            slice_start_pos = slice_start_pos + 8
                        # DisPlaySettingがP2Onlyの時、計測値のデータ数が8なので、足りないデータはLogの計測値を使用
                        elif display_settings[replace_index - 1] == 3:
                            temp_matrix = matrix_d_hat[slice_start_pos:slice_start_pos + 4]
                            front_data = (
                                plate_data[plate_data['step'] == replace_index].get(measurement_list[0])).to_numpy()
                            end_data = (
                                plate_data[plate_data['step'] == replace_index].get(measurement_list[0])).to_numpy()
                            com_matrix = np.append(front_data, temp_matrix, end_data)
                            plate_ae_data.append(com_matrix)
                            slice_start_pos = slice_start_pos + 4
                        else:
                            return -1
                    # ae補正データを使用してDataFrameを生成
                    plate_ae_result = pd.DataFrame(plate_ae_data,
                                                   columns=measurement_list[0] + measurement_list[1] + measurement_list[
                                                       2])
                    # DataFrameを既存のデータで追加
                    plate_df = pd.concat([plate_df, plate_ae_result])
                # DataFrameを既存のデータで追加
                lotid_df = pd.concat([lotid_df, plate_df])
            # DataFrameを既存のデータで追加
            ae_df = pd.concat([ae_df, lotid_df])
            # Logデータと統合前にindexデータを初期化する
            ae_df = ae_df.reset_index(drop=True)
            # Logデータの計測値ColumnをDrop
            log_data.drop(columns=measurement_list[0] + measurement_list[1] + measurement_list[2], inplace=True)
            # Logデータとae補正データを統合
            log_data = pd.concat([log_data, ae_df], axis=1)

            return log_data

        except Exception as e:
            logger.error('failed to ae_correction')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))







