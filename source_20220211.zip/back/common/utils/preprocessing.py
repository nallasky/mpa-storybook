import os
import pandas.tseries.offsets as t_offsets
import datetime
import pandas as pd
from config.app_config import *


def creanup_log_list_by_job(log_df):
    """
    Job単位に仕分けたログファイルから不要なデータを取り除く

    - 同一PlateのStep情報に重複がある場合、後に登場したものを残し、それ以外を削除
    - 先頭PlateのStep情報がそのJobのステップ数に満たなければ捨てる

    :param dataframe log_df: 操作対象(直接書き換えます)
    :return:
    """
    if len(log_df) == 0:
        return

    drop_list = []
    last_glass_id = ''
    got_shot_no = []
    for index in reversed(range(log_df.shape[0])):
        glass_id = log_df.iloc[index]['glass_id']
        shot_no = log_df.iloc[index]['step_no']
        if last_glass_id != glass_id:
            got_shot_no.clear()
            last_glass_id = glass_id
        if shot_no in got_shot_no:
            # 重複を登録
            drop_list.append(index)
        else:
            got_shot_no.append(shot_no)

    if len(drop_list) != 0:
        # 行を削除
        log_df.drop(drop_list, errors='ignore', inplace=True)
        log_df.reset_index(drop=True, inplace=True)


def creanup_log_list_by_term(log_df, valid_interval_minutes):
    """
    時間順に並ぶログから不要なデータを取り除く

    :param pd.DataFrame log_df: 時間順に並んだログデータ
    :param valid_interval_minutes:
    :return:
    """
    if valid_interval_minutes is None:
        return log_df

    valid_interval_minutes = int(valid_interval_minutes)

    # やることは無いのでそのまま返す
    if valid_interval_minutes <= 0:
        return log_df

    # 次ログから valid_interval_minutes 以上離れたデータだけ抽出する
    interval_minutes = t_offsets.DateOffset(minutes=valid_interval_minutes)
    log_df = log_df[(log_df['log_time'] + interval_minutes) <= log_df['log_time'].shift(-1)].reset_index(drop=True)
    return log_df


def get_divided_list(all_df, one_period, start_period_datetime, last_log_datetime, list_group):
    one_period_unit = one_period[-1]
    one_period_val = int(one_period[0:-1])

    list_by_period = []
    period_len = t_offsets.DateOffset(months=one_period_val if one_period_unit == 'm' else 0,
                                      days=one_period_val if one_period_unit == 'd' else 0,
                                      hours=one_period_val if one_period_unit == 'h' else 0)
    period_st = start_period_datetime
    period_ed = period_st + period_len
    while period_st <= last_log_datetime:
        cur_period_dict = {}
        cur_df = all_df[(period_st <= all_df['log_time']) & (all_df['log_time'] < period_ed)]
        if len(cur_df) > 0:
            cur_period_dict['start'] = period_st
            cur_period_dict['end'] = period_ed - t_offsets.DateOffset(seconds=1)

            if list_group == 'job':
                cur_period_job_list = []
                for name, group_df in cur_df.groupby(['device', 'process']):
                    job_name = name[0] + '/' + name[1]
                    cur_period_job_list.append(job_name)

                cur_period_dict['job_list'] = cur_period_job_list

            list_by_period.append(cur_period_dict)

        period_st = period_ed
        period_ed = period_st + period_len

    return list_by_period


def divide_by_stats_period(log_df, start, stats_period):
    if stats_period is None:
        return log_df

    stats_period_unit = stats_period[-1].lower()
    stats_period_val = int(stats_period[0:-1])

    start = datetime.datetime.strptime(start, '%Y-%m-%d %H:%M:%S')
    log_df['period'] = start

    if stats_period_val <= 0:
        return log_df

    if stats_period_unit not in ['m', 'd', 'h']:
        return log_df

    interval_period = t_offsets.DateOffset(months=stats_period_val if stats_period_unit == 'm' else 0,
                                      days=stats_period_val if stats_period_unit == 'd' else 0,
                                      hours=stats_period_val if stats_period_unit == 'h' else 0)

    # 最終データのタイムスタンプ
    # last_log_time = log_df.iloc[log_df.shape[0] - 1]['log_time']
    last_log_time = log_df['log_time'].max()

    # 順繰りに仕分けして行く
    st = start
    ed = st + interval_period
    while st <= last_log_time:
        log_df.loc[
            (st <= log_df.log_time) &
            (log_df.log_time < ed),
            'period'] = st
        st = ed
        ed = st + interval_period

    return log_df


def load_data(rid, **filters):
    root_dir = os.path.join(CNV_RESULT_PATH, rid)
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False)
        dfs.append(df)

    df = pd.concat(dfs)

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == val]

    for col in COLUMN_OMIT_LIST:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    if len(df) > 0 and 'log_time' in df.columns:
        # 時間順序で整列
        df.sort_values(by='log_time', ascending=True, inplace=True)
        df.reset_index(inplace=True, drop=True)

    return df


def add_column_adc_meas(rid):
    root_dir = os.path.join(CNV_RESULT_PATH, rid)
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()

    # AdcMeasurementの疑似LotID用の変数
    pseudo_lot_cnt = 0

    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False, dtype=str)
        df['pseudo_lot_id'] = False

        before_plate = -1
        ascflg = False
        descflg = False

        for i in range(len(df)):
            # 空白を除去した上でLotIDを取得
            lot_id = df['lot_id'].values[i].strip()

            # LotIDが空か？
            if len(lot_id) == 0:
                dummy_lot_id = df['dummy_lot_id'].values[i].strip()
                # DummyLotIDが空か？
                if len(dummy_lot_id) == 0:
                    # Plate取得
                    plate = int(df['plate'].values[i])
                    # 初回の計測か？
                    if before_plate == -1:
                        before_plate = plate
                    # plateの値が前回と同じ場合は処理無し
                    elif before_plate == plate:
                        pass
                    # Plateの数値が前回より大きい（昇順に並んでいた場合）
                    elif before_plate < plate and not descflg:
                        before_plate = plate
                        ascflg = True
                    # Plateの数が前回より小さい（降順に並んでいた場合）
                    elif before_plate > plate and not ascflg:
                        before_plate = plate
                        descflg = True

                    if ascflg:
                        # 取得したplateの数が小さくなった場合
                        if before_plate > plate:
                            # 疑似LotIDのナンバリングを更新
                            pseudo_lot_cnt += 1
                            ascflg = False
                            before_plate = plate
                    if descflg:
                        # 取得したplateの数が大きくなった場合
                        if before_plate < plate:
                            # 疑似LotIDのナンバリングを更新
                            pseudo_lot_cnt += 1
                            descflg = False
                            before_plate = plate

                    # 疑似Lotフラグを設定
                    df.at[i, 'pseudo_lot_id'] = True
                    # 疑似LotIDを設定（LOTID_日付_ナンバリング）
                    df.at[i, 'lot_id'] = 'LOTID_' + \
                                           str(datetime.date.today()) + \
                                           '_' + str(pseudo_lot_cnt)
                else:
                    # DummyLotIDを設定
                    df.at[i, 'lot_id'] = dummy_lot_id
                    df.at[i, 'pseudo_lot_id'] = True


        df['job'] = df['device'] + '/' + df['process']
        df.to_csv(path, header=True, index=False)
        dfs.append(df)
        pseudo_lot_cnt += 1

    df = pd.concat(dfs)

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    if len(df) > 0 and 'log_time' in df.columns:
        # 時間順序で整列
        df.sort_values(by='log_time', ascending=True, inplace=True)
        df.reset_index(inplace=True, drop=True)

    return df


def load_adc_meas(rid, **filters):
    root_dir = os.path.join(CNV_RESULT_PATH, rid)
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False, dtype=str)
        dfs.append(df)

    df = pd.concat(dfs)

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == val]

    for col in COLUMN_OMIT_LIST:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    if len(df) > 0 and 'log_time' in df.columns:
        # 時間順序で整列
        df.sort_values(by='log_time', ascending=True, inplace=True)
        df.reset_index(inplace=True, drop=True)

    return df


def get_data_period(df):
    if 'log_time' in df.columns:
        period = dict()
        period['start'] = df['log_time'].min()
        period['end'] = df['log_time'].max()
        return period
    else:
        return None


def make_dummy_data(column_type_dict):
    data = dict()
    for key, val in column_type_dict.items():
        if val is int:
            data[key] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        elif val is float:
            data[key] = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]
        elif val is str:
            data[key] = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        elif val is datetime:
            data[key] = ['2021-01-01', '2021-02-01', '2021-03-01', '2021-04-01', '2021-05-01',
                         '2021-06-01', '2021-07-01', '2021-08-01', '2021-09-01', '2021-10-01']
        elif val is bool:
            data[key] = [True, False, True, False, True, False, True, False, True, False]
        else:
            data[key] = ['', '', '', '', '', '', '', '', '', '']

    return pd.DataFrame(data)
