import React from 'react';
import { Provider } from 'react-redux';
import { configureStore, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { TaskBoxType, TaskType } from "../../../lib/task";
import TaskList from "./TaskList";
import * as TaskStories from '../Task/Task.stories';

export const MockedState = {
  tasks: [
    { state: TaskStories.Default.args?.task?.state || 'TASK_INBOX', id: '1', title: 'Task 1' },
    { state: TaskStories.Default.args?.task?.state || 'TASK_INBOX', id: '2', title: 'Task 2' },
    { state: TaskStories.Default.args?.task?.state || 'TASK_INBOX', id: '3', title: 'Task 3' },
    { state: TaskStories.Default.args?.task?.state || 'TASK_INBOX', id: '4', title: 'Task 4' },
    { state: TaskStories.Default.args?.task?.state || 'TASK_INBOX', id: '5', title: 'Task 5' },
    { state: TaskStories.Default.args?.task?.state || 'TASK_INBOX', id: '6', title: 'Task 6' },
  ],
  status: 'idle',
  error: null
}

interface MockStoreProps {
  taskboxState: TaskBoxType,
  children: React.ReactNode,
}

const Mockstore: React.FC<MockStoreProps> = ({ taskboxState, children }) => (
  <Provider
    store={configureStore({
      reducer: {
        taskbox: createSlice({
          name: 'taskbox',
          initialState: taskboxState,
          reducers: {
            updateTaskState: (state, action: PayloadAction<TaskType>) => {
              const { id, state: newTaskState } = action.payload
              const task = state.tasks.findIndex(({ id: index }) => index === id)
              if (task >= 0) {
                state.tasks[task].state = newTaskState
              }
            }
          },
        }).reducer,
      },
    })}
  >
    {children}
  </Provider>
)

export default {
  component: TaskList,
  title: 'TaskList',
  decorators: [(story: () => React.ReactNode) => <div>{story()}</div>],
  excludeStories: /.*MockedState$/,
}

const Template = () => <TaskList />

export const Default = Template.bind({})
// @ts-ignore
Default.decorators = [
  (story: () => React.ReactNode) => <Mockstore taskboxState={MockedState}>{story()}</Mockstore>,
]

export const WithPinnedTasks = Template.bind({})
// @ts-ignore
WithPinnedTasks.decorators = [
  (story: () => React.ReactNode) => {
    const pinnedtasks = [
      ...MockedState.tasks.slice(0, 5),
      { id: '6', title: 'Task 6 (pinned)', state: 'TASK_PINNED' },
    ]
    return (
      <Mockstore
        taskboxState={{
          ...MockedState,
          tasks: pinnedtasks,
        }}
      >
        {story()}
      </Mockstore>
    )
  },
];

export const Loading = Template.bind({})
// @ts-ignore
Loading.decorators = [
  (story: () => React.ReactNode) => (
    <Mockstore
      taskboxState={{
        ...MockedState,
        status: 'loading',
      }}
    >
      {story()}
    </Mockstore>
  ),
];

export const Empty = Template.bind({})
// @ts-ignore
Empty.decorators = [
  (story: () => React.ReactNode) => (
    <Mockstore
      taskboxState={{
        ...MockedState,
        tasks: [],
      }}
    >
      {story()}
    </Mockstore>
  ),
];
