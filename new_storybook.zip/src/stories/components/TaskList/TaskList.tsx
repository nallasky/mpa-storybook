import React from 'react';
import { useSelector } from "react-redux";
import styled from "styled-components";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck } from '@fortawesome/free-solid-svg-icons';
import Task from "../Task/Task";
import { updateTaskState } from '../../../lib/task';
import { ReducerType } from '../../../lib/rootReducer';
import { useAppDispatch } from "../../../lib/store";

const LoadingItem = styled.div`
  @keyframes blink {
    0% {
      opacity: 0.3;
    }
    50% {
      opacity: 1;
    }
    100% {
      opacity: 0.3;
    }
  }
  display: flex;
  width: 100%;
  color: transparent;
  padding: 0.5rem;
  background-color: white;
  column-gap: 1rem;
  & + div {
    border-top: 1px solid #efefef;
  }
  & span {
    background-color: #dadada;
  }
  & > .glow-checkbox {
    width: 22px;
    animation: blink 2s ease-in-out infinite;
  }
  & > .glow-text {
    display: flex;
    column-gap: 0.25rem;
    background-color: white;
    animation: blink 2s ease-in-out infinite;
  }
`;

const EmptyWrapper = styled.div`
  width: 100%;
  height: 500px;
  background-color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  & > div {
    text-align: center;
    & > svg {
      color: #26c6da;
    }
    & > .bold {
      font-weight: bold;
      font-size: 20px;
    }
    & > div {
      font-size: 16px;
    }
  }
`

const TaskList: React.FC = () => {
  const tasks = useSelector((state: ReducerType) => {
    const tasksInOrder = [
      ...state.taskbox.tasks.filter((t) => t.state === 'TASK_PINNED'),
      ...state.taskbox.tasks.filter((t) => t.state !== 'TASK_PINNED'),
    ]
    return tasksInOrder.filter((t) => t.state === 'TASK_INBOX' || t.state === 'TASK_PINNED')
  })
  const { status } = useSelector((state: ReducerType) => state.taskbox)
  const dispatch = useAppDispatch();

  const pinTask = (v: string) => {
    const isPinned = tasks.find(({ id }) =>  id === v)?.state === 'TASK_PINNED';
    dispatch(updateTaskState({ id: v, state: isPinned ? 'TASK_INBOX' : 'TASK_PINNED'}))
  }
  const archiveTask = (v: string) => {
    dispatch(updateTaskState({ id: v, state: 'TASK_ARCHIVED'}))
  }

  const LoadingRow = (
    <LoadingItem>
      <span className="glow-checkbox" />
      <span className="glow-text">
        <span>loading</span> <span>cool</span> <span>state</span>
      </span>
    </LoadingItem>
  )

  console.log('gtpark status', status);

  if (status === 'loading') {
    return (
      <div data-testid="loading">
        {LoadingRow}
        {LoadingRow}
        {LoadingRow}
        {LoadingRow}
        {LoadingRow}
        {LoadingRow}
      </div>
    )
  }

  if (!tasks.length) {
    return (
     <EmptyWrapper>
       <div>
         <FontAwesomeIcon icon={faCheck} size="6x" />
         <div className="bold">You have no tasks.</div>
         <div>Sit back and relax.</div>
       </div>
     </EmptyWrapper>
    )
  }

  return (
    <div>
      {tasks.map((task) => (
        <Task
          key={task.id}
          task={task}
          onPinTask={(t) => pinTask(t)}
          onArchiveTask={(t) => archiveTask(t)}
        />
      ))}
    </div>
  )
}

export default TaskList