import React from 'react'
import { Provider } from 'react-redux'
import { rest } from 'msw'
import store from "../../../lib/store"
import InboxScreen from "./InboxScreen";
import { MockedState } from "../TaskList/TaskList.stories";
import { runInboxScreenErrorTest } from "./InboxScreenTest";

export default {
  component: InboxScreen,
  title: 'InboxScreen',
  decorators: [(story: () => React.ReactNode) => <Provider store={store}>{story()}</Provider>]
}

const Template = () => <InboxScreen />

export const Default = Template.bind({})
// @ts-ignore
Default.parameters = {
  msw: {
    handlers: [
      rest.get('https://jsonplaceholder.typicode.com/todos?userId=1', (_, res, ctx) => {
        return res(ctx.json(MockedState.tasks))
      })
    ]
  }
}

export const Error = Template.bind({})
// @ts-ignore
Error.parameters = {
  msw: {
    handlers: [
      rest.get('https://jsonplaceholder.typicode.com/todos?userId=1', (_, res, ctx) => {
        return res(ctx.status(403))
      })
    ]
  }
}
runInboxScreenErrorTest(Error);