import React, { useEffect } from 'react'
import { useSelector } from "react-redux";
import { fetchTasks } from "../../../lib/task";
import TaskList from "../TaskList/TaskList";
import { useAppDispatch } from "../../../lib/store";
import { ReducerType } from "../../../lib/rootReducer";

const InboxScreen: React.FC = () => {
  const dispatch = useAppDispatch()
  const { error } = useSelector((state: ReducerType) => state.taskbox)

  useEffect(() => {
    dispatch(fetchTasks())
  }, [])

  if (error) {
    return (
      <div>
        <div>
          <div>Oh no!</div>
          <div>Something went wrong</div>
        </div>
      </div>
    )
  }

  return (
    <div>
      <nav>
        <h1>Taskbox</h1>
      </nav>
      <TaskList />
    </div>
  )
}

export default InboxScreen