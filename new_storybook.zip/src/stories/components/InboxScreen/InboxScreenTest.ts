import InboxScreen from "./InboxScreen";
import { ComponentStory } from '@storybook/react';
import { expect } from "@storybook/jest";
import { within } from '@storybook/testing-library';

export const runInboxScreenErrorTest = (story: ComponentStory<typeof InboxScreen>): ComponentStory<typeof InboxScreen> => {
  story.play = async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const findText = canvas.findByText(/Something/i);
    expect(findText).toBeInTheDocument();
  }
  return story;
}

export const runInboxDefaultScreenErrorTest = (story: ComponentStory<typeof InboxScreen>): ComponentStory<typeof InboxScreen> => {
  story.play = async ({ canvasElement }) => {
    const canvas = within(canvasElement);
  };
  return story;
}