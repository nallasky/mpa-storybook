import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar, faCheck } from '@fortawesome/free-solid-svg-icons';
import styled from "styled-components";

export interface TaskProps {
  /** Task의 기본 정보 */
  task: {
    id: string,
    title: string | number,
    state: string,
  },
  /** Checkbox onClick 이벤트 핸들러 */
  onArchiveTask?: (id: string) => void,
  /** Pin onClick 이벤트 핸들러 */
  onPinTask?: (id: string) => void,
}

const TaskWrapper = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  column-gap: 1rem;
  background-color: #fff;
  padding: 0.5rem;
  transition: all 0.2s ease-in-out;
  & + div {
    border-top: 1px solid #efefef;
  }
`

const TaskTitleWrapper = styled.div`
  flex-grow: 1;
  & > input[type='text'] {
    width: 100%;
    border: none;
    outline: none;
    pointer-events: none;
    vertical-align: top;
  }
`

const TaskCheckBoxLabel = styled.label`
  cursor: pointer;
  & > input[type='checkbox'] {
    display: none;
    &:checked + span {
      color: #1890ff;
      border-color: transparent;
    }
  }
  & > span {
    display: block;
    border: 1px solid #1890ff;
    border-radius: 2px;
    color: transparent;
    transition: all 0.5s ease-in-out;
  }
`

const TaskPin = styled.span<{ isPinned: boolean }>`
  cursor: pointer;
  color: ${({ isPinned }) => isPinned ? '#1890ff' : '#efefef' };
`

const Task: React.FC<TaskProps> = ({ task: { id, title, state }, onArchiveTask, onPinTask }) => {
  return (
    <TaskWrapper>
      <TaskCheckBoxLabel>
        <input
          type="checkbox"
          defaultChecked={state === 'TASK_ARCHIVED'}
          disabled={true}
          name="checked"
        />
        <span
          onClick={() => {
            if (onArchiveTask) {
              onArchiveTask(id)
            }
          }}
          id={`archiveTask-${id}`}
          aria-label={`archiveTask-${id}`}
        >
          <FontAwesomeIcon icon={faCheck} />
        </span>
      </TaskCheckBoxLabel>
      <TaskTitleWrapper>
        <input type="text" value={title} readOnly={true} />
      </TaskTitleWrapper>
      <div onClick={(e) => e.stopPropagation()}>
        <a
          onClick={() => {
            if (onPinTask) {
              onPinTask(id)
            }
          }}
        >
          <TaskPin id={`pinTask-${id}`} aria-label={`pinTask-${id}`} isPinned={state === 'TASK_PINNED'}>
            <FontAwesomeIcon icon={faStar} size="sm" />
          </TaskPin>
        </a>
      </div>
    </TaskWrapper>
  );
}

export default Task;