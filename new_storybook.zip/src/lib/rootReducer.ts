import { combineReducers } from '@reduxjs/toolkit'
import { default as taskbox } from "./task";

const reducer = combineReducers({
  taskbox
})

export type ReducerType = ReturnType<typeof reducer>
export default reducer
