import { createSlice, PayloadAction, createAsyncThunk, ActionReducerMapBuilder } from "@reduxjs/toolkit";

export interface TaskType {
  id: string,
  title: string,
  state: string,
}

export interface TaskBoxType {
  tasks: TaskType[],
  status: string,
  error: any,
}

interface UpdateTaskType {
  id: string,
  state: string,
}

interface FetchTasksType {
  userId: number,
  id: number,
  title: string,
  completed: boolean,
}

const defaultTasks = [
  { id: '1', title: 'Something', state: 'TASK_INBOX' },
  { id: '2', title: 'Something more', state: 'TASK_INBOX' },
  { id: '3', title: 'Something else', state: 'TASK_INBOX' },
  { id: '4', title: 'Something again', state: 'TASK_INBOX' },
]

const TaskBoxData = {
  tasks: defaultTasks,
  status: 'idle',
  error: null as any
}

export const fetchTasks = createAsyncThunk('todos/fetchTodos', async () => {
  const response = await fetch('https://jsonplaceholder.typicode.com/todos?userId=1')
  const data = await response.json()
  return data.map((task: FetchTasksType) => ({
    id: `${task.id}`,
    title: task.title,
    state: task.completed ? 'TASK_ARCHIVED' : 'TASK_INBOX',
  }))
})

const TasksSlice = createSlice({
  name: 'taskbox',
  initialState: TaskBoxData,
  reducers: {
    updateTaskState: (state, action: PayloadAction<UpdateTaskType>) => {
      const { id, state: newTaskState } = action.payload
      const task = state.tasks.findIndex(({ id: index }) => index === id)
      if (task >= 0) {
        state.tasks[task].state = newTaskState
      }
    }
  },
  extraReducers: (builder: ActionReducerMapBuilder<TaskBoxType>) => {
    builder
      .addCase(fetchTasks.pending, (state: TaskBoxType) => {
        state.status = 'loading'
        state.error = null as any
        state.tasks = [];
      })
      .addCase(fetchTasks.fulfilled, (state: TaskBoxType, action: PayloadAction<TaskType[]>) => {
        state.status = 'succeeded'
        state.error = null as any
        state.tasks = action.payload
      })
      .addCase(fetchTasks.rejected, (state: TaskBoxType) => {
        state.status = 'failed'
        state.error = 'Something went wrong'
        state.tasks = []
      })
  }
})

export const { updateTaskState } = TasksSlice.actions
export default TasksSlice.reducer