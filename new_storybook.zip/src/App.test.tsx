import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders loading state', () => {
  render(<App />);
  const findLoading = screen.getAllByText(/loading/i);
  expect(findLoading).toBeInTheDocument();
});
