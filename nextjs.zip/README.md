## Readme

- 실행 환경

```
아래의 환경에서 과제를 작성하였습니다.

OS: windows 10
Node: 18.15.0
Browser: Chrome
```

- 실행 방법

```
1. yarn install을 실행하여 패키지를 설치합니다.
2. 설치가 완료되면 yarn start를 실행합니다.
3. http://localhost:3000으로 접속하시면 과제 내용을 확인 하실 수 있습니다.
```

- 기타 커맨드

```
yarn storybook: storybook을 실행합니다.
- http://localhost:6006 으로 접속 할 수 있습니다.
- storybook 코드는 /stories 폴더에 있습니다.

yarn e2e: e2e 테스트를 진행합니다.
- 테스트 코드는 /cypress/e2e 폴더에 있습니다.
- 테스트 완료 후에 레포트가 생성됩니다. (/cypress/repots/html/index.html)
```

- 추가 설명

```
- 과제는 Next.js(Typescript)를 사용하여 작성하였습니다.
- 상태 관리 라이브러리로 zustand를 채용하였습니다.
- Emotion 라이브러리를 사용하여 CSS를 작성하였습니다.
- 서버로 부터 수신하는 데이터는 react-query를 통해 관리하였습니다.
- 1920*1080 해상도에서 과제를 작성 하였습니다.
```
