import { create } from 'zustand'
import { immer } from 'zustand/middleware/immer'
import { devtools } from 'zustand/middleware'

export interface CartItem {
  id: number
  amount: number
}

interface CartState {
  list: CartItem[]
  total: number
  addCart: (id: number) => void
  removeCart: (id: number) => void
}

export const useCartStore = create(
  devtools(
    immer<CartState>((set) => ({
      list: [],
      total: 0,
      addCart: (id: number) => {
        set((state: CartState) => {
          if (state.list.find((v: CartItem) => v.id === id)) {
            state.list = state.list.map((v: CartItem) => {
              if (v.id !== id) {
                return v
              }
              return {
                ...v,
                amount: v.amount + 1,
              }
            })
          } else {
            state.list.push({ id, amount: 1 })
            state.total = state.total + 1
          }
        })
      },
      removeCart: (id: number) => {
        set((state: CartState) => {
          const amount = state.list.find((v: CartItem) => v.id === id)?.amount

          if (amount === 1) {
            state.list = state.list.filter((v: CartItem) => v.id !== id)
            state.total = state.total - 1
          } else {
            state.list = state.list.map((v: CartItem) => {
              if (v.id !== id) {
                return v
              }
              return {
                ...v,
                amount: v.amount - 1,
              }
            })
          }
        })
      },
    })),
  ),
)
