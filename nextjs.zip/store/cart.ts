import { create } from 'zustand'
import { immer } from 'zustand/middleware/immer'
import { devtools } from 'zustand/middleware'
import { Product } from '@/types/products'
import { Cart, changeCartStoreType } from '@/types/cart'

interface CartState {
  list: Cart[]
  addCart: (itemInfo: Product) => void
  removeCart: (id: number) => void
  changeCartInfo: (type: changeCartStoreType, id: number) => void
}

export const useCartStore = create(
  devtools(
    immer<CartState>((set) => ({
      list: [],
      addCart: (itemInfo: Product) => {
        set((state: CartState) => {
          if (
            state.list.find(
              (v: Cart) => v.itemInfo.item_no === itemInfo.item_no,
            )
          ) {
            state.list = state.list.map((v: Cart) => {
              if (v.itemInfo.item_no !== itemInfo.item_no) {
                return v
              }
              return {
                ...v,
                amount: v.amount + 1,
              }
            })
          } else {
            state.list.push({ itemInfo, amount: 1, checked: true })
          }
        })
      },
      removeCart: (id: number) => {
        set((state: CartState) => {
          const amount = state.list.find(
            (v: Cart) => v.itemInfo.item_no === id,
          )?.amount

          if (amount === 1) {
            state.list = state.list.filter(
              (v: Cart) => v.itemInfo.item_no !== id,
            )
          } else {
            state.list = state.list.map((v: Cart) => {
              if (v.itemInfo.item_no !== id) {
                return v
              }
              return {
                ...v,
                amount: v.amount - 1,
              }
            })
          }
        })
      },
      changeCartInfo: (type: changeCartStoreType, id: number) => {
        set((state: CartState) => {
          if (type === 'remove') {
            state.list = state.list.filter(
              (v: Cart) => v.itemInfo.item_no !== id,
            )
          } else {
            state.list = state.list.map((v: Cart) => {
              if (v.itemInfo.item_no !== id) return v

              const result: Cart = v

              switch (type) {
                case 'decrease':
                  result.amount = result.amount - 1
                  break

                case 'increase':
                  result.amount = result.amount + 1
                  break

                case 'checked':
                  result.checked = !result.checked
                  break

                default:
                  break
              }

              return result
            })
          }
        })
      },
    })),
  ),
)
