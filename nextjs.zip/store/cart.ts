import { create } from 'zustand'
import { immer } from 'zustand/middleware/immer'
import { devtools } from 'zustand/middleware'
import { Product } from '@/types/products'
import { Cart, changeCartStoreType } from '@/types/cart'
import { Coupon } from '@/types/coupons'

interface CartState {
  list: Cart[]
  coupon: Coupon | object
  addCart: (itemInfo: Product) => void
  removeCart: (id: number) => void
  removeCheckedCart: () => void
  changeCartInfo: (type: changeCartStoreType, id: number) => void
  changeCartCheckedAll: () => void
  changeCoupon: (coupon: Coupon | object) => void
  initializeCartInfo: () => void
  initializeCartList: () => void
}

export const useCartStore = create(
  devtools(
    immer<CartState>((set) => ({
      list: [],
      coupon: {},
      addCart: (itemInfo: Product) => {
        set((state: CartState) => {
          if (
            state.list.find(
              (v: Cart) => v.itemInfo.item_no === itemInfo.item_no,
            )
          ) {
            state.list = state.list.map((v: Cart) => {
              if (v.itemInfo.item_no !== itemInfo.item_no) {
                return v
              }
              return {
                ...v,
                amount: v.amount + 1,
              }
            })
          } else {
            state.list.push({ itemInfo, amount: 1, checked: true })
          }
        })
      },
      removeCart: (id: number) => {
        set((state: CartState) => {
          const amount = state.list.find(
            (v: Cart) => v.itemInfo.item_no === id,
          )?.amount

          if (amount === 1) {
            state.list = state.list.filter(
              (v: Cart) => v.itemInfo.item_no !== id,
            )
          } else {
            state.list = state.list.map((v: Cart) => {
              if (v.itemInfo.item_no !== id) {
                return v
              }
              return {
                ...v,
                amount: v.amount - 1,
              }
            })
          }
        })
      },
      removeCheckedCart: () => {
        set((state: CartState) => {
          state.list = state.list.filter((v: Cart) => !v.checked)
        })
      },
      changeCartInfo: (type: changeCartStoreType, id: number) => {
        set((state: CartState) => {
          if (type === 'remove') {
            state.list = state.list.filter(
              (v: Cart) => v.itemInfo.item_no !== id,
            )
          } else {
            state.list = state.list.map((v: Cart) => {
              if (v.itemInfo.item_no !== id) return v

              const result: Cart = v

              switch (type) {
                case 'decrease':
                  result.amount = result.amount - 1
                  break

                case 'increase':
                  result.amount = result.amount + 1
                  break

                case 'checked':
                  result.checked = !result.checked
                  break

                default:
                  break
              }

              return result
            })
          }
        })
      },
      changeCartCheckedAll: () => {
        set((state: CartState) => {
          const currentCheckedItems = state.list.filter((v: Cart) => v.checked)
          state.list = state.list.map((v: Cart) => ({
            ...v,
            checked: currentCheckedItems.length !== state.list.length,
          }))
        })
      },
      changeCoupon: (coupon: Coupon | object) => {
        set((state: CartState) => {
          state.coupon = coupon
        })
      },
      initializeCartInfo: () => {
        set((state: CartState) => {
          state.list = state.list.map((v: Cart) => ({ ...v, checked: true }))
          state.coupon = {}
        })
      },
      initializeCartList: () => {
        set((state: CartState) => {
          state.list = []
        })
      },
    })),
  ),
)
