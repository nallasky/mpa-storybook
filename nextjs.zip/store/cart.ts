import { create } from 'zustand'
import { immer } from 'zustand/middleware/immer'
import { ProductListItem } from '@/types/products'
import {
  Cart,
  ChangeCartInfoType,
  CHANGE_CART_METHOD,
  RemoveCartType,
} from '@/types/cart'
import { Coupon } from '@/types/coupons'

interface CartState {
  list: Cart[]
  coupon: Coupon
  addCart: (itemInfo: ProductListItem) => void
  removeCart: (itemInfo: RemoveCartType) => void
  removeCheckedCart: () => void
  changeCartInfo: (itemInfo: ChangeCartInfoType) => void
  changeCartCheckedAll: () => void
  changeCoupon: (coupon: Coupon) => void
  initializeCartInfo: () => void
  initializeCartList: () => void
}

export const initialCouponValue: Coupon = {
  type: 'none',
  title: 'none',
}

export const useCartStore = create(
  immer<CartState>((set) => ({
    list: [],
    coupon: initialCouponValue,
    addCart: (itemInfo: ProductListItem) => {
      set((state: CartState) => {
        if (
          state.list.find((v: Cart) => v.itemInfo.item_no === itemInfo.item_no)
        ) {
          state.list = state.list.map((v: Cart) => {
            if (v.itemInfo.item_no !== itemInfo.item_no) {
              return v
            }
            return {
              ...v,
              amount: v.amount + 1,
            }
          })
        } else {
          state.list.push({ itemInfo, amount: 1, checked: true })
        }
      })
    },
    removeCart: (itemInfo: RemoveCartType) => {
      set((state: CartState) => {
        const { id, amount } = itemInfo
        if (amount === 1) {
          state.list = state.list.filter((v: Cart) => v.itemInfo.item_no !== id)
        } else {
          state.list = state.list.map((v: Cart) => {
            if (v.itemInfo.item_no !== id) {
              return v
            }
            return {
              ...v,
              amount: v.amount - 1,
            }
          })
        }
      })
    },
    removeCheckedCart: () => {
      set((state: CartState) => {
        state.list = state.list.filter((v: Cart) => !v.checked)
      })
    },
    changeCartInfo: (itemInfo: ChangeCartInfoType) => {
      set((state: CartState) => {
        const { type, id } = itemInfo
        if (type === CHANGE_CART_METHOD.REMOVE) {
          state.list = state.list.filter((v: Cart) => v.itemInfo.item_no !== id)
        } else {
          state.list = state.list.map((v: Cart) => {
            if (v.itemInfo.item_no !== id) return v

            const result: Cart = v

            switch (type) {
              case CHANGE_CART_METHOD.DECREASE:
                result.amount = result.amount - 1
                break

              case CHANGE_CART_METHOD.INCREASE:
                result.amount = result.amount + 1
                break

              case CHANGE_CART_METHOD.CHECK:
                result.checked = !result.checked
                break

              default:
                break
            }

            return result
          })
        }
      })
    },
    changeCartCheckedAll: () => {
      set((state: CartState) => {
        const currentCheckedItems: Cart[] = state.list.filter(
          (v: Cart) => v.checked,
        )
        state.list = state.list.map((v: Cart) => ({
          ...v,
          checked: currentCheckedItems.length !== state.list.length,
        }))
      })
    },
    changeCoupon: (coupon: Coupon) => {
      set((state: CartState) => {
        state.coupon = coupon
      })
    },
    initializeCartInfo: () => {
      set((state: CartState) => {
        state.list = state.list.map((v: Cart) => ({ ...v, checked: true }))
        state.coupon = initialCouponValue
      })
    },
    initializeCartList: () => {
      set((state: CartState) => {
        state.list = []
      })
    },
  })),
)
