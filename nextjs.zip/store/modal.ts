import { create } from 'zustand'
import { immer } from 'zustand/middleware/immer'
import { Modal } from '@/types/modal'

interface ModalState {
  currentModals: Modal[]
  openModal: (modalInfo: Modal) => void
  closeModal: (component: (props: any) => JSX.Element) => void
}

export const useModalStore = create(
  immer<ModalState>((set) => ({
    currentModals: [],
    openModal: (modalInfo) => {
      set((state: ModalState) => {
        state.currentModals.push(modalInfo)
      })
    },
    closeModal: (component: (props: any) => JSX.Element) => {
      set((state: ModalState) => {
        state.currentModals = state.currentModals.filter(
          (v: Modal) => v.Component !== component,
        )
      })
    },
  })),
)
