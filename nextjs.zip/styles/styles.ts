import styled from '@emotion/styled'

export const CommonModalContent = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 100000;
  width: 400px;
  background-color: white;
  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3),
    0 2px 6px 2px rgba(60, 64, 67, 0.15);
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  row-gap: 16px;
  & > .modal-content-body {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    row-gap: 16px;
    padding: 16px 16px 0 16px;
  }
  & > .modal-content-footer {
    display: flex;
    overflow: hidden;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    width: 100%;
    & > button {
      outline: none;
      border: none;
      height: 48px;
      cursor: pointer;
      transition: all 0.2s;
      &:hover {
        opacity: 0.75;
      }
      &:not(.single-button) {
        flex-basis: 50%;
      }
      &:first-of-type {
        background-color: var(--default-font-color);
        color: white;      
      }
      &:last-of-type {
        background-color: rgba(0, 0, 0, 0.2);    
      }
    }
  }
`