import React from 'react'
import styled from '@emotion/styled'
import { dehydrate, QueryClient } from '@tanstack/react-query'
import { getCoupons } from '@/utils/api/coupons/coupons'
import Layout from '@/components/common/layout'
import CartTitle from '@/components/cart/cartTitle'
import CartList from "@/components/cart/cartList";
import CartTotalPrice from "@/components/cart/cartTotalPrice";

const CartWrapper = styled.div`
  display: flex;
  flex-direction: column;
  row-gap: 16px;
  & > .cart-body {
    margin: 16px 0;
  }
`

export async function getServerSideProps() {
  const queryClient = new QueryClient()
  await queryClient.prefetchQuery(['coupons'], getCoupons)
  return {
    props: {
      dehydratedState: dehydrate(queryClient),
    },
  }
}

export default function Cart() {
  return (
    <Layout title="Cart">
      <CartWrapper>
        <div className="cart-header">
          <CartTitle />
        </div>
        <div className="cart-body">
          <CartList />
        </div>
        <div className="cart-footer">
          <CartTotalPrice />
        </div>
      </CartWrapper>
    </Layout>
  )
}
