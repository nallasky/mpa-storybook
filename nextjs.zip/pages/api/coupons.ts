// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'
import { couponMockData } from '@/mockData/mockData'
import { Coupon } from '@/types/coupons'

type Data = Coupon[]

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>,
) {
  res.status(200).json(couponMockData)
}
