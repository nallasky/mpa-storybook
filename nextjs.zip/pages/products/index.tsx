import React, { useState } from 'react'
import styled from '@emotion/styled'
import { dehydrate, QueryClient, useQuery } from '@tanstack/react-query'
import ProductTitle from '@/components/product/productTitle'
import ProductList from '@/components/product/productList'
import Pagination from '@/components/common/pagination'
import Layout from '@/components/common/layout'
import { getProducts } from '@/utils/api/products/products'
import { SHOW_ITEM_PER_PAGE } from '@/constants/config'

const ProductWrapper = styled.div`
  display: flex;
  flex-direction: column;
  & > .product-body {
    margin: 32px 0;
  }
  & > .product-footer {
    align-self: center;
  }
`

export async function getServerSideProps() {
  const queryClient = new QueryClient()
  await queryClient.prefetchQuery(['products'], getProducts)
  return {
    props: {
      dehydratedState: dehydrate(queryClient),
    },
  }
}

export default function Products() {
  const [currentPage, setCurrentPage] = useState(1)
  const { data } = useQuery(['products'], getProducts)

  return (
    <Layout title="Product">
      <ProductWrapper>
        <div className="product-header">
          <ProductTitle />
        </div>
        <div className="product-body">
          <ProductList offset={(currentPage - 1) * SHOW_ITEM_PER_PAGE} />
        </div>
        <div className="product-footer">
          <Pagination
            currentPage={currentPage}
            limit={data?.length ?? 0}
            itemPerPage={SHOW_ITEM_PER_PAGE}
            onPageChange={(page: number) => setCurrentPage(page)}
          />
        </div>
      </ProductWrapper>
    </Layout>
  )
}
