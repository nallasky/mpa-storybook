import React, { useMemo, useState } from 'react'
import styled from '@emotion/styled'
import { dehydrate, QueryClient, useQuery } from '@tanstack/react-query'
import ProductTitle from '@/components/product/productTitle'
import ProductList from '@/components/product/productList'
import Pagination from '@/components/common/pagination'
import Layout from '@/components/common/layout'
import { getProducts } from '@/utils/api/products/products'
import { SHOW_ITEM_PER_PAGE } from '@/constants/config'
import { ProductListItem } from '@/types/products'

const ProductWrapper = styled.div`
  display: flex;
  flex-direction: column;
  & > .product-body {
    margin: 32px 0;
  }
  & > .product-footer {
    align-self: center;
  }
`

export async function getServerSideProps() {
  const queryClient = new QueryClient()
  await queryClient.prefetchQuery(['products'], getProducts)
  return {
    props: {
      dehydratedState: dehydrate(queryClient),
    },
  }
}

export default function Products() {
  const [currentPage, setCurrentPage] = useState<number>(1)
  const { data } = useQuery(['products'], getProducts)

  const sortedData: ProductListItem[] = useMemo(() => {
    if (!data || !data.length) return []
    const offset: number = (currentPage - 1) * SHOW_ITEM_PER_PAGE
    return data.slice(offset, offset + SHOW_ITEM_PER_PAGE)
  }, [data, currentPage])

  return (
    <Layout title="Product">
      <ProductWrapper>
        <div className="product-header">
          <ProductTitle />
        </div>
        <div className="product-body">
          <ProductList data={sortedData} />
        </div>
        <div className="product-footer">
          <Pagination
            currentPage={currentPage}
            limit={data?.length ?? 0}
            itemPerPage={SHOW_ITEM_PER_PAGE}
            onPageChange={(page: number) => setCurrentPage(page)}
          />
        </div>
      </ProductWrapper>
    </Layout>
  )
}
