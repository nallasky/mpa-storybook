export interface Product {
  item_no: number
  item_name: string
  detail_image_url: string
  price: number
  availableCoupon?: boolean
}

export interface ProductListItem extends Product {
  score: number
}
