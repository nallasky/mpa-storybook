export interface Modal {
  Component: (props: any) => JSX.Element
  props: any
}
