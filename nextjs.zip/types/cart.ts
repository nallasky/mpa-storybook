import { Product } from '@/types/products'

export type changeCartStoreType = 'decrease' | 'increase' | 'checked' | 'remove'

export interface Cart {
  itemInfo: Product
  amount: number
  checked: boolean
}
