import { Product } from '@/types/products'

export const CHANGE_CART_METHOD = {
  DECREASE: 0,
  INCREASE: 1,
  CHECK: 2,
  REMOVE: 3,
} as const

export const CLICK_CART_METHOD = {
  ADD: 0,
  REMOVE: 1,
} as const

export type clickCartType =
  (typeof CLICK_CART_METHOD)[keyof typeof CLICK_CART_METHOD]

export type changeCartStoreType =
  (typeof CHANGE_CART_METHOD)[keyof typeof CHANGE_CART_METHOD]

export interface Cart {
  itemInfo: Product
  amount: number
  checked: boolean
}

export interface ChangeCartInfoType {
  type: changeCartStoreType
  id: number
}

export interface RemoveCartType {
  id: number
  amount: number
}
