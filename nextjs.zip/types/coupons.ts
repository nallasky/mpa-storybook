export interface CouponListItem {
  type: string
  title: string
  discountAmount?: number
  discountRate?: number
}
