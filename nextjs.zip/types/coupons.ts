export const COUPON_TYPE_NONE = 'none'
export const COUPON_TYPE_RATE = 'rate'
export const COUPON_TYPE_AMOUNT = 'amount'

export interface Coupon {
  type: string
  title: string
  discountAmount?: number
  discountRate?: number
}
