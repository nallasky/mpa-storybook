export interface Coupon {
  type: string
  title: string
  discountAmount?: number
  discountRate?: number
}
