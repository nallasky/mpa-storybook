export const SHOW_ITEM_PER_PAGE: number = 5
export const MAX_CART_LENGTH: number = 3
