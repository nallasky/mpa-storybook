export const URL_PRODUCTS = 'http://localhost:3000/api/products'
export const URL_COUPOUNS = 'http://localhost:3000/api/coupons'
