import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import ProductItem from '@/components/product/productItem'
import { userEvent, within } from '@storybook/testing-library'
import { expect } from '@storybook/jest'

const meta: Meta<typeof ProductItem> = {
  title: 'Components/Product/ProductItem',
  component: ProductItem,
}

export default meta

type Story = StoryObj<typeof ProductItem>

export const Default: Story = {
  args: {
    item_no: 661347,
    item_name: '카드 포켓 에어쿠션 투명 폰 케이스(아이폰 갤럭시 핸드폰)',
    detail_image_url:
      'https://img.29cm.co.kr/next-product/2020/10/14/eaddd1ba3d374a789a5084da0ea485d4_20201014205258.jpg?width=500',
    price: 37600,
    amount: 0,
    disabledAddCartButton: false,
    cartClickHandler: (type: string, item_no: number) =>
      console.log(`${type} ${item_no}`),
  },
  render: (args) => {
    return (
      <ul>
        <ProductItem {...args} />
      </ul>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('가격 표시 확인', async () => {
      await canvas.findByText('37,600원')
    })

    await step('타이틀 표시 확인', async () => {
      await canvas.findByText(
        '카드 포켓 에어쿠션 투명 폰 케이스(아이폰 갤럭시 핸드폰)',
      )
    })

    await step('카트 추가 버튼 동작 확인', async () => {
      const addButton = await canvas.findByTestId(
        'product-item-add-cart-button',
      )
      await userEvent.click(addButton)
    })

    await step('카트 삭제 버튼 disabled 상태 확인', async () => {
      const removeButton = await canvas.findByTestId(
        'product-item-remove-cart-button',
      )
      expect(removeButton).toHaveAttribute('disabled')
    })

    await step('카트 수량 미표시 확인', async () => {
      expect(
        await canvas.findByTestId('product-item-amount-text-wrapper'),
      ).not.toHaveClass('show-amount-text')
    })
  },
}

export const DisabledAddCartButton: Story = {
  args: {
    item_no: 661347,
    item_name: '카드 포켓 에어쿠션 투명 폰 케이스(아이폰 갤럭시 핸드폰)',
    detail_image_url:
      'https://img.29cm.co.kr/next-product/2020/10/14/eaddd1ba3d374a789a5084da0ea485d4_20201014205258.jpg?width=500',
    price: 37600,
    amount: 0,
    disabledAddCartButton: true,
    cartClickHandler: (type: 'add' | 'remove', item_no: number) =>
      console.log(`${type} ${item_no}`),
  },
  render: (args) => {
    return (
      <ul>
        <ProductItem {...args} />
      </ul>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('상품 추가 불가 메세지 표시 확인', async () => {
      await canvas.findByText('장바구니에 담을 수 없습니다.')
    })
  },
}

export const AlreadyInCart: Story = {
  args: {
    item_no: 661347,
    item_name: '카드 포켓 에어쿠션 투명 폰 케이스(아이폰 갤럭시 핸드폰)',
    detail_image_url:
      'https://img.29cm.co.kr/next-product/2020/10/14/eaddd1ba3d374a789a5084da0ea485d4_20201014205258.jpg?width=500',
    price: 37600,
    amount: 1,
    disabledAddCartButton: false,
    cartClickHandler: (type: 'add' | 'remove', item_no: number) =>
      console.log(`${type} ${item_no}`),
  },
  render: (args) => {
    return (
      <ul>
        <ProductItem {...args} />
      </ul>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('카트 수량 표시 확인', async () => {
      expect(
        await canvas.findByTestId('product-item-amount-text-wrapper'),
      ).toHaveClass('show-amount-text')
    })
  },
}
