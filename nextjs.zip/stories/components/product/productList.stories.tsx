import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { rest } from 'msw'
import { within } from '@storybook/testing-library'
import { expect } from '@storybook/jest'
import ProductList from '@/components/product/productList'
import { URL_PRODUCTS } from '@/constants/url'
import { productMockData } from '../../../mockData/mockData'

const meta: Meta<typeof ProductList> = {
  title: 'Components/Product/ProductList',
  component: ProductList,
}

export default meta

type Story = StoryObj<typeof ProductList>

export const Default: Story = {
  args: {
    offset: 0,
  },
  render: (args) => {
    return <ProductList {...args} />
  },
  parameters: {
    msw: {
      handlers: [
        rest.get(URL_PRODUCTS, (_, res, ctx) => {
          return res(ctx.json(productMockData))
        }),
      ],
    },
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('상품 5개 표시 확인', async () => {
      const items = await canvas.findByTestId('product-item-list')
      expect(items.childNodes.length).toBe(5)
    })
  },
}

export const Empty: Story = {
  args: {
    offset: 0,
  },
  render: (args) => {
    return <ProductList {...args} />
  },
  parameters: {
    msw: {
      handlers: [
        rest.get(URL_PRODUCTS, (_, res, ctx) => {
          return res(ctx.json([]))
        }),
      ],
    },
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('Empty Component 표시 확인', async () => {
      await canvas.findByText('표시할 상품이 없습니다.')
    })
  },
}
