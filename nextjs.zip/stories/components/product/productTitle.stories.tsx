import React, { useEffect } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import ProductTitle from '../../../components/product/productTitle'
import { useCartStore } from '../../../store/cart'
import { expect } from '@storybook/jest'
import { within } from '@storybook/testing-library'

const meta: Meta<typeof ProductTitle> = {
  title: 'Components/Product/ProductTitle',
  component: ProductTitle,
}

export default meta

type Story = StoryObj<typeof ProductTitle>

export const Default: Story = {
  render: () => {
    const { addCart } = useCartStore()

    useEffect(() => {
      addCart(1)
    }, [])

    return (
      <div className="storybook-screen-wrapper">
        <ProductTitle />
      </div>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('타이틀 확인', async () => {
      await canvas.findByText('상품 리스트')
    })

    await step('cart Link 표시 확인', async () => {
      await canvas.getByRole('link', { hidden: true })
    })

    await step('장바구니 수량 표시 확인', async () => {
      const link = await canvas.getByRole('link', { hidden: true })
      expect(Number(link.children[0].innerHTML)).toBe(1)
    })
  },
}
