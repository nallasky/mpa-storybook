import React, { useEffect } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import ProductTitle from '../../../components/product/productTitle'
import { within } from '@storybook/testing-library'
import { useCartStore } from "../../../store/cart";

const meta: Meta<typeof ProductTitle> = {
  title: 'Components/Product/ProductTitle',
  component: ProductTitle,
}

export default meta

type Story = StoryObj<typeof ProductTitle>

export const Default: Story = {
  render: () => {
    return <ProductTitle />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('타이틀 확인', async () => {
      await canvas.findByText('상품 리스트')
    })

    await step('cart Link 표시 확인', async () => {
      await canvas.getByRole('link', { hidden: true })
    })
  },
}

export const DisplayAmount: Story = {
  render: () => {
    const { addCart, initializeCartList } = useCartStore()

    useEffect(() => {
      addCart({
        item_no: 995684,
        item_name: 'FRAME CASE Air Bumper',
        detail_image_url: 'https://img.29cm.co.kr/next-product/2021/02/24/8cba9f3ec5594042bf9abf83a5a2de29_20210224175633.jpg?width=500',
        price: 25000
      })
      return () => initializeCartList()
    }, [])

    return <ProductTitle />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('숫자 표시 확인', async () => {
      await canvas.findByText('1')
    })
  },
}
