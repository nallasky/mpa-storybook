import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import ChangeCartModal from '@/components/modals/changeCartModal'
import { userEvent, within } from '@storybook/testing-library'

const meta: Meta<typeof ChangeCartModal> = {
  title: 'Components/Modals/ChangeCartModal',
  component: ChangeCartModal,
  argTypes: {
    type: { control: 'select', options: ['add', 'remove'] },
  },
}

export default meta

type Story = StoryObj<typeof ChangeCartModal>

export const AddNewItem: Story = {
  args: {
    type: 'add',
    alreadyAdded: false,
    onClose: () => console.log('onClose function called'),
  },
  render: (args) => {
    return <ChangeCartModal {...args} />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('메세지 확인', async () => {
      await canvas.getByText('장바구니에 상품이 추가되었습니다.')
    })

    await step('버튼 동작 확인', async () => {
      const leftButton = await canvas.findByTestId('common-modal-left-button')
      await userEvent.click(leftButton)

      const rightButton = await canvas.findByTestId('common-modal-right-button')
      await userEvent.click(rightButton)
    })
  },
}

export const PlusItem: Story = {
  args: {
    type: 'add',
    alreadyAdded: true,
    onClose: () => console.log('onClose function called'),
  },
  render: (args) => {
    return <ChangeCartModal {...args} />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('메세지 확인', async () => {
      await canvas.getByText('선택한 상품의 수량이 1개 추가되었습니다.')
    })

    await step('버튼 동작 확인', async () => {
      const leftButton = await canvas.findByTestId('common-modal-left-button')
      await userEvent.click(leftButton)

      const rightButton = await canvas.findByTestId('common-modal-right-button')
      await userEvent.click(rightButton)
    })
  },
}

export const MinusItem: Story = {
  args: {
    type: 'remove',
    alreadyAdded: true,
    onClose: () => console.log('onClose function called'),
  },
  render: (args) => {
    return <ChangeCartModal {...args} />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('메세지 확인', async () => {
      await canvas.getByText('선택한 상품의 수량이 1개 감소하였습니다.')
    })

    await step('버튼 동작 확인', async () => {
      const leftButton = await canvas.findByTestId('common-modal-left-button')
      await userEvent.click(leftButton)

      const rightButton = await canvas.findByTestId('common-modal-right-button')
      await userEvent.click(rightButton)
    })
  },
}

export const RemoveItem: Story = {
  args: {
    type: 'remove',
    alreadyAdded: false,
    onClose: () => console.log('onClose function called'),
  },
  render: (args) => {
    return <ChangeCartModal {...args} />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('메세지 확인', async () => {
      await canvas.getByText('선택한 상품이 장바구니에서 삭제되었습니다.')
    })

    await step('버튼 동작 확인', async () => {
      const leftButton = await canvas.findByTestId('common-modal-left-button')
      await userEvent.click(leftButton)

      const rightButton = await canvas.findByTestId('common-modal-right-button')
      await userEvent.click(rightButton)
    })
  },
}
