import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { rest } from 'msw'
import ApplyCouponModal from '../../../components/modals/applyCouponModal'
import { couponMockData } from '../../../mockData/mockData'
import { URL_COUPOUNS } from '../../../constants/url'
import { within, userEvent } from '@storybook/testing-library'
import { expect } from '@storybook/jest'

const meta: Meta<typeof ApplyCouponModal> = {
  title: 'Components/Modals/ApplyCouponModal',
  component: ApplyCouponModal,
}

export default meta

type Story = StoryObj<typeof ApplyCouponModal>

export const Default: Story = {
  args: {
    onClose: () => {},
  },
  parameters: {
    msw: {
      handlers: [
        rest.get(URL_COUPOUNS, (_, res, ctx) => {
          return res(ctx.json(couponMockData))
        }),
      ],
    },
  },
  render: (args) => {
    return <ApplyCouponModal {...args} />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('쿠폰 표시 확인', async () => {
      await new Promise((r) => setTimeout(r, 1000))
      const radioButtons = await canvas.findAllByRole('radio', { hidden: true })
      expect(radioButtons.length).toBe(3)
      await canvas.findByText('10% 할인 쿠폰')
      await canvas.findByText('10,000원 할인 쿠폰')
      await canvas.findByText('쿠폰 적용 안함')
      expect(radioButtons[2].checked).toEqual(true)
    })

    await step('쿠폰 변경 확인', async () => {
      const radioButtons = await canvas.findAllByRole('radio', { hidden: true })
      await userEvent.click(radioButtons[0])
      expect(radioButtons[0].checked).toEqual(true)
      await userEvent.click(radioButtons[1])
      expect(radioButtons[1].checked).toEqual(true)
      await userEvent.click(radioButtons[2])
      expect(radioButtons[2].checked).toEqual(true)
    })

    await step('버튼 동작 확인', async () => {
      const leftButton = await canvas.findByTestId('common-modal-left-button')
      await userEvent.click(leftButton)

      const rightButton = await canvas.findByTestId('common-modal-right-button')
      await userEvent.click(rightButton)
    })
  },
}
