import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import SuccessRemoveCartItemModal from '../../../components/modals/successRemoveCartItemModal'
import { userEvent, within } from '@storybook/testing-library'

const meta: Meta<typeof SuccessRemoveCartItemModal> = {
  title: 'Components/Modals/SuccessRemoveCartItemModal',
  component: SuccessRemoveCartItemModal,
}

export default meta

type Story = StoryObj<typeof SuccessRemoveCartItemModal>

export const Default: Story = {
  args: {
    onClose: () => {},
  },
  render: (args) => {
    return <SuccessRemoveCartItemModal {...args} />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('메세지 확인', async () => {
      await canvas.getByText('선택한 상품이 삭제 됐습니다.')
    })

    await step('버튼 동작 확인', async () => {
      const singleButton = await canvas.findByTestId(
        'alert-modal-single-button',
      )
      await userEvent.click(singleButton)
    })
  },
}
