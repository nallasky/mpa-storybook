import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import RemoveCheckedCartItemModal from "../../../components/modals/removeCheckedCartItemModal";
import {userEvent, within} from "@storybook/testing-library";

const meta: Meta<typeof RemoveCheckedCartItemModal> = {
  title: 'Components/Modals/RemoveCheckedCartItemModal',
  component: RemoveCheckedCartItemModal
}

export default meta

type Story = StoryObj<typeof RemoveCheckedCartItemModal>

export const Default: Story = {
  args: {
    itemId: 1,
    onClose: () => {}
  },
  render: (args) => {
    return <RemoveCheckedCartItemModal {...args} />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('메세지 확인', async () => {
      await canvas.getByText('상품을 삭제 하시겠습니까?')
    })

    await step('버튼 동작 확인', async () => {
      const leftButton = await canvas.findByTestId('common-modal-left-button')
      await userEvent.click(leftButton)

      const rightButton = await canvas.findByTestId('common-modal-right-button')
      await userEvent.click(rightButton)
    })
  },
}