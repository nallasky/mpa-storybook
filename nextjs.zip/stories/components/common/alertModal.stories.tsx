import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons'
import { userEvent, within } from '@storybook/testing-library'
import AlertModal from '../../../components/common/alertModal'

const meta: Meta<typeof AlertModal> = {
  title: 'Components/Common/AlertModal',
  component: AlertModal,
}

export default meta

type Story = StoryObj<typeof AlertModal>

export const Default: Story = {
  args: {
    buttonText: '닫기',
    buttonHandler: () => {},
  },
  render: (args) => {
    return (
      <AlertModal {...args}>
        <FontAwesomeIcon icon={faCheckCircle} size="5x" />
        <p>Alert Modal!!</p>
      </AlertModal>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('메세지 확인', async () => {
      await canvas.getByText('Alert Modal!!')
    })

    await step('버튼 동작 확인', async () => {
      const singleButton = await canvas.findByTestId(
        'alert-modal-single-button',
      )
      await userEvent.click(singleButton)
    })
  },
}
