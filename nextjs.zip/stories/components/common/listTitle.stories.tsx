import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import styled from '@emotion/styled'
import ListTitle from '@/components/common/listTitle'
import { within } from '@storybook/testing-library'

const meta: Meta<typeof ListTitle> = {
  title: 'Components/Common/ListTitle',
  component: ListTitle,
}

export default meta

type Story = StoryObj<typeof ListTitle>

export const TitleOnly: Story = {
  args: {
    title: 'List Title',
  },
  render: (args) => {
    return (
      <div className="storybook-screen-wrapper">
        <ListTitle title={args.title} />
      </div>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('타이틀 텍스트 확인', async () => {
      await canvas.findByText('List Title')
    })
  },
}

const TitleListButton = styled.button`
  outline: none;
  border: 1px solid #dadada;
  background-color: white;
  border-radius: 4px;
  padding: 4px 8px;
  cursor: pointer;
`

export const WithChildren: Story = {
  args: {
    title: 'With Children',
  },
  render: (args) => {
    return (
      <div className="storybook-screen-wrapper">
        <ListTitle title={args.title}>
          <TitleListButton data-testid="list-title-button">
            List Button
          </TitleListButton>
        </ListTitle>
      </div>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('children 표시 확인', async () => {
      await canvas.findByTestId('list-title-button')
    })
  },
}
