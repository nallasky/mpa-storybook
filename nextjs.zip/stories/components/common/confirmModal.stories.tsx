import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons'
import ConfirmModal from '../../../components/common/confirmModal'
import { userEvent, within } from '@storybook/testing-library'

const meta: Meta<typeof ConfirmModal> = {
  title: 'Components/Common/ConfirmModal',
  component: ConfirmModal,
}

export default meta

type Story = StoryObj<typeof ConfirmModal>

export const Default: Story = {
  args: {
    leftButtonText: '적용하기',
    leftButtonHandlers: () => {},
    rightButtonText: '닫기',
    rightButtonHandlers: () => {},
  },
  render: (args) => {
    return (
      <ConfirmModal {...args}>
        <FontAwesomeIcon icon={faExclamationCircle} size="5x" />
        <p>Confirm Modal!!!</p>
      </ConfirmModal>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('메세지 확인', async () => {
      await canvas.getByText('Confirm Modal!!!')
    })

    await step('버튼 동작 확인', async () => {
      const leftButton = await canvas.findByTestId('common-modal-left-button')
      await userEvent.click(leftButton)

      const rightButton = await canvas.findByTestId('common-modal-right-button')
      await userEvent.click(rightButton)
    })
  },
}
