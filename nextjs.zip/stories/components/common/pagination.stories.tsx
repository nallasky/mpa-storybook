import React, { useState, useEffect } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { within, userEvent } from '@storybook/testing-library'
import { expect } from '@storybook/jest'
import Pagination from '@/components/common/pagination'

const meta: Meta<typeof Pagination> = {
  title: 'Components/Common/Pagination',
  component: Pagination,
}

export default meta

type Story = StoryObj<typeof Pagination>

export const Default: Story = {
  args: {
    limit: 20,
    itemPerPage: 5,
    currentPage: 1,
  },
  render: (args) => {
    const [currentPage, setCurrentPage] = useState(args.currentPage)

    useEffect(() => {
      setCurrentPage(args.currentPage)
    }, [args.currentPage])

    return (
      <div className="storybook-screen-wrapper">
        <Pagination
          limit={args.limit}
          currentPage={currentPage}
          itemPerPage={args.itemPerPage}
          onPageChange={(page: number) => {
            setCurrentPage(page)
          }}
        />
      </div>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('< 버튼의 disabled 상태 확인', async () => {
      const prevButton = await canvas.findByTestId('pagination-move-prev-page')
      expect(prevButton).toHaveAttribute('disabled')
    })

    await step('> 버튼 동작 확인', async () => {
      const nextButton = await canvas.findByTestId('pagination-move-next-page')
      await userEvent.click(nextButton)
      const secondButton = await canvas.findByTestId('pagination-move-page-2')
      expect(secondButton).toHaveClass('selected')
    })

    await step(
      '숫자 버튼 클릭 확인 및 > 버튼의 disabled 상태 확인',
      async () => {
        const limitPageButton = await canvas.findByTestId(
          'pagination-move-page-4',
        )
        expect(limitPageButton).not.toBeUndefined()
        await userEvent.click(limitPageButton)
        expect(limitPageButton).toHaveClass('selected')
        const nextButton = await canvas.findByTestId(
          'pagination-move-next-page',
        )
        expect(nextButton).toHaveAttribute('disabled')
      },
    )

    await step('< 버튼 동작 확인', async () => {
      const prevButton = await canvas.findByTestId('pagination-move-prev-page')
      await userEvent.click(prevButton)
      const thirdButton = await canvas.findByTestId('pagination-move-page-3')
      expect(thirdButton).toHaveClass('selected')
    })
  },
}
