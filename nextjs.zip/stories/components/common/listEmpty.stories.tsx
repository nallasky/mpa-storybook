import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import ListEmpty from '../../../components/common/listEmpty'
import { within } from '@storybook/testing-library'

const meta: Meta<typeof ListEmpty> = {
  title: 'Components/Common/ListEmpty',
  component: ListEmpty,
}

export default meta

type Story = StoryObj<typeof ListEmpty>

export const Default: Story = {
  args: {
    message: 'List is Empty!!',
  },
  render: (args) => {
    return <ListEmpty {...args} />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('메세지 확인', async () => {
      await canvas.getByText('List is Empty!!')
    })
  },
}
