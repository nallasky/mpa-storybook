import React, { useState, useEffect } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { within, userEvent } from '@storybook/testing-library'
import { expect } from '@storybook/jest'
import CommonCheckBox from '../../../components/common/commonCheckBox'

const meta: Meta<typeof CommonCheckBox> = {
  title: 'Components/Common/CommonCheckBox',
  component: CommonCheckBox,
}

export default meta

type Story = StoryObj<typeof CommonCheckBox>

export const Default: Story = {
  args: {
    label: '',
    checked: true,
  },
  render: (args) => {
    const [isChecked, setIsChecked] = useState(args.checked)

    useEffect(() => {
      setIsChecked(args.checked)
    }, [args.checked])

    return (
      <CommonCheckBox
        onChangeHandler={() => setIsChecked((prev) => !prev)}
        checked={isChecked}
        label={args.label}
      />
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('checked 상태 확인', async () => {
      const checkbox = await canvas.getByRole('checkbox', { hidden: true })
      expect(checkbox.checked).toEqual(true)
    })

    await step('클릭 동작 확인', async () => {
      const checkbox = await canvas.getByRole('checkbox', { hidden: true })
      await userEvent.click(checkbox)
      await userEvent.click(checkbox)
    })
  },
}

export const WithLabelText: Story = {
  args: {
    label: 'CheckBox',
    checked: true,
  },
  render: (args) => {
    const [isChecked, setIsChecked] = useState(args.checked)

    useEffect(() => {
      setIsChecked(args.checked)
    }, [args.checked])

    return (
      <CommonCheckBox
        onChangeHandler={() => setIsChecked((prev) => !prev)}
        checked={isChecked}
        label={args.label}
      />
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('라벨 표시 확인', async () => {
      await canvas.findByText('CheckBox')
    })
  },
}
