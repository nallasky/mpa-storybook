import React, { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import CartItem from "../../../components/cart/cartItem";
import { changeCartStoreType } from "../../../types/cart";
import { CartListWrapper } from "../../../components/cart/cartList";
import { userEvent, within } from "@storybook/testing-library";
import { expect } from "@storybook/jest";

const meta: Meta<typeof CartItem> = {
  title: 'Components/Cart/CartItem',
  component: CartItem
}

export default meta

type Story = StoryObj<typeof CartItem>

const CommonCartItemStory = (args) => {
  const [cartItemInfo, setCartItemInfo] = useState({...args});

  const eventHandler = (type: changeCartStoreType, id: number) => {
    if (type === 'remove') {
      console.log('event handler type remove!')
    } else {
      const result = {...cartItemInfo}

      switch (type) {
        case 'decrease':
          result.amount = result.amount - 1
          break

        case 'increase':
          result.amount = result.amount + 1
          break

        case 'checked':
          result.checked = !result.checked
          break

        default:
          break
      }

      setCartItemInfo(result)
    }
  }

  return (
    <CartListWrapper style={{ width: '100%' }}>
      <CartItem {...cartItemInfo} eventHandler={eventHandler} />
    </CartListWrapper>
  )
}

export const Default: Story = {
  args: {
    itemInfo: {
      item_no: 995684,
      item_name: 'FRAME CASE Air Bumper',
      detail_image_url: 'https://img.29cm.co.kr/next-product/2021/02/24/8cba9f3ec5594042bf9abf83a5a2de29_20210224175633.jpg?width=500',
      price: 25000
    },
    amount: 1,
    checked: true,
  },
  render: (args) => <CommonCartItemStory {...args} />,
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('체크 박스 checked 상태 확인', async () => {
      const checkbox = await canvas.findByRole('checkbox', { hidden: true })
      expect(checkbox.checked).toEqual(true)
      await userEvent.click(checkbox)
      expect(checkbox.checked).toEqual(false)
      await userEvent.click(checkbox)
    })

    await step('타이틀 표시 확인', async () => {
      await canvas.findByText('FRAME CASE Air Bumper')
    })

    await step('수량 확인', async () => {
      const textbox = await canvas.findByRole('textbox')
      expect(Number(textbox.value)).toEqual(1)
      const buttons = await canvas.findAllByRole('button')
      expect(buttons[1].disabled).toEqual(true)
      await userEvent.click(buttons[0])
      expect(buttons[1].disabled).toEqual(false)
      expect(Number(textbox.value)).toEqual(2)
      await userEvent.click(buttons[1])
      expect(Number(textbox.value)).toEqual(1)
      await userEvent.click(buttons[2])
    })

    await step('쿠폰 적용 메세지 확인', async () => {
      await canvas.findByText('쿠폰 적용 가능')
    })

    await step('가격 확인', async () => {
      await canvas.findByText('25,000원')
    })
  },
}

export const NotAvailableCoupon: Story = {
  args: {
    itemInfo: {
      item_no: 870160,
      item_name: '위키오 3in1 거치대형 무선충전기 아이폰, 갤럭시, 스마트워치, 무선이어폰 동시충전',
      detail_image_url: 'https://img.29cm.co.kr/next-product/2021/01/21/af916f6191f24a84b076e74e613a4795_20210121114833.jpg?width=500',
      price: 39900,
      availableCoupon: false,
    },
    amount: 1,
    checked: true,
  },
  render: (args) => <CommonCartItemStory {...args} />,
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('쿠폰 적용 불가능 메세지 확인', async () => {
      await canvas.findByText('쿠폰 적용 불가능')
    })
  },
}