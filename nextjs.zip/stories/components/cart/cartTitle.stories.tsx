import React, { useEffect } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import CartTitle from "../../../components/cart/cartTitle";
import { within } from "@storybook/testing-library";
import { expect } from "@storybook/jest";
import { useCartStore } from "../../../store/cart";

const meta: Meta<typeof CartTitle> = {
  title: 'Components/Cart/CartTitle',
  component: CartTitle
}

export default meta

type Story = StoryObj<typeof CartTitle>

export const Default: Story = {
  render: () => {
    const { initializeCartList } = useCartStore()

    useEffect(() => {
      initializeCartList()
    }, [])

    return <CartTitle />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('이전 페이지 돌아가기 버튼 확인', async () => {
      const buttons = await canvas.findAllByRole('button')
      expect(buttons[0].disabled).toEqual(false)
    })

    await step('쿠폰 적용하기 버튼 확인', async () => {
      const buttons = await canvas.findAllByRole('button')
      expect(buttons[1].disabled).toEqual(true)
    })

    await step('전체 상품 선택/해제 버튼 확인', async () => {
      const buttons = await canvas.findAllByRole('button')
      expect(buttons[2].disabled).toEqual(true)
    })

    await step('선택된 상품 모두 삭제 버튼 확인', async () => {
      const buttons = await canvas.findAllByRole('button')
      expect(buttons[3].disabled).toEqual(true)
    })
  }
}

export const AllButtonEnabled: Story = {
  render: () => {
    const { addCart, initializeCartList } = useCartStore()

    useEffect(() => {
      addCart({
        item_no: 995684,
        item_name: 'FRAME CASE Air Bumper',
        detail_image_url: 'https://img.29cm.co.kr/next-product/2021/02/24/8cba9f3ec5594042bf9abf83a5a2de29_20210224175633.jpg?width=500',
        price: 25000
      })
      return () => initializeCartList()
    }, [])

    return <CartTitle />
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('이전 페이지 돌아가기 버튼 확인', async () => {
      const buttons = await canvas.findAllByRole('button')
      expect(buttons[0].disabled).toEqual(false)
    })

    await step('쿠폰 적용하기 버튼 확인', async () => {
      const buttons = await canvas.findAllByRole('button')
      expect(buttons[1].disabled).toEqual(false)
    })

    await step('전체 상품 선택/해제 버튼 확인', async () => {
      const buttons = await canvas.findAllByRole('button')
      expect(buttons[2].disabled).toEqual(false)
    })

    await step('선택된 상품 모두 삭제 버튼 확인', async () => {
      const buttons = await canvas.findAllByRole('button')
      expect(buttons[3].disabled).toEqual(false)
    })
  }
}