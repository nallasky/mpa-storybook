import React, { useEffect } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import CartTotalPrice from "../../../components/cart/cartTotalPrice";
import { useCartStore } from "../../../store/cart";
import { within } from "@storybook/testing-library";
import { expect } from "@storybook/jest";

const meta: Meta<typeof CartTotalPrice> = {
  title: 'Components/Cart/CartTotalPrice',
  component: CartTotalPrice
}

export default meta

type Story = StoryObj<typeof CartTotalPrice>

export const Default: Story = {
  render: () => {
    const { addCart, initializeCartList } = useCartStore()

    useEffect(() => {
      addCart({
        item_no: 995684,
        item_name: 'FRAME CASE Air Bumper',
        detail_image_url: 'https://img.29cm.co.kr/next-product/2021/02/24/8cba9f3ec5594042bf9abf83a5a2de29_20210224175633.jpg?width=500',
        price: 25000
      })
      return () => initializeCartList()
    }, [])

    return (
      <div style={{ width: "100%" }}>
        <CartTotalPrice />
      </div>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('상품금액 확인', async () => {
      await canvas.findByText('상품금액')
      const prices = await canvas.findAllByText('25,000원')
      expect(prices.length).toEqual(2)
    })

    await step('상품할인금액 확인', async () => {
      await canvas.findByText('상품할인금액')
      await canvas.findByText('0원')
    })

    await step('결제예정금액 확인', async () => {
      await canvas.findByText('결제예정금액')
    })
  }
}
