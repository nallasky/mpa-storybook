import React, { useEffect } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import CartList from '../../../components/cart/cartList'
import { useCartStore } from '../../../store/cart'
import { productMockData } from '../../../mockData/mockData'
import { ProductListItem } from '../../../types/products'
import { within } from '@storybook/testing-library'
import { expect } from '@storybook/jest'

const meta: Meta<typeof CartList> = {
  title: 'Components/Cart/CartList',
  component: CartList,
}

export default meta

type Story = StoryObj<typeof CartList>

export const Default: Story = {
  render: () => {
    const { addCart, initializeCartList } = useCartStore()

    useEffect(() => {
      productMockData.slice(0, 3).forEach((v: ProductListItem) => {
        const { score, ...rest } = v
        addCart(rest)
      })
      return () => initializeCartList()
    }, [])

    return (
      <div style={{ width: '100%' }}>
        <CartList />
      </div>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('리스트 길이 확인', async () => {
      const checkboxes = await canvas.findAllByRole('checkbox', {
        hidden: true,
      })
      expect(checkboxes.length).toEqual(3)
    })
  },
}

export const EmptyList: Story = {
  render: () => {
    const { initializeCartList } = useCartStore()

    useEffect(() => {
      initializeCartList()
    }, [])

    return (
      <div style={{ width: '100%' }}>
        <CartList />
      </div>
    )
  },
  play: async ({ canvasElement, step }) => {
    const canvas = within(canvasElement)

    await step('비어있음 메세지 확인', async () => {
      await canvas.findByText('장바구니가 비어 있습니다.')
    })
  },
}
