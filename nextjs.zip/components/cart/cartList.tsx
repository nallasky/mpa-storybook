import React from 'react'
import styled from '@emotion/styled'
import { shallow } from 'zustand/shallow'
import { useCartStore } from '@/store/cart'
import { Cart, changeCartStoreType } from '@/types/cart'
import { useModalStore } from '@/store/modal'
import CartItem from '@/components/cart/cartItem'
import ListEmpty from '@/components/common/listEmpty'
import RemoveCheckedCartItemModal from '@/components/modals/removeCheckedCartItemModal'

export const CartListWrapper = styled.div`
  display: flex;
  flex-direction: column;
  row-gap: 16px;
  border-top: 2px solid #333;
  border-bottom: 2px solid #333;
  padding: 16px 0;
`

const CartList = () => {
  const { changeCartInfo } = useCartStore()
  const list = useCartStore((state) => state.list, shallow)
  const openModal = useModalStore((state) => state.openModal)

  if (!list.length) {
    return <ListEmpty message="장바구니가 비어 있습니다." />
  }

  const eventHandler = (type: changeCartStoreType, id: number) => {
    if (type === 'remove') {
      openModal({
        Component: RemoveCheckedCartItemModal,
        props: { itemId: id },
      })
    } else {
      changeCartInfo(type, id)
    }
  }

  return (
    <CartListWrapper>
      {list.map((v: Cart) => {
        return (
          <CartItem
            key={v.itemInfo.item_no}
            eventHandler={eventHandler}
            {...v}
          />
        )
      })}
    </CartListWrapper>
  )
}

export default CartList
