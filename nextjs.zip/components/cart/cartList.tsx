import React from 'react'
import styled from '@emotion/styled'
import { useCartStore } from '@/store/cart'
import { Cart } from '@/types/cart'
import CartItem from '@/components/cart/cartItem'
import ListEmpty from '@/components/common/listEmpty'

const CartListWrapper = styled.div`
  display: flex;
  flex-direction: column;
  row-gap: 16px;
  border-top: 2px solid #333;
  border-bottom: 2px solid #333;
  padding: 16px 0;
`

const CartList = () => {
  const { list, changeCartInfo } = useCartStore()

  if (!list.length) {
    return <ListEmpty message="장바구니가 비어 있습니다." />
  }

  return (
    <CartListWrapper>
      {list.map((v: Cart) => {
        return (
          <CartItem
            key={v.itemInfo.item_no}
            eventHandler={changeCartInfo}
            {...v}
          />
        )
      })}
    </CartListWrapper>
  )
}

export default CartList
