import React, { useMemo } from 'react'
import styled from '@emotion/styled'
import { shallow } from 'zustand/shallow'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEquals, faMinus } from '@fortawesome/free-solid-svg-icons'
import { useCartStore } from '@/store/cart'
import { Cart } from '@/types/cart'
import { priceToString } from '@/utils/common/functions'

const CartTotalPriceWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 32px 96px;
  background-color: #f9f9f9;
  border-top: 1px dashed #dadada;
  border-bottom: 1px dashed #dadada;
  & > * {
    text-align: center;
  }
`

const CartTotalPriceItem = styled.div`
  & > .price {
    margin-top: 4px;
    font-size: 24px;
    font-weight: bold;
    &.coupon {
      color: #ef2a23;
    }
  }
`

const CartTotalPrice = () => {
  const list = useCartStore((state) => state.list, shallow)
  const coupon = useCartStore((state) => state.coupon, shallow)

  const defaultPrice = useMemo(() => {
    return list.reduce((acc: number, v: Cart) => {
      if (!v.checked) return acc
      return acc + v.itemInfo.price * v.amount
    }, 0)
  }, [list])

  const discountPrice = useMemo(() => {
    const availableDiscountItems = list.filter(
      (v: Cart) => v.checked && v.itemInfo.availableCoupon === undefined,
    )
    if (!Object.keys(coupon).length || !availableDiscountItems.length) return 0

    const couponInfo: any = coupon

    if (couponInfo.type === 'rate' && couponInfo.discountRate) {
      const price = availableDiscountItems.reduce((acc: number, v: Cart) => {
        return acc + v.itemInfo.price * v.amount
      }, 0)
      return Math.floor(price * (couponInfo.discountRate * 0.01))
    }
    return couponInfo.discountAmount
  }, [list, coupon])

  if (!list.length) return <></>

  return (
    <CartTotalPriceWrapper>
      <CartTotalPriceItem>
        <h3>상품금액</h3>
        <div className="price">{`${priceToString(defaultPrice)}원`}</div>
      </CartTotalPriceItem>
      <div className="minus-icon">
        <FontAwesomeIcon icon={faMinus} size="2x" />
      </div>
      <CartTotalPriceItem>
        <h3>상품할인금액</h3>
        <div className="price coupon">{`${priceToString(
          discountPrice,
        )}원`}</div>
      </CartTotalPriceItem>
      <div className="equal-icon">
        <FontAwesomeIcon icon={faEquals} size="2x" />
      </div>
      <CartTotalPriceItem>
        <h3>결제예정금액</h3>
        <div className="price">{`${priceToString(
          defaultPrice - discountPrice,
        )}원`}</div>
      </CartTotalPriceItem>
    </CartTotalPriceWrapper>
  )
}

export default CartTotalPrice
