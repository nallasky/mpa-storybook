import React from 'react';
import styled from "@emotion/styled";
import { shallow } from "zustand/shallow";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEquals, faMinus } from "@fortawesome/free-solid-svg-icons";
import { useCartStore } from "@/store/cart";

const CartTotalPriceWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 32px 96px;
  background-color: #f9f9f9;
  border-top: 1px dashed #dadada;
  border-bottom: 1px dashed #dadada;
  & > * {
    text-align: center;
  }
`;

const CartTotalPriceItem = styled.div`
  & > .price {
    margin-top: 4px;
    font-size: 24px;
    font-weight: bold;
    &.coupon {
      color: #ef2a23;
    }
  }
`;

const CartTotalPrice = () => {
  const list = useCartStore((state) => state.list, shallow);

  if (!list.length) return <></>

  return (
    <CartTotalPriceWrapper>
      <CartTotalPriceItem>
        <h3>상품금액</h3>
        <div className="price">145,000원</div>
      </CartTotalPriceItem>
      <div className="minus-icon">
        <FontAwesomeIcon icon={faMinus} size="2x" />
      </div>
      <CartTotalPriceItem>
        <h3>상품할인금액</h3>
        <div className="price coupon">12,500원</div>
      </CartTotalPriceItem>
      <div className="equal-icon">
        <FontAwesomeIcon icon={faEquals} size="2x" />
      </div>
      <CartTotalPriceItem>
        <h3>결제예정금액</h3>
        <div className="price">132,500원</div>
      </CartTotalPriceItem>
    </CartTotalPriceWrapper>
  )
}

export default CartTotalPrice