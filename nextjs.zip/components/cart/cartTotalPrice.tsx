import React, { useMemo } from 'react'
import styled from '@emotion/styled'
import { shallow } from 'zustand/shallow'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEquals, faMinus } from '@fortawesome/free-solid-svg-icons'
import { useCartStore } from '@/store/cart'
import { Cart } from '@/types/cart'
import { priceToString } from '@/utils/common/functions'
import { COUPON_TYPE_NONE, COUPON_TYPE_RATE } from '@/types/coupons'

const CartTotalPriceWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 32px 96px;
  background-color: #f9f9f9;
  border-top: 1px dashed #dadada;
  border-bottom: 1px dashed #dadada;
  & > * {
    text-align: center;
  }
`

const CartTotalPriceItemWrapper = styled.div<{ isDiscount: boolean }>`
  & > .price {
    margin-top: 4px;
    font-size: 24px;
    font-weight: bold;
    ${({ isDiscount }) => isDiscount && `color: #ef2a23;`}
  }
`

interface CartTotalPriceItemProps {
  title: string
  price: string | number
  isDiscount?: boolean
}

const CartTotalPriceItem = ({
  title,
  price,
  isDiscount = false,
}: CartTotalPriceItemProps) => {
  return (
    <CartTotalPriceItemWrapper isDiscount={isDiscount}>
      <h3>{title}</h3>
      <div className="price">{`${priceToString(price)}원`}</div>
    </CartTotalPriceItemWrapper>
  )
}

const CartTotalPrice = () => {
  const list = useCartStore((state) => state.list, shallow)
  const coupon = useCartStore((state) => state.coupon, shallow)

  const defaultPrice: number = useMemo(() => {
    return list.reduce((acc: number, v: Cart) => {
      if (!v.checked) return acc
      return acc + v.itemInfo.price * v.amount
    }, 0)
  }, [list])

  const discountPrice: number = useMemo(() => {
    const availableDiscountItems: Cart[] = list.filter(
      (v: Cart) => v.checked && v.itemInfo.availableCoupon === undefined,
    )
    if (coupon.type === COUPON_TYPE_NONE || !availableDiscountItems.length)
      return 0

    if (coupon.type === COUPON_TYPE_RATE && coupon.discountRate) {
      const price: number = availableDiscountItems.reduce(
        (acc: number, v: Cart) => {
          return acc + v.itemInfo.price * v.amount
        },
        0,
      )
      return Math.floor(price * (coupon.discountRate * 0.01))
    }
    return coupon?.discountAmount ?? 0
  }, [list, coupon])

  if (!list.length) return <></>

  return (
    <CartTotalPriceWrapper>
      <CartTotalPriceItem title="상품금액" price={defaultPrice} />
      <div className="minus-icon">
        <FontAwesomeIcon icon={faMinus} size="2x" />
      </div>
      <CartTotalPriceItem
        title="상품할인금액"
        price={discountPrice}
        isDiscount
      />
      <div className="equal-icon">
        <FontAwesomeIcon icon={faEquals} size="2x" />
      </div>
      <CartTotalPriceItem
        title="결제예정금액"
        price={defaultPrice < discountPrice ? 0 : defaultPrice - discountPrice}
      />
    </CartTotalPriceWrapper>
  )
}

export default CartTotalPrice
