import React from 'react'
import styled from '@emotion/styled'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faChevronUp, faChevronDown } from '@fortawesome/free-solid-svg-icons'
import CommonCheckBox from '@/components/common/commonCheckBox'
import { Cart, changeCartStoreType, CHANGE_CART_METHOD } from '@/types/cart'
import { priceToString } from '@/utils/common/functions'

const CartItemWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  & > * {
    text-align: center;
  }
  & + div {
    padding-top: 16px;
    border-top: 1px solid #e9ecef;
  }
  & > .item-price-wrapper {
    flex-basis: 150px;
  }
  & > .not-available-coupon {
    color: #ef2a23;
    font-weight: 500;
  }
`

const CartItemInfoWrapper = styled.div`
  display: flex;
  align-items: center;
  column-gap: 8px;
  flex-basis: 600px;
  & > .item-image {
    position: relative;
    width: 144px;
    flex-shrink: 0;
    & > .image-box {
      overflow: hidden;
      border-radius: 4px;
      position: relative;
      width: 100%;
      padding-top: 100%;
      background-color: #f3f3f3;
      & > img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        image-rendering: pixelated;
      }
    }
  }
  & > .item-name {
    display: -webkit-box;
    max-height: 48px;
    overflow: hidden;
    word-break: break-all;
    text-overflow: ellipsis;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    text-align: left;
  }
`

const CartItemAmountWrapper = styled.div`
  display: flex;
  flex-direction: column;
  row-gap: 8px;
  & button {
    outline: none;
    background-color: white;
    border-radius: 4px;
    border: 1px solid #b9b9b9;
    cursor: pointer;
    transition: all 0.2s;
    &.delete-button {
      padding: 4px 0;
    }
    &:hover {
      background-color: #efefef;
    }
    &:disabled {
      background-color: #dadada;
      cursor: not-allowed;
    }
  }
  & > .amount-control {
    display: flex;
    align-items: center;
    column-gap: 8px;
    & > input[type='text'] {
      width: 48px;
      text-align: center;
      border: 1px solid #b9b9b9;
      outline: none;
      font-size: 16px;
      padding: 4px 8px;
      border-radius: 4px;
    }
    & > .amount-change-buttons {
      display: flex;
      flex-direction: column;
      width: 32px;
      row-gap: 4px;
    }
  }
`

interface CartItemProps extends Cart {
  eventHandler: (type: changeCartStoreType, id: number) => void
}

const CartItem = React.memo(
  ({ itemInfo, amount, checked, eventHandler }: CartItemProps) => {
    const { item_no, item_name, detail_image_url, price, availableCoupon } =
      itemInfo

    const isNotAvailableCoupon: boolean =
      availableCoupon !== undefined && !availableCoupon

    return (
      <CartItemWrapper>
        <div className="item-checkbox-wrapper">
          <CommonCheckBox
            checked={checked}
            onChangeHandler={() =>
              eventHandler(CHANGE_CART_METHOD.CHECK, item_no)
            }
          />
        </div>
        <CartItemInfoWrapper>
          <div className="item-image">
            <div className="image-box">
              <img src={detail_image_url} alt="Cart Item" />
            </div>
          </div>
          <div className="item-name">{item_name}</div>
        </CartItemInfoWrapper>
        <CartItemAmountWrapper>
          <div className="title">수량</div>
          <div className="amount-control">
            <input type="text" value={amount} disabled />
            <div className="amount-change-buttons">
              <button
                onClick={() =>
                  eventHandler(CHANGE_CART_METHOD.INCREASE, item_no)
                }
              >
                <FontAwesomeIcon icon={faChevronUp} />
              </button>
              <button
                onClick={() =>
                  eventHandler(CHANGE_CART_METHOD.DECREASE, item_no)
                }
                disabled={amount === 1}
              >
                <FontAwesomeIcon icon={faChevronDown} />
              </button>
            </div>
          </div>
          <button
            className="delete-button"
            onClick={() => eventHandler(CHANGE_CART_METHOD.REMOVE, item_no)}
          >
            삭제하기
          </button>
        </CartItemAmountWrapper>
        <div className={isNotAvailableCoupon ? 'not-available-coupon' : ''}>
          {isNotAvailableCoupon ? '쿠폰 적용 불가능' : '쿠폰 적용 가능'}
        </div>
        <div className="item-price-wrapper">{`${priceToString(
          price * amount,
        )}원`}</div>
      </CartItemWrapper>
    )
  },
  (prev: CartItemProps, next: CartItemProps) => {
    const { eventHandler: prevEventHandler, ...prevProps } = prev
    const { eventHandler: nextEventHandler, ...nextProps } = next

    return JSON.stringify(prevProps) === JSON.stringify(nextProps)
  },
)

CartItem.displayName = 'CartItem'

export default CartItem
