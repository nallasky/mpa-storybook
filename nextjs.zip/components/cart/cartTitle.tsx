import React, { useEffect, useMemo } from 'react'
import { shallow } from 'zustand/shallow'
import { useRouter } from 'next/router'
import styled from '@emotion/styled'
import { useModalStore } from '@/store/modal'
import ListTitle from '@/components/common/listTitle'
import ApplyCouponModal from '@/components/modals/applyCouponModal'
import { useCartStore } from '@/store/cart'
import RemoveCheckedCartItemModal from '@/components/modals/removeCheckedCartItemModal'
import { Cart } from '@/types/cart'

const CartButtonsWrapper = styled.div`
  & button {
    outline: none;
    background-color: white;
    border-radius: 4px;
    border: 1px solid #b9b9b9;
    cursor: pointer;
    transition: all 0.2s;
    padding: 4px;
    &:not(:disabled):hover {
      background-color: #efefef;
    }
    & + button {
      margin-left: 8px;
    }
    &:disabled {
      background-color: #dadada;
      cursor: not-allowed;
    }
  }
`

const CartTitle = () => {
  const router = useRouter()
  const openModal = useModalStore((state) => state.openModal)
  const { initializeCartInfo, changeCartCheckedAll } = useCartStore()
  const list = useCartStore((state) => state.list, shallow)

  const availableCouponItemsCount: number = useMemo(() => {
    return list.filter(
      (v: Cart) => v.itemInfo.availableCoupon === undefined && v.checked,
    ).length
  }, [list])

  useEffect(() => {
    return () => initializeCartInfo()
  }, [])

  return (
    <ListTitle title="장바구니">
      <CartButtonsWrapper>
        <button onClick={() => router.back()}>이전 페이지로 돌아가기</button>
        <button
          onClick={() => {
            openModal({
              Component: ApplyCouponModal,
              props: {},
            })
          }}
          disabled={!list.length || !availableCouponItemsCount}
        >
          쿠폰 적용하기
        </button>
        <button onClick={changeCartCheckedAll} disabled={!list.length}>
          전체 상품 선택/해제
        </button>
        <button
          onClick={() =>
            openModal({ Component: RemoveCheckedCartItemModal, props: {} })
          }
          disabled={!list.length}
        >
          선택된 상품 모두 삭제
        </button>
      </CartButtonsWrapper>
    </ListTitle>
  )
}

export default CartTitle
