import React from 'react'
import { useRouter } from "next/router";
import styled from '@emotion/styled'
import { useModalStore } from "@/store/modal";
import ListTitle from '@/components/common/listTitle'
import ApplyCouponModal from "@/components/modals/applyCouponModal";

const CartButtonsWrapper = styled.div`
  & button {
    outline: none;
    background-color: white;
    border-radius: 4px;
    border: 1px solid #b9b9b9;
    cursor: pointer;
    transition: all 0.2s;
    padding: 4px;
    &:hover {
      background-color: #efefef;
    }
    & + button {
      margin-left: 8px;
    }
  }
`

const CartTitle = () => {
  const router = useRouter()
  const openModal = useModalStore((state) => state.openModal)

  return (
    <ListTitle title="장바구니">
      <CartButtonsWrapper>
        <button onClick={() => router.back()}>이전 페이지로 돌아가기</button>
        <button
          onClick={() => {
            openModal({
              Component: ApplyCouponModal,
              props: {}
            })
          }}
        >
          쿠폰 적용하기
        </button>
        <button>선택된 상품 모두 삭제</button>
      </CartButtonsWrapper>
    </ListTitle>
  )
}

export default CartTitle
