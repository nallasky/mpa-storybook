import React from 'react'
import { CommonModalContent } from '@/styles/styles'

interface AlertModalProps {
  children: React.ReactNode
  buttonText: string
  buttonHandler: () => void
}

const AlertModal = ({
  children,
  buttonText,
  buttonHandler,
}: AlertModalProps) => {
  return (
    <CommonModalContent>
      <div className="modal-content-body">{children}</div>
      <div className="modal-content-footer">
        <button className="single-button" onClick={buttonHandler}>
          {buttonText}
        </button>
      </div>
    </CommonModalContent>
  )
}

export default AlertModal
