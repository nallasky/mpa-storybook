import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons'
import { CommonModalContent } from '@/styles/styles'

interface AlertModalProps {
  title: string
  buttonHandler?: () => void
  onClose: () => void
}

const AlertModal = ({ title, buttonHandler, onClose }: AlertModalProps) => {
  return (
    <CommonModalContent>
      <div className="modal-content-body">
        <FontAwesomeIcon icon={faCheckCircle} size="5x" />
        <p>{title}</p>
      </div>
      <div className="modal-content-footer">
        <button
          className="single-button"
          onClick={() => {
            if (buttonHandler) {
              buttonHandler()
            }
            onClose()
          }}
          data-testid="alert-modal-single-button"
        >
          닫기
        </button>
      </div>
    </CommonModalContent>
  )
}

export default AlertModal
