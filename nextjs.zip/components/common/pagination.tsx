import styled from '@emotion/styled'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faAngleLeft, faAngleRight } from '@fortawesome/free-solid-svg-icons'

const PaginationWrapper = styled.div`
  display: flex;
  column-gap: 8px;
  align-items: center;
`

const PaginationButton = styled.button`
  padding: 8px 16px;
  outline: none;
  border: 1px solid transparent;
  background-color: white;
  border-radius: 4px;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s;
  &:hover:not(:disabled):not(.selected) {
    background-color: rgba(0, 0, 0, 0.06);
  }
  &:disabled {
    color: rgba(0, 0, 0, 0.25);
    cursor: not-allowed;
  }
  &.selected {
    border-color: #1890ff;
    color: #1890ff;
    font-weight: bold;
  }
`

interface PaginationProps {
  limit: number
  currentPage: number
  itemPerPage: number
  onPageChange: (page: number) => void
}

const Pagination = ({
  limit,
  currentPage,
  itemPerPage,
  onPageChange,
}: PaginationProps) => {
  const maxPage = Math.ceil(limit / itemPerPage)
  const pageArr: number[] = []

  for (let i = 1; i <= maxPage; i++) {
    pageArr.push(i)
  }

  if (!limit || limit <= itemPerPage) return <></>

  return (
    <PaginationWrapper>
      <PaginationButton
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        data-testid="pagination-move-prev-page"
      >
        <FontAwesomeIcon icon={faAngleLeft} />
      </PaginationButton>
      {pageArr.map((i) => (
        <PaginationButton
          key={i}
          className={i === currentPage ? 'selected' : ''}
          onClick={() => onPageChange(i)}
          data-testid={`pagination-move-page-${i}`}
        >
          {i}
        </PaginationButton>
      ))}
      <PaginationButton
        onClick={() => onPageChange(currentPage + 1)}
        disabled={maxPage === currentPage}
        data-testid="pagination-move-next-page"
      >
        <FontAwesomeIcon icon={faAngleRight} />
      </PaginationButton>
    </PaginationWrapper>
  )
}

export default Pagination
