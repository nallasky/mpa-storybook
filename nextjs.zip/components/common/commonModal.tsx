import React from 'react'
import styled from '@emotion/styled'
import { CSSTransition, TransitionGroup } from 'react-transition-group'
import { useModalStore, Modal } from '@/store/modal'

const ModalBackGround = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  backdrop-filter: blur(2px);
  z-index: 10000;
`

const CommonModal = () => {
  const { currentModals, closeModal } = useModalStore()

  const close = (component: (props: unknown) => JSX.Element) => {
    closeModal(component)
  }

  return (
    <TransitionGroup className="common-modals">
      {currentModals.map((modalInfo: Modal, idx) => {
        const { Component, props } = modalInfo
        const itemRef = React.createRef<HTMLDivElement>()

        const onClose = () => {
          close(Component)
        }

        return (
          <CSSTransition
            key={idx}
            timeout={200}
            classNames="common-modal"
            nodeRef={itemRef}
          >
            <ModalBackGround ref={itemRef}>
              <Component {...props} onClose={onClose} />
            </ModalBackGround>
          </CSSTransition>
        )
      })}
    </TransitionGroup>
  )
}

export default CommonModal
