import React, { ReactNode } from 'react'
import styled from '@emotion/styled'

interface ListTitleProps {
  title: string
  children?: ReactNode
}

const ListTitleWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
`

const ListTitle = ({ title, children }: ListTitleProps) => {
  return (
    <ListTitleWrapper>
      <h2>{title}</h2>
      {children}
    </ListTitleWrapper>
  )
}

ListTitle.defaultProps = {
  children: <></>,
}

export default ListTitle
