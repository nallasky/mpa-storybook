import React from 'react'
import styled from '@emotion/styled'

const CheckBoxWrapper = styled.label`
  position: relative;
  display: inline-block;
  & > input[type='checkbox'] {
    display: none;
    &:focus + span::before {
      box-shadow: 0 0 0 2px rgba(51, 51, 51, 0.5);
    }
    &:checked + span::after {
      transform: scale(1);
    }
  }
  & > span {
    display: inline-block;
    padding-left: 1.4rem;
    cursor: pointer;
    font-size: 14px;
    &::before {
      position: absolute;
      left: 0;
      top: 4px;
      height: 16px;
      width: 16px;
      border: 1px solid rgba(51, 51, 51, 0.13);
      border-radius: 4px;
      content: '';
      transition: all 0.25s;
    }
    &::after {
      position: absolute;
      left: 2px;
      top: 6px;
      content: '';
      width: 14px;
      height: 14px;
      background-color: rgba(51, 51, 51, 0.8);
      border-radius: 4px;
      transition: all 0.25s;
      transform: scale(0);
    }
  }
`

interface CommonCheckBoxProps {
  label?: string
  checked: boolean
  onChangeHandler: () => void
}

const CommonCheckBox = ({
  label,
  checked,
  onChangeHandler,
}: CommonCheckBoxProps) => {
  return (
    <CheckBoxWrapper>
      <input type="checkbox" checked={checked} onChange={onChangeHandler} />
      <span>{label}</span>
    </CheckBoxWrapper>
  )
}

CommonCheckBox.defaultProps = {
  label: '',
}

export default CommonCheckBox
