import React from 'react'
import styled from '@emotion/styled'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons'

const EmptyWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  row-gap: 16px;
  & > p {
    font-size: 18px;
  }
`

interface ListEmptyProps {
  message: string
}

const ListEmpty = ({ message }: ListEmptyProps) => {
  return (
    <EmptyWrapper>
      <FontAwesomeIcon icon={faExclamationCircle} size="7x" />
      <p>{message}</p>
    </EmptyWrapper>
  )
}

export default ListEmpty
