import React from 'react'
import { CommonModalContent } from '@/styles/styles'

interface ConfirmModalProps {
  children: React.ReactNode
  leftButtonLText: string
  leftButtonHandlers: () => void
  rightButtonLText: string
  rightButtonHandlers: () => void
}

const ConfirmModal = ({
  children,
  leftButtonLText,
  leftButtonHandlers,
  rightButtonLText,
  rightButtonHandlers,
}: ConfirmModalProps) => {
  return (
    <CommonModalContent>
      <div className="modal-content-body">{children}</div>
      <div className="modal-content-footer">
        <button onClick={leftButtonHandlers}>{leftButtonLText}</button>
        <button onClick={rightButtonHandlers}>{rightButtonLText}</button>
      </div>
    </CommonModalContent>
  )
}

export default ConfirmModal
