import React from 'react'
import { CommonModalContent } from '@/styles/styles'

interface ConfirmModalProps {
  children: React.ReactNode
  leftButtonText: string
  leftButtonHandlers: () => void
  rightButtonText: string
  rightButtonHandlers: () => void
}

const ConfirmModal = ({
  children,
  leftButtonText,
  leftButtonHandlers,
  rightButtonText,
  rightButtonHandlers,
}: ConfirmModalProps) => {
  return (
    <CommonModalContent>
      <div className="modal-content-body">{children}</div>
      <div className="modal-content-footer">
        <button
          onClick={leftButtonHandlers}
          data-testid="common-modal-left-button"
        >
          {leftButtonText}
        </button>
        <button
          onClick={rightButtonHandlers}
          data-testid="common-modal-right-button"
        >
          {rightButtonText}
        </button>
      </div>
    </CommonModalContent>
  )
}

export default ConfirmModal
