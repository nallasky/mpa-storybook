import React from 'react'
import { useQuery } from '@tanstack/react-query'
import styled from '@emotion/styled'
import ProductItem from './productItem'
import { useModalStore } from '@/store/modal'
import { useCartStore } from '@/store/cart'
import { Cart } from "@/types/cart";
import ChangeCartModal from '@/components/modals/changeCartModal'
import { getProducts } from '@/utils/api/products/products'
import { ProductListItem } from '@/types/products'
import ListEmpty from '@/components/common/listEmpty'

const ProductItemList = styled.ul`
  display: flex;
  width: 100%;
  column-gap: 16px;
  min-height: 335.19px;
  & > li {
    flex-basis: calc(((var(--container-width) - (16px * 4)) / 5));
  }
`

interface ProductListProps {
  offset: number
}

const ProductList = ({ offset }: ProductListProps) => {
  const { openModal } = useModalStore()
  const { list, addCart, removeCart } = useCartStore()

  const { data } = useQuery(['products'], getProducts)

  const cartClickHandler = (type: string, id: number) => {
    const findItemAmount = list.find(
      (item: Cart) => item.itemInfo.item_no === id,
    )?.amount
    let alreadyAdded: boolean
    if (type === 'add') {
      alreadyAdded = !!findItemAmount
      addCart(data.find((v: ProductListItem) => v.item_no === id))
    } else {
      alreadyAdded = findItemAmount !== 1
      removeCart(id)
    }
    openModal({
      Component: ChangeCartModal,
      props: {
        type,
        alreadyAdded,
      },
    })
  }

  if (!data || !data.length) {
    return <ListEmpty message="표시할 상품이 없습니다." />
  }

  const sortedData: ProductListItem[] = data.sort(
    (a: ProductListItem, b: ProductListItem) => b.score - a.score,
  )

  return (
    <ProductItemList data-testid="product-item-list">
      {sortedData.slice(offset, offset + 5).map((v: ProductListItem) => {
        const { item_no } = v
        const findItemFromCart = list.find(
          (item: Cart) => item.itemInfo.item_no === item_no,
        )
        return (
          <ProductItem
            key={item_no}
            amount={findItemFromCart?.amount ?? 0}
            cartClickHandler={cartClickHandler}
            disabledAddCartButton={list.length === 3 && !findItemFromCart}
            {...v}
          />
        )
      })}
    </ProductItemList>
  )
}

export default ProductList
