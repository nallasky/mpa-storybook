import React from 'react'
import { useQuery } from '@tanstack/react-query'
import styled from '@emotion/styled'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons'
import ProductItem from './productItem'
import { useModalStore } from '@/store/modal'
import { useCartStore, CartItem } from '@/store/cart'
import ChangeCartModal from '@/components/modals/changeCartModal'
import { getProducts } from '@/utils/api/products/products'
import { ProductListItem } from '@/types/products'

const ProductItemList = styled.ul`
  display: flex;
  width: 100%;
  column-gap: 16px;
  min-height: 335.19px;
  & > li {
    flex-basis: calc(((var(--container-width) - (16px * 4)) / 5));
  }
`

const ProductEmpty = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  row-gap: 16px;
  & > p {
    font-size: 18px;
  }
`

interface ProductListProps {
  offset: number
}

const ProductList = ({ offset }: ProductListProps) => {
  const { openModal } = useModalStore()
  const { list, total, addCart, removeCart } = useCartStore()

  const { data } = useQuery(['products'], getProducts)

  const cartClickHandler = (type: string, id: number) => {
    const findItemAmount = list.find((item: CartItem) => item.id === id)?.amount
    let alreadyAdded: boolean
    if (type === 'add') {
      alreadyAdded = !!findItemAmount
      addCart(id)
    } else {
      alreadyAdded = findItemAmount !== 1
      removeCart(id)
    }
    openModal({
      Component: ChangeCartModal,
      props: {
        type,
        alreadyAdded,
      },
    })
  }

  if (!data || !data.length) {
    return (
      <ProductEmpty>
        <FontAwesomeIcon icon={faExclamationCircle} size="7x" />
        <p>표시할 상품이 없습니다.</p>
      </ProductEmpty>
    )
  }

  return (
    <ProductItemList data-testid="product-item-list">
      {data.slice(offset, offset + 5).map((v: ProductListItem) => {
        const { item_no } = v
        const findItemFromCart = list.find(
          (item: CartItem) => item.id === item_no,
        )
        return (
          <ProductItem
            key={item_no}
            amount={findItemFromCart?.amount ?? 0}
            cartClickHandler={cartClickHandler}
            disabledAddCartButton={total === 3 && !findItemFromCart}
            {...v}
          />
        )
      })}
    </ProductItemList>
  )
}

export default ProductList
