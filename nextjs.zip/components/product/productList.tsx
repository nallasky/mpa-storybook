import React from 'react'
import { shallow } from 'zustand/shallow'
import styled from '@emotion/styled'
import ProductItem from './productItem'
import { useModalStore } from '@/store/modal'
import { useCartStore } from '@/store/cart'
import { Cart, clickCartType, CLICK_CART_METHOD } from '@/types/cart'
import ChangeCartModal from '@/components/modals/changeCartModal'
import AlertModal from '@/components/common/alertModal'
import { ProductListItem } from '@/types/products'
import ListEmpty from '@/components/common/listEmpty'
import { MAX_CART_LENGTH, SHOW_ITEM_PER_PAGE } from '@/constants/config'
import { Modal } from '@/types/modal'

const ProductItemList = styled.ul`
  display: flex;
  width: 100%;
  column-gap: 16px;
  min-height: 335.19px;
  & > li {
    flex-basis: calc(((var(--container-width) - (16px * ${SHOW_ITEM_PER_PAGE - 1})) / ${SHOW_ITEM_PER_PAGE}));
  }
`

interface ProductListProps {
  data: ProductListItem[]
}

const ProductList = ({ data }: ProductListProps) => {
  const { openModal } = useModalStore()
  const list: Cart[] = useCartStore((state) => state.list, shallow)
  const { addCart, removeCart } = useCartStore()

  const cartClickHandler = (type: clickCartType, id: number) => {
    const findItemAmount: number | undefined = list.find(
      (item: Cart) => item.itemInfo.item_no === id,
    )?.amount
    const modalInfo: Modal = {
      Component: AlertModal,
      props: {
        title:
          type === CLICK_CART_METHOD.ADD
            ? '상품을 장바구니에 추가하지 못했습니다.'
            : '상품을 장바구니에서 삭제하지 못했습니다.',
      },
    }

    if (type === CLICK_CART_METHOD.ADD) {
      const itemInfo: ProductListItem | undefined = data.find(
        (v: ProductListItem) => v.item_no === id,
      )

      if (itemInfo) {
        addCart(itemInfo)
        modalInfo.Component = ChangeCartModal
        modalInfo.props = {
          type,
          alreadyAdded: !!findItemAmount,
        }
      }
    } else if (findItemAmount !== undefined) {
      removeCart({
        id,
        amount: findItemAmount,
      })
      modalInfo.Component = ChangeCartModal
      modalInfo.props = {
        type,
        alreadyAdded: findItemAmount !== 1,
      }
    }
    openModal(modalInfo)
  }

  if (!data || !data.length) {
    return <ListEmpty message="표시할 상품이 없습니다." />
  }

  return (
    <ProductItemList data-testid="product-item-list">
      {data.map((v: ProductListItem) => {
        const { item_no, item_name, detail_image_url, price } = v
        const findItemFromCart: Cart | undefined = list.find(
          (item: Cart) => item.itemInfo.item_no === item_no,
        )
        return (
          <ProductItem
            key={item_no}
            amount={findItemFromCart?.amount ?? 0}
            cartClickHandler={cartClickHandler}
            disabledAddCartButton={
              list.length === MAX_CART_LENGTH && !findItemFromCart
            }
            item_no={item_no}
            item_name={item_name}
            detail_image_url={detail_image_url}
            price={price}
          />
        )
      })}
    </ProductItemList>
  )
}

export default ProductList
