import React from 'react'
import { shallow } from 'zustand/shallow'
import Link from 'next/link'
import styled from '@emotion/styled'
import EmptyCart from '../../public/shopping-cart-empty.png'
import { useCartStore } from '@/store/cart'
import ListTitle from '@/components/common/listTitle'

const CartLinkWrapper = styled.div`
  position: relative;
  display: inline-block;
  width: 74px;
  text-align: center;
  & > .cart-link {
    display: block;
    width: 100%;
    padding-top: 36px;
    background: url(${EmptyCart.src}) no-repeat center/36px;
    & > .cart-count {
      position: absolute;
      top: -8px;
      right: 12px;
      background-color: var(--default-font-color);
      padding: 0 8px;
      border-radius: 50%;
      text-align: center;
      color: white;
      line-height: 26px;
    }
  }
`

const ProductTitle = () => {
  const list = useCartStore((state) => state.list, shallow)

  return (
    <ListTitle title="상품 리스트">
      <CartLinkWrapper>
        <Link href="/cart" className="cart-link" aria-label="cart">
          {!!list.length && <span className="cart-count">{list.length}</span>}
        </Link>
      </CartLinkWrapper>
    </ListTitle>
  )
}

export default ProductTitle
