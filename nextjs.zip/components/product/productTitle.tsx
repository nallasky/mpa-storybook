import styled from '@emotion/styled'
import EmptyCart from '../../public/shopping-cart-empty.png'
import { useCartStore } from '@/store/cart'
import ListTitle from '@/components/common/listTitle'

const CartLinkWrapper = styled.div`
  position: relative;
  display: inline-block;
  width: 74px;
  text-align: center;
  & > .cart-link {
    display: block;
    width: 100%;
    padding-top: 36px;
    background: url(${EmptyCart.src}) no-repeat center/36px;
    & > .cart-count {
      position: absolute;
      top: -8px;
      right: 12px;
      background-color: #333;
      padding: 0 8px;
      border-radius: 50%;
      text-align: center;
      color: white;
      line-height: 26px;
    }
  }
`

const ProductTitle = () => {
  const { total } = useCartStore()

  return (
    <ListTitle title="상품 리스트">
      <CartLinkWrapper>
        <a href="#" className="cart-link">
          {!!total && <span className="cart-count">{total}</span>}
        </a>
      </CartLinkWrapper>
    </ListTitle>
  )
}

export default ProductTitle
