import React from 'react'
import styled from '@emotion/styled'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons'
import EmptyCart from '../../public/shopping-cart-empty.png'
import AddCart from '../../public/add-cart.png'
import RemoveCart from '../../public/remove-cart.png'
import { priceToString } from '@/utils/common/functions'
import { clickCartType, CLICK_CART_METHOD } from '@/types/cart'

const ProductCard = styled.div`
  display: flex;
  flex-direction: column;
  row-gap: 8px;
  height: fit-content;
  & > * {
    cursor: default;
  }
  & > .product-card-header {
    position: relative;
    width: 100%;
    &:hover {
      & > .cart-buttons,
      & > .prevent-add {
        opacity: 0.9 !important;
      }
    }
    & > .prevent-add {
      position: absolute;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      row-gap: 4px;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      opacity: 0;
      border-radius: 4px;
      background-color: white;
      transition: all 0.2s;
    }
    & > .image-box {
      overflow: hidden;
      border-radius: 4px;
      position: relative;
      width: 100%;
      padding-top: 100%;
      background-color: #f3f3f3;
      & > img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        image-rendering: pixelated;
      }
    }
    & > .cart-buttons {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      display: flex;
      border-radius: 4px;
      overflow: hidden;
      opacity: 0;
      transition: all 0.2s;
      & > button {
        outline: none;
        flex: 0 1 50%;
        border: none;
        font-size: 32px;
        cursor: pointer;
        &.add-cart-button {
          background: url(${AddCart.src}) no-repeat center/50% #f0f0f0;
        }
        &.remove-cart-button {
          background: url(${RemoveCart.src}) no-repeat center/50% #f0f0f0;
        }
      }
    }
  }
  & > .product-card-body {
    display: flex;
    flex-direction: column;
    row-gap: 4px;
    & > .price-and-cart {
      display: flex;
      align-items: center;
      justify-content: space-between;
      & > .cart-icon {
        width: 32px;
        height: 32px;
        border: 1px solid transparent;
        background: url(${EmptyCart.src}) no-repeat center/50%;
        & > .amount-text {
          display: inline-block;
          width: 100%;
          height: 100%;
          border-radius: 50%;
          color: white;
          text-align: center;
          background-color: var(--default-font-color);
          line-height: 1.8;
          opacity: 0;
        }
        &.show-amount-text {
          & > .amount-text {
            opacity: 1;
          }
        }
      }
    }
    & > .name {
      display: -webkit-box;
      max-height: 48px;
      overflow: hidden;
      word-break: break-all;
      text-overflow: ellipsis;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
  }
`

interface ProductItemProps {
  item_no: number
  item_name: string
  detail_image_url: string
  price: number
  amount: number
  disabledAddCartButton: boolean
  cartClickHandler: (type: clickCartType, id: number) => void
}

const ProductItem = React.memo(
  ({
    item_no,
    item_name,
    detail_image_url,
    price,
    amount,
    disabledAddCartButton,
    cartClickHandler,
  }: ProductItemProps) => {
    return (
      <li>
        <ProductCard>
          <div className="product-card-header">
            <div className="image-box">
              <img src={detail_image_url} alt="Product Item" />
            </div>
            {disabledAddCartButton ? (
              <div className="prevent-add">
                <FontAwesomeIcon icon={faExclamationCircle} size="4x" />
                <p>장바구니에 담을 수 없습니다.</p>
                <p>(최대 등록 가능한 상품 수: 3개)</p>
              </div>
            ) : (
              <div className="cart-buttons">
                <button
                  className="add-cart-button"
                  onClick={() =>
                    cartClickHandler(CLICK_CART_METHOD.ADD, item_no)
                  }
                  disabled={disabledAddCartButton}
                  aria-label="add-cart-button"
                  data-testid="product-item-add-cart-button"
                />
                <button
                  className="remove-cart-button"
                  onClick={() =>
                    cartClickHandler(CLICK_CART_METHOD.REMOVE, item_no)
                  }
                  disabled={!amount}
                  aria-label="remove-cart-button"
                  data-testid="product-item-remove-cart-button"
                />
              </div>
            )}
          </div>
          <div className="product-card-body">
            <div className="price-and-cart">
              <strong>{`${priceToString(price)}원`}</strong>
              <div
                className={'cart-icon' + (amount ? ' show-amount-text' : '')}
                data-testid="product-item-amount-text-wrapper"
              >
                <span
                  className="amount-text"
                  data-testid="product-item-amount-text"
                >
                  {amount}
                </span>
              </div>
            </div>
            <div className="name" title={item_name}>
              {item_name}
            </div>
          </div>
        </ProductCard>
      </li>
    )
  },
  (prev: ProductItemProps, next: ProductItemProps) => {
    const { cartClickHandler: prevCartClickHandler, ...prevProps } = prev
    const { cartClickHandler: nextCartClickHandler, ...nextProps } = next

    return JSON.stringify(prevProps) === JSON.stringify(nextProps)
  },
)

ProductItem.displayName = 'ProductItem'

export default ProductItem
