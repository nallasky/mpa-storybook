import React from 'react'
import { useRouter } from 'next/router'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons'
import ConfirmModal from '@/components/common/confirmModal'

interface ChangeCartModalMessageProps {
  type: string
  alreadyAdded: boolean
}

const ModalMessage = ({ type, alreadyAdded }: ChangeCartModalMessageProps) => {
  if (type === 'remove') {
    return (
      <p>
        {alreadyAdded
          ? '선택한 상품의 수량이 1개 감소하였습니다.'
          : '선택한 상품이 장바구니에서 삭제되었습니다.'}
      </p>
    )
  }

  return (
    <p>
      {alreadyAdded
        ? '선택한 상품의 수량이 1개 추가되었습니다.'
        : '장바구니에 상품이 추가되었습니다.'}
    </p>
  )
}

interface ChangeCartModalProps extends ChangeCartModalMessageProps {
  onClose: () => void
}

const ChangeCartModal = ({
  type,
  alreadyAdded,
  onClose,
}: ChangeCartModalProps) => {
  const router = useRouter()

  return (
    <ConfirmModal
      leftButtonText="계속 쇼핑하기"
      leftButtonHandlers={onClose}
      rightButtonText="장바구니로 이동하기"
      rightButtonHandlers={() => {
        onClose()
        router.push('/cart')
      }}
    >
      <FontAwesomeIcon icon={faCheckCircle} size="5x" />
      <ModalMessage type={type} alreadyAdded={alreadyAdded} />
    </ConfirmModal>
  )
}

export default ChangeCartModal
