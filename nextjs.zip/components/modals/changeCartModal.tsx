import React from 'react'
import styled from '@emotion/styled'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons'

const ModalContent = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 100000;
  width: 400px;
  background-color: white;
  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3),
    0 2px 6px 2px rgba(60, 64, 67, 0.15);
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  row-gap: 16px;
  & > .modal-content-body {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    row-gap: 16px;
    padding: 16px 16px 0 16px;
  }
  & > .modal-content-footer {
    display: flex;
    overflow: hidden;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    & > button {
      outline: none;
      border: none;
      height: 48px;
      cursor: pointer;
      transition: all 0.2s;
      &:hover {
        opacity: 0.75;
      }
      &.go-shopping-button {
        flex-basis: 50%;
        background-color: #333;
        color: white;
      }
      &.go-cart-button {
        flex-basis: 50%;
        background-color: rgba(0, 0, 0, 0.2);
      }
    }
  }
`

interface ChangeCartModalMessageProps {
  type: string
  alreadyAdded: boolean
}

const ModalMessage = ({ type, alreadyAdded }: ChangeCartModalMessageProps) => {
  if (type === 'remove') {
    return (
      <p>
        {alreadyAdded
          ? '선택한 상품의 수량이 1개 감소하였습니다.'
          : '선택한 상품이 장바구니에서 삭제되었습니다.'}
      </p>
    )
  }

  return (
    <p>
      {alreadyAdded
        ? '선택한 상품의 수량이 1개 추가되었습니다.'
        : '장바구니에 상품이 추가되었습니다.'}
    </p>
  )
}

interface ChangeCartModalProps extends ChangeCartModalMessageProps {
  onClose: () => void
}

const ChangeCartModal = ({
  type,
  alreadyAdded,
  onClose,
}: ChangeCartModalProps) => {
  return (
    <ModalContent>
      <div className="modal-content-body">
        <FontAwesomeIcon icon={faCheckCircle} size="5x" />
        <ModalMessage type={type} alreadyAdded={alreadyAdded} />
      </div>
      <div className="modal-content-footer">
        <button
          className="go-shopping-button"
          data-testid="change-cart-modal-left-button"
          onClick={onClose}
        >
          계속 쇼핑하기
        </button>
        <button
          className="go-cart-button"
          data-testid="change-cart-modal-right-button"
          onClick={onClose}
        >
          장바구니로 이동하기
        </button>
      </div>
    </ModalContent>
  )
}

export default ChangeCartModal
