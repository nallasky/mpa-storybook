import React, { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import styled from '@emotion/styled'
import { getCoupons } from '@/utils/api/coupons/coupons'
import { useCartStore } from '@/store/cart'
import { Coupon } from '@/types/coupons'
import ConfirmModal from '@/components/common/confirmModal'

const RadioWrapper = styled.div`
  width: 100%;
  & > label {
    & > input[type='radio'] {
      display: none;
      &:checked + .label-name {
        background-color: var(--default-font-color);
        color: white;
      }
    }
    & > .label-name {
      display: inline-block;
      width: 100%;
      padding: 8px;
      border: 1px solid var(--default-font-color);
      border-radius: 4px;
      transition: all 0.2s;
      cursor: pointer;
      text-align: center;
    }
  }
`

interface CouponListItemProps {
  title: string
  checked: boolean
  eventHandler: (title: string) => void
}

const CouponListItem = ({
  title,
  checked,
  eventHandler,
}: CouponListItemProps) => {
  return (
    <RadioWrapper>
      <label>
        <input
          type="radio"
          checked={checked}
          onChange={() => eventHandler(title)}
        />
        <span className="label-name">{title}</span>
      </label>
    </RadioWrapper>
  )
}

interface ApplyCouponModalProps {
  onClose: () => void
}

const ApplyCouponModal = ({ onClose }: ApplyCouponModalProps) => {
  const { coupon, changeCoupon } = useCartStore()
  const { data } = useQuery(['coupons'], getCoupons)

  const couponInfo: any = coupon

  const [currentCoupon, setCurrentCoupon] = useState(
    couponInfo?.title ?? 'none',
  )

  const onApply = () => {
    let newCoupon: Coupon | object = {}

    if (currentCoupon !== 'none') {
      newCoupon = data.find((v: Coupon) => v.title === currentCoupon)
    }

    changeCoupon(newCoupon)
    onClose()
  }

  return (
    <ConfirmModal
      leftButtonLText="적용하기"
      leftButtonHandlers={onApply}
      rightButtonLText="닫기"
      rightButtonHandlers={onClose}
    >
      {data.map((v: Coupon) => {
        return (
          <CouponListItem
            key={v.title}
            title={v.title}
            checked={v.title === currentCoupon}
            eventHandler={(title: string) => setCurrentCoupon(title)}
          />
        )
      })}
      <RadioWrapper>
        <label>
          <input
            type="radio"
            checked={currentCoupon === 'none'}
            onChange={() => setCurrentCoupon('none')}
          />
          <span className="label-name">쿠폰 적용 안함</span>
        </label>
      </RadioWrapper>
    </ConfirmModal>
  )
}

export default ApplyCouponModal
