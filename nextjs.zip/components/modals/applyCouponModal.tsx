import React from 'react'
import styled from "@emotion/styled";
import { CommonModalContent } from "@/styles/styles";

const RadioWrapper = styled.div`
  width: 100%;
  & > label {
    & > input[type='radio'] {
      display: none;
      &:checked + .label-name {
        background-color: var(--default-font-color);
        color: white;
      }
    }
    & > .label-name {
      display: inline-block;
      width: 100%;
      padding: 8px;
      border: 1px solid var(--default-font-color);
      border-radius: 4px;
      transition: all 0.2s;
      cursor: pointer;
    }
  }
`

interface ApplyCouponModalProps {
  onClose: () => void
}

const ApplyCouponModal = ({ onClose }) => {
  return (
    <CommonModalContent>
      <div className="modal-content-body">
        <RadioWrapper>
          <label>
            <input type="radio" checked />
            <span className="label-name">10% 할인 쿠폰</span>
          </label>
        </RadioWrapper>
        <RadioWrapper>
          <label>
            <input type="radio" />
            <span className="label-name">5000원 할인 쿠폰</span>
          </label>
        </RadioWrapper>
        <RadioWrapper>
          <label>
            <input type="radio" />
            <span className="label-name">쿠폰 적용 안함</span>
          </label>
        </RadioWrapper>
      </div>
      <div className="modal-content-footer">
        <button>적용하기</button>
        <button onClick={onClose}>닫기</button>
      </div>
    </CommonModalContent>
  )
}

export default ApplyCouponModal