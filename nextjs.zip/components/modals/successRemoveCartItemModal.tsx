import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons'
import AlertModal from '@/components/common/alertModal'

interface SuccessRemoveCartItemModalProps {
  onClose: () => void
}

const SuccessRemoveCartItemModal = ({
  onClose,
}: SuccessRemoveCartItemModalProps) => {
  return (
    <AlertModal buttonText="닫기" buttonHandler={onClose}>
      <FontAwesomeIcon icon={faCheckCircle} size="5x" />
      <p>선택한 상품이 삭제 됐습니다.</p>
    </AlertModal>
  )
}

export default SuccessRemoveCartItemModal
