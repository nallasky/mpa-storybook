import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons'
import ConfirmModal from '@/components/common/confirmModal'
import { useCartStore } from '@/store/cart'
import { useModalStore } from '@/store/modal'
import AlertModal from '@/components/common/alertModal'
import { CHANGE_CART_METHOD } from '@/types/cart'

interface RemoveCheckedCartItemModalProps {
  itemId?: number
  onClose: () => void
}

const RemoveCheckedCartItemModal = ({
  itemId = undefined,
  onClose,
}: RemoveCheckedCartItemModalProps) => {
  const openModal = useModalStore((state) => state.openModal)
  const { removeCheckedCart, changeCartInfo } = useCartStore()

  const onDelete = () => {
    if (itemId !== undefined) {
      changeCartInfo({
        type: CHANGE_CART_METHOD.REMOVE,
        id: itemId,
      })
    } else {
      removeCheckedCart()
    }
    onClose()
    setTimeout(() => {
      openModal({
        Component: AlertModal,
        props: {
          title: '선택한 상품이 삭제 됐습니다.',
        },
      })
    }, 210)
  }

  return (
    <ConfirmModal
      leftButtonText="삭제하기"
      leftButtonHandlers={onDelete}
      rightButtonText="닫기"
      rightButtonHandlers={onClose}
    >
      <FontAwesomeIcon icon={faTrashAlt} size="5x" />
      <p>상품을 삭제 하시겠습니까?</p>
    </ConfirmModal>
  )
}

export default RemoveCheckedCartItemModal
