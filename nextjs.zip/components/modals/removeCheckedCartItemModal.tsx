import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons'
import ConfirmModal from '@/components/common/confirmModal'
import { useCartStore } from '@/store/cart'
import { useModalStore } from '@/store/modal'
import SuccessRemoveCartItemModal from '@/components/modals/successRemoveCartItemModal'

interface RemoveCheckedCartItemModalProps {
  itemId?: number
  onClose: () => void
}

const RemoveCheckedCartItemModal = ({
  itemId,
  onClose,
}: RemoveCheckedCartItemModalProps) => {
  const openModal = useModalStore((state) => state.openModal)
  const { removeCheckedCart, changeCartInfo } = useCartStore()

  const onDelete = () => {
    if (itemId !== undefined) {
      changeCartInfo('remove', itemId)
    } else {
      removeCheckedCart()
    }
    onClose()
    setTimeout(() => {
      openModal({ Component: SuccessRemoveCartItemModal, props: {} })
    }, 210)
  }

  return (
    <ConfirmModal
      leftButtonText="삭제하기"
      leftButtonHandlers={onDelete}
      rightButtonText="닫기"
      rightButtonHandlers={onClose}
    >
      <FontAwesomeIcon icon={faTrashAlt} size="5x" />
      <p>상품을 삭제 하시겠습니까?</p>
    </ConfirmModal>
  )
}

RemoveCheckedCartItemModal.defaultProps = {
  itemId: undefined,
}

export default RemoveCheckedCartItemModal
