import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons'
import ConfirmModal from '@/components/common/confirmModal'
import { useCartStore } from '@/store/cart'
import { useModalStore } from '@/store/modal'
import SuccessRemoveCartItemModal from '@/components/modals/successRemoveCartItemModal'

interface RemoveCheckedCartItemModalProps {
  onClose: () => void
}

const RemoveCheckedCartItemModal = ({
  onClose,
}: RemoveCheckedCartItemModalProps) => {
  const openModal = useModalStore((state) => state.openModal)
  const removeCheckedCart = useCartStore((state) => state.removeCheckedCart)

  const onDelete = () => {
    removeCheckedCart()
    onClose()
    setTimeout(() => {
      openModal({ Component: SuccessRemoveCartItemModal, props: {} })
    }, 200)
  }

  return (
    <ConfirmModal
      leftButtonLText="삭제하기"
      leftButtonHandlers={onDelete}
      rightButtonLText="닫기"
      rightButtonHandlers={onClose}
    >
      <FontAwesomeIcon icon={faTrashAlt} size="5x" />
      <p>선택한 상품을 모두 삭제 하시겠습니까?</p>
    </ConfirmModal>
  )
}

export default RemoveCheckedCartItemModal
