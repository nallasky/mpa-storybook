"use strict";
(() => {
var exports = {};
exports.id = 345;
exports.ids = [345];
exports.modules = {

/***/ 8207:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/add-cart.41039e5d.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAaElEQVR42jXKIQrCUAAA0IdiVvAkJssXTB7BoKJmkyZP4AG0fQxisnsbkW1leWFlsLAt7eXH0gosRAEmHqbmGn+1ACeZKDWWiDDTOsv9lAKMVAo3XxcYYOvu6mgNQ7w98fHqx84Bexs6xsIYC6Fs/nYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 2206:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/remove-cart.ba92d7ee.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAaUlEQVR42jXKIQ6CUAAA0Ded3c2TWCzqZvIIBnU6jRZn8gIeQE1sBEZi41CQqBQCgfAJjPr22NmDra81zP0trARBN9BDIVK6KUWwFDxVgsYGZlq1j9wLJjj5ebs7wBSpGJlkHGdXXBzpAfczGJf3RWMpAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 8098:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/shopping-cart-empty.cc176331.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAZElEQVR42lXBIQ6CAAAAwMNpUKObU/+g1dncMDs3i8UH6NQZCDA6gQKDROEVfIifkLkjdjeyUki8ff18pPBws7CzsVbD3hOw9YepXOjiKHImQK1VaWTmTHDQC3VKCLD0MnN1YgDdgA84xlJYzwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 998:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4115);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4563);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _emotion_styled__WEBPACK_IMPORTED_MODULE_1__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _emotion_styled__WEBPACK_IMPORTED_MODULE_1__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const PaginationWrapper = /*#__PURE__*/ (0,_emotion_styled__WEBPACK_IMPORTED_MODULE_1__["default"])("div", {
    target: "e1l6ppb90"
})("display:flex;column-gap:8px;align-items:center;");
const Button = /*#__PURE__*/ (0,_emotion_styled__WEBPACK_IMPORTED_MODULE_1__["default"])("button", {
    target: "e1l6ppb91"
})("padding:8px 16px;outline:none;border:1px solid transparent;background-color:white;border-radius:4px;font-size:14px;cursor:pointer;transition:all 0.2s;&:hover:not(:disabled):not(.selected){background-color:rgba(0,0,0,0.06);}&:disabled{color:rgba(0,0,0,0.25);cursor:not-allowed;}&.selected{border-color:#1890ff;color:#1890ff;font-weight:bold;}");
const Pagination = ({ limit , currentPage , itemPerPage , onPageChange  })=>{
    const maxPage = Math.ceil(limit / itemPerPage);
    const pageArr = [];
    for(let i = 1; i <= maxPage; i++){
        pageArr.push(i);
    }
    if (!limit || limit <= itemPerPage) return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(PaginationWrapper, {
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Button, {
                onClick: ()=>onPageChange(currentPage - 1),
                disabled: currentPage === 1,
                "data-testid": "pagination-move-prev-page",
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__.FontAwesomeIcon, {
                    icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__.faAngleLeft
                })
            }),
            pageArr.map((i)=>/*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Button, {
                    className: i === currentPage ? "selected" : "",
                    onClick: ()=>onPageChange(i),
                    "data-testid": `pagination-move-page-${i}`,
                    children: i
                }, i)),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Button, {
                onClick: ()=>onPageChange(currentPage + 1),
                disabled: maxPage === currentPage,
                "data-testid": "pagination-move-next-page",
                children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__.FontAwesomeIcon, {
                    icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__.faAngleRight
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pagination);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5873:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4563);
/* harmony import */ var _components_common_confirmModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7769);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__, _components_common_confirmModal__WEBPACK_IMPORTED_MODULE_5__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__, _components_common_confirmModal__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const ModalMessage = ({ type , alreadyAdded  })=>{
    if (type === "remove") {
        return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            children: alreadyAdded ? "선택한 상품의 수량이 1개 감소하였습니다." : "선택한 상품이 장바구니에서 삭제되었습니다."
        });
    }
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        children: alreadyAdded ? "선택한 상품의 수량이 1개 추가되었습니다." : "장바구니에 상품이 추가되었습니다."
    });
};
const ChangeCartModal = ({ type , alreadyAdded , onClose  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_common_confirmModal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        leftButtonText: "계속 쇼핑하기",
        leftButtonHandlers: onClose,
        rightButtonText: "장바구니로 이동하기",
        rightButtonHandlers: ()=>{
            onClose();
            router.push("/cart");
        },
        children: [
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__.FontAwesomeIcon, {
                icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faCheckCircle,
                size: "5x"
            }),
            /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ModalMessage, {
                type: type,
                alreadyAdded: alreadyAdded
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChangeCartModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9846:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4115);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4563);
/* harmony import */ var _public_shopping_cart_empty_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8098);
/* harmony import */ var _public_add_cart_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8207);
/* harmony import */ var _public_remove_cart_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2206);
/* harmony import */ var _utils_common_functions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(602);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _emotion_styled__WEBPACK_IMPORTED_MODULE_2__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _emotion_styled__WEBPACK_IMPORTED_MODULE_2__, _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ProductCard = /*#__PURE__*/ (0,_emotion_styled__WEBPACK_IMPORTED_MODULE_2__["default"])("div", {
    target: "em1v9kh0"
})("display:flex;flex-direction:column;row-gap:8px;height:fit-content;& > *{cursor:default;}& > .product-card-header{position:relative;width:100%;&:hover{& > .cart-buttons,& > .prevent-add{opacity:0.9 !important;}}& > .prevent-add{position:absolute;display:flex;flex-direction:column;align-items:center;justify-content:center;row-gap:4px;top:0;left:0;width:100%;height:100%;opacity:0;border-radius:4px;background-color:white;transition:all 0.2s;}& > .image-box{overflow:hidden;border-radius:4px;position:relative;width:100%;padding-top:100%;background-color:#f3f3f3;& > img{position:absolute;top:0;left:0;width:100%;height:100%;image-rendering:pixelated;}}& > .cart-buttons{position:absolute;top:0;left:0;width:100%;height:100%;display:flex;border-radius:4px;overflow:hidden;opacity:0;transition:all 0.2s;& > button{outline:none;flex:0 1 50%;border:none;font-size:32px;cursor:pointer;&.add-cart-button{background:url(", _public_add_cart_png__WEBPACK_IMPORTED_MODULE_6__/* ["default"].src */ .Z.src, ") no-repeat center/50% #f0f0f0;}&.remove-cart-button{background:url(", _public_remove_cart_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"].src */ .Z.src, ") no-repeat center/50% #f0f0f0;}}}}& > .product-card-body{display:flex;flex-direction:column;row-gap:4px;& > .price-and-cart{display:flex;align-items:center;justify-content:space-between;& > .cart-icon{width:32px;height:32px;border:1px solid transparent;background:url(", _public_shopping_cart_empty_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"].src */ .Z.src, ") no-repeat center/50%;& > .amount-text{display:inline-block;width:100%;height:100%;border-radius:50%;color:white;text-align:center;background-color:var(--default-font-color);line-height:1.8;opacity:0;}&.show-amount-text{& > .amount-text{opacity:1;}}}}& > .name{display:-webkit-box;max-height:48px;overflow:hidden;word-break:break-all;text-overflow:ellipsis;-webkit-line-clamp:2;-webkit-box-orient:vertical;}}");
const ProductItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().memo(({ item_no , item_name , detail_image_url , price , amount , disabledAddCartButton , cartClickHandler  })=>{
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
        children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ProductCard, {
            children: [
                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "product-card-header",
                    children: [
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "image-box",
                            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: detail_image_url,
                                alt: "Product Item"
                            })
                        }),
                        disabledAddCartButton && !amount ? /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "prevent-add",
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_3__.FontAwesomeIcon, {
                                    icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faExclamationCircle,
                                    size: "4x"
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "장바구니에 담을 수 없습니다."
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "(최대 등록 가능한 상품 수: 3개)"
                                })
                            ]
                        }) : /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "cart-buttons",
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "add-cart-button",
                                    onClick: ()=>cartClickHandler("add", item_no),
                                    disabled: disabledAddCartButton,
                                    "aria-label": "add-cart-button",
                                    "data-testid": "product-item-add-cart-button"
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "remove-cart-button",
                                    onClick: ()=>cartClickHandler("remove", item_no),
                                    disabled: !amount,
                                    "aria-label": "remove-cart-button",
                                    "data-testid": "product-item-remove-cart-button"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "product-card-body",
                    children: [
                        /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "price-and-cart",
                            children: [
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                    children: `${(0,_utils_common_functions__WEBPACK_IMPORTED_MODULE_8__/* .priceToString */ .w)(price)}원`
                                }),
                                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "cart-icon" + (amount ? " show-amount-text" : ""),
                                    "data-testid": "product-item-amount-text-wrapper",
                                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "amount-text",
                                        "data-testid": "product-item-amount-text",
                                        children: amount
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "name",
                            title: item_name,
                            children: item_name
                        })
                    ]
                })
            ]
        })
    });
}, (prev, next)=>{
    return prev.price === next.price && prev.amount === next.amount && prev.disabledAddCartButton === next.disabledAddCartButton;
});
ProductItem.displayName = "ProductItem";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductItem);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7145:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4115);
/* harmony import */ var _productItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9846);
/* harmony import */ var _store_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2416);
/* harmony import */ var _store_cart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(353);
/* harmony import */ var _components_modals_changeCartModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5873);
/* harmony import */ var _utils_api_products_products__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1455);
/* harmony import */ var _components_common_listEmpty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7261);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__, _emotion_styled__WEBPACK_IMPORTED_MODULE_3__, _productItem__WEBPACK_IMPORTED_MODULE_4__, _store_modal__WEBPACK_IMPORTED_MODULE_5__, _store_cart__WEBPACK_IMPORTED_MODULE_6__, _components_modals_changeCartModal__WEBPACK_IMPORTED_MODULE_7__, _components_common_listEmpty__WEBPACK_IMPORTED_MODULE_8__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__, _emotion_styled__WEBPACK_IMPORTED_MODULE_3__, _productItem__WEBPACK_IMPORTED_MODULE_4__, _store_modal__WEBPACK_IMPORTED_MODULE_5__, _store_cart__WEBPACK_IMPORTED_MODULE_6__, _components_modals_changeCartModal__WEBPACK_IMPORTED_MODULE_7__, _components_common_listEmpty__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const ProductItemList = /*#__PURE__*/ (0,_emotion_styled__WEBPACK_IMPORTED_MODULE_3__["default"])("ul", {
    target: "e1g0r0hf0"
})("display:flex;width:100%;column-gap:16px;min-height:335.19px;& > li{flex-basis:calc(((var(--container-width) - (16px * 4)) / 5));}");
const ProductList = ({ offset  })=>{
    const { openModal  } = (0,_store_modal__WEBPACK_IMPORTED_MODULE_5__/* .useModalStore */ .a)();
    const { list , addCart , removeCart  } = (0,_store_cart__WEBPACK_IMPORTED_MODULE_6__/* .useCartStore */ .x)();
    const { data  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        "products"
    ], _utils_api_products_products__WEBPACK_IMPORTED_MODULE_9__/* .getProducts */ .X);
    const cartClickHandler = (type, id)=>{
        const findItemAmount = list.find((item)=>item.itemInfo.item_no === id)?.amount;
        let alreadyAdded;
        if (type === "add") {
            alreadyAdded = !!findItemAmount;
            addCart(data.find((v)=>v.item_no === id));
        } else {
            alreadyAdded = findItemAmount !== 1;
            removeCart(id);
        }
        openModal({
            Component: _components_modals_changeCartModal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
            props: {
                type,
                alreadyAdded
            }
        });
    };
    if (!data || !data.length) {
        return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_listEmpty__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            message: "표시할 상품이 없습니다."
        });
    }
    const sortedData = data.sort((a, b)=>b.score - a.score);
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ProductItemList, {
        "data-testid": "product-item-list",
        children: sortedData.slice(offset, offset + 5).map((v)=>{
            const { item_no  } = v;
            const findItemFromCart = list.find((item)=>item.itemInfo.item_no === item_no);
            return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_productItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                amount: findItemFromCart?.amount ?? 0,
                cartClickHandler: cartClickHandler,
                disabledAddCartButton: list.length === 3 && !findItemFromCart,
                ...v
            }, item_no);
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3696:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var zustand_shallow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1561);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4115);
/* harmony import */ var _public_shopping_cart_empty_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8098);
/* harmony import */ var _store_cart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(353);
/* harmony import */ var _components_common_listTitle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2164);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, zustand_shallow__WEBPACK_IMPORTED_MODULE_2__, _emotion_styled__WEBPACK_IMPORTED_MODULE_4__, _store_cart__WEBPACK_IMPORTED_MODULE_6__, _components_common_listTitle__WEBPACK_IMPORTED_MODULE_7__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, zustand_shallow__WEBPACK_IMPORTED_MODULE_2__, _emotion_styled__WEBPACK_IMPORTED_MODULE_4__, _store_cart__WEBPACK_IMPORTED_MODULE_6__, _components_common_listTitle__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const CartLinkWrapper = /*#__PURE__*/ (0,_emotion_styled__WEBPACK_IMPORTED_MODULE_4__["default"])("div", {
    target: "e1acewf20"
})("position:relative;display:inline-block;width:74px;text-align:center;& > .cart-link{display:block;width:100%;padding-top:36px;background:url(", _public_shopping_cart_empty_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"].src */ .Z.src, ") no-repeat center/36px;& > .cart-count{position:absolute;top:-8px;right:12px;background-color:var(--default-font-color);padding:0 8px;border-radius:50%;text-align:center;color:white;line-height:26px;}}");
const ProductTitle = ()=>{
    const list = (0,_store_cart__WEBPACK_IMPORTED_MODULE_6__/* .useCartStore */ .x)((state)=>state.list, zustand_shallow__WEBPACK_IMPORTED_MODULE_2__.shallow);
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_listTitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        title: "상품 리스트",
        children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartLinkWrapper, {
            children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                href: "/cart",
                className: "cart-link",
                children: !!list.length && /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "cart-count",
                    children: list.length
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductTitle);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5116:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Products),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7101);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4115);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9752);
/* harmony import */ var _components_common_layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9328);
/* harmony import */ var _components_product_productTitle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3696);
/* harmony import */ var _components_product_productList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7145);
/* harmony import */ var _components_common_pagination__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(998);
/* harmony import */ var _utils_api_products_products__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1455);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _emotion_styled__WEBPACK_IMPORTED_MODULE_2__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__, _components_common_layout__WEBPACK_IMPORTED_MODULE_4__, _components_product_productTitle__WEBPACK_IMPORTED_MODULE_5__, _components_product_productList__WEBPACK_IMPORTED_MODULE_6__, _components_common_pagination__WEBPACK_IMPORTED_MODULE_7__]);
([_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__, _emotion_styled__WEBPACK_IMPORTED_MODULE_2__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__, _components_common_layout__WEBPACK_IMPORTED_MODULE_4__, _components_product_productTitle__WEBPACK_IMPORTED_MODULE_5__, _components_product_productList__WEBPACK_IMPORTED_MODULE_6__, _components_common_pagination__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ProductWrapper = /*#__PURE__*/ (0,_emotion_styled__WEBPACK_IMPORTED_MODULE_2__["default"])("div", {
    target: "eahvntm0"
})("display:flex;flex-direction:column;& > .product-body{margin:32px 0;}& > .product-footer{align-self:center;}");
async function getServerSideProps() {
    const queryClient = new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClient();
    await queryClient.prefetchQuery([
        "products"
    ], _utils_api_products_products__WEBPACK_IMPORTED_MODULE_8__/* .getProducts */ .X);
    return {
        props: {
            dehydratedState: (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.dehydrate)(queryClient)
        }
    };
}
function Products() {
    const [currentPage, setCurrentPage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const { data  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.useQuery)([
        "products"
    ], _utils_api_products_products__WEBPACK_IMPORTED_MODULE_8__/* .getProducts */ .X);
    return /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_layout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        title: "Products",
        children: /*#__PURE__*/ (0,_emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ProductWrapper, {
            children: [
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "product-header",
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_productTitle__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "product-body",
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_productList__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        offset: (currentPage - 1) * 5
                    })
                }),
                /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "product-footer",
                    children: /*#__PURE__*/ _emotion_react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_pagination__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        currentPage: currentPage,
                        limit: data?.length ?? 0,
                        itemPerPage: 5,
                        onPageChange: (page)=>setCurrentPage(page)
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1455:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ getProducts)
/* harmony export */ });
/* harmony import */ var _constants_url__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3232);

const getProducts = async ()=>{
    const res = await fetch(_constants_url__WEBPACK_IMPORTED_MODULE_0__/* .URL_PRODUCTS */ .l);
    return await res.json();
};


/***/ }),

/***/ 7197:
/***/ ((module) => {

module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 7101:
/***/ ((module) => {

module.exports = import("@emotion/react/jsx-runtime");;

/***/ }),

/***/ 4115:
/***/ ((module) => {

module.exports = import("@emotion/styled");;

/***/ }),

/***/ 4563:
/***/ ((module) => {

module.exports = import("@fortawesome/free-solid-svg-icons");;

/***/ }),

/***/ 9752:
/***/ ((module) => {

module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ 6912:
/***/ ((module) => {

module.exports = import("zustand");;

/***/ }),

/***/ 3602:
/***/ ((module) => {

module.exports = import("zustand/middleware");;

/***/ }),

/***/ 3868:
/***/ ((module) => {

module.exports = import("zustand/middleware/immer");;

/***/ }),

/***/ 1561:
/***/ ((module) => {

module.exports = import("zustand/shallow");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664,853], () => (__webpack_exec__(5116)));
module.exports = __webpack_exports__;

})();