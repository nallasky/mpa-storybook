describe('Products 페이지', () => {
  it('페이지 기본 표시 항목 확인', () => {
    cy.visit('http://localhost:3000/products')
    /* ==== Generated with Cypress Studio ==== */
    cy.get('h2').should('have.text', '상품 리스트')
    cy.get('.cart-link').should('be.visible')
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).should('be.enabled')
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-remove-cart-button"]',
    ).should('be.disabled')
    cy.get('[data-testid="pagination-move-prev-page"]').should('be.disabled')
    cy.get('[data-testid="pagination-move-page-1"]').should(
      'have.class',
      'selected',
    )
    cy.get('[data-testid="pagination-move-next-page"]').should('be.enabled')
    cy.get('[data-testid="pagination-move-page-3"]').should('be.enabled')
    /* ==== End Cypress Studio ==== */
  })
  it('pagination 동작 확인', () => {
    cy.visit('http://localhost:3000/products')
    /* ==== Generated with Cypress Studio ==== */
    cy.get('[data-testid="pagination-move-next-page"]').click()
    cy.get('[data-testid="pagination-move-page-2"]').should(
      'have.class',
      'selected',
    )
    cy.get('[data-testid="pagination-move-next-page"]').click()
    cy.get('[data-testid="pagination-move-page-3"]').should(
      'have.class',
      'selected',
    )
    cy.get('[data-testid="pagination-move-next-page"]').should('be.disabled')
    cy.get('[data-testid="pagination-move-prev-page"]').click()
    cy.get('[data-testid="pagination-move-page-2"]').should(
      'have.class',
      'selected',
    )
    cy.get('[data-testid="pagination-move-prev-page"]').click()
    cy.get('[data-testid="pagination-move-page-1"]').should(
      'have.class',
      'selected',
    )
    cy.get('[data-testid="pagination-move-prev-page"]').should('be.disabled')
    /* ==== End Cypress Studio ==== */
  })
  it('상품 추가/삭제 확인', () => {
    cy.visit('http://localhost:3000/products')
    /* ==== Generated with Cypress Studio ==== */
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-body > .price-and-cart > [data-testid="product-item-amount-text-wrapper"] > [data-testid="product-item-amount-text"]',
    ).should('have.text', '0')
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-body > p').should(
      'have.text',
      '장바구니에 상품이 추가되었습니다.',
    )
    cy.get('.modal-content-footer > :nth-child(1)').should(
      'have.text',
      '계속 쇼핑하기',
    )
    cy.get('.modal-content-footer > :nth-child(2)').should(
      'have.text',
      '장바구니로 이동하기',
    )
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-body > .price-and-cart > [data-testid="product-item-amount-text-wrapper"] > [data-testid="product-item-amount-text"]',
    ).should('have.text', '1')
    cy.get(
      ':nth-child(2) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-body > p').should(
      'have.text',
      '장바구니에 상품이 추가되었습니다.',
    )
    cy.get('.modal-content-footer > :nth-child(1)').should(
      'have.text',
      '계속 쇼핑하기',
    )
    cy.get('.modal-content-footer > :nth-child(2)').should(
      'have.text',
      '장바구니로 이동하기',
    )
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(3) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-body > p').should(
      'have.text',
      '장바구니에 상품이 추가되었습니다.',
    )
    cy.get('.modal-content-footer > :nth-child(1)').should(
      'have.text',
      '계속 쇼핑하기',
    )
    cy.get('.modal-content-footer > :nth-child(2)').should(
      'have.text',
      '장바구니로 이동하기',
    )
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(4) > .css-1xiqjh8 > .product-card-header > .prevent-add > :nth-child(2)',
    ).should('have.text', '장바구니에 담을 수 없습니다.')
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-body > .price-and-cart > [data-testid="product-item-amount-text-wrapper"] > [data-testid="product-item-amount-text"]',
    ).should('have.text', '2')
    cy.get('.modal-content-footer > :nth-child(2)').click()
    cy.get('h2').should('have.text', '장바구니')
    cy.get('.css-112bbqk > :nth-child(1)').should(
      'have.text',
      '이전 페이지로 돌아가기',
    )
    cy.get('.css-112bbqk > :nth-child(1)').click()
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-remove-cart-button"]',
    ).click()
    cy.get('.modal-content-body > p').should(
      'have.text',
      '선택한 상품의 수량이 1개 감소하였습니다.',
    )
    cy.get('.modal-content-footer > :nth-child(1)').should(
      'have.text',
      '계속 쇼핑하기',
    )
    cy.get('.modal-content-footer > :nth-child(2)').should(
      'have.text',
      '장바구니로 이동하기',
    )
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-body > .price-and-cart > [data-testid="product-item-amount-text-wrapper"] > [data-testid="product-item-amount-text"]',
    ).should('have.text', '1')
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-remove-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-body > .price-and-cart > [data-testid="product-item-amount-text-wrapper"] > [data-testid="product-item-amount-text"]',
    ).should('have.text', '0')
    cy.get(
      ':nth-child(2) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-remove-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(3) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-remove-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(2)').click()
    cy.get('.css-n8uif9 > p').should('have.text', '장바구니가 비어 있습니다.')
    cy.get('.css-112bbqk > :nth-child(1)').should(
      'have.text',
      '이전 페이지로 돌아가기',
    )
    cy.get('.css-112bbqk > :nth-child(1)').click()
    /* ==== End Cypress Studio ==== */
  })
})
