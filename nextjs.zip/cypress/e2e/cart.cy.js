describe('Cart 페이지', () => {
  it('페이지 기본 표시 항목 확인', () => {
    cy.visit('http://localhost:3000/cart')
    /* ==== Generated with Cypress Studio ==== */
    cy.get('h2').should('have.text', '장바구니')
    cy.get('.css-n8uif9 > p').should('have.text', '장바구니가 비어 있습니다.')
    cy.get('.css-112bbqk > :nth-child(1)').should(
      'have.text',
      '이전 페이지로 돌아가기',
    )
    cy.get('.css-112bbqk > :nth-child(2)').should('have.text', '쿠폰 적용하기')
    cy.get('.css-112bbqk > :nth-child(2)').should('be.disabled')
    cy.get('.css-112bbqk > :nth-child(3)').should(
      'have.text',
      '전체 상품 선택/해제',
    )
    cy.get('.css-112bbqk > :nth-child(3)').should('be.disabled')
    cy.get('.css-112bbqk > :nth-child(4)').should(
      'have.text',
      '선택된 상품 모두 삭제',
    )
    cy.get('.css-112bbqk > :nth-child(4)').should('be.disabled')
    /* ==== End Cypress Studio ==== */
  })
  it('장바구니 리스트 동작 확인 (쿠폰 가능한 상품만)', () => {
    cy.visit('http://localhost:3000/products')
    /* ==== Generated with Cypress Studio ==== */
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(2) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(3) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(2)').click()
    cy.get('.css-112bbqk > :nth-child(2)').should('be.enabled')
    cy.get('.css-112bbqk > :nth-child(3)').should('be.enabled')
    cy.get('.css-112bbqk > :nth-child(4)').should('be.enabled')
    cy.get(':nth-child(1) > .price').should('not.have.text', '0원')
    cy.get(':nth-child(3) > .price').should('have.text', '0원')
    cy.get(':nth-child(5) > .price').should('not.have.text', '0원')
    cy.get(
      ':nth-child(1) > .item-checkbox-wrapper > .css-zo6d8w > input[type="checkbox"]',
    )
      .check({ force: true })
      .should('be.checked')
    cy.get(
      ':nth-child(2) > .item-checkbox-wrapper > .css-zo6d8w > input[type="checkbox"]',
    )
      .check({ force: true })
      .should('be.checked')
    cy.get(
      ':nth-child(3) > .item-checkbox-wrapper > .css-zo6d8w > input[type="checkbox"]',
    )
      .check({ force: true })
      .should('be.checked')
    cy.get('.css-1t3oncu > :nth-child(1) > :nth-child(4)').should(
      'have.text',
      '쿠폰 적용 가능',
    )
    cy.get('.css-1t3oncu > :nth-child(2) > :nth-child(4)').should(
      'have.text',
      '쿠폰 적용 가능',
    )
    cy.get(':nth-child(3) > :nth-child(4)').should(
      'have.text',
      '쿠폰 적용 가능',
    )
    cy.get(':nth-child(1) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '1',
    )
    cy.get(':nth-child(2) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '1',
    )
    cy.get(':nth-child(3) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '1',
    )
    cy.get('.css-112bbqk > :nth-child(3)').click()
    cy.get(
      ':nth-child(1) > .item-checkbox-wrapper > .css-zo6d8w > input[type="checkbox"]',
    ).uncheck({ force: true })
    cy.get(
      ':nth-child(2) > .item-checkbox-wrapper > .css-zo6d8w > input[type="checkbox"]',
    ).uncheck({ force: true })
    cy.get(
      ':nth-child(3) > .item-checkbox-wrapper > .css-zo6d8w > input[type="checkbox"]',
    ).uncheck({ force: true })
    cy.get(':nth-child(1) > .price').should('have.text', '0원')
    cy.get(':nth-child(3) > .price').should('have.text', '0원')
    cy.get(':nth-child(5) > .price').should('have.text', '0원')
    cy.get(':nth-child(1) > .item-checkbox-wrapper > .css-zo6d8w > span').click(
      { force: true },
    )
    cy.get(
      ':nth-child(1) > .item-checkbox-wrapper > .css-zo6d8w > input',
    ).check({ force: true })
    cy.get(':nth-child(2) > .item-checkbox-wrapper > .css-zo6d8w > span').click(
      { force: true },
    )
    cy.get(
      ':nth-child(2) > .item-checkbox-wrapper > .css-zo6d8w > input',
    ).check({ force: true })
    cy.get(':nth-child(3) > .item-checkbox-wrapper > .css-zo6d8w > span').click(
      { force: true },
    )
    cy.get(
      ':nth-child(3) > .item-checkbox-wrapper > .css-zo6d8w > input',
    ).check({ force: true })
    cy.get(':nth-child(1) > .price').should('not.have.text', '0원')
    cy.get(':nth-child(5) > .price').should('not.have.text', '0원')
    cy.get(':nth-child(1) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '1',
    )
    cy.get(':nth-child(2) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '1',
    )
    cy.get(':nth-child(3) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '1',
    )
    cy.get(
      ':nth-child(1) > .css-1vbnram > .amount-control > .amount-change-buttons > [disabled=""]',
    ).should('be.disabled')
    cy.get(
      ':nth-child(2) > .css-1vbnram > .amount-control > .amount-change-buttons > [disabled=""]',
    ).should('be.disabled')
    cy.get(
      ':nth-child(3) > .css-1vbnram > .amount-control > .amount-change-buttons > [disabled=""]',
    ).should('be.disabled')
    cy.get(
      ':nth-child(1) > .css-1vbnram > .amount-control > .amount-change-buttons > :nth-child(1)',
    ).click({ force: true })
    cy.get(
      ':nth-child(2) > .css-1vbnram > .amount-control > .amount-change-buttons > :nth-child(1) > .svg-inline--fa > path',
    ).click({ force: true })
    cy.get(
      ':nth-child(3) > .css-1vbnram > .amount-control > .amount-change-buttons > :nth-child(1) > .svg-inline--fa',
    ).click({ force: true })
    cy.get(':nth-child(1) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '2',
    )
    cy.get(':nth-child(2) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '2',
    )
    cy.get(':nth-child(3) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '2',
    )
    cy.get(
      ':nth-child(1) > .css-1vbnram > .amount-control > .amount-change-buttons > :nth-child(2)',
    ).click({ force: true })
    cy.get(
      ':nth-child(2) > .css-1vbnram > .amount-control > .amount-change-buttons > :nth-child(2) > .svg-inline--fa',
    ).click({ force: true })
    cy.get(
      ':nth-child(3) > .css-1vbnram > .amount-control > .amount-change-buttons > :nth-child(2) > .svg-inline--fa > path',
    ).click({ force: true })
    cy.get(':nth-child(1) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '1',
    )
    cy.get(':nth-child(2) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '1',
    )
    cy.get(':nth-child(3) > .css-1vbnram > .amount-control > input').should(
      'have.value',
      '1',
    )
    cy.get(
      ':nth-child(1) > .css-1vbnram > .amount-control > .amount-change-buttons > [disabled=""]',
    ).should('be.disabled')
    cy.get(
      ':nth-child(2) > .css-1vbnram > .amount-control > .amount-change-buttons > [disabled=""]',
    ).should('be.disabled')
    cy.get(
      ':nth-child(3) > .css-1vbnram > .amount-control > .amount-change-buttons > [disabled=""]',
    ).should('be.disabled')
    cy.get('.css-112bbqk > :nth-child(2)').click({ force: true })
    cy.get(':nth-child(2) > label > .label-name').click({ force: true })
    cy.get(':nth-child(2) > label > input').check({ force: true })
    cy.get('.modal-content-footer > :nth-child(1)').click({ force: true })
    cy.get(':nth-child(3) > .price').should('not.have.text', '0원')
    cy.get('.css-112bbqk > :nth-child(2)').click({ force: true })
    cy.get(':nth-child(3) > label > .label-name').click({ force: true })
    cy.get(':nth-child(3) > label > input').check({ force: true })
    cy.get('.modal-content-footer > :nth-child(1)').click({ force: true })
    cy.get(':nth-child(3) > .price').should('have.text', '0원')
    cy.get('.css-112bbqk > :nth-child(2)').click({ force: true })
    cy.get(':nth-child(1) > label > .label-name').click({ force: true })
    cy.get('.modal-content-body > :nth-child(1) > label > input').check({
      force: true,
    })
    cy.get('.modal-content-footer > :nth-child(1)').click({ force: true })
    cy.get(':nth-child(3) > .price').should('not.have.text', '0원')
    /* ==== End Cypress Studio ==== */
  })
  it('장바구니 리스트 동작 확인 (쿠폰 불가능한 상품만)', () => {
    cy.visit('http://localhost:3000/products')
    /* ==== Generated with Cypress Studio ==== */
    cy.get(
      ':nth-child(5) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get('[data-testid="pagination-move-page-3"]').click()
    cy.get(
      ':nth-child(2) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(2)').click()
    cy.get('.css-112bbqk > [disabled=""]').should('be.disabled')
    cy.get(':nth-child(1) > .not-available-coupon').should(
      'have.text',
      '쿠폰 적용 불가능',
    )
    cy.get(':nth-child(2) > .not-available-coupon').should(
      'have.text',
      '쿠폰 적용 불가능',
    )
    cy.get(':nth-child(3) > .not-available-coupon').should(
      'have.text',
      '쿠폰 적용 불가능',
    )
    /* ==== End Cypress Studio ==== */
  })
  it('장바구니 아이템 삭제 확인', () => {
    cy.visit('http://localhost:3000/products')
    /* ==== Generated with Cypress Studio ==== */
    cy.get(
      ':nth-child(1) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(2) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get(
      ':nth-child(3) > .css-1xiqjh8 > .product-card-header > .cart-buttons > [data-testid="product-item-add-cart-button"]',
    ).click()
    cy.get('.modal-content-footer > :nth-child(2)').click()
    cy.get('.css-1t3oncu').children().should('have.length', 3)
    cy.get(':nth-child(1) > .css-1vbnram > .delete-button').click()
    cy.get('.modal-content-footer > :nth-child(2)').click()
    cy.get('.css-1t3oncu').children().should('have.length', 3)
    cy.get(':nth-child(1) > .css-1vbnram > .delete-button').click()
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get('.css-1t3oncu').children().should('have.length', 2)
    cy.get('.single-button').click()
    cy.get('.css-112bbqk > :nth-child(4)').click()
    cy.get('.modal-content-footer > :nth-child(1)').click()
    cy.get('.single-button').click()
    cy.get('.css-n8uif9 > p').should('have.text', '장바구니가 비어 있습니다.')
    /* ==== End Cypress Studio ==== */
  })
})
