import { URL_COUPOUNS } from '@/constants/url'

export const getCoupons = async () => {
  const res = await fetch(URL_COUPOUNS)
  return await res.json()
}
