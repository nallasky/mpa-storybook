import { URL_PRODUCTS } from '@/constants/url'

export const getProducts = async () => {
  const res = await fetch(URL_PRODUCTS)
  return await res.json()
}
