#!/bin/bash

echo "Download cras application."

# curl -D ...

if [ ! -f /canon/cras.tar ]; then
  echo "Error on downloading an application"
  exit 1
fi

cp /canon/cras.tar /usr/local

echo "Decompress the archive file"
tar xf /usr/local/cras.tar

echo "Start the application"
cd /usr/local
python main.py release
