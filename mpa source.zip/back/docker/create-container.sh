#!/bin/bash

docker network create crasnet

# Create a container to run the database.

dbc=$(docker ps -a | grep database | wc -l)
if [ $dbc -eq 0 ]; then
  echo "Create a database container."
  dbi=$(docker images -a | grep postgres | wc -l)
  if [ $dbi -gt 0 ]; then
    echo "Delete old image of database"
    docker stop database
    docker rm database
    docker rmi postgres:13-alpine
  fi

  echo "Load postgres image"
  docker load -i postgres.tar

  echo "Create database container"
  docker run -it --name database \
    --network crasnet \
    -p 5432:5432 \
    --restart always \
    --mount type=bind,source=/canon,target=/canon \
    postgres:13-alpine
fi

# Install all docker related packages.
#yum localinstall -y

# Create a container to run the main application.
containers=2
i=0

while [ $i -le $containers ]; do
  port=$((5000+i))
  docker load -i crasserver.tar
  docker run -it --name cras-server \
    --network crasnet \
    --restart always \
    -p ${port}:5000 \
    --mount type=bind,source=/canon,target=/canon \
    -e "CONTAINER=cras-${i}"
    crasserver
  ((i++))
done

