# Release notes
## Version 1.0.0 (YYYY. MM. DD)
### Frontend
* 初版リリース
### Backend
* 初版リリース

# パッケージ設置
`pip install --trusted-host files.pythonhosted.org -r requirements.txt`

# Flask App 実行方法
Terminalの/back/フォルダ経路で下記を実行
1. 開発用で実行

`python main.py`

2. リリース用で実行

`python main.py release` 

## CRASサーバー駆動

CRAS 서버로 구동하기 위해서는 환경 변수에 아래 내용을 추가해 주어야 합니다.

```
// ex) SET CRAS_SITE_NAME=BSOT
CRAS_SITE_NAME=<거점명>
```

> 설치 스크립트를 통해 설치한 경우, 설치 과정에서 상기 환경 변수를 입력하는 과정이 있으므로 별도로 설정은 필요하지 않습니다.  

# 유닛 테스트 
1. pytest-watch 패키지 설치

`pip install --trusted-host files.pythonhosted.org pytest-watch`
   
2. Terminal에서 `ptw` 실행하면, 코드 수정때마다 자동으로 /test폴더의 testcase를 실행해준다. 

# Coverage 테스트
설명 사이트 : https://pytest-cov.readthedocs.io/en/latest/config.html#reference

1. coverage 패키지 설치

`pip install --trusted-host files.pythonhosted.org coverage`

2. Terminal에서 `coverage run --concurrency=multiprocessing main.py` 실행 후 테스트 실시.

3. 테스트 결과를 html로 보기

`coverage html`

# pytest를 통한 coverage 테스트
1. pytest-cov 패키지 설치

`pip install --trusted-host files.pythonhosted.org pytest-cov`

2. .coveragerc 파일을 생성. 내용은 없어도 무방.

3. pytest 테스트 명령 실시

`pytest -s -v --cov=common --cov=controller --cov=dao --cov=flaskapp --cov=service --cov-report=html test/`

* -s : print 로그 표시
* -v : Test Case별 테스트 결과 확인

# requirements.txt에 package 추가 방법
파이썬 패키지 추가하실때는,

`pip install --trusted-host files.pythonhosted.org 패키지명`

으로 개별 설치 후에

`pip freeze > requirements.txt`

를 실행해서 requirements.txt파일에 반영해주세요. 그래야 사용 버전을 맞출수 있습니다.