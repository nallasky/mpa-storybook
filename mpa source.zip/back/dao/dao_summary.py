import datetime
import os

import psycopg2.extras
import psycopg2 as pg2
import configparser

from config.app_config import DB_CONFIG_PATH
from config.cras_config import HISTORY_LIMIT
from dao.utils import get_datetime, get_db_config


class SummaryDao:

    def __init__(self):
        self.config = get_db_config()

    def insert_job(self, **form):
        try:
            sql = "insert into cnvset.summary_job (id, site, fab, start, \"end\")" \
                  f"values ('{form['id']}', '{form['site']}', '{form['fab']}', '{get_datetime(form['start'])}', " \
                  f"'{get_datetime(form['end'])}') returning *"

            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(sql)
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to insert a job {msg}')
            return None

    def get_job(self, rid):
        try:
            sql = f"select * from cnvset.summary_job where id = '{rid}'"
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(sql)
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to get job info {msg}')
            return None

    def change_status(self, rid, status, zip_path=None):
        try:
            zip_sql = ''
            if zip_path is not None:
                zip_sql = f", zip_path = '{zip_path}'"
            sql = f"update cnvset.summary_job set status = '{status}' {zip_sql} where id = '{rid}' returning *"
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(sql)
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to change status {msg}')
            return None

    def get_history_list(self, rid=None):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    _rid = ''
                    if rid:
                        _rid = f"and id = '{rid}'"
                    sql = f"select id, to_char(created, 'YYYY-MM-DD HH24:MI:SS') as start, status \
                            from cnvset.summary_job where status not in ('idle') {_rid} order by created desc \
                            limit {HISTORY_LIMIT}"
                    cursor.execute(sql)
                    _ret = cursor.fetchall()
                    if len(_ret) == 0:
                        return None
                    ret = [dict(_) for _ in _ret]
                    return ret

        except Exception as msg:
            print(f'failed to get history list {msg}')
            raise IOError('')
        return None
