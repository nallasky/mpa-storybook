from io import StringIO
import pandas as pd
import pandas.io.sql as sqlio
import psycopg2 as pg2
import psycopg2.extras
import psycopg2.errors
import configparser

from config.app_config import *
from dao.exception import DatabaseQueryException
from dao.utils import get_db_config


class ConvertDao:

    __instance = None

    @classmethod
    def __get_instance(cls):
        return cls.__instance

    @classmethod
    def instance(cls, *args, **kargs):
        cls.__instance = cls(*args, **kargs)
        cls.instance = cls.__get_instance
        return cls.__instance

    def __init__(self):
        print('initialize job dao')
        self.config = get_db_config()

    def insert_df(self, table, df):
        if not str(table).startswith('convert'):
            table = 'convert.%s' % table

        buffer = StringIO()

        if '' in df.columns:
            del df['']

        df['created_time'] = pd.Timestamp.now()

        # df.to_csv('test.csv', index=False, header=True)
        df.to_csv(buffer, index=False, header=False)
        buffer.seek(0)

        with pg2.connect(**self.config) as conn:
            with conn.cursor() as cur:
                try:
                    cur.copy_from(buffer, table, sep=",", columns=df.columns, null='-99999999999999')
                except (Exception, pg2.DatabaseError) as error:
                    conn.rollback()
                    raise DatabaseQueryException(error)

    def count_row(self, table):
        if not str(table).startswith('convert'):
            table = 'convert.%s' % table
        with pg2.connect(**self.config) as connect:
            with connect.cursor() as cursor:
                cursor.execute(f'select count(*) from {table}')
                return int(cursor.fetchone()[0])
        print('unexpected operation')
        return 0

    def get_columns(self, table):
        if not str(table).startswith('convert'):
            table = 'convert.%s' % table
        schema, table = table.split('.')
        with pg2.connect(**self.config) as connect:
            sql = "select * from information_schema.columns where table_name = '%s' and table_schema = '%s'" \
                  % (table, schema)
            df = sqlio.read_sql_query(sql, connect)
            return df['column_name'].tolist()

    def get_version_info_log_time(self, count=2):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor() as cursor:
                    cursor.execute(f"select log_time from convert.version_info group by log_time \
                                        order by log_time desc limit {count}")
                    _ret = cursor.fetchall()
                    ret = [_[0] for _ in _ret]
                    return ret
        except Exception as msg:
            print(f'failed to get version info log time. {msg}')
        return None

    def get_version_info(self, date=None, df=False):
        try:
            with pg2.connect(**self.config) as connect:
                where_date = ''
                if date is not None:
                    where_date = f"where log_time = '{date}'"
                sql = f"select * from convert.version_info {where_date}"
                if df:
                    return pd.read_sql(sql, connect)
                else:
                    with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                        cursor.execute(sql)
                        _ret = cursor.fetchall()
                        ret = [dict(_) for _ in _ret]
                        return ret
        except Exception as msg:
            print(f'failed to get version info. {msg}')
        return None

    def get_log_info(self, table, equipment=None):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    sql_equipment = ''
                    if equipment is not None:
                        sql_equipment = f"where equipment_name='{equipment}'"
                    cursor.execute(f"select to_char(min(log_time), 'YYYY-MM-DD HH24:MI:SS') as start, \
                                        to_char(max(log_time), 'YYYY-MM-DD HH24:MI:SS') as end, count(*) \
                                        from convert.{table} {sql_equipment}")
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to get log info. {msg}')
        return None

    def get_converted_data(self, table, start, end, equipment=None):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor() as cursor:
                    sql_interval = f"where log_time >= '{start}' and log_time <= '{end}'"
                    sql_equipment = ''
                    if equipment is not None:
                        sql_equipment = f"and equipment_name='{equipment}'"
                    buffer = StringIO()
                    sql = f"copy (select * from convert.{table} {sql_interval} {sql_equipment}) \
                            to stdout with csv delimiter '\t'"
                    cursor.copy_expert(sql, buffer)
                    return buffer.getvalue()
        except Exception as msg:
            print(f'failed to get converted log. {msg}')
        return None



