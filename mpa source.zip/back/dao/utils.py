import os
import datetime
import psycopg2 as pg2


def get_db_config():
    if os.environ.get('CRAS_SITE_NAME') is None:
        import configparser
        from config.app_config import DB_CONFIG_PATH

        config = configparser.ConfigParser()
        config.read(DB_CONFIG_PATH)
        try:
            return {
                'dbname': config['DBSETTINGS']['DB_NAME'],
                'user': config['DBSETTINGS']['DB_USER'],
                'host': config['DBSETTINGS']['DB_HOST'],
                'password': config['DBSETTINGS']['DB_PASSWORD'],
                'port': config['DBSETTINGS']['DB_PORT']
            }
        except KeyError:
            return None
    else:
        from config.cras_config import DB_NAME, DB_USER, DB_HOST, DB_PORT, DB_PASSWORD
        return {
            'dbname': DB_NAME,
            'user': DB_USER,
            'host': DB_HOST,
            'password': DB_PASSWORD,
            'port': DB_PORT
        }


def get_datetime(time: str):
    fmt = ['%Y-%m-%d %H:%M:%S', '%Y%m%d%H%M%S', '%Y-%m-%d']
    if time is None:
        return None
    for f in fmt:
        try:
            return datetime.datetime.strptime(time, f)
        except ValueError:
            continue
    return None


def get_date_string(time: datetime.date):
    return time.strftime('%Y-%m-%d %H:%M:%S')


def exist_table(table_name, schema_name='public'):
    try:
        config = get_db_config()
        sql = f"select exists (select from information_schema.tables \
                where table_name='{table_name}' and table_schema='{schema_name}')"
        with pg2.connect(**config) as connect:
            with connect.cursor() as cursor:
                cursor.execute(sql)
                ret = cursor.fetchone()
                return ret[0]

    except Exception as msg:
        print(f'exist_table exception occurs. {msg}')
        return False
