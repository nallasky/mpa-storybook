from dao.dao_base import DAOBaseClass


class DAODisplayString(DAOBaseClass):
    TABLE_NAME = 'settings.display_string'

    def __init__(self):
        super().__init__(DAODisplayString.TABLE_NAME)

    def __del__(self):
        super().__del__()
        print('__del__', __class__)
