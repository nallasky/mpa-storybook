import psycopg2.extras
import psycopg2 as pg2

from config.cras_config import HISTORY_LIMIT
from dao import get_db_config


class VersionJobDao:

    def __init__(self):
        self.config = get_db_config()

    def insert_job(self, form):
        try:
            sql = f"insert into cnvset.version_job (id, period) values ('{form['id']}', '{form['period']}') \
                   returning *"

            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(sql)
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to insert version job. {msg}')
        return None

    def get_job(self, rid):
        try:
            sql = f"select * from cnvset.version_job where id = '{rid}'"
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(sql)
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to get job info {msg}')
            return None

    def change_status(self, rid, status, file=None):
        try:
            file_sql = ''
            if file is not None:
                file_sql = f", file_path = '{file}'"
            sql = f"update cnvset.version_job set status = '{status}' {file_sql} where id = '{rid}' returning *"
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(sql)
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to change status {msg}')
            return None

    def get_history_list(self, rid=None):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    _rid = ''
                    if rid:
                        _rid = f"and id = '{rid}'"
                    sql = f"select id, to_char(created, 'YYYY-MM-DD HH24:MI:SS'), status \
                            from cnvset.version_job where \
                            status not in ('idle') {_rid} order by created desc limit {HISTORY_LIMIT}"
                    cursor.execute(sql)
                    _ret = cursor.fetchall()
                    if len(_ret) == 0:
                        return None
                    ret = [dict(_) for _ in _ret]
                    return ret

        except Exception as msg:
            print(f'failed to get history list {msg}')
            raise IOError('')
        return None

    def job_exist(self):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor() as cursor:
                    cursor.execute(f"select count(*) from cnvset.version_job where status in ('idle', 'running')")
                    _ret = cursor.fetchone()
                    if _ret[0]>0:
                        return True
                    else:
                        return False
        except Exception as msg:
            print(f'failed to check job exist. {msg}')
        return False

