import datetime
import logging
import os

import psycopg2.extras
import psycopg2 as pg2
import configparser
import pandas as pd

from config.app_config import DB_CONFIG_PATH
from config.cras_config import HISTORY_LIMIT
from dao.utils import get_datetime, get_db_config

log = logging.getLogger('cras-job-dao')


class CrasJobDao:

    def __init__(self):
        self.config = get_db_config()

    def insert_job(self, job):
        try:
            sql = f"insert into cnvset.cras_job (id, site, fab) values \
                    ('{job['id']}', '{job['site']}', '{job['fab']}') returning *"
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(sql)
                    _job = cursor.fetchone()
                    if _job is None:
                        return None
                    return dict(_job)

        except Exception as msg:
            log.error(f'failed to insert a job {msg}')
            return None

    def get_job(self, rid):
        try:
            sql = f"select * from cnvset.cras_job where id = '{rid}'"
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(sql)
                    _job = cursor.fetchone()
                    if _job is None:
                        return None
                    return dict(_job)
        except Exception as msg:
            log.error(f'failed to get job info {msg}')
            return None

    def change_status(self, rid, status, pdf_path=None, data_path=None, judge_path=None, mail_path=None):
        try:
            path_sql = ''
            if pdf_path is not None:
                path_sql = f", pdf_path = '{pdf_path}'"
            if data_path is not None:
                path_sql = f"{path_sql}, data_path = '{data_path}'"
            if judge_path is not None:
                path_sql = f"{path_sql}, judge_path = '{judge_path}'"
            if mail_path is not None:
                path_sql = f"{path_sql}, mail_path = '{mail_path}'"

            sql = f"update cnvset.cras_job set status = '{status}' {path_sql} where id = '{rid}' returning *"
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(sql)
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to change status {msg}')
            return None

    def get_last_exec(self, rid):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor() as cursor:
                    sql = f"select site, fab from cnvset.cras_job where id = '{rid}'"
                    cursor.execute(sql)
                    ret = cursor.fetchone()
                    site, fab = ret[0], ret[1]

                    sql = f"select cras_last_exec from cnvbase.equipments \
                            where user_name = '{site}' and fab_name ='{fab}' order by cras_last_exec limit 1"
                    cursor.execute(sql)
                    ret = cursor.fetchone()
                    return ret[0]

        except Exception as msg:
            print(f'failed to get last exec time {msg}')
            return None

    def get_cras_tool_info(self):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    sql = f"select user_name, fab_name, tool_id from cnvbase.equipments"
                    cursor.execute(sql)
                    _ret = cursor.fetchall()
                    ret = list()
                    for r in _ret:
                        ret.append(dict(r))
                    return ret

        except Exception as msg:
            print(f'failed to get cras tool info {msg}')
            return None

    def get_cras_data(self, site, fab):
        try:
            with pg2.connect(**self.config) as connect:
                sql = f"select * from cras_data_{site}_{fab}"
                return pd.read_sql(sql, connect)
        except Exception as msg:
            print(f'failed to get cras tool info {msg}')
            return None

    def get_history_list(self, rid=None):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    _rid = ''
                    if rid:
                        _rid = f"and id = '{rid}'"
                    sql = f"select id, to_char(created, 'YYYY-MM-DD HH24:MI:SS') as start, status \
                            from cnvset.cras_job where status not in ('idle') {_rid} order by created desc \
                            limit {HISTORY_LIMIT}"
                    cursor.execute(sql)
                    _ret = cursor.fetchall()
                    if len(_ret) == 0:
                        return None
                    ret = [dict(_) for _ in _ret]
                    return ret

        except Exception as msg:
            print(f'failed to get history list {msg}')
            raise IOError('')
        return None
