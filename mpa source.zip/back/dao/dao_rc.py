import psycopg2.extras
import psycopg2 as pg2
from flask import current_app

from dao.utils import get_db_config


class RapidCollectorDao:

    __instance = None

    @classmethod
    def __get_instance(cls):
        return cls.__instance

    @classmethod
    def instance(cls, *args, **kargs):
        cls.__instance = cls(*args, **kargs)
        cls.instance = cls.__get_instance
        return cls.__instance

    def __init__(self):
        print('initialize base server dao')
        self.config = get_db_config()
        self.schema = 'cnvset'
        self.config_table = '%s.rapid_collector_config' % self.schema

    def get_config(self):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute('select * from %s order by id desc limit 1' % self.config_table)
                    config = cursor.fetchone()
                    return dict(config)
        except Exception as msg:
            print('failed to get config (%s)' % msg)
        return None

    def set_config(self, config):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor() as cursor:
                    cursor.execute('select * from %s order by id desc limit 1' % self.config_table)
                    c = cursor.fetchone()
                    if c is not None:
                        config = {**config, 'id': c[0]}
                        sql = '''
                            update cnvset.rapid_collector_config set
                                 addr = %(addr)s,
                                 port = %(port)s,
                                 username = %(username)s,
                                 pass = %(pass)s,
                                 plans = %(plans)s
                                 where id = %(id)s
                        '''
                    else:
                        sql = '''
                            insert into cnvset.rapid_collector_config
                                (addr, port, username, pass, plans) values
                                ( %(addr)s, %(port)s, %(username)s, %(pass)s, %(plans)s )
                        '''
                    cursor.execute(sql, config)
                    print('set rapid-collector-config')
        except Exception as msg:
            print('failed to get config (%s)' % msg)

    def get_status(self):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    sql = f'select addr, port, username, plans, \
                                (select result from cnvset.rapid_job_history as hist \
                                    where hist.id = cnf.convert_history) as convert_status, \
                                (select result from cnvset.rapid_job_history as hist \
                                    where hist.id = cnf.summary_history) as summary_status, \
                                (select result from cnvset.rapid_job_history as hist \
                                    where hist.id = cnf.cras_history) as cras_status, \
                                (select result from cnvset.rapid_job_history as hist \
                                    where hist.id = cnf.version_history) as version_status \
                            from cnvset.rapid_collector_config as cnf order by id desc limit 1'
                    cursor.execute(sql)
                    return dict(cursor.fetchone())
        except Exception as msg:
            print(f'failed to get status ({msg})')
        return None

    def set_status(self, job_category, result, log=None):
        print(f'set_status {job_category} {result}')
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute('select id from cnvset.rapid_collector_config order by id desc limit 1')
                    rc = cursor.fetchone()
                    if rc is None:
                        raise Exception('no rapid collector config')
                    rc = dict(rc)

                    sql = f"insert into cnvset.rapid_job_history (type, result, log) \
                            values ('{job_category}', '{result}', '{log}')"
                    cursor.execute(sql)

                    category_column = f'{job_category}_history'
                    # sql = f'update cnvset.rapid_collector_config set {category_column}={history_id}'


        except Exception as msg:
            print(f'failed to set status ({msg})')
