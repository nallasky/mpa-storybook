from dao.dao_base import DAOBaseClass


class DAOPickupItems(DAOBaseClass):
    TABLE_NAME = 'analysis.pickup_items'

    def __init__(self, log_name):
        super().__init__(table_name=DAOPickupItems.TABLE_NAME)
        self.df = self.fetch_all(args={'where': "log_name='{0}'".format(log_name)})

    def __del__(self):
        super().__del__()
        print('__del__', __class__)

    def get_columns_comma_separated(self):
        columns = self.df['column_name'].unique().tolist()
        for item in columns:
            if item == 'index':
                columns.remove('index')

        return ', '.join(columns)

    def get_operation_list(self):
        return self.df['op_type'].dropna(axis=0).unique().tolist()

    def get_unique_cell_formula_list(self):
        cell_formula = self.df['cell_formula'].dropna(axis=0)
        # cell_list = full_unit.apply(lambda x: x.split('|')[0])

        return cell_formula.unique()

    def get_unique_all_formula_list(self, cell_form=None):
        if cell_form is None:
            all_formula = self.df['all_formula'].dropna(axis=0)
            # full_unit = self.df[operation].dropna(axis=0)
            # all_list = full_unit.apply(lambda x: x.split('|')[1])

        else:
            all_formula = self.df[self.df['cell_formula'] == cell_form]['all_formula'].dropna(axis=0)
            # cell_list = full_unit.apply(lambda x: x.split('|')[0])
            # all_list = full_unit[cell_list == cell_unit].apply(lambda x: x.split('|')[1])

        return all_formula.unique()

    def get_column_list(self, cell_form=None, all_form=None):
        select_df = self.df

        if cell_form is not None:
            select_df = select_df[select_df['cell_formula'] == cell_form]

        if all_form is not None:
            select_df = select_df[select_df['all_formula'] == all_form]

        # select_df = self.df[(self.df['op_type'] == op_type) & (self.df['cell_formula'] == cell_form)]
        # select_df = self.df[['column_name', operation]].dropna(axis=0)
        # cell_list = select_df[operation].apply(lambda x: x.split('|')[0])

        return select_df['column_name'].dropna(axis=0).tolist()

    def get_disp_str_dict(self, col_list, cell_form=None):
        if cell_form is None:
            select_df = self.df[self.df['column_name'].isin(col_list)]
        else:
            select_df = self.df[(self.df['cell_formula'] == cell_form) & (self.df['column_name'].isin(col_list))]

        dict = {}
        for i in range(len(select_df)):
            dict[select_df.iloc[i]['column_name']] = select_df.iloc[i]['disp_str']

        return dict

    def get_detail_disp_str_dict(self, col_list):
        select_df = self.df[self.df['column_name'].isin(col_list)]

        dict = dict()
        for i in range(len(select_df)):
            dict[select_df.iloc[i]]['column_name'] = select_df.iloc[i]['detail_disp_str']

        return dict

    def sort_by_disp_order(self, columns):
        df = self.df.sort_values(by='disp_order', ascending=True)

        disp_order = []
        for i in range(len(df)):
            if df.iloc[i]['disp_str'] in columns:
                disp_order.append(df.iloc[i]['disp_str'])

        return disp_order

    def sort_by_column_order(self, columns):
        df = self.df.sort_values(by='disp_order', ascending=True)
        column_list = df['column_name'].unique().tolist()

        disp_order = []
        for column in column_list:
            if column in columns:
                disp_order.append(column)

        return disp_order

    def get_disp_srt_vs_disp_graph_f_dict(self):
        df = self.df.sort_values(by='disp_order', ascending=True)

        disp_graph_dict = dict()
        for i in range(len(df)):
            disp_graph_dict[df.iloc[i]['disp_str']] = df.iloc[i]['disp_graph_f']

        return disp_graph_dict

    def get_column_name_vs_disp_graph_f_dict(self):
        df = self.df.sort_values(by='disp_order', ascending=True)

        disp_graph_dict = dict()
        for i in range(len(df)):
            disp_graph_dict[df.iloc[i]['column_name']] = df.iloc[i]['disp_graph_f']

        return disp_graph_dict
