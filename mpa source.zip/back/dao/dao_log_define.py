from dao.dao_base import DAOBaseClass


class DAOLogDefine(DAOBaseClass):
    TABLE_NAME = 'settings.log_define'

    def __init__(self):
        super().__init__(DAOLogDefine.TABLE_NAME)

    def __del__(self):
        super().__del__()
        print('__del__', __class__)
