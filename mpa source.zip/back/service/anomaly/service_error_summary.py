import os
import sys
from datetime import datetime, timedelta
import subprocess
import pandas as pd

from config.cras_config import ZIP_EXEC, ZIP_OPTIONS
from dao.dao_base import DAOBaseClass
from service.summary.exception import ErrorSummaryException


class ErrorSummary:
    def get_days(self, lastday):
        """
        昨日の日付と引数で指定された日付だけさかのぼった日の日付を取得する
        :param lastday: さかのぼる日付
        :return: 昨日の日付、さかのぼった日付
        """
        now = datetime.now()
        delta_day = now
        to_day = ('{0:04d}/{1:02d}/{2:02d}'.format(delta_day.year, delta_day.month, delta_day.day))
        delta_day = now + timedelta(days=-lastday)
        from_day = ('{0:04d}/{1:02d}/{2:02d}'.format(delta_day.year, delta_day.month, delta_day.day))
        return from_day, to_day

    def lastdayslist(self, days):
        """
        昨日の日付と引数で指定された日付だけさかのぼった日の間の日付のリストを取得する
        :param days: 取得する日付の期間
        :return: 日付のリスト

        """
        now = datetime.now()
        days_list = []
        for day in range(-days, 0):
            delta_day = now + timedelta(days=day)

            days_list.append('{0:04d}/{1:02d}/{2:02d}'.format(delta_day.year, delta_day.month, delta_day.day))
        return days_list

    def delta2str(self, t_delta):
        """
        time deltaを文字列に変換
        :param t_delta: デルタ時間
        :return: 変換後の文字列
        """
        sec_ = t_delta.seconds
        hour_ = int(int(sec_) / 3600)
        min_ = int((int(sec_) - hour_ * 3600) / 60)
        sec_ = int(sec_ - hour_ * 3600 - min_ * 60)
        return '{0:02d}:{1:02d}:{2:02d}'.format(hour_, min_, sec_)

    def output_excel(self, output_file, input_df, eqp_list):
        """
        データフレームからexcelファイルを作成する
        :param output_file:
        :param input_df:
        :return:
        """
        writer = pd.ExcelWriter(output_file)
        #    tool_list = input_df['equipment_name'].unique()
        for tool in eqp_list:
            tool_summary = input_df[input_df['equipment_name'] == tool]
            del tool_summary['equipment_name']
            tool_summary = tool_summary.sort_values(['ErrRank', 'TotalCount', 'TotalTime', 'ErrNo'],
                                                    ascending=[True, False, False, True])
            tool_summary['ErrNo'] = tool_summary['ErrNo'].str.upper()
            tool_summary = tool_summary.drop_duplicates(['ErrNo'])
            namelist = tool.split('_')
            # tool_name = namelist[len(namelist) - 1]
            tool_name = namelist[len(namelist) - 2] + '_' + namelist[len(namelist) - 1]
            tool_summary.to_excel(writer, sheet_name=tool_name, index=False)
        writer.save()

    def create_summary_df(self, dbif, output_file, time_span, fab):
        """
        指定された期間のエラーサマリーデータを作成しExcelとして出力
        :param dbif: DBとのIFオブジェクト
        :param output_file: 出力するファイル名
        :param time_span: 取得するエラーの期間(過去何日か)
        :return:
        """

        # サマリーを作る期間を設定する
        from_day, to_day = self.get_days(time_span)
        # from_day, to_day = '2020-11-20', '2020-11-26'
        timespan_str = "log_date >='{}' AND log_date< '{}' ".format(from_day, to_day)
        days = self.lastdayslist(time_span)

        # DBから指定期間のエラーサマリーを取得する
        # エラー毎にカウントする処理もDB側で行ってしまう
        #outdf = dbif.get_data_with(
        #    "equipment_name, error_no, error_name,error_rank, sum(elapsed) AS elapsed, sum(error_count) AS count",
        #    "error_summary",
        #    timespan_str,
        #    "equipment_name, error_no, error_name,error_rank;")
        outdf = dbif.fetch_all(table='convert.error_summary',
                               args={'select': 'equipment_name, error_no, error_name,error_rank, \
                                               sum(elapsed) AS elapsed, sum(error_count) AS count',
                                     'where': '{} '.format(timespan_str)+' group by equipment_name, error_no, \
                                            error_name,error_rank'})
        outdf = outdf.loc[:, ['equipment_name', 'error_rank', 'error_no', 'error_name', 'count', 'elapsed']]

        # 一日毎の集計列を付加していく
        for day in days:
            logdate_str = "log_date ='{}'".format(day)
            # 一日毎のエラー数を取得する。エラー毎のカウントもDB側で処理する
            #oneday = dbif.get_data_with("equipment_name, error_no, sum(error_count) AS day_col ",
            #                            "error_summary",
            #                            logdate_str,
            #                            "error_no, equipment_name;")
            oneday = dbif.fetch_all(table='convert.error_summary',
                                    args={'select': 'equipment_name, error_no, sum(error_count) AS day_col',
                                          'where': '{}'.format(logdate_str)+' group by error_no, equipment_name'})

            # 取得したデータと、指定期間のサマリーデータを結合する
            outdf = pd.merge(outdf, oneday, on=['equipment_name', 'error_no'], how='left')
            # NaNの部分は0にする
            outdf = outdf.fillna('0')

            outdf['day_col'] = outdf['day_col'].astype(int)
            outdf = outdf.rename(columns={'day_col': day})

        # 欠損値を補間し経過時間を文字列にする
        outdf = outdf.fillna('0')
        outdf['elapsed'] = outdf['elapsed'].map(self.delta2str).astype(dtype=str)

        # 出力するテーブルのカラム名を変換する
        colname = {'error_no': 'ErrNo',
                   'error_name': 'ErrName',
                   'error_rank': 'ErrRank',
                   'elapsed': 'TotalTime',
                   'count': 'TotalCount'}
        outdf = outdf.rename(columns=colname)

        # 装置のリストを作成
        """
        if fab == 'CZ' or fab == 'T2' or fab == 'T4':  # equipement DBに小文字になっていて必要な例外処理
            sqlstr = "SELECT equipment_name FROM equipments WHERE fab_name='{}' ORDER BY equipment_name".format(fab.lower())
        elif fab == 'WUHAN':
            sqlstr = "SELECT equipment_name FROM equipments WHERE fab_name='{}' ORDER BY equipment_name".format('WH')
        else:
        """

        if fab == 'CQ':
            eqpret = dbif.fetch_all(table='cnvbase.equipments',
                                    args={'select': 'equipment_name',
                                          'where': "fab_name='{}'".format('H1')+' order by equipment_name'})

        elif fab == 'CZ':
            eqpret = dbif.fetch_all(table='cnvbase.equipments',
                                    args={'select': 'equipment_name',
                                          'where': "fab_name='{}'".format('H2')+' order by equipment_name'})
        else:
            eqpret = dbif.fetch_all(table='cnvbase.equipments',
                                    args={'select': 'equipment_name',
                                          'where': "fab_name='{}'".format(fab)+' order by equipment_name'})

        #eqpret = dbif.execute_sql(sqlstr)
        eqp_list = []
        for r in eqpret['equipment_name']:
            eqp_list.append(r)
        if len(eqp_list) == 0:
            raise ErrorSummaryException('empty eqp_list')
        self.output_excel(output_file, outdf, eqp_list)

    def create_summary_zip(self, zip_name, excel_name, passwd, time_span, fab):
        """
        DBから指定期間のエラーサマリを取得・集計しzipファイルを作成
        :param connection_config:
        :param zip_name:
        :param excel_name:
        :param passwd:
        :param zip_path:
        :param time_span:
        :return:
        """
        dbif = DAOBaseClass()
        df = self.create_summary_df(dbif, excel_name, time_span, fab)
        cmd_str = f'{ZIP_EXEC} {ZIP_OPTIONS % passwd} {zip_name} {excel_name}'
        ret = subprocess.call(cmd_str, shell=True)
        return ret

