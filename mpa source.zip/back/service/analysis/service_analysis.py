import os
import datetime
import time
from copy import deepcopy
from multiprocessing import Process, Manager
import pandas as pd

from dao.dao_log_define import DAOLogDefine
from dao.dao_pickup_items import DAOPickupItems
from dao.dao_base import DAOBaseClass

from common.utils.response import ResponseForm
from common.utils import calculator, preprocessing

LOG_NAME = 'PLATEAUTOFOCUSCOMPENSATION'


class AnalysisService:
    def __init__(self):
        pass
        # super(Process, self).__init__()
        # manager = Manager()
        #
        # self.id = manager.Value('d', 0)
        # self.args = args
        # self.log_define = None

    # def run(self):
    #     # self.id = current_process().pid
    #
    #     # for i in range(10):
    #     #     time.sleep(1)
    #     #     # print('current proc pid : ', current_process().pid)
    #     #     print('sub process : ', self.pid, 'working : ', self.id.value)
    #
    #     if 'source' in self.args:
    #         if self.args['source'] == 'local':
    #             self._convert_log_from_local()
    #         else:
    #             self._convert_log_from_db()
    #
    # def get_id(self):
    #     return self.id.value
    #
    # def set_id(self, id):
    #     self.id.value = id

    # def _convert_log_from_local(self):
    #     if 'target_path' in self.args and 'log_name' in self.args:
    #         target_path = self.args['target_path']
    #         log_name = self.args['log_name']
    #
    #         # Targetディレクトリが存在するかどうかを確認
    #         if os.path.exists(target_path) is True:
    #             # 変換するログファイルのリストを作成する
    #             logfilelist = []
    #
    #             if os.path.isdir(target_path) is True:
    #                 for file_name in os.listdir(target_path):
    #                     log_file_name = os.path.join(target_path, file_name)
    #                     if os.path.isdir(log_file_name) is False:
    #                         logfilelist.append([target_path, file_name])
    #
    #             for [target_path, file_name] in logfilelist:
    #                 convert_file_name = self._convert_log_format(target_path, file_name)
    #                 if convert_file_name is not None:
    #                     file_name = convert_file_name
    #
    #                 # ログ情報をDBから取り出す
    #                 log_info_header_df, log_info_wo_header_df = self.get_log_define(log_name)
    #                 print(log_info_header_df, log_info_wo_header_df)
    #
    # def _convert_log_from_db(self):
    #     pass
    #
    # def _convert_log_format(self, log_path, file_name):
    #     current_year = str(datetime.date.today().year)
    #
    #     with open(os.path.join(log_path, file_name), 'r') as log_file:
    #         lines = log_file.readlines()
    #
    #         # Logのライン数が1ラインの場合は処理しない
    #         if len(lines) < 2:
    #             print('1')
    #             return
    #
    #         # HEADERがあるのは処理しない
    #         if lines[1][0] == '#':
    #             print('2')
    #             return
    #
    #         header = ''
    #
    #         TYPE1_COMMA_CNT = 25
    #
    #         if lines[1].count(',') == TYPE1_COMMA_CNT:
    #             header = '#24160,24161,24049,2404A,2404B,2404C,2404D,2404E,2404F,241C1,241C2,241C3,241C4,2408B,2408C,2408D,2408E,2408F,24090,241C5,241C6,241C7,241C8,GlassID,LotID,Date Time'
    #         else:
    #             return
    #
    #         # HEADERTYPEに変更してファイルを保存
    #         new_file_name = 'NEW_' + file_name
    #         with open(os.path.join(log_path, new_file_name), 'w') as new_log_file:
    #             new_log_file.writelines(lines[0])
    #             new_log_file.writelines(header + '\n')
    #             for i in range(1, len(lines)):
    #
    #                 if lines[i].count(',') == TYPE1_COMMA_CNT:
    #                     pos = lines[i].rfind(',') + 1
    #                     lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:]
    #
    #                 new_log_file.writelines(lines[i])
    #
    #         return new_file_name
    #
    # def get_log_define(self, log_name):
    #     """
    #     指定されたlog type IDのLogDefine情報を取得する
    #     :param log_name: Log種別に固有のID
    #     :return:
    #     """
    #     if self.log_define is None:
    #         dao_log_define = DAOLogDefine()
    #         self.log_define = dao_log_define.fetch_all()
    #
    #     with_header = self.log_define[(self.log_define['log_name'] == log_name)
    #                                   & (self.log_define['log_header'] == 'with_header')]
    #
    #     wo_header = self.log_define[(self.log_define['log_name'] == log_name)
    #                                 & (self.log_define['log_header'] == 'without_header')]
    #
    #     return with_header, wo_header

    def __del__(self):
        print('__del__', __class__)

    def get_list(self, log_name, job_id, one_period, adj_period, list_group):

        # dao_afc = DAOAfc()

        try:
            dao = self.get_dao(log_name)
            cnt = dao.load_data_by_id(job_id=job_id)
            if cnt == 0:
                return ResponseForm(res=False, msg='There is no Log Data. You might have wrong id.')

            # 1st Period の開始時刻とログの最後の時刻を取得
            first_log_time = dao.get_log_time_min()

            # 期間指定がある場合
            start_time = calculator.period_start_datetime(first_log_time, one_period, adj_period)

            job_list = dao.get_divided_list(one_period, start_time, list_group)
            return ResponseForm(res=True, data=job_list)

        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_summary(self, log_name, job_id, **args):
        try:
            dao_pickup_items = DAOPickupItems(log_name=log_name)
            columns_str = dao_pickup_items.get_columns_comma_separated()
            if columns_str is not None:
                dao = self.get_dao(log_name)
                dao.load_data(job_id=job_id, **args)

                summary_result = None
                all_merge_df = None

                if args['group_by'] == 'column':
                    group = args['group_value']
                else:
                    group = args['group_by']

                cell_form_list = dao_pickup_items.get_unique_cell_formula_list()

                for cell_form in cell_form_list:
                    cell_column_list = dao_pickup_items.get_column_list(cell_form=cell_form)
                    split_cell_form_list = cell_form.split('.')
                    cell_df = dao.get_df()

                    if group == 'period':
                        cell_df['log_time'] = cell_df['period']

                    for formula in split_cell_form_list:
                        cell_df = calculator.calc_formula(formula, cell_df, cell_column_list, group)

                    all_form_list = dao_pickup_items.get_unique_all_formula_list(cell_form=cell_form)

                    for all_form in all_form_list:
                        all_column_list = dao_pickup_items.get_column_list(cell_form=cell_form,
                                                                           all_form=all_form)
                        split_all_form_list = all_form.split('.')
                        all_summary_df = deepcopy(cell_df)

                        for formula in split_all_form_list:
                            all_summary_df = calculator.calc_formula(formula, all_summary_df, all_column_list)

                        if isinstance(all_summary_df, pd.Series):
                            df = pd.DataFrame(all_summary_df, columns=['ALL']).T
                            if all_merge_df is None:
                                all_merge_df = df
                            else:
                                all_merge_df = pd.concat([all_merge_df, df], axis=1)

                    disp_str_dict = dao_pickup_items.get_disp_str_dict(col_list=cell_column_list, cell_form=cell_form)
                    if isinstance(cell_df, pd.Series):
                        cell_df = pd.DataFrame(cell_df).T

                    cell_df.rename(columns=disp_str_dict, inplace=True)
                    if all_merge_df is not None:
                        all_merge_df.rename(columns=disp_str_dict, inplace=True)

                    if summary_result is None:
                        summary_result = cell_df
                    else:
                        summary_result = summary_result.reset_index().merge(cell_df.reset_index(), how='left').set_index('index')

                if summary_result is not None:
                    if args['jobname'] is not None:
                        summary_result['device'] = args['jobname'].split('/')[0]
                        summary_result['process'] = args['jobname'].split('/')[1]

                        disp_str_dict = dao_pickup_items.get_disp_str_dict(col_list=['device', 'process'])
                        summary_result.rename(columns=disp_str_dict, inplace=True)

                    summary_result.reset_index(inplace=True)
                    summary_result['index'] = summary_result['index'] + 1

                    if all_merge_df is not None:
                        all_merge_df.reset_index(inplace=True)
                        summary_result = pd.concat([summary_result, all_merge_df])
                        summary_result.reset_index(inplace=True, drop=True)

                    disp_str_dict = dao_pickup_items.get_disp_str_dict(col_list=[group, 'index'])
                    summary_result.rename(columns=disp_str_dict, inplace=True)

                    disp_order = dao_pickup_items.sort_by_disp_order(summary_result.columns)
                    disp_graph = dao_pickup_items.get_disp_srt_vs_disp_graph_f_dict()
                    rtn_dict = {'disp_order': disp_order, 'disp_graph_f': disp_graph,
                                'summary': summary_result.to_dict(orient='index')}
                    return ResponseForm(res=True, data=rtn_dict)
                else:
                    return ResponseForm(res=False, msg='There is nothing to summary.')
            else:
                return ResponseForm(res=False, msg='There is no Pickup Items.')
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_dao(self, log_name):
        dao = DAOBaseClass(table_name='cnvbase.log_define')
        row = dao.fetch_one(args={'select': 'db_table', 'where': "log_name='{0}'".format(log_name)})

        return DAOBaseClass(table_name='convert.{}'.format(row[0]))

    # todo DB에서 그룹핑이 가능한 컬럼 정보를 참조하도록 구성 변경 필요
    def get_group_avail_columns(self, log_name):
        if log_name == 'PLATEAUTOFOCUSCOMPENSATION':
            return ['lot_id']
        elif log_name == 'LiPSFocus':
            return []
        elif log_name == 'TiltMeasurementLog':
            return []
        elif log_name == 'MountPressLog':
            return []
        elif log_name == 'PRESCANCOMPENSATIONMONITOR':
            return ['lot_id']

    # todo DB에서 필터링 가능한 컬럼 정보를 참조하도록 구성 변경 필요
    def get_filter_key_value(self, log_name):
        if log_name == 'PLATEAUTOFOCUSCOMPENSATION':
            return {'key': [], 'value': []}
        elif log_name == 'LiPSFocus':
            return {'key': [], 'value': []}
        elif log_name == 'TiltMeasurementLog':
            return {'key': [], 'value': []}
        elif log_name == 'MountPressLog':
            return {'key': ['status'], 'value': [{'status': ['Job']}]}
        elif log_name == 'PRESCANCOMPENSATIONMONITOR':
            return {'key': [], 'value': []}

    def get_detail(self, log_name, job_id, **args):
        try:
            dao_pickup_items = DAOPickupItems(log_name=log_name)
            columns_str = dao_pickup_items.get_columns_comma_separated()
            if columns_str is not None:
                dao = self.get_dao(log_name)
                dao.load_data(job_id=job_id, select=columns_str, **args)

                if args['group_by'] == 'column':
                    column = args['group_value']
                else:
                    column = args['group_by']
                
                df = dao.get_df()
                df = df[df[column].isin(args['group_selected'])]

                # column_list = dao_pickup_items.get_column_list()
                # disp_str_dict = dao_pickup_items.get_detail_disp_str_dict(col_list=column_list)
                # df.rename(columns=disp_str_dict, inplace=True)

                df.reset_index(inplace=True, drop=True)
                df.reset_index(inplace=True)
                df['index'] = df['index'] + 1
                disp_order = dao_pickup_items.sort_by_column_order(df.columns)
                disp_graph = dao_pickup_items.get_column_name_vs_disp_graph_f_dict()
                rtn_dict = {'disp_order': disp_order, 'disp_graph_f': disp_graph,
                            'detail': df.to_dict(orient='index')}

                return ResponseForm(res=True, data=rtn_dict)
            else:
                return ResponseForm(res=False, msg='There is no Pickup Items.')
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))
