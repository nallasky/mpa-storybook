class ErrorSummaryException(Exception):
    pass
