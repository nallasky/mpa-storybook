import os

from config import app_config
from multiprocessing import Process
import logging

from dao.dao_summary import SummaryDao
from service.anomaly.service_error_summary import ErrorSummary
from service.logger.process_log_base import ProcessLogBase
from service.logger.service_logger import ServiceLogger
from service.summary.exception import ErrorSummaryException

log = logging.getLogger(app_config.LOG)


class SummaryProcess(ProcessLogBase):

    def __init__(self, request_id):
        self.request_id = request_id
        self.io = SummaryDao()

        cache_root = '.summary'
        if not os.path.exists(cache_root):
            os.mkdir(cache_root)

        self.cache_path = os.path.join(cache_root, self.request_id)
        self.dbg_file = f'{self.request_id}.log'
        self.log = None

        if not os.path.exists(self.cache_path):
            os.mkdir(self.cache_path)

        log_q = ServiceLogger.instance().queue
        log_config = ServiceLogger.instance().worker_configurer

        process = Process(target=self.run, args=(log_q, log_config, ))
        process.daemon = True
        process.start()

    def run(self, log_q, log_config):
        self.log = self.get_logger(log_q, log_config, os.path.join(self.cache_path, self.dbg_file))
        self.inf(f'error summary process start {self.request_id}')

        self.io.change_status(self.request_id, 'running')

        zip_out = os.path.join(self.cache_path, 'error_summary.zip')
        excel_out = os.path.join(self.cache_path, 'error_summary.xlsx')
        zip_password = 'password'

        job = self.io.get_job(self.request_id)
        if job is None:
            self.err(f'invalid job {self.request_id}')
            raise RuntimeError('invalid job')

        error_summary = ErrorSummary()
        try:
            ret = error_summary.create_summary_zip(zip_out, excel_out, zip_password, 7, job['fab'])
            if ret != 0:
                self.err("create_summary_zip error!")
                self.io.change_status(self.request_id, 'error')
                return
        except ErrorSummaryException as msg:
            self.err(f'summary error {msg}')
            self.io.change_status(self.request_id, 'error')
            return

        self.inf(f'summary finish {self.request_id}')
        self.io.change_status(self.request_id, 'success', os.path.abspath(zip_out))
