import pandas as pd
import psycopg2
from psycopg2 import extras
import datetime


class DatabaseIF:
    """
    PostgresにアクセスするためのIFクラス
    """

    def __init__(self, **connection_config):
        self.connection_config = connection_config

    def execute_sql(self, sql_str):
        """
        SQLを実行する
        :param sql_str:
        :return:
        """
        with psycopg2.connect(**self.connection_config) as connection:
            connection.autocommit = True
            with connection.cursor() as cur:
                cur.execute(sql_str)
                ret_val = cur.fetchall()
        return ret_val

    def update_data(self, db_table, update_data, where_data):
        """
        データをUpdateする
        :param db_table:
        :param update_data:
        :param where_data:
        :return:
        """
        values = []
        key_str = ''
        is_first_elem = True

        update_key = update_data[0]
        update_value = update_data[1]
        where_key = where_data[0]
        where_value = where_data[1]

        sql_str = "UPDATE {} SET {} = %s WHERE {} = %s;".format(db_table, update_key, where_key)

        with psycopg2.connect(**self.connection_config) as connection:
            connection.autocommit = True
            with connection.cursor()as cur:
                cur.execute(sql_str, (update_value, where_value))

    def get_data(self, table, select_col='*'):
        """
        指定テーブルのデータをDBから取得する
        :param table: テーブル名
        :param select_col:
        :return: DataFrame
        """
        with psycopg2.connect(**self.connection_config) as connection:
            connection.autocommit = True
            sql_str = "SELECT {}  FROM {} ;".format(select_col, table)

            log_df = pd.read_sql(sql=sql_str, con=connection)
            return log_df

    def get_data_by_sql(self, sql):
        """
        指定したテーブル、SQLでデータをDataFrameとして取得
        :param sql:
        :return:
        """

        with psycopg2.connect(**self.connection_config) as connection:
            connection.autocommit = True
            log_df = pd.read_sql(sql=sql, con=connection)
            return log_df

    def get_data_by_sql_dict(self, sql):
        from psycopg2.extras import DictCursor
        import psycopg2
        with psycopg2.connect(**self.connection_config) as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
                cur.execute(sql)
                results = cur.fetchall()
                dict_result = []

                for row in results:
                    dict_result.append(dict(row))

                return dict_result

    def insert_data(self, db_table, insert_dict):
        """
        指定されたテーブルに辞書の中身をinsertする
        :param db_table: テーブル名
        :param insert_dict: insertする辞書データ
        :return:
        """
        values = []
        key_str = ''
        is_first_elem = True

        for key, value in insert_dict.items():
            # print(key)
            values.append(value)
            if not is_first_elem:
                key_str += ','
            is_first_elem = False
            key_str += key
        sql_str = "INSERT INTO " + db_table + " (" + key_str + ") VALUES %s"
        value_tuple = tuple(values)
        value_list = list()
        value_list.append(value_tuple)

        with psycopg2.connect(**self.connection_config) as connection:
            connection.autocommit = True
            with connection.cursor()as cur:
                extras.execute_values(cur, sql_str, value_list)

    def insert_df_data(self, table_name, insert_df):
        """
        指定されたテーブルにデータフレームをInsertする
        :param table_name: テーブル名
        :param insert_df: insertするデータフレーム
        :return:
        """
        for _, elem in insert_df.iterrows():
            values = []
            key_str = ''
            is_first_elem = True
            elem = elem.dropna()
            for key, value in elem.items():
                values.append(value)
                if not is_first_elem:
                    key_str += ','
                is_first_elem = False
                key_str += key

            sql_str = "INSERT INTO " + table_name + " (" + key_str + ") VALUES %s"
            value_tuple = tuple(values)
            value_list = list()
            value_list.append(value_tuple)
            with psycopg2.connect(**self.connection_config) as connection:
                connection.autocommit = True
                with connection.cursor()as cur:
                    extras.execute_values(cur, sql_str, value_list)

    def get_primary_key(self, table_name):
        """
        テーブルの主キーを取得する
        :param table_name:
        :return:
        """
        table_names = table_name.split('.')
        if len(table_names) == 2:
            # 'table_name' can have a schema name
            table_name = table_names[1]

        sql = "SELECT ccu.column_name \
                FROM  information_schema.table_constraints tb_con \
                INNER  JOIN  information_schema.constraint_column_usage ccu \
                    ON    tb_con.constraint_catalog = ccu.constraint_catalog \
                    AND   tb_con.constraint_schema = ccu.constraint_schema \
                    AND   tb_con.constraint_name = ccu.constraint_name \
                INNER JOIN information_schema.key_column_usage kcu \
                    ON   tb_con.constraint_catalog = kcu.constraint_catalog \
                    AND  tb_con.constraint_schema = kcu.constraint_schema \
                    AND  tb_con.constraint_name = kcu.constraint_name \
                    AND  ccu.column_name = kcu.column_name \
                WHERE tb_con.table_name = %s AND tb_con.constraint_type = 'PRIMARY KEY' ;"
        with psycopg2.connect(**self.connection_config) as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                # print(table_name)
                cur.execute(sql, [table_name])
                pkeys = cur.fetchall()
        pkey_list = []
        for pkey in pkeys:
            pkey_list.append(pkey[0])

        return pkey_list

    def is_running_data_duplicate(self, pkeys, values, data):
        """
        データの重複を確認する
        :param pkeys:
        :param values:
        :param data:
        :return:
        """

        data_list = []
        for pkey in pkeys:
            if pkey == 'log_date':
                date_str = data[pkey]
                if '/' in date_str:
                    y, m, h = date_str.split('/')
                    data_list.append(datetime.date(int(y), int(m), int(h)))
                elif '-' in date_str:
                    y, m, h = date_str.split('-')
                    data_list.append(datetime.date(int(y), int(m), int(h)))
                else:
                    data_list.append(date_str)
            else:
                data_list.append(data[pkey])
        # print(data_list)
        if tuple(data_list) in values:
            return True
        else:
            return False

    def get_db_data_by_key(self, keys, table):
        """
        指定したカラム、テーブルのデータを取得する
        :param keys:
        :param table:
        :return:
        """
        key_str = ''
        is_first_elem = True
        for key in keys:
            if not is_first_elem:
                key_str += ','
            is_first_elem = False
            key_str += key

        with psycopg2.connect(**self.connection_config) as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                sql = 'SELECT {} from {} ;'.format(key_str, table)
                cur.execute(sql)
                ret = cur.fetchall()
                return ret

    def insert_running_data(self, insert_df, table_name):
        """
        DBにデータをInsertする
        とりあえずrunning logに特化する
        :param insert_df: InsertするDataframe
        :param table_name: Table名
        :return:
        """
        pkeys = self.get_primary_key(table_name)  # 主キーを取得
        pkey_values = self.get_db_data_by_key(pkeys, table_name)  # 主キーの値のリストを作成
        if len(insert_df) == 0:
            return
        with psycopg2.connect(**self.connection_config) as conn:
            conn.autocommit = True

            insert_df = insert_df.drop_duplicates(pkeys)
            with conn.cursor() as cur:
                # とりあえず１行ずつInsertする.
                # 欠損値除去のためこのような処理にしている
                for _, elem in insert_df.iterrows():
                    values = []
                    key_str = ''
                    is_first_elem = True
                    elem = elem.dropna()  # 欠損値を除去する
                    if not self.is_running_data_duplicate(pkeys, pkey_values, elem):
                        for key, value in elem.items():
                            values.append(value)
                            if not is_first_elem:
                                key_str += ','
                            is_first_elem = False
                            key_str += key

                        sql_str = "INSERT INTO " + table_name + " (" + key_str + ") VALUES %s"
                        value_tuple = tuple(values)
                        value_list = []
                        value_list.append(value_tuple)
                        extras.execute_values(cur, sql_str, value_list)

    def exec_sql(self, sql, val_list):
        """
        SQLを実行する
        :param sql:
        :param val_list:
        :return:
        """
        with psycopg2.connect(**self.connection_config) as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                cur.execute(sql, val_list)
                ret = cur.fetchall()
                return ret
