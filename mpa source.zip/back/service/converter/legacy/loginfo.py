from service.converter.legacy.rsscommon import definfo
import numpy as np

class LogInfo:
    """
    Log情報データクラス
      Logを変換するための情報を持つ
    """

    def __init__(self, loginfo):
        # print(loginfo.shape)
        self.log_name = loginfo['log_name'].values[0]
        self.device_row = self.check_value(loginfo['device_row'].values[0])
        self.device_col = self.check_value(loginfo['device_column'].values[0])
        self.process_row = self.check_value(loginfo['process_row'].values[0])
        self.process_col = self.check_value(loginfo['process_column'].values[0])

        self.dir_row = self.check_value(loginfo['dir_row'].values[0])
        self.dir_col = self.check_value(loginfo['dir_column'].values[0])

        self.step_row = self.check_value(loginfo['step_row'].values[0])
        self.step_col = self.check_value(loginfo['step_column'].values[0])



        self.data_start = self.check_value(loginfo['data_start_row'].values[0])
        self.db_table = loginfo['db_table'].values[0]
        self.format = loginfo['log_format'].values[0]
        self.header_start = self.check_value(loginfo['column_name_row'].values[0])
        self.log_header = loginfo['log_header'].values[0]




    def check_value(self, val):
        """

        :param val:
        :return:
        """
        if val != val:
            return -1
        if val == np.nan:
            return -1
        else:
            return int(val)

    def _get_data_dict(self, column_info):
        """
        ログのヘッダ名とDBに格納するときのデータ名/型/係数を対応させる辞書を作成する
        :param column_info:
        :return:
        """
        col_numbers = column_info[definfo.COL_NUM]
        data_type = column_info[definfo.DATA_TYPE]
        param_list = column_info[definfo.OUTPUT_COL]
        coef_list_temp = column_info[definfo.COEF]

        name_dict = dict(zip(col_numbers, param_list))
        type_dict = dict(zip(param_list, data_type))

        coef_list = []
        for coef in coef_list_temp:
            if coef != coef:
                coef = 1
            elif str(coef).replace(',', '').replace('.', '').replace('-', '').isnumeric():
                coef = float(coef)
            else:
                coef = 1
            coef_list.append(coef)

        coef_dict = dict(zip(param_list, coef_list))
        return name_dict, type_dict, coef_dict
