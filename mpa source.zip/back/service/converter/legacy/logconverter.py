import datetime
import os
import sys
import csv
import codecs
# from rsscommon import definfo
import re
import pandas as pd
import numpy as np
from multiprocessing import Pool
import multiprocessing
import psycopg2
from psycopg2.extras import DictCursor

from service.converter.legacy.rsscommon import definfo


class LogConverter(object):
    """
    ログ変換のためのベースクラス
    このクラスを継承してログ種類毎の変換クラスを作成する
    """

    def __init__(self, log_define, data_define, eqp_info):
        """
        コンストラクタ
        :param log_define: ログ定義 ログのタイプ、DBの名前を定義する
        :param eqp_info: 解析ログのTool情報
        """

        #  基本変換クラス
        self.BASIC_CONVERTER = {'character': str,
                                'str': str
                                }

        # 数値変換クラス
        self.NUMERIC_CONVERTER = {'integer': int,
                                  'bigint': int,
                                  'float': float,
                                  'int': int
                                  }
        # 特殊変換クラス (時刻・日付)
        self.SPECIAL_CONVERTER = {'timestamp1': self._convert_datetime1,
                                  'timestamp2': self._convert_datetime2,
                                  'timestamp3': self._convert_datetime3,
                                  'timestamp4': self._convert_datetime4,
                                  'timestamp7': self._convert_datetime7,
                                  'date': self._convert_date,
                                  'time': self._convert_time
                                  }
        self.log_define = log_define
        self.eqp_info = eqp_info

    def output_db_data(self, log_file):
        """
        指定されたLogを定義にしたがいDBに格納できる形式に変換する
        :param log_file:変換対象のログファイル
        :return: 変換後のデータ(辞書形式)のリスト
        """

        return None

    def read_log_data(self, log_file):
        return None, None, None

    def get_param_name(self, column_define):
        """
        ログのヘッダ名とDBに格納するときのパラメータ名を対応させる辞書を作成する
        :param column_define: カラム情報　DF (DBから取り出したもの)
        :return:
        """

        ## 変換元のカラム名がキーで変換後のカラム名が値になる辞書を作成
        col_name = column_define[definfo.INPUT_COL]
        param_name = column_define[definfo.OUTPUT_COL]

        ret_dict = dict(zip(col_name, param_name))
        return ret_dict

    def convert_data(self, type_, value_, coef_=1):
        """
        データを指定型に変換
        :param type_: 型名
        :param value_: 値
        :return:
        """

        # NaN かどうかの判定
        if value_ != value_:
            return None
        # 型毎に変換処理を行う
        if type_ in self.NUMERIC_CONVERTER:  # 数値型の変換の場合
            if type(value_) == str and '*' in value_:  # 計測値に*が含まれる場合データを捨てる
                return None
            elif type(value_) == str:
                if self.is_num(value_):  # 数値データの変換
                    return self.NUMERIC_CONVERTER[type_](value_.strip()) * self.NUMERIC_CONVERTER[type_](coef_)
                else:
                    return None
            else:
                return self.NUMERIC_CONVERTER[type_](value_) * self.NUMERIC_CONVERTER[type_](coef_)

        elif type_ in self.BASIC_CONVERTER:  # 文字等の型変換
            return self.BASIC_CONVERTER[type_](value_)

        elif type_ in self.SPECIAL_CONVERTER:  # 時刻等特別な変換処理が必要な型変換
            return self.SPECIAL_CONVERTER[type_](value_)

        return None

    def _convert_time(self, value_):
        """
        時間データを変換する
        :param value_:
        :return:
        """
        time_list = value_.split(':')
        time_val = int(time_list[0]) * 3600 + int(time_list[1]) * 60 + int(time_list[2])
        return time_val

    def _convert_date(self, value_):
        """
        日付データを変換する
        :param value_:
        :return:
        """
        # daytime = datetime.datetime.strptime(value_, '%Y/%m/%d')
        # daydata = datetime.datetime(daytime.year, daytime.month, daytime.day)
        return value_

    def _convert_datetime1(self, value_):
        """
        YYYY/MM/DD hh:mm:ss形式の日時データを変換する
        :param value_:
        :return:
        """
        if str(value_).strip() == '0':
            return None
        value_ = str(value_).strip()
        if value_ == value_:
            year = value_[:4]
            month = value_[5:7]
            day = value_[8:10]
            hour = value_[11:13]
            minute = value_[14:16]
            second = value_[17:19]
            ret_str = '{}-{}-{} {}:{}:{}'.format(year, month, day, hour, minute, second)

            return ret_str
            # return datetime.datetime.strptime(str(value_), '%Y/%m/%d %H:%M:%S')
        return None

    def _convert_datetime2(self, value_):
        """
        YYYYMMDDhhmmss形式の日時データを変換する
        :param value_:
        :return:
        """
        if str(value_).strip() == '0':
            return None
        return datetime.datetime.strptime(str(value_).strip(), '%Y%m%d%H%M%S')

    def _convert_datetime3(self, value_):
        """
        YYYYMMDDhhmmss形式の日時データを変換する
        :param value_:
        :return:
        """
        if str(value_).strip() == '0':
            return None

        return datetime.datetime.strptime(str(value_).strip(), '%Y/%m/%d %H:%M:%S:%f')

    def _convert_datetime4(self, value_):
        """
        YYYYMMDDhhmmss形式の日時データを変換する
        :param value_:
        :return:
        """
        date, time = str(value_).split(' ')
        year, month, day = date.split('-')
        hour, minute, second = time.split(':')
        sec, msec = second.split('.')
        return datetime.datetime(int(year), int(month), int(day), int(hour), int(minute), int(sec), int(msec + '000'))

    def _convert_datetime7(self, value_):
        """
        YYYY/MM/DD hhmmss形式の日時データを変換する
        :param value_:
        :return:
        """
        date, time = str(value_).split(' ')
        year, month, day = date.split('/')
        hour = time[0:2]
        minute = time[2:4]
        sec = time[4:6]
        msec = time[6:8]
        return datetime.datetime(int(year), int(month), int(day), int(hour), int(minute), int(sec), int(msec + '000'))

    def is_num(self, s):
        """
        入力された値が数値データかどうかを確認する
        :param s:
        :return:
        """
        # 文字列から , . - を削除して数値かどうか確認

        return str(s).replace(',', '').replace('.', '').replace('-', '').isnumeric()


class StandardLogConverterNoHeader(LogConverter):
    """
    ヘッダなし形式(CSV形式)ファイルの変換クラス
    """

    def __init__(self, log_define, data_define, eqp_name, year=None):
        self.name_dict, self.type_dict, self.coef_dict = self._get_data_dict(data_define)
        if year is None:
            self.year = datetime.date.today().year
        else:
            self.year = year

        self.logfile = ''
        super().__init__(log_define, data_define, eqp_name)
        self.SPECIAL_CONVERTER['timestamp5'] = self._convert_datetime5

    def output_db_data(self, log_file):
        """
        指定されたLogを定義にしたがいDBに格納できる形式に変換する
        :param log_file:変換対象のログファイル
        :return: 変換後のデータ(辞書形式)のリスト
        """
        logdf = self.read_log_data(log_file)
        # data_list = []
        if logdf is None:
            # print("[ERROR:NO HEADER output_db_data] logdf is none :", log_file)
            return None

        # 型変換を行う
        # tqdm.pandas(desc="Type Convert")
        # converted_df = logdf.progress_apply(self.convert_series_data)

        # 年月日変換時の年をファイル名から求める
        # ファイル名が年で始まらない場合はコンストラクタで指定されたものを使用する
        # 本処理は旧ログにのみ必要なので、2020年以降は必要ないはず。
        tmpyear = self.year

        logfile_base = os.path.basename(log_file)
        self.logfile = logfile_base
        if logfile_base.startswith('201') or logfile_base.startswith('202'):
            self.year = int(logfile_base[:4])

        converted_df = logdf.apply(self.convert_series_data)
        self.year = tmpyear

        #  log_timeがカラムにある場合、同じ時間のログを識別するためのindexを付加する
        if 'log_time' in converted_df.columns.values:
            logtime_duplicate = converted_df.duplicated(subset='log_time')
            idx_list = self.create_same_time_idx(logtime_duplicate)
            converted_df['log_idx'] = idx_list

        #  occurred_dateがカラムにある場合、同じ時間のログを識別するためのindexを付加する
        elif 'occurred_date' in converted_df.columns.values:
            logtime_duplicate = converted_df.duplicated(subset='occurred_date')
            idx_list = self.create_same_time_idx(logtime_duplicate)
            converted_df['log_idx'] = idx_list

        self.logfile = ''
        return converted_df

    def create_same_time_idx(self, logtime_duplicate):
        """
        同じ日時のログのインデックスを作成する

        :param logtime_duplicate:  同じ日時で重複しているがどうかのlist(Trueが重複している)
        :return:
        """
        ret_list = []
        cnt = 1
        # 引数のリスト内にTrueがある場合直前の項目と日時が重複しているのでそれを利用する。
        for i in logtime_duplicate:
            if not i:  # Falseの場合
                idx = 0
                cnt = 1
            else:  # Trueの場合
                idx = cnt
                cnt += 1
            ret_list.append(idx)
        return ret_list

    def convert_series_data(self, ser_value_):
        """
        データを指定型に変換
        :param ser_value_: 値(Seres形式)
        :return:
        """
        col_name = ser_value_.name
        ret_list = []
        if col_name in self.type_dict:
            type_ = self.type_dict[col_name]
            coef_ = self.coef_dict[col_name]
        else:
            return ser_value_
        convert_val = ser_value_
        if type_ in self.SPECIAL_CONVERTER:  # 日時等の変換処理
            # return ser_value_
            # with Pool(1) as pool:
            #     convert_val = pool.map(self.SPECIAL_CONVERTER[type_], ser_value_.values)
            #     ret_list = convert_val
            for value in ser_value_.values:
                ret_list.append(self.SPECIAL_CONVERTER[type_](value))
        elif type_ == 'timestamp6':
            ret_list = self._convert_datetime6(ser_value_.values)

        else:
            for value_ in ser_value_.values:
                # 型毎に変換処理を行う
                convert_val = None
                if type_ in self.NUMERIC_CONVERTER:  # 数値型の変換の場合
                    convert_val = self.convert_numeric_type(type_, value_, coef_)
                elif type_ in self.BASIC_CONVERTER:  # 文字等の型変換
                    if value_ == value_:
                        convert_val = self.BASIC_CONVERTER[type_](value_).strip()
                    else:
                        convert_val = ''
                ret_list.append(convert_val)
        return ret_list

    def convert_numeric_type(self, type_, value_, coef_):
        """
        数値データの変換処理
        値にcoefを乗じて型変換を行う
        欠損値の場合、欠損値のままではDB格納に支障をきたすため
        :param type_:
        :param value_:
        :param coef_:
        :return:
        """
        if value_ == (-99999999999999):
            return (-99999999999999)

        if value_ != value_:  # 欠損値の場合
            # 欠損値の場合あり得ない値にする
            # convert_val = self.NUMERIC_CONVERTER[type_](-99999999999999)
            convert_val = -99999999999999
        # 値に*が含まれるか'-',''の場合
        if type(value_) is str:
            value_ = value_.strip()
        if type(value_) is str and ('*' in value_ or value_ == '-' or value_ == ''):
            # あり得ない値にする
            # convert_val = self.NUMERIC_CONVERTER[type_](-99999999999999)
            convert_val = -99999999999999
        elif not self.is_num(value_):
            # convert_val = self.NUMERIC_CONVERTER[type_](-99999999999999)
            convert_val = -99999999999999
        # 小数型の場合
        elif type_ == 'float':

            convert_val = float(coef_) * float(value_)
        else:
            convert_val = int(round(float(coef_) * float(value_)))
        return convert_val

    def read_log_data(self, log_file):
        """
        ログファイルを読み込みTool情報、job情報をログに応じて付加する
        :param log_file:
        :return:
        """
        lines = []
        header = []
        device = None
        process = None
        extend_dict = {}
        header_ext = []

        # Header位置
        # col_name_row = int(self.log_define['column_name_row'])
        # Logデータ開始位置
        data_start = self.log_define.data_start

        # device/process 位置情報
        device_row = int(self.log_define.device_row)
        device_col = int(self.log_define.device_col)
        process_row = int(self.log_define.process_row)
        process_col = int(self.log_define.process_col)
        dir_row = int(self.log_define.dir_row)
        dir_col = int(self.log_define.dir_col)
        step_row = int(self.log_define.step_row)
        step_col = int(self.log_define.step_col)

        device_name = None
        process_name = None
        plate_dir = None
        step_num = None

        headers = None
        # logファイルを読み込み、Device/Process情報を取得
        # header情報を取得する
        # print(log_file)

        with codecs.open(log_file, 'r', 'utf-8', 'ignore') as f:  # ファイルをopen
            line_cnt = 1
            for line in f:

                # Device/Process情報を読み込み変換する
                if process_row == process_row:
                    process_row = int(process_row)
                    process_col = int(process_col)

                if device_row == device_row:
                    device_row = int(device_row)
                    device_col = int(device_col)

                # デバイス名の取得
                if device_row == device_row and device_row == line_cnt:
                    line_elem = [x.strip() for x in line.split(',')]
                    device = line_elem[device_col - 1]
                    device_name = device

                # プロセス名の取得
                if process_row == process_row and process_row == line_cnt:
                    line_elem = [x.strip() for x in line.split(',')]
                    process = line_elem[process_col - 1]
                    process_name = process

                # Plate Directionの取得

                if dir_row == dir_row and dir_row == line_cnt:
                    # print('direction')
                    line_elem = [x.strip() for x in line.split(',')]

                    plate_dir = line_elem[dir_col - 1]
                    # print(plate_dir)

                if step_row == step_row and step_row == line_cnt:
                    # print('step_num')
                    line_elem = [x.strip() for x in line.split(',')]

                    step_num = line_elem[step_col - 1]
                    # print(step_num)

                elif line_cnt >= data_start:  # データ開始行以降のデータを読み込み最終的なヘッダを作成する
                    col_num = len(line.split(','))
                    if col_num != len(self.name_dict):  # 定義でのカラム数と実際のカラム数が同じかどうかを確認
                        if line.split(',')[-1] == '\n' and col_num - 1 == len(self.name_dict):  # 最終列に無駄なカンマがある場合
                            read_col = range(col_num - 1)

                        else:
                            return None  # 同じでない場合は処理を中止
                    else:
                        read_col = range(col_num)
                    headers = list()
                    for idx in range(len(self.name_dict)):
                        headers.append(self.name_dict[idx + 1])
                    break
                line_cnt += 1

        # ログファイルを読み込みDataFrame形式にする
        log_df = pd.read_csv(log_file, names=headers, skiprows=data_start - 1, usecols=read_col, index_col=False,
                             sep=',')
        # log_df.to_csv('output.csv')
        log_df['equipment_name'] = self.eqp_info.eqp_name
        if device_name is not None:
            log_df['device'] = device_name
        if process_name is not None:
            log_df['process'] = process_name
        if plate_dir is not None:
            log_df['direction'] = plate_dir
        if step_num is not None:
            log_df['step_num'] = step_num

        return log_df

    def _get_data_dict(self, define):
        """
        ログのヘッダ名とDBに格納するときのデータ名/型/係数を対応させる辞書を作成する
        :param define:
        :return:
        """
        col_numbers = define[definfo.COL_NUM]
        data_type = define[definfo.DATA_TYPE]
        param_list = define[definfo.OUTPUT_COL]
        coef_list_temp = define[definfo.COEF]
        name_dict = dict(zip(col_numbers, param_list))
        type_dict = dict(zip(param_list, data_type))
        coef_list = []
        for coef in coef_list_temp:
            if coef != coef:
                coef = 1.0
            elif self.is_num(coef):
                coef = float(coef)
            else:
                coef = 1.0
            coef_list.append(coef)
        coef_dict = dict(zip(param_list, coef_list))
        return name_dict, type_dict, coef_dict

    def _convert_datetime5(self, value_):
        """
        MMDDhhmmss形式の日時データを変換する
        :param value_:
        :return:
        """
        try:
            date, time = str(value_).split(' ')
        except:
            return datetime.datetime(int(2000), int(1), int(1), int(0), int(0), int(0))

        year = self.year
        month, day = date.split('/')
        if self.logfile.startswith('201') or self.logfile.startswith('202'):
            if self.logfile[4:6] == '01' and month == '12':  # ファイル名の月が1月でログの月が12月の場合年を-1
                year = year - 1
        hour, minute, second = time.split(':')
        return datetime.datetime(int(year), int(month), int(day), int(hour), int(minute), int(second))

    def _convert_datetime6(self, input_data):
        inv_logtime = input_data[::-1]
        now_year = self.year
        lastmonthday = 9999
        new_time = list()
        for elem in inv_logtime:
            conv_monthday = self._get_month_day(elem)
            if conv_monthday > lastmonthday:
                now_year -= 1
            new_time.append(str(now_year) + '/' + elem)
            lastmonthday = conv_monthday
        return new_time[::-1]

    def _get_month_day(self, input_day):
        tmp = input_day.split(' ')[0]
        monthday = int(tmp.split('/')[0]) * 100 + int(tmp.split('/')[1])
        return monthday


class StandardLogConverter(LogConverter):
    """
    標準形式(CSV形式)ファイルの変換クラス
    """

    def __init__(self, log_define, data_define, eqp_info):
        self.name_dict, self.type_dict, self.coef_dict, self.num_dict, self.sub_name_dict = self._get_data_dict(
            data_define)
        super().__init__(log_define, data_define, eqp_info)

    def output_db_data(self, log_file):
        """
        指定されたLogを定義に従いDBに格納できる形式に変換する
        :param log_file:変換対象のログファイル
        :return: 変換後のデータ(辞書形式)のリスト
        """
        # ログを読み込む
        logdf = self.read_log_data(log_file)
        # data_list = []

        if logdf is None:
            # print("[ERROR:HEADER output_db_data] logdf is none :", log_file)
            return None

        # 読み込んだログのヘッダと定義されたヘッダ情報を比較し、ログにないものを抜き出す
        not_exist_header = [i for i in self.name_dict.keys() if i not in logdf.columns]

        """
        # ####################################
        # Header名が変更されたログの対応 (START)
        # convert_columns_define DBに"input_col_name_sub"Fieldを追加し、
        # not_exist_header にある項目が"input_col_name_sub"Fieldにある場合
        # その値(Header名)に変更する。
        not_exist_header_dellist = list()

        for col in not_exist_header:
            if col in self.sub_name_dict.keys():
                not_exist_header_dellist.append(col)

                sub_name = self.sub_name_dict[col]

                # self.name_dictのinput_col_nameをinput_col_name_subに変更
                self.name_dict[sub_name] = self.name_dict[col]
                del self.name_dict[col]

                # self.type_dictのinput_col_nameをinput_col_name_subに変更
                self.type_dict[sub_name] = self.type_dict[col]
                del self.type_dict[col]

                # self.coef_dictのinput_col_nameをinput_col_name_subに変更
                self.coef_dict[sub_name] = self.coef_dict[col]
                del self.coef_dict[col]

                # self.num_dictのinput_col_nameをinput_col_name_subに変更
                for idx in range(len(self.num_dict)):
                    if self.num_dict[idx+1] == col:
                        self.num_dict[idx+1] = sub_name
                        break;                            

        for dellist in not_exist_header_dellist:
            not_exist_header.remove(dellist)

        # Header名が変更されたログの対応 (END)
        # #################################### 
        """

        unexpected_header = [i for i in logdf.columns if i not in self.name_dict.keys()]

        # 上記で抜き出した存在しないヘッダをログデータに付加する
        for col in not_exist_header:
            if col.lower() != 'device' and col.lower() != 'process':
                val = self.get_col_null(col)
                logdf[col] = val

        # col_list = list()

        # for idx in range(len(self.num_dict)):
        #    col_list.append(self.num_dict[idx+1])

        if 'device' in logdf.columns:
            # col_list.append('device')
            if 'device' in unexpected_header:
                unexpected_header.remove('device')

        if 'process' in logdf.columns:
            # col_list.append('process')
            if 'process' in unexpected_header:
                unexpected_header.remove('process')

        if 'equipment_name' in logdf.columns:
            # col_list.append('equipment_name')
            if 'equipment_name' in unexpected_header:
                unexpected_header.remove('equipment_name')

        if 'direction' in logdf.columns:
            # col_list.append('direction')
            if 'direction' in unexpected_header:
                unexpected_header.remove('direction')

        # print(sorted(list(logdf.columns)))
        # print(sorted(col_list))
        # logdf.columns = col_list
        # print(col_list.sort())
        # 型変換を行う
        # tqdm.pandas(desc="Type Convert")
        # converted_df = logdf.progress_apply(self.convert_series_data)

        # 変換DBに定義が無いカラム行を削除
        for i in unexpected_header:
            del logdf[i]

        converted_df = logdf.apply(self.convert_series_data)
        # ヘッダをDBのカラム名に合わせる
        headers = [self.name_dict[i] if i in self.name_dict else i for i in converted_df.columns]
        converted_df.columns = headers

        #  log_timeがカラムにある場合、同じ時間のログを識別するためのindexを付加する
        if 'log_time' in headers:
            logtime_duplicate = converted_df.duplicated(subset='log_time')
            idx_list = self.create_same_time_idx(logtime_duplicate)
            converted_df['log_idx'] = idx_list

        #  occurred_dateがカラムにある場合、同じ時間のログを識別するためのindexを付加する
        elif 'occurred_date' in headers:
            logtime_duplicate = converted_df.duplicated(subset='occurred_date')
            idx_list = self.create_same_time_idx(logtime_duplicate)
            converted_df['log_idx'] = idx_list

        ret_df = converted_df.sort_index(axis=1)

        return ret_df

    def create_same_time_idx(self, logtime_duplicate):
        """
        同じ日時のログのインデックスを作成する

        :param logtime_duplicate:  同じ日時で重複しているがどうかのlist(Trueが重複している)
        :return:
        """
        ret_list = []
        cnt = 1
        # 引数のリスト内にTrueがある場合直前の項目と日時が重複しているのでそれを利用する。
        for i in logtime_duplicate:
            if not i:  # Falseの場合
                idx = 0
                cnt = 1
            else:  # Trueの場合
                idx = cnt
                cnt += 1
            ret_list.append(idx)
        return ret_list

    def convert_series_data(self, ser_value_):
        """
        データを指定型に変換
        :param ser_value_: 値
        :return:
        """
        col_name = ser_value_.name
        ret_list = []
        if col_name in self.type_dict:
            type_ = self.type_dict[col_name]
            coef_ = self.coef_dict[col_name]
        else:
            return ser_value_
        convert_val = ser_value_

        if type_ in self.SPECIAL_CONVERTER:  # 日時等の変換処理
            # with Pool(1) as pool:  # 日時変換は複数スレッドで処理する
            #     convert_val = pool.map(self.SPECIAL_CONVERTER[type_], ser_value_.values)
            #     ret_list = convert_val
            for value in ser_value_.values:
                ret_list.append(self.SPECIAL_CONVERTER[type_](value))
        else:
            for value_ in ser_value_.values:
                # 型毎に変換処理を行う
                convert_val = None
                if type_ in self.NUMERIC_CONVERTER:  # 数値型の変換の場合
                    convert_val = self.convert_numeric_type(type_, value_, coef_)
                elif type_ in self.BASIC_CONVERTER:  # 文字等の型変換
                    if value_ == value_:
                        convert_val = self.BASIC_CONVERTER[type_](value_).strip()
                    else:
                        convert_val = ''
                ret_list.append(convert_val)
        return ret_list

    def convert_numeric_type(self, type_, value_, coef_):
        """
        数値データの変換処理
        値にcoefを乗じて型変換を行う
        欠損値の場合、欠損値のままではDB格納に支障をきたすため
        :param type_:
        :param value_:
        :param coef_:
        :return:
        """
        if value_ == (-99999999999999):
            return (-99999999999999)

        if value_ != value_:  # 欠損値の場合
            # 欠損値の場合あり得ない値にする
            # convert_val = self.NUMERIC_CONVERTER[type_](-99999999999999)
            convert_val = -99999999999999
        # 値に*が含まれるか'-',''の場合
        if type(value_) is str:
            value_ = value_.strip()
        if type(value_) is str and ('*' in value_ or value_ == '-' or value_ == ''):
            # あり得ない値にする
            # convert_val = self.NUMERIC_CONVERTER[type_](-99999999999999)
            convert_val = -99999999999999
        elif not self.is_num(value_):
            # convert_val = self.NUMERIC_CONVERTER[type_](-99999999999999)
            convert_val = -99999999999999
        # 小数型の場合
        elif type_ == 'float':

            convert_val = float(coef_) * float(value_)
        else:
            convert_val = int(round(float(coef_) * float(value_)))
        return convert_val

    def read_log_data(self, log_file):
        """
        ログファイルを読み込みTool情報、job情報をログに応じて付加する
        :param log_file:
        :return:
        """
        lines = []
        header = []
        device = None
        process = None
        extend_dict = {}
        header_ext = []
        # Header位置
        col_name_row = int(self.log_define.header_start)
        # Logデータ開始位置
        data_start = int(self.log_define.data_start)
        # device/process 位置情報
        device_row = self.log_define.device_row
        device_col = self.log_define.device_col
        process_row = self.log_define.process_row
        process_col = self.log_define.process_col
        dir_row = int(self.log_define.dir_row)
        dir_col = int(self.log_define.dir_col)
        step_row = int(self.log_define.step_row)
        step_col = int(self.log_define.step_col)

        device_name = None
        process_name = None
        plate_dir = None
        step_num = None

        # logファイルを読み込み、Device/Process情報を取得
        # header情報を取得する
        # print(log_file)
        with codecs.open(log_file, 'r', 'utf-8', 'ignore') as f:  # ファイルをopen
            line_cnt = 1
            for line in f:
                # Device/Process情報を読み込み変換する
                if process_row == process_row:
                    process_row = int(process_row)
                    process_col = int(process_col)
                if device_row == device_row:
                    device_row = int(device_row)
                    device_col = int(device_col)

                # デバイス名の取得
                if device_row == device_row and device_row == line_cnt:
                    line_elem = [x.strip() for x in line.split(',')]
                    device = line_elem[device_col - 1]
                    device_name = device

                # プロセス名の取得
                if process_row == process_row and process_row == line_cnt:
                    line_elem = [x.strip() for x in line.split(',')]
                    process = line_elem[process_col - 1]
                    process_name = process

                # Plate Directionの取得
                if dir_row == dir_row and dir_row == line_cnt:
                    line_elem = [x.strip() for x in line.split(',')]
                    plate_dir = line_elem[dir_col - 1]

                # Step Numの取得
                if dir_row == step_row and step_row == line_cnt:
                    line_elem = [x.strip() for x in line.split(',')]
                    step_num = line_elem[step_col - 1]

                if line_cnt == col_name_row:  # Headerまで読み飛ばす
                    if line.startswith('#'):  # ヘッダの先頭に#がある場合#を読み飛ばす
                        header = line[1:]
                    else:  # ヘッダは必ず#で始まるのでが無い場合は不正なログとみなす
                        return None

                elif line_cnt >= data_start:  # データ開始行以降のデータを読み込み最終的なヘッダを作成する
                    col_num = len(line.split(','))
                    header_num = len(header.split(','))
                    if col_num > header_num:
                        header_ext = ['col_' + str(i) for i in range(header_num, col_num - header_num)]
                    break
                line_cnt += 1

        headers = [x.strip() for x in header.split(',')]
        headers.extend(header_ext)

        # ログファイルを読み込みDataFrame形式にする
        log_df = pd.read_csv(log_file, names=headers, skiprows=data_start - 1, index_col=False, sep=',')
        log_df = log_df.drop(header_ext, axis=1)
        # log_df.to_csv('output.csv')
        log_df['equipment_name'] = self.eqp_info.eqp_name
        if device_name is not None:
            log_df['device'] = device_name
        if process_name is not None:
            log_df['process'] = process_name

        if plate_dir is not None:
            log_df['direction'] = plate_dir

        if step_num is not None:
            log_df['step_num'] = step_num

        return log_df

    def get_col_null(self, col_name):
        """
        カラムに応じたNULLを取得する
        :param col_name:
        :return:
        """
        type_ = self.type_dict[col_name]
        if type_ in self.SPECIAL_CONVERTER:  # 日時等の変換処理
            return None
        else:
            if type_ in self.NUMERIC_CONVERTER:  # 数値型の変換の場合
                return -99999999999999
            elif type_ in self.BASIC_CONVERTER:  # 文字等の型変換
                return None

    def _get_data_dict(self, define):
        """
        ログのヘッダ名とDBに格納するときのデータ名/型/係数を対応させる辞書を作成する
        :param define:
        :return:
        """
        col_name = define[definfo.INPUT_COL].astype(str)
        sub_col_name = define[definfo.SUB_COL_NAME].astype(str)
        data_type = define[definfo.DATA_TYPE]
        param_list = define[definfo.OUTPUT_COL]
        coef_list_temp = define[definfo.COEF]
        numlist = define[definfo.COL_NUM]
        name_dict = dict(zip(col_name, param_list))
        type_dict = dict(zip(col_name, data_type))
        num_dict = dict(zip(numlist, col_name))
        sub_name_dict = dict(zip(col_name, sub_col_name))

        coef_list = []
        for coef in coef_list_temp:
            if coef != coef:
                coef = 1
            elif self.is_num(coef):
                coef = float(coef)
            else:
                coef = 1
            coef_list.append(coef)

        coef_dict = dict(zip(col_name, coef_list))
        return name_dict, type_dict, coef_dict, num_dict, sub_name_dict


class RunningLogConverter(LogConverter):
    """
    CRAS用データ解析クラス
    """
    CRAS_LOG_STR = '【Remote Support】'
    # CRAS_LOG_STR = '【New】'
    PARAM_PTN = '(.+\[.+\])'
    PARAM_PTN_1 = '(IL PRS4)'
    AVE_PTN = 'Average = ([+-]?[0-9]+(\.[0-9]*)?([eE][+-]?[0-9]+)?)'
    MAX_PTN = 'Max = ([+-]?[0-9]+(\.[0-9]*)?([eE][+-]?[0-9]+)?)'
    MIN_PTN = 'Min = ([+-]?[0-9]+(\.[0-9]*)?([eE][+-]?[0-9]+)?)'
    LOG_NAME = 'cras.xlsx'
    STR_LIST = ['Serial Number', 'ToolID']
    DATE_LIST = ['Day']
    TIME_LIST = ['Tact time', 'Plate transfer waiting time']
    INT_LIST = ['Plate unload number', 'Manual Assist Time', 'Pause time', 'Mask transfer number']

    def __init__(self, log_define, data_define, eqp_name):
        self.parameter_define = data_define
        super().__init__(log_define, data_define, eqp_name)

    def output_db_data(self, log_file):
        """
        稼働率ログをDB格納用データに変換する
        :param log_file:
        :return:
        """
        converted_list = []

        log = self.read_log_data(log_file).split('\n')
        converted_data_running = dict()
        for define in self.parameter_define.iterrows():  # 定義項目を一つ取り出しループ
            converted_data_running.update(self.exec_running_econvert_(log, define))  # 文字列を'/'で分割して解析処理を実行

        if converted_data_running:  # データが変換できた場合Tool情報,logtypeを付加する
            converted_data_running['equipment_name'] = self.eqp_info.eqp_name

        try:
            converted_data_cras = self.exec_convert_(log)  # 文字列を'/'で分割して解析処理を実行

            converted_data_running.update(converted_data_cras)
            converted_list.append(converted_data_running)

        except ValueError:
            print('ValueError Exception')
            converted_list.append(converted_data_running)
            pass

        return converted_list

    def read_log_data(self, log_file):
        """
        ログファイルを読み込む
        :param log_file:
        :return:
        """

        lines = []
        header = []
        device = None
        process = None
        extend_dict = {}
        with codecs.open(log_file, 'r', 'utf-8', 'ignore') as f:  # ファイルをopen
            lines = f.read()

        return lines

    def exec_convert_(self, log):
        """
        ログ変換の実行
        :param log:  ログの内容
        :return:
        """

        idx = log.index(RunningLogConverter.CRAS_LOG_STR)
        category = ''
        cras_data = {}

        cat_ptn = re.compile('●(.+)')
        prm_ptn = re.compile(RunningLogConverter.PARAM_PTN)
        prm_ptn_1 = re.compile(RunningLogConverter.PARAM_PTN_1)
        ave_ptn = re.compile(RunningLogConverter.AVE_PTN)
        max_ptn = re.compile(RunningLogConverter.MAX_PTN)
        min_ptn = re.compile(RunningLogConverter.MIN_PTN)
        for line in log[idx + 1:]:

            # カテゴリ名を抜き出す
            match = cat_ptn.search(line)
            if match:
                # 行末のカンマを削除
                category = match.group(1).rstrip()
                category = category.replace(',', '').rstrip() + ' '
                if 'Mount Press Monitor' not in category:
                    category = ''
                else:
                    category = 'Mount Press '

            else:
                # パラメータ名の抜き出し
                param_name = ''
                param_match = prm_ptn.search(line)

                if not param_match:  # Averageがない場合別のパターンで試す
                    param_match = prm_ptn_1.search(line)
                if param_match:
                    param_name = param_match.group(1).rstrip().replace('.', '')

                # 平均値の抜き出し
                param_match = ave_ptn.search(line)
                if param_match:  # Averageがある場合
                    ave_str = param_match.group(1)
                    ave = float(ave_str)
                    cras_data[category + param_name + ' Average'] = ave

                # 最大値の抜き出し
                param_match = max_ptn.search(line)
                if param_match:  # MAXがある場合
                    max_val = float(param_match.group(1))
                    cras_data[category + param_name + ' Max'] = max_val

                # 最小値の抜き出し
                param_match = min_ptn.search(line)
                if param_match:  # MINがある場合
                    min_val = float(param_match.group(1))
                    cras_data[category + param_name + ' Min'] = min_val

        return cras_data

    def exec_running_convert_(self, log, define):
        """
        ログデータを受け取り
        :param log:
        :param define:

        :return:
        """
        converted_data = dict()
        param_name = define[1]['parameter_name']
        for line in log:  # logから1行ずつ取り出しパターンにマッチするか検索
            if param_name in line:  # パラメータの検索文字列があるか判断
                pat_str = define[1]['pattern']
                match = re.search(pat_str, line)  # パラメータパターンで検索
                if match:  # マッチした場合
                    val = match.group(int(define[1]['group_pattern']))
                    converted_data[define[1]['db_column']] = self.convert_data(define[1]['data_type'], val)
        return converted_data

    def _get_val_list(self, log, param_list):
        """
        logからパラメータリストに対応する値のリストを作成する
        :param log:
        :param param_list:
        :return:
        """
        val_list = []
        for param in param_list:
            param = param.rstrip()
            val = self.get_param_val(param, log)
            val_list.append(val)

        return val_list

    def get_param_val(self, param, log):
        """

        :param param:
        :param log:
        :return:
        """
        log_key = log.keys()

        for name in log_key:

            if name == param:
                return log[name]
        return ''


class RunningLog(LogConverter):
    """
    稼働率ログデータクラス
    """

    def __init__(self, log_define, data_define, eqp_info):
        """

        :param log_define:
        :param data_define:
        :param eqp_info:
        """
        self.parameter_define = data_define
        super().__init__(log_define, data_define, eqp_info)

    def read_log_data(self, log_file):
        """
        ログファイルを読み込む
        :param log_file:
        :return:
        """

        lines = []
        header = []
        device = None
        process = None
        extend_dict = {}
        with codecs.open(log_file, 'r', 'utf-8', 'ignore') as f:  # 1行ごとにリストに入れる
            lines = f.read()

        return lines

    def output_db_data(self, log_file):
        """
        稼働率ログをDB格納用データに変換する
        :param log_file:
        :return:
        """
        converted_list = []
        log = self.read_log_data(log_file).split('\n')
        convert_result = self.convert_log(log)  # 文字列を'/'で分割して解析処理を実行
        return convert_result

    def convert_log(self, log):
        """
    　　Logデータを受け取り、変換する
        """

        converted_data = {}
        for define in self.parameter_define.iterrows():  # 定義項目を一つ取り出しループ

            if type(log) == bytes:  # Byte列の場合UTF-8にエンコードする
                log = log.decode('utf-8')
            self.exec_convert(log, define, converted_data)  # 文字列を'/'で分割して解析処理を実行

        converted_data['equipment_name'] = self.eqp_info.eqp_name

        retdf = pd.DataFrame([converted_data])
        return retdf

    def exec_convert(self, log, define, converted_data):
        """
        ログデータを受け取り
        :param log:
        :param define:
        :param converted_data:
        :return:
        """
        param_name = define[1]['parameter_name']
        # print(param_name)
        for line in log:  # logから1行ずつ取り出しパターンにマッチするか検索
            if param_name in line:  # パラメータの検索文字列があるか判断
                pat_str = define[1]['pattern']
                match = re.search(pat_str, line)  # パラメータパターンで検索
                if match:  # マッチした場合
                    val = match.group(int(define[1]['group_pattern']))
                    converted_data[define[1]['db_column']] = self.convert_type(val, define[1]['data_type'])

    def convert_type(self, val, type_):
        """
        入力された変数を型変換する
        :param val:
        :param type_:
        :return:
        """
        if type_ == 'int':
            return int(val)
        elif type_ == 'float':
            return float(val)
        elif type_ == 'date':  # 日付はISO形式に
            return val.replace('/', '-')
        elif type_ == 'time':  # 時間はそのまま文字列
            if val[:2] == '24':
                val = '23:59:59'
            return val

        else:  # その他はとりあえず文字列にする
            return str(val)


class ChamberConverter(LogConverter):
    """
    Chamber logファイルの変換クラス
    """

    def __init__(self, log_define, data_define, eqp_info):
        self.colname = list(data_define['output_col_name'])
        # print(self.colname)
        super().__init__(log_define, data_define, eqp_info)

    def output_db_data(self, log_file):
        """
        指定されたLogを定義にしたがいDBに格納できる形式に変換する
        :param log_file:変換対象のログファイル
        :return: 変換後のデータ(辞書形式)のリスト
        """
        # data_list = []

        with open(log_file, encoding='shift_jis') as f:
            line = f.readline()
            skip_row = 0
            if line[1] == 'P':
                skip_row = 3
            elif line[1] == 'D' or line[0] == 'D':
                skip_row = 1
        try:
            logdf = pd.read_csv(log_file, names=self.colname, skiprows=skip_row, encoding='shift_jis', index_col=False)
        except:
            logdf = pd.read_csv(log_file, names=self.colname, skiprows=skip_row, encoding='utf_8', index_col=False)

        if len(logdf) == 0:
            return None

        if 'date' in logdf.columns:
            date_str = 'date'
        else:
            date_str = 'Date'

        if 'time' in logdf.columns:
            time_str = 'time'
        else:
            time_str = 'Time'

        date_s = logdf[date_str].replace('/', '-')
        time_s = logdf[time_str]
        logdf['log_time'] = logdf[date_str].replace('/', '-') + ' ' + logdf[time_str]
        logdf.drop([date_str, time_str], axis=1, inplace=True)
        logdf['equipment_name'] = self.eqp_info.eqp_name

        #  1秒毎のデータの場合5秒毎にダウンサンプリングする
        #  1秒程度データが飛ぶことがあるので複数のデータで確認
        a = logdf.iloc[3]['log_time']
        b = logdf.iloc[4]['log_time']
        c = logdf.iloc[5]['log_time']

        adt = datetime.datetime.strptime(a, '%Y/%m/%d %H:%M:%S')
        bdt = datetime.datetime.strptime(b, '%Y/%m/%d %H:%M:%S')
        cdt = datetime.datetime.strptime(c, '%Y/%m/%d %H:%M:%S')
        time_diff1 = bdt - adt
        time_diff2 = cdt - bdt
        if time_diff1.seconds < 2 or time_diff2.seconds < 2:
            logdf = logdf[::5]

        return logdf


class VersionConverter(LogConverter):
    """
    Version情報の変換クラス
    """

    def __init__(self, log_define, data_define, eqp_info):
        self.colname = list(data_define['output_col_name'])
        # print(self.colname)
        super().__init__(log_define, data_define, eqp_info)

    def output_db_data(self, log_file):
        """
        指定されたLogを定義にしたがいDBに格納できる形式に変換する
        :param log_file:変換対象のログファイル
        :return: 変換後のデータ(辞書形式)のリスト
        """
        # data_list = []

        try:
            logdf = pd.read_csv(log_file, names=self.colname, encoding='shift_jis')
        except:
            logdf = pd.read_csv(log_file, names=self.colname, encoding='utf_8')

        if len(logdf) == 0:
            return None

        for col in logdf.columns:
            logdf[col] = logdf[col].map(str.strip)

        logdf['log_time'] = datetime.date.today()
        logdf['equipment_name'] = self.eqp_info.eqp_name

        return logdf


class StatusMonitorConverter(LogConverter):
    """
    StatusMonitor情報の変換クラス
    """

    def __init__(self, log_define, data_define, eqp_info):
        self.host = '10.147.1.144'
        self.port = 5432
        self.dbname = 'settings'
        self.user = 'rssuser'
        self.password = 'rssuser'

        # self.colname = list(data_define['output_col_name'])
        # print(self.colname)
        super().__init__(log_define, data_define, eqp_info)

    def getConnection(self):
        return psycopg2.connect(
            f'host={self.host} port={self.port} dbname={self.dbname} user={self.user} password={self.password}')

    def getTargetRowAll(self, tablename, select='*'):
        '''
        テーブルの全情報を取得してDataFlameで返す
        検索対象が存在しない場合は空のDataFlameを返す
        '''
        with self.getConnection() as conn:
            df = pd.read_sql(sql=f"SELECT {select} FROM {tablename}", con=conn)

        return df

    def check_event(self, event, start, end, input_data):
        is_started = False
        start_time = None

        output_list = list()

        for _, elem in input_data.iterrows():
            if elem.Event == start:
                start_time = elem['Date Time']
                is_started = True

            elif is_started is True and elem.Event == end:
                output_data = dict()
                output_data['event'] = event

                output_data['start_time'] = start_time
                output_data['end_time'] = elem['Date Time']

                # 時間差は秒単位でfloat型に変換する
                elapsed = abs(elem['Date Time'] - start_time)
                output_data['elapsed'] = elapsed.total_seconds()

                output_data['device'] = str(elem['Device']).rstrip()
                output_data['process'] = str(elem['Process']).rstrip()
                output_data['lot_id'] = str(elem['LotID']).rstrip()
                output_data['plate_id'] = str(elem['GlassID']).rstrip()

                check_nunList = ['device', 'process', 'lot_id', 'plate_id']
                # nanは空欄に変換する
                for check_num in check_nunList:
                    if output_data[check_num] == 'nan':
                        output_data[check_num] = ''

                output_data['plate_no'] = elem['Plate']
                output_list.append(output_data)
                is_started = False
        return output_list

    def output_db_data(self, log_file):
        """
        指定されたLogを定義にしたがいDBに格納できる形式に変換する
        :param log_file:変換対象のログファイル
        :return: 変換後のデータ(辞書形式)のリスト
        """
        event_df = self.getTargetRowAll('status_monitor_items')

        try:
            status_df = pd.read_csv(log_file, encoding='shift_jis')
        except:
            status_df = pd.read_csv(log_file, encoding='utf_8')

        # headerなしのファイルは対象外とする
        if len(status_df) == 0 or 'Event' not in status_df.columns.values:
            return None

        status_df['Event'] = status_df['Event'].str.rstrip()

        ret_list = list()
        for _, elem in event_df.iterrows():
            item = elem['name']
            start = elem['start_state']
            end = elem['end_state']
            tmd_df = status_df.query('Event == @start or Event == @end')
            tmd_df['Date Time'] = tmd_df['Date Time'] + '000'
            tmd_df['Date Time'] = pd.to_datetime(tmd_df['Date Time'], format='%Y/%m/%d %H:%M:%S:%f')
            ret = self.check_event(item, start, end, tmd_df)
            ret_list.extend(ret)

        output_df = pd.DataFrame(ret_list)
        output_df['equipment_name'] = self.eqp_info.eqp_name
        output_df = output_df.sort_values('start_time')
        output_df = output_df.reindex(
            columns=['equipment_name', 'event', 'start_time', 'end_time', 'elapsed', 'device', 'process', 'lot_id',
                     'plate_id', 'plate_no'])

        return output_df