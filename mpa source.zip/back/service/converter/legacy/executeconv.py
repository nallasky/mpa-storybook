import argparse
import configparser
import datetime
import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor
import pandas as pd

from config import app_config
from dao.utils import exist_table
from service.converter.legacy import logconverter, database_if, errlog
from service.converter.legacy.equipment import Equipment
from service.converter.legacy.loginfo import LogInfo
from service.converter.legacy.rsscommon import definfo


logger = logging.getLogger(app_config.LOG)


class ExecuteConvert:
    """
    変換を実行するクラス
    """

    def __init__(self, dbg_print, **setting_config):

        self.setting_dbif = database_if.DatabaseIF(**setting_config)
        self.root_path = ""
        self.target_path = ""
        self.dbif = database_if.DatabaseIF(**setting_config)
        self.error_summary = errlog.ErrorLog(**setting_config)
        self.log_define = None
        self.log_columns = None
        self.equipments = None
        self.log_type = None
        self.special_log_type = None
        self.cpu_core_cnt = os.cpu_count()
        if dbg_print:
            self.dbg = dbg_print
        else:
            self.dbg = logger.info

        """
        print("######################################")
        print("# user_name :", user_name)
        print("# fab_name :", fab_name)
        print("# input path :", self.target_path)
        print("# output  path :", self.root_path)
        print("# cras_db_addr :", param['cras_db_addr'])
        print("# cras_db_port :", param['cras_db_port'])
        print("# cras_db_name :", param['cras_db_name'])
        print("######################################")
        """

    def exec_convert(self, user_name, fab_name):
        """
        コンバートのメインループ
        :return:
        """
        target = self.dbif.get_data('equipments')
        # tpe = ThreadPoolExecutor(max_workers=10)
        # 処理のメインループ

        for _, elem in target.iterrows():
            temp_username = elem['user_name']
            temp_fabname = elem['fab_name']

            ## FAB名例外処理 #########################
            if elem['user_name'] == 'GKC':
                if elem['fab_name'] == 'G1':
                    temp_fabname = 'BQ'
                elif elem['fab_name'] == 'G2':
                    temp_fabname = 'BZ'
            ## FAB名例外処理 ########################

            if elem['exec'] is True:
                # BSOT s1, s2は同じサーバーなので区別が必要
                if user_name == temp_username and fab_name == temp_fabname:
                    target_eqp = Equipment(elem)
                    self._exec_log_eqp(target_eqp)

                # tpe.submit(self._exec_log_eqp, target_eqp)

        # tpe.shutdown()
        ##LOG 変換後 log_timeが逆になるデータは削除する
        ##############　_convert_logfilelist
        self._delete_oldlog_from_list(os.path.join(self.root_path, target_eqp.user_name + '/' + target_eqp.fab_name))

    def _exec_log_eqp(self, target_eqp):
        # 1.処理する対象装置情報を取り出す
        self.dbg("===== Equipment Infomation =====")
        self.dbg("Equipment name :", target_eqp.eqp_name)
        self.dbg("User name :", target_eqp.user_name)
        self.dbg("FAB name :", target_eqp.fab_name)
        self.dbg("TOOL NAME :", target_eqp.tool_name)
        self.dbg("================================\r\n")

        log_path = target_eqp.user_name + '/' + target_eqp.fab_name + '/' + target_eqp.tool_name
        target_path = os.path.join(self.target_path, log_path)  # 変換対象ログパス
        output__path = os.path.join(self.root_path, target_eqp.user_name + '/' + target_eqp.fab_name)  # 変換後のログ格納先

        self.dbg("target path :", target_path)
        self.dbg("output path :", output__path, "\r\n")

        # Targetディレクトリが存在するかどうかを確認
        if os.path.exists(target_path) is False:
            self.dbg("[ERROR:_exec_log_eqp] target_path is not exist.")
            return

        # ログ変換処理
        # self._convert_directories(target_eqp, target_path, output__path)
        self._convert_logfilelist(target_eqp, target_path, output__path)

        # ログ変換後 equipmentのlast_exec_timeを更新
        where_data = ('equipment_name', target_eqp.eqp_name)
        update_data = ('last_exec_time', target_eqp.next_time)

        if (target_eqp.user_name == 'LOCAL') and (target_eqp.fab_name == 'LOCAL'):
            self.dbg("LOCAL TEST")
        else:
            self.dbif.update_data('equipments', update_data, where_data)

    def _delete_oldlog_from_list(self, output_path):
        """
        変換したLOGファイルの中でOLD LOGを削除する
        :param output_path:
        :return:
        """
        self.dbg("[[[Old log delete start]]]")
        self.dbg("   PATH : ", output_path)
        start_time = time.time()

        logfilelist = []
        current_year = str(datetime.date.today().year)

        for (dirpath, dirnames, filenames) in os.walk(output_path):
            for i in range(0, len(filenames)):
                ## ファイル名に西暦が含まれていれば検査しない(変換処理の時間短縮のために)
                ## 20201109 TiltMeasurementLogの場合、ファイル名に西暦が含まれているが検査が必要な場合がるので、
                ##          filenames[i].find('TiltMeasurementLog') >= 0 を追加
                if filenames[i].find(current_year) == -1 or filenames[i].find('TiltMeasurementLog') >= 0:
                    logfilelist.append(os.path.join(dirpath, filenames[i]))
                    # print("   ADD LIST : " + filenames[i])

        # for i in range(0, len(logfilelist)):
        #    print(logfilelist[i])

        # 変換するログファイルのリストを変換する
        tpe = ThreadPoolExecutor(max_workers=self.cpu_core_cnt)

        for log_name_file in enumerate(logfilelist):
            tpe.submit(self._delete_oldlog, log_name_file[1])

        tpe.shutdown(wait=True)

        self.dbg("[[[Old log delete end]]] (", time.time() - start_time, ")")

    def _delete_oldlog(self, file_name):
        """
        変換したLOGファイルの中でOLD LOGを削除する
        :param output_path:
        :return:
        """
        ### 例外処理対象ログ
        ## error_log : log_time -> occurred_date
        ## version_info : '%Y-%m-%d %H:%M:%S' -> '%Y-%m-%d
        ###
        time_field_name = 'log_time'

        ## error_log : log_time -> occurred_date
        if file_name.find('ErrorLog') != -1:
            time_field_name = 'occurred_date'

        ## version_info : '%Y-%m-%d %H:%M:%S' -> '%Y-%m-%d
        ## 対応しない
        if file_name.find('VersionInfo') != -1:
            return

        log_df = pd.read_csv(file_name, sep=',')

        # time_pre = datetime.datetime.strptime(log_df[time_field_name][len(log_df)-1], '%Y-%m-%d %H:%M:%S')
        time_pre = int(log_df[time_field_name][len(log_df) - 1].replace('-', '').replace(' ', '').replace(':', ''))

        change_data = False

        for i in range(len(log_df) - 1, -1, -1):
            # time_now = datetime.datetime.strptime(log_df[time_field_name][i], '%Y-%m-%d %H:%M:%S')
            time_now = int(log_df[time_field_name][i].replace('-', '').replace(' ', '').replace(':', ''))

            if time_now > time_pre:
                log_df = log_df[i + 1::]
                change_data = True
                break
            time_pre = time_now

        if change_data is True:
            self.dbg("   Delete old log:", file_name)
            log_df.to_csv(file_name, index=False)

    def _convert_directories(self, target_eqp, target_path, output_path):
        """
        ディレクトリを探索しログを変換する
        :param target_eqp:
        :param target_path:
        :param output_path:
        :return:
        """

        """

        # Targetディレクトリが存在するかどうかを確認
        if os.path.exists(target_path) is False:
            return
        # Targetディレクトリ内を探索しログ変換を実行する
        target_eqp.set_now_time()


        for log_name in os.listdir(target_path):

            # 取り出したパスを変換

            self._convert_log(target_eqp, log_name, target_path, output_path)


            #tpe.submit(self._convert_log, target_eqp, log_name, target_path, output_path)
        #tpe.shutdown()

        where_data = ('equipment_name', target_eqp.eqp_name)
        update_data = ('last_exec_time',  target_eqp.next_time)


        self.dbif.update_data('equipments', update_data, where_data)
        """

    def _convert_log_format_MountPressLog(self, log_path, file_name):
        """
        MountPressLogのFormatを変更する
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        new_header = '# Status, MNTPress_LB[kPa], MNTPress_LF[kPa], MNTPress_RB[kPa], MNTPress_RF[kPa], MNTOffs_LB[mm], MNTOffs_LF[mm], MNTOffs_RB[mm], MNTOffs_RF[mm], PSZ_Cnt_RB[-], PSZ_Cnt_LB[-], PSZ_Cnt_LF[-], PSZ_Cnt_RF[-], PSZ_COut_RB[bit], PSZ_COut_LB[bit], PSZ_COut_LF[bit], PSZ_COut_RF[bit], PSZ_Cur_RB[bit], PSZ_Cur_LB[bit], PSZ_Cur_LF[bit], PSZ_Cur_RF[bit], PSX[nm], PSY[nm], PST[msec], PSZ[nm], PSP[msec], PSR[msec], MSY[nm], MNT_COut_RBZ[bit], MNT_COut_LBZ[bit], MNT_COut_LFZ[bit], MNT_COut_RFZ[bit], Date'
        new_format_comma_cnt = 32  ## NEW Formt LogのCommaのCount

        lines = []

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## 新しいFormatなので変換不要
        if lines[0].count(',') == new_format_comma_cnt:
            return

        convert_end_line = 0

        ## LOGのFormatが混在しているかを確認
        if lines[0].count(',') == lines[len(lines) - 1].count(','):
            ## 混在していない場合の処理
            convert_end_line = len(lines)
        else:
            ## 混在している場合の処理 (OLD, NEWの順序のみ対応)
            ## Log Formatが変わる部分を探す
            for i in range(len(lines)):
                if lines[i].count(',') == new_format_comma_cnt:
                    convert_end_line = i
                    break

        ## ログの変換処理
        for i in range(convert_end_line):
            if lines[i].count(',') == 9:
                pos = lines[i].rfind(',') + 1

                lines[i] = lines[i][:pos] + ',,,,,,,,,,,,,,,,,,,,,,,' + lines[i][pos:]

            else:
                pos = 0
                for j in range(28):
                    pos = lines[i].find(',', pos + 1)
                lines[i] = lines[i][:pos] + ', 0, 0, 0, 0' + lines[i][pos:]

        # HEADRを変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(new_header + '\n')
            for i in range(1, len(lines)):
                log_file.writelines(lines[i])
        return new_file_name

    def _convert_log_format_IlluminationStatusLog(self, log_path, file_name):
        """
        IlluminationStatusLogのFormatを変更する
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        new_header = '#Date Time,34B02,34B00,34B01,34B03,34B04,34B05,34B06,34B07,34B08,34B09,34B0A,34B0B,34B0C,34B10,34B0D,34B0E,34B0F,GlassID,LotID'
        # new_format_comma_cnt = 20 ## NEW Formt LogのCommaのCount
        old1_format_comma_cnt = 17  ## Formt LogのCommaのCount
        old2_format_comma_cnt = 18  ## Formt LogのCommaのCount
        old3_format_comma_cnt = 14  ## Formt LogのCommaのCount

        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは日付に西暦がないことを探して付ける
        if lines[0][0] == '#':
            file_write = False

            for i in range(1, len(lines)):
                if lines[i][:2] != '20':
                    lines[i] = current_year + '/' + lines[i]
                    file_write = True

            # HEADRを変更してファイルを保存
            new_file_name = 'NEW_' + file_name
            if file_write is True:
                with open(os.path.join(log_path, new_file_name), 'w') as log_file:
                    for i in range(len(lines)):
                        log_file.writelines(lines[i])
                return new_file_name
        else:
            for i in range(len(lines)):
                if lines[i].count(',') == old1_format_comma_cnt:
                    insert_pos = 13
                    pos = 0
                    for j in range(insert_pos + 1):
                        pos = lines[i].find(',', pos + 1)
                    lines[i] = current_year + '/' + lines[i][:pos] + ',' + lines[i][pos:].rstrip('\n').rstrip(
                        '\r') + ',,\n'

                elif lines[i].count(',') == old2_format_comma_cnt:
                    lines[i] = current_year + '/' + lines[i].rstrip('\n').rstrip('\r') + ',,\n'

                elif lines[i].count(',') == old3_format_comma_cnt:
                    lines[i] = current_year + '/' + lines[i].rstrip('\n').rstrip('\r') + ',,,,,,\n'

                    # HEADRを変更してファイルを保存
            new_file_name = 'NEW_' + file_name
            with open(os.path.join(log_path, new_file_name), 'w') as log_file:
                log_file.writelines(new_header + '\n')
                for i in range(len(lines)):
                    log_file.writelines(lines[i])
            return new_file_name

    def _convert_log_format_LaserInterferometerPowerLog(self, log_path, file_name):
        """
        Log Formatが混在しているログについて分離する
        分離したログはHeaderを追加するので、
        HEADERありFormatとHeader無しFormatの2種類で
        分離されて変換及び格納される

        //////////////////////////////////////
        MPA Console
        Function Screen Specification
        ～ Laser Interferometer Power Log ～
        [[[[1]]]]
        ＜Machine Type：H740/H760/H800のとき（※PSX-2/PSXF/PS-Yaw-L/PS-Yaw-Rは、画面非表示の場合はRecallにも出力しない）＞
        項目:MSX-1[uW],MSY-1[uW],MSY-2[uW],PSX-1[uW],PSX-2[uW],PSY-1[uW],PSY-2[uW],PS-Yaw L[uW],PS-Yaw R[uW],PS-Pitch[uW],PS-Roll[uW],WLC[uW],BMB-X2[uW],Date Time,GlassID,LotID
        ※System Parameter画面のLaser Interferometer LogがmV&Interlockの場合、Recall部のヘッダは以下の通りとなる。
        #24844,24845,24846,24841,2484E,      24842,24843,24847,24848,2484A,2484B,24849,2484C,DateTime,GlassID,LotID

        [[[[2]]]]
        ＜Machine Type：E813/H1000/E900のとき（※PSX-2/ PSXF/PS-Yaw-L/PS-Yaw-Rは、画面非表示の場合はRecallにも出力しない）＞
        項目：MSX-1[mV],MSY-1[mV],MSY-2[mV],PSX-1[mV],PSX-2[mV],PSXF[mV],PSY-1[mV],PSY-2[mV],PS-Yaw L[mV],PS-Yaw R[mV],PS-Pitch[mV],PS-Roll[mV],WLC[mV],MSX-2[mV],Date Time,GlassID,LotID
        ※System Parameter画面のLaser Interferometer LogがmV&Interlockの場合、Recall部のヘッダは以下の通りとなる。
        #24844,24845,24846,24841,2484E,2484D,24842,24843,24847,24848,2484A,2484B,24849,2484C,DateTime,GlassID,LotID


        ＜Machine Type：H740/H760/H800のとき＞
        ##### CopyTime 12/26 2009 10:26:24 #####
        ##### LASER INTERFEROMETER POWER LOG #####
        # MSX-1[uW],MSY-1[uW],MSY-2[uW],PSX-1[uW],PSX-2[uW],PSY-1[uW],PSY-2[uW],PS-Yaw L[uW],PS-Yaw R[uW],PS-Pitch[uW],PS-Roll[uW],WLC[uW],BMB-X2[uW],Date Time,GlassID,LotID
        &&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,YYYY/MM/DD hh:mm:ss
        ※System Parameter画面のLaser Interferometer LogがmV&Interlockの場合は画面名が”LASER INTERFEROMETER POWER LOG [INTERLOCK]”となり、
        ヘッダの単位が[uW]から[mV]に変更となる

        ＜Machine Type：E813/H1000/E900のとき＞
        ##### CopyTime 12/26 2009 10:26:24 #####
        ##### LASER INTERFEROMETER POWER LOG #####
        # MSX-1[mV],MSY-1[mV],MSY-2[mV],PSX-1[mV],PSX-2[mV],PSXF[mV],PSY-1[mV],PSY-2[mV],PS-Yaw L[mV],PS-Yaw R[mV],PS-Pitch[mV],PS-Roll[mV],WLC[mV],MSX-2[mV],Date Time,GlassID,LotID
        &&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,&&&&.&&&,YYYY/MM/DD hh:mm:ss
        //////////////////////////////////////



        :param log_path:
        :param file_name:
        :return　:　なし
        """

        new_header = '#24844,24845,24846,24841,2484E,2484D,24842,24843,24847,24848,2484A,2484B,24849,2484C,Date Time,GlassID,LotID,'
        header_comma_cnt = 17  ## header Formt LogのComma Count

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは処理しない
        # if lines[0][0] == '#' :
        #    return

        ## LOGのFormatが混在しているかを確認
        if lines[0].count(',') == lines[len(lines) - 1].count(','):
            ## 混在していない場合は処理しない
            return
        elif lines[0].count(',') == header_comma_cnt and lines[1].count(',') == header_comma_cnt - 1:
            ## [[[[1]]]]のケース対応
            insert_pos = 5
            for i in range(1, len(lines)):
                if lines[i].count(',') == header_comma_cnt - 1:
                    pos = 0
                    for j in range(insert_pos):
                        pos = lines[i].find(',', pos + 1)
                    lines[i] = lines[i][:pos] + ',' + lines[i][pos:]
            new_file_name = 'NEW_' + file_name
            with open(os.path.join(log_path, new_file_name), 'w') as log_file:
                for i in range(len(lines)):
                    log_file.writelines(lines[i])
            return new_file_name
        else:
            ## 混在している場合の処理(headerなし, Headerありの順序のみ対応)
            ## Log Formatが変わる部分を探す
            format_change_line = 0

            for i in range(len(lines)):
                if lines[i].count(',') == header_comma_cnt:
                    format_change_line = i
                    break

            ## 2020-08-05 Heaerがない部分のデータは処理しないように修正
            """ 
            HeaderなしFormatのログは既存のファイル名で保存
            with open(os.path.join(log_path, file_name), 'w') as log_file:
                for i in range(format_change_line):
                    log_file.writelines(lines[i])

            file_name2 = "HEADER_"+file_name
            ## HeaderありFormatのログは別途のファイル名で保存
            with open(os.path.join(log_path, file_name2), 'w') as log_file:
                log_file.writelines(new_header+'\n')
                for i in range(format_change_line, len(lines)):
                    log_file.writelines(lines[i])

            return file_name2
            """
            ## HeaderありFormatのログは別途のファイル名で保存
            new_file_name = 'NEW_' + file_name
            with open(os.path.join(log_path, new_file_name), 'w') as log_file:
                log_file.writelines(new_header + '\n')
                for i in range(format_change_line, len(lines)):
                    log_file.writelines(lines[i])
            return new_file_name

    def _convert_log_format_TiltMeasurementLog(self, log_path, file_name):
        """
        IlluminationStatusLogのFormatを変更する
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        new_header = '#248B1,248B2,248B3,248B5,248B4,248B6,248B7,248B8,248B9,Date Time,GlassID,LotID'

        new_format_comma_cnt = 12  ## NEW Formt LogのCommaのCount
        new2_format_comma_cnt = 11  ## NEW Formt 2 LogのCommaのCount
        old1_format_comma_cnt = 8  ## NEW Formt LogのCommaのCount
        old2_format_comma_cnt = 9  ## NEW Formt LogのCommaのCount
        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは処理しない
        if lines[0][0] == '#':
            return

        for i in range(len(lines)):
            if lines[i].count(',') == old1_format_comma_cnt:
                pos = lines[i].rfind(',') + 1
                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:].rstrip('\n').rstrip('\r') + ',,,\n'

                pos = 0
                for j in range(8):
                    pos = lines[i].find(',', pos + 1)

                lines[i] = lines[i][:pos] + ',' + lines[i][pos:]

            elif lines[i].count(',') == old2_format_comma_cnt:
                pos = lines[i].rfind(',') + 1
                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:].rstrip('\n').rstrip('\r') + ',,,\n'

            elif lines[i].count(',') == new2_format_comma_cnt:
                pos = 0
                for j in range(8):
                    pos = lines[i].find(',', pos + 1)

                lines[i] = lines[i][:pos] + ',' + lines[i][pos:]

        # HEADRを変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(new_header + '\n')
            for i in range(len(lines)):
                log_file.writelines(lines[i])
        return new_file_name

    def _convert_log_format_MASKSCANADJUST(self, log_path, file_name):
        """
        MASKSCANADJUSTのFormatを変更する
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        new_header = '#14220,14221,14222,14223,14224,14225,14226,14227,14228,14229,1422A,1422B,1422C,1422D,14240,Date Time,GlassID,LotID,'

        old_format_comma_cnt = 15  ## NEW Formt LogのCommaのCount
        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは処理しない
        if lines[0][0] == '#':
            return

        for i in range(len(lines)):
            if lines[i].count(',') == old_format_comma_cnt:
                pos = lines[i].rfind(',') + 1
                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:].rstrip('\n').rstrip('\r') + ',,,\n'

        # HEADRを変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(new_header + '\n')
            for i in range(len(lines)):
                log_file.writelines(lines[i])
        return new_file_name

    def _convert_log_format_ADCCOMPENSATION(self, log_path, file_name):
        """
        ADCCOMPENSATIONのFormatを変更する
        :param log_path:
        :param file_name:
        :return　:　なし

        ※　日単位のログなので、混在の考慮は不要
        Fiendの数はHeaderありログの同じログのみ変換処理する。
        　－処理内容
        　　１．Headerの追加
        　　２．日付に西暦を追加
        """
        new_header = '#14041,14040,24017,24018,24019,2401A,24030,24031,2401B,2401C,24D00,24D01,24D02,24D03,24D04,2405A,2405B,24032,24033,242A0,242A1,242A2,242A3,242A4,242A5,242A6,24CF0,24CF1,24CF2,24CF3,24CF4,242A7,242C0,242C1,240DE,GlassID,LotID,Date Time,Chuck,204D7'

        TYPE10_comma_cnt = 24  ## TYPE10 LogのCommaのCount
        TYPE30_comma_cnt = 39  ## TYPE30 LogのCommaのCount

        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは処理しない
        if lines[1][0] == '#':
            return

        ## 最新ログFormatのみ対応
        if (lines[1].count(',') != TYPE10_comma_cnt) and (lines[1].count(',') != TYPE30_comma_cnt):
            return

        for i in range(len(lines)):
            if lines[i].count(',') == TYPE10_comma_cnt:
                pos = lines[i].rfind(',') + 1
                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:].rstrip('\n').rstrip('\r') + ',,\n'

                pos = 0
                for j in range(22):
                    pos = lines[i].find(',', pos + 1)

                lines[i] = lines[i][:pos] + ',,,' + lines[i][pos:]

                pos = 0
                for j in range(14):
                    pos = lines[i].find(',', pos + 1)

                lines[i] = lines[i][:pos] + ',,,,,' + lines[i][pos:]

                pos = 0
                for j in range(2):
                    pos = lines[i].find(',', pos + 1)

                lines[i] = lines[i][:pos] + ',,,,,' + lines[i][pos:]


            elif lines[i].count(',') == TYPE30_comma_cnt:
                pos = 0
                for j in range(37):
                    pos = lines[i].find(',', pos + 1) + 1

                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:]

        # HEADRを変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(lines[0])
            log_file.writelines(new_header + '\n')

            for i in range(1, len(lines)):
                log_file.writelines(lines[i])

        return new_file_name

    def _convert_log_format_M_PSYNCHRONIZATIONERROR(self, log_path, file_name):
        """
        ADCCOMPENSATIONのFormatを変更する
        :param log_path:
        :param file_name:
        :return　:　なし

        ※　日単位のログなので、混在の考慮は不要
        Fiendの数はHeaderありログの同じログのみ変換処理する。
        　－処理内容
        　　１．Headerの追加
        　　２．日付に西暦を追加
        """
        new_header = '#24160,28000,24252,24250,24253,24251,240A5,24057,240A6,24058,24256,24254,24257,24255,2425A,24258,2425B,24259,2425E,2425C,2425F,2425D,24262,24260,24263,24261,24CC2,24CC0,24CC3,24CC1,24264,24265,24266,24267,2028C,GlassID,LotID,Date Time,2424F'

        TYPE10_comma_cnt = 33  ## TYPE10 LogのCommaのCount
        TYPE20_comma_cnt = 37  ## TYPE10 LogのCommaのCount
        TYPE30_comma_cnt = 38  ## TYPE30 LogのCommaのCount

        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは処理しない
        if lines[1][0] == '#':
            return

        if (lines[1].count(',') != TYPE10_comma_cnt) and (lines[1].count(',') != TYPE20_comma_cnt) and (
                lines[1].count(',') != TYPE30_comma_cnt):
            return

        for i in range(len(lines)):
            if lines[i].count(',') == TYPE10_comma_cnt:
                pos = lines[i].rfind(',') + 1
                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:].rstrip('\n').rstrip('\r') + ',\n'

                pos = 0
                for j in range(30):
                    pos = lines[i].find(',', pos + 1)

                lines[i] = lines[i][:pos] + ',,,,' + lines[i][pos:]

            elif lines[i].count(',') == TYPE20_comma_cnt:
                pos = lines[i].rfind(',') + 1
                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:].rstrip('\n').rstrip('\r') + ',\n'

            elif lines[i].count(',') == TYPE30_comma_cnt:
                pos = 0
                for j in range(37):
                    pos = lines[i].find(',', pos + 1) + 1

                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:]

        # HEADRを変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(lines[0])
            log_file.writelines(new_header + '\n')

            for i in range(1, len(lines)):
                log_file.writelines(lines[i])
        return new_file_name

    def _convert_log_format_MASKOPAFLOG(self, log_path, file_name):
        """
        MASKOPAFLOGのFormatを変更する
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        new_header = '#14A30,14A31,14A32,14A33,14A38,14A39,14A3A,Device,Process,Date Time,GlassID,LotID'

        old_comma_cnt = 8  ## TYPE10 LogのCommaのCount

        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは処理しない
        if lines[1][0] == '#':
            return

        ## HeaderがあるTypeなのに、Headerの先頭に“＃”がない場合がある。
        ## この場合は [#]のみ付ける
        if lines[0].find('14A30') == 0:
            lines[0] = "#" + lines[0]
            new_file_name = 'NEW_' + file_name
            with open(os.path.join(log_path, new_file_name), 'w') as log_file:
                for i in range(len(lines)):
                    log_file.writelines(lines[i])
            return new_file_name

        if (lines[1].count(',') != old_comma_cnt):
            return

        for i in range(len(lines)):
            if lines[i].count(',') == old_comma_cnt:
                pos = lines[i].rfind(',') + 1
                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:].rstrip('\n').rstrip('\r') + ',,,\n'
                pos = lines[i].find('/')
                lines[i] = lines[i][:pos] + ',' + lines[i][pos + 1:]

        # HEADERTYPEに変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(new_header + '\n')
            for i in range(len(lines)):
                log_file.writelines(lines[i])
        return new_file_name

    def _convert_log_format_LiPSFocus(self, log_path, file_name):
        """
        LiPSFocusのFormatを変更する
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        new_header = '#Date Time,Device,Process,24B03,24B05,24B02,24B00,24B04,24B01,24B13,24B12,24B17,24B16,24B1B,24B1A,24B0A,24B0B,24B0C,24B0D,30B5C,GlassID,LotID,20B13,20B14,20B15,20B2C,20B2D,20B2E'

        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは処理しない
        if lines[0][0] == '#':
            return

        for i in range(len(lines)):
            # YEAR
            if lines[i][:2] != '20':
                lines[i] = current_year + '/' + lines[i]

            if lines[i].count(',') == 26:
                # Device, processの区分を「,」に変更
                pos = lines[i].find('/', lines[i].find(','))
                lines[i] = lines[i][:pos] + ',' + lines[i][pos + 1:]
                # ill_modeを最後に移動
                """
                pos = 0
                pos2 = 0

                for j in range(19):
                    pos = lines[i].find(',', pos+1)
                pos2 = lines[i].find(',', pos+1)

                lines[i] = lines[i][:pos] + lines[i][pos2:].rstrip('\n').rstrip('\r') + lines[i][pos:pos2] + '\n'
                """
            elif lines[i].count(',') == 23:
                # Device, processの区分を「,」に変更
                pos = lines[i].find('/', lines[i].find(','))
                lines[i] = lines[i][:pos] + ',' + lines[i][pos + 1:]

                pos = 0
                for j in range(16):
                    pos = lines[i].find(',', pos + 1)
                lines[i] = lines[i][:pos] + ',,' + lines[i][pos:]

            elif lines[i].count(',') == 25:
                # Device, processの区分を「,」に変更
                pos = lines[i].find('/', lines[i].find(','))
                lines[i] = lines[i][:pos] + ',' + lines[i][pos + 1:]

                pos = 0
                for j in range(19):
                    pos = lines[i].find(',', pos + 1)
                lines[i] = lines[i][:pos] + ',' + lines[i][pos:]

        # HEADRを変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(new_header + '\n')
            for i in range(len(lines)):
                log_file.writelines(lines[i])
        return new_file_name

    def _convert_log_format_MSXBMBMonitor(self, log_path, file_name):
        """
        MSXBMBMonitorのFormatを変更する
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        new_header = '#24160,233CB,233CC,Device,Process,GlassID,LotID,Date Time'

        old_comma_cnt = 6  ## No Header LogのComma Count

        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        if len(lines) < 1:
            return

        ## HEADERがあるのは処理しない
        ## 2020/08/07  バージョンダウンのためHeader+Header無しが混在するケースの対応。

        need_save = False
        data_startline = 0

        if lines[0][0] == '#':
            data_startline = 1  # HeaderがあるLOGは1から
            # return
        else:
            need_save = True

        for i in range(data_startline, len(lines)):
            if lines[i].count(',') == old_comma_cnt:
                pos = lines[i].rfind(',') + 1
                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:]
                pos = lines[i].find('/')
                lines[i] = lines[i][:pos] + ',' + lines[i][pos + 1:]

                need_save = True

        # 変更がないと保存市内で返却
        if need_save == False:
            return

        # 変更してファイルを保存
        new_file_name = 'NEW_' + file_name

        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            if data_startline == 0:
                log_file.writelines(new_header + '\n')

            for i in range(len(lines)):
                log_file.writelines(lines[i])

        return new_file_name

    def _convert_log_format_LiPSTVAA(self, log_path, file_name):
        """
        LiPSTVAAのFormatを変更する
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        new_header = '#10B20,10B21,10B22,10B23,10B24,20B73,20B74,20B75,10B1E,10B1F,DateTime,GlassID,LotID'

        type10_20_comma_cnt = 8  ## No Header LogのComma Count
        type30_comma_cnt = 10  ## No Header LogのComma Count
        type30_comma_cnt2 = 11  ## No Header LogのComma Count

        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは処理しない
        if lines[0][0] == '#':
            return

        ## LOGのFormatが混在しているかを確認
        if lines[0].count(',') == lines[len(lines) - 1].count(','):
            ## 混在していない場合は処理しない
            return

        for i in range(len(lines)):
            if lines[i].count(',') == type10_20_comma_cnt:
                pos = lines[i].rfind(',') + 1
                lines[i] = lines[i][:pos] + ',,' + current_year + '/' + lines[i][pos:].rstrip('\n').rstrip(
                    '\r') + ',,,\n'

            elif lines[i].count(',') == type30_comma_cnt:
                pos = lines[i].rfind(',') + 1
                lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:].rstrip('\n').rstrip('\r') + ',,,\n'

            elif lines[i].count(',') == type30_comma_cnt2:
                pos = 0

                for j in range(8):
                    pos = lines[i].find(',', pos + 1)

                lines[i] = lines[i][:pos] + ',,' + lines[i][pos:]

        # HEADERTYPEに変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(new_header + '\n')
            for i in range(len(lines)):
                log_file.writelines(lines[i])
        return new_file_name

    def _convert_log_format_STAGEACCURACYAFC(self, log_path, file_name):
        """
        _convert_log_format_STAGEACCURACYAFC
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは処理しない
        if lines[1][0] == '#':
            return

        if lines[1] == '#':
            return

        header = ''

        TYPE1_COMMA_CNT = 16

        if lines[1].count(',') == TYPE1_COMMA_CNT:
            header = '#24160,28000,235AC,235AD,235AE,235B0,235B1,235B2,235B4,235B5,235B6,235B8,235B9,235BA,GlassID,LotID,Date Time'
        else:
            return

            # HEADERTYPEに変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(lines[0])
            log_file.writelines(header + '\n')
            for i in range(1, len(lines)):

                if lines[i].count(',') == TYPE1_COMMA_CNT:
                    pos = lines[i].rfind(',') + 1
                    lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:]

                log_file.writelines(lines[i])

        return new_file_name

    def _convert_log_format_PLATEAUTOFOCUSCOMPENSATION(self, log_path, file_name):
        """
        _convert_log_format_PLATEAUTOFOCUSCOMPENSATION
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        current_year = str(datetime.date.today().year)

        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 2:
            return

        ## HEADERがあるのは処理しない
        if lines[1][0] == '#':
            return

        header = ''

        TYPE1_COMMA_CNT = 25

        if lines[1].count(',') == TYPE1_COMMA_CNT:
            header = '#24160,24161,24049,2404A,2404B,2404C,2404D,2404E,2404F,241C1,241C2,241C3,241C4,2408B,2408C,2408D,2408E,2408F,24090,241C5,241C6,241C7,241C8,GlassID,LotID,Date Time'
        else:
            return

        # HEADERTYPEに変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(lines[0])
            log_file.writelines(header + '\n')
            for i in range(1, len(lines)):

                if lines[i].count(',') == TYPE1_COMMA_CNT:
                    pos = lines[i].rfind(',') + 1
                    lines[i] = lines[i][:pos] + current_year + '/' + lines[i][pos:]

                log_file.writelines(lines[i])

        return new_file_name

    def _convert_log_format_ADCMEASUREMENT(self, log_path, file_name):
        """
        _convert_log_format_ADCMEASUREMENT
        :param log_path:
        :param file_name:
        :return　:　なし
        """
        with open(os.path.join(log_path, file_name), 'r') as log_file:
            lines = log_file.readlines()

        ## Logのライン数が1ラインの場合は処理しない
        if len(lines) < 3:
            return

        header = '#14041,14040,14070,14071,14072,14073,14074,14075,14076,14077,14078,14079,1407A,1407B,140E2,140E3,140E4,140E5,140E6,140E7,14163,14164,14165,14106,14107,GlassID,LotID,Date Time,Chuck'
        new_header = '#14041,14040,14070,14071,14072,14073,14074,14075,14076,14077,14078,14079,1407A,1407B,140E2,140E3,140E4,140E5,140E6,140E7,14163,14164,14165,14106,GlassID,LotID,Date Time,Chuck,14107'

        # header の順序が合わないケースの対応のみ実施
        # LOGのHEADERがheaderと一致する場合のみ処理
        if lines[1].rstrip('\n').rstrip('\r') != header:
            return

        # 念のためLOGに　14107_　があるかも検査してある場合んのみ変更する
        if lines[2].find('14107_') == -1:
            return

            # HEADERTYPEに変更してファイルを保存
        new_file_name = 'NEW_' + file_name
        with open(os.path.join(log_path, new_file_name), 'w') as log_file:
            log_file.writelines(lines[0])
            log_file.writelines(new_header + '\n')
            for i in range(2, len(lines)):
                log_file.writelines(lines[i])

        return new_file_name

    def _convert_log_format(self, log_path, log_name, file_name):
        """
        Logファイル内部で形式が異なる場合分離する
        :param log_path:
        :param log_name:
        :param file_name:
        :return　分離したLOGファイルがあればそのファイルの名:
        """
        if log_name == 'MountPressLog':
            return self._convert_log_format_MountPressLog(log_path, file_name)
        elif log_name == 'IlluminationStatusLog':
            return self._convert_log_format_IlluminationStatusLog(log_path, file_name)
        elif log_name == 'LaserInterferometerPowerLog':
            return self._convert_log_format_LaserInterferometerPowerLog(log_path, file_name)
        elif log_name == 'TiltMeasurementLog':
            return self._convert_log_format_TiltMeasurementLog(log_path, file_name)
        elif log_name == 'MASKSCANADJUST':
            return self._convert_log_format_MASKSCANADJUST(log_path, file_name)
        elif log_name == 'ADCCOMPENSATION':
            return self._convert_log_format_ADCCOMPENSATION(log_path, file_name)
        elif log_name == 'M_PSYNCHRONIZATIONERROR':
            return self._convert_log_format_M_PSYNCHRONIZATIONERROR(log_path, file_name)
        elif log_name == 'MASKOPAFLOG':
            return self._convert_log_format_MASKOPAFLOG(log_path, file_name)
        elif log_name == 'LiPSFocus':
            return self._convert_log_format_LiPSFocus(log_path, file_name)
        elif log_name == 'MSXBMBMonitor':
            return self._convert_log_format_MSXBMBMonitor(log_path, file_name)
        elif log_name == 'LiPSTVAA':
            return self._convert_log_format_LiPSTVAA(log_path, file_name)
        elif log_name == 'STAGEACCURACYAFC':
            return self._convert_log_format_STAGEACCURACYAFC(log_path, file_name)
        elif log_name == 'PLATEAUTOFOCUSCOMPENSATION':
            return self._convert_log_format_PLATEAUTOFOCUSCOMPENSATION(log_path, file_name)
        elif log_name == 'ADCMEASUREMENT':
            return self._convert_log_format_ADCMEASUREMENT(log_path, file_name)
        else:
            return

    def _convert_logfilelist(self, target_eqp, target_path, output_path):
        """
        target_pathしたのすべてのファイルをリスト化して変換
        :param target_eqp:
        :param target_path:
        :param output_path:
        :return:
        """

        # 変換するログファイルのリストを作成する
        logfilelist = []

        for log_name in os.listdir(target_path):
            log_path = os.path.join(target_path, log_name)
            if os.path.isdir(log_path) is True:
                for file_name in os.listdir(log_path):
                    log_file_name = os.path.join(log_path, file_name)
                    if os.path.isdir(log_file_name) is False:
                        mtime = os.stat(log_file_name).st_mtime
                        log_time = datetime.datetime.fromtimestamp(mtime)
                        if (log_time > target_eqp.last_time) and ('.index' not in file_name):
                            logfilelist.append([log_name, file_name])

        # Targetディレクトリ内を探索しログ変換を実行する
        target_eqp.set_now_time()

        # 変換するログファイルのリストを変換する
        tpe = ThreadPoolExecutor(max_workers=self.cpu_core_cnt)

        count = -1

        for count, log_name_file in enumerate(logfilelist):
            # print(count, log_name_file[0], log_name_file[1])
            # self._convert_log_file(target_eqp,
            #                         log_name_file[0],
            #                         log_name_file[1],
            #                         target_path,
            #                         output_path)

            tpe.submit(self._convert_log_file,
                       target_eqp,
                       log_name_file[0],
                       log_name_file[1],
                       target_path,
                       output_path)

        tpe.shutdown(wait=True)

        self.dbg("==================================")
        self.dbg(count + 1, "files converting end\r\n\r\n")

    def _convert_running_log(self, target_eqp, log_name, target_path):
        """
        稼働率ログを変換する
        :param target_eqp:
        :param log_name:
        :param target_path:
        :return:
        """
        log_path = target_path + '/' + log_name
        last_log_time = target_eqp.last_time

        # ディレクトリ内のファイルを一つずつ変換する
        for file_name in os.listdir(log_path):
            log_time = datetime.datetime.fromtimestamp(os.stat(log_path + '/' + file_name).st_mtime)

            if log_time > last_log_time:  # indexファイルは対象外
                try:
                    # 稼働率データを変換する
                    log_info_header_df, log_info_wo_header_df = self.get_log_define(log_name)
                    if len(log_info_header_df) == 0:
                        return

                    log_info = LogInfo(log_info_header_df)
                    convert_info = self.get_log_convert_info(log_name, target_eqp.header_log_type)
                    log_converter = self.get_log_converter(log_name, log_info, convert_info, target_eqp, header=True)
                    self.dbg(log_path + '/' + file_name)
                    running_df = log_converter.output_db_data(log_path + '/' + file_name)
                    if running_df is not None and len(running_df) != 0:
                        self.dbif.insert_running_data(running_df, 'convert.running_rate')
                    # Errorサマリーを変換する
                    summary_df = self.error_summary.convert_log(log_path + '/' + file_name, target_eqp)
                    if summary_df is not None and len(summary_df) != 0:
                        self.dbif.insert_running_data(summary_df, 'convert.error_summary')
                except:
                    self.dbg('Convert Error:', log_path + '/' + file_name)

    def _convert_running_log_file(self, target_eqp, log_name, file_name, target_path):
        """
        稼働率ログを変換する
        :param target_eqp:
        :param log_name:
        :param file_name:
        :param target_path:
        :return:
        """
        # log_path = target_path + '/' + log_name
        log_path = target_path

        # 稼働率データを変換する
        log_info_header_df, _ = self.get_log_define(log_name)

        if len(log_info_header_df) == 0:
            self.dbg('[ERROR:_convert_running_log_file] log_info_header_df is none')
            return

        log_info = LogInfo(log_info_header_df)

        convert_info = self.get_log_convert_info(log_name, target_eqp.header_log_type)
        log_converter = self.get_log_converter(log_name,
                                               log_info,
                                               convert_info,
                                               target_eqp,
                                               header=True)

        running_df = log_converter.output_db_data(log_path + '/' + file_name)

        if running_df is not None and len(running_df) != 0:
            self.dbif.insert_running_data(running_df, 'convert.running_rate')
        else:
            self.dbg('[ERROR:_convert_running_log_file] running_df is none')

        # Errorサマリーを変換する
        summary_df = self.error_summary.convert_log(log_path + '/' + file_name, target_eqp)
        if summary_df is not None and len(summary_df) != 0:
            self.dbif.insert_running_data(summary_df, 'convert.error_summary')
        else:
            self.dbg('[ERROR:_convert_running_log_file] summary_df is none')

    def _convert_chamber_log(self, target_eqp, log_name, target_path, output_path):
        """
        チャンバーログを変換する
        :param target_eqp:
        :param log_name:
        :param target_path:
        :param output_path:
        :return:
        """
        output_log_path = os.path.join(output_path, log_name, target_eqp.eqp_name)
        log_path = target_path + '/' + log_name
        last_log_time = target_eqp.last_time
        # ディレクトリ内のファイルを一つずつ変換する
        _, loginfo = self.get_log_define(log_name)
        log_info_obj = LogInfo(loginfo)
        conv_data = self.get_log_convert_info(log_name, target_eqp.chamber_log_type)
        chamber_log_converter = logconverter.ChamberConverter(log_info_obj, conv_data, target_eqp)
        for file_name in os.listdir(log_path):
            log_time = datetime.datetime.fromtimestamp(os.stat(log_path + '/' + file_name).st_mtime)

            if log_time > last_log_time:  # indexファイルは対象外
                # チャンバーを変換する
                self.dbg(log_path + '/' + file_name)
                try:
                    conv_data = chamber_log_converter.output_db_data(log_path + '/' + file_name)
                except:
                    self.dbg('Convert Error' + log_path + '/' + file_name)
                    conv_data = None

                if conv_data is not None:
                    self.output_convert_log(conv_data, output_log_path, log_info_obj,
                                            file_name, target_eqp.eqp_name,
                                            target_eqp.header_log_type, chamber_mode=False)

    def _convert_chamber_log_file(self, target_eqp, log_name, file_name, target_path, output_path):
        """
        チャンバーログを変換する
        :param target_eqp:
        :param log_name:
        :param file_name:
        :param target_path:
        :param output_path:
        :return:
        """
        output_log_path = os.path.join(output_path, log_name, target_eqp.eqp_name)
        log_path = target_path + '/' + log_name

        # ディレクトリ内のファイルを一つずつ変換する
        _, loginfo = self.get_log_define(log_name)
        log_info_obj = LogInfo(loginfo)
        conv_data = self.get_log_convert_info(log_name, target_eqp.chamber_log_type)
        chamber_log_converter = logconverter.ChamberConverter(log_info_obj, conv_data, target_eqp)

        # チャンバーを変換する
        # print(log_path + '/' + file_name)

        try:
            conv_data = chamber_log_converter.output_db_data(log_path + '/' + file_name)
        except Exception as errmsg:
            self.dbg('[ERROR:_convert_chamber_log_file] ' + log_path + '/' + file_name)
            self.dbg(errmsg)
            conv_data = None

        if conv_data is not None:
            self.output_convert_log(conv_data, output_log_path, log_info_obj,
                                    file_name, target_eqp.eqp_name,
                                    target_eqp.header_log_type, chamber_mode=False)
        else:
            self.dbg('[ERROR:_convert_chamber_log_file] conv_data is none')

    def _convert_version_info(self, target_eqp, log_name, target_path, output_path):
        """
        Version Infoを変換する
        :param target_eqp:
        :param log_name:
        :param target_path:
        :param output_path:
        :return:
        """
        output_log_path = os.path.join(output_path, log_name, target_eqp.eqp_name)
        log_path = os.path.join(target_path, log_name)
        last_log_time = target_eqp.last_time
        # ディレクトリ内のファイルを一つずつ変換する
        _, loginfo = self.get_log_define(log_name)
        log_info_obj = LogInfo(loginfo)
        conv_data = self.get_log_convert_info(log_name, 'VER')
        versioninfo_converter = logconverter.VersionConverter(log_info_obj, conv_data, target_eqp)
        for file_name in os.listdir(log_path):

            # 変換処理の実行
            self.dbg(log_path + '/' + file_name)
            try:
                conv_data = versioninfo_converter.output_db_data(log_path + '/' + file_name)
            except:
                self.dbg('Convert Error' + log_path + '/' + file_name)
                conv_data = None

            if conv_data is not None:
                self.output_convert_log(conv_data, output_log_path, log_info_obj,
                                        file_name, target_eqp.eqp_name,
                                        target_eqp.wo_header_log_type)

    def _convert_version_info_file(self, target_eqp, log_name, file_name, target_path, output_path):
        """
        Version Infoを変換する
        :param target_eqp:
        :param log_name:
        :param target_path:
        :param output_path:
        :return:
        """
        output_log_path = os.path.join(output_path, log_name, target_eqp.eqp_name)
        log_path = os.path.join(target_path, log_name)
        # last_log_time = target_eqp.last_time
        # ディレクトリ内のファイルを一つずつ変換する
        _, loginfo = self.get_log_define(log_name)
        log_info_obj = LogInfo(loginfo)
        conv_data = self.get_log_convert_info(log_name, 'VER')
        versioninfo_converter = logconverter.VersionConverter(log_info_obj, conv_data, target_eqp)

        # 変換処理の実行
        # print(log_path + '/' + file_name)
        try:
            conv_data = versioninfo_converter.output_db_data(os.path.join(target_path, file_name))
        except Exception as errmsg:
            self.dbg('[ERROR:_convert_version_info_file] ' + log_path + '/' + file_name)
            self.dbg(errmsg)
            conv_data = None

        if conv_data is not None:
            return self.output_convert_log(conv_data, output_log_path, log_info_obj,
                                    file_name, target_eqp.eqp_name,
                                    target_eqp.wo_header_log_type)
        else:
            self.dbg('[ERROR:_convert_version_info_file] conv_data is none')

    def _convert_statusmonitor_log_file(self, target_eqp, log_name, file_name, target_path, output_path):
        """
        20201012北岡追加
        StatusMonitorを解析して解析結果を出力する
        :param target_eqp:
        :param log_name:
        :param target_path:
        :param output_path:
        :return:
        """
        output_log_path = os.path.join(output_path, log_name, target_eqp.eqp_name)
        log_path = target_path + '/' + log_name
        last_log_time = target_eqp.last_time
        # ディレクトリ内のファイルを一つずつ解析する
        loginfo, _ = self.get_log_define(log_name)
        log_info_obj = LogInfo(loginfo)
        conv_data = None
        statusmonitor_converter = logconverter.StatusMonitorConverter(log_info_obj, conv_data, target_eqp)
        log_time = datetime.datetime.fromtimestamp(os.stat(log_path + '/' + file_name).st_mtime)

        if log_time > last_log_time:  # indexファイルは対象外
            # StatusMonitorを解析する
            self.dbg(log_path + '/' + file_name)
            try:
                conv_data = statusmonitor_converter.output_db_data(log_path + '/' + file_name)
            except:
                self.dbg('Convert Error' + log_path + '/' + file_name)
                conv_data = None

            if conv_data is not None:
                self.output_convert_log(conv_data, output_log_path, log_info_obj,
                                        file_name, target_eqp.eqp_name,
                                        target_eqp.header_log_type, chamber_mode=False)
            else:
                self.dbg('[ERROR:_convert_statusmonitor_log_file] conv_data is none')

    def _convert_log(self, target_eqp, log_name, target_path, output_path):
        """
        指定ディレクトリ内のログを変換する
        :param target_eqp:
        :param log_name:
        :param target_path:
        :param output_path:
        :return:
        """
        """
        log_path = target_path + '/' + log_name
        print(log_path)

        # 稼働率ログかどうか
        if log_name == 'RUNNING':
            self._convert_running_log(target_eqp, log_name, target_path)
            return
        # チェンバーログかどうか
        if log_name == 'ChamberDetailLog':
            self._convert_chamber_log(target_eqp, log_name, target_path, output_path)
            return
        # Version Infoかどうか
        if log_name == 'VersionInfo':
            self._convert_version_info(target_eqp, log_name, target_path, output_path)
            return

        # ログ情報をDBから取り出す
        log_info_header_df, log_info_wo_header_df = self.get_log_define(log_name)
        if len(log_info_header_df) == 0:
            return
        log_info = LogInfo(log_info_header_df)
        log_info_wo_header = None
        if len(log_info_wo_header_df) != 0:
            log_info_wo_header = LogInfo(log_info_wo_header_df)

        # 変換のための情報を取得する
        log_format = log_info.format  # ログフォーマット
        no_header_type = self.get_log_convert_type(target_eqp, log_name)
        output_log_path = os.path.join(output_path, log_name, target_eqp.eqp_name)
        last_log_time = target_eqp.last_time

        log_converter_wo_header = None

        # CSV形式のログの場合
        if log_format == definfo.LOG_STANDARD:
            # 変換情報を取得
            convert_info = self.get_log_convert_info(log_name, target_eqp.header_log_type)
            # ヘッダなしログの情報がある場合 ヘッダなし変換オブジェクトを取得
            if no_header_type is not None and no_header_type != '' and log_info_wo_header is not None:

                convert_info_wo_header = self.get_log_convert_info(log_name, no_header_type)
                log_converter_wo_header = \
                    self.get_log_converter(log_name, log_info_wo_header, convert_info_wo_header, target_eqp, header=False)
        else:
            convert_info = self.get_log_convert_info(log_name)

        # 変換オブジェクトを作成する

        log_converter = self.get_log_converter(log_name, log_info, convert_info, target_eqp, header=True)

        if log_converter is None:
            return

        # ディレクトリ内のファイルを一つずつ変換する
        for file_name in os.listdir(log_path):


            log_time = datetime.datetime.fromtimestamp(os.stat(log_path + '/' + file_name).st_mtime)
            if '.index' not in file_name and log_time > last_log_time:  # indexファイルは対象外
                try:
                    print(file_name)
                    insert_df = log_converter.output_db_data(log_path + '/' + file_name)
                    print(file_name)
                except Exception as e:
                    print('Convert Error' + log_path + '/' + file_name)
                    print(e)
                    insert_df = None
                if insert_df is not None:

                    self.output_convert_log(insert_df,
                                            output_log_path,
                                            log_info,
                                            file_name,
                                            target_eqp.eqp_name,
                                            target_eqp.header_log_type)
                elif log_converter_wo_header is not None:
                    try:
                        insert_df = log_converter_wo_header.output_db_data(log_path + '/' + file_name)
                        if insert_df is not None:
                           self.output_convert_log(insert_df,
                                               output_log_path,
                                               log_info_wo_header,
                                               file_name,
                                               target_eqp.eqp_name,
                                               no_header_type )
                    except:
                        print('Convert Error' + log_path + '/' + file_name)
        """

    def _convert_log_file(self, target_eqp, log_name, file_name, target_path, output_path):
        """
        指定ディレクトリ内のログを変換する
        :param target_eqp:
        :param log_name:
        :param file_name:
        :param target_path:
        :param output_path:
        :return:
        """
        # log_path = target_path + '/' + log_name
        log_path = os.path.dirname(file_name)
        file_name = os.path.basename(file_name)

        ## Log Format Convert(Header変更対応など)
        convert_file_name = self._convert_log_format(log_path, log_name, file_name)

        if convert_file_name != None:
            file_name = convert_file_name

        logfile_size = int(os.path.getsize(log_path + '/' + file_name) / 1024)
        self.dbg('[' + log_name + ']' + log_path + '/' + file_name + '(' + str(logfile_size) + ' KByte)')

        # 稼働率ログかどうか
        if log_name == 'RUNNING':
            self._convert_running_log_file(target_eqp, log_name, file_name, target_path)
            return

        # チェンバーログかどうか
        if log_name == 'ChamberDetailLog':
            self._convert_chamber_log_file(target_eqp,
                                           log_name,
                                           file_name,
                                           target_path,
                                           output_path)
            return

        # Version Infoかどうか
        if log_name == 'VersionInfo':
            return self._convert_version_info_file(target_eqp,
                                            log_name,
                                            file_name,
                                            target_path,
                                            output_path)

        # 20201012北岡追加
        # StatusMonitorかどうか
        if log_name == 'StatusMonitor':
            self._convert_statusmonitor_log_file(target_eqp,
                                                 log_name,
                                                 file_name,
                                                 target_path,
                                                 output_path)
            return

        # UM温調ログかどうか
        if log_name == 'UMTemperatureDetailLog':
            self._convert_chamber_log_file(target_eqp,
                                           log_name,
                                           file_name,
                                           target_path,
                                           output_path)
            return

        # ログ情報をDBから取り出す
        log_info_header_df, log_info_wo_header_df = self.get_log_define(log_name)

        if len(log_info_header_df) == 0:
            self.dbg("[ERROR:_convert_log_file#1] log_info_header_df is none. " + log_path + '/' + file_name)

            if convert_file_name is not None and len(convert_file_name) != 0:
                os.remove(log_path + '/' + file_name)

            return

        log_info = LogInfo(log_info_header_df)
        log_info_wo_header = None
        if len(log_info_wo_header_df) != 0:
            log_info_wo_header = LogInfo(log_info_wo_header_df)

        # 変換のための情報を取得する
        log_format = log_info.format  # ログフォーマット
        no_header_type = self.get_log_convert_type(target_eqp, log_name)
        output_log_path = os.path.join(output_path, log_name, target_eqp.eqp_name)
        log_converter_wo_header = None

        # CSV形式のログの場合
        if log_format == definfo.LOG_STANDARD:
            # 変換情報を取得
            convert_info = self.get_log_convert_info(log_name, target_eqp.header_log_type)

            # ヘッダなしログの情報がある場合 ヘッダなし変換オブジェクトを取得
            if (no_header_type is not None) and (no_header_type != '') and (log_info_wo_header is not None):
                convert_info_wo_header = self.get_log_convert_info(log_name, no_header_type)
                log_converter_wo_header = self.get_log_converter(log_name,
                                                                 log_info_wo_header,
                                                                 convert_info_wo_header,
                                                                 target_eqp,
                                                                 header=False)
        else:
            convert_info = self.get_log_convert_info(log_name)

        # 変換オブジェクトを作成する
        log_converter = self.get_log_converter(log_name,
                                               log_info,
                                               convert_info,
                                               target_eqp,
                                               header=True)

        if log_converter is None:
            self.dbg("[ERROR:_convert_log_file#2] log_converter is none. " + log_path + '/' + file_name)

            if convert_file_name is not None and len(convert_file_name) != 0:
                os.remove(log_path + '/' + file_name)

            return

        # とりあえず、Headerありタイプでトライしてい見る
        try:
            insert_df = log_converter.output_db_data(log_path + '/' + file_name)
        except Exception as errmsg:
            self.dbg('[ERROR:_convert_log_file#3] log_converter.output_db_data Error' + log_path + '/' + file_name)
            self.dbg(errmsg)
            insert_df = None

        if insert_df is not None:
            # Headerありタイプで変換成功時保存
            try:
                return self.output_convert_log(insert_df,
                                        output_log_path,
                                        log_info,
                                        file_name,
                                        target_eqp.eqp_name,
                                        target_eqp.header_log_type)
            except Exception as errmsg:
                self.dbg('[ERROR;_convert_log_file] output_convert_log' + log_path + '/' + file_name)
                self.dbg(errmsg)

        elif log_converter_wo_header is not None:
            # Header ありタイプで失敗、log_converter_wo_headerがあれば、Headerなしタイプでトライ
            try:
                insert_df = log_converter_wo_header.output_db_data(log_path + '/' + file_name)

                if insert_df is not None:
                    try:
                        return self.output_convert_log(insert_df,
                                                output_log_path,
                                                log_info_wo_header,
                                                file_name,
                                                target_eqp.eqp_name,
                                                no_header_type)
                    except Exception as errmsg:
                        self.dbg('[ERROR:_convert_log_file#4] output_convert_log' + log_path + '/' + file_name)
                        self.dbg(errmsg)
                else:
                    self.dbg('[ERROR: insert_df is none]' + log_path + '/' + file_name)

            except Exception as errmsg:
                self.dbg(
                    '[ERROR:_convert_log_file#5] log_converter_wo_header.output_db_data ' + log_path + '/' + file_name)
                self.dbg(errmsg)
        else:
            self.dbg('[ERROR;_convert_log_file] ALL NONE:' + log_path + '/' + file_name + '(' + no_header_type + ')')

        if convert_file_name is not None and len(convert_file_name) != 0:
            os.remove(log_path + '/' + file_name)

        return None, None

    def output_convert_log(self, insert_df, output_path, log_info, file_name, tool_name, log_type, chamber_mode=False):
        """
        変換したログを出力する
        :param insert_df:
        :param output_path:
        :param log_info:
        :param file_name:
        :param tool_name:
        :param log_type:
        :return:
        """
        db_table = log_info.db_table

        if log_info is not None:
            if not os.path.exists(output_path):
                os.makedirs(output_path, exist_ok=True)

        if '' in insert_df.columns:
            del insert_df['']

        log_type_path = output_path + '/' + log_type
        log_eqp_path = output_path + '/' + 'ChamberLog' + '/' + tool_name + '/'
        if not os.path.exists(log_type_path):
            os.makedirs(log_type_path, exist_ok=True)

        elif chamber_mode is True and os.path.exists(log_eqp_path) is False:
            os.makedirs(log_eqp_path, exist_ok=True)
        if chamber_mode:
            insert_df.to_csv(log_eqp_path + '/' + log_info.log_name + '_' \
                             + file_name + '_' + tool_name + '.csv', index=False)

        insert_df.to_csv(log_type_path + '/' + log_info.log_name + '_' \
                         + file_name + '_' + tool_name + '.csv', index=False)

        return db_table, insert_df

            # self.dbif.insert_df_data(db_table, insert_df)

    def get_log_convert_type(self, equipment, log_name):
        """
        例外的なログタイプを取得する
        :param equipment:
        :param log_name:
        :return:
        """
        if exist_table('special_log_type'):
            if self.special_log_type is None:
                self.special_log_type = self.dbif.get_data('special_log_type')
                # self.special_log_type.to_excel('logtype.xlsx')

            log_type = self.special_log_type[(self.special_log_type['log_name'] == log_name) \
                                             & (self.special_log_type['equipment_name'] == equipment.eqp_name)]

            if len(log_type) != 0:
                return log_type['log_type'].values[0]

        return equipment.wo_header_log_type

    def get_log_converter(self, log_name, log_def, convert_info, eqp_name, header=True, year=None):
        """
        指定されたログ種別IDに対応するLogConverterオブジェクトを取得する
        :param log_type_id:
        :param log_def:
        :param convert_info:
        :param eqp_name:
        :param header:
        :param year:
        :return:
        """
        log_format = self.get_format_type(log_name)

        if header is True and log_format == definfo.LOG_STANDARD:  # 通常のCSV形式
            return logconverter.StandardLogConverter(log_def, convert_info, eqp_name)
        elif log_format == definfo.LOG_RUNNING:  # 稼働率
            return logconverter.RunningLog(log_def, convert_info, eqp_name)
        elif header is False and log_format == definfo.LOG_STANDARD:
            return logconverter.StandardLogConverterNoHeader(log_def, convert_info, eqp_name, year)
        elif log_format == definfo.LOG_VERSION:
            return logconverter.VersionConverter(log_def, convert_info, eqp_name)
        else:
            return None

    def get_format_type(self, log_name):
        """
        指定されたログ種別IDのフォーマットタイプを取得する
        :param log_name: Log種別に固有のID
        :return:
        """
        if self.log_define is None:
            self.log_define = self.setting_dbif.get_data('cnvbase.log_define')

        log_format = self.log_define[self.log_define['log_name'] == log_name]['log_format']

        return log_format.values[0]

    def get_db_table(self, log_type_id):
        """
        指定されたログ種別IDを格納するtable名を取得する
        :param log_type_id: Log種別に固有のID
        :return:
        """
        if self.log_define is None:
            self.log_define = self.setting_dbif.get_data('log_define')

        log_format = self.log_define[self.log_define['logtype_id'] == log_type_id]['db_table']

        return log_format.values[0]

    def get_log_convert_info(self, log_name, log_type=None):
        """
        指定されたlog の変換のための情報を取得する
        :param log_name: Log固有の名前
        :param log_type: Logタイプ CSVの場合のタイプ
        :return:
        """
        log_format = self.get_format_type(log_name)
        if log_format == definfo.LOG_STANDARD or log_format == definfo.LOG_CHAMBER or log_format == definfo.LOG_VERSION:
            if self.log_columns is None:
                self.log_columns = self.setting_dbif.get_data('cnvbase.convert_columns_define')

            # print(log_name)
            # print(log_type)

            retval = self.log_columns[(self.log_columns['log_name'] == log_name) & \
                                      (self.log_columns['log_type'] == log_type)].sort_values(by=['col_no'],
                                                                                              ascending=True)

            return retval
        elif log_format == definfo.LOG_RUNNING:
            return self.setting_dbif.get_data('cnvbase.running_log_define')
        else:
            return None

    def get_log_define(self, log_name):
        """
        指定されたlog type IDのLogDefine情報を取得する
        :param log_name: Log種別に固有のID
        :return:
        """
        if self.log_define is None:
            self.log_define = self.setting_dbif.get_data('cnvbase.log_define')

        # print(self.log_define['log_header'])
        # print(type(self.log_define['log_header'][0]))
        with_header = self.log_define[(self.log_define['log_name'] == log_name) \
                                      & (self.log_define['log_header'] == 'with_header')]

        wo_header = self.log_define[(self.log_define['log_name'] == log_name) \
                                    & (self.log_define['log_header'] == 'without_header')]

        return with_header, wo_header

    def get_dir_name(self, eqp_name):
        """
        装置名からログ出力先のパスを取得する
        :param eqp_name:
        :return:
        """

        if self.equipments is None:
            self.equipments = self.dbif.get_data('equipments')

        equipment = dict(self.equipments[self.equipments['equipment_name'] == eqp_name].iloc[0])

        user_name = equipment['user_name']
        fab_name = equipment['fab_name']
        tool_id = equipment['tool_id']

        return user_name + '/' + fab_name + '/' + tool_id


class PreConverter(object):
    """
    ログを変換できる形に予め処理するクラス
    """

    def __init__(self, log_root, **setting_config):
        """
        コンストラクタ
        :param setting_config: データベース接続情報
        :param log_root: ログディレクトリ
        """
        self.setting_dbif = database_if.DatabaseIF(**setting_config)
        self.log_root = log_root

        """
        print("######################################")
        print("# <<<Pre Converter>>>")
        print("# log path :", self.log_root)
        print("# cras_db_addr :", setting_config['host'])
        print("# cras_db_port :", setting_config['port'])
        print("# cras_db_name :", setting_config['database'])
        print("######################################")
        """

    def exec_convert(self, user_name, fab_name):
        """
        ログ変換処理を実行する
        :return:
        """

        # データベースから変換情報を取得
        def_df = self.setting_dbif.get_data('pre_convert_define')

        # データベースから装置情報を取得
        eqp_df = self.setting_dbif.get_data('equipments')

        # 変換処理メインループ
        # 定義データから定義情報を取り出す
        for _, elem in def_df.iterrows():
            eqp = elem['equipment_name']
            eqp_list = list(eqp_df['equipment_name'])
            input_path = elem['input_path']
            # 装置情報が有る場合
            if eqp in eqp_list:
                # 装置情報を取得し、ログのパスを作成
                eqp_info = eqp_df[eqp_df['equipment_name'] == eqp].iloc[0]
                log_path_elem = eqp_info['user_name'] + '/' + \
                                eqp_info['fab_name'] + '/' + \
                                eqp_info['tool_id'] + '/'

                log_path = os.path.join(self.log_root, log_path_elem + input_path)
                if os.path.exists(log_path):
                    files = os.listdir(log_path)
                    last_time = eqp_info['last_exec_time']

                    # 変換ルーチンを呼び出す
                    self._convert(files, elem, last_time, os.path.join(self.log_root, log_path_elem))

    def _convert(self, files, conv_info, last_time, log_path_root):
        """
        ファイル毎に変換を実行する
        :param file_list:
        :param conv_info:
        :return:
        """
        input_path = os.path.join(log_path_root, conv_info['input_path'])
        output_path = os.path.join(log_path_root, conv_info['output_path'])

        # ログディレクトリ内のファイルを変換する
        for file in files:
            input_file = os.path.join(input_path, file)
            output_file = os.path.join(output_path, file)
            log_time = datetime.datetime.fromtimestamp(os.stat(input_file).st_mtime)
            # 最終処理のタイムスタンプより新しい場合に変換
            if log_time > last_time:
                # if True:
                self.dbg(log_time, last_time, input_file)
                if not os.path.exists(output_path):
                    os.makedirs(output_path, exist_ok=True)
                if conv_info['process_type'] == 'replace':
                    self._replace_header(input_file, output_file, conv_info['headers'])
                elif conv_info['process_type'] == 'add':
                    self._add_header_and_del_row(input_file, output_file, conv_info['headers'], conv_info['back_comma'])

    def _add_header_and_del_row(self, input_file, output_file, headers, last_comma):
        """
        新旧フォーマットが混じったログの処理を行う。
        ヘッダが無いログにカラムを付加し、不要なデータを削除する。
        :param input_file:
        :param output_file:
        :param headers:
        :return:
        """
        with open(input_file, "r") as f:
            # すべての内容を読み込む
            lines = f.readlines()

        logs = list()
        # ヘッダ付きログの場合変換は行わずファイルをコピーする
        if lines[0].startswith('#'):
            with open(output_file, "w") as f:
                # すべての内容を書き込む
                f.writelines(lines)
                return
        # 逆順にデータを読み込み
        for line in (reversed(lines)):
            input_line = line.strip('\n').split(',')
            if last_comma is True and input_line[-1] == '':
                del input_line[-1]
            if len(input_line) == len(headers.split(',')):
                logs.append(input_line)
        df_header = headers.strip('#').split(',')
        df = pd.DataFrame(logs[::-1], columns=df_header)
        df = df[df['Date Time'].apply(lambda n: n.startswith('20'))]  # 西暦(20で始まる)のデータのみを抽出
        df.columns = headers.split(',')
        df.to_csv(output_file, index=False)

    def _replace_header(self, input_file, output_file, headers):
        """
        ヘッダを置換し出力する
        :param input_file: 入力ファイル
        :param output_path: 出力ファイル
        :param headers: ヘッダ
        :return:
        """
        # 入力ファイルのすべての内容を読み込む
        with open(input_file, "r") as f:

            lines = f.readlines()

        # １行目がヘッダの場合ヘッダを置換し書き込み
        if headers[-1] != '\n':
            headers += '\n'
        if lines[0].startswith('#'):
            lines[0] = headers
            with open(output_file, "w") as f:
                f.writelines(lines)


def main(parser):
    """
    # 1.ターゲットから処理する対象の情報を取り出す
    # 2. LogTypeIDを使用し、logDefineからカラム情報を、Log_typeからファイル情報を取り出す
    # 3. 対象ファイルを読み込み、上記情報を使用し、変換する
    # 4. 装置情報を付加する
    # 5. データを格納する

    :return:
    """
    parser.add_argument("-f", type=str, help="define files. This option is required", required=True)
    parser.add_argument("-user", type=str, help="define files. This option is required", required=True)
    parser.add_argument("-fab", type=str, help="define files. This option is required", required=True)

    command_arguments = parser.parse_args()
    ini = configparser.ConfigParser()
    ini.read(command_arguments.f)

    # Setting DBの情報：INIファイルから取得
    setting_config = {
        'host': ini.get("setting_db", "db_addr"),
        'port': ini.get("setting_db", "port"),
        'database': ini.get("setting_db", "database"),
        'user': ini.get("setting_db", "user"),
        'password': ini.get("setting_db", "pass")
    }

    """
    # CRAS DBの情報：Setting DBから取得
    connection_config = {
        'host': ini.get("database", "address"),
        'port':  ini.get("database", "port"),
        'database': ini.get("database", "database"),
        #'database': 'devdb',
        'user': ini.get("database", "user"),
        'password': ini.get("database", "password")
    }
    """

    # Setting DBから取得
    # output_path = ini.get("settings", "output")
    # input_path = ini.get("settings", "input")

    # 1.ターゲットから処理する対象の情報を取り出す
    # execute = ExecuteConvert(connection_config, setting_config, output_path, input_path)
    execute = ExecuteConvert(setting_config, command_arguments.user, command_arguments.fab)
    # execute = ExecuteConvert(connection_config, 'C:/rss_dev_test/log', 'C:/rss_dev_test/collect_def/output')

    if len(execute.root_path) == 0 or len(execute.target_path) == 0:
        self.dbg("log path is not available!!!")
        return

    """
    2020年6月18日から　Pre Converterは不要
    ############################
    # GKC BQの場合PreConverterを実行する
    ############################
    if command_arguments.user == 'GKC' and command_arguments.fab == 'BQ':
        print("excute pre converte!!!")
        precon_execute = PreConverter(execute.connection_config, execute.target_path)
        precon_execute.exec_convert(command_arguments.user, command_arguments.fab)
    """

    ############################
    # LOG変換開始
    ############################
    execute.exec_convert(command_arguments.user, command_arguments.fab)


def local_debug(parser):
    """
    # 1.ターゲットから処理する対象の情報を取り出す
    # 2. LogTypeIDを使用し、logDefineからカラム情報を、Log_typeからファイル情報を取り出す
    # 3. 対象ファイルを読み込み、上記情報を使用し、変換する
    # 4. 装置情報を付加する
    # 5. データを格納する

    :return:
    """
    parser.add_argument("-f", type=str, help="define files. This option is required", required=True)

    command_arguments = parser.parse_args()
    ini = configparser.ConfigParser()
    ini.read(command_arguments.f)

    # Setting DBの情報：INIファイルから取得
    setting_config = {
        'host': ini.get("setting_db", "db_addr"),
        'port': ini.get("setting_db", "port"),
        'database': ini.get("setting_db", "database"),
        'user': ini.get("setting_db", "user"),
        'password': ini.get("setting_db", "pass")
    }

    execute = ExecuteConvert(setting_config, 'LOCAL', 'LOCAL')

    if len(execute.root_path) == 0 or len(execute.target_path) == 0:
        print("log path is not available!!!")
        return

    execute.exec_convert('LOCAL', 'LOCAL')


if __name__ == '__main__':
    start_time = time.time()
    print("## executeconv.py start >>>>>")
    arg_parser = argparse.ArgumentParser()
    main(arg_parser)
    print("## executeconv.py end <<<<< (", time.time() - start_time, ")")
