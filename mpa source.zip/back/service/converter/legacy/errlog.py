import pandas as pd
import json
import re
import os
import datetime

from service.converter.legacy import database_if
import numpy as np


class ErrorLog():
    """
    稼働率ログのエラー関連ログ解析クラス
    """
    A_RANK_PTN1 = '【Error occurrence】.*・A rank\n(.*)・B rank'
    A_RANK_PTN2 = '【Error occurrence】.*・A rank\n(.*)・B/D rank'
    B_RANK_PTN1 = '・B rank\n(.*)・C rank'
    B_RANK_PTN2 = '・B/D rank\n(.*)・C rank'
    C_RANK_PTN1 = '・C rank\n(.*)・D rank'
    C_RANK_PTN2 = '・C rank\n(.*)$'
    C_RANK_PTN3 = '・C rank\n(.*)【'
    D_RANK_PTN1 = '・D rank\n(.*)【'
    D_RANK_PTN2 = '・D rank\n(.*)$'
    ERR_CODE_PTN = '\w{7}'
    ERR_NAME_PTN = '/(.+),\w+'
    ERR_COUNT_PTN = ',(\d+)\[time\]'
    ERR_ELAPSED_PTN = '\d{2}:\d{2}:\d{2}'
    ERR_RANK = ['A', 'B', 'C', 'D']
    LOG_COL = ['rank', 'code', 'name', ]
    ERR_LOG_COL = ["DATE", "TOOL", "RANK", "ERR"]
    ERR_DB_COL = ['equipment_name', 'log_date', 'error_no', 'error_name', 'error_rank',
                  'error_count', 'elapsed', 'error_category']
    DATE_PTN = 'Start time:(\d{4}/\d{2}/\d{2})'
    COL_DICT = {'Day': 'log_date',
                'Elapsed': 'elapsed',
                'ErrCount': 'error_count',
                'ErrNo': 'error_no',
                'ErrRank': 'error_rank',
                'ErrName': 'error_name'
                }

    def __init__(self, **db_setting):
        self.db_setting = db_setting
        self.error_category = {}

    def read_log(self, file):
        """
        ログファイルを読み込みファイル内容を返す
        :param file: ファイル名
        :return: ファイル内容
        """
        data = None
        try:
            with open(file, 'r', encoding='utf-8') as f:
                data = f.read()
        except:
            with open(file, 'r', encoding='shift_jis') as f:
                data = f.read()
        return data

    def convert_log(self, log_path, target_eqp):
        """
        ログの変換処理
        :param data:
        :return:
        """
        log = self.read_log(log_path)
        dbdf = pd.DataFrame(columns=self.ERR_DB_COL)
        date = self.get_date(log)
        if date:
            err_list = self.create_error_list(log)
            db_err = self.create_err_df(target_eqp.eqp_name,  date, err_list)
            dbdf = dbdf.append(db_err, ignore_index=True)
        return dbdf

    def convert_errlog(self, error_log, err_rank):
        """
        稼働率データからエラーサマリを作成する
        :param error_log:
        :param err_rank:
        :return:
        """
        err_no = error_log.split('/', 1)[0].strip().upper()
        err_str = error_log.split('/', 1)[1].split(',')
        name = err_str[0].strip()
        count = int(err_str[1].replace('[time]', ''))
        elapsed = np.nan
        if err_rank != 'C':
            try:
                h, m, s = err_str[2].split(':')

                delta = int(h) * 10000 + int(m) * 100 + int(s)
                if delta >= 240000:
                    elapsed = np.nan
                else:
                    elapsed = err_str[2].strip()
            except:
                elapsed = np.nan

        return [err_no, name, err_rank, count, elapsed]

    def create_err_df(self, machine, date, ranked_err):
        """
        エラーDB登録・ファイル出力用のDataFrameを作成する
        :param machine: 装置
        :param date: エラーの日付
        :param ranked_err: ランク毎に分けられたエラー
        :return: ファイル出力用データ、DB出力用データ
        """

        rank = 0
        posgre = database_if.DatabaseIF(**self.db_setting)  # MongoDB I/Fインスタンスの生成

        errlog_list = []
        db_list = []
        for err_list in ranked_err:  # エラーリストからランク毎のエラー一覧を取得
            if len(err_list) != 0:
                for err in err_list:
                    err = err.strip()
                    if len(err) != 0:
                        str_rank = self.convert_rank(rank)  # エラーランクを文字に変換
                        err_elem = self.convert_errlog(err, str_rank)
                        err_no = err_elem[0].upper()
                        category = self.get_error_category(err_no, posgre)
                        try:
                            equipment_name = machine
                            err_val = [equipment_name, date]
                            err_val.extend(err_elem)
                            err_val.append(category)
                            db_list.append(err_val)
                        except:
                            print(machine)

            rank += 1
        dbdf = pd.DataFrame(db_list, columns=self.ERR_DB_COL)
        return dbdf

    def get_error_category(self, error_no, db_if):
        """
        Error Noからカテゴリを取得する
        :param error_no:
        :param db_if:
        :return:
        """

        # 取得のためのSQL
        sql = 'SELECT category_name FROM cnvbase.error_category WHERE unit_no = %s AND category_no = %s;'
        unit = error_no[0]  # エラーユニットNo(CONS/MAIN/SCAN/PERL)
        cat = error_no[2]  # エラー発生サブユニット(発生箇所)

        if (unit, cat) not in self.error_category:
            ret = db_if.exec_sql(sql, [unit, cat])
            if len(ret) == 0:  # 取得できなかった場合Otherにする
                category = 'Other'
            else:
                category = ret[0][0]
            self.error_category[(unit, cat)] = category
        else:
            category = self.error_category[(unit, cat)]

        return category

    def create_error_list(self, logdata):
        """
        ログからランク毎のエラーリストを作成する
        :param logdata: ログ
        :return: ランク毎エラーリスト　頭からA->B->C->D となる
        """
        err_list = []
        arank = re.search(ErrorLog.A_RANK_PTN1, logdata, flags=re.DOTALL)
        brank = re.search(ErrorLog.B_RANK_PTN1, logdata, flags=re.DOTALL)
        crank = re.search(ErrorLog.C_RANK_PTN1, logdata, flags=re.DOTALL)
        drank = re.search(ErrorLog.D_RANK_PTN1, logdata, flags=re.DOTALL)

        if arank is None:
            arank = re.search(ErrorLog.A_RANK_PTN2, logdata, flags=re.DOTALL)

        if brank is None:
            brank = re.search(ErrorLog.B_RANK_PTN2, logdata, flags=re.DOTALL)

        if crank is None:
            crank = re.search(ErrorLog.C_RANK_PTN2, logdata, flags=re.DOTALL)

        if crank is None:
            crank = re.search(ErrorLog.C_RANK_PTN3, logdata, flags=re.DOTALL)

        if drank is None:
            drank = re.search(ErrorLog.D_RANK_PTN2, logdata, flags=re.DOTALL)

        if arank:
            alist = arank.group(1).split('\n')
            err_list.append(alist)
        else:
            err_list.append(list())

        if brank:
            blist = brank.group(1).split('\n')
            err_list.append(blist)
        else:
            err_list.append(list())

        if crank:
            clist = crank.group(1).split('\n')
            err_list.append(clist)
        else:
            err_list.append(list())

        if drank:
            dlist = drank.group(1).split('\n')
            err_list.append(dlist)
        else:
            err_list.append(list())

        return err_list


    def convert_rank(self, rank):
        """
        エラーランク変換
        :param rank: エラーランクの数字
        :return: エラーランク文字
        """
        if rank == 0:
            return 'A'
        elif rank == 1:
            return 'B'
        elif rank == 3:
            return 'D'
        else:
            return 'C'

    def get_date(self, data):
        """
        ログの内容から日付を抜き出す
        :param data: ログ
        :return: 日付
        """
        date = None
        match = re.search(self.DATE_PTN, data)
        if match:
            date = re.search(self.DATE_PTN, data).group(1)
        return date

