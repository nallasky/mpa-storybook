ESP_ADDR = 'ESP_IP_ADDR'
ESP_USER = 'ESP_USER'
ESP_PASS = 'ESP_PASS'
COLLECT_NO_COL = 'COLLECT_NO'
COLLECT_TIME_COL = 'COLLECT_TIME'
COLLECT_TYPE = 'TYPE'
USER_COL = 'USER'
FAB_COL = 'FAB'
TOOL_COL = 'TOOL'
SERIAL_COL = 'SERIAL'
MACHINE_COL = 'MACHINE_TYPE'
LOG_NAME = 'Logname'
LOG_PATH = 'Path'

COLLECTION_TYPE = 'COLLECTION_TYPE'
COLLECTION_TARGET = 'COLLECTION_TARGET'
COLLECTION_PATH = 'COLLECTION_PATH'
TARGET_PATH = 'TARGET_PATH'
COLLECTION_TYPE_FILE = 1
COLLECTION_TYPE_ESP = 2

# Inputデータ定義用定数
INPUT_COL = 'input_col_name'
OUTPUT_COL = 'output_col_name'
DATA_TYPE = 'data_type'
COEF = 'coef'
COL_NUM = 'col_no'
SUB_COL_NAME = 'input_col_name_sub'

# Logデータ定義用定数
LOG_TYPE='log_format'
DB_TABLE = 'db_table'
UPDATE = 'is_daily_updated'
COL_NAME_ROW = 'column_name_row'
DATA_START_ROW = 'data_start_row'
DEVICE = 'device'
PROCESS = 'process'
EQP_NAME = 'equipment_name'

# Logタイプ
LOG_STANDARD = 'standard'
LOG_RUNNING = 'RUNNING'
LOG_CHAMBER = 'CHAMBER'
LOG_COMBINED = 'multiple'
LOG_ILLSTATUS = 'ILLSTATUS'
LOG_VERSION = 'version'
