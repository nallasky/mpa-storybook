import datetime


class Equipment:

    def __init__(self, loginfo):
        # 2021-05-25  Ted  Delete unused variables.
        # (self.phase, self.tool_inner_name)

        self.user_name = loginfo['user_name']  # ユーザー名
        self.fab_name = loginfo['fab_name']  # ファブ名
        # self.phase = loginfo['phase']  # Phase名
        if self.user_name == 'GKC' and self.fab_name == 'G4':
            self.tool_name = loginfo['tool_id'] + '_' + loginfo['inner_tool_id']  # 顧客装置名
        else:
            self.tool_name = loginfo['tool_id']

        # self.tool_inner_name = loginfo['inner_tool_id']  # キヤノン装置名

        self.header_log_type = loginfo['log_header_type']  # ヘッダありの場合のログ種別
        self.wo_header_log_type = loginfo['old_log_type']  # ヘッダなしの場合のログ種別
        self.chamber_log_type = loginfo['chamber_log_type']  # ヘッダなしの場合のログ種別
        self.eqp_type = loginfo['equipment_type']  # 装置種別
        self.last_time = loginfo['last_exec_time']  # 解析の最終時間
        self.eqp_name = loginfo['equipment_name']  # 装置名
        self.next_time = datetime.datetime.now()  # 次に解析するログのタイムスタンプ

    def set_now_time(self):
        """
         次に解析するログのタイムスタンプを現在以降のものにする
        :return:
        """
        self.next_time = datetime.datetime.now()
        # print(self.next_time)

    def to_dict(self):
        """
        装置情報を辞書に変換する
        :return:
        """

        log_info = dict()
        log_info['user'] = self.user_name
        log_info['fab'] = self.fab_name
        log_info['tool'] = self.tool_name
        log_info['log_header_type'] = self.header_log_type
        log_info['old_log_type'] = self.wo_header_log_type
        log_info['chamber_log_type'] = self.chamber_log_type
        log_info['equipment_type'] = self.eqp_type
        log_info['last_exec_time'] = self.next_time
        return log_info
