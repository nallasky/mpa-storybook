import time
import os
import shutil
import datetime
import logging
from threading import Thread
import pandas.tseries.offsets as t_offsets

from config.app_config import *
from dao.dao_base import DAOBaseClass

logger = logging.getLogger(LOG)


class ServiceCleaner(Thread):
    def __init__(self):
        Thread.__init__(self)

    def run(self):
        while True:
            dao = DAOBaseClass(table_name='cnvset.job')

            date_offset = t_offsets.DateOffset(hours=EXPIRING_DATE_HOUR)
            date = datetime.datetime.now() - date_offset

            # Clean cnvset.job, .convert directory
            df = dao.fetch_all(args={'select': 'start, id, status', 'where': "start < '%s' and status = 'success'" % date})

            if len(df) > 0:
                for i in range(len(df)):
                    job_id = df.iloc[i]['id']
                    # dao.delete("delete from cnvset.working_logs where job_id = '%s'" % job_id)
                    job_path = os.path.join(local_cache_root, job_id)
                    if os.path.exists(job_path):
                        shutil.rmtree(job_path)
                        logger.info(f'Clean cache files from {job_path}')

                dao.delete("delete from cnvset.job where start < '%s' and status = 'success'" % date)

            # Clean Converted Logs
            sql = "SELECT table_schema,table_name FROM information_schema.tables " \
                  "WHERE table_schema = '%s' ORDER BY table_schema,table_name" % SCHEMA_CONVERT
            tables = dao.execute(sql)
            for table in tables:
                _count = dao.execute(f"select count(*) from information_schema.columns where table_name = '{table[1]}' \
                                and table_schema = '{SCHEMA_CONVERT}' and column_name = 'created_time'")
                if _count[0][0] > 0:
                    dao.delete(f"delete from {SCHEMA_CONVERT + '.' + table[1]} where created_time < '{date}'")
            time.sleep(CLEANER_INTERVAL)
