"""
File: version_info_mail_html.py
Date:
Author:
Description:Version Info reportを作成
Rev:
"""
import sys
import os
import datetime

from jinja2 import Template


sys.path.append(os.path.dirname(os.getcwd()))
sys.path.append(os.path.abspath(os.getcwd()))


BASE_HTML = '''
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <title>Version Info Report</title>
</head>
<style type="text/css">
body {
    color:#000000;
    background-color:#FCECE8;
    margin:10px 10px 10px 10px;
    padding:0px;
    font:normal normal normal 11pt/14pt 'Arial';
}
.gs_none {
    border-width:0px;
}
.gs_header {
    border-width:0px;
    background-color:#FCECE8;
    padding: 20px 20px 20px 20px;
    font:normal normal normal 14pt/14pt 'Arial';
}
.gs_tail {
    border-width:0px;
    padding: 20px 20px 20px 20px;
    font:normal normal normal 11pt/14pt 'Arial';
}
table {
    border:0px;
    border-collapse:collapse;
    font:normal normal normal 11pt/13pt 'Arial';
    table-layout:fixed;
    word-break:break-all;
}
th {
    border:0px;
    padding: 1px 5px 1px 5px;
    font:normal normal bold 11pt/13pt 'Arial';
    text-align:center;
    vertical-align:middle;
    background-color:#F8D7CD;
}
td {
    border:0px;
    padding: 1px 5px 1px 5px;
}
.gs_bar1 {
    border-width:0px;
    color:#FFFFFF;
    background-color:#ED7D31;
    font:normal normal bold 14pt/14pt 'Arial';
    padding:3px 3px;
}
.gs_bar2 {
    border-width:0px;
    color:#FFFFFF;
    background-color:#ED7D31;
    text-align:right;
}
.gs_barmark {
    color:#FFD700;
    font:normal normal bold 14pt/14pt 'Arial';
}
.gs_body {
    border-width:0px 1px 0px 1px;
    padding:10px;
    background-color:#FFFFFF;
    text-align:left;
    vertical-align:top;
}
</style>
<body>
    {{ table_data }}    
</body>
</html>
'''

def create_html_data(version_dict, report_header, report_tail):
    """
    Production dataからメール配信用HTMLの作成
    :param production_data:
    :return HTML Data
    """
    tool_list = list(version_dict.keys())
    tool_list.sort()
   
    date_list = list(version_dict[tool_list[0]].columns)
    date_list.remove('unit')
    date_list.remove('version_up')

    table_html = '''
    <table class="gs_none" style="width:{{ html_width }}">
    <tr>        
    <td class="gs_body" colspan="100" style="border:1px solid #EA5234;">
        <table class="gs_none" style="width:100%;">
            <tr>
                <td class="gs_header" colspan="96" style="border:5px solid #EA5234;">{{ report_header }}</td>
            </tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
        </table>
        {% for tool, vesion_up_list in render_data.items(): %}
        <table class="gs_none" style="width:100%;">
            <tr>
                <td class="gs_bar1" colspan="96"><font class="gs_barmark">&#X25C6; </font> {{ tool }}</td>
            </tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
            <tr>
                <td class="gs_none" colspan="96">
                    <table class="gs_none" style="width:100%;">
                        <thead>
                            <tr>                               
                                <th scope="col" style="border:1px solid #EA5234; width:150px;">UNIT</th>
                                {% for date in date_list: %}
                                <th scope="col" style="border:1px solid #EA5234; width:100px;">{{ date }}</th>
                                {% endfor %}
                            </tr>
                        </thead>
                        <tbody>
                            {% for record in vesion_up_list: %}
                            <tr>
                                <td style="text-align:center; border:1px solid #EA5234; background-color:#F8D7CD;"><b>{{ record[0] }}</b></td>
                                {% for i in range(1, date_list_cnt+1): %}
                                <td style="text-align:center; border:1px solid #EA5234;">{{ record[i] }}</td>
                                {% endfor %}
                            </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr><td class="gs_none" colspan="96">&nbsp;<br>&nbsp;</td></tr>
        </table>
        {% endfor %}
        <table class="gs_none" style="width:100%;">
            <tr><td class="gs_none" colspan="96"><hr></td></tr>
            <tr>
                <td class="gs_tail" colspan="96">{{ report_tail }}</td>
            </tr>
            <tr><td class="gs_none" colspan="96"><hr></td></tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
        </table>
    </td>
    </tr>
    <tr>
    <td class="gs_none" colspan="100" style="text-align:right;">Canon Remote Alarm System Version 2.0</td>
    </tr>
    </table>
    '''
    render_data = dict()

    for tool in tool_list:
        vesion_up_list = version_dict[tool]
        vesion_up_list = vesion_up_list[vesion_up_list['version_up'] == 'TRUE']
        vesion_up_list = vesion_up_list.drop(['version_up'], axis=1)
        vesion_up_list.reset_index(inplace=True, drop=True)
        
        if len(vesion_up_list) > 0:
            render_data[tool] = vesion_up_list.values.tolist()

    if len(render_data) == 0 :
        # print('no render data')
        return ''
    
    # HTMLの幅を決める
    width = 980

    if len(date_list) > 7:
        width = width + ((len(date_list)-7) * 110)

    html_width = '{}px'.format(width)

    ## Table Data Create
    table_data = {'render_data': render_data, 'date_list_cnt':len(date_list),'date_list':date_list, 'report_header':report_header, 'report_tail':report_tail, 'html_width':html_width}
    table_template = Template(table_html)
    output_table_html = table_template.render(table_data)     

    ## HTML Data Create
    data = {'table_data': output_table_html}        
    template = Template(BASE_HTML)
    output_html = template.render(data)        

    #print(os.path.abspath(os.getcwd())+"/test.html")
    #with open(os.path.abspath(os.getcwd())+"/test.html", "w") as f:
    #    # すべての内容を書き込む
    #    f.write(output_html)
    #print(output_html)

    return output_html