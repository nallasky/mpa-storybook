"""
File: send_version_info.py
Date:
Author:
Description: MPAのVersion情報変更をメールで送信
Rev:
"""
import datetime
import os
import smtplib
import socket
import sys
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate
from multiprocessing import Process

import pandas as pd

from config.cras_config import VERSION_ROOT
from dao.dao_base_server import BaseServerDao
from dao.dao_convert import ConvertDao
from dao.dao_version_job import VersionJobDao
from service.logger.process_log_base import ProcessLogBase
from service.logger.service_logger import ServiceLogger
from service.version.version_info_mail_html import create_html_data

sys.path.append(os.path.dirname(os.getcwd()))
sys.path.append(os.path.abspath(os.getcwd()))


class VersionCheckProcess(ProcessLogBase):

    def __init__(self, rid):
        self.rid = rid
        self.cache_root = '.version'
        if not os.path.exists(self.cache_root):
            os.mkdir(self.cache_root)
        self.cache_path = os.path.join(self.cache_root, self.rid)
        os.mkdir(self.cache_path)
        self.dbg_file = f'{self.rid}.log'

        self.log = None

        log_q = ServiceLogger.instance().queue
        log_config = ServiceLogger.instance().worker_configurer

        child = Process(target=self.create_version_report, args=(log_q, log_config,))
        child.daemon = True
        child.start()

    def create_message(self, from_addr, to_addr, subject, body, attach_file=None, cc_addr=None):
        """
        送信メッセージを作成する
        """
        msg = MIMEMultipart()
        msg["Subject"] = subject
        msg["From"] = from_addr
        msg["To"] = to_addr.replace(',', ', ')
        if cc_addr is not None:
            msg["Cc"] = cc_addr
        msg['Date'] = formatdate()

        # メール本文
        body = MIMEText(body, "html")
        msg.attach(body)

        # 添付ファイルを作成する。
        if attach_file is not None:
            attachment = MIMEBase('application', 'zip')

            file = open(attach_file['path'], 'rb')
            attachment.set_payload(file.read())
            file.close()

            encoders.encode_base64(attachment)
            attachment.add_header("Content-Disposition", "attachment", filename=attach_file['name'])

            msg.attach(attachment)

        return msg

    def create_subject(self, user, acq_period):
        """
        Subjectを作成する
        :param user:ユーザー名
        :paramacq_period : サマリーの期間
        :return:
        """
        subject_ = '【C-RAS】【Error Summary】{} ({})'.format(user, acq_period)
        return subject_

    def send_msg(self, smtp_server, from_addr, to_addr, cc_addr, msg):
        """
        メッセージを送信する
        :param smtp_server: SMTPサーバー
        :param from_addr: fromアドレス
        :param to_addr: toアドレス
        :param cc_addr: ccアドレス
        :param msg: メッセージ
        :return:
        """
        print("# Send Mail Start")
        print("# SMTP Server Addr. :", smtp_server)
        # print(msg.as_string())

        smtp = smtplib.SMTP(smtp_server)
        # smtp.set_debuglevel(1)

        print('# HOST NAME : ', socket.gethostname())
        print('# IP ADDRESS : ', socket.gethostbyname(socket.getfqdn()))

        # sendToList = to_addr.split(',') + cc_addr.split(',')

        try:
            # smtp.sendmail(from_addr, sendToList, msg.as_string())
            smtp.send_message(msg)
        except Exception as errmsg:
            print("## send_message error")
            print(errmsg)
            smtp.close()
            sys.exit(1)

        print("# Send Mail End")

        smtp.close()

    def send_mail_version_up_info(self, _version_dict):
        """
        """
        mail_msg = ''

        pd.set_option('display.max_row', None)
        pd.set_option('display.max_columns', None)
        pd.set_option('display.width', 300)

        for equipment_name in _version_dict.keys():
            vesion_up_list = _version_dict[equipment_name]
            vesion_up_list = vesion_up_list[vesion_up_list['version_up'] == 'TRUE']
            vesion_up_list = vesion_up_list.drop(['version_up'], axis=1)
            vesion_up_list.reset_index(inplace=True, drop=True)

            if len(vesion_up_list) > 0:
                mail_msg = mail_msg + '■' + equipment_name + '\r\n'
                mail_msg = mail_msg + '{}\r\n\r\n\r\n'.format(vesion_up_list)

        return mail_msg

    def create_version_report(self, log_q, log_config):
        self.log = self.get_logger(log_q, log_config, os.path.join(self.cache_path, self.dbg_file))

        self.inf('create version process (rid=%s)' % self.rid)

        io = VersionJobDao()
        job = io.get_job(self.rid)

        fab_name = 's2'

        user_name = os.environ.get('CRAS_SITE_NAME')  # Site name
        if user_name is None:
            io.change_status(self.rid, 'error')
            return None

        rows = ConvertDao.instance().count_row('version_info')
        if rows == 0:
            self.inf('no data to create a version report')
            io.change_status(self.rid, 'success')
            return None

        job = io.change_status(self.rid, 'running')

        _date_period = job['period']
        _today = datetime.date.today()
        _yesterday = _today - datetime.timedelta(days=1)
        _equip_list = BaseServerDao.instance().get_equipments(df=True)

        self.inf(f'today={_today}')

        if fab_name == 'CQ':
            fab_name = 'H1'

        if fab_name == 'CZ':
            fab_name = 'H2'

        _equip_list = _equip_list[_equip_list['user_name'] == user_name]
        _equip_list = _equip_list[_equip_list['fab_name'] == fab_name]

        _version_info = ConvertDao.instance().get_version_info(df=True)
        _version_list = _version_info['unit'].drop_duplicates().sort_values()

        _version_dict = dict()

        for row in _equip_list.iterrows():
            param = row[1]
            self.inf(f"Create Version List : {param['equipment_name']}")

            _version_table = pd.DataFrame(columns=['unit'])
            _version_table['unit'] = _version_list
            _version_table['version_up'] = ''

            # _version_infoから該当装置のみ洗い出す
            _version_info_equ = _version_info[_version_info['equipment_name'] == param['equipment_name']]
            if len(_version_info_equ) == 0:
                continue

            for _delta in range(_date_period):
                _date = _today - datetime.timedelta(days=_delta)
                _version_table['{}'.format(str(_date))] = '-'

                # _version_info_equから該当日付のみ洗い出す
                _version_info_equ_day = _version_info_equ[_version_info_equ['log_time'] == _date].sort_values(
                    by=['unit'])
                _version_info_equ_day.reset_index(inplace=True, drop=True)

                for i in range(len(_version_table)):
                    _unit = _version_table.loc[i, 'unit']
                    _temp = _version_info_equ_day[_version_info_equ_day['unit'] == _unit]
                    if len(_temp) > 0:
                        _temp.reset_index(inplace=True, drop=True)
                        _version_table.loc[i, str(_date)] = _temp['version'][0]

            self.inf(_version_table)

            ## 指摘された期間中バージョンの変更があるかをチェック
            for i in range(len(_version_table)):
                _ver = '-'
                for _delta in range(_date_period):
                    _date = _today - datetime.timedelta(days=_delta)

                    if _version_table.loc[i, str(_date)] != _version_table.loc[i, str(_date)]:
                        _version_table.loc[i, str(_date)] = '-'

                    if _ver != '-' and _version_table.loc[i, str(_date)] != '-' and _ver != _version_table.loc[
                        i, str(_date)]:
                        _version_table.loc[i, 'version_up'] = 'TRUE'
                        self.inf('version_up = True')
                        # _version_up = True
                        _version_table.loc[i, str(_date + datetime.timedelta(days=1))] = '★ ' + _version_table.loc[
                            i, str(_date + datetime.timedelta(days=1))]

                    _ver = _version_table.loc[i, str(_date)]

            _version_dict[param['tool_id'] + '_' + param['inner_tool_id']] = _version_table

        # create send mail msg
        # mail_msg = send_mail_version_up_info(_version_dict)

        self.inf('--------------- version_dict ----------------')
        self.inf(_version_dict)

        mail_msg = create_html_data(_version_dict, 'cras_mail_header', 'cras_mail_tail')
        report = ''
        if mail_msg == '':
            self.inf('no reporting data')
        else:
            report = os.path.join(root, f'version_report_{user_name}_{fab_name}.html')
            with open(report, 'w', encoding='utf-8') as f:
                f.write(mail_msg)
                self.inf('writing done')
        io.change_status(self.rid, 'success', report)
