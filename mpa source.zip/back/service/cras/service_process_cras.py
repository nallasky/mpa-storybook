import json
import os
import subprocess
import sys
import pandas as pd
import datetime
import requests
from multiprocessing import Process

from config.cras_config import CRAS_OUTPUT
from dao.dao_base import DAOBaseClass
from dao.dao_cras_job import CrasJobDao
from service.cras.exception import CrasException
from service.cras.service_create_data_cras import CRASDataCreate
from service.cras.service_production_report_cras import CCrasProductonReport
from service.cras.service_report_cras import CRASReport
from service.cras.service_send_mail_cras import CrasSendMail
from service.cras.service_judge_data_cras import CCrasJudge, create_abnormal_report_html
from service.cras.service_judge_data_cras import CCrasAbnormalReport
from shutil import copyfile

from service.logger.process_log_base import ProcessLogBase
from service.logger.service_logger import ServiceLogger


class ProcessCras(ProcessLogBase):
    """
    CRAS Process Class
    """

    # def __init__(self, ini_file, user_name, fab_name, cras_test):
    def __init__(self, request_id):
        self.request_id = request_id
        self.log = None
        self.io = CrasJobDao()
        job = self.io.get_job(request_id)

        # self.ini_file = ini_file
        self.user_name = job['site']
        self.fab_name = job['fab']
        self.cras_info = self.io.get_cras_data(self.user_name, self.fab_name)

        # 2021.05.07 Ted. Modify target_table values.
        self.cras_info['target_table'] = self.cras_info['target_table'].apply(
            lambda tbl: f'convert.{tbl}' if tbl is not None and tbl != '' else '')

        cache_root = '.cras'
        if not os.path.exists(cache_root):
            os.mkdir(cache_root)

        self.cache_path = os.path.join(cache_root, self.request_id)
        self.dbg_file = f'{self.request_id}.log'

        # if cras_test == 'TRUE':
        #     self.cras_test = 'TRUE'
        # else:
        #     self.cras_test = 'FALSE'
        self.cras_test = 'FALSE'
        # self.inf(f"CRAS TEST MODE: {self.cras_test}")

        self.output_path = os.path.join(self.cache_path, 'out')
        self.days = 31
        self.judge_period = 1

        self.cras_db_config = None
        self.cras_tool_data = self.io.get_cras_tool_info()

        self.mail_settings = None
        self.mail_address = None

        # self.input_file = "C:/rss/output/CRASData/cras.xlsx"
        self.input_file = None
        # self.output = "C:/rss/newcrasresult.xlsx"
        # self.output = os.path.join(self.output_path, CRAS_OUTPUT)
        self.output = os.path.join(self.output_path, f'JudgeResult_{self.user_name}-{self.fab_name}.xlsx')

        self.cras_pdf_name = os.path.join(self.output_path, 'CRAS_REPORT.pdf')
        self.mail_body_output = os.path.join(self.output_path, 'MESSAGE.html')

        self.zipexe_path = None
        self.zip_password = 'password'

        self.report_header = None
        self.report_tail = None

        self.cras_abnormal_data_table_name = 'cras_abnormal_data_' + self.user_name.lower() + '_' + self.fab_name.lower()
        self.send_mail = CrasSendMail()

        self.production_report = None

        log_q = ServiceLogger.instance().queue
        log_config = ServiceLogger.instance().worker_configurer

        process = Process(target=self.run, args=(log_q, log_config,))
        process.daemon = True
        process.start()

    def load_execute_info(self):
        """
        data setting
        """
        # ini = configparser.ConfigParser()
        # ini.read(self.ini_file)

        # db_if = posgre_if.PostgreIf(ini, 'setting_db')
        # settings_db = db_if.get_log_tabledata('collector_settings')
        # db_if = DAOBaseClass(dbname='settings', user='rssuser', password='rssuser', host='10.1.31.180')
        # settings_db = db_if.fetch_all(table='collector_settings')
        # response = self.rest_client('api/setting/collector_settings', 'GET', '')
        # collector_settings = json.loads(response.text)
        # response = self.rest_client('api/setting/cras_info_tool', 'GET', '')
        # cras_info_tool = json.loads(response.text)
        #
        # for param in collector_settings["lists"]:
        #     if (param['userName'] == self.user_name) and (param['fabName'] == self.fab_name):
        #         self.cras_db_config = {
        #             'host': param['crasDBAddr'],  # '172.27.227.237', #
        #             'port': param['crasDBPort'],
        #             'database': param['crasDBName'],
        #             'user': param['crasDBUser'],
        #             'password': param['crasDBPass']
        #         }
        #
        #         self.output_path = param['crasOutputPath']
        #         self.days = int(param['crasPeriod']) + 1
        #         #self.cras_tool_data = db_if.get_log_tabledata('cras_info_tool')
        #         self.cras_tool_data = cras_info_tool
        #
        #         self.mail_settings = {
        #             'smtp_server': param['sesSmtpServer'],
        #             'mail_sender_addr': param['sesMailSenderAddr'],
        #         }
        #
        #         self.mail_address = param['sesMailList']
        #
        #         self.zipexe_path = param['sesZipexePath']
        #         self.zip_password = param['sesZipPassword']
        #
        #         self.report_header = param['crasMailHeader']
        #         self.report_tail = param['crasMailTail']
        #         break
        #
        # if self.cras_db_config is None:
        #     print("db_addr is none")
        #     sys.exit(1)

        ## CRAS実行日計算
        last_exec = self.io.get_last_exec(self.request_id)

        self.inf(f"Today : {datetime.datetime.now().date()}")
        self.inf(f"CRAS last Execute : {last_exec}")

        if last_exec is None:
            _timedelta = datetime.timedelta(days=1)
        else:
            _timedelta = datetime.datetime.now() - last_exec

        self.judge_period = _timedelta.days

        if self.judge_period <= 0:
            self.judge_period = 1
        elif self.judge_period > 3:
            self.judge_period = 3

        self.inf(f"CRAS judge_period : {self.judge_period}")

    def update_cras_excute_date(self):
        """
        """
        _cras_info_table_name = 'cras_info_{}_{}'.format(self.user_name.lower(), self.fab_name.lower())
        # cras_db_if = database_if.DatabaseIF(self.cras_db_config)
        cras_db_if = DAOBaseClass(**self.cras_db_config)

        # ログ変換後 equipmentのlast_exec_timeを更新
        _today = '{}'.format(datetime.date.today())

        where_data = ('index', '1')
        update_data = ('last_execute', _today)

        self.inf(f"Update CRAS Execute Date : {_today}")
        # cras_db_if.update_data(_cras_info_table_name, update_data, where_data)
        cras_db_if.update_all(_cras_info_table_name, update_data, where_data)

    def execte_cras(self):
        self.load_execute_info()

        # 1. Create CRAS Data
        self.inf('### Create CRAS Data Start')
        self.Create_CRAS_Data()
        self.inf('### Create CRAS Data End')

        # 2. Production Report Create and mail
        if self.cras_test == 'FALSE':
            self.inf('### send_production_report Start')
            self.send_production_report()
            self.inf('### send_production_report End')
        else:
            self.inf("[CRAS TEST] Skip Send Production Report")

        # 3. Abnormal Data Report Create and mail
        self.inf('### CRAS Start')
        self.send_abnormal_report()  # <- テスト後、実際のSetting DBに変更が必要
        self.inf('### CRAS End')
        ###################

    def Create_CRAS_Data(self):
        """
        """
        createobj = CRASDataCreate(self.cras_tool_data,
                                   self.user_name,
                                   self.fab_name,
                                   dbg_print=self.inf)

        # file_name = 'cras.xlsx'
        file_name = f'CRASDATA_{self.user_name}-{self.fab_name}.xlsx'

        equipments_list = createobj.get_eqp_list()
        if len(equipments_list) == 0:
            self.err("no equipments. stop cras processing")
            raise CrasException("no equipments")

        cras_info = self.cras_info

        # CRAS 判定に必要な値のみ取得する場合
        # cras_info = cras_info[cras_info['enable'] == True]

        # データをDBから取得
        result = createobj.collect_data_by_day(cras_info, days=self.days)

        # file Save
        output = self.output_path + '/' + file_name

        if not os.path.isdir(self.output_path):
            os.makedirs(self.output_path)

        self.output_to_excel_by_tool(result, output, equipments_list)
        self.input_file = output

    def output_to_excel_by_tool(self, df, output, equipments):
        """
        CRAS用のファイルを出力する
        :param df:
        :param output:
        :return:
        """
        tools = df['ToolID'].drop_duplicates()
        # シートを装置毎に分割してExcelにする
        with pd.ExcelWriter(output) as writer:
            for tool in tools:
                if tool in equipments:
                    equipments.remove(tool)
                    book = df[df['ToolID'] == tool]
                    book = book.sort_values(by=['Day'], ascending=[False]).drop_duplicates('Day', keep='last')
                    book['Day'] = book['Day'].astype(str)
                    book['Day'] = book['Day'].str.replace('-', '/')
                    book.to_excel(writer, sheet_name=tool, index=False)
            for eqp in equipments:
                book = pd.DataFrame(columns=df.columns)
                book.to_excel(writer, sheet_name=eqp, index=False)
            writer.save()

    def send_production_report(self):
        """
        Production Report作成及びメール配信
        :param parser:
        :return:
        """
        # Production Report作成
        # production = cras_production_report.CCrasProductonReport(self.user_name,
        production = CCrasProductonReport(self.user_name, self.fab_name)
        production_report = production.create_production_report_html(self.report_header, self.report_tail)

        self.production_report = production_report

        # Production Mail配信
        # _mail_tile = '[C-RAS][Production Analysis] {}-{}'.format(self.user_name, self.fab_name)
        # self.send_mail.send_html_main(production_report, self.mail_address, self.mail_settings, _mail_tile)

    def get_state_count(self, toolid, cras_id, date):
        """
        """
        date = datetime.datetime.strptime(date, '%Y/%m/%d').date()

        # cras_db_if = database_if.DatabaseIF(self.cras_db_config)
        cras_db_if = DAOBaseClass(**self.cras_db_config)
        sql = "toolid = '{0}' AND cras_id = '{1}' AND date <= '{2}'".format(toolid, cras_id, date)

        # err_data = cras_db_if.get_data_with_col(self.cras_abnormal_data_table_name, sql)
        err_data = cras_db_if.fetch_all(table=self.cras_abnormal_data_table_name, args={'where': '{}'.format(sql)})

        err_data = err_data.sort_values(['date'], ascending=False)

        count = 0

        for _, elem in err_data.iterrows():
            if elem['date'] == date:
                date = date - datetime.timedelta(days=1)
                count = count + 1
            else:
                break

        return count

    def send_abnormal_report(self):
        """
        CRASデータ作成～Mail配信
        :param parser:
        :return:

        """
        rast_date = datetime.date.today() - datetime.timedelta(days=1)  # 昨日まで
        start_date = datetime.date.today() - datetime.timedelta(days=self.judge_period)  # 何日前から

        # Database Setting
        # cras_db_if = database_if.DatabaseIF(self.cras_db_config)
        cras_db_if = DAOBaseClass()

        # CRAS判定Data作成
        # cras_judge = cras_judge_data.CCrasJudge(self.input_file, cras_db_info, self.user_name, self.fab_name)
        cras_judge = CCrasJudge(self.input_file, self.user_name, self.fab_name, dbg_print=self.inf)
        result_df = cras_judge.create_cras_judge_data(rast_date, start_date)
        result_df.to_excel(self.output)

        # result_df = result_df.query('Result == "FALSE"')
        result_df = result_df.sort_values('ToolID')
        result_df.reset_index(inplace=True, drop=True)

        # CRAS Data をDBに格納
        if self.cras_test == 'FALSE':
            abnormal_db_df = result_df[result_df['Result'] == 'FALSE']
            abnormal_db_df = abnormal_db_df.loc[:, ['Date', 'ToolID', 'CRAS_ID', 'Value']]
            # cras_db_if.insert_df_data(self.cras_abnormal_data_table_name, abnormal_db_df)
            cras_db_if.insert_from_df(self.cras_abnormal_data_table_name, abnormal_db_df)

        ##State(連続で発生している日)をカウンター
        result_df['State'] = '0'

        for i in range(len(result_df)):
            if result_df.loc[i, 'Result'] == 'FALSE':
                count = self.get_state_count(result_df.loc[i, 'ToolID'],
                                             result_df.loc[i, 'CRAS_ID'],
                                             result_df.loc[i, 'Date'])
                result_df.loc[i, 'State'] = count

        # dbからequipmentsTable取得
        # equipment_df = cras_db_if.get_data('equipments',
        #                                   'equipment_name, tool_serial, tool_id, inner_tool_id')
        equipment_df = cras_db_if.fetch_all(table='cnvbase.equipments',
                                            args={'select': 'equipment_name, tool_serial, tool_id, inner_tool_id'})

        equipment_df = equipment_df.sort_values(by=['equipment_name'], axis=0)

        # Error Summary DataをDBから取得
        # err_summary = cras_db_if.get_data_with(
        #    "equipment_name, log_date, error_no, error_name, error_rank, sum(elapsed) AS elapsed, sum(error_count) AS count",
        #    "error_summary",
        #    "log_date <='{}' AND log_date >='{}' AND error_rank != 'C'".format(rast_date, start_date),
        #    "equipment_name, log_date, error_no, error_name,error_rank;")
        err_summary = cras_db_if.fetch_all(table='convert.error_summary',
                                           args={
                                               'select': 'equipment_name, log_date, error_no, error_name, error_rank, sum(elapsed) AS elapsed, sum(error_count) AS count',
                                               'where': "log_date <='{}' AND log_date >='{}' AND error_rank != 'C'".format(
                                                   rast_date,
                                                   start_date) + " group by equipment_name, log_date, error_no, error_name,error_rank;"})

        err_summary['log_date'] = err_summary['log_date'].astype(str)
        err_summary['log_date'] = err_summary['log_date'].str.replace('-', '/')

        # equipment_df = cras_db_if.get_data('equipments',
        #                                   'equipment_name, tool_serial, tool_id, inner_tool_id')
        equipment_df = cras_db_if.fetch_all(table='cnvbase.equipments',
                                            args={'select': 'equipment_name, tool_serial, tool_id, inner_tool_id'})

        equipment_df = equipment_df.sort_values(by=['equipment_name'], axis=0)

        # CRAS Mail
        # abnormal_rpt = cras_judge_data.CCrasAbnormalReport(self.cras_db_config)
        abnormal_rpt = CCrasAbnormalReport()
        abnormal_report = create_abnormal_report_html(result_df, err_summary, equipment_df, self.report_header,
                                                      self.report_tail)

        with open(os.path.join(self.mail_body_output), 'w', encoding='utf-8') as f:
            f.write(abnormal_report)

        # for CRAS TEST
        if self.cras_test == 'TRUE':
            self.inf("[CRAS TEST] Skip Send CRAS Report")
            self.inf(f"CRAS DATA FILE : {self.input_file}")
            self.inf(f"CRAS RESULT FILE : {self.output}")
            return

        # PDF作成
        cras_report = CRASReport(dbg_print=self.inf)
        cras_report.create_cras_report_pdf(self.user_name,
                                           self.fab_name,
                                           self.input_file,
                                           result_df,  # self.output,
                                           err_summary,
                                           equipment_df,
                                           self.cras_pdf_name,
                                           self.zip_password)


        return

        # Mail配信
        to_addr, cc_addr = self.send_mail.make_addr_list(self.mail_address)

        _mail_tile = '[C-RAS][Abnormal Detection] {}-{}'.format(self.user_name, self.fab_name)

        msg = self.send_mail.create_html_message(self.mail_settings["mail_sender_addr"],
                                                 to_addr,
                                                 _mail_tile,
                                                 abnormal_report,
                                                 cc_addr=cc_addr)

        # File Attach
        # 1. PDF
        file_path = os.path.dirname(self.cras_pdf_name)

        file_name = 'CRAS_Report_' + self.user_name + '-' + self.fab_name
        file_name = file_name + '_{0:04d}{1:02d}{2:02d}'.format(datetime.date.today().year,
                                                                datetime.date.today().month,
                                                                datetime.date.today().day)
        pdf_file_name = file_name + '.pdf'

        if os.path.exists(os.path.join(file_path, pdf_file_name)) is True:
            os.remove(os.path.join(file_path, pdf_file_name))

        os.rename(self.cras_pdf_name, os.path.join(file_path, pdf_file_name))

        attachment = self.send_mail.create_attach_file(file_path, pdf_file_name, 'pdf')
        if attachment is not None:
            msg.attach(attachment)

        # 2. CRASDATA_USER-FAB_YYYYMMDD.zip
        file_path = os.path.dirname(self.input_file)

        file_name = 'CRASDATA_' + self.user_name + '-' + self.fab_name
        file_name = file_name + '_{0:04d}{1:02d}{2:02d}'.format(datetime.date.today().year,
                                                                datetime.date.today().month,
                                                                datetime.date.today().day)
        zip_file_name = file_name + '.zip'
        excel_file_name = file_name + '.xlsx'

        copyfile(self.input_file, os.path.join(file_path, excel_file_name))

        self.create_zipfile(os.path.join(file_path, zip_file_name), os.path.join(file_path, excel_file_name))

        os.remove(os.path.join(file_path, excel_file_name))

        attachment = self.send_mail.create_attach_file(file_path, zip_file_name, 'zip')
        if attachment is not None:
            msg.attach(attachment)

            # 3. JudgeResult_USER-FAB_YYYYMMDD.zip
        # create_zipfile(self, self.output, file_name):
        file_path = os.path.dirname(self.output)

        file_name = 'JudgeResult_' + self.user_name + '-' + self.fab_name
        file_name = file_name + '_{0:04d}{1:02d}{2:02d}'.format(datetime.date.today().year,
                                                                datetime.date.today().month,
                                                                datetime.date.today().day)
        zip_file_name = file_name + '.zip'
        excel_file_name = file_name + '.xlsx'

        copyfile(self.output, os.path.join(file_path, excel_file_name))

        self.create_zipfile(os.path.join(file_path, zip_file_name), os.path.join(file_path, excel_file_name))

        os.remove(os.path.join(file_path, excel_file_name))

        attachment = self.send_mail.create_attach_file(file_path, zip_file_name, 'zip')
        if attachment is not None:
            msg.attach(attachment)

        self.send_mail.send_msg(self.mail_settings["smtp_server"],
                                self.mail_settings["mail_sender_addr"],
                                to_addr,
                                cc_addr,
                                msg)

        ## Update CRAS配信日付
        self.update_cras_excute_date()

        ####################

    def create_zipfile(self, zip_name, file_name):
        arg_str = ' a -p{} {} {}'.format(self.zip_password, zip_name, file_name)
        cmd_str = self.zipexe_path + arg_str
        # print (cmd_str)
        ret = subprocess.call(cmd_str)
        return ret

    def run(self, log_q, log_config):
        """
        CRASデータ出力処理main関数
        :param parser:
        :return:
        """

        # parser.add_argument("-f", type=str, help="define files. This option is required", required=True)
        # parser.add_argument("-user", type=str, help="User Name. This option is required", required=True)
        # parser.add_argument("-fab", type=str, help='FAB Name. This option is required', required=True)
        # parser.add_argument("-crastest", type=str, help='CRAS TEST')
        # command_arguments = parser.parse_args()

        self.log = self.get_logger(log_q, log_config, os.path.join(self.cache_path, self.dbg_file))

        try:
            self.execte_cras()

            if os.path.exists(self.cras_pdf_name):
                self.inf(f'cras done with success {self.request_id}')
                self.io.change_status(self.request_id, 'success',
                                      pdf_path=os.path.abspath(self.cras_pdf_name),
                                      data_path=os.path.abspath(self.input_file),
                                      judge_path=os.path.abspath(self.output),
                                      mail_path=os.path.abspath(self.mail_body_output))
                return

        except Exception as msg:
            self.err(f"cras processing stopped with error {msg}")

        self.inf(f'cras failed {self.request_id}')
        self.io.change_status(self.request_id, 'error')
        return
