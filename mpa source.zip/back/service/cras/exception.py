class CrasException(Exception):
    pass
