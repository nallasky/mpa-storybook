import datetime
import os

import PyPDF2
import pandas as pd
import pdfkit
from PyPDF2 import PdfFileMerger

from service.cras.service_report_graph_cras import CRASReportgraph
from service.cras.service_report_html_cras import CRASReporthtml


class CRASReport:

    def __init__(self, dbg_print):
        self.dbg = dbg_print

    def cras_summary_data_create(self, tool_list, judge_result, err_summary, equipment_df):
        """
        レポート１ページのマトメデータを生成

        :param equipment_df:
            :CRAS DBのequipments Table
        :param judge_result
            :CRAS 判定結果Data Table
        :param err_summary
            :CRAS DBのerror_summary Table

        :return: レポート１ページのマトメデータ PandasのDataFrame
        """
        pdata = pd.DataFrame(columns=['tool_id',
                                      'Abnomal Count',
                                      'A Rank Error',
                                      'B/D Rank Error',
                                      'disp_name'])

        for tool_id in tool_list:
            # Counting abnomal count
            abnomal_cnt = len(judge_result[judge_result['ToolID'] == tool_id])

            # Error Summary count
            err_lst = err_summary[err_summary['tool_id'] == tool_id]

            eq_lst = equipment_df[equipment_df['tool_id'] == tool_id]

            #
            if len(err_lst) == 0:
                err_lst = err_summary[err_summary['inner_tool_id'] == tool_id]

            if len(eq_lst) == 0:
                eq_lst = equipment_df[equipment_df['inner_tool_id'] == tool_id]

            rank_a_cnt = len(err_lst[err_lst['error_rank'] == 'A'])
            rank_b_d_cnt = len(err_lst[err_lst['error_rank'] != 'A'])

            eq_lst.reset_index(inplace=True, drop=True)

            disp_name = eq_lst['tool_id'][0] + '_' + eq_lst['inner_tool_id'][0]

            pdata = pdata.append({"tool_id": tool_id,
                                  "Abnomal Count": abnomal_cnt,
                                  "A Rank Error": rank_a_cnt,
                                  "B/D Rank Error": rank_b_d_cnt,
                                  "disp_name": disp_name}, ignore_index=True)

        return pdata


    def create_cras_report_pdf(self, user_name, fab_name, cras_in_f, judge_result, err_summary,
                               equipment_df, cras_pdf_f, pdf_pass):
        """
        C-RAS 生成のMain

        :param parser:
            :Input Parameter

        :return: None
        """
        tool_list = judge_result['ToolID'].drop_duplicates().sort_values()

        ## NG Data のみ
        judge_result = judge_result[judge_result['Result'] == 'FALSE'].sort_values(by=['CRAS_ID'])
        judge_result = judge_result.sort_values(by=['ToolID'])

        ## CRAS DBの「equipments」Table取得
        # cras_db_if = database_if.DatabaseIF(cras_db_config)
        # equipment_df = cras_db_if.get_data('equipments',
        #                                   'equipment_name, tool_serial, tool_id, inner_tool_id, user_name, fab_name')
        # equipment_df = equipment_df.sort_values(by=['equipment_name'], axis=0)
        # equipment_df = equipment_df[equipment_df['fab_name'] == fab_name]

        ## CRAS Report作成情報設定
        report_date = datetime.date.today() - datetime.timedelta(days=1)
        cras_report_path = os.path.dirname(cras_pdf_f)
        pdf_name = cras_pdf_f
        pdf_pass = pdf_pass

        # 生成したGraph Image, HTMLファイルのリスト保存し、PDF生成後削除する
        graph_image_list = []
        html_list = []

        # Graph, HTML生成Module初期化
        graph = CRASReportgraph()
        html = CRASReporthtml(user_name, fab_name, report_date)

        err_summary.insert(0, 'tool_id', None)
        err_summary.insert(0, 'inner_tool_id', None)

        for i in range(len(err_summary)):
            err_summary.loc[i, 'tool_id'] = err_summary['equipment_name'][i].split('_')[2]
            err_summary.loc[i, 'inner_tool_id'] = err_summary['equipment_name'][i].split('_')[3]

        # CRAS 判定結果データとError Summay DataのDB置からReportの１ページデータ作成
        cras_summary_data = self.cras_summary_data_create(tool_list, judge_result, err_summary, equipment_df)
        # cras_summary_data = cras_summary_data.sort_values(by=['inner_tool_id'])

        # Create Graph [Summary Page]
        graph_image_list.append(os.path.join('summary_graph.png'))
        graph.create_summary_graph(cras_summary_data, graph_image_list[0])

        # Create HTML [Summary Page]
        html_list.append(os.path.join(cras_report_path, 'summary_page.html'))
        html.generate_report_mainpage(cras_summary_data, html_list[0], graph_image_list[0])

        # Create Graph and HTML [SUB Page]
        for row in cras_summary_data.iterrows():
            count_data = row[1]

            self.dbg(f">>>> {count_data['tool_id']}")
            self.dbg(f">>>>      Abnomal Count {count_data['Abnomal Count']}")
            self.dbg(f">>>>      A Rank Error {count_data['A Rank Error']}")
            self.dbg(f">>>>      B/D Rank Error {count_data['B/D Rank Error']}")

            err_cnt = count_data['Abnomal Count']
            err_cnt = err_cnt + count_data['A Rank Error']
            err_cnt = err_cnt + count_data['B/D Rank Error']

            if err_cnt > 0:
                page_idx = len(html_list)

                sub_judge_result = judge_result[judge_result['ToolID'] == count_data['tool_id']]
                sub_judge_result = sub_judge_result.sort_values(by=['CRAS_ID'])
                # sub_err_summary = err_summary[err_summary['inner_tool_id'] == count_data['inner_tool_id']]

                html_list.append(os.path.join(cras_report_path,
                                              'cras_sub_page_{}.html'.format(page_idx)))

                # Graph
                img_start_idx = len(graph_image_list)
                for event_row in sub_judge_result.iterrows():
                    image_idx = len(graph_image_list)
                    event_data = event_row[1]

                    png_file_name = '{}_{}.png'.format(count_data['tool_id'], event_data['Event'])

                    graph_image_list.append(os.path.join(cras_report_path, png_file_name))

                    crasdata = pd.read_excel(cras_in_f,
                                             sheet_name=count_data['tool_id'])

                    err_judge = 'Over'
                    if event_data['Compare'] == 'Under' or event_data['Compare'] == 'AbsUnder':
                        err_judge = 'Under'

                    graph.create_cras_graph(crasdata,
                                            event_data['Event'],
                                            graph_image_list[image_idx],
                                            event_data['Threshold'],
                                            event_data['Condition'],
                                            event_data['Range[day]'],
                                            err_judge)

                    self.dbg(f"   Create Graph {png_file_name}")
                    # time.sleep(0.1)

                # html
                html.generate_report_subpage(count_data['disp_name'],
                                             sub_judge_result,
                                             html_list[page_idx],
                                             graph_image_list,
                                             img_start_idx)

        ## html to pdf
        self.convert_html_to_pdf(html_list, pdf_name, pdf_pass)

        # Delete HTML, Graph Image
        for f_name in enumerate(html_list):
            if os.path.isfile(f_name[1]):
                os.remove(f_name[1])

        for f_name in enumerate(graph_image_list):
            if os.path.isfile(f_name[1]):
                os.remove(f_name[1])

        return pdf_name


    def convert_html_to_pdf(self, html_list, pdf_name, pdf_pass):
        """
        HTML -> PDF

        :param html_list:
            :HTML List
        :param pdf_name:
            :PDF File Name
        :param pdf_pass:
            :PDF File Password

        :return: None
        """

        # 指定できる出力オプション https://wkhtmltopdf.org/usage/wkhtmltopdf.txt
        options = {
            'page-size': 'A4',
            'margin-top': '1.0in',
            'margin-right': '0.5in',
            'margin-bottom': '0.5in',
            'margin-left': '0.5in',
            'encoding': "UTF-8",
            'no-outline': None,
            'disable-smart-shrinking': '',
            'enable-local-file-access': '',
            'dpi': '96',
        }

        # HTML to PDF and PDF File Merge
        merger = PdfFileMerger()

        for f_name in enumerate(html_list):
            pdfkit.from_file(f_name[1], f_name[1] + '.pdf', options=options)
            merger.append(f_name[1] + '.pdf')

        merger.write(pdf_name)
        merger.close()

        # Password
        with open(pdf_name, "rb") as pdf_file:
            output = PyPDF2.PdfFileWriter()
            input_stream = PyPDF2.PdfFileReader(pdf_file)

            for i in range(0, input_stream.getNumPages()):
                output.addPage(input_stream.getPage(i))

            output_stream = open(pdf_name + '.pdf', "wb")

            # Set user and owner password to pdf file
            output.encrypt(pdf_pass, use_128bit=True)
            output.write(output_stream)
            output_stream.close()

        # Delete Temp Files
        for f_name in enumerate(html_list):
            if os.path.isfile(f_name[1] + '.pdf'):
                os.remove(f_name[1] + '.pdf')

        if os.path.isfile(pdf_name):
            os.remove(pdf_name)

        # Rename
        if os.path.isfile(pdf_name + '.pdf'):
            os.rename(pdf_name + '.pdf', pdf_name)
