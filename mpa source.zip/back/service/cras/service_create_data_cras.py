import pandas as pd
import datetime

from dao.dao_base import DAOBaseClass
from collections import OrderedDict


class CRASDataCreate:
    """
    CRASデータ作成クラス
    """

    def __init__(self, cras_tool_data, user_name, fab_name, dbg_print):

        self.user_name = user_name
        self.fab_name = fab_name
        self.dbif = DAOBaseClass()
        self.target = self.target_info(cras_tool_data, user_name, fab_name)
        self.dbg = dbg_print

    def target_info(self, cras_tool_data, user_name, fab_name):
        """
        CRASデータ設定ファイルを読み込む
        :param define_path:
        :return:
        """
        target_list = list()

        for param in cras_tool_data:
            if (param['user_name'] == user_name) and (param['fab_name'] == fab_name):
                target_list.append(param['tool_id'])

        return target_list

    def get_cras_info(self):
        """
        CRASファイル作成用の定義情報をDBから取得する
        :return:
        """
        table_name = 'cras_data_{}_{}'.format(self.user_name.lower(),
                                              self.fab_name.lower())

        # return self.dbif.get_data(table_name)
        return self.dbif.fetch_all(table=table_name)

    def get_equipment_info(self):
        """
        CRASファイル作成対象の装置情報を取得する
        :return:
        """
        # return self.dbif.get_data('equipments')
        return self.dbif.fetch_all(table='equipments')

    def create_db_param_data(self, cras_info, table):
        """
        :return:
        """
        param_by_table = cras_info[cras_info['target_table'] == table]

        param_list = dict()
        special_param_list = dict()
        free_param_list = dict()
        lot_job_param_list = dict()
        where_list = list(param_by_table['where_str'].drop_duplicates().dropna())

        # パラメータと演算種別を取り出す
        for _, elem in param_by_table.iterrows():
            if elem['where_str'] not in where_list:
                where_str = ''
            else:
                where_str = elem['where_str']

            # 単独のデータを使用する統計処理
            # if elem['target_col2'] != elem['target_col2'] and \
            #         elem['group_col'] != elem['group_col'] and \
            if len(elem['target_col2']) == 0 and len(elem['group_col']) == 0 and elem['calc_period_unit'] == 'day':
                ret_str = self.get_operator_str(elem['operations'],
                                                elem['target_col1'],
                                                elem['item_name'])
                if ret_str is not None and ret_str != 'free':  # 対応していない、特殊演算の場合noneになる
                    if where_str in param_list:
                        param_list[where_str].append(ret_str)
                    else:
                        add_list = list()
                        add_list.append(ret_str)
                        param_list[where_str] = add_list

                elif ret_str == 'free':
                    if where_str in free_param_list:
                        free_param_list[where_str].append(elem)
                    else:
                        add_list = list()
                        add_list.append(elem)
                        free_param_list[where_str] = add_list

                else:
                    if where_str in special_param_list:
                        special_param_list[where_str].append(elem)
                    else:
                        add_list = list()
                        add_list.append(elem)
                        special_param_list[where_str] = add_list

            # 複数のデータを使用する統計処理の場合
            # elif elem['group_col'] != elem['group_col'] and \
            #        elem['calc_period_unit'] == 'day':
            elif len(elem['group_col']) == 0 and elem['calc_period_unit'] == 'day':
                ret_str = self.get_multi_operator_str(elem['operations'],
                                                      elem['target_col1'],
                                                      elem['target_col2'],
                                                      elem['item_name'])
                if where_str in param_list:  #
                    param_list[where_str].append(ret_str)
                else:
                    add_list = list()
                    add_list.append(ret_str)
                    param_list[where_str] = add_list

            # ロット単位またはJOB単位の統計処理の場合
            elif elem['calc_period_unit'] == 'lot' or elem['calc_period_unit'] == 'job':
                if where_str in lot_job_param_list:
                    lot_job_param_list[where_str].append(elem)
                else:
                    add_list = list()
                    add_list.append(elem)
                    lot_job_param_list[where_str] = add_list

        return param_list, special_param_list, free_param_list, lot_job_param_list

    def use_inner_tool_id(self):
        """
        equipmentの　inner_tool_idを使用するかtool_idを使用するかを判断
        :return: True - inner_tool_idを使用
                 False - tool_idを使用
        """
        if (self.user_name == 'BSOT'):
            if (self.fab_name == 's1' or self.fab_name == 's2'):
                return True

        if (self.user_name == 'GKC'):
            if (self.fab_name == 'G4'):
                return True

        return False

    def collect_data_by_day(self, cras_info, days=30):
        """
        期間を指定してデータを取得する
        :param cras_info:
        :param target_date:
        :param days
        :return:
        """
        table_list = list(cras_info['target_table'].drop_duplicates())

        ret_df = None
        equipment_df = None

        if self.use_inner_tool_id() is True:
            # equipment_df = self.dbif.get_data('equipments', 'equipment_name, tool_serial, inner_tool_id')
            equipment_df = self.dbif.fetch_all(table='cnvbase.equipments',
                                               args={'select': 'equipment_name, tool_serial, inner_tool_id'})
        else:
            # equipment_df = self.dbif.get_data('equipments', 'equipment_name, tool_serial, tool_id')
            equipment_df = self.dbif.fetch_all(table='cnvbase.equipments',
                                               args={'select': 'equipment_name, tool_serial, tool_id'})

        # table毎にSQLを実行
        df_list = []
        for table in table_list:  # table一覧からtableを一つ取り出す

            param_list, special_param_list, free_param_list, lot_job_param_list = self.create_db_param_data(cras_info,
                                                                                                            table)

            if len(param_list) > 0:
                # DB処理の実行
                for key in param_list.keys():
                    if key == '':
                        where_str = None
                    else:
                        where_str = key
                    sql_dict = self.exec_general_stats(table, param_list[key], days=days, where_add=where_str)
                    if sql_dict is not None and len(sql_dict) > 0:
                        df_list.append(self.db_dict_to_df(sql_dict, cras_info))

            # 特殊演算(slope等)の実施
            if len(special_param_list) > 0:

                for key in special_param_list.keys():
                    if key == '':
                        where_str = None
                    else:
                        where_str = key
                    ret = self.exec_special_operation(pd.DataFrame(special_param_list[key]), days=days,
                                                      where_add=where_str)
                    if len(ret) > 0:
                        df_list.extend(ret)

            if len(free_param_list) > 0:
                for key in free_param_list.keys():
                    if key == '':
                        where_str = None
                    else:
                        where_str = key

                    ret = self.exec_free_calc_sql(table, pd.DataFrame(free_param_list[key]), days=days,
                                                  where_add=where_str)
                    if len(ret) > 0:
                        ret_df = self.db_dict_to_df(ret, cras_info)
                        df_list.append(ret_df)
            # Lot毎集計処理
            if len(lot_job_param_list) > 0:
                for key in lot_job_param_list.keys():
                    if key == '':
                        where_str = None
                    else:
                        where_str = key
                    ret = self.collect_data_lot_job_operation(lot_job_param_list[key], days=days, where_add=where_str)
                    if len(ret) > 0:
                        df_list.extend(ret)
            # print(param_list)
        ret_df = None

        if len(df_list) > 1:
            for idx in range(len(df_list) - 1):
                if ret_df is None:
                    right = df_list[0]
                else:
                    right = ret_df
                left = df_list[idx + 1]

                ret_df = pd.merge(left, right, on=['equipment_name', 'log_day'], how='outer')
        else:
            ret_df = df_list[0]
            # ret_df.to_excel('ret_df.xlsx')

        join_df = pd.merge(ret_df, equipment_df, on='equipment_name')
        # join_df.to_excel('join_df.xlsx')
        df = self.convert_df_col(join_df, cras_info)
        # df.to_excel('c:/rss/inter.xlsx')

        return df

    def create_free_param_list(self, param_df):
        """
        自由形式演算の処理のためのパラメータリスト生成
        :param param_df:
        :return:
        """
        inner_list = list()
        outer_list = list()
        cnt = 0

        # CRASデータ定義から演算パラメータを取得しlistに格納
        for _, elem in param_df.iterrows():
            inner_list.append(elem['target_col1'] + ' AS "free{}"'.format(str(cnt)))
            cals_str = elem['operations'].split('_')[1]
            out_ope = self.get_operator_str(cals_str, "free{}".format(str(cnt)), elem['item_name'])
            outer_list.append(out_ope)
            cnt += 1

        return inner_list, outer_list

    def exec_free_calc_sql(self, table, param_df, days=30, where_add=None):
        """
        計算をフリーフォームで定義する処理を実行する
        :param table:
        :param days:
        :return:
        """
        inner_param, outer_param = self.create_free_param_list(param_df)
        # Inner SQL
        # SELECT句
        day_str = self.get_day_str(table)

        select_str = 'SELECT equipment_name,' + day_str + ',' + ','.join(inner_param) + '\n'
        from_str = 'FROM {}\n'.format(table)

        if where_add is not None:
            inner_from = 'WHERE ' + where_add + '\n'
        else:
            inner_from = ''
        inner_sql = 'FROM (' + select_str + from_str + inner_from + ') AS f\n'

        # Outer SQL

        select_day = "date_trunc('day', {})::date as log_day".format(day_str)  # 年月日時データを年月日日データにする
        outer_select_str = 'SELECT equipment_name,' + select_day + ',' + ','.join(outer_param) + '\n'

        # WHERE 句
        end_day = datetime.date.today()
        start_day = end_day - datetime.timedelta(days=days)
        where_str = "WHERE {0} >= '{1}' AND {0} < '{2}'\n".format(day_str, start_day, end_day)
        # GROUP BY 句
        group_by_str = "GROUP BY equipment_name,date_trunc('day', {})::date \n".format(day_str)
        # ORDER BY 句
        order_by_str = "ORDER BY equipment_name, date_trunc('day', {})::date;".format(day_str)
        # 最終的なSQLの作成
        sql_str = outer_select_str + inner_sql + where_str + group_by_str + order_by_str
        # SQLの実行
        self.dbg(sql_str)
        # return self.dbif.get_data_by_sql_dict(sql_str)
        return self.dbif.execute_by_dict(sql_str)
        # results = self.dbif.execute(sql_str)
        # dict_result = []
        # for row in results:
        #    dict_result.append(dict(row))

        # return dict_result

    def exec_general_stats(self, table, param_list, days=30, where_add=None):
        """
        DBで一般的な統計処理を実行し結果を得る
        :param table:
        :param param_list:
        :param days:
        :param where_add:
        :return:
        """
        # SELECT句
        day_str = self.get_day_str(table)

        select_day = "date_trunc('day', {})::date as log_day".format(day_str)  # 年月日時データを年月日日データにする
        select_str = 'SELECT equipment_name,' + select_day + ',' + ','.join(param_list) + '\n'
        from_str = 'FROM {}\n'.format(table)
        # WHERE 句
        end_day = datetime.date.today()
        start_day = end_day - datetime.timedelta(days=days)
        if where_add is None:
            where_str = "WHERE {0} >= '{1}' AND {0} < '{2}'\n".format(day_str, start_day, end_day)
        else:
            where_str = "WHERE {0} >= '{1}' AND {0} < '{2}' AND {3}\n".format(day_str, start_day, end_day, where_add)
        # GROUP BY 句
        group_by_str = "GROUP BY equipment_name,date_trunc('day', {})::date \n".format(day_str)
        # ORDER BY 句
        order_by_str = "ORDER BY equipment_name, date_trunc('day', {})::date;".format(day_str)
        # 最終的なSQLの作成
        sql_str = select_str + from_str + where_str + group_by_str + order_by_str
        # SQLの実行
        self.dbg(sql_str)
        # return self.dbif.get_data_by_sql_dict(sql_str)
        return self.dbif.execute_by_dict(sql_str)

        # results = self.dbif.execute(sql_str)
        # dict_result = []
        # for row in results:
        #    dict_result.append(row)

        # return dict_result

    def collect_data_lot_job_operation(self, elem, days=30, where_add=None):
        """
        Lot単位でのデータをＤＢで処理する
        :param elem:
        :param days:
        :return:
        """
        info_df = pd.DataFrame(elem)
        lot_day_df = info_df[info_df['calc_period_unit'] == 'lot']
        job_day_df = info_df[info_df['calc_period_unit'] == 'job']
        ret_list = list()
        if len(lot_day_df) > 0:

            ret = self.get_group_day(lot_day_df, 'lot', days=days, where_add=where_add)
            if len(ret) > 0:
                ret_list.extend(ret)

        if len(job_day_df) > 0:

            ret = self.get_group_day(job_day_df, 'job', days=days, where_add=where_add)
            if len(ret) > 0:
                ret_list.extend(ret)

        return ret_list

    def db_dict_to_df(self, input_dict, cras_info):
        """
        DBから取得した辞書形式のデータからDataFrameを作成する
        :param input_dict: 入力データ
        :param cras_info:CRASデータ定義
        :return:
        """
        df_list = []
        # print(cras_info)
        for data in input_dict:
            df_dict = dict()
            # 辞書からキーと値を取得し、型変換を行う
            for key, val in data.items():
                tmp = cras_info[cras_info['item_name'] == key]
                if val is None or val != val or tmp is None or len(tmp) == 0:
                    df_dict[key] = val
                else:  # 型変換を行う
                    col_type = tmp['col_type'].values[0]
                    if col_type == 'integer':
                        df_dict[key] = int(float(val) * float(tmp['coef']))
                    elif col_type == 'float':
                        df_dict[key] = float(val) * float(tmp['coef'])
                    elif col_type == 'time':
                        df_dict[key] = val.isoformat()
                    else:
                        df_dict[key] = val
            # 変換した辞書データを一行ずつlistに格納
            df_list.append(df_dict)
        ret_df = pd.DataFrame(df_list)
        return ret_df

    def convert_df_col(self, input_df, cras_info):
        """
        DataFrameのカラム名をCRAS用に変換する
        :param input_df:
        :param cras_info:
        :return:
        """
        conv_dict = OrderedDict()
        conv_dict['tool_serial'] = 'Serial Number'

        if self.use_inner_tool_id() is True:
            conv_dict['inner_tool_id'] = 'ToolID'
        else:
            conv_dict['tool_id'] = 'ToolID'

        conv_dict['log_day'] = 'Day'
        for _, elem in cras_info.sort_values('cras_index').iterrows():
            conv_dict[elem['item_name']] = elem['item_name']
        retdf = input_df.loc[:, conv_dict.keys()]
        retdf = retdf.rename(columns=conv_dict)
        return retdf

    def get_operator_str(self, calc, col_name, as_name=''):
        """
        定義されている演算をSQLにするための文字列を作成する
        :param calc: 演算
        :param col_name: 演算対象カラム名
        :param as_name: 演算後のカラム名
        :return:
        """
        ope_str = None
        if as_name != '':
            as_str = ' AS "{}" '.format(as_name)
        else:
            as_str = ''

        if calc == 'max' or calc == 'min' or calc == 'stddev' or calc == 'variance':
            ope_str = calc + '(' + col_name + ')' + as_str
        elif calc == 'average':
            ope_str = 'avg({})'.format(col_name) + as_str
        elif calc == 'range':
            ope_str = 'abs(max({0}) - min({0}))'.format(col_name) + as_str
        elif calc == 'absmax':
            ope_str = 'max(abs({}))'.format(col_name) + as_str
        elif calc == 'absmin':
            ope_str = 'min(abs({}))'.format(col_name) + as_str
        elif calc == 'stddevp':
            ope_str = 'stddev_pop({})'.format(col_name) + as_str
        elif calc == 'variancep':
            ope_str = 'var_pop({})'.format(col_name) + as_str

        elif len(calc) >= 4 and calc[:4] == 'free':
            ope_str = 'free'
        elif calc == 'nop':
            ope_str = 'max' + '(' + col_name + ')' + as_str
            # ope_str = '{}'.format(col_name) + as_name
        return ope_str

    def exec_slope_sql(self, cras_info, days=30, where_add=None):
        """
        SLOPE処理のSQLを作成する
        :param cras_info: CRASデータ作成情報
        :param days: 集計期間
        :return:
        """
        # subクエリー作成
        # SELECT句
        df_list = list()
        table_list = list(cras_info['target_table'].drop_duplicates())

        for table in table_list:
            param_by_table = cras_info[cras_info['target_table'] == table]
            param_list_sub_in = list()
            param_list_sub_out = list()
            param_list_main = list()

            day_str = self.get_day_str(table)

            # 指定パラメータ演算を行うためSQL部品を作成
            for _, elem in param_by_table.iterrows():
                # パラメータの取り出し
                param_list_sub_in.append(elem['target_col1'])
                param_list_sub_out.append('t.' + elem['target_col1'])
                param_list_main.append('regr_slope(rnum.{}, rnum.row_number)'.format(elem['target_col1']) \
                                       + ' AS "{}"'.format(elem['item_name']))
            # sub_select_day = "date_trunc('day', {})::date as log_day".format(day_str)
            sub_in_select_str = 'SELECT  equipment_name, {0}, '.format(day_str) + ','.join(param_list_sub_in) + '\n'
            sub_out_select_str = 'SELECT row_number()' + \
                                 'OVER (PARTITION BY t.equipment_name, date_trunc(\'day\',t.{0} )::date '.format(
                                     day_str) + \
                                 'ORDER BY equipment_name, {0} ),  t.equipment_name, t.{0}, '.format(day_str) \
                                 + ', '.join(param_list_sub_out) + '\n'

            sub_from_str = 'FROM {}\n'.format(table)

            # WHERE 句
            end_day = datetime.date.today()
            start_day = end_day - datetime.timedelta(days=days)

            if where_add is not None:
                sub_where_str = \
                    "WHERE {0} >= '{1}' AND {0} < '{2}' ".format(day_str, start_day, end_day)
            else:
                sub_where_str = \
                    "WHERE {0} >= '{1}' AND {0} < '{2}' AND {3}".format(day_str, start_day, end_day, where_add)
            # GROUP BY 句
            # group_by_str = "GROUP BY equipment_name,date_trunc('day', {})::date \n".format(day_str)

            # 最終的なSUB クエリの作成
            inner_sub = sub_in_select_str + sub_from_str + sub_where_str + ") t \n"
            sub_query_str = "(" + sub_out_select_str + "FROM (" + inner_sub + ") rnum"
            main_select_str = "SELECT equipment_name, date_trunc('day', rnum.log_time)::date AS log_day, " + ', '.join(
                param_list_main) + '\n'
            main_from_str = 'FROM {} \n'.format(sub_query_str)

            # GROUP BY 句
            main_group_by_str = "GROUP BY equipment_name, date_trunc('day', {} )::date \n".format(day_str)

            # 最終的なSUB クエリの作成
            main_query_str = main_select_str + \
                             main_from_str + \
                             main_group_by_str + ";"

            print(main_query_str)
            # sql_dict = self.dbif.get_data_by_sql_dict(main_query_str)
            sql_dict = self.dbif.execute_by_dict(main_query_str)

            # results = self.dbif.execute(main_query_str)
            # sql_dict = []
            # for row in results:
            #    sql_dict.append(dict(row))

            if sql_dict is not None and len(sql_dict) > 0:
                df_list.append(self.db_dict_to_df(sql_dict, cras_info))

            return df_list

    def get_eqp_list(self):
        """
        出力する対象の装置一覧を取得する
        :return:
        """
        # eqp_list = list(self.target['ToolID'])
        return self.target

    def exec_special_operation(self, cras_info, days=30, where_add=None):
        """
        Slope等の特殊演算を実行
        :param cras_info:
        :param days:
        :return:
        """
        ret_list = list()
        slope_df = cras_info[cras_info['operations'] == 'slope']
        slope_result = self.exec_slope_sql(slope_df, days=days, where_add=where_add)
        if len(slope_result) > 0:
            ret_list.extend(slope_result)

        return ret_list

    def get_multi_operator_str(self, calc, col_name1, col_name2, as_name=''):
        """
        定義されている演算をSQLにするための文字列を作成する
        :param calc: 演算
        :param col_name1: 演算対象カラム名1
        :param col_name2: 演算対象カラム名2
        :param as_name: 演算後のカラム名
        :return:
        """
        ope_str = None
        if as_name != '':
            as_str = ' AS "{}" '.format(as_name)
        else:
            as_str = ''

        if calc == 'corr':
            ope_str = 'corr(' + col_name2 + ',' + col_name1 + ')' + as_str
        else:
            return None

        return ope_str

    def get_group_day(self, cras_info, group, days=30, where_add=None):
        """
        指定グループ毎に集計後に日単位で演算する処理
        :param cras_info: 定義ファイル
        :param group: 集計するグループ種別
        :param days: 出力期間
        :return:
        """

        df_list = list()
        if group == 'lot':
            group_str = 'lot'
            if where_add is None:
                null_str = 'lot_id IS NOT NULL'
            else:
                null_str = 'lot_id IS NOT NULL AND {}'.format(where_add)
        elif group == 'job':
            group_str = 'device, process'
            if where_add is None:
                null_str = 'device IS NOT NULL AND process IS NOT NULL '
            else:
                null_str = 'device IS NOT NULL AND process IS NOT NULL '.format(where_add)
        else:
            return df_list

        # subクエリー作成
        # SELECT句

        table_list = list(cras_info['target_table'].drop_duplicates())
        for table in table_list:
            day_str = self.get_day_str(table)

            param_by_table = cras_info[cras_info['target_table'] == table]
            param_list_sub = list()
            param_list_main = list()
            # special_param_list = list()
            # パラメータと演算種別を取り出し、SELECT句を作成

            cnt = 0

            # 指定パラメータ演算を行うためSQL部品を作成
            for _, elem in param_by_table.iterrows():

                operation1 = elem['operations'].split('_')[0]  # 最初の演算
                operation2 = elem['operations'].split('_')[1]  # 一日毎の演算
                tmp_col = 'tmp_col' + str(cnt)
                ret = self.get_operator_str(operation1,
                                            elem['target_col1'],
                                            tmp_col)
                if ret is not None:
                    param_list_sub.append(ret)
                ret = self.get_operator_str(operation2,
                                            tmp_col,
                                            elem['item_name'])
                if ret is not None:
                    param_list_main.append(ret)
                cnt += 1

            if len(param_list_sub) > 0:
                sub_select_day = "date_trunc('day', {})::date as log_day".format(day_str)
                sub_select_str = 'SELECT equipment_name,' + sub_select_day + ',' + ','.join(param_list_sub) + '\n'
                sub_from_str = 'FROM {}\n'.format(table)

                # WHERE 句
                end_day = datetime.date.today()
                start_day = end_day - datetime.timedelta(days=days)
                sub_where_str = \
                    "WHERE {0} >= '{1}' AND " \
                    "{0} < '{2}' AND " \
                    " {3} \n".format(day_str, start_day, end_day, null_str)

                # GROUP BY 句
                group_by_str = "GROUP BY equipment_name,date_trunc('day', {0})::date, {1} \n".format(day_str, group_str)
                # 最終的なSUB クエリの作成
                sub_query_str = sub_select_str + sub_from_str + sub_where_str + group_by_str
                if len(param_list_main) > 0:
                    main_select_str = 'SELECT equipment_name, log_day, ' + ', '.join(param_list_main) + '\n'
                    main_from_str = 'FROM ({}) AS BY_LOT\n'.format(sub_query_str)

                    # GROUP BY 句
                    main_group_by_str = "GROUP BY equipment_name, log_day \n".format(day_str)
                    # ORDER BY 句
                    main_order_by_str = "ORDER BY equipment_name, log_day;".format(day_str)
                    # 最終的なSUB クエリの作成
                    main_query_str = main_select_str + \
                                     main_from_str + \
                                     main_group_by_str + \
                                     main_order_by_str
                    self.dbg(main_query_str)

                    # sql_dict = self.dbif.get_data_by_sql_dict(main_query_str)
                    # results = self.dbif.execute(main_query_str)
                    # sql_dict = []
                    # for row in results:
                    #    sql_dict.append(dict(row))
                    sql_dict = self.dbif.execute_by_dict(main_query_str)

                    if sql_dict is not None and len(sql_dict) > 0:
                        df_list.append(self.db_dict_to_df(sql_dict, cras_info))

            return df_list

    def get_calc_single_data_by_day(self, table, calc, col, start_date, end_date):
        """
        日単位のデータ集計を実行する
        :param table: テーブル名
        :param calc: 集計処理
        :param col: 集計対象カラム名
        :param start_date: 集計開始日時
        :param end_date: 集計終了日時
        :return:
        """
        ope_str = self.get_operator_str(calc, col)

        if ope_str is None:
            return None
        day_str = self.get_day_str(table)

        sql = "SELECT equipment_name, \
                {0} \
                FROM  {1} \
                WHERE {2} >= '{3}' AND {2} < '{4} '\
                GROUP BY equipment_name;".format(ope_str, table, day_str, start_date, end_date)
        self.dbg(sql)
        # try:
        # ret = self.dbif.execute_sql(sql)
        ret = self.dbif.execute(sql)
        return ret
        # except:
        #    print('DB Exception')
        #    return None

    def get_calc_double_data_by_day(self, table, calc, col1, col2, start_date, end_date, as_name=''):
        """
        日単位の複数データ集計を実行する
        :param table: テーブル名
        :param calc: 集計処理
        :param col1: 集計対象カラム名
        :param col2: 集計対象カラム名
        :param start_date: 集計開始日時
        :param end_date: 集計終了日時
        :param as_name: 演算後のカラム名
        :return:
        """

        if as_name != '':
            as_str = ' AS "{}" '.format(as_name)
        else:
            as_str = ''

        if calc == 'corr':
            ope_str = 'corr(' + col2 + ',' + col1 + ')' + as_str
        else:
            return None
        day_str = self.get_day_str(table)

        sql = "SELECT equipment_name, \
                {0} \
                FROM  {1} \
                WHERE {2} >= '{3}' AND {2} < '{4}'\
                GROUP BY equipment_name;".format(ope_str, table, day_str, start_date, end_date)
        # print(sql)
        # try:
        # ret = self.dbif.execute_sql(sql)
        ret = self.dbif.execute(sql)
        return ret
        # except:
        #    print('DB Exception')
        #    return None

    def get_day_str(self, table):
        """
        集計単位の取得
        """
        _table = table.split('.')
        if len(_table) == 2:
            table = _table[1]

        if table == 'running_rate' or table == 'error_summary':
            day_str = 'log_date'
        elif table == 'status_monitor_analysis':
            day_str = 'start_time'
        elif table == 'arcnetlog_analysis_data':
            day_str = 'time_start'
        elif table == 'arcnetlog_analysis_async':
            day_str = 'time'
        else:
            day_str = 'log_time'
        return day_str
