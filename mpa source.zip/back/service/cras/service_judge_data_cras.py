import sys
import os
import datetime
from jinja2 import Template
import pandas as pd
import numpy as np

from dao.dao_base import DAOBaseClass
from service.cras.service_mail_html_cras import BASE_HTML


class CCrasJudge:
    """
    CRAS Judge
    """
    def __init__(self, input_file, user_name, fab_name, dbg_print):
        self.input_file = input_file
        self.user_name = user_name
        self.fab_name = fab_name
        self.dbg = dbg_print

    def read_cras_rule(self, mpa_name='master'):
        #dbif = database_if.DatabaseIF(cras_db_info)
        dbif = DAOBaseClass()

        # sql = 'SELECT cras_crasdefine.* , cras_inputdata.item_name FROM cras_crasdefine \
        #       INNER JOIN cras_inputdata \
        #       ON cras_crasdefine.cras_item_id = cras_inputdata.id;'
        #
        # cras_rule = dbif.get_data_by_sql(sql)

        cras_rule_table_name = 'cras_item_{}_{}_{}'.format(self.user_name.lower(),
                                                           self.fab_name.lower(),
                                                           mpa_name.lower())

        self.dbg(f"CRAS RULE TABLE : {cras_rule_table_name}")

        #cras_rule = dbif.get_data(cras_rule_table_name)
        cras_rule = dbif.fetch_all(table=cras_rule_table_name)
        cras_rule = cras_rule[cras_rule['enable'] == True]

        return cras_rule


    def create_cras_judge_data(self, rast_date, start_date):
        """
        CRASの判定を実行し結果を作成する
        :param input_file:CRAS入力データファイル名
        :param cras_rule:CRAS判定ルール
        :return:結果一覧DataFrame
        """
        bk = pd.ExcelFile(self.input_file)
        sheet_list = bk.sheet_names
        cras_rule = self.read_cras_rule()

        # ToDo
        # 最終実行時間はDBで管理したい
        # データが入っていない場合の処理は考慮が必要
        output_list = list()

        for sheet in sheet_list:
            input_df = pd.read_excel(self.input_file, sheet_name=sheet)
            input_df['Day'] = input_df['Day'].str.replace('/', '-').apply(datetime.date.fromisoformat)

            self.dbg(f"Tool ID : {sheet}")

            for _, rule in cras_rule.iterrows():
                calc_range = rule['calc_range']
                for dd in range((rast_date - start_date).days +1):
                    exec_date = start_date + datetime.timedelta(days=dd)

                    item = rule['item_name']
                    calc_range = rule['calc_range'] - 1
                    comp = rule['compare']
                    threshold = rule['threshold']
                    exec_end = exec_date - datetime.timedelta(days=calc_range)

                    # data = input_df[input_df['Day'] >= exec_end & input_df['Day'] <= exec_date].set_index('Day')
                    data = input_df.query('@exec_end  <= Day <= @exec_date').set_index('Day')

                    if item in data.columns:
                        cras_info = dict()
                        cras_info['Date'] = exec_date.strftime('%Y/%m/%d')
                        cras_info['ToolID'] = sheet
                        cras_info['CRAS_ID'] = rule['cras_id']
                        ret = self.judge_data(data.loc[:, [item]], rule)
                        cras_info.update(ret)
                        output_list.append(cras_info)

        result_df = pd.DataFrame(output_list).sort_values(['Date', 'ToolID', 'CRAS_ID'], ascending=[False, True, True])

        return result_df

    def judge_data(self, input_data, rule):
        """
        CRAS入力に演算処理を行い判定処理を実行する
        :param input_data: CRAS入力データ
        :param rule: 判定ルール
        :return:
        """
        ret_data = {'Title': rule['title'],
                    'Event': rule['item_name'],
                    'Range[day]': rule['calc_range'],
                    'Condition': rule['condition'],
                    'Compare': rule['compare'],
                    'Threshold': rule['threshold']
                    }

        if len(input_data) == 0:
            ret_data['Value'] = 0
            ret_data['Cras Data Exist'] = 'Empty'
            ret_data['Result'] = 'TRUE'
            return ret_data

        if rule['calc_range'] == 1:  # 判定範囲が1日の場合
            # データが一つの場合、演算の種類によらず処理は同じ
            value = input_data[rule['item_name']].values[0]
            if value != value:
                ret_data['Value'] = 0
                ret_data['Cras Data Exist'] = 'Empty'
                ret_data['Result'] = 'TRUE'
                return ret_data

            ret_data['Value'] = value
            ret_data['Cras Data Exist'] = 'Exist'
            ret_data['Result'] = self.check_threshold(rule['threshold'], rule['compare'], value)

        else:  # 判定範囲が複数日の場合
            input_data = input_data.reset_index()
            input_data_nona = input_data.dropna()

            if input_data[rule['item_name']][0] != input_data[rule['item_name']][0] or len(input_data_nona) == 0:
                ret_data['Value'] = 0
                ret_data['Cras Data Exist'] = 'Empty'
                ret_data['Result'] = 'TRUE'
                return ret_data

            if rule['condition'] == 'Sum':  # 合計処理
                data = np.array(input_data_nona[rule['item_name']])
                value = np.sum(data)

            elif rule['condition'] == 'Ave.':  # 平均処理
                data = np.array(input_data_nona[rule['item_name']])
                value = np.average(data)

            elif rule['condition'] == 'Diff.':  # 過去の平均との差分
                data = np.array(input_data_nona[rule['item_name']])
                value = data[0] - np.average(data)

            elif rule['condition'] == 'Rate':  # 過去の平均との変化
                data = np.array(input_data_nona[rule['item_name']])
                data_ave = np.average(data)

                if data_ave == 0.0 or data[0] == 0:
                    value = 0
                else:
                    value = 100.0 - (data[0] / data_ave) * 100

            elif rule['condition'] == 'Range':  # データの範囲
                data = np.array(input_data_nona[rule['item_name']])
                value = np.abs(np.max(data) - np.min(data))

            elif rule['condition'] == 'Coef.':  # 一次近似の傾き(Slope)
                data = np.array(input_data_nona[rule['item_name']])
                x = input_data_nona.index.values

                if len(x) <= 1:
                    ret_data['Value'] = 0
                    ret_data['Cras Data Exist'] = 'Empty'
                    return ret_data
                else:
                    a, b = np.polyfit(x, data, 1)
                    value = a

            else:
                ret_data['Value'] = 0
                ret_data['Cras Data Exist'] = 'Empty'
                return ret_data

            ret_data['Value'] = value
            ret_data['Cras Data Exist'] = 'Exist'
            ret_data['Result'] = self.check_threshold(rule['threshold'], rule['compare'], value)

        if ret_data['Value'] != ret_data['Value']:
            self.dbg(ret_data)

        return ret_data

    def check_threshold(self, threshold, comp, value):
        """
        CRAS入力データの閾値判定を行う
        :param threshold: 閾値
        :param comp: 判定方法
        :param value: 値
        :return: 判定結果
        """

        if comp == 'Over':  # 閾値以上か
            if value > threshold:
                return 'FALSE'
            else:
                return 'TRUE'

        elif comp == 'Under':  # 閾値以下か
            if value < threshold:
                return 'FALSE'
            else:
                return 'TRUE'

        elif comp == 'AbsOver':  # 入力値の絶対値が閾値以上か
            if np.abs(value) > threshold:
                return 'FALSE'
            else:
                return 'TRUE'

        elif comp == 'AbsUnder':  # 入力値の絶対値が閾値以下か
            if np.abs(value) < threshold:
                return 'FALSE'
            else:
                return 'TRUE'

        return 'FALSE'


def create_abnormal_report_html(result_data, err_summary, equipment_df, report_header, report_tail):
    """
    """
    table_html = '''
<table class="gs_none" style="width:980px;">
<tr>
    <td class="gs_body" colspan="100" style="border:1px solid #02439f;">
        <table class="gs_none" style="width:100%;">
            <tr>
                <td class="gs_header" colspan="96" style="border:5px solid #02439f;">{{ report_header }}</td>
            </tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
        </table>
        {% for tool, tool_list in render_data.items(): %}
        <table class="gs_none" style="width:100%;">
            <tr>
                <td class="gs_bar1" colspan="96"><font class="gs_barmark">&#x25C6; </font> {{ tool }}</td>
            </tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
        </table>            
            {% for day, day_list in tool_list.items(): %}
        <table class="gs_none" style="width:100%;">
            <tr>
                <td class="gs_none" colspan="96" style="text-align:right;"><B>[{{ day }}]</B></td>
            </tr>
            <tr><td class="gs_none" colspan="96"><hr></td></tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
            <tr>
                <td class="gs_none" colspan="96"><B>&#x25C7; Abnormal Detection</B></td>
            </tr>
            <tr>
                <td class="gs_none" colspan="96">
                    <table class="gs_none" style="width:100%;">
                        {% if (day_list['abnormal_records']|length) > 0: %}
                        <thead>
                            <tr>                               
                                <th scope="col" style="border:1px solid #02439f;">State</th>
                                <th scope="col" style="border:1px solid #02439f;">Item Name</th>
                                <th scope="col" style="border:1px solid #02439f;">Threshold</th>
                                <th scope="col" style="border:1px solid #02439f;">Compare</th>
                                <th scope="col" style="border:1px solid #02439f;">Value</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for record in day_list['abnormal_records']: %}
                            <tr>
                                <td style="text-align:center; width:10%; border:1px solid #02439f;">{{ record[0] }}</td>
                                <td style="border:1px solid #02439f;">{{ record[1] }}</td>
                                <td style="text-align:center; width:10%; border:1px solid #02439f;">{{ record[2] }}</td>
                                <td style="text-align:center; width:10%; border:1px solid #02439f;">{{ record[3] }}</td>
                                <td style="text-align:center; width:10%; border:1px solid #02439f;">{{ record[4] }}</td>
                            </tr>
                            {% endfor %}
                        </tbody>
                        {% else :%}
                        <tr><td class="gs_none" colspan="96">-None-</td></tr>
                        {% endif %}
                    </table>

                </td>
            </tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
            <tr>
                <td class="gs_none" colspan="96"><B>&#x25C7; Error List</B></td>
            </tr>
            <tr>
                <td class="gs_none" colspan="96">
                    <table class="gs_none" style="width:100%;">
                        {% if (day_list['err_records']|length) > 0: %}
                        <thead>
                            <tr>
                                <th scope="col" style="border:1px solid #02439f;">Error No.</th>
                                <th scope="col" style="border:1px solid #02439f;">Error Name</th>
                                <th scope="col" style="border:1px solid #02439f;">Error Rank</th>
                                <th scope="col" style="border:1px solid #02439f;">Elapsed</th>
                                <th scope="col" style="border:1px solid #02439f;">Count</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for record in day_list['err_records']: %}
                            <tr>
                                <td style="text-align:center; width:10%; border:1px solid #02439f;">{{ record[0] }}</td>
                                <td style="border:1px solid #02439f;">{{ record[1] }}</td>
                                <td style="text-align:center; width:10%; border:1px solid #02439f;">{{ record[2] }}</td>
                                <td style="text-align:center; width:10%; border:1px solid #02439f;">{{ record[3] }}</td>
                                <td style="text-align:center; width:10%; border:1px solid #02439f;">{{ record[4] }}</td>
                            </tr>
                            {% endfor %}
                        </tbody>
                        {% else :%}
                        <tr><td class="gs_none" colspan="96">-None-</td></tr>
                        {% endif %}
                    </table>
                </td>
            </tr>
            <tr><td class="gs_none" colspan="96">&nbsp;<br>&nbsp;<br>&nbsp;</td></tr>
        </table>
            {% endfor %}    
        {% endfor %}
        <table class="gs_none" style="width:100%;">
            <tr><td class="gs_none" colspan="96"><hr></td></tr>
            <tr>
                <td class="gs_tail" colspan="96">{{ report_tail }}</td>
            </tr>
            <tr><td class="gs_none" colspan="96"><hr></td></tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
        </table>
    </td>
</tr>
<tr>
    <td class="gs_none" colspan="100" style="text-align:right;">Canon Remote Alarm System Version 2.0</td>
</tr>
</table>
'''
    tool_list = result_data['ToolID'].drop_duplicates().sort_values()
    day_list = result_data['Date'].drop_duplicates().sort_values()
    ng_data = result_data[result_data['Result'] == 'FALSE']

    render_data = dict()

    for tool in tool_list:
        data_dict = dict()
        for day in day_list:
            equipment = equipment_df[(equipment_df['tool_id'] == tool) | (equipment_df['inner_tool_id'] == tool)]

            equipment_name = equipment['equipment_name']
            inner_tool_id = equipment['inner_tool_id']
            tool_id = equipment['tool_id']

            abnormal_list = list()
            error_list = list()

            odata = ng_data[(ng_data['ToolID'] == tool) & (ng_data['Date'] == day)]
            odata = odata.sort_values(by='CRAS_ID')
            # print(odata)

            # Abnormal Data List
            for _, elem in odata.iterrows():
                state = ''

                if elem['State'] == 1:
                    state = 'New'
                else:
                    state = 'Cont {}'.format(elem['State'])

                abnormal_list.append([state, elem['Event'], str(elem['Threshold']), elem['Compare'], str(format(elem['Value'], '.3f'))])

            # Error Log List
            if len(equipment_name) >= 1:
                err_list = err_summary[(err_summary['equipment_name'] == equipment_name.values[0]) & (err_summary['log_date'] == day)]

                for _, elem in err_list.iterrows():
                    m, s = divmod(elem['elapsed'].total_seconds(), 60)
                    h, m = divmod(m, 60)
                    elapsed_time = '{0:02d}:{1:02d}:{2:02d}'.format(int(h) ,int(m) ,int(s))
                    error_list.append \
                        ([elem['error_no'], elem['error_name'], elem['error_rank'], elapsed_time, elem['count']])

                tool = tool_id.values[0] + '_' + inner_tool_id.values[0]

            data_dict[day] = {'abnormal_records': abnormal_list, 'err_records': error_list}

        render_data[tool] = data_dict

    ## Table Data Create
    table_data = {'render_data': render_data, 'report_header' :report_header, 'report_tail' :report_tail}
    table_template = Template(table_html)
    output_table_html = table_template.render(table_data)

    ## HTML Data Create
    data = {'table_data': output_table_html}
    template = Template(BASE_HTML)
    output_html = template.render(data)

    # print(os.path.abspath(os.getcwd())+"/test.html")
    # with open(os.path.abspath(os.getcwd())+"/test.html", "w") as f:
    #    # すべての内容を書き込む
    #    f.write(output_html)

    # print(output_html)

    return output_html


class CCrasAbnormalReport:
    """
    Create CRAS Abnormal Report
    """
    def __init__(self):
        pass

