import sys
import os
import smtplib
import socket

from email.mime.text import MIMEText
from email.utils import formatdate
from email.mime.multipart import MIMEMultipart
from email import encoders
from email.mime.base import MIMEBase

class CrasSendMail:
    def create_html_message(self, from_addr, to_addr, subject, body, attach_file=None, cc_addr=None):
        """
        送信メッセージを作成する
        """
        msg = MIMEMultipart()
        msg["Subject"] = subject
        msg["From"] = from_addr
        msg["To"] = to_addr  # .replace(',', ', ')
        if cc_addr is not None:
            msg["Cc"] = cc_addr
        msg['Date'] = formatdate()

        # メール本文
        body = MIMEText(body, "html")
        msg.attach(body)

        """
        # file Attach
        if attach_file is not None:
            attachment = MIMEBase('application', 'pdf')
    
            file = open(attach_file['path'],'rb')
            attachment.set_payload(file.read())
            file.close()
    
            encoders.encode_base64(attachment)
            attachment.add_header("Content-Disposition", "attachment", filename=attach_file['name'])
    
            msg.attach(attachment)
        """

        return msg


    def create_message(self, from_addr, to_addr, subject, body, attach_file=None, cc_addr=None):
        """
        送信メッセージを作成する
        """
        msg = MIMEMultipart()
        msg["Subject"] = subject
        msg["From"] = from_addr
        msg["To"] = to_addr  # .replace(',', ', ')
        if cc_addr is not None:
            msg["Cc"] = cc_addr
        msg['Date'] = formatdate()

        # メール本文
        body = MIMEText(body)
        msg.attach(body)

        return msg


    def create_subject(self, user, acq_period):
        """
        Subjectを作成する
        :param user:ユーザー名
        :paramacq_period : サマリーの期間
        :return:
        """
        subject_ = '【C-RAS】【Error Summary】{} ({})'.format(user, acq_period)
        return subject_


    def send_msg(self, smtp_server, from_addr, to_addr, cc_addr, msg):
        """
        メッセージを送信する
        :param smtp_server: SMTPサーバー
        :param from_addr: fromアドレス
        :param to_addr: toアドレス
        :param cc_addr: ccアドレス
        :param msg: メッセージ
        :return:
        """
        print("# Send Mail Start")
        print("# SMTP Server Addr. :", smtp_server)
        # print(msg.as_string())

        smtp = smtplib.SMTP(smtp_server)
        # smtp.set_debuglevel(1)

        print('# HOST NAME : ', socket.gethostname())
        print('# IP ADDRESS : ', socket.gethostbyname(socket.getfqdn()))

        # sendToList = to_addr.split(',') + cc_addr.split(',')

        try:
            # smtp.sendmail(from_addr, sendToList, msg.as_string())
            smtp.send_message(msg)
        except Exception as errmsg:
            print("## send_message error")
            print(errmsg)
            smtp.close()
            sys.exit(1)

        print("# Send Mail End")

        smtp.close()


    def make_addr_list(self, user_info):
        """
        to_addr, cc_addrを生成
        メールを送信する
        :param parser:
        :return:
        """

        to_addr = ""
        cc_addr = ""
        """
        for _, elem in user_info.iterrows():
            mail_addr = elem['description']
            to_addr += '<' + mail_addr + '>, '
    
        """

        to_addr = user_info.replace(',', ', ')

        # print(to_addr)

        return to_addr, cc_addr


    def send_html_main(self, msg, user_info, server_info, subject, attach_file=None):
        """
        Main処理
        メールを送信する
        :param parser:
        :return:
        """
        to_addr, cc_addr = self.make_addr_list(user_info)

        # Mail設定の読み込み

        # for row in ses_mail_addr.iterrows():
        #    mail = row[1]
        #    if (mail['user_name'] == user_name) and (mail['fab_name'] == fab_name):
        #        if mail['send_type'] == 'TO':
        #            to_addr = to_addr +  mail['mail_addr'] + ','
        #        elif  mail['send_type'] == 'CC':
        #            cc_addr = cc_addr +  mail['mail_addr'] + ','

        # Mimeタイプの作成
        # mime = {'type': 'application', 'subtype': 'zip'}

        msg = self.create_html_message(server_info["mail_sender_addr"],
                                  to_addr,
                                  subject,
                                  msg,
                                  attach_file=attach_file,
                                  cc_addr=cc_addr)

        print("# create_message end")

        self.send_msg(server_info["smtp_server"],
                 server_info["mail_sender_addr"],
                 to_addr,
                 cc_addr,
                 msg)


    def send_main(self, msg, user_info, server_info, subject):
        """
        Main処理
        メールを送信する
        :param parser:
        :return:
        """
        to_addr, cc_addr = make_addr_list(user_info)

        # Mail設定の読み込み

        # for row in ses_mail_addr.iterrows():
        #    mail = row[1]
        #    if (mail['user_name'] == user_name) and (mail['fab_name'] == fab_name):
        #        if mail['send_type'] == 'TO':
        #            to_addr = to_addr +  mail['mail_addr'] + ','
        #        elif  mail['send_type'] == 'CC':
        #            cc_addr = cc_addr +  mail['mail_addr'] + ','

        # Mimeタイプの作成
        # mime = {'type': 'application', 'subtype': 'zip'}

        msg = self.create_message(server_info["mail_sender_addr"],
                             to_addr,
                             subject,
                             msg)

        print("# create_message end")

        self.send_msg(server_info["smtp_server"],
                 server_info["mail_sender_addr"],
                 to_addr,
                 cc_addr,
                 msg)


    def create_attach_file(self, file_path, file_name, file_type):
        """
        """
        if os.path.exists(os.path.join(file_path, file_name)):
            attachment = MIMEBase('application', file_type)

            file = open(os.path.join(file_path, file_name), 'rb')
            attachment.set_payload(file.read())
            file.close()

            encoders.encode_base64(attachment)
            attachment.add_header("Content-Disposition", "attachment", filename=file_name)

            return attachment

        return None
