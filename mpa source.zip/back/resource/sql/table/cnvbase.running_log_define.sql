create table cnvbase.running_log_define
(
    parameter_name text,
    db_column      text,
    pattern        text,
    group_pattern  integer,
    data_type      varchar(15)
);