create table convert.each_shot_illumination_auto_adjust_monitor
(
    equipment_name      text      not null,
    device              text,
    process             text,
    plate               integer,
    step                integer,
    dose_value          double precision,
    expo_speed          integer,
    target_illumination integer,
    actual_illumination integer,
    lamp_power_l        integer,
    lamp_power_c        integer,
    lamp_power_r        integer,
    adjust_mode         text,
    glass_id            text,
    lot_id              text,
    chuck               text,
    log_time            timestamp not null,
    log_idx             integer   not null,
    created_time           timestamp not null,
	request_id              varchar(50),
    constraint each_shot_illumination_auto_adjust_monitor_pkey
        primary key (equipment_name, log_time, log_idx)
);
