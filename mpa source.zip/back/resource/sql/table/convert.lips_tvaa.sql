create table convert.lips_tvaa
(
    equipment_name     text         not null,
    glass_id           text,
    lot_id             text,
    point              integer,
    tv_measurement_xl  integer,
    tv_measurement_yl  integer,
    tv_measurement_xr  integer,
    tv_measurement_yr  integer,
    stage_position_psx integer,
    stage_position_psy integer,
    stage_position_msy integer,
    status             integer,
    x_shift            integer,
    log_time           timestamp(6) not null,
    log_idx            integer      not null,
    created_time           timestamp not null,
	request_id              varchar(50),
    constraint lips_tvaa_pkey
        primary key (equipment_name, log_time, log_idx)
);

