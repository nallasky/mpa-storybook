create table convert.running_event
(
    equipment_name text      not null,
    log_time       timestamp not null,
    message1       text,
    message2       text,
    message3       text,
    log_idx        integer   not null,
	created_time           timestamp not null,
	request_id              varchar(50),
    constraint running_event_pkey
        primary key (equipment_name, log_time, log_idx)
);

