create table convert.static_electricity_monitor3
(
    equipment_name text      not null,
    device         text,
    process        text,
    plate          integer,
    step           integer,
    glass_id       text,
    lot_id         text,
    input_voltage  integer,
    liftup_voltage integer,
    output_voltage integer,
    log_time       timestamp not null,
    log_idx        integer   not null,
    chuck          text,
	created_time           timestamp not null,
	request_id              varchar(50),
    constraint static_electricity_monitor3_pkey
        primary key (equipment_name, log_time, log_idx)
);

