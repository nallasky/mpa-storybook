create table cnvset.cras_job
(
    id      varchar(50)                                   not null constraint cras_job_pk primary key,
    site    varchar(15)                                   not null,
    fab     varchar(15)                                   not null,
    created timestamp      default now()                  not null,
    status  request_status default 'idle'::request_status not null,
    pdf_path text,
    data_path text,
    judge_path text,
    mail_path text
);