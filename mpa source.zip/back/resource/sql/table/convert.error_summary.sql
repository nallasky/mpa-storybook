create table convert.error_summary
(
    equipment_name text       not null,
    log_date       date       not null,
    error_no       varchar(7) not null,
    error_name     text,
    elapsed        time default '00:00:00'::time without time zone,
    error_rank     varchar(1),
    error_count    integer,
    error_category varchar(20),
    constraint error_summary_pkey   primary key (equipment_name, log_date, error_no)
);