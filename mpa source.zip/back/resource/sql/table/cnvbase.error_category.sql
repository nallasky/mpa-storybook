create table cnvbase.error_category
(
    unit_no       varchar(1),
    category_no   varchar(1),
    category_name varchar(15)
);