create table convert.mask_bend_monitor3
(
    equipment_name text      not null,
    device         text,
    process        text,
    plate          integer,
    step           integer,
    glass_id       text,
    lot_id         text,
    status         text,
    msy_pos        integer,
    bend_l         integer,
    bend_c         integer,
    bend_r         integer,
    bend_diff_ave  integer,
    bend_diff_lr   integer,
    bend_diff      integer,
    pressure       integer,
    log_time       timestamp not null,
    log_idx        integer   not null,
    chuck          text,
    created_time           timestamp not null,
	request_id              varchar(50),
    constraint mask_bend_monitor3_pkey
        primary key (equipment_name, log_time, log_idx)
);

