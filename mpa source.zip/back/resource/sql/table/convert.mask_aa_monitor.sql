create table convert.mask_aa_monitor
(
    equipment_name     text      not null,
    device             text,
    process            text,
    glass_id           text,
    lot_id             text,
    xl                 integer,
    yl                 integer,
    xr                 integer,
    yr                 integer,
    x                  integer,
    y                  integer,
    theta              integer,
    measurement_number integer,
    log_time           timestamp not null,
    log_idx            integer   not null,
    created_time           timestamp not null,
	request_id              varchar(50),
    constraint mask_aa_monitor_pkey
        primary key (equipment_name, log_time, log_idx)
);

