create table convert.version_info
(
    equipment_name text not null,
    log_time       date not null,
    unit           text not null,
    version        text,
    created_time   timestamp not null,
    request_id     varchar(50),
    constraint version_info_pkey
        primary key (equipment_name, log_time, unit)
);