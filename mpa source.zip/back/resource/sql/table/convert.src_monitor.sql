create table convert.src_monitor
(
    equipment_name text      not null,
    device         text,
    process        text,
    plate          integer,
    l_xl           integer,
    l_yl           integer,
    r_xr           integer,
    r_yr           integer,
    lx_pos         integer,
    ly_pos         integer,
    rx_pos         integer,
    ry_pos         integer,
    m_xr           integer,
    m_yr           integer,
    dr_comp        integer,
    mr             integer,
    mask_temp      double precision,
    mx             integer,
    my             integer,
    mark_span_x    integer,
    mark_span_y    integer,
    glass_id       text,
    lot_id         text,
    chuck          text,
    log_time       timestamp not null,
    log_idx        integer   not null,
	created_time           timestamp not null,
	request_id              varchar(50),
    constraint src_monitor_pkey
        primary key (equipment_name, log_time, log_idx)
);

