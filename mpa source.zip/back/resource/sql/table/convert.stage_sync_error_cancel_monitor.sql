create table convert.stage_sync_error_cancel_monitor
(
    equipment_name           text      not null,
    glass_id                 text,
    lot_id                   text,
    plate                    integer,
    step                     integer,
    position                 text,
    tv_meas_xl_before_cancel integer,
    tv_meas_yl_before_cancel integer,
    tv_meas_xr_before_cancel integer,
    tv_meas_yr_before_cancel integer,
    sync_err_ave_x           integer,
    sync_err_ave_y           integer,
    sync_err_ave_t           integer,
    tv_meas_xl_after_cancel  integer,
    tv_meas_yl_after_cancel  integer,
    tv_meas_xr_after_cancel  integer,
    tv_meas_yr_after_cancel  integer,
    log_time                 timestamp not null,
    log_idx                  integer   not null,
	created_time           timestamp not null,
	request_id              varchar(50),
    constraint stage_sync_error_cancel_monitor_pkey
        primary key (equipment_name, log_time, log_idx)
);