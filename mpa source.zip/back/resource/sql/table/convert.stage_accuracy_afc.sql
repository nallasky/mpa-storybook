create table convert.stage_accuracy_afc
(
    equipment_name   text      not null,
    device           text,
    process          text,
    plate            integer,
    step             integer,
    glass_id         text,
    lot_id           text,
    ps_z_ave_max     integer,
    ps_z_ave_min     integer,
    ps_z_std_dev     integer,
    ps_pitch_ave_max integer,
    ps_pitch_ave_min integer,
    ps_pitch_std_dev integer,
    ps_roll_ave_max  integer,
    ps_roll_ave_min  integer,
    ps_roll_std_dev  integer,
    z_sensor_ave_max integer,
    z_sensor_ave_min integer,
    z_sensor_std_dev integer,
    log_time         timestamp not null,
    log_idx          integer   not null,
    chuck            text,
	created_time           timestamp not null,
	request_id              varchar(50),
    constraint stage_accuracy_afc_pkey
        primary key (equipment_name, log_time, log_idx)
);


