create table cnvset.version_job
(
    id      varchar(50)  not null constraint version_job_pk primary key,
    created timestamp  default now()  not null,
    status  request_status default 'idle'::request_status not null,
    period  integer  default 7  not null,
    file_path text
);