create table convert.operation_log
(
    equipment_name text      not null,
    log_time       timestamp not null,
    host           text,
    ip_address     text,
    author         text,
    operator       text,
    screen_name    text,
    message        text,
    glass_id       text,
    lot_id         text,
    log_idx        integer   not null,
	created_time           timestamp not null,
	request_id              varchar(50),
    constraint operation_log_pkey
        primary key (equipment_name, log_time, log_idx)
);

