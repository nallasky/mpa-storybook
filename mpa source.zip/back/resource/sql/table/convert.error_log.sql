create table convert.error_log
(
    equipment_name   text      not null,
    error_code       text,
    error_message    text,
    occurrence_count integer,
    occurred_date    timestamp not null,
    reseted_date     timestamp,
    ppid             text,
    device           text,
    process          text,
    glass_id         text,
    lot_id           text,
    chuck            text,
    log_idx          integer   not null,
    created_time           timestamp not null,
	request_id              varchar(50),
    constraint error_log_pkey
        primary key (equipment_name, occurred_date, log_idx)
);


