create table cnvset.summary_job
(
    id      varchar(50)                                   not null constraint summary_job_pk primary key,
    site    varchar(15)                                   not null,
    fab     varchar(15)                                   not null,
    created timestamp      default now()                  not null,
    status  request_status default 'idle'::request_status not null,
    start   timestamp,
    "end"   timestamp,
    zip_path text
);