create table convert.mecha_pre_alignment
(
    equipment_name    text      not null,
    device            text,
    process           text,
    chuck             text,
    plate_no          integer,
    glass_id          text,
    lot_id            text,
    log_time          timestamp not null,
    x_rear_or_x       integer,
    x_front_or_y_left integer,
    y_or_y_right      integer,
    x                 integer,
    y                 integer,
    theta             integer,
    log_idx           integer   not null,
    direction         integer,
	created_time           timestamp not null,
	request_id              varchar(50),
    constraint mecha_pre_alignment_pkey
        primary key (equipment_name, log_time, log_idx)
);
