create table convert.status_monitor_analysis
(
    equipment_name varchar(128) not null,
    event          varchar(128) not null,
    start_time     timestamp(6) not null,
    end_time       timestamp(6) not null,
    elapsed        double precision,
    device         varchar(32),
    process        varchar(32),
    lot_id         varchar(32),
    plate_id       varchar(32),
    plate_no       integer,
	created_time           timestamp not null,
	request_id              varchar(50),
    constraint status_monitor_analysis_pkey
        primary key (equipment_name, event, start_time)
);

