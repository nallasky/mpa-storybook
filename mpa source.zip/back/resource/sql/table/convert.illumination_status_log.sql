create table convert.illumination_status_log
(
    equipment_name         text      not null,
    log_time               timestamp not null,
    flyeyesd_pos           integer,
    flyeye_sib_illmode_pos integer,
    slit_ndfilter_pos      integer,
    lamp_num               integer,
    glass_id               text,
    lot_id                 text,
    lamp_pow_r             integer,
    lamp_time_l            integer,
    lamp_pow_l             integer,
    lamp_pow_c             integer,
    lamp_time_r            integer,
    uniformity_sensor      integer,
    il_prs4                integer,
    il_prs5                integer,
    il_prs2                integer,
    il_prs3                integer,
    lamp_time_c            integer,
    il_prs1                integer,
    illum_sensor_ad        integer,
    log_idx                integer   not null,
    created_time           timestamp not null,
    request_id              varchar(50),
    constraint illumination_status_log_pkey
        primary key (equipment_name, log_time, log_idx)
);