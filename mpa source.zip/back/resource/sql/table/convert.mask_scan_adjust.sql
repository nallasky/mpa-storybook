create table convert.mask_scan_adjust
(
    equipment_name  text      not null,
    count           integer,
    tv_pos_xl       integer,
    tv_pos_yl       integer,
    tv_pos_xr       integer,
    tv_pos_yr       integer,
    ms_pos_xl       integer,
    ms_pos_yl       integer,
    ms_pos_xr       integer,
    ms_pos_yr       integer,
    ps_pos_xl       integer,
    ps_pos_yl       integer,
    ps_pos_xr       integer,
    ps_pos_yr       integer,
    mask_theta_comp integer,
    mask_x_comp     integer,
    log_time        timestamp not null,
    glass_id        text,
    lot_id          text,
    log_idx         integer   not null,
	created_time           timestamp not null,
	request_id              varchar(50),
    constraint mask_scan_adjust_pkey
        primary key (equipment_name, log_time, log_idx)
);

