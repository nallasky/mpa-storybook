create table convert.mask_temperature_monitor
(
    equipment_name            text      not null,
    device                    text,
    process                   text,
    glass_id                  text,
    lot_id                    text,
    plate                     integer,
    temperature_plate_prepare integer,
    temperature_calc_mag      integer,
    magnification_x           integer,
    magnification_y           integer,
    chuck                     text,
    log_time                  timestamp not null,
    log_idx                   integer   not null,
	created_time           timestamp not null,
	request_id              varchar(50),
    constraint mask_temperature_monitor_pkey
        primary key (equipment_name, log_time, log_idx)
);

