import os

from flask import Flask, render_template, g, send_from_directory, jsonify
# from flask_cors import CORS
from flask_restx import Api

from controller.cras.cras import Cras
from controller.analysis.controller_analysis import ANALYSIS
from controller.converter.converter import CONVERTER
from controller.rapid.rapid_controller import Rapid
from controller.setting.controller_setting import SETTING
from controller.resources.controller_resources import RESOURCES
from controller.dbimport.controller_import import IMPORT
from controller.export.controller_export import EXPORT
from controller.summary.error_summary import Summary
from controller.version.version_info import Version
from dao import init_db, db_validate
from config.app_config import *


def create_app(config_filename=None):
    app = Flask(__name__, static_folder='../web/static/', template_folder='../web/static')

    if config_filename is not None:
        app.config.from_pyfile(config_filename)

    app.config.SWAGGER_UI_DOC_EXPANSION = 'none'  # none, list, full
    # app.config.SWAGGER_SUPPORTED_SUBMIT_METHODS = []

    api = Api(app,
              doc='/doc/',
              version=app.config['API_VERSION'],
              title=app.config['API_TITLE'],
              description=app.config['API_DESCRIPTION'],
              license=app.config['API_LICENSE'])

    # 외부 서비스, 포트, 도메인에서의 API요청을 허용
    # CORS(app, resources={r"/api/*": {"origins": "*"}})

    # MPA Analysis Tool 전용 REST API
    api.add_namespace(ANALYSIS, '/api/analysis')
    api.add_namespace(SETTING, '/api/setting')
    api.add_namespace(RESOURCES, '/api/resources')

    # 공용 REST API
    api.add_namespace(CONVERTER, '/api/converter')
    api.add_namespace(IMPORT, '/api/import')
    api.add_namespace(EXPORT, '/api/export')

    # init db
    init_db()
    db_validate()

    @app.route('/main', methods=['GET'])
    def catch_all():
        g.jinja2_test = 'made by gtttpark!'
        return render_template('index.html')

    @app.route('/js/<path:filename>')
    def serve_static_js(filename):
        root_dir = os.getcwd()
        return send_from_directory(os.path.join(root_dir, STATIC_JS_PATH), filename)

    @app.route('/<path:filename>')
    def serve_static(filename):
        root_dir = os.getcwd()
        return send_from_directory(os.path.join(root_dir, STATIC_PATH), filename)

    @app.route('/fonts/<path:filename>')
    def serve_static_fonts(filename):
        root_dir = os.getcwd()
        return send_from_directory(os.path.join(root_dir, STATIC_PONTS_PATH), filename)

    @app.route('/logmonitor/api/configure/sites/names')
    def user_fab():
        data = [
            {
                "siteId": 1,
                "crasSiteName": "BSOT"
            },
            {
                "siteId": 2,
                "crasSiteName": "Qoyole"
            },
            {
                "siteId": 3,
                "crasSiteName": "GKC"
            }
        ]
        return jsonify(data)

    @app.route('/logmonitor/api/equipments')
    def equipments():
        data = {
            "equipments": {
                "Qoyole": [
                    "BSOT_s1_OLINB0_G086",
                    "BSOT_s1_OLIN80_G089",
                    "BSOT_s2_SBPCNF80_G215",
                    "GKC_G1_BF8_G220",
                    "BSOT_s2_SBPCN580_G152",
                    "BSOT_s1_OLIND0_G083",
                    "BSOT_s1_OLINE0_G088",
                    "BSOT_s1_OLINC0_G087",
                    "BSOT_s1_OLINF0_G137",
                    "BSOT_s2_SBPCNB80_G182",
                    "BSOT_s1_OLINA0_G108",
                    "BSOT_s1_OLIN90_G107",
                    "BSOT_s1_OLIN60_G085",
                    "BSOT_s2_SBPCN380_G146",
                    "BSOT_s1_OLIN40_G084",
                    "Qoyole_RZ_SFT2_DH82",
                    "BSOT_s2_SBPCNA80_G183",
                    "BSOT_s2_SBPCN480_G147",
                    "BSOT_s2_SBPCNE80_G230",
                    "Qoyole_RZ_SFT1_DH80",
                    "BSOT_s1_OLIN10_G090"
                ],
                "BSOT": [
                    "BSOT_s1_OLINB0_G086",
                    "BSOT_s1_OLIN80_G089",
                    "BSOT_s2_SBPCNF80_G215",
                    "GKC_G1_BF8_G220",
                    "BSOT_s2_SBPCN580_G152",
                    "BSOT_s1_OLIND0_G083",
                    "BSOT_s1_OLINE0_G088",
                    "BSOT_s1_OLINC0_G087",
                    "BSOT_s1_OLINF0_G137",
                    "BSOT_s2_SBPCNB80_G182",
                    "BSOT_s1_OLINA0_G108",
                    "BSOT_s1_OLIN90_G107",
                    "BSOT_s1_OLIN60_G085",
                    "BSOT_s2_SBPCN380_G146",
                    "BSOT_s1_OLIN40_G084",
                    "Qoyole_RZ_SFT2_DH82",
                    "BSOT_s2_SBPCNA80_G183",
                    "BSOT_s2_SBPCN480_G147",
                    "BSOT_s2_SBPCNE80_G230",
                    "Qoyole_RZ_SFT1_DH80",
                    "BSOT_s1_OLIN10_G090"
                ],
                "GKC": [
                    "BSOT_s1_OLINB0_G086",
                    "BSOT_s1_OLIN80_G089",
                    "BSOT_s2_SBPCNF80_G215",
                    "GKC_G1_BF8_G220",
                    "BSOT_s2_SBPCN580_G152",
                    "BSOT_s1_OLIND0_G083",
                    "BSOT_s1_OLINE0_G088",
                    "BSOT_s1_OLINC0_G087",
                    "BSOT_s1_OLINF0_G137",
                    "BSOT_s2_SBPCNB80_G182",
                    "BSOT_s1_OLINA0_G108",
                    "BSOT_s1_OLIN90_G107",
                    "BSOT_s1_OLIN60_G085",
                    "BSOT_s2_SBPCN380_G146",
                    "BSOT_s1_OLIN40_G084",
                    "Qoyole_RZ_SFT2_DH82",
                    "BSOT_s2_SBPCNA80_G183",
                    "BSOT_s2_SBPCN480_G147",
                    "BSOT_s2_SBPCNE80_G230",
                    "Qoyole_RZ_SFT1_DH80",
                    "BSOT_s1_OLIN10_G090"
                ]
            }
        }
        return jsonify(data)

    @app.route('/logmonitor/api/connection')
    def connection():
        data = {
            "version": "ex) Log Monitoring Server v1.0.0"
        }
        return jsonify(data)

    @app.route('/logmonitor/api/date/PLATEAUTOFOCUSCOMPENSATION/BSOT_s1_OLINB0_G086')
    def date():
        data = {
            "start": "2021-01-01",
            "end": "2021-03-03"
        }
        return jsonify(data)

    return app
