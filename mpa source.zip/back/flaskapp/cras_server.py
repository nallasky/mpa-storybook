from flask import Flask, Response, make_response
from flask_restx import Api

from controller.converter.converter import CONVERTER
from controller.cras.cras import Cras
from controller.dbimport.controller_import import IMPORT
from controller.export.controller_export import EXPORT
from controller.rapid.rapid_controller import Rapid
from controller.summary.error_summary import Summary
from controller.version.version_info import Version
from dao import init_db
from config.app_config import *


def create_app(config_filename):
    if config_filename is None:
        print('no config_filename')
        exit(-1)

    # Instantiate flask.
    app = Flask(__name__)

    app.config.from_pyfile(config_filename)
    app.config.SWAGGER_UI_DOC_EXPANSION = 'none'  # none, list, full
    api = Api(app,
              doc='/doc/',
              version=app.config['API_VERSION'],
              title=app.config['API_TITLE'],
              description=app.config['API_DESCRIPTION'],
              license=app.config['API_LICENSE'])

    api.add_namespace(CONVERTER, '/api/converter')
    # api.add_namespace(IMPORT, '/api/import')
    # api.add_namespace(EXPORT, '/api/export')
    api.add_namespace(Summary, '/api/summary')
    api.add_namespace(Cras, '/api/cras')
    api.add_namespace(Rapid, '/api/rapid')
    api.add_namespace(Version, '/api/version')

    # init db
    init_db()

    @app.route('/api', methods=['GET'])
    def hello():
        return make_response('1.0.0', 200)

    return app


