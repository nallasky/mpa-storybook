##########################################################################
# Application Information
##########################################################################
APP_MAJOR = 0
APP_MINOR = 0
APP_REVISION = 1
APP_VERSION = '%s.%s.%s' % (APP_MAJOR, APP_MINOR, APP_REVISION)
APP_COPYRIGHT = 'Copyright (c) 2021 CANON Inc. All rights reserved.'
APP_MODE = 'Desktop'

API_VERSION = APP_VERSION
API_TITLE = 'MPA Analysis Tool - REST API SERVER'
API_DESCRIPTION = 'MPA Analysis ToolのREST APIに対する詳細説明ページです。'
API_LICENSE = APP_COPYRIGHT

##########################################################################
# Debug Mode
##########################################################################
DEBUG = True

##########################################################################
# Log System Settings
##########################################################################
LOG = 'APP_LOG'
LOG_FILENAME = 'log.log'
LOG_FILEPATH = 'logs'
LOG_ERRNAME = 'err.log'
LOG_MAXBYTE = 10 * 1024 * 1024
LOG_BACKUPCOUNT = 100
LOG_FORMAT = '%(asctime)s: %(levelname)s: %(module)s: %(message)s'
LOG_DATEFMT = '%Y-%m-%d %H:%M:%S'

##########################################################################
# PATH
##########################################################################
RESOURCE_PATH = '../resource'
BACKUP_PATH = '../.backup'
TEMP_PATH = '../.tmp'
local_cache_root = '../.convert'

DB_CONFIG_PATH = '../config/db_config.conf'

STATIC_JS_PATH = '../web/static/js'
STATIC_PATH = '../web/static'
STATIC_PONTS_PATH = '../web/static/fonts'

RSC_JSON_MAIN = 'json/page_main.json'
RSC_JSON_ABOUT = 'json/page_about.json'
RSC_JSON_MGMT = 'json/page_mgmt.json'
RSC_JSON_LOCAL_FORM = 'json/setting_local_form.json'
RSC_JSON_REMOTE_FORM = 'json/setting_remote_form.json'

##########################################################################
# DATA CLEAN INTERVAL
##########################################################################
CLEANER_INTERVAL = 60 * 60  # 60min
EXPIRING_DATE_HOUR = 24     # 24Hours

##########################################################################
# DATABASE SCHEMA
##########################################################################
SCHEMA_SETTINGS = 'settings'
SCHEMA_CONVERT = 'convert'
SCHEMA_ANALYSIS = 'analysis'
SCHEMA_PUBLIC = 'public'
SCHEMA_CNVBASE = 'cnvbase'
SCHEMA_CNVSET = 'cnvset'
SCHEMA_LIST = [SCHEMA_PUBLIC, SCHEMA_CNVBASE, SCHEMA_SETTINGS, SCHEMA_CONVERT, SCHEMA_ANALYSIS, SCHEMA_CNVSET]
SCHEMA_EXPORT_LIST = [SCHEMA_ANALYSIS, SCHEMA_CNVBASE]

##########################################################################
# Remote Server URL
##########################################################################
API_GET_NAMES = '/logmonitor/api/configure/sites/names'
API_GET_EQUIPMENTS = '/logmonitor/api/equipments'
API_GET_DATE = '/logmonitor/api/date'
API_GET_LOG = '/logmonitor/api/log'
API_GET_CONNECTION = '/logmonitor/api/connection'
