# Database config for CRAS server
DB_NAME = "rssdb"
DB_USER = "rssadmin"
DB_HOST = "localhost"
DB_PASSWORD = "1234"
DB_PORT = 5432

# Set Zip command.
ZIP_EXEC = '/usr/local/7zz'  # 'C:\\Program Files\\7-Zip\\7z.exe'
ZIP_OPTIONS = 'a -p%s'

# Converter settings
CONVERTING_PROCESSES = 4
CONVERTER_ROOT = '.convert'

# Set CRAS file path
CRAS_OUTPUT = 'newcrasresult.xlsx'
VERSION_ROOT = '/CANON/cras/version'
CRAS_ROOT = '.cras'

# Error summary config
SUMMARY_ROOT = '.summary'

# Version check config
VERSION_ROOT = '.version'

# History
HISTORY_LIMIT = 1000

