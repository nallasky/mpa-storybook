import datetime
import logging
import os

from flask import Response, request, make_response, jsonify, send_file
from flask_restx import Resource, Namespace

from config import app_config
from config.cras_config import CRAS_ROOT
from dao.dao_cras_job import CrasJobDao
from service.cras.service_process_cras import ProcessCras

log = logging.getLogger(app_config.LOG)
Cras = Namespace('CRAS', description='It servers CRAS features.')


@Cras.route('/job')
class CrasRequest(Resource):
    parser = Cras.parser()
    parser.add_argument('site', required=True, help='A site name that interface with this server.')
    parser.add_argument('fab', required=True, help='A fab name you want to summary errors.')
    parser.add_argument('password', help='A password for a zip file.')

    @Cras.expect(parser)
    @Cras.doc(responses={
        200: 'Success',
        400: 'Parameter error'
    })
    def post(self):
        """
        Request a CRAS job.
        """
        log.info(f'{request.method} {request.path}')
        param = self.parser.parse_args()
        try:
            form = {
                'id': get_request_id(),
                'site': param['site'],
                'fab': param['fab']
            }
            io = CrasJobDao()
            job = io.insert_job(form)
            if job is None:
                log.error('failed to insert job')
                return Response(status=400)

            ProcessCras(job['id'])

            response = make_response(jsonify({'rid': job['id']}), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'

            return response

        except KeyError as msg:
            log.error(f'param error {msg}')
            return Response(status=400)


@Cras.route('/job/<string:rid>')
@Cras.param('rid', 'Request ID(Job ID)')
class CrasStatus(Resource):

    @Cras.doc(responses={
        200: 'Success',
        400: 'Parameter error'
    })
    def get(self, rid):
        """
        Get a specific cras job status.
        """
        log.info(f'{request.method} {request.path}')
        io = CrasJobDao()
        job = io.get_job(rid)
        if job is None:
            log.error(f'failed to get cras info {rid}')
            return Response(status=400)

        body = create_response_body(job)
        response = make_response(jsonify(body), 200)

        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@Cras.route('/job/download/<string:rid>/<string:type>')
@Cras.param('rid', 'Request ID(Job ID)')
class CrasDownloadReport(Resource):

    @Cras.doc(responses={
        200: 'Success',
        400: 'Parameter error'
    })
    def get(self, rid, type):
        """
        Download a cras report.
        """
        log.info(f'{request.method} {request.path}')
        job = CrasJobDao().get_job(rid)
        if job is None:
            log.error(f'invalid rid {rid}')
            return Response(status=400)
        file_path = job[f'{type}_path']
        if os.path.exists(file_path):
            return send_file(file_path, as_attachment=True)
        return Response(status=500)


@Cras.route('/history')
class ConvertHistoryList(Resource):
    def get(self):
        log.info(f'{request.method} {request.path}')
        try:
            io = CrasJobDao().get_history_list()
            response = make_response(jsonify(io), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        except Exception as msg:
            log.error(f'failed to query. {msg}')
        return Response(status=500)


@Cras.route('/history/<string:rid>')
class ConvertHistory(Resource):
    def get(self, rid):
        log.info(f'{request.method} {request.path}')
        io = CrasJobDao()
        job = io.get_job(rid)
        if not job:
            log.error(f'invalid rid {rid}')
            return Response(status=400)
        if io.get_history_list(rid) is None:
            log.error(f'invalid history {rid}')
            return Response(status=400)
        detail_file = os.path.join(CRAS_ROOT, rid, f'{rid}.log')
        if not os.path.exists(detail_file):
            log.error('detail history file is not exist')
            return Response(status=500)
        with open(detail_file, 'r', encoding='utf-8') as f:
            response = make_response(f.read(), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        return Response(status=500)


def get_request_id():
    now = datetime.datetime.now()
    return now.strftime("cras_%Y%m%d_%H%M%S%f")


def create_response_body(job):
    body = {
        'rid': job['id'],
        'status': job['status'],
        'site': job['site'],
        'fab': job['fab']
    }
    if job['status'] == 'success':
        body = {
            **body,
            'download_mail': f"/api/cras/job/download/{job['id']}/mail",
            'download_pdf': f"/api/cras/job/download/{job['id']}/pdf",
            'download_data': f"/api/cras/job/download/{job['id']}/data",
            'download_judge': f"/api/cras/job/download/{job['id']}/judge"
        }
    return body
