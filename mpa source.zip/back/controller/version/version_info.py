import datetime
import json
import logging
import os
from io import StringIO

from flask import Response, request, make_response, jsonify, send_file
from flask_restx import Resource, Namespace

from config import app_config
from config.cras_config import VERSION_ROOT
from dao.dao_convert import ConvertDao
from dao.dao_version_job import VersionJobDao
from service.version.send_version_info import VersionCheckProcess

log = logging.getLogger(app_config.LOG)

Version = Namespace('Version', description='It serves features about version checking.')


@Version.route('/')
class VersionStatus(Resource):
    def get(self):
        log.info(f'{request.method} {request.path}')
        rows = ConvertDao.instance().count_row('version_info')
        if rows > 0:
            body = {'status': 'okay'}
        else:
            body = {'status': '-'}
        response = make_response(jsonify(body), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@Version.route('/diff')
class VersionDifference(Resource):
    def get(self):
        log.info(f'{request.method} {request.path}')
        io = ConvertDao.instance()
        date = io.get_version_info_log_time()
        if date is None:
            return Response(status=400)
        body = dict()
        for d in date:
            info = io.get_version_info(d)
            if info is not None:
                body = {**body, str(d): info}

        response = make_response(jsonify(body), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@Version.route('/job')
class VersionCheckRequest(Resource):
    parser = Version.parser()
    parser.add_argument('period', required=False, type=int, default=7, help='Set period to look into checking versions.')

    def post(self):
        log.info(f'{request.method} {request.path}')
        io = VersionJobDao()
        if io.job_exist():
            log.error('busy')
            return Response(status=400)
        param = self.parser.parse_args()
        form = {
            'id': get_request_id(),
            'period': param['period'],
        }
        job = io.insert_job(form)
        if job is None:
            return Response(status=400)
        VersionCheckProcess(form['id'])
        response = make_response(jsonify({'rid': job['id']}), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@Version.route('/job/<string:rid>')
@Version.param('rid', 'Request ID(Job ID)')
class VersionCheckStatus(Resource):

    @Version.doc(responses={
        200: 'Success',
        400: 'Internal server error',
        500: 'Parameter error'
    })
    def get(self, rid):
        log.info(f'{request.method} {request.path}')
        io = VersionJobDao()
        job = io.get_job(rid)
        if job is None:
            return Response(status=500)

        body = {
            'rid': job['id'],
            'status': job['status'],
            'download': f"/api/version/job/download/{job['id']}"
        }
        response = make_response(jsonify(body), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@Version.route('/job/download/<string:rid>')
class VersionCheckDownloadReport(Resource):

    def get(self, rid):
        log.info(f'{request.method} {request.path}')
        io = VersionJobDao()
        job = io.get_job(rid)
        if job is None or job['file_path'] is None or job['file_path'] == '':
            return Response(status=500)
        if os.path.exists(job['file_path']):
            return send_file(job['file_path'], as_attachment=True)
        return Response(status=500)


@Version.route('/history')
class VersionCheckHistoryList(Resource):
    def get(self):
        log.info(f'{request.method} {request.path}')
        io = VersionJobDao()
        history = io.get_history_list()
        response = make_response(jsonify(history), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@Version.route('/history/<string:rid>')
class VersionCheckHistory(Resource):
    def get(self, rid):
        log.info(f'{request.method} {request.path}')
        io = VersionJobDao()
        job = io.get_job(rid)
        if not job:
            log.error(f'invalid rid {rid}')
            return Response(status=400)
        if io.get_history_list(rid) is None:
            log.error(f'invalid history {rid}')
            return Response(status=400)
        detail_file = os.path.join(VERSION_ROOT, rid, f'{rid}.log')
        if not os.path.exists(detail_file):
            log.error('detail history file is not exist')
            return Response(status=500)
        with open(detail_file, 'r', encoding='utf-8') as f:
            response = make_response(f.read(), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        return Response(status=500)


def get_request_id():
    now = datetime.datetime.now()
    return now.strftime("version_%Y%m%d_%H%M%S%f")
