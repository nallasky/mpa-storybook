import os
import shutil
import zipfile
import logging
from flask import request, Response, current_app
from werkzeug.datastructures import FileStorage
from flask_restx import Resource, Namespace, fields
import threading
from config import app_config
from common.utils.response import make_json_response
from dao.dao_base import DAOBaseClass
from dao import init_db, init_table, init_data

logger = logging.getLogger(app_config.LOG)

IMPORT = Namespace(name='IMPORT', description='データベーステーブルのImport用API。')

sem = threading.Semaphore()

@IMPORT.route('')
class SETTINGConnectionCheck(Resource):
    parser = IMPORT.parser()
    parser.add_argument('files', type=FileStorage, location='files', required=True, help='FILE名')

    @IMPORT.expect(parser)
    @IMPORT.response(200, 'Success')
    @IMPORT.response(400, 'Bad Request')
    @IMPORT.response(500, 'Internal Server Error')
    def post(self):
        """
        データベース テーブルのImportを担当する。
        Import失敗時本来データで復旧させる。
        """
        logger.info(str(request))

        args = self.parser.parse_args()
        # f = request.files['file']
        f = args['files']

        sem.acquire()

        if '.zip' not in f.filename.lower():
            sem.release()
            return make_json_response(status=400, msg='Accept only zip file format.')

        try:
            if not os.path.exists(current_app.config['TEMP_PATH']):
                os.mkdir(current_app.config['TEMP_PATH'])

            save_path = os.path.join(current_app.config['TEMP_PATH'], f.filename)
            f.save(save_path)

            dao = DAOBaseClass()
            resp_form = dao.get_table_list_from_schema(app_config.SCHEMA_EXPORT_LIST)
            if not resp_form.res:
                shutil.rmtree(current_app.config['TEMP_PATH'])
                sem.release()
                return make_json_response(status=500, msg=resp_form.msg)

            table_list = resp_form.data

            backup_path = current_app.config['BACKUP_PATH']
            if os.path.exists(backup_path):
                shutil.rmtree(backup_path)

            shutil.copytree(current_app.config['RESOURCE_PATH'], backup_path)

            import_file = zipfile.ZipFile(save_path)

            for file in import_file.namelist():
                filename = file.split('/')[-1]
                if filename.replace('.csv', '') in table_list:
                    dir_path = self.get_resource_path(filename)
                    if dir_path is not None:
                        import_file.extract(file, dir_path)

            del import_file

            shutil.rmtree(current_app.config['TEMP_PATH'])

            dao = DAOBaseClass()
            resp_form = dao.drop_tables()

            if resp_form.res:
                resp = init_table()
                if not resp.res:
                    dao.drop_tables()
                    shutil.rmtree(current_app.config['RESOURCE_PATH'])
                    shutil.copytree(backup_path, current_app.config['RESOURCE_PATH'])
                    init_db()
                    shutil.rmtree(backup_path)
                    sem.release()
                    return make_json_response(status=500, msg=resp.msg)

                resp = init_data()
                if not resp.res:
                    dao.drop_tables()
                    shutil.rmtree(current_app.config['RESOURCE_PATH'])
                    shutil.copytree(backup_path, current_app.config['RESOURCE_PATH'])
                    init_db()
                    shutil.rmtree(backup_path)
                    sem.release()
                    return make_json_response(status=500, msg=resp.msg)
            else:
                shutil.rmtree(current_app.config['RESOURCE_PATH'])
                shutil.copytree(backup_path, current_app.config['RESOURCE_PATH'])
                init_db()
                shutil.rmtree(backup_path)
                sem.release()
                return make_json_response(status=500, msg=resp_form.msg)

            shutil.rmtree(backup_path)

            sem.release()
            return Response(status=200)

        except Exception as e:
            sem.release()
            return make_json_response(status=500, msg=str(e))

    def get_resource_path(self, filename):
        for dirpath, dirnames, filenames in os.walk(current_app.config['RESOURCE_PATH']):
            for file in filenames:
                if file == filename:
                    return dirpath
