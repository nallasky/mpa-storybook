import logging
import os
from flask import request, Response, json
from flask_restx import Resource, Namespace, fields
import requests

from config import app_config
from common.utils.response import make_json_response, ResponseForm
from dao.dao_management_setting import DAOMGMTSetting
from dao.dao_base import DAOBaseClass

logger = logging.getLogger(app_config.LOG)

RESOURCES = Namespace(name='RESOURCES', description='Management Setting変更をためのAPI。')

settings_response_model = RESOURCES.model('settings_response_model', {
    'log_name': fields.String(description='Log名', example='PLATEAUTOFOCUSCOMPENSATION'),
    'title': fields.String(description='タイトル', example='Plate Auto Focus Compensation(AFC) Analysis'),
    'formList': fields.List(fields.String(example='local'), description='設定を構成するFORMリスト'),
    'form': fields.Raw(description='FORM情報', example={
        'local': [
            {
                'title': '1. Select Source',
                'items': [
                    {
                        'target': 'source',
                        'title': 'From',
                        'type': 'select',
                        'mode': 'singular',
                        'options': [
                            'local', 'remote'
                        ]
                    }
                ]
            }
        ],
        'remote': [
            {
                'title': '1. Select Source',
                'items': [
                    {
                        'target': 'source',
                        'title': 'From',
                        'type': 'select',
                        'mode': 'singular',
                        'options': [
                            'local', 'remote'
                        ]
                    }
                ]
            }
        ]}),
})

date_response_model = RESOURCES.model('date_response_model', {
    'start': fields.String(description='Logの開始時間', example='2021-01-01'),
    'end': fields.String(description='Logの終了時間', example='2021-03-03'),
})


@RESOURCES.route('/<string:page>')
@RESOURCES.param('page', 'ページ名')
class PAGEResources(Resource):
    @RESOURCES.response(200, 'Success')
    @RESOURCES.response(400, 'Bad Request')
    def get(self, page):
        """
        ページ毎の構成情報を提供。
        """
        logger.info(str(request))

        resp_form = self.get_page_resource(page)

        if resp_form.res:
            return make_json_response(**resp_form.data)
        else:
            return make_json_response(status=400, msg=resp_form.msg)

    def get_page_resource(self, page):
        if page == 'main':
            return self.get_main_resource()
        elif page == 'about':
            return self.get_about_resource()
        elif page == 'mgmt':
            return self.get_mgmt_resource()
        else:
            return ResponseForm(res=False, msg='Not Found')

    def get_main_resource(self):
        try:
            with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_JSON_MAIN), 'r') as f:
                json_data = json.load(f)

            if 'footer' in json_data:
                if 'copyright' in json_data['footer']:
                    json_data['footer']['copyright'] = app_config.APP_COPYRIGHT

                if 'version' in json_data['footer']:
                    json_data['footer']['version'] = app_config.APP_VERSION

            return ResponseForm(res=True, data=json_data)

        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_about_resource(self):
        try:
            with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_JSON_ABOUT), 'r') as f:
                json_data = json.load(f)

            if 'version' in json_data:
                json_data['version'] = app_config.APP_VERSION

            if 'app_mode' in json_data:
                json_data['app_mode'] = app_config.APP_MODE

            if 'copyright' in json_data:
                json_data['copyright'] = app_config.APP_COPYRIGHT

            if 'licenses' in json_data:
                with open('LICENSE.md', 'r', encoding='utf-8') as f:
                    md = f.read()
                json_data['licenses'] = md

            return ResponseForm(res=True, data=json_data)

        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_mgmt_resource(self):
        try:
            with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_JSON_MGMT), 'r') as f:
                json_data = json.load(f)

            dao_mgmt = DAOMGMTSetting()
            df = dao_mgmt.fetch_all()

            if 'settings' in json_data:
                for setting in json_data['settings']:
                    if 'target' in setting:
                        if setting['target'] == 'local' or setting['target'] == 'remote':
                            if 'items' in setting:
                                for item in setting['items']:
                                    item_target = item['target']
                                    if item_target in df.columns:
                                        target = setting['target']
                                        item['content'] = df[df['target'] == target].reset_index(drop=True)[item_target][0]
                        elif setting['target'] == 'table':
                            dao = DAOBaseClass()
                            resp_form = dao.get_table_list_from_schema(app_config.SCHEMA_EXPORT_LIST)
                            if resp_form.res == True:
                                if 'items' in setting:
                                    no = {'type': 'column', 'title': 'no', 'items': [str(i+1) for i in range(len(resp_form.data))]}
                                    table = {'type': 'column', 'title': 'Table name', 'items': [table for table in resp_form.data]}
                                    setting['items'].append(no)
                                    setting['items'].append(table)

            return ResponseForm(res=True, data=json_data)

        except Exception as e:
            return ResponseForm(res=False, msg=str(e))


@RESOURCES.route('/settings/<string:log_name>')
@RESOURCES.param('log_name', 'LOG名')
class SETTINGSResource(Resource):
    @RESOURCES.doc(model=settings_response_model)
    @RESOURCES.response(200, 'Success')
    @RESOURCES.response(400, 'Bad Request')
    def get(self, log_name):
        """
        機能毎の設定画面構成情報を提供。
        """
        logger.info(str(request))

        resp_form = self.get_settings_resource(log_name)

        if resp_form.res:
            return make_json_response(**resp_form.data)
        else:
            return make_json_response(status=400, msg=resp_form.msg)

    def get_settings_resource(self, log_name):
        try:
            base_form = self.get_base_form()
            default_setting = self.get_default_setting(log_name)


            base_form['log_name'] = default_setting['log_name']
            base_form['title'] = default_setting['title']

            dao_mgmt = DAOMGMTSetting()
            mgmt_df = dao_mgmt.fetch_all()
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

        db_remote_df = mgmt_df[mgmt_df['target'] == 'remote'].reset_index()
        isnull = db_remote_df['host'].isnull().values.any()
        forms = dict()
        if not isnull:
            host = db_remote_df['host'][0]
            while host[-1] == '/':
                host = host[:-1]

            url = host + app_config.API_GET_CONNECTION
            try:
                response = requests.get(url)
            except Exception as e:
                return ResponseForm(res=False, msg=str(e))

            if response.status_code == 200:
                # Remote Form 추가
                base_form['formList'].append('remote')

                remote_form = self.get_remote_form()
                if remote_form.res:
                    for setting in remote_form.data:
                        for item in setting['items']:
                            if item['target'] == 'source':
                                item['options'] = base_form['formList']
                            if item['target'] == 'user_fab':
                                resp_form = self.get_user_fab_info(host)
                                if resp_form.res:
                                    item['options'] = resp_form.data

                                if len(item['options']) > 0:
                                    resp_form = self.get_equipment_info(host)
                                    if resp_form.res:
                                        options_list = []
                                        for option in item['options']:
                                            equipment = dict()
                                            equipment[option] = resp_form.data[option]
                                            options_list.append(equipment)
                                        item['subItem']['options'] = options_list

                            if item['target'] == 'period':
                                pass
                    forms['remote'] = remote_form.data

        # Local Form 추가
        local_form = self.get_local_form()
        if local_form.res:
            for setting in local_form.data:
                for item in setting['items']:
                    if item['target'] == 'source':
                        item['options'] = base_form['formList']
                    if item['target'] == 'target_path':
                        item['type'] = default_setting['target_path']
                    if item['target'] == 'equipment_type':
                        resp_form = self.get_local_equipment_type()
                        if resp_form.res:
                            item['options'] = resp_form.data
            forms['local'] = local_form.data

        base_form['form'] = forms

        return ResponseForm(res=True, data=base_form)

    def get_user_fab_info(self, host):
        try:
            url = host + app_config.API_GET_NAMES

            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                resp_data = []
                for item in data:
                    resp_data.append(item['crasSiteName'])

                return ResponseForm(res=True, data=resp_data)
            else:
                return ResponseForm(res=False, msg=response.text, status=response.status_code)

        except Exception as e:
            return ResponseForm(res=False, msg=str(e), status=400)

    def get_equipment_info(self, host):
        try:
            url = host + app_config.API_GET_EQUIPMENTS

            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()

                return ResponseForm(res=True, data=data['equipments'])
            else:
                return ResponseForm(res=False, msg=response.text, status=response.status_code)

        except Exception as e:
            return ResponseForm(res=False, msg=str(e), status=400)

    def get_local_equipment_type(self):
        try:
            dao = DAOBaseClass(table_name='cnvbase.equipments')
            df = dao.fetch_all()

            return ResponseForm(res=True, data=df['equipment_type'].dropna(axis=0).unique().tolist())

        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_default_setting(self, log_name):
        if log_name == 'afc':
            return {
                'log_name': 'PLATEAUTOFOCUSCOMPENSATION',
                'title': 'Plate Auto Focus Compensation(AFC) Analysis',
                'target_path': 'directory',
            }
        elif log_name == 'prescan':
            return {
                'log_name': 'PRESCANCOMPENSATIONMONITOR',
                'title': 'Pre Scan Compensation Analysis',
                'target_path': 'directory'
            }
        elif log_name == 'tiltmeasure':
            return {
                'log_name': 'TiltMeasurementLog',
                'title': 'Tilt Measurement Analysis',
                'target_path': 'file'
            }
        elif log_name == 'mountpress':
            return {
                'log_name': 'MountPressLog',
                'title': 'Mount Press Analysis',
                'target_path': 'file'
            }
        elif log_name == 'lipsfocus':
            return {
                'log_name': 'LiPSFocus',
                'title': 'LIPS Focus Analysis',
                'target_path': 'file'
            }
        else:
            return {

            }

    def get_base_form(self):
        return {
            'log_name': None,
            'title': None,
            'formList': ['local'],
            'form': None
        }

    def get_local_form(self):
        try:
            with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_JSON_LOCAL_FORM), 'r') as f:
                json_data = json.load(f)

            return ResponseForm(res=True, data=json_data)

        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_remote_form(self):
        try:
            with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_JSON_REMOTE_FORM), 'r') as f:
                json_data = json.load(f)

            return ResponseForm(res=True, data=json_data)

        except Exception as e:
            return ResponseForm(res=False, msg=str(e))


@RESOURCES.route('/settings/date/<string:log_name>/<string:equipment>')
@RESOURCES.param('log_name', 'LOG名')
@RESOURCES.param('equipment', '装置名')
class DateResource(Resource):
    @RESOURCES.doc(model=date_response_model)
    @RESOURCES.response(200, 'Success')
    @RESOURCES.response(400, 'Bad Request')
    def get(self, log_name, equipment):
        """
        該当装置のLogの開始・終了区間情報を提供。
        """
        logger.info(str(request))

        resp_form = self.get_start_end_date(log_name, equipment)

        if resp_form.res:
            return make_json_response(**resp_form.data)
        else:
            return make_json_response(status=resp_form.status, msg=resp_form.msg)

    def get_start_end_date(self, log_name, equipment):
        try:
            dao_mgmt = DAOMGMTSetting()
            mgmt_df = dao_mgmt.fetch_all()
        except Exception as e:
            return ResponseForm(res=False, msg=str(e), status=400)

        db_remote_df = mgmt_df[mgmt_df['target'] == 'remote'].reset_index()
        isnull = db_remote_df['host'].isnull().values.any()
        if not isnull:
            host = db_remote_df['host'][0]
            while host[-1] == '/':
                host = host[:-1]

            url = host + app_config.API_GET_DATE + f'/{log_name}/{equipment}'
            try:
                response = requests.get(url)
                if response.status_code == 200:
                    return ResponseForm(res=True, data=response.json())
                else:
                    return ResponseForm(res=False, msg=response.text, status=response.status_code)

            except Exception as e:
                return ResponseForm(res=False, msg=str(e), status=400)

        else:
            return ResponseForm(res=False, msg='Set remote server info first.', status=400)
