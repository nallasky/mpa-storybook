import logging
from flask import request
from flask_restx import Resource, Namespace, fields
import requests
import pandas as pd
from io import StringIO

from config import app_config
from service.analysis.service_analysis import AnalysisService
from dao.dao_management_setting import DAOMGMTSetting
from dao.dao_base import DAOBaseClass
from common.utils.response import make_json_response, ResponseForm
from common.utils import parameter
from controller.converter.converter import create_request_id

logger = logging.getLogger(app_config.LOG)

ANALYSIS = Namespace(name='ANALYSIS', description='ログ分析用API。')

analysis_body = ANALYSIS.model('analysis_body', {
    'log_name': fields.String(description='ログ名', example='PLATEAUTOFOCUSCOMPENSATION'),
    'source': fields.String(description='[local, DB]', example='local'),
    'target_path': fields.String(description='フォルダ経路',
                                 example='P:/log_sample/server_log_path/BSOT/s2/SBPCN480/PLATEAUTOFOCUSCOMPENSATION'),
    'model': fields.String(description='ログフォーマット区分のためのモデル名', example='E813'),
    'one_period': fields.String(description='指定時間を1個のperiodで区分 [12, 24]', example='24'),
    'adjust_period': fields.String(description='periodを区分するための基準時間', example='0'),
    'first_half_year': fields.String(description='ログにyear情報がない場合、1～6月のデータのyear設定', example='2021'),
    'second_half_year': fields.String(description='ログにyear情報がない場合、7～12月のデータのyear設定. [Same Year, Last Year]',
                                      example='Same Year'),
})

analysis_list_response = ANALYSIS.model('analysis_list_response', {
    'items': fields.List(fields.Raw(example={'target': 'one_period',
                                             'title': 'One Period(hour)',
                                             'type': 'select',
                                             'mode': 'singular',
                                             'options': ['12h', '24h'],
                                             'selected': '24h'}, description='target:파라미터명, title:타이틀, '
                                                                              'type:옵션 아이템타입, mode:옵션 아이템 모드, '
                                                                              'options:선택옵션, selected:선택된 옵션'),
                         description='설정 가능한 아이템 리스트'),
    'data': fields.List(fields.Raw(description='start:시작날짜, end:종료날짜, job_list:장치리스트',
                                   example={'start': '2017-05-11 00:00:00',
                                            'end': '2017-05-11 23:59:59',
                                            'job_list': ['SCAN3X2/SCANDBG']}),
                        description='기간별 데이터를 리스트로 반환'),
})

analysis_summary_response = ANALYSIS.model('analysis_summary_response', {
    'items': fields.List(fields.Raw(example={'target': 'valid_interval_minutes',
                                             'title': 'Valid Interval(Min)',
                                             'type': 'select',
                                             'mode': 'singular',
                                             'options': ['1', '2'],
                                             'selected': None}, description='target:파라미터명, title:타이틀, '
                                                                              'type:옵션 아이템타입, mode:옵션 아이템 모드, '
                                                                              'options:선택옵션, selected:선택된 옵션'),
                        description='설정 가능한 아이템 리스트'),
    'data': fields.Raw(example={'disp_order': [], 'summary': {'index 0~ALL': {'column名': '値'}}},
                       description='disp_order:컬럼표시순서, summary:표시 데이터'),
})

analysis_detail_response = ANALYSIS.model('analysis_detail_response', {
    'data': fields.Raw(example={'disp_order': [], 'detail': {'index 0~': {'column名': '値'}}},
                       description='disp_order:컬럼표시순서, detail:표시 데이터'),
})

analysis_remote_response = ANALYSIS.model('analysis_remote_response', {
    'rid': fields.String(description='Request ID', example='request_YYYYMMDD_hhmmssssssss')
})

# @AFC.route('')
# class AFCDefault(Resource):
#     def post(self):
#         dao_lips_log_focus = DAOLipsLogFocus()
#         lips_log_focus_df = dao_lips_log_focus.fetch_all()
#
#         column_to_display = DAODisplayString()
#         column_to_display_df = column_to_display.fetch_all(args={'select': 'column_name, display_str'})
#
#         column_to_display_dict = dict()
#         for data in column_to_display_df.values:
#             column_to_display_dict[data[0]] = data[1]
#
#         return make_json_response(header_str=column_to_display_dict, data=lips_log_focus_df.to_dict(orient='index'))
#
#     def get(self):
#         return {}

# @AFC.route('')
# class AFCDefault(Resource):
#     @AFC.expect(afc_body)
#     @AFC.response(200, 'Success', afc_resp)
#     def post(self):
#         """
#         Plate Auto Focus Compensationログの分析を要請する。
#         """
#
#         # todo Key Check
#         success = 1
#         body = request.get_json()
#
#         # Start Service Process
#         afc_controller = AfcService(args=body)
#         ProcessManager.instance().append_proc(afc_controller)
#         afc_controller.start()
#         afc_controller.set_id(afc_controller.pid)
#
#         return make_json_response(success=success)


@ANALYSIS.route('/lists/<string:log_name>/<string:job_id>')
@ANALYSIS.param('job_id', 'Job ID')
@ANALYSIS.param('log_name', 'Log Name')
class AnalysisLists(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('one_period', help='期間の時間単位(1h, 2h, 4h, 6h, 12h, 24h, 1d～, 1m～)')
    parser.add_argument('adj_period', help='期間の節目(0h-23h, 1d-31d, 0d:first day of log_list)')
    parser.add_argument('list_group', help='グループ表示方式(job, none)')

    @ANALYSIS.expect(parser)
    @ANALYSIS.doc(model=analysis_list_response)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    @ANALYSIS.response(500, 'Internal Server Error')
    def get(self, log_name, job_id):
        """
        Logデータを期間/グループで分類してリストで返還するAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        # todo 파라미터 default값을 가져와서 설정해줘야한다.
        default_setting = get_default_setting(log_name)
        if args['one_period'] is None:
            args['one_period'] = default_setting['one_period']
        if args['adj_period'] is None:
            args['adj_period'] = default_setting['adj_period']
        if args['list_group'] is None:
            args['list_group'] = default_setting['list_group']

        # パラメータの妥当性チェック
        res, msg = parameter.is_period_valid(args['one_period'], args['adj_period'])
        if not res:
            return make_json_response(msg=msg, status=400)

        analysis = AnalysisService()
        res_form = analysis.get_list(log_name, job_id, args['one_period'], args['adj_period'], args['list_group'])
        if res_form.res:
            items = self.get_list_items().data
            for item in items:
                item['selected'] = args[item['target']]
                if item['mode'] == 'subItem':
                    item['subItem']['selected'] = args[item['subItem']['target']]
            return make_json_response(items=items, data=res_form.data)
        else:
            return make_json_response(status=500, msg=res_form.msg)

    def get_list_items(self):
        return ResponseForm(res=True, data=
        [
            {
                'target': 'one_period',
                'title': 'One Period',
                'type': 'select',
                'mode': 'subItem',
                'options': ['12h', '24h', '7d', '14d', '1m'],
                'subItem': {
                    'target': 'adj_period',
                    'title': 'Adjust Period',
                    'type': 'select',
                    'mode': 'singular',
                    'options': [
                        {'12h': ['0h', '1h', '2h', '3h', '4h', '5h', '6h', '7h', '8h', '9h', '10h', '11h',
                                 '12h', '13h', '14h', '15h', '16h', '17h', '18h', '19h', '20h', '21h', '22h',
                                 '23h']},
                        {'24h': ['0h', '1h', '2h', '3h', '4h', '5h', '6h', '7h', '8h', '9h', '10h', '11h',
                                 '12h', '13h', '14h', '15h', '16h', '17h', '18h', '19h', '20h', '21h', '22h',
                                 '23h']},
                        {
                            '7d': ['0d', '1d', '2d', '3d', '4d', '5d', '6d', '7d', '8d', '9d', '10d',
                                   '11d', '12d', '13d', '14d', '15d', '16d', '17d', '18d', '19d', '20d',
                                   '21d', '22d', '23d', '24d', '25d', '26d', '27d', '28d', '29d', '30d', '31d']
                        },
                        {
                            '14d': ['0d', '1d', '2d', '3d', '4d', '5d', '6d', '7d', '8d', '9d', '10d',
                                    '11d', '12d', '13d', '14d', '15d', '16d', '17d', '18d', '19d', '20d',
                                    '21d', '22d', '23d', '24d', '25d', '26d', '27d', '28d', '29d', '30d', '31d']
                        },
                        {
                            '1m': ['0d', '1d', '2d', '3d', '4d', '5d', '6d', '7d', '8d', '9d', '10d',
                                   '11d', '12d', '13d', '14d', '15d', '16d', '17d', '18d', '19d', '20d',
                                   '21d', '22d', '23d', '24d', '25d', '26d', '27d', '28d', '29d', '30d', '31d']
                        }
                    ],
                    'selected': None
                },
                'selected': None
            },
            {
                'target': 'list_group',
                'title': 'List Group',
                'type': 'select',
                'mode': 'singular',
                'options': ['job'],
                'selected': None
            }
        ])


@ANALYSIS.route('/summaries/<string:log_name>/<string:job_id>')
@ANALYSIS.param('job_id', 'Job ID')
@ANALYSIS.param('log_name', 'Log Name')
class AnalysisSummaries(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('jobname', help='選択したジョブ名')
    parser.add_argument('start', required=True, help='期間の開始時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('end', required=True, help='期間の終了時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('valid_interval_minutes', help='設定間隔(Min)未満の連続したLogデータをSKIP.')
    parser.add_argument('filter_key', help='Logのフィルタリング情報')
    parser.add_argument('filter_value', help='Logのフィルタリング値')
    parser.add_argument('group_by', help='統計演算を適用させるグループ情報')
    parser.add_argument('group_value', help='統計演算グループを分類する基準値')

    @ANALYSIS.expect(parser)
    @ANALYSIS.doc(model=analysis_summary_response)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(500, 'Internal Server Error')
    def get(self, job_id, log_name):
        """
        期間/グループ別LOGデータの分析結果を返還するAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        # job_name = args['jobname'] if 'jobname' in args else None
        # valid_interval_minutes = args['valid_interval_minutes'] if 'valid_interval_minutes' in args else None
        # stats_period = args['stats_period'] if 'stats_period' in args else None
        # filter_key = args['filter_key'] if 'filter_key' in args else None
        # filter_value = args['filter_value'] if 'filter_value' in args else None
        # group_by = args['group_by'] if 'group_by' in args else None

        # todo 파라미터 default값을 가져와서 설정해줘야한다.
        default_setting = get_default_setting(log_name)
        if args['valid_interval_minutes'] is None:
            args['valid_interval_minutes'] = default_setting['valid_interval_minutes']
        if args['filter_key'] is None:
            args['filter_key'] = default_setting['filter_key']
        if args['filter_value'] is None:
            args['filter_value'] = default_setting['filter_value']
        if args['group_by'] is None:
            args['group_by'] = default_setting['group_by']
        if args['group_value'] is None:
            args['group_value'] = default_setting['group_value']

        analysis = AnalysisService()

        res_form = analysis.get_summary(log_name, job_id, **args)
        if res_form.res:
            group_columns = analysis.get_group_avail_columns(log_name)
            filter_kv = analysis.get_filter_key_value(log_name)

            items = self.get_summary_items().data
            for item in items:
                item['selected'] = args[item['target']]
                if item['mode'] == 'subItem':
                    item['subItem']['selected'] = args[item['subItem']['target']]

                if item['target'] == 'group_by':
                    if len(group_columns) > 0:
                        item['options'].append('column')
                        item['subItem']['options'].append({'column': group_columns})

                if item['target'] == 'filter_key':
                    item['options'].extend(filter_kv['key'])
                    item['subItem']['options'].extend(filter_kv['value'])

            return make_json_response(items=items, data=res_form.data)
        else:
            return make_json_response(status=500, msg=res_form.msg)

    def get_summary_items(self):
        return ResponseForm(res=True, data=
        [
            {
                'target': 'valid_interval_minutes',
                'title': 'Valid Interval(Min)',
                'type': 'select',
                'mode': 'singular',
                'options': ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10',
                            '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
                            '21', '22', '23', '24', '25', '26', '27', '28', '29', '30',
                            '31', '32', '33', '34', '35', '36', '37', '38', '39', '40',
                            '41', '42', '43', '44', '45', '46', '47', '48', '49', '50',
                            '51', '52', '53', '54', '55', '56', '57', '58', '59', '60'],
                'selected': None
            },
            {
                'target': 'group_by',
                'title': 'Group By',
                'type': 'select',
                'mode': 'subItem',
                'options': ['period'],
                'subItem': {
                    'target': 'group_value',
                    'title': 'Group Value',
                    'type': 'select',
                    'mode': 'singular',
                    'options': [
                        {'period': ['1h', '2h', '4h']}
                    ],
                    'selected': None
                },
                'selected': None
            },
            {
                'target': 'filter_key',
                'title': 'Filter Key',
                'type': 'select',
                'mode': 'subItem',
                'options': [],
                'subItem': {
                    'target': 'filter_value',
                    'title': 'Filter Value',
                    'type': 'select',
                    'mode': 'singular',
                    'options': [],
                    'selected': None
                },
                'selected': None
            }
        ])


@ANALYSIS.route('/details/<string:log_name>/<string:job_id>')
@ANALYSIS.param('job_id', 'Job ID')
@ANALYSIS.param('log_name', 'Log Name')
class AnalysisDetail(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('jobname', help='選択したジョブ名')
    parser.add_argument('start', required=True, help='期間の開始時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('end', required=True, help='期間の終了時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('valid_interval_minutes', help='設定間隔(Min)未満の連続したLogデータをSKIP.')
    parser.add_argument('filter_key', help='Logのフィルタリング情報')
    parser.add_argument('filter_value', help='Logのフィルタリング値')
    parser.add_argument('group_by', required=True, help='統計演算を適用させるグループ情報')
    parser.add_argument('group_value', required=True, help='統計演算グループを分類する基準値')
    parser.add_argument('group_selected', required=True, help='選択されたグループ区分情報', action='append')

    @ANALYSIS.expect(parser)
    @ANALYSIS.doc(model=analysis_detail_response)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(500, 'Internal Server Error')
    def get(self, job_id, log_name):
        """
        期間/グループ別全体LOGデータを返還するAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        # job_name = args['jobname'] if 'jobname' in args else None
        # valid_interval_minutes = args['valid_interval_minutes'] if 'valid_interval_minutes' in args else None
        # stats_period = args['stats_period'] if 'stats_period' in args else None
        # filter_key = args['filter_key'] if 'filter_key' in args else None
        # filter_value = args['filter_value'] if 'filter_value' in args else None
        # group_by = args['group_by'] if 'group_by' in args else None

        analysis = AnalysisService()

        res_form = analysis.get_detail(log_name, job_id, **args)
        if res_form.res:
            return make_json_response(data=res_form.data)
        else:
            return make_json_response(status=500, msg=res_form.msg)


def get_default_setting(log_name):
    if log_name == 'PLATEAUTOFOCUSCOMPENSATION':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': 'job',
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'column', 'group_value': 'lot_id'}
    elif log_name == 'PRESCANCOMPENSATIONMONITOR':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': 'job',
                'valid_interval_minutes': None, 'filter_key': 'step_no', 'filter_value': '1',
                'group_by': 'column', 'group_value': 'lot_id'}
    elif log_name == 'LiPSFocus':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': None,
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'period', 'group_value': '4h'}
    elif log_name == 'TiltMeasurementLog':
        return {'one_period': '1m', 'adj_period': '0d', 'list_group': None,
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'period', 'group_value': '1d'}
    elif log_name == 'MountPressLog':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': None,
                'valid_interval_minutes': None, 'filter_key': 'status', 'filter_value': 'Job',
                'group_by': 'period', 'group_value': '4h'}


@ANALYSIS.route('/remote/<string:log_name>/<string:equipment_name>')
@ANALYSIS.param('log_name', 'Log Name')
@ANALYSIS.param('equipment_name', '装置名')
class AnalysisRemote(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('period', required=True, help='LOG取得期間(YYYY-MM-DD~YYYY-MM-DD)')

    @ANALYSIS.expect(parser)
    @ANALYSIS.doc(model=analysis_remote_response)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(500, 'Internal Server Error')
    def post(self, log_name, equipment_name):
        """
        遠隔LOGを取得して内部DBに格納する。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        if '~' not in args['period']:
            return make_json_response(status=500, msg='Please Check period. It must be contained "~"')

        [start, end] = args['period'].split('~')

        res_form = self.get_remote_log(log_name, equipment_name, start, end)
        if res_form.res:
            dao = DAOBaseClass(table_name='cnvbase.log_define')
            row = dao.fetch_one(args={'select': 'db_table', 'where': f"log_name='{log_name}'"})

            dao = DAOBaseClass(table_name=f'convert.{row[0]}')
            columns = dao.get_columns()

            buf = StringIO(res_form.data['data'])

            df = pd.read_csv(buf, sep='\t', names=columns)

            rid = create_request_id()
            df['request_id'] = rid

            dao.insert_from_stringio(df)

            return make_json_response(rid=rid)
        else:
            return make_json_response(status=500, msg=res_form.msg)

    def get_remote_log(self, log_name, equipment_name, start, end):
        try:
            dao_mgmt = DAOMGMTSetting()
            mgmt_df = dao_mgmt.fetch_all()
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

        db_remote_df = mgmt_df[mgmt_df['target'] == 'remote'].reset_index()
        isnull = db_remote_df['host'].isnull().values.any()
        if not isnull:
            host = db_remote_df['host'][0]
            while host[-1] == '/':
                host = host[:-1]

            url = host + app_config.API_GET_LOG + f'/{equipment_name}/{log_name}'
            params = {'start': start, 'end': end}

            try:
                response = requests.get(url, params=params)
                if response.status_code == 200:
                    return ResponseForm(res=True, data=response.json())
                else:
                    return ResponseForm(res=False, msg=response.text, status=response.status_code)

            except Exception as e:
                return ResponseForm(res=False, msg=str(e), status=400)

        else:
            return ResponseForm(res=False, msg='Set remote server info first.', status=400)