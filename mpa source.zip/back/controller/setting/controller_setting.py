import logging
from flask import request, Response
from flask_restx import Resource, Namespace, reqparse
import configparser
import requests

from config import app_config
from common.utils.response import make_json_response, ResponseForm
from dao.dao_base import DAOBaseClass
from dao.dao_management_setting import DAOMGMTSetting
from config.app_config import *
from dao import init_db

logger = logging.getLogger(app_config.LOG)

SETTING = Namespace(name='SETTING', description='Management Setting変更をためのAPI。')


@SETTING.route('/connection-check')
class SETTINGConnectionCheck(Resource):
    parser = SETTING.parser()
    parser.add_argument('host', required=True, help='test')
    parser.add_argument('port')
    parser.add_argument('username', dest='user')
    parser.add_argument('dbname')
    parser.add_argument('password')

    @SETTING.expect(parser)
    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def post(self):
        """
        Connection CheckのためのAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        if 'http://' in args['host'] or 'https://' in args['host']:
            while args['host'][-1] == '/':
                args['host'] = args['host'][:-1]

            url = args['host'] + API_GET_CONNECTION
            try:
                response = requests.get(url)
                if response.status_code == 200:
                    resp_form = ResponseForm(res=True, data=response.content)
                else:
                    resp_form = ResponseForm(res=False, msg=response.text, status=response.status_code)
            except Exception as e:
                resp_form = ResponseForm(res=False, msg=str(e), status=400)
        else:
            dao = DAOBaseClass(**args)
            resp_form = dao.connection_check()
        if resp_form.res:
            return make_json_response(data=resp_form.data)
        else:
            return make_json_response(status=resp_form.status, msg=resp_form.msg)


@SETTING.route('/local-database-info')
class SETTINGLocalDatabaseInfo(Resource):
    parser = SETTING.parser()
    parser.add_argument('host', required=True)
    parser.add_argument('port', required=True)
    parser.add_argument('username', required=True, dest='user')
    parser.add_argument('dbname', required=True)
    parser.add_argument('password', required=True)

    @SETTING.expect(parser)
    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def post(self):
        """
        Local Database Infoの変更を要請する。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        args['target'] = 'local'
        dao = DAOMGMTSetting(**args)
        res_form = dao.connection_check()

        if res_form.res:
            res_form = dao.update_db_setting(**args)
        else:
            return make_json_response(status=400, msg=res_form.msg)

        if res_form.res:
            db_config = configparser.ConfigParser()
            db_config.read(DB_CONFIG_PATH)

            db_config.set('DBSETTINGS', 'DB_NAME', args['dbname'])
            db_config.set('DBSETTINGS', 'DB_USER', args['user'])
            db_config.set('DBSETTINGS', 'DB_HOST', args['host'])
            db_config.set('DBSETTINGS', 'DB_PASSWORD', args['password'])
            db_config.set('DBSETTINGS', 'DB_PORT', args['port'])

            with open(DB_CONFIG_PATH, 'w') as configfile:
                db_config.write(configfile)

            init_db()
            return Response(status=200)
        else:
            return make_json_response(status=400, msg=res_form.msg)


@SETTING.route('/remote-server-info')
class SETTINGRemoteServerInfo(Resource):
    parser = SETTING.parser()
    parser.add_argument('host', required=True)

    @SETTING.expect(parser)
    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def post(self):
        """
        Remote Server Infoの変更を要請する。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        args['target'] = 'remote'
        dao_mgmt = DAOMGMTSetting()

        if 'http://' in args['host'] or 'https://' in args['host']:
            while args['host'][-1] == '/':
                args['host'] = args['host'][:-1]

            url = args['host'] + API_GET_CONNECTION
            try:
                response = requests.get(url)
                if response.status_code == 200:
                    resp_form = ResponseForm(res=True, data=response.content)
                else:
                    resp_form = ResponseForm(res=False, msg=response.text, status=response.status_code)
            except Exception as e:
                resp_form = ResponseForm(res=False, msg=str(e), status=400)
        else:
            resp_form = ResponseForm(res=False, msg='Host MUST be started with "http://" or "https://". ', status=400)

        if resp_form.res:
            res_form = dao_mgmt.update_db_setting(**args)
        else:
            return make_json_response(status=resp_form.status, msg=resp_form.msg)

        if res_form.res:
            return Response(status=200)
        else:
            return make_json_response(status=400, msg=res_form.msg)
