import datetime
import json
import os
import logging
from flask import Response, request, make_response, jsonify
from flask_restx import Resource, Namespace
from config import app_config
from dao.dao_base_server import BaseServerDao
from dao.dao_rc import RapidCollectorDao
from service.converter.exception import RapidConnectionError
from service.converter.rapidconnector import RapidConnector

log = logging.getLogger(app_config.LOG)

Rapid = Namespace('Rapid')


@Rapid.route('/plan')
class RapidCollectorGetPlanList(Resource):
    def get(self):
        log.info(f'{request.method} {request.path}')
        config = {
            'host': request.args.get('host', type=str),
            'port': request.args.get('port', default=80, type=int),
            'user': request.args.get('user', type=str),
            'password': request.args.get('pass', type=str)
        }
        bad_param = [_bad for _bad in config if config[_bad] is None]
        if len(bad_param):
            return Response(status=400, response='parameter error')

        connector = RapidConnector(config)
        plans = connector.get_plans()
        response = make_response(jsonify(plans), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@Rapid.route('/machine')
class RapidCollectorGetMachineList(Resource):
    # This API will be deprecated.
    # It's planning that all information about equipments(machines) will be got from rapid collector.
    # Rapid collector doesn't supply enough information to fill the equipments table for now,
    # So it services 2 API ('/rc/machine' and '/rc/equipment') at first.
    def get(self):
        log.info(f'{request.method} {request.path}')
        config = {
            'host': request.args.get('host', type=str),
            'port': request.args.get('port', default=80, type=int),
            'user': request.args.get('user', type=str),
            'password': request.args.get('pass', type=str)
        }
        bad_param = [_bad for _bad in config if config[_bad] is None]
        if len(bad_param):
            return Response(status=400, response='parameter error')

        connector = RapidConnector(config)
        machines = connector.get_machines()
        response = make_response(jsonify(machines), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@Rapid.route('/equipment')
class RapidCollectorGetEquipment(Resource):
    def get(self):
        log.info(f'{request.method} {request.path}')
        site = request.args.get('site', type=str, default=None)
        fab = request.args.get('fab', type=str, default=None)
        equipments = BaseServerDao.instance().get_equipments(site=site, fab=fab)
        response = make_response(jsonify(equipments), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@Rapid.route('/valid')
class RapidCollectorConnectionCheck(Resource):
    def get(self):
        log.info(f'{request.method} {request.path}')
        config = {
            'host': request.args.get('host', type=str),
            'port': request.args.get('port', default=80, type=int),
            'user': request.args.get('user', type=str),
            'password': request.args.get('pass', type=str)
        }
        try:
            connect = RapidConnector(config)
            if connect.me():
                return Response(status=200)
        except RapidConnectionError as msg:
            return Response(status=500, response=msg)


