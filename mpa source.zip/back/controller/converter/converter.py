import datetime
import json
import os
import logging
from flask import Response, request, make_response, jsonify
from flask_restx import Resource, Namespace
from werkzeug.utils import secure_filename

from config.cras_config import CONVERTER_ROOT
from dao.dao_base_server import BaseServerDao
from dao.dao_convert import ConvertDao
from dao.dao_file import FileDao
from dao.dao_job import DAOJob, DatabaseQueryException
from dao.dao_rc import RapidCollectorDao
from dao.utils import exist_table, get_datetime, get_date_string
from service.converter.convert_process import create_convert_process
from config import app_config
from service.converter.rapidconnector import RapidConnector

logger = logging.getLogger(app_config.LOG)

CONVERTER = Namespace('CONVERTER')


@CONVERTER.route('/rc/collect')
class RapidCollectorStartController(Resource):
    def post(self):
        param = json.loads(request.get_data())
        try:
            plan_id = ','.join([str(_id).strip() for _id in param['plan_id']])
            form = {
                'addr': param['addr'].strip(),
                'port': param['port'],
                'username': param['user'].strip(),
                'pass': param['pass'].strip(),
                'plans': plan_id
            }
            io = RapidCollectorDao.instance().set_config(form)
        except KeyError as msg:
            response = 'parameter error (%s)' % msg
            return Response(status=400, response=response)
        return Response(status=200)

    def get(self):
        info = RapidCollectorDao.instance().get_config()
        if info is None:
            return Response(status=400, response='no info')
        print('done')


@CONVERTER.route('/rc/status')
class RapidCollectorStatusController(Resource):
    def get(self):
        status = RapidCollectorDao.instance().get_status()
        if status is None:
            return Response(400)
        status['plan_id'] = [int(_id) for _id in status['plans'].split(',')]
        response = make_response(jsonify(status), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@CONVERTER.route('/rc/plan')
class RapidCollectorGetPlanList(Resource):
    def get(self):
        logger.info(f'{request.method} {request.path}')
        config = {
            'host': request.args.get('host', type=str),
            'port': request.args.get('port', default=80, type=int),
            'user': request.args.get('user', type=str),
            'password': request.args.get('pass', type=str)
        }
        bad_param = [_bad for _bad in config if config[_bad] is None]
        if len(bad_param):
            return Response(status=400, response='parameter error')

        connector = RapidConnector(config)
        plans = connector.get_plans()
        response = make_response(jsonify(plans), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@CONVERTER.route('/rc/machine')
class RapidCollectorGetMachineList(Resource):
    # This API will be deprecated.
    # It's planning that all information about equipments(machines) will be got from rapid collector.
    # Rapid collector doesn't supply enough information to fill the equipments table for now,
    # So it services 2 API ('/rc/machine' and '/rc/equipment') at first.
    def get(self):
        logger.info(f'{request.method} {request.path}')
        config = {
            'host': request.args.get('host', type=str),
            'port': request.args.get('port', default=80, type=int),
            'user': request.args.get('user', type=str),
            'password': request.args.get('pass', type=str)
        }
        bad_param = [_bad for _bad in config if config[_bad] is None]
        if len(bad_param):
            return Response(status=400, response='parameter error')

        connector = RapidConnector(config)
        machines = connector.get_machines()
        response = make_response(jsonify(machines), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@CONVERTER.route('/rc/equipment')
class RapidCollectorGetEquipment(Resource):
    def get(self):
        logger.info(f'{request.method} {request.path}')
        site = request.args.get('site', type=str, default=None)
        fab = request.args.get('fab', type=str, default=None)
        equipments = BaseServerDao.instance().get_equipments(site=site, fab=fab)
        response = make_response(jsonify(equipments), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@CONVERTER.route('/table/<string:table_name>')
class ConvertTableInfo(Resource):
    def get(self, table_name):
        logger.info(f'{request.method} {request.path}')
        info = BaseServerDao.instance().get_table_info(table_name)
        if info is None:
            return Response(status=404)
        _body = {
            'start': '2020-01-01 00:00:00',
            'end': '2021-02-02 02:02:02',
            'rows': 5000
        }
        response = make_response(jsonify(_body), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@CONVERTER.route('/job')
class ConvertJobRequestController(Resource):

    def post(self):
        logger.info(f'{request.method} {request.path}')
        param = json.loads(request.get_data())
        try:
            form = compose_request_form(**param)
            if form is None:
                raise ConvertInvalidRequest('failed to create request form')
            io = DAOJob.instance()
            try:
                io.insert_job(**form)
            except DatabaseQueryException:
                logger.error('failed to insert job')
                return Response(status=400)
            logger.info('job submitted (id=%s)' % form['id'])
            process = create_convert_process(form['id'])

            # Create a response
            body = {'rid': form['id']}
            if form['job_type'] == 'rapid':
                body = {**body, 'total-zip-files': len(process.download_list)}
            elif form['job_type'] == 'local':
                pass
            else:
                raise ConvertInvalidRequest('hmm!?')

            response = make_response(jsonify(body), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        except ConvertInvalidRequest as msg:
            return Response(status=500, response=msg)
        except RapidLogNotExist as msg:
            return Response(status=204, response=msg)

        return Response(status=400)


@CONVERTER.route('/job/<string:rid>')
class ConvertJobHandleController(Resource):
    def get(self, rid):
        logger.info(f'{request.method} {request.path}')
        detail = request.args.get('detail', False, bool)
        io = DAOJob.instance()
        info = io.get_job_info(rid, detail)
        if info is None:
            logger.error(f'invalid rid {rid}')
            return Response(status=500)
        response = make_response(jsonify(info), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response

    def delete(self, rid):
        logger.info(f'{request.method} {request.path}')
        try:
            io = DAOJob.instance()
            job = io.get_job(rid)
            if job['status'] != 'success':
                io.change_job_status(rid, 'cancel')
        except DatabaseQueryException as msg:
            logger.error(f'failed to cancel job {rid}')
            return Response(status=500)
        return Response(status=200)


@CONVERTER.route('/file')
class ConvertFileUpload(Resource):
    root_path = '.files'

    def post(self):
        logger.info(f'{request.method} {request.path}')
        if not os.path.exists(self.root_path):
            os.mkdir(self.root_path)
        files = request.files.getlist('files')
        fid_list = []
        for file in files:
            filename = secure_filename(file.filename)
            f = None
            file_index = 1
            while f is None or os.path.exists(f):
                _filename = f'{file_index}____{filename}'
                f = os.path.join(self.root_path, _filename)
                file_index += 1
            file.save(f)
            fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))
            if fid is None:
                logger.error('failed to store file info')
                return Response(status=500)
            fid_list.append(fid)

        response = make_response(jsonify({'fid': fid_list}), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@CONVERTER.route('/history')
class ConvertHistoryList(Resource):
    def get(self):
        try:
            io = DAOJob.instance().get_history_list()
            response = make_response(jsonify(io), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        except Exception as msg:
            logger.error(f'failed to query. {msg}')
        return Response(status=500)


@CONVERTER.route('/history/<string:rid>')
class ConvertHistory(Resource):
    def get(self, rid):
        io = DAOJob.instance()
        job = io.get_job(rid)
        if job is None:
            logger.error(f'invalid rid {rid}')
            return Response(status=500)
        history = io.get_history_list(rid)
        if history is None:
            logger.error(f"invalid history {rid}")
            return Response(status=500)
        detail_file = os.path.join(CONVERTER_ROOT, rid, f'{rid}.log')
        if not os.path.exists(detail_file):
            logger.error(f'detail history is not exist')
            return Response(status=400)
        with open(detail_file, 'r', encoding='utf-8') as f:
            response = make_response(f.read(), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response
        return Response(status=400)


@CONVERTER.route('/log/<string:log_name>')
@CONVERTER.param('log_name', 'Log name what you get information about.')
class ConvertGetLogInfo(Resource):
    parser = CONVERTER.parser()
    parser.add_argument('equipment', required=False, help='When you specific this, the server returns information \
                                                          only about the specific equipment.')

    @CONVERTER.doc(responses={
        200: 'Success',
        400: 'Internal server error',
        500: 'Parameter error'
    })
    def get(self, log_name):
        logger.info(f'{request.method} {request.path}')
        param = self.parser.parse_args()
        log_define = BaseServerDao.instance().get_log_define(log_name)
        if log_define is None:
            return Response(status=500)
        table = log_define['db_table']
        if not exist_table(table, 'convert'):
            return Response(status=400)
        info = ConvertDao.instance().get_log_info(table, param['equipment'])
        if info is None:
            response = make_response({'count': 0}, 200)
        else:
            response = make_response(info, 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@CONVERTER.route('/log/dump/<string:log_name>')
class ConvertGetConvertedLog(Resource):
    parser = CONVERTER.parser()
    parser.add_argument('start', required=True, help='Dump starting time.')
    parser.add_argument('end', required=True, help='Dump end time.')
    parser.add_argument('equipment', required=False, help='When you specific this, the server returns information \
                                                              only about the specific equipment.')

    @CONVERTER.doc(responses={
        200: 'Success',
        400: 'Internal server error',
        500: 'Parameter error'
    })
    def get(self, log_name):
        logger.info(f'{request.method} {request.path}')
        param = self.parser.parse_args()
        log_define = BaseServerDao.instance().get_log_define(log_name)
        if log_define is None:
            return Response(status=500)
        table = log_define['db_table']
        if not exist_table(table, 'convert'):
            return Response(status=400)
        start = get_datetime(param['start'])
        end = get_datetime(param['end'])
        end = end.replace(hour=23, minute=59, second=59)
        dump = ConvertDao.instance().get_converted_data(table, start, end, param['equipment'])
        response = make_response({'data': dump}, 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


class ConvertInvalidRequest(Exception):
    pass


class RapidCollectorConnectionError(Exception):
    pass


class RapidLogNotExist(Exception):
    pass


def create_request_id():
    now = datetime.datetime.now()
    return now.strftime("request_%Y%m%d_%H%M%S%f")


def compose_request_form(**param):
    fa = {
        'local': compose_local_request_form,
        'rapid': compose_rapid_request_form
    }
    if 'source' not in param or param['source'] not in fa:
        raise ConvertInvalidRequest('invalid request (source)')
    form = fa[param['source']](**param)
    if form is None:
        return None
    form = {
        **form,
        'id': create_request_id(),
        'job_type': param['source']
    }
    return form


def compose_local_request_form(**param):
    logger.info('compose_local_request_form')
    if 'file' not in param:
        raise ConvertInvalidRequest('invalid request (target_path)')
    fio = FileDao.instance()
    if not fio.exists(param['file']):
        raise ConvertInvalidRequest(f"invalid file id in {param['file']}")
    form = {
        'file': ','.join([str(_) for _ in param['file']])
    }

    # When there aren't 'equipment_type' and 'log_name', It has to get these from file name.
    # To find a equipment and a log name, it refers some information from rapid-collector.
    if 'equipment_type' not in param or 'log_name' not in param:
        rapid_info = param['config']
        _rapid = json.dumps({
            'host': rapid_info['host'],
            'port': int(rapid_info['port']),
            'user': rapid_info['user'],
            'password': rapid_info['password']
        })
        return {
            **form,
            'equipment_names': '',
            'log_name': '',
            'rapid_info': _rapid
        }

    sio = BaseServerDao.instance()
    equipments = sio.get_equipments(equipment_type=param['equipment_type'], df=True)
    if equipments is None or len(equipments) == 0:
        raise ConvertInvalidRequest('equipment_type error')
    equipments = equipments.drop_duplicates(['log_header_type', 'old_log_type'])

    return {
        **form,
        'equipment_names': ','.join([_ for _ in equipments['equipment_name']]),
        'log_name': param['log_name']
    }


def compose_rapid_request_form(**param):
    try:
        if 'site' in param:
            site = param['site']
        else:
            site = os.environ.get('CRAS_SITE_NAME')
        if site is None:
            logger.error('no site name')
            return None
        rapid_info = param['config']
        plan_id = ','.join([str(_id).strip() for _id in param['plan_id']])
        logger.info(f"rapid host={rapid_info['host']}:{rapid_info['port']} plan={plan_id}")
        collect_start = get_datetime(param['created']) - datetime.timedelta(param['before'])
        logger.info(f'collect_start={collect_start}')

        _rapid = json.dumps({
            'host': rapid_info['host'],
            'port': int(rapid_info['port']),
            'user': rapid_info['user'],
            'password': rapid_info['password'],
            'collect_start': get_date_string(collect_start),
            'plan_id': param['plan_id']
        })

        log_exist = False
        connect = RapidConnector(rapid_info)
        for pid in param['plan_id']:
            _list = connect.get_download_list(pid)
            if _list is None or len(_list) == 0:
                continue
            for _item in _list:
                item_date = get_datetime(_item['created'])
                if collect_start <= item_date:
                    log_exist = True
                    break
            else:
                continue
            break

        if not log_exist:
            raise RapidLogNotExist('no logs')

        return {'rapid_info': _rapid, 'site': site}
    except KeyError as msg:
        logger.error(f'parameter error ({msg})')
    return None
