import base64
import logging
import io
import os
import zipfile
from flask import request, Response
from flask_restx import Resource, Namespace, fields
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

from config import app_config
from common.utils.response import make_json_response
from dao.dao_base import DAOBaseClass

logger = logging.getLogger(app_config.LOG)

EXPORT = Namespace(name='EXPORT', description='ログ変換に関連した設定情報のExport用API')

export_response = EXPORT.model('export_table_response', {
    'version': fields.String(description='description', example='example')
})


@EXPORT.route('/table')
class ExportTableDefault(Resource):
    @EXPORT.response(200, 'Success')
    @EXPORT.response(500, 'Internal Server Error')
    def get(self):
        """
        CNVBASE SchemaのテーブルデータをZIP圧縮ファイルで生成する。
        """
        logger.info(str(request))

        dao = DAOBaseClass()

        resp_form = dao.export_tables_from_schema(app_config.SCHEMA_EXPORT_LIST)
        if resp_form.res:
            try:
                archive = io.BytesIO()

                with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as zip_archive:
                    for key, buffer in resp_form.data.items():
                        zip_archive.writestr(key+'.csv', buffer.getvalue())
            except Exception as e:
                return Response(status=500)

            return Response(archive.getvalue(), headers={
                'Content-Type': 'application/zip',
                'Content-Disposition': 'attachment; filename=%s;' % 'export.zip'
            })
        else:
            return make_json_response(status=500, msg=resp_form.msg)


@EXPORT.route('')
class ExportDefault(Resource):
    parser = EXPORT.parser()
    parser.add_argument('files', type=FileStorage, location='files', required=True, help='FILE名', action='append')

    @EXPORT.expect(parser)
    @EXPORT.doc(model=export_response)
    @EXPORT.response(200, 'Success')
    @EXPORT.response(500, 'Internal Server Error')
    def post(self):
        """
        tableデータとグラフ イメージのExportを実施する。
        """
        logger.info(str(request))

        # files = request.form.getlist('files')
        # print(files)
        args = self.parser.parse_args()
        files = args['files']

        try:
            archive = io.BytesIO()

            with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as zip_archive:
                for file in files:
                    filename = file.filename
                    raw = file.read()

                    filename = filename.split(sep='.')
                    folder = filename[0]
                    extension = filename[-1]
                    filename = '.'.join(filename[1:]).replace('/', '_')

                    if extension == 'png':
                        raw = raw.replace(b'data:image/png;base64,', b'')
                        raw = base64.b64decode(raw)

                    zip_archive.writestr(os.path.join(folder, filename), raw)

            # with open('my_file.zip', 'wb') as f_out:
            #     f_out.write(archive.getvalue())

        except Exception as e:
            return Response(status=500)

        return Response(archive.getvalue(), headers={
            'Content-Type': 'application/zip',
            'Content-Disposition': 'attachment; filename=%s;' % 'export.zip'
        })

