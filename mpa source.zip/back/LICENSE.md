# Open Source Software(OSS) Notice

## PostgreSQL
- Version : 10.16
- License : PostgreSQL License
- https://www.postgresql.org/about/licence/

## Python
- Version : 3.9.4
- License : PSF
- https://docs.python.org/3/license.html


### Python Dependencies

| Name            | Version   | License                                             | URL                                         |
|-----------------|-----------|-----------------------------------------------------|---------------------------------------------|
| Flask           | 1.1.2     | BSD License                                         | https://flask.palletsprojects.com/en/1.1.x/license/ |
| Jinja2          | 2.11.3    | BSD License                                         | https://palletsprojects.com/p/jinja/        |
| MarkupSafe      | 1.1.1     | BSD License                                         | https://palletsprojects.com/p/markupsafe/   |
| Werkzeug        | 1.0.1     | BSD License                                         | https://github.com/pallets/werkzeug/blob/master/LICENSE.rst|
| aniso8601       | 9.0.1     | BSD License                                         | https://bitbucket.org/nielsenb/aniso8601    |
| attrs           | 20.3.0    | MIT License                                         | https://www.attrs.org/                      |
| certifi         | 2020.12.5 | Mozilla Public License 2.0 (MPL 2.0)                | https://certifiio.readthedocs.io/en/latest/ |
| chardet         | 4.0.0     | GNU Library or Lesser General Public License (LGPL) | https://github.com/chardet/chardet          |
| click           | 7.1.2     | BSD License                                         | https://palletsprojects.com/p/click/        |
| flask-restx     | 0.3.0     | BSD License                                         | https://github.com/python-restx/flask-restx/blob/master/LICENSE|
| idna            | 2.10      | BSD License                                         | https://github.com/kjd/idna                 |
| itsdangerous    | 1.1.0     | BSD License                                         | https://palletsprojects.com/p/itsdangerous/ |
| jsonschema      | 3.2.0     | MIT License                                         | https://github.com/Julian/jsonschema        |
| numpy           | 1.20.2    | BSD License                                         | https://numpy.org/doc/stable/license.html   |
| pandas          | 1.2.3     | BSD                                                 | https://pandas.pydata.org/docs/getting_started/overview.html|
| psycopg2        | 2.8.6     | GNU Library or Lesser General Public License (LGPL) | https://www.psycopg.org/license/            |
| pyrsistent      | 0.17.3    | MIT License                                         | http://github.com/tobgu/pyrsistent/         |
| python-dateutil | 2.8.1     | BSD License, Apache Software License                | https://dateutil.readthedocs.io             |
| pytz            | 2021.1    | MIT License                                         | http://pythonhosted.org/pytz                |
| requests        | 2.25.1    | Apache Software License                             | https://requests.readthedocs.io             |
| simplejson      | 3.17.2    | MIT License, Academic Free License (AFL)            | https://github.com/simplejson/simplejson/blob/master/LICENSE.txt|
| six             | 1.15.0    | MIT License                                         | https://github.com/benjaminp/six            |
| urllib3         | 1.26.4    | MIT License                                         | https://urllib3.readthedocs.io/             |

## React
- Version : 
- License : MIT License
- https://github.com/facebook/react/blob/master/LICENSE