﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnalysisTool_Launcher
{
    public partial class SplashScreen : Form
    {
        Timer tmr;
        Process process;

        public SplashScreen()
        {
            InitializeComponent();

            this.Load += TrayIcon_Load;

            FormClosing += new FormClosingEventHandler(closing);
            FormClosing += new FormClosingEventHandler(TrayIcon_Dispose);

            LaunchAnalysisTool();            
        }

        private void LaunchAnalysisTool()
        {
            var psi = new ProcessStartInfo();
            psi.FileName = @"D:\Project\mpaanalysistool_master\back\venv\Scripts\python.exe"; //파이썬 설치 경로
            psi.Arguments = $"\"D:\\Project\\mpaanalysistool_master\\back\\main.py\" \"release\""; //파일경로            
            //psi.Arguments = $"\"D:\\Project\\mpaanalysistool_master\\back\\flaskapp\\test.py\"";

            // Proecss configuration
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;

            process = Process.Start(psi);
            /*var errors = "";
            var results = "";

            using (var process = Process.Start(psi))
            {
                errors = process.StandardError.ReadToEnd();
                results = process.StandardOutput.ReadToEnd();
            }

            MessageBox.Show(results);*/
        }

        private void LaunchBrowser()
        {
            System.Diagnostics.Process.Start("http://localhost:5000/main");
        }

        public void TrayIcon_Load(object sender, EventArgs e)
        {
            Tray_Icon.ContextMenuStrip = Context_TrayIcon;
        }

        private void closing(object sender, FormClosingEventArgs e)
        {
            process.Kill();
        }

        public void TrayIcon_Dispose(object sender, FormClosingEventArgs e)
        {
            Tray_Icon.Dispose();
        }

        private void SplashScreen_Shown(object sender, EventArgs e)
        {
            tmr = new Timer();

            //set time interval 3 sec
            tmr.Interval = 3000;

            //starts the timer
            tmr.Start();
            tmr.Tick += tmr_Tick;
        }

        void tmr_Tick(object sender, EventArgs e)
        {
            //after 3 sec stop the timer
            //tmr.Stop();

            //hide this form
            //this.Hide();


            if(IsAddressRunning("http://localhost:5000/main") == true)
            {
                tmr.Stop();
                this.Hide();
                LaunchBrowser();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public bool IsAddressRunning(string address)
        {
            try
            {
                WebClient webClient = new WebClient();
                webClient.DownloadData(address);
                webClient.Dispose();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
