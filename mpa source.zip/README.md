# 개발환경
- Node 버전 : v14.15.3
- yarn 버전 : v1.22.5
- python 버전 : 3.7+
- PostgreSQL : 10.16

# Frontend
## 패키지 설치
1. 소스를 클론받는다.
2. IntelliJ를 열어 front폴더를 Workspace로 지정해서 Open한다.
3. 커맨드 창에서 `yarn` 명령어를 입력해서 필요 패키지들을 설치한다.

> Error: unable to verify the first certificate

와 같은 에러 발생 시,  `set NODE_TLS_REJECT_UNAUTHORIZED=0`을 입력하고 다시 설치한다.

## 실행 스크립트
1. `yarn start` : 개발 모드
2. `yarn build` : 'back/web/static'폴더에 배포용 패키징 js파일 생성
 
## IntelliJ 설정적용
http://10.1.9.22:9080/product/mpaanalysistool/wikis/Settings/IntelliJ/ESLint-Prettier 참고

# Backend
## 패키지 설치
1. 소스를 클론받는다.
2. Pycharm을 열어 back폴더를 Workspace로 지정해서 Open한다.
3. Pycharm에서 가상환경을 설정해준다.
4. Pycharm 커맨드 창에서 아래 명령어를 입력한다.

`pip install --trusted-host pypi.python.org --trusted-host pypi.org --trusted-host files.pythonhosted.org -r requirements.txt`

5. main.py를 Run해서 어플리케이션을 기동한다.
6. d


# Launcher App
1. 소스를 클론 받는다.
2. Visual Studio 2019를 열어 Launcher App내의 프로젝트 솔루션 파일을 Open한다.
