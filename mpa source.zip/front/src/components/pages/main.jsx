import React, { useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBinoculars } from '@fortawesome/free-solid-svg-icons';
import AppLayout from '../templates/mainLayout';
import NaviBar from '../UI/molecules/NaviBar';
import { css } from '@emotion/react';
import TitleBar from '../UI/molecules/TitleBar/TitleBar';
import MainPageItem from '../UI/molecules/MainPageItem/MainPageItem';
import VersionInfo from '../UI/atoms/Version';
import Button from '../UI/atoms/Button/Button';
import MgmtPage from '../pages/mgmt';
import { Spin } from 'antd';
import Divider from '../UI/atoms/Divider';
import { Switch, Route } from 'react-router-dom';
import JobCreatePage from './focus';
import PropTypes from 'prop-types';
import Error from './error';
import { getVersionInfo, getMainInfo } from '../../lib/api/axios/requests';
import useBasicJob from '../../hooks/useBasicInfo';
import JobStatusPage from '../pages/focus/jobStatus';

const titleStyle = css`
  color: black;
  z-index: 300;
  font-weight: 400;
  font-size: 44px;
  text-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  margin-bottom: 22px;
  margin-top: 22px;
`;

const itemWrapper = css`
  margin: 2rem 0;
  display: flex;
  & > div + div {
    margin-left: 4.9rem;
  }
`;

const buttonWrapper = css`
  position: fixed;
  bottom: 110px;
  right: 50px;
  z-index: 300;
`;

const DefaultPage = ({ info, selectJob }) => {
  const jobSelect = (url) => {
    console.log('jobSelect', url);
    selectJob(url);
  };

  return info.map((menu, i) => {
    return (
      <div key={i}>
        <TitleBar text={menu.title} />
        <div css={itemWrapper}>
          {menu.subfunc.map((submenu, idx) => {
            return (
              <MainPageItem
                key={idx}
                mainText={submenu.title}
                subText={submenu.midTitle}
                buttonText={submenu.btnTitle}
                onClick={() => jobSelect(submenu.url)}
              />
            );
          })}
        </div>
        <Divider />
      </div>
    );
  });
};

DefaultPage.propTypes = {
  info: PropTypes.array,
  selectJob: PropTypes.func,
};

const MainPage = () => {
  const {
    isErrorStatus,
    setErrorStatus,
    isLoading,
    loadStart,
    loadCompleted,
    setBasicInfo,
    ToolInfo,
    MenuInfo,
    showMgmt,
    openMgmtPage,
    closeMgmtPage,
    JobUrl,
    selectJobUrl,
    clearJobUrl,
  } = useBasicJob();

  useEffect(() => {
    const fetchInfos = async () => {
      loadStart();
      try {
        const tool = await getVersionInfo();
        const menu = await getMainInfo();
        setBasicInfo(tool, menu);
      } catch (e) {
        console.log(e);
        setErrorStatus(e);
      }
      loadCompleted();
    };
    fetchInfos().then(console.log('==MainPage Load completed===='));
  }, []);

  if (isLoading)
    return (
      <div>
        <Spin tip="Loading..." size="large" />
      </div>
    );

  if (isErrorStatus)
    return (
      <div>
        <p>error occurred</p>
        <p>{isErrorStatus}</p>
      </div>
    );

  if (ToolInfo == null || MenuInfo == null) return <div>no data</div>;

  const { title, navibar, body, footer } = MenuInfo;

  return (
    <>
      <AppLayout>
        <AppLayout.Header>
          <p css={titleStyle}>{title}</p>
          <NaviBar data={navibar} />
        </AppLayout.Header>
        <AppLayout.Content>
          <Switch>
            <>
              <Route exact path={'/main'}>
                <DefaultPage info={body} selectJob={selectJobUrl} />
              </Route>
              <Route path={'/job'}>
                <JobStatusPage />
              </Route>
              <Route path={'/main'} component={Error.notfound} />
            </>
          </Switch>
        </AppLayout.Content>
        <AppLayout.Footer>
          <VersionInfo footer={footer} info={ToolInfo} />
        </AppLayout.Footer>
        <div css={buttonWrapper}>
          <Button iconOnly size="md" onClick={openMgmtPage}>
            <FontAwesomeIcon icon={faBinoculars} />
          </Button>
        </div>
        <MgmtPage show={showMgmt} closeFunc={closeMgmtPage} />
        <JobCreatePage JobUrl={JobUrl} clearJobUrl={clearJobUrl} />
      </AppLayout>
    </>
  );
};

export default MainPage;
