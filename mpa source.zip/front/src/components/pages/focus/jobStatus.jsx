import React, { useEffect, useState, useCallback } from 'react';
import { Layout, Menu, Breadcrumb, Empty, Tabs, Popover, Tooltip } from 'antd';
import { css } from '@emotion/react';
import {
  CloudDownloadOutlined,
  SlidersOutlined,
  ClockCircleOutlined,
  SettingOutlined,
} from '@ant-design/icons';
import useJobStatus from '../../../hooks/useJobStatus';
import {
  getFocusJobList,
  getSummaryData,
  getDetailData,
  updateFocusJobList,
} from '../../../lib/api/axios/requests';
import SideBar from '../../UI/atoms/SideBar';
import FocusTable from '../../UI/molecules/FocusTable';
import FocusGraph from '../../UI/molecules/FocusGraph';
import Button from '../../UI/atoms/Button';
import InputForm from '../../UI/atoms/Input/InputForm';
import { getParseJsonData } from '../../../lib/util/Util';
import { useLocation } from 'react-router';
import { Export } from '../../UI/organisms';

const { SubMenu } = Menu;
const { Content } = Layout;
const { TabPane } = Tabs;

const contentWrapper = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100%;
  & > div + div {
    margin-top: 1rem;
  }
`;
const controlStyle = css`
  position: absolute;
  top: 24px;
  right: 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  z-index: 1;
  width: 200px;
`;

const JobStatusPage = () => {
  const [isLoading, setLoading] = useState(false);
  const [isError, setError] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [isExport, setExport] = useState(false);
  const {
    JobList,
    setJobListInfo,
    sItems,
    settingItems,
    detailJobInfo,
    setDetailJobInfo,
  } = useJobStatus();

  const locationHook = useLocation();

  const { log_name, job_id } = locationHook.state;
  const [activeTab, setActiveTab] = useState('1');
  const [summaryData, setSummaryData] = useState(null);
  const [detailData, setDetailData] = useState(null);
  const [detailItems, setDetailItems] = useState({
    title: null,
    option: [],
    value: [],
  });
  const [title, setTitle] = useState({
    summary: null,
    detail: null,
  });
  const [detailParam, setDetailParam] = useState({
    groupBy: null,
    groupValue: null,
    selectedRows: [],
    startDate: null,
    endDate: null,
    jobName: null,
  });

  useEffect(async () => {
    try {
      const { data, items } = await getFocusJobList(
        log_name, //'PLATEAUTOFOCUSCOMPENSATION',
        job_id, //'request_20210507_154236212408',
      ).then(console.log('=============JobStatusPage load completed========'));
      items.map((obj) => {
        obj.mode === 'subItem'
          ? setDetailJobInfo((prevState) => ({
              ...prevState,
              [obj.target]: obj.selected,
              [obj.subItem.target]: obj.subItem.selected,
            }))
          : setDetailJobInfo((prevState) => ({
              ...prevState,
              [obj.target]: obj.selected,
            }));
      });
      setJobListInfo(data);
      settingItems(items);
    } catch (e) {
      console.log(e);
      setError(e);
    }
    setLoading(false);
  }, []);

  const drawSummary = async (jobName, startDate, endDate) => {
    const { items, data } = await getSummaryData(
      log_name,
      job_id,
      jobName,
      startDate,
      endDate,
    );
    const graphData = createGraphData(data, 'Date');

    Object.keys(items).map((key) => {
      if (items[key].target === 'group_by') {
        setDetailParam((prevState) => {
          return {
            ...prevState,
            groupBy: items[key].selected,
            groupValue: items[key].subItem.selected,
            jobName: jobName,
            startDate: startDate,
            endDate: endDate,
          };
        });

        setDetailItems((prevState) => {
          return {
            ...prevState,
            title: items[key].selected === 'column' ? 'Column' : 'Period',
          };
        });
      }
    });

    setTitle((prevState) => {
      return {
        ...prevState,
        summary:
          jobName !== null
            ? `${startDate} ~ ${endDate} (${jobName})`
            : `${startDate} ~ ${endDate}`,
      };
    });

    setSummaryData({
      ...data,
      graphData,
    });
    setDetailData(null);
    setActiveTab('1');
  };

  const drawDetail = async (params) => {
    const { data } = await getDetailData(log_name, job_id, params);
    const { startDate, endDate, jobName } = params;
    const graphData = createGraphData(
      data,
      detailParam.groupBy === 'column' ? 'lot_id' : 'log_time',
    );

    setTitle((prevState) => {
      return {
        ...prevState,
        detail:
          jobName !== null
            ? `${startDate} ~ ${endDate} (${jobName})`
            : `${startDate} ~ ${endDate}`,
      };
    });

    setDetailData({
      ...data,
      graphData,
    });
    setActiveTab('2');
  };

  const changeTab = useCallback((key) => {
    setActiveTab(key);
  }, []);

  const changeProc = async (event) => {
    const item = getParseJsonData(event);
    console.log('item', item);
    item.map((obj) => {
      if (obj.id !== undefined) {
        setDetailJobInfo((prevState) => ({
          ...prevState,
          [obj.id]: obj.value,
        }));
      }
    });
  };

  useEffect(async () => {
    if (isLoading === false) {
      try {
        const { data, status } = await updateFocusJobList(
          log_name, //'PLATEAUTOFOCUSCOMPENSATION',
          job_id, //'request_20210507_154236212408',
          detailJobInfo,
        ).then(console.log('=============JobList update completed========'));
        if (status === 'OK') {
          console.log('jobList', data);
          setJobListInfo(data);
        }
      } catch (e) {
        console.log(e);
        setError(e);
      }
    }
  }, [detailJobInfo]);

  const popSetting = (setting) => {
    return setting.map((obj, idx) => {
      return (
        <div style={{ width: '400px' }} key={idx}>
          {obj.mode === 'singular' ? (
            <InputForm.select
              formName={obj.target}
              formLabel={obj.title}
              options={obj.options}
              defaultV={obj.selected}
              required={false}
              changeFunc={changeProc}
            />
          ) : obj.mode === 'subItem' ? (
            <InputForm.subItem
              formLabel={obj.title}
              formName={obj.target}
              options={obj.options}
              defaultV={obj.selected}
              subItem={obj.subItem}
              changeFunc={changeProc}
            />
          ) : (
            ''
          )}
        </div>
      );
    });
  };

  const createGraphData = (data, xKey) => {
    const { disp_graph_f } = data;
    const tempYvalue = [0],
      tempYoption = [{ label: 'ALL', value: 0 }],
      tempXoption = [];
    let tempXvalue = 0;

    Object.keys(disp_graph_f).map((key, index) => {
      if (disp_graph_f[key]) {
        tempYvalue.push(index + 1);
        tempYoption.push({
          label: key,
          value: index + 1,
        });
      }

      tempXoption.push({
        label: key,
        value: index,
      });
      if (key === xKey) tempXvalue = index;
    });

    return {
      xOption: tempXoption,
      xValue: tempXvalue,
      yOption: tempYoption,
      yValue: tempYvalue,
    };
  };

  if (isError) return <div>{isError}</div>;
  if (sItems === null || JobList === null) return <></>;

  return (
    <>
      <Export isOpen={isExport} closeFunc={() => setExport(false)} />
      <Content style={{ padding: '0 50px' }}>
        <Breadcrumb style={{ margin: '16px 0' }}>
          <Breadcrumb.Item>Home</Breadcrumb.Item>
          <Breadcrumb.Item>Focus</Breadcrumb.Item>
          <Breadcrumb.Item>Plate Auto Focus Compensation (AFC)</Breadcrumb.Item>
        </Breadcrumb>
        {JobList.length > 0 ? (
          <Layout
            className="site-layout-background"
            style={{ padding: '24px 0', position: 'relative' }}
          >
            <SideBar
              collapsible={true}
              collapsed={collapsed}
              triggerFunc={() => setCollapsed(!collapsed)}
            >
              <Menu mode="inline" style={{ height: '100%' }} selectable={false}>
                <div style={{ whiteSpace: 'nowrap', margin: '16px' }}>
                  <Popover
                    placement="topLeft"
                    title={'Setting'}
                    content={popSetting(sItems)}
                    trigger="click"
                  >
                    <Tooltip title="setting">
                      <Button theme="antd" iconOnly>
                        <SettingOutlined />
                      </Button>
                    </Tooltip>
                  </Popover>
                </div>
                {JobList.map((menu, index) => {
                  return menu.job_list && menu.job_list.length > 0 ? (
                    <SubMenu
                      key={index}
                      title={menu.start + '~' + menu.end}
                      icon={<ClockCircleOutlined />}
                    >
                      {menu.job_list.map((submenu, idx) => {
                        return (
                          <Menu.Item
                            key={index + '_' + idx}
                            onClick={() =>
                              drawSummary(submenu, menu.start, menu.end)
                            }
                          >
                            {submenu}
                          </Menu.Item>
                        );
                      })}
                    </SubMenu>
                  ) : (
                    <Menu.Item
                      key={index}
                      onClick={() => drawSummary(null, menu.start, menu.end)}
                    >
                      {menu.start + '~' + menu.end}
                    </Menu.Item>
                  );
                })}
              </Menu>
            </SideBar>
            <Content style={{ paddingLeft: '1rem' }}>
              {summaryData !== null ? (
                <>
                  <div css={controlStyle}>
                    <Button
                      theme="white"
                      style={{ fontWeight: '400' }}
                      onClick={() => drawDetail(detailParam)}
                      disabled={
                        detailParam.selectedRows.length === 0 ||
                        activeTab === '2'
                      }
                    >
                      <SlidersOutlined />
                      Analysis
                    </Button>
                    <Button
                      theme="white"
                      style={{ fontWeight: '400' }}
                      onClick={() => setExport(true)}
                    >
                      <CloudDownloadOutlined />
                      Export
                    </Button>
                  </div>
                  <Tabs activeKey={activeTab} onChange={changeTab}>
                    <TabPane tab="Summary" key="1">
                      <div css={contentWrapper}>
                        <FocusTable
                          titleText={title.summary}
                          tableProps={{
                            pagination: false,
                            scroll: { x: true, y: 300 },
                            rowSelection: {
                              getCheckboxProps: (data) => ({
                                disabled: data.date === 'NaT',
                              }),
                              onChange: (selectedRowKeys) => {
                                const tempParamArray = [],
                                  tempOptionArray = [
                                    { value: 0, label: 'ALL' },
                                  ],
                                  tempOptionValueArray = [0];
                                const dataKey =
                                  detailParam.groupBy === 'column'
                                    ? 'LotID'
                                    : 'Period Start';

                                if (selectedRowKeys.length > 0) {
                                  selectedRowKeys.map((value) => {
                                    tempParamArray.push(
                                      summaryData['summary'][value][dataKey],
                                    );
                                  });
                                }

                                setDetailParam((prevState) => {
                                  return {
                                    ...prevState,
                                    selectedRows: tempParamArray,
                                  };
                                });

                                tempParamArray.map((v, i) => {
                                  tempOptionArray.push({
                                    value: i + 1,
                                    label: v,
                                  });
                                  tempOptionValueArray.push(i + 1);
                                });

                                setDetailItems((prevState) => {
                                  return {
                                    ...prevState,
                                    option: tempOptionArray,
                                    value: tempOptionValueArray,
                                  };
                                });
                              },
                            },
                          }}
                          data={summaryData}
                        />
                        <FocusGraph data={summaryData} />
                      </div>
                    </TabPane>
                    {detailData !== null ? (
                      <TabPane tab="Detail" key="2">
                        <div css={contentWrapper}>
                          <FocusTable
                            titleText={title.summary}
                            tableProps={{
                              pagination: false,
                              scroll: { x: true, y: 300 },
                            }}
                            data={detailData}
                            optionInfo={detailItems}
                            optionChange={setDetailItems}
                          />
                          <FocusGraph
                            data={detailData}
                            filterInfo={{
                              target:
                                detailParam.groupBy === 'column'
                                  ? 'lot_id'
                                  : 'log_time',
                              value: detailItems.option.filter(
                                (item) =>
                                  item.value !== 0 &&
                                  detailItems.value.includes(item.value),
                              ),
                            }}
                          />
                        </div>
                      </TabPane>
                    ) : (
                      ''
                    )}
                  </Tabs>
                </>
              ) : (
                <div css={contentWrapper}>
                  <Empty />
                </div>
              )}
            </Content>
          </Layout>
        ) : (
          <Empty />
        )}
      </Content>
    </>
  );
};

export default JobStatusPage;
