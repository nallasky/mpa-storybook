import React, { useEffect, useState } from 'react';
import { Focus } from '../../UI/organisms';
import ProgressModal from '../../UI/organisms/ProgressModal';
import { useHistory } from 'react-router';
import {
  reqFileUpload,
  initFocusJob,
  getStatusFocusJob,
  reqPostFocusJob,
  reqDeleteFocusJob,
  updateDate,
} from '../../../lib/api/axios/requests';
import useFocusJob from '../../../hooks/useFocusJob';
import { getParseData } from '../../../lib/util/Util';
import PropTypes from 'prop-types';

const JobCreatePage = ({ JobUrl, clearJobUrl }) => {
  const [isRemoteId, setRemoteId] = useState(null);
  const [isProcessJob, setProcessJob] = useState(false);
  const history = useHistory();
  const {
    isOpenCreateJob,
    closeCreateJob,
    openCreateJob,
    isSettingInfo,
    setSettingInfo,
    isErrorStatus,
    setErrorStatus,
    isLoading,
    loadStart,
    loadCompleted,
    JobInfo,
    setJobInfo,
    initValidPeriod,
    setValidPeriod,
  } = useFocusJob();

  const startAnalysis = async () => {
    console.log('JobInfo', JobInfo);
    const { target_path } = JobInfo;
    let response;
    closeJobModal();

    if (JobInfo.source !== 'remote') {
      response = await reqFileUpload(target_path).then(
        console.log('==========file upload complete==============='),
      );
      if (response.status === 200) {
        if (response.jobId.length > 0) {
          await reqPostFocusJob(JobInfo, response.jobId).then((res) => {
            res.status === 200
              ? setRemoteId(res.jobId)
              : console.log('status', res.status);
          });
        }
      }
      console.log(response);
      setProcessJob(true);
    } else {
      await reqPostFocusJob(JobInfo, 0).then((res) => {
        if (res.jobId !== 0) {
          setRemoteId(res.jobId);
          history.push({
            pathname: '/job',
            state: { log_name: `${JobInfo.log_name}`, job_id: `${res.jobId}` },
          });
        }
      });
    }
  };

  const closeJobModal = () => {
    closeCreateJob();
    clearJobUrl();
  };

  const endProcessModal = async (status, rows) => {
    setProcessJob(false);
    clearJobUrl();
    if (status === 'success') {
      rows > 0
        ? history.push({
            pathname: '/job',
            state: { log_name: `${JobInfo.log_name}`, job_id: `${isRemoteId}` },
          })
        : console.log('go to mainpage ');
    } else if (status !== 'success') {
      await reqDeleteFocusJob(isRemoteId).then((res) =>
        console.log(' delete job response', res),
      );
    }
  };

  const contentChange = async (event) => {
    const item = getParseData(event);
    console.log('contentChange', item);

    if (item.id === 'equipment_name') {
      try {
        const { date } = await updateDate(JobInfo.log_name, item.value);
        setValidPeriod(date);
        setJobInfo((prevState) => ({
          ...prevState,
          [item.id]: item.value,
          ['period']: `${date.start}~${date.end}`,
        }));
      } catch (e) {
        initValidPeriod();
      }
    } else {
      setJobInfo((prevState) => ({
        ...prevState,
        [item.id]: item.value,
      }));
    }
  };

  const checkAnalysisStatus = async (
    setStatusFunc,
    setPercentFunc,
    contentsFunc,
  ) => {
    console.log('checkAnalysisStatus', isRemoteId);
    try {
      if (isRemoteId !== null) {
        const { status, percent, detail } = await getStatusFocusJob(isRemoteId);
        setStatusFunc(status);
        setPercentFunc(percent);
        contentsFunc(detail);
      }
    } catch (e) {
      console.log(e);
      setErrorStatus(e);
    }
  };

  const fetchInfos = async () => {
    loadStart();
    console.log('getJobType', JobUrl);
    try {
      const res = await initFocusJob(JobUrl);
      console.log(res);
      setSettingInfo(res);
    } catch (e) {
      console.log(e);
      setErrorStatus(e);
    }
    loadCompleted();
    openCreateJob();
    initValidPeriod();
  };

  useEffect(() => {
    if (JobUrl !== null)
      fetchInfos().then(console.log('=====intialize completed ===='));
  }, [JobUrl]);

  if (isLoading) return <></>;
  if (isErrorStatus) return <div>{isErrorStatus}</div>;
  if (isSettingInfo === null) return <></>;

  console.log('=================FocusJObPage================');

  return (
    <>
      {' '}
      <Focus
        isOpen={isOpenCreateJob}
        startFunc={startAnalysis}
        closeFunc={closeJobModal}
        changefunc={contentChange}
        info={isSettingInfo}
      />
      <ProgressModal
        isOpen={isProcessJob}
        closeFunc={endProcessModal}
        statusFunc={checkAnalysisStatus}
      />
    </>
  );
};

JobCreatePage.propTypes = {
  JobUrl: PropTypes.string,
  clearJobUrl: PropTypes.func,
  isRemoteId: PropTypes.string,
  setRemoteId: PropTypes.func,
};

export default JobCreatePage;
