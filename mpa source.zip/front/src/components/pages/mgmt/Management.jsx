import React, { useEffect, useState } from 'react';
import { Drawer, Collapse } from 'antd';
import PropTypes from 'prop-types';
import useMgmtInfo from '../../../hooks/useMgmtInfo';
import { getMgmtInfo } from '../../../lib/api/axios/requests';
import { css } from '@emotion/react';
import { DBSetting, DBTable } from '../../UI/molecules/DrawerSetting';

const { Panel } = Collapse;

const MainTitleDiv = css`
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 16px 24px;
  color: #f0f0f0;
  background: #000000;
`;

const MgmtPage = ({ show, closeFunc }) => {
  const [openPanel, setOpenPanel] = useState([]);
  const {
    loadStart,
    settingInfo,
    setMgmtInfo,
    setErrorStatus,
    loadCompleted,
    isUpdate,
    changeDBInfo,
    clearUpdateFlag,
  } = useMgmtInfo();

  const fetchInfos = async () => {
    loadStart();
    try {
      const res = await getMgmtInfo();
      console.log('getMgmtInfo: ', res);
      setMgmtInfo(res);
      res.settings.map((obj, i) =>
        setOpenPanel((prevState) => [...prevState, i]),
      );
    } catch (e) {
      console.log(e);
      setErrorStatus(e);
    }
    loadCompleted();
  };

  useEffect(() => {
    fetchInfos().then(console.log('=====getMgmtInfo completed ===='));
    return () => clearUpdateFlag();
  }, []);

  useEffect(async () => {
    try {
      const res = await getMgmtInfo().then(
        console.log('=====getMgmtInfo update ===='),
      );
      console.log('getMgmtInfo: ', res);
      console.log('isUpdate: ', isUpdate);
      setMgmtInfo(res);
    } catch (e) {
      console.log(e);
      setErrorStatus(e);
    }
    return () => clearUpdateFlag();
  }, [isUpdate]);

  if (settingInfo == null) return <div>Waiting</div>;

  const callback = (e) => {
    console.log('callback:', e);
    setOpenPanel(e);
  };

  const CollapseContents = () => {
    const { settings } = settingInfo;
    return (
      <Collapse onChange={callback} defaultActiveKey={openPanel}>
        {settings.map((obj, i) => {
          return (
            <Panel header={obj.title} key={i}>
              {obj.target === 'table' ? (
                <>
                  {' '}
                  <DBTable info={obj} />
                </>
              ) : (
                <>
                  {' '}
                  <DBSetting info={obj} update={changeDBInfo} />
                </>
              )}
            </Panel>
          );
        })}
      </Collapse>
    );
  };

  return (
    <>
      <Drawer
        title={<div css={MainTitleDiv}>{settingInfo.title}</div>}
        width={600}
        closable={false}
        onClose={closeFunc}
        visible={show}
        placement="right"
      >
        <CollapseContents />
      </Drawer>
    </>
  );
};

MgmtPage.propTypes = {
  show: PropTypes.bool,
  closeFunc: PropTypes.func,
};

export default MgmtPage;
