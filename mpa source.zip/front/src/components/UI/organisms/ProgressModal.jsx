import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Modal } from '../atoms/Modal';
import Button from '../atoms/Button';
import { css } from '@emotion/react';
import { Spin, Progress } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
/*
import { AUTOCLOSE_TIME } from '../../../lib/util/Util';
*/

const contentStyle = css`
  display: block;
  padding: 24px;
`;

const ProcessIconStyle = css`
  position: absolute;
  width: 120px;
  height: 120px;
  left: 240px;
  top: 81px;
`;

const footerStyle = css`
  display: flex;
  justify-content: flex-end;
  align-items: center;
`;

/*****************************************************************************
 *              Main Modal
 *****************************************************************************/

const ProgressModal = ({ isOpen, closeFunc, statusFunc }) => {
  const [status, setStatus] = useState('idle');
  const [percent, setPercent] = useState(0);
  const [contents, setContents] = useState(null);

  useEffect(() => {
    const refresh = setInterval(() => {
      console.log('=======setInterval========');
      console.log('status', status);
      console.log('contents', contents);
      console.log('percent', percent);
      if (isOpen === true && percent !== 100 && status !== 'success')
        statusFunc(setStatus, setPercent, setContents);
      else clearInterval(refresh);
    }, 1000);
    return () => clearInterval(refresh);
  }, [status, percent, contents, isOpen]);

  useEffect(() => {
    console.log('=======useEffect========');
    console.log('status', status);
    console.log('contents', contents);
    console.log('percent', percent);
    if (status === 'success' && contents !== undefined) {
      contents.converted !== undefined && contents.converted !== 0
        ? closeFunc(status, contents.converted)
        : console.log('contents', contents);
    }
  }, [status, contents]);

  if (isOpen === false) return <></>;

  const closeModal = () => {
    closeFunc(status, 0);
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        header={
          <div>
            {status === 'error'
              ? 'ERROR'
              : status === 'success'
              ? 'COMPLETE'
              : 'PROCESS'}
          </div>
        }
        content={
          <Contents
            type={
              status === 'error'
                ? 'ERROR'
                : status === 'success'
                ? 'COMPLETE'
                : 'PROCESS'
            }
            percent={percent}
            contents={contents}
          />
        }
        footer={
          <ModalFooter
            closeFunc={closeModal}
            btnText={status === 'success' ? 'Close' : 'Cancel'}
          />
        }
        closeIcon={false}
      />
    </>
  );
};

ProgressModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  closeFunc: PropTypes.func.isRequired,
  statusFunc: PropTypes.func.isRequired,
};

/*****************************************************************************
 *              Modal Contents
 *****************************************************************************/
const ErrorContents = css`
  flex: none;
  order: 0;
  flex-grow: 1;
  margin: 0px 10px;
`;

const ItemDiv = css`
  margin-bottom: 7px;
  color: rgba(0, 0, 0, 0.65);
  font-size: 14px;
  line-height: 1.5715;
`;

const ItemLabel = css`
  display: inline-block;
  margin-right: 8px;
  color: rgba(0, 0, 0, 0.85);
`;

const Contents = ({ type, percent, contents }) => {
  if (contents === null) {
    const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;
    return (
      <div css={contentStyle}>
        {
          <div css={ErrorContents}>
            <div css={ItemDiv}>
              <Spin indicator={antIcon} />
              <p css={ItemLabel}>{'File uploading'}</p>
            </div>
          </div>
        }
      </div>
    );
  }
  return (
    <div css={contentStyle}>
      {
        <div css={ErrorContents}>
          <div css={ItemDiv}>
            <p css={ItemLabel}>{'Error Files'}:</p>
            {contents.error_files}
          </div>
          <div css={ItemDiv}>
            <p css={ItemLabel}>{'Success Files'}:</p>
            {contents.success_files}
          </div>
          <div css={ItemDiv}>
            <p css={ItemLabel}>{'Total Files'}:</p>
            {contents.total_files}
          </div>
          <div css={ItemDiv}>
            <p css={ItemLabel}>{'Converted rows'}:</p>
            {contents.converted}
          </div>
        </div>
      }
      {type === 'COMPLETE' ? (
        <Progress type="circle" percent={100} css={ProcessIconStyle} />
      ) : type === 'PROCESS' ? (
        <Progress type="circle" percent={percent} css={ProcessIconStyle} />
      ) : (
        <Progress
          type="circle"
          percent={percent}
          status="exception"
          css={ProcessIconStyle}
        />
      )}
    </div>
  );
};
Contents.propTypes = {
  type: PropTypes.string,
  percent: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  contents: PropTypes.object,
};

/*****************************************************************************
 *              Modal Footer
 *****************************************************************************/

const ModalFooter = ({ btnText, closeFunc }) => {
  return (
    <div css={footerStyle}>
      <Button
        theme={'blue'}
        onClick={closeFunc}
        style={{ marginLeft: '8px', fontWeight: 400 }}
      >
        {btnText ? btnText : 'Close'}
      </Button>
    </div>
  );
};

ModalFooter.propTypes = {
  btnText: PropTypes.string,
  closeFunc: PropTypes.func.isRequired,
};

export default ProgressModal;
