import React from 'react';
import { Menu } from 'antd';
import { HomeOutlined } from '@ant-design/icons';
import SubMenu from 'antd/es/menu/SubMenu';
import { css } from '@emotion/react';
import PropTypes from 'prop-types';
import { useHistory } from 'react-router';

const MainBoxCss = css`
  background: #061178;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 26px 26px 10px 10px;
  display: flex;
  flex-wrap: no-wrap;
  justify-content: center;
`;

const MenuItemCss = css`
  padding: 0 4.5rem !important;
`;

const NaviBar = ({ data }) => {
  const history = useHistory();
  return (
    <div css={MainBoxCss}>
      <Menu
        theme="dark"
        mode="horizontal"
        defaultSelectedKeys="home"
        style={{ background: 'transparent' }}
      >
        <Menu.Item
          key="home"
          icon={<HomeOutlined />}
          css={MenuItemCss}
          style={{ textTransform: 'uppercase' }}
          onClick={() => history.replace('/main')}
        >
          HOME
        </Menu.Item>
        {data.map((menu, index) => {
          return menu.subfunc && menu.subfunc.length > 0 ? (
            <SubMenu key={index} title={menu.title} css={MenuItemCss}>
              {menu.subfunc.map((submenu, idx) => {
                return <Menu.Item key={idx}>{submenu.title}</Menu.Item>;
              })}
            </SubMenu>
          ) : (
            <Menu.Item
              key={index}
              disabled
              css={MenuItemCss}
              style={{ textTransform: 'uppercase' }}
            >
              {menu}
            </Menu.Item>
          );
        })}
      </Menu>
    </div>
  );
};

NaviBar.propTypes = {
  data: PropTypes.array,
};

export default NaviBar;
