import React, { useEffect, useState } from 'react';
/*
import { css } from '@emotion/react';
*/
import { LoadingOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';
import { Descriptions, Spin, Badge } from 'antd';
import Button from '../../atoms/Button';
import InputForm from '../../atoms/Input/InputForm';
import { getParseData } from '../../../../lib/util/Util';
import {
  reqDBConnectionCheck,
  updateDBInformation,
} from '../../../../lib/api/axios/requests';

const DBSetting = ({ info, update }) => {
  const [edit, setEdit] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [status, setStatus] = useState(false);
  const [message, setMessage] = useState(null);
  const [editInfo, setEditInfo] = useState(null);

  const resetInfo = () => {
    console.log('reset DBInfo');
    const resetItem = editInfo.items.map((obj) =>
      obj.content !== undefined ? { ...obj, content: '' } : obj,
    );
    setEditInfo((prevState) => ({
      ...prevState,
      items: resetItem,
    }));
  };

  const applySetting = async () => {
    console.log('apply DBInfo');

    const setting = editInfo.items.filter((obj) => obj.content === '');

    if (setting.length === 0) {
      try {
        setLoading(true);
        const data = await updateDBInformation(
          editInfo.items,
          editInfo.url,
          console.log('=============DBINfo Update========'),
        );
        if (data.status === 'OK') {
          update();
          setEdit(false);
          console.log('data', data);
        }
      } catch (e) {
        setStatus('NG');
        setMessage(null);
        if (e.response) {
          const { statusText, data } = e.response;
          setStatus(statusText);
          setMessage(data.msg);
          console.log('testConnect e1 ', e.response);
        } else if (e.request) {
          console.log('testConnect e2 ', e.request);
          setMessage(e.request);
        } else if (e.message) {
          console.log('testConnect e3 ', e.message);
          setMessage(e.message);
        }
      }
      setLoading(false);
    } else {
      console.log('ERROR ');
    }
  };
  const testConnect = async (url) => {
    console.log('url', url);
    try {
      setLoading(true);
      const data = await reqDBConnectionCheck(editInfo.items, url).then(
        console.log('=============JobList update completed========'),
      );
      if (data.status === 'OK') {
        setStatus(data.status);
        setMessage(data.msg);
        console.log('data', data);
      }
    } catch (e) {
      setStatus('NG');
      setMessage(null);
      if (e.response) {
        const { statusText, data } = e.response;
        setStatus(statusText);
        setMessage(data.msg);
        console.log('testConnect e1 ', e.response);
      } else if (e.request) {
        console.log('testConnect e2 ', e.request);
        setMessage(e.request);
      } else if (e.message) {
        console.log('testConnect e3 ', e.message);
        setMessage(e.message);
      }
    }
    setLoading(false);
  };

  const changeEvent = (e) => {
    const event = getParseData(e);
    const modifiedItem = editInfo.items.map((obj) =>
      obj.target === event.id ? { ...obj, content: event.value } : obj,
    );
    setEditInfo((prevState) => ({
      ...prevState,
      items: modifiedItem,
    }));
    console.log('e', e);
  };

  useEffect(() => {
    setEditInfo(info);
  }, [setEdit]);

  useEffect(() => {
    console.log('DBSetting create');
  }, []);

  return edit === false ? (
    <Descriptions
      title={info.title}
      bordered
      column={6}
      layout={'vertical'}
      extra={<Button onClick={() => setEdit(true)}>Edit</Button>}
    >
      {info.items.map((obj, i) => {
        if (obj.type === 'input' || obj.type === 'password') {
          return (
            <Descriptions.Item
              label={obj.title}
              key={i}
              span={obj.target === 'host' || obj.target === 'port' ? 3 : 2}
            >
              {obj.type === 'input'
                ? obj.content
                : obj.content !== undefined && obj.content.length > 0
                ? '*******'
                : ''}
            </Descriptions.Item>
          );
        }
      })}
    </Descriptions>
  ) : (
    <Descriptions
      title={editInfo.title}
      bordered
      column={2}
      extra={
        <>
          <Button
            onClick={resetInfo}
            style={{ marginLeft: '8px', fontWeight: 400 }}
          >
            {'Reset'}
          </Button>
          <Button
            theme={'white'}
            onClick={() => applySetting()}
            style={{ marginLeft: '8px', fontWeight: 400 }}
          >
            {'Apply'}
          </Button>
        </>
      }
    >
      <div>
        {editInfo.items.map((obj, i) => {
          return (
            <>
              {obj.type === 'password' ? (
                <Descriptions.Item span={2} key={i}>
                  <InputForm.password
                    formLabel={obj.title}
                    formName={obj.target}
                    changeFunc={changeEvent}
                    value={obj.content}
                  />
                </Descriptions.Item>
              ) : obj.type === 'input' ? (
                <Descriptions.Item
                  span={obj.target === 'host' || obj.target === 'port' ? 1 : 2}
                  key={i}
                >
                  <InputForm.text
                    formLabel={obj.title}
                    formName={obj.target}
                    changeFunc={changeEvent}
                    value={obj.content}
                  />
                </Descriptions.Item>
              ) : obj.target === 'test_connection' ? (
                <Descriptions.Item span={2} key={i}>
                  <div>
                    <Button
                      onClick={() => testConnect(obj.url)}
                      style={{ marginLeft: '8px', fontWeight: 400 }}
                    >
                      {obj.title}
                    </Button>
                    <>
                      {isLoading === true ? (
                        <Spin
                          style={{ left: '10px' }}
                          indicator={
                            <LoadingOutlined style={{ fontSize: 24 }} spin />
                          }
                        />
                      ) : status === 'OK' ? (
                        <>
                          <Badge
                            status="success"
                            text="SUCCESS"
                            style={{ left: '10px' }}
                          />{' '}
                          <p />
                          <div css={{ paddingLeft: '15px' }}>{message}</div>
                        </>
                      ) : status ? (
                        <>
                          <Badge
                            status="error"
                            text={status}
                            style={{ left: '10px' }}
                          />
                          <p />
                          <div css={{ fontsize: '12px' }}>{message}</div>
                        </>
                      ) : (
                        <></>
                      )}
                    </>
                  </div>
                </Descriptions.Item>
              ) : (
                <div key={i}>{obj.type}</div>
              )}
            </>
          );
        })}
      </div>
    </Descriptions>
  );
};

DBSetting.propTypes = {
  info: PropTypes.object,
  update: PropTypes.func,
};

export default DBSetting;
