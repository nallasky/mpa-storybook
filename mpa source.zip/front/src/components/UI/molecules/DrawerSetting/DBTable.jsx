import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Badge, Descriptions, Spin, Upload, Table, message } from 'antd';
import Button from '../../atoms/Button';
import { CloudUploadOutlined } from '@ant-design/icons/lib/icons';
import { LoadingOutlined } from '@ant-design/icons';
import {
  exportFile,
  reqZipFileUpload,
} from '../../../../lib/api/axios/requests';

const DBTable = ({ info }) => {
  const [uploadFile, setUploadFile] = useState(null);
  const [isLoading, setLoading] = useState(false);
  const [status, setStatus] = useState(false);
  const [Message, setMessage] = useState(null);
  const [TableData, setTableData] = useState(null);

  useEffect(() => {
    console.log('DBTable create');
    if (info) setTableData(tableData(info.items));
  }, []);
  const tableData = (obj) => {
    const data = obj.filter((obj) => obj.type === 'column');
    const convertData = (matrix, dataIndex) =>
      matrix.map((row, i) => {
        return { key: i, [dataIndex]: row };
      });
    const title = data.map((item) => {
      return {
        title: item.title.toUpperCase(),
        dataIndex: item.title.replace(/ /gi, ''),
        key: item.title.replace(/ /gi, ''),
      };
    });
    const tabledata = data.map((obj) =>
      title
        .filter((obj2) => obj.title.replace(/ /gi, '') === obj2.dataIndex)
        .map((obj2) => convertData(obj.items, obj2.dataIndex)),
    );
    const combinedItems = (arr = []) => {
      const finalData = [];
      arr.map((obj, i) => {
        if (i === 0)
          return obj.map((row) =>
            arr.map((obj2, j) => {
              if (j > 0)
                return obj2.map((row2) => {
                  const res = row.map((x) =>
                    Object.assign(
                      {},
                      x,
                      row2.find((y) => y.key === x.key),
                    ),
                  );
                  finalData.push(res);
                });
            }),
          );
      });
      console.log(finalData);
      return finalData;
    };

    return {
      columns: title,
      dataSource: combinedItems(tabledata),
    };
  };
  /*const exportZipFile = async (url, filename) => {
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'file.zip'); //any other extension
    document.body.appendChild(link);
    link.click();
    link.remove();
  };*/
  const importZipFile = async (url) => {
    console.log('importZipFile');
    if (uploadFile === null) {
      setUploadFile((prevState) => ({
        ...prevState,
        url: url,
      }));
    } else {
      setLoading(true);
      try {
        await reqZipFileUpload(uploadFile).then((res) => {
          setStatus(res.status);
          if (res.status === 'NG') setMessage(res.data.message);
          else {
            setUploadFile(null);
            setMessage(null);
            setStatus(null);
          }
          console.log('===file upload completed====');
        });
      } catch (e) {
        setStatus('NG');
        if (e.response) {
          const { statusText, data } = e.response;
          setStatus(statusText);
          setMessage(data.msg);
          console.log('testConnect e1 ', e.response);
        } else if (e.request) {
          console.log('testConnect e2 ', e.request);
          setMessage(e.request);
        } else if (e.message) {
          console.log('testConnect e3 ', e.message);
          setMessage(e.message);
        }
      }
      setLoading(false);
    }
  };
  const eventClick = (target, url) => {
    target === 'export' ? exportFile(url, 'file.zip') : importZipFile(url);
  };
  const ZipUploadProps = {
    name: 'files',
    beforeUpload: (file) => {
      if (file.type !== 'application/x-zip-compressed') {
        message.error(`${file.name} is not a zip file`);
        return Upload.LIST_IGNORE;
      } else {
        const formData = new FormData();
        formData.append('files', file);
        setUploadFile((prevState) => ({
          ...prevState,
          file: formData,
        }));
        return false;
      }
    },
    onRemove: (file) => {
      setUploadFile(file);
      return file;
    },
  };
  if (info == null || TableData === null) return <>{'DB Table empty'}</>;
  const { items } = info;
  console.log('TableData', TableData);

  return (
    <>
      {uploadFile === null ? (
        <Descriptions
          title={info.title}
          column={2}
          layout="vertical"
          extra={
            <div style={{ display: 'flex' }}>
              {items
                .filter((obj) => obj.type === 'button')
                .map((obj, i) => {
                  return (
                    <div key={i}>
                      <Button
                        onClick={() => eventClick(obj.target, obj.url)}
                        style={{ marginLeft: '8px', fontWeight: 400 }}
                      >
                        {obj.title}
                      </Button>
                    </div>
                  );
                })}
            </div>
          }
        >
          <Descriptions.Item>
            <div>
              <Table
                bordered
                pagination={false}
                columns={TableData.columns}
                dataSource={TableData.dataSource[0]}
                size="middle"
                rowKey="key"
              />
            </div>
          </Descriptions.Item>
        </Descriptions>
      ) : (
        <Descriptions
          title={info.title}
          layout="vertical"
          extra={
            <>
              <Button
                onClick={() => setUploadFile(null)}
                style={{ marginLeft: '8px', fontWeight: 400 }}
              >
                {'Cancel'}
              </Button>
              <Button
                theme={'white'}
                disabled={uploadFile.file === undefined}
                onClick={() => importZipFile()}
                style={{ marginLeft: '8px', fontWeight: 400 }}
              >
                {'Apply'}
              </Button>
            </>
          }
        >
          <Descriptions.Item>
            <div>
              <Upload {...ZipUploadProps} maxCount={1}>
                <Button
                  icon={<CloudUploadOutlined />}
                  style={{ marginLeft: '8px', fontWeight: 400 }}
                >
                  Upload zip only
                </Button>
              </Upload>
            </div>
            {uploadFile.file !== undefined ? (
              <>
                {isLoading === true ? (
                  <Spin
                    style={{ left: '10px' }}
                    indicator={
                      <LoadingOutlined style={{ fontSize: 24 }} spin />
                    }
                  />
                ) : status ? (
                  <>
                    <Badge
                      status="error"
                      text={status}
                      style={{ left: '10px' }}
                    />
                    <p />
                    <div css={{ fontsize: '12px' }}>{Message}</div>
                  </>
                ) : (
                  <></>
                )}
              </>
            ) : (
              <></>
            )}
          </Descriptions.Item>
        </Descriptions>
      )}
    </>
  );
};

DBTable.propTypes = {
  info: PropTypes.object,
};

export default DBTable;
