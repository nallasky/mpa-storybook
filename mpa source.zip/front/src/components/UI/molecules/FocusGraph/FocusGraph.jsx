import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { Select, Empty } from 'antd';
import Graph from '../../atoms/Graph';
import useAnalysisInfo from '../../../../hooks/useAnalysisInfo';

const { Option } = Select;

const contentWrapper = css`
  width: 100%;
  & > div + div {
    margin-top: 1rem;
  }
`;
const graphWrapper = css`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: auto;
  gap: 1rem;
  width: 100%;
`;
const optionWrapper = css`
  display: flex;
  justify-content: space-between;
  & > div {
    display: flex;
    align-items: center;
    & > span > span {
      color: red;
    }
  }
`;
const emptyWrapper = css`
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const FocusGraph = React.memo(({ data, filterInfo }) => {
  const { summary, detail, graphData } = data;
  const { xOption, xValue, yOption, yValue } = graphData;
  const sourceData = summary !== undefined ? summary : detail;
  const [xAxisValue, setXAxisValue] = useState(0);
  const [infoX, setInfoX] = useState([]);
  const [graphType, setGrapeType] = useState('bar');
  const { yAxisValue, setYAxisValue } = useAnalysisInfo();

  useEffect(() => {
    createXdata(summary !== undefined ? 'Date' : filterInfo.target);
  }, [filterInfo, data]);

  useEffect(() => {
    setXAxisValue(xValue);
    setYAxisValue(yValue);
  }, [xValue, yValue]);

  const createXdata = (xKey) => {
    if (xKey.length === 0) return;

    const isDetail = filterInfo.target !== '';
    const tempData = [],
      label = [];

    if (isDetail) {
      filterInfo.value.map((v) => label.push(v.label));
    }

    Object.keys(sourceData).map((key) => {
      if (
        sourceData[key]['index'] !== 'ALL' &&
        (!isDetail ||
          (isDetail && label.includes(sourceData[key][filterInfo.target])))
      ) {
        tempData.push(sourceData[key][xKey]);
      }
    });

    setInfoX(tempData.filter((v, i) => tempData.indexOf(v) === i));
  };

  const changeXoption = (v) => {
    const { label } = xOption.find((option) => option.value === v);

    if (label === undefined) return;

    setXAxisValue(v);
    createXdata(label);
  };

  const filteringGraph = (values) => {
    let result = [];
    const exceptZero = values.filter((value) => value !== 0);

    if (
      !yAxisValue.includes(0) &&
      (values.includes(0) || exceptZero.length === yOption.length - 1)
    ) {
      yOption.map((option) => {
        result.push(option.value);
      });
    } else {
      result = yAxisValue.includes(0) && !values.includes(0) ? [] : exceptZero;
    }

    setYAxisValue(result);
  };

  return (
    <div css={contentWrapper}>
      <div css={optionWrapper}>
        <div>
          <span>
            <span>*</span> Graph Type:
          </span>
          <Select
            value={graphType}
            style={{ marginLeft: '1rem' }}
            onChange={(v) => setGrapeType(v)}
          >
            <Option value="bar">Bar</Option>
            <Option value="scatter">Line</Option>
          </Select>
        </div>
        <div>
          <span>
            <span>*</span> Axis (X):
          </span>
          <Select
            value={xAxisValue}
            options={xOption}
            style={{ marginLeft: '1rem' }}
            onChange={changeXoption}
          />
        </div>
        <div>
          <span>
            <span>*</span> Axis (Y):
          </span>
          <Select
            mode="multiple"
            maxTagCount="responsive"
            style={{ marginLeft: '1rem', width: '300px' }}
            value={yAxisValue}
            options={yOption}
            onChange={filteringGraph}
            placeholder="Select option"
          />
        </div>
      </div>
      <div css={yAxisValue.length > 0 ? graphWrapper : emptyWrapper}>
        {yAxisValue.length > 0 ? (
          yOption.map((option, index) => {
            if (index === 0 || !yAxisValue.includes(option.value)) return '';

            const infoY = [];

            Object.keys(sourceData).map((key) => {
              infoY.push(sourceData[key][option.label]);
            });

            if (infoY.length !== 0) {
              return (
                <div id={`graph_${option.value}`} key={index}>
                  <Graph
                    graphProps={{
                      data: [{ type: graphType, x: infoX, y: infoY }],
                      layout: {
                        width: 570,
                        height: 360,
                        autosize: true,
                        title: option.label,
                        xaxis: {
                          tickmode: 'auto',
                          nticks: infoX.length,
                        },
                      },
                      config: {
                        modeBarButtonsToRemove: [
                          'pan2d',
                          'pan3d',
                          'zoom2d',
                          'zoom3d',
                          'lasso2d',
                          'select2d',
                          'hoverClosestCartesian',
                          'hoverCompareCartesian',
                          'autoScale2d',
                          'autoScale3d',
                          'toggleSpikelines',
                        ],
                        displaylogo: false,
                      },
                    }}
                  />
                </div>
              );
            } else {
              return '';
            }
          })
        ) : (
          <Empty />
        )}
      </div>
    </div>
  );
});

FocusGraph.displayName = 'FocusGraph';
FocusGraph.propTypes = {
  data: PropTypes.object.isRequired,
  filterInfo: PropTypes.shape({
    target: PropTypes.string,
    value: PropTypes.array,
  }),
};
FocusGraph.defaultProps = {
  filterInfo: {
    target: '',
    value: [],
  },
};

export default FocusGraph;
