import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { Table, Select, Empty } from 'antd';
import { DatabaseOutlined } from '@ant-design/icons';
import useAnalysisInfo from '../../../../hooks/useAnalysisInfo';

const componentWrapper = css`
  width: 100%;
  & > div + div {
    margin-top: 1rem;
  }
`;
const titleStyle = css`
  font-weight: 500;
  font-size: 14px;
  margin-left: 1rem;
`;
const headerStyle = css`
  display: flex;
  justify-content: space-between;
`;
const titleWrapper = css`
  display: flex;
  align-items: center;
`;
const requireTag = css`
  color: red;
`;

const FocusTable = React.memo(
  ({ titleIcon, titleText, tableProps, data, optionInfo, optionChange }) => {
    const { disp_order, summary, detail } = data;
    const selectedData = summary === undefined ? detail : summary;

    const {
      columnInfo,
      dataSource,
      setDataSource,
      setColumnInfo,
    } = useAnalysisInfo();
    const type = summary === undefined ? 'detail' : 'summary';
    useEffect(() => {
      const tempColumn = [];

      disp_order.map((item) => {
        const str = replaceString(item);

        tempColumn.push({
          title: item,
          dataIndex: str,
          key: str,
          ellipsis: true,
        });
      });

      setColumnInfo(type, tempColumn);
      setDataSource(type, createInitDataSource(selectedData));
    }, [data]);

    const filteringData = (values) => {
      const exceptZero = values.filter((value) => value !== 0);

      if (
        !optionInfo.value.includes(0) &&
        (values.includes(0) ||
          exceptZero.length === optionInfo.option.length - 1)
      ) {
        setDataSource(type, createInitDataSource(selectedData));
        createInitOptionValue();
      } else {
        const labels = [],
          tempData = [],
          optionValue =
            optionInfo.value.includes(0) && !values.includes(0)
              ? []
              : exceptZero;
        let index = 0;

        if (optionValue.length > 0) {
          optionValue.map((value) => {
            if (value !== 0) {
              const { label } = optionInfo.option.find(
                (item) => item.value === value,
              );

              if (label !== undefined) {
                labels.push(label);
              }
            }
          });

          const fKey = optionInfo.title === 'Column' ? 'lot_id' : 'log_time';

          Object.keys(selectedData).map((key) => {
            if (labels.includes(selectedData[key][fKey])) {
              tempData.push(createRowData(selectedData[key], index));
              index++;
            }
          });
        }

        setDataSource(type, tempData);
        optionChange((prevState) => {
          return {
            ...prevState,
            value: optionValue,
          };
        });
      }
    };

    const createRowData = (data, index) => {
      const rowData = { key: index };

      Object.keys(data).map((itemKey) => {
        rowData[replaceString(itemKey)] = data[itemKey];
      });

      return rowData;
    };

    const createInitDataSource = (data) => {
      const tempArray = [];

      Object.keys(data).map((itemsKey, i) => {
        tempArray.push(createRowData(data[itemsKey], i));
      });

      return tempArray;
    };

    const createInitOptionValue = () => {
      const tempArray = [];

      optionInfo.option.map((item) => {
        tempArray.push(item.value);
      });

      optionChange((prevState) => {
        return {
          ...prevState,
          value: tempArray,
        };
      });
    };
    return (
      <div css={componentWrapper}>
        <div css={headerStyle}>
          <div css={titleWrapper}>
            {titleIcon}
            <span css={titleStyle}>{titleText}</span>
          </div>
          {summary === undefined ? (
            <div>
              <span>
                <span css={requireTag}>*</span> {optionInfo.title + ':'}
              </span>
              <Select
                mode="multiple"
                maxTagCount="responsive"
                style={{ marginLeft: '1rem', width: '300px' }}
                value={optionInfo.value}
                options={optionInfo.option}
                onChange={filteringData}
                placeholder="Select option"
              />
            </div>
          ) : (
            ''
          )}
        </div>
        <div>
          {detail === undefined || optionInfo.value.length > 0 ? (
            <Table
              {...tableProps}
              dataSource={dataSource(type)}
              columns={columnInfo(type)}
            />
          ) : (
            <Empty />
          )}
        </div>
      </div>
    );
  },
);

const replaceString = (s) => {
  return s.toLowerCase().replaceAll(/\./g, '').replaceAll(/\s/g, '_');
};

FocusTable.displayName = 'FocusTable';
FocusTable.propTypes = {
  titleIcon: PropTypes.node,
  titleText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  tableProps: PropTypes.object,
  data: PropTypes.object.isRequired,
  optionInfo: PropTypes.object,
  optionChange: PropTypes.func,
};
FocusTable.defaultProps = {
  titleIcon: <DatabaseOutlined />,
  text: 'Title',
};

export default FocusTable;
