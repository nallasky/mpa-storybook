import React from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import Plot from 'react-plotly.js';

const graphWrapper = css`
  display: flex;
  justify-content: center;
  align-items: center;
`;

const Graph = ({ graphProps, wrapperStyle }) => {
  return (
    <div css={[graphWrapper, wrapperStyle]}>
      <Plot {...graphProps} />
    </div>
  );
};

Graph.displayName = 'Graph';
Graph.propTypes = {
  graphProps: PropTypes.object.isRequired,
  wrapperStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

export default Graph;
