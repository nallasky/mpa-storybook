import React, { useEffect, useState } from 'react';
import moment from 'moment';
import { Form, Select, DatePicker, Upload, Button, Input } from 'antd';
import { getParseData } from '../../../../lib/util/Util';
import PropTypes from 'prop-types';
import {
  FolderOpenFilled,
  LockOutlined,
  InboxOutlined,
} from '@ant-design/icons';

const { RangePicker } = DatePicker;
const { Option } = Select;
const { Dragger } = Upload;

const InputForm = ({ children }) => {
  return <div>{children}</div>;
};

const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 20 },
};

const SelectForm = ({
  formName,
  formLabel,
  changeFunc,
  options,
  defaultV,
  required,
}) => {
  const [form] = Form.useForm();
  const onFormLayoutChange = (e) => {
    const event = getParseData(e);
    changeFunc !== undefined
      ? changeFunc({
          [formName]: event.value !== undefined ? event.value : '',
        })
      : console.log(e);
  };

  useEffect(() => {
    form.setFieldsValue({ [formName]: defaultV });
  }, []);

  return (
    <>
      <Form {...layout} form={form} onValuesChange={onFormLayoutChange}>
        <Form.Item
          name={formName}
          label={formLabel}
          initialvalues={{ [formName]: defaultV ? defaultV : options[0] }}
          rules={[
            {
              required: required !== undefined ? required : true,
            },
          ]}
        >
          <Select
            value={defaultV}
            allowClear={required !== undefined ? !required : false}
          >
            {
              // eslint-disable-next-line react/jsx-key
              options.map((item, idx) => {
                return (
                  <Option key={idx} value={item}>
                    {item}
                  </Option>
                );
              })
            }
          </Select>
        </Form.Item>
      </Form>
    </>
  );
};

SelectForm.propTypes = {
  formName: PropTypes.string,
  formLabel: PropTypes.string,
  changeFunc: PropTypes.func,
  options: PropTypes.array,
  defaultV: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  required: PropTypes.bool,
};

const MultiSelectForm = ({
  formName,
  formLabel,
  changeFunc,
  options,
  subItem,
  defaultV,
  required,
}) => {
  const [firstValue, setFirstValue] = useState();
  const [subOptions, setSubOptions] = useState(null);
  const [form] = Form.useForm();

  const onItemChange = (e) => {
    const event = getParseData(e);
    if (event.id === formName) {
      setFirstValue(event.value);
      form.setFieldsValue({ [subItem.target]: '' });
      if (changeFunc !== undefined)
        changeFunc({ [event.id]: event.value, [subItem.target]: '' });
    } else {
      changeFunc !== undefined ? changeFunc(e) : console.log(e);
    }
  };

  const getSubOptions = (select) => {
    const item =
      subItem.options !== null
        ? subItem.options.find((obj) => getParseData(obj).id === select)
        : undefined;

    if (item !== undefined) {
      const sub = getParseData(item);
      return sub.value;
    }
    return null;
  };

  useEffect(() => {
    setSubOptions(getSubOptions(firstValue));
  }, [firstValue]);

  useEffect(() => {
    options
      ? setSubOptions(getSubOptions(defaultV ? defaultV : options[0]))
      : '';
    form.setFieldsValue({ [subItem.target]: subItem.selected });
  }, []);

  return (
    <>
      <Form
        {...layout}
        form={form}
        initialvalues={{
          [formName]: defaultV,
          [subItem.target]: subItem.selected,
        }}
        onValuesChange={onItemChange}
      >
        <Form.Item
          name={formName}
          label={formLabel}
          rules={[
            {
              required: required !== undefined ? required : true,
            },
          ]}
        >
          <Select allowClear={required !== undefined ? !required : false}>
            {
              // eslint-disable-next-line react/jsx-key
              options.map((item, idx) => {
                return (
                  <Option key={idx} value={item}>
                    {item}
                  </Option>
                );
              })
            }
          </Select>
        </Form.Item>
        <Form.Item
          name={subItem.target}
          label={subItem.title}
          rules={[
            {
              required: required !== undefined ? required : true,
            },
          ]}
        >
          <Select allowClear={required !== undefined ? !required : false}>
            {subOptions &&
              // eslint-disable-next-line react/jsx-key
              subOptions.map((item, idx) => {
                return (
                  <Option key={idx} value={item}>
                    {item}
                  </Option>
                );
              })}
          </Select>
        </Form.Item>
      </Form>
    </>
  );
};

MultiSelectForm.propTypes = {
  formName: PropTypes.string,
  formLabel: PropTypes.string,
  changeFunc: PropTypes.func,
  options: PropTypes.array,
  subItem: PropTypes.object,
  required: PropTypes.bool,
  defaultV: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.object,
  ]),
};

const dateFormat = 'YYYY-MM-DD';

const DateSelectForm = ({ formName, formLabel, changeFunc, start, end }) => {
  const [form] = Form.useForm();

  const onFormLayoutChange = (e) => {
    const event = getParseData(e);
    const start = moment(e[event.id][0]).format(dateFormat);
    const end = moment(e[event.id][1]).format(dateFormat);
    changeFunc !== undefined
      ? changeFunc({ [event.id]: [start, end].join('~') })
      : console.log(e);
  };
  useEffect(() => {
    form.setFieldsValue({
      [formName]: [moment(start, dateFormat), moment(end, dateFormat)],
    });
  }, [start, end]);

  const disabledDate = (current) => {
    // Can not select days before today and today
    return (
      current &&
      (current < moment(start).endOf('day') ||
        current > moment(end).endOf('day'))
    );
  };

  return (
    <>
      <Form {...layout} form={form} onValuesChange={onFormLayoutChange}>
        <Form.Item
          name={formName}
          label={formLabel ? formLabel : ' '}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <RangePicker
            disabledDate={disabledDate}
            format={dateFormat}
            value={[moment(start, dateFormat), moment(end, dateFormat)]}
            disabled={[!start & true, !end & true]}
          />
        </Form.Item>
      </Form>
    </>
  );
};

DateSelectForm.propTypes = {
  formName: PropTypes.string,
  formLabel: PropTypes.string,
  start: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  end: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  changeFunc: PropTypes.func,
};

const DirectoryForm = ({ formName, formLabel, changeFunc }) => {
  const [fileList, setFileList] = useState([]);
  const onFormLayoutChange = (e) => {
    const event = getParseData(e);
    const formData = new FormData();
    fileList.map((obj) => {
      formData.append('files', obj);
    });

    changeFunc !== undefined
      ? changeFunc({ [event.id]: formData })
      : console.log('onFormLayoutChange2', e);
  };

  const BeforeProps = {
    name: 'files',
    multiple: true,
    action: '',
    beforeUpload: (file) => {
      setFileList((prev) => [...prev, file]);
      return false;
    },
    onChange: (info) => {
      console.log('onChange', info.fileList);
    },
    onRemove: (file) => {
      setFileList((fileList) => {
        const index = fileList.indexOf(file);
        const newFileList = fileList.slice();
        newFileList.splice(index, 1);
        return newFileList;
      });
    },
    fileList,
  };

  return (
    <>
      <Form {...layout} onValuesChange={onFormLayoutChange}>
        <Form.Item
          name={formName}
          label={formLabel}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Upload {...BeforeProps} directory>
            <Button icon={<FolderOpenFilled />}>Upload Directory</Button>
          </Upload>
        </Form.Item>
      </Form>
    </>
  );
};

DirectoryForm.propTypes = {
  formName: PropTypes.string,
  formLabel: PropTypes.string,
  changeFunc: PropTypes.func,
  defaultV: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

const FileForm = ({ formName, formLabel, changeFunc }) => {
  const [fileList, setFileList] = useState([]);

  const onFormLayoutChange = (e) => {
    const event = getParseData(e);
    const formData = new FormData();
    fileList.map((obj) => {
      formData.append('files', obj);
    });

    changeFunc !== undefined
      ? changeFunc({ [event.id]: formData })
      : console.log('onFormLayoutChange2', e);
  };

  const props = {
    name: 'files',
    action: '', //backend server
    onChange: (info) => {
      console.log('onChange', info.fileList);
    },
    beforeUpload: (file) => {
      setFileList((prev) => [...prev, file]);
      return false;
    },
    onRemove: (file) => {
      setFileList((fileList) => {
        const index = fileList.indexOf(file);
        const newFileList = fileList.slice();
        newFileList.splice(index, 1);
        return newFileList;
      });
    },
  };

  return (
    <>
      <Form {...layout} onValuesChange={onFormLayoutChange}>
        <Form.Item
          name={formName}
          label={formLabel}
          rules={[
            {
              required: true,
            },
          ]}
          valuePropName="fileList"
        >
          <Dragger
            {...props}
            style={{ height: '100px', width: '300px' }}
            maxCount={1}
          >
            <p className="ant-upload-drag-icon">
              <InboxOutlined />
            </p>
            <p className="ant-upload-text">
              Click or drag file to this area to upload
            </p>
          </Dragger>
        </Form.Item>
      </Form>
    </>
  );
};

FileForm.propTypes = {
  formName: PropTypes.string,
  formLabel: PropTypes.string,
  changeFunc: PropTypes.func,
};

const TextForm = ({ formName, formLabel, changeFunc, value }) => {
  const [form] = Form.useForm();
  const onFormLayoutChange = (e) => {
    changeFunc !== undefined ? changeFunc(e) : console.log(e);
  };

  useEffect(() => {
    form.setFieldsValue({ [formName]: value });
  }, [value]);

  return (
    <>
      <Form {...layout} form={form} onValuesChange={onFormLayoutChange}>
        <Form.Item
          name={formName}
          label={formLabel}
          initialvalues={{ [formName]: value }}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Input allowClear />
        </Form.Item>
      </Form>
    </>
  );
};

TextForm.propTypes = {
  formName: PropTypes.string,
  formLabel: PropTypes.string,
  changeFunc: PropTypes.func,
  value: PropTypes.string,
};

const PasswordForm = ({ formName, formLabel, changeFunc, value }) => {
  const [form] = Form.useForm();

  const onFormLayoutChange = (e) => {
    changeFunc !== undefined ? changeFunc(e) : console.log(e);
  };

  useEffect(() => {
    form.setFieldsValue({ [formName]: value });
  }, [value]);

  return (
    <>
      <Form {...layout} form={form} onValuesChange={onFormLayoutChange}>
        <Form.Item
          name={formName}
          label={formLabel}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Input
            prefix={<LockOutlined className="site-form-item-icon" />}
            type="password"
            value={value}
            placeholder="Password"
            allowClear
          />
        </Form.Item>
      </Form>
    </>
  );
};

PasswordForm.propTypes = {
  formName: PropTypes.string,
  formLabel: PropTypes.string,
  changeFunc: PropTypes.func,
  value: PropTypes.string,
};

InputForm.propTypes = {
  children: PropTypes.node,
};

InputForm.select = SelectForm;
InputForm.subItem = MultiSelectForm;
InputForm.directory = DirectoryForm;
InputForm.datePicker = DateSelectForm;
InputForm.file = FileForm;
InputForm.text = TextForm;
InputForm.password = PasswordForm;

export default InputForm;
