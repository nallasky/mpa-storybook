import React from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';

const FormCard = ({ title, children, formStyle, titleStyle }) => {
  return (
    <div css={[formMainStyle, formStyle]}>
      <p css={[formTitleStyle, titleStyle]}>{title}</p>
      {children}
    </div>
  );
};

FormCard.displayName = 'FormCard';
FormCard.propTypes = {
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  children: PropTypes.node.isRequired,
  formStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  titleStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};
FormCard.defaultProps = {
  title: 'Form Title',
};

const formMainStyle = css`
  padding: 1rem;
  background: #f0f5ff;
`;

const formTitleStyle = css`
  color: #1890ff;
  font-weight: 600;
`;

export default FormCard;
