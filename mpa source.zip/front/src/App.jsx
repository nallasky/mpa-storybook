import React from 'react';
import 'antd/dist/antd.css';
import MainPage from './components/pages/main';
import { Switch, Route } from 'react-router-dom';

const App = () => {
  return (
    <>
      <Switch>
        <>
          <Route path={['/main', '/job']}>
            <MainPage />
          </Route>
        </>
      </Switch>
    </>
  );
};

export default App;
