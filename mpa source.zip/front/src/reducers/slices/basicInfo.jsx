import { createSlice } from '@reduxjs/toolkit';
const initialState = {
  yAxis: [],
  Summary: {
    column: '',
    dataSource: '',
  },
  Detail: {
    column: '',
    dataSource: '',
  },
};
const AnalysisInfo = createSlice({
  name: 'AnalysisInfo',
  initialState,
  reducers: {
    initAnalysisReducer: () => initialState,
    SelectYAxiosReducer: (state, action) => {
      state.yAxis = action.payload;
    },
    SummaryHeaderAxiosReducer: (state, action) => {
      state.Summary.column = action.payload;
    },
    SummaryDataAxiosReducer: (state, action) => {
      state.Summary.dataSource = action.payload;
    },
    DetailHeaderAxiosReducer: (state, action) => {
      state.Detail.column = action.payload;
    },
    DetailDataAxiosReducer: (state, action) => {
      state.Detail.dataSource = action.payload;
    },
  },
});

//reducer's action
export const {
  initAnalysisReducer: initAnalysisAction,
  SelectYAxiosReducer,
  SummaryHeaderAxiosReducer,
  SummaryDataAxiosReducer,
  DetailHeaderAxiosReducer,
  DetailDataAxiosReducer,
} = AnalysisInfo.actions;

export const AnalysisSelectedYAxis = (state) => state.AnalysisInfo.yAxis;
export const AnalysisSummaryData = (state) => state.AnalysisInfo.Summary;
export const AnalysisDetailData = (state) => state.AnalysisInfo.Detail;

export default AnalysisInfo.reducer;
