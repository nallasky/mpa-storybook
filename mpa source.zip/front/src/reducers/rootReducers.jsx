import { combineReducers } from '@reduxjs/toolkit';
import AnalysisInfo from './slices/basicInfo';
import SettingInfo from './slices/SettingInfo';

const rootReducer = combineReducers({
  AnalysisInfo,
  SettingInfo,
});

export default rootReducer;
