import {
  AnalysisSelectedYAxis,
  SelectYAxiosReducer,
  initAnalysisAction,
  AnalysisSummaryData,
  AnalysisDetailData,
  DetailHeaderAxiosReducer,
  DetailDataAxiosReducer,
  SummaryDataAxiosReducer,
  SummaryHeaderAxiosReducer,
} from '../reducers/slices/basicInfo';
import { useDispatch, useSelector } from 'react-redux';
import { useCallback } from 'react';

export default function useAnalysisInfo() {
  const dispatch = useDispatch();
  const yAxisValue = useSelector(AnalysisSelectedYAxis);
  const SummaryData = useSelector(AnalysisSummaryData);
  const DetailData = useSelector(AnalysisDetailData);
  const columnInfo = (type) =>
    type === 'summary' ? SummaryData.column : DetailData.column;
  const dataSource = (type) =>
    type === 'summary' ? SummaryData.dataSource : DetailData.dataSource;

  const setYAxisValue = useCallback(
    (value) => {
      dispatch(SelectYAxiosReducer(value));
    },
    [dispatch],
  );

  const setColumnInfo = useCallback(
    (type, value) => {
      type === 'summary'
        ? dispatch(SummaryHeaderAxiosReducer(value))
        : dispatch(DetailHeaderAxiosReducer(value));
    },
    [dispatch],
  );
  const setDataSource = useCallback(
    (type, value) => {
      type === 'summary'
        ? dispatch(SummaryDataAxiosReducer(value))
        : dispatch(DetailDataAxiosReducer(value));
    },
    [dispatch],
  );

  const initAnalysisValue = useCallback(() => {
    dispatch(initAnalysisAction());
  }, [dispatch]);

  return {
    yAxisValue,
    setYAxisValue,
    initAnalysisValue,
    columnInfo,
    dataSource,
    setDataSource,
    setColumnInfo,
    SummaryData,
    DetailData,
  };
}
