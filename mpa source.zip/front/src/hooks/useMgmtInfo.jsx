import { useCallback, useState } from 'react';

const useMgmtInfo = () => {
  const [isLoading, setLoading] = useState(false);
  const [isErrorStatus, setError] = useState(null);
  const [settingInfo, setSettingInfo] = useState(null);
  const [isUpdate, setUpdateFlag] = useState(false);

  const setErrorStatus = useCallback(
    (e) => {
      setError(e);
    },
    [setError],
  );

  const clearErrorStatus = useCallback(() => {
    setError(null);
  }, [setError]);

  const loadStart = useCallback(() => {
    setLoading(true);
  }, [setError]);

  const loadCompleted = useCallback(() => {
    setLoading(false);
  }, [setLoading]);

  const setMgmtInfo = useCallback(
    (info) => {
      setSettingInfo(info);
      clearUpdateFlag();
    },
    [settingInfo],
  );

  const clearMgmtInfo = useCallback(() => {
    setSettingInfo(null);
    setUpdateFlag(false);
  }, []);

  const changeDBInfo = useCallback(() => {
    setUpdateFlag(true);
  }, [isUpdate]);

  const clearUpdateFlag = useCallback(() => {
    setUpdateFlag(false);
  }, []);

  return {
    isErrorStatus,
    setErrorStatus,
    clearErrorStatus,
    isLoading,
    loadStart,
    loadCompleted,
    settingInfo,
    setMgmtInfo,
    clearMgmtInfo,
    isUpdate,
    clearUpdateFlag,
    changeDBInfo,
  };
};

export default useMgmtInfo;
