import { useState, useCallback } from 'react';
import {
  getValidPeriod,
  initialSettingAction,
  UpdateDurationReducer,
} from '../reducers/slices/SettingInfo';
import { useDispatch, useSelector } from 'react-redux';

export const initialState = {
  log_name: '',
  source: '',
  target_path: [],
  equipment_type: '',
};

const useFocusJob = () => {
  const [isOpenCreateJob, setCreateJob] = useState(true);
  const [selectJobType, setSelectJobType] = useState(null);
  const [isLoading, setLoading] = useState(false);
  const [isErrorStatus, setError] = useState(null);
  const [isSettingInfo, setSettingJobInfo] = useState(null);
  const [JobInfo, setJobInfo] = useState(initialState);
  const dispatch = useDispatch();
  const validPeriod = useSelector(getValidPeriod);
  const setValidPeriod = useCallback(
    (value) => {
      dispatch(UpdateDurationReducer(value));
    },
    [dispatch],
  );
  const initValidPeriod = useCallback(() => {
    dispatch(initialSettingAction());
  }, [dispatch]);

  const clearSelectJobType = useCallback(() => {
    setSelectJobType(null);
  }, [setCreateJob]);

  const openCreateJob = useCallback(() => {
    setCreateJob(true);
    clearSelectJobType();
  }, [setCreateJob]);

  const closeCreateJob = useCallback(() => {
    setCreateJob(false);
    clearSelectJobType();
  }, [setCreateJob]);

  const selectedJob = useCallback(
    (type) => {
      if (type !== undefined) selectJobType(type);
    },
    [setSelectJobType],
  );
  const setErrorStatus = useCallback(
    (e) => {
      setError(e);
    },
    [setError],
  );

  const clearErrorStatus = useCallback(() => {
    setError(null);
  }, [setError]);

  const loadStart = useCallback(() => {
    setLoading(true);
    clearSettingInfo();
    clearErrorStatus();
  }, [setError, setLoading, setSettingJobInfo, setJobInfo]);

  const loadCompleted = useCallback(() => {
    setLoading(false);
  }, [setLoading]);

  const setSettingInfo = useCallback(
    (setting) => {
      setSettingJobInfo(setting);
      const { log_name } = setting;
      if (log_name !== undefined) {
        setJobInfo((prevState) => ({
          ...prevState,
          log_name: log_name,
        }));
      }
    },
    [setSettingJobInfo],
  );
  const clearSettingInfo = useCallback(() => {
    setSettingJobInfo(null);
    initJobInfo();
  }, [setSettingJobInfo]);

  const initJobInfo = useCallback(() => {
    setJobInfo(initialState);
  }, [setJobInfo]);

  const updateJobInfo = useCallback(
    (info) => {
      console.log('before: ', JobInfo);
      console.log('After: ', info);
      setJobInfo(info);
    },
    [setJobInfo],
  );

  return {
    isOpenCreateJob,
    openCreateJob,
    closeCreateJob,
    selectedJob,
    selectJobType,
    setSelectJobType,
    isErrorStatus,
    setErrorStatus,
    clearErrorStatus,
    isLoading,
    loadStart,
    loadCompleted,
    isSettingInfo,
    setSettingInfo,
    clearSettingInfo,
    JobInfo,
    setJobInfo,
    updateJobInfo,
    validPeriod,
    setValidPeriod,
    initValidPeriod,
  };
};

export default useFocusJob;
