import { useCallback, useState } from 'react';

const initialState = {
  log_name: '',
  job_id: '',
  jobList: [],
};
export default function useJobStatus() {
  const [JobList, setJobList] = useState(null);
  const [sItems, setSItem] = useState(null);
  const [detailJobInfo, setDetail] = useState(null);

  const initJobListInfo = useCallback(() => {
    setJobList(initialState);
  }, [setJobList]);

  const setJobListInfo = useCallback(
    (jobList) => {
      setJobList(jobList);
    },
    [JobList],
  );

  const initSItems = useCallback(() => {
    setSItem([]);
  }, []);

  const settingItems = useCallback(
    (items) => {
      setSItem(items);
    },
    [sItems],
  );

  const initDetailJobInfo = useCallback(() => {
    setDetail(null);
  }, []);

  const setDetailJobInfo = useCallback(
    (detail) => {
      setDetail(detail);
    },
    [detailJobInfo],
  );

  return {
    JobList,
    initJobListInfo,
    setJobListInfo,

    detailJobInfo,
    setDetailJobInfo,
    initDetailJobInfo,

    sItems,
    settingItems,
    initSItems,
  };
}
