import { useCallback, useState } from 'react';

const useBasicJob = () => {
  const [isLoading, setLoading] = useState(false);
  const [isErrorStatus, setError] = useState(null);
  const [ToolInfo, setToolInfo] = useState(null);
  const [MenuInfo, setMenuInfo] = useState(null);
  const [showMgmt, setMgmtshow] = useState(null);
  const [JobUrl, setJobUrl] = useState(null);

  const setErrorStatus = useCallback(
    (e) => {
      setError(e);
    },
    [setError],
  );

  const clearErrorStatus = useCallback(() => {
    setError(null);
  }, [setError]);

  const loadStart = useCallback(() => {
    setLoading(true);
  }, [setError]);

  const loadCompleted = useCallback(() => {
    setLoading(false);
  }, [setLoading]);

  const setBasicInfo = useCallback(
    (tool, menu) => {
      setToolInfo(tool);
      setMenuInfo(menu);
    },
    [setMenuInfo, setToolInfo],
  );

  const clearToolInfo = useCallback(() => {
    setToolInfo(null);
  }, [setToolInfo]);

  const clearMenuInfo = useCallback(() => {
    setMenuInfo(null);
  }, [setMenuInfo]);

  const openMgmtPage = useCallback(() => {
    setMgmtshow(true);
  }, [setMgmtshow]);

  const closeMgmtPage = useCallback(() => {
    setMgmtshow(false);
  }, [setMgmtshow]);

  const selectJobUrl = useCallback(
    (url) => {
      console.log(url);
      setJobUrl(url);
    },
    [setJobUrl],
  );

  const clearJobUrl = useCallback(() => {
    setJobUrl(null);
  }, [setJobUrl]);

  return {
    isErrorStatus,
    setErrorStatus,
    clearErrorStatus,
    isLoading,
    loadStart,
    loadCompleted,
    ToolInfo,
    MenuInfo,
    setBasicInfo,
    clearToolInfo,
    clearMenuInfo,
    showMgmt,
    openMgmtPage,
    closeMgmtPage,
    JobUrl,
    selectJobUrl,
    clearJobUrl,
  };
};

export default useBasicJob;
