import { JobStepType, JobType } from '@typesdef/Job';
import { TypeColumnDefineTab } from './../types/columnDefine';
import { TypeConvertRule, TypeConvertRulePreview } from './../types/convertRules';

export const breadcrumbLocation = {
  status_remote: ['Status', 'Remote'],
  status_local: ['Status', 'Remote'],
  configure: ['Configure'],
  rules_logdef: ['Rules', 'Log Definition'],
  rules_logconv: ['Rules', 'Log Converter'],
};

export const LOG_HISTORY_MAX_LIST_COUNT = 50;
export const ERROR_SUMMARY_DEFAULT_BEFORE = 7;
export const CRAS_DATA_DEFAULT_BEFORE = 30;
export const MPA_VERSION_DEFAULT_BEFORE = 7;
export const EMAIL_ADDRESS_MAX = 100;
export const EMAIL_SUBJECT_MAX = 255;
export const EMAIL_BEFORE_MAX = 999;
export const CONFIGURE_NAME_MAX = 30;
export const DEFAULT_PASSWORD_VALUE = '******';
export const ACCESS_TOKEN_NAME = 'access-token';
export const REFRESH_TOKEN_NAME = 'refresh-token';
export const TOKEN_PATH = '/';
export const SESSION_STORAGE_EXPIRED = 'expired';
export const SESSION_STORAGE_TIMEOUT = 'isTimeout';
export const SESSION_STORAGE_TIMEOUT_MIN = 'timeoutMin';
export const NAME_MAX_LENGTH = 30;
export const JOB_DEFAULT_RETENTION_PERIOD = 7;

export const DISPLAY_LOCALHOST_NAME = 'localhost';
export const DEFAULT_URL = process.env.PUBLIC_URL;
export const CUSTOM_STEP_PYTHON_NAME = 'run.py';
export const CUSTOM_STEP_SCRIPT_NAME = 'run.sh';

export const ADMINISTRATOR = 'Administrator';
export const QUERY_REFETCH_INTERVAL = 3000;

export const RULE_PREVIEW_MAX_LINE = 7;

export const ERROR_LOG_ALL_USER = {
  userId: 'all',
  username: 'All',
};

export const ERROR_LOG_DEFAULT_USER = {
  userId: 'default',
  username: 'Default',
};

export const ERROR_LOG_DEFAULT_SETTING = {
  key: 'default',
  value: 'default',
  label: 'Default',
};

export const ERROR_LOG_ALL_SETTING = {
  key: 'all',
  value: 'all',
  label: 'All',
};

export const ERROR_LOG_ALL_STATUS = {
  key: 'all',
  value: 'all',
  label: 'All',
};

export const PAGE_URL = {
  FORBIDDEN: DEFAULT_URL + '/forbidden',
  NOT_FOUND: DEFAULT_URL + '/notfound',
  LOGIN: DEFAULT_URL + '/login',
  HOME: DEFAULT_URL + '/dashboard/home',
  NOT_LICENSED: DEFAULT_URL + '/dashboard/notlicensed',
  CHANGE_PASSWORD: DEFAULT_URL + '/change-password',
  test: DEFAULT_URL + '/dashboard/test',

  DEBUG_LOG: DEFAULT_URL + '/dashboard/debug',
  RULES_CONVERT: DEFAULT_URL + '/dashboard/rules/convert',
  RULES_CRAS_DATA: DEFAULT_URL + '/dashboard/rules/cras-data',
  RULES_DEFINE_COLUMN: DEFAULT_URL + '/dashboard/rules/define/column',
  RULES_DEFINE_CYLINDER: DEFAULT_URL + '/dashboard/rules/define/cylinder',
  RULES_DEFINE_MACHINE: DEFAULT_URL + '/dashboard/rules/define/machine',

  STATUS_LOCAL: DEFAULT_URL + '/dashboard/status/local',
  STATUS_LOCAL_ADD: DEFAULT_URL + '/dashboard/status/local/add',
  STATUS_REMOTE: DEFAULT_URL + '/dashboard/status/remote',
  STATUS_REMOTE_STEP: ({ jobId, jobName }: { jobId: number | string; jobName: string }): string =>
    DEFAULT_URL + `/dashboard/status/remote/step/${jobId}?name=${jobName}`,
  STATUS_REMOTE_ADD: DEFAULT_URL + '/dashboard/status/remote/add',
  STATUS_REMOTE_EDIT: ({
    jobId,
    siteId,
    jobName,
  }: {
    jobId: string | number;
    siteId: string | number;
    jobName: string;
  }): string => DEFAULT_URL + `/dashboard/status/remote/edit?sid=${siteId}&jid=${jobId}&name=${jobName}`,

  STATUS_REMOTE_BUILD_HISTORY_TYPE: DEFAULT_URL + '/dashboard/status/remote/history',
  STATUS_LOCAL_BUILD_HISTORY_TYPE: DEFAULT_URL + '/dashboard/status/local/history',
  STATUS_REMOTE_BUILD_HISTORY_ROUTE: DEFAULT_URL + '/dashboard/status/remote/history/:stepType/:jobId',
  STATUS_LOCAL_BUILD_HISTORY_ROUTE: DEFAULT_URL + '/dashboard/status/local/history/:stepType/:jobId',
  STATUS_REMOTE_LOCAL_BUILD_HISTORY: ({
    jobType,
    stepType,
    jobId,
    stepId,
    stepName,
    jobName,
    historyId,
  }: {
    jobType: JobType;
    stepType: JobStepType;
    jobId: number | string;
    stepId: number | string;
    stepName?: string | null;
    jobName?: string | null;
    historyId?: string | null;
  }): string => {
    let url = DEFAULT_URL + `/dashboard/status/${jobType}/history/${stepType}/${jobId}`;
    const params = [`jobId=${jobId}`, `stepId=${stepId}`];

    jobName && params.push(`jobName=${jobName}`);
    stepName && params.push(`stepName=${stepName}`);
    historyId && params.push(`historyId=${historyId}`);
    params.forEach((item, idx) => {
      const andChar = idx === 0 ? '?' : '&';
      url = url + andChar + item;
    });

    return url;
  },
  ERROR_LOG_DOWNLOAD: DEFAULT_URL + '/dashboard/errorlog/download',
  ERROR_LOG_STATUS: DEFAULT_URL + '/dashboard/errorlog/status',
  ERROR_LOG_SETTING: DEFAULT_URL + '/dashboard/errorlog/setting',
  CONFIGURE: DEFAULT_URL + '/dashboard/configure',
  ADDRESS_BOOK: DEFAULT_URL + '/dashboard/address',
  ACCOUNT: DEFAULT_URL + '/dashboard/account',
  SYSTEM_CONFIG: DEFAULT_URL + '/dashboard/system',
  RULES_CRAS_DATA_EDIT_CREATE: (id: string | number, name: string): string =>
    DEFAULT_URL + `/dashboard/rules/cras-data/create/${id}?name=${name}`,
  RULES_CRAS_DATA_EDIT_JUDGE: (id: string | number, name: string): string =>
    DEFAULT_URL + `/dashboard/rules/cras-data/judge/${id}?name=${name}`,
  RULES_CONVERT_RULE: ({
    type,
    inputType,
    id,
    name,
  }: {
    type: 'add' | 'edit';
    inputType: TypeConvertRule;
    id: string | number;
    name: string;
  }): string => DEFAULT_URL + `/dashboard/rules/convert/${id}/${type}?inputType=${inputType}&name=${name}`,
  RULES_ANALYSIS_MAHALANOBIS: DEFAULT_URL + '/dashboard/rules/analysis/mahalanobis',
  RULES_ANALYSIS_MAHALANOBIS_EDIT: (id: string | number, name: string): string =>
    DEFAULT_URL + `/dashboard/rules/analysis/mahalanobis/${id}?name=${name}`,
  RULES_ANALYSIS_ARCNET_ITEM: DEFAULT_URL + '/dashboard/rules/analysis/arcnet/item',
  RULES_ANALYSIS_ARCNET_ITEM_EDIT: ({
    type,
    id,
    name,
  }: {
    type: 'analysis' | 'calculate';
    id: string | number;
    name: string;
  }) => DEFAULT_URL + `/dashboard/rules/analysis/arcnet/item/${id}/${type}?name=${name}`,
  RULES_ANALYSIS_ARCNET_UNIT: DEFAULT_URL + '/dashboard/rules/analysis/arcnet/unit',
};

export const API_URL = {
  GET_HOME_REMOTE_JOB_LIST: DEFAULT_URL + '/api/v1/home',
  GET_HOME_REMOTE_JOB_DETAIL_LIST: (siteId: string | number, queries: string) =>
    DEFAULT_URL + `/api/v1/home/${siteId}${queries}`,

  GET_STATUS_SITE_LIST: DEFAULT_URL + '/api/v1/status/site',
  GET_STATUS_SITE_LIST_NOT_ADDED_REMOTE_JOB: DEFAULT_URL + '/api/v1/status/site/job',
  GET_STATUS_SITE_LIST_NOT_ADDED_CRAS_DATA: DEFAULT_URL + '/api/v1/status/site/cras',

  UPLOAD_STATUS_LOCAL_JOB_FILE_URL: DEFAULT_URL + '/api/v1/upload',

  GET_STATUS_BUILD_HISTORY_LIST: (type: string, jobId: string, stepId: string, queries: string): string =>
    DEFAULT_URL + `/api/v1/history/${type}/${jobId}/${stepId}${queries}`,

  GET_STATUS_BUILD_HISTORY_STATUS: (id: string): string => DEFAULT_URL + `/api/v1/history/${id}`,
  GET_STATUS_BUILD_HISTORY_LOG: ({
    type,
    jobId,
    stepId,
    historyId,
    serverType,
  }: {
    type: JobType;
    jobId: number | string;
    stepId: number | string;
    historyId: string | number;
    serverType: 'logmonitor' | 'cras';
  }): string => DEFAULT_URL + `/api/v1/history/${type}/${jobId}/${stepId}/${historyId}/${serverType}`,
  GET_STATUS_BUILD_HISTORY_LOG_DOWNLOAD: ({
    serverType,
    historyId,
  }: {
    serverType: string;
    historyId: string;
  }): string => DEFAULT_URL + `/api/v1/upload/job/history/${historyId}/${serverType}`,
  DELETE_STATUS_BUILD_HISTORY_LOG: (historyId: string): string => DEFAULT_URL + `/api/v1/history/${historyId}`,

  GET_STATUS_REMOTE_JOB_LIST: DEFAULT_URL + '/api/v1/status/job/remote',
  GET_STATUS_REMOTE_JOB_STEP_LIST: (jobId: string | number): string =>
    DEFAULT_URL + `/api/v1/status/job/remote/${jobId}/step`,
  GET_STATUS_REMOTE_JOB_BUILD_QUEUE: (jobId: string | number): string =>
    DEFAULT_URL + `/api/v1/status/job/remote/${jobId}/buildqueue`,
  GET_STATUS_REMOTE_JOB_BUILD_EXECUTOR: (jobId: string | number): string =>
    DEFAULT_URL + `/api/v1/status/job/remote/${jobId}/buildexecutor`,
  GET_STATUS_REGISTERED_JOB_FOR_SITE: (siteId: string | number): string =>
    DEFAULT_URL + `/api/v1/status/site/${siteId}/job`,
  GET_STATUS_REMOTE_JOB_INFO: (id: string | number): string => DEFAULT_URL + `/api/v1/job/remote/${id}`,
  GET_STATUS_REMOTE_JOB_TIME_LINE: (id: string | number): string => DEFAULT_URL + `/api/v1/job/remote/timeline/${id}`,
  GET_STATUS_REMOTE_JOB_STOP_STATUS: (jobId: string | number): string =>
    DEFAULT_URL + `/api/v1/status/job/remote/${jobId}/status`,
  GET_STATUS_REMOTE_JOB_STOP_STATUS_ALL: (jobId: string | number): string =>
    DEFAULT_URL + `/api/v1/status/job/remote/${jobId}/status/all`,
  GET_STATUS_REMOTE_PLAN_LIST: (siteId: string | number): string => DEFAULT_URL + `/api/v1/job/remote/plan/${siteId}`,
  POST_STATUS_REMOTE_JOB_STEP_FILES: DEFAULT_URL + '/api/v1/upload/job/remote/custom',
  GET_STATUS_REMOTE_JOB_STEP_FILES: (jobId: string | number, stepId: string): string =>
    DEFAULT_URL + `/api/v1/upload/job/remote/custom/${stepId}?jobId=${jobId}`,
  POST_STATUS_REMOTE_JOB: DEFAULT_URL + '/api/v1/job/remote',
  PUT_STATUS_REMOTE_JOB: (jobId: string | number): string => DEFAULT_URL + `/api/v1/job/remote/${jobId}`,
  DELETE_STATUS_REMOTE_JOB: (jobId: string | number): string => DEFAULT_URL + `/api/v1/job/remote/${jobId}`,
  RUN_STATUS_REMOTE_JOB: (jobId: string | number): string => DEFAULT_URL + `/api/v1/job/remote/${jobId}/run`,
  STOP_STATUS_REMOTE_JOB: (jobId: string | number): string => DEFAULT_URL + `/api/v1/job/remote/${jobId}/stop`,
  EXECUTE_MANUAL_STATUS_REMOTE_STEP: (jobId: string | number, stepId: string | number): string =>
    DEFAULT_URL + `/api/v1/job/remote/manual/${jobId}/${stepId}`,
  GET_STATUS_REMOTE_JOB_JUDGE_RULE_LIST: (siteId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/cras/${siteId}/judge/enable`,

  GET_STATUS_REMOTE_JOB_IS_CUSTOM: DEFAULT_URL + `/api/v1/job/custom`,
  GET_STATUS_REMOTE_JOB_EXPORT: DEFAULT_URL + `/api/v1/upload/job/remote`,
  POST_STATUS_REMOTE_JOB_UPLOAD_IMPORT_FILE: DEFAULT_URL + `/api/v1/upload/job/remote`,
  POST_STATUS_REMOTE_JOB_IMPORT: DEFAULT_URL + `/api/v1/job/remote/import`,
  POST_STATUS_REMOTE_JOB_IMPORT_CUSTOMIZE: DEFAULT_URL + `/api/v1/job/remote/list`,
  GET_STATUS_REMOTE_JOB_COPY: (jobId: string | number): string => DEFAULT_URL + `/api/v1/job/remote/copy/${jobId}`,
  POST_STATUS_REMOTE_JOB_COPY: DEFAULT_URL + `/api/v1/job/remote/copy`,
  PATCH_STATUS_REMOTE_MANUAL_EXECUTE_JOB: (jobId: string | number): string =>
    DEFAULT_URL + `/api/v1/job/remote/manual/${jobId}`,

  GET_STATUS_LOCAL_JOB_LIST: (queries?: string) => DEFAULT_URL + `/api/v1/status/job/local${queries ?? ''}`,
  POST_STATUS_LOCAL_JOB: DEFAULT_URL + '/api/v1/job/local',
  DELETE_STATUS_LOCAL_JOB: (jobId: string | number): string => DEFAULT_URL + `/api/v1/job/local/${jobId}`,

  GET_ERROR_LOG_LIST: (siteId: string | number, queries: string): string =>
    DEFAULT_URL + `/api/v1/errorlog/${siteId}${queries}`,
  GET_ERROR_LOG_SETTING_LIST: (siteId: string | number, userId: string | number, queries: string): string =>
    DEFAULT_URL + `/api/v1/errorlog/setting/${siteId}/${userId}${queries}`,
  POST_ERROR_LOG_DOWNLOAD: (siteId: string | number, userId: string | number): string =>
    DEFAULT_URL + `/api/v1/errorlog/download/${siteId}/${userId}`,
  GET_ERROR_LOG_STATUS_LIST: (siteId: string | number, userId: string | number, queries: string): string =>
    DEFAULT_URL + `/api/v1/errorlog/download/${siteId}/${userId}${queries}`,
  GET_ERROR_LOG_DOWNLOAD: DEFAULT_URL + '/api/v1/errorlog/download',
  GET_ERROR_LOG_DOWNLOAD_STATUS: DEFAULT_URL + '/api/v1/errorlog/download/status',
  GET_ERROR_LOG_EXPORT: (siteId: string | number, userId: string | number): string =>
    DEFAULT_URL + `/api/v1/upload/errorlog/${siteId}/${userId}`,
  GET_ERROR_LOG_IMPORT: (siteId: string | number, userId: string | number): string =>
    DEFAULT_URL + `/api/v1/upload/errorlog/${siteId}/${userId}`,
  GET_ERROR_LOG_DOWNLOAD_FILE: (id: string): string => DEFAULT_URL + `/api/v1/errorlog/download/file/${id}`,
  GET_ERROR_LOG_CATEGORY_OPTIONS: (siteId: string | number): string =>
    DEFAULT_URL + `/api/v1/errorlog/setting/category/${siteId}`,

  POST_ERROR_LOG_SETTING_ADD: (siteId: string | number, userId: string | number) =>
    DEFAULT_URL + `/api/v1/errorlog/setting/${siteId}/${userId}`,
  PUT_ERROR_LOG_SETTING_EDIT: (siteId: string | number, userId: string | number, itemId: string | number) =>
    DEFAULT_URL + `/api/v1/errorlog/setting/${siteId}/${userId}/${itemId}`,
  DELETE_ERROR_LOG_SETTING: (siteId: string | number, userId: string | number, itemId: string | number) =>
    DEFAULT_URL + `/api/v1/errorlog/setting/${siteId}/${userId}/${itemId}`,

  GET_CONFIGURE_SITE_DB: DEFAULT_URL + '/api/v1/site',
  POST_CONFIGURE_SITE_DB: DEFAULT_URL + '/api/v1/site',
  GET_CONFIGURE_SITE_DB_DETAIL: (siteId: string | number): string => DEFAULT_URL + `/api/v1/site/${siteId}`,
  PUT_CONFIGURE_SITE_DB: (siteId: string | number): string => DEFAULT_URL + `/api/v1/site/${siteId}`,
  DELETE_CONFIGURE_SITE_DB: (siteId: string | number): string => DEFAULT_URL + `/api/v1/site/${siteId}`,
  GET_CONFIGURE_HOST_DB: DEFAULT_URL + '/api/v1/host',
  POST_CONFIGURE_HOST_DB: DEFAULT_URL + '/api/v1/host',
  GET_CONFITURE_CRAS_CONNECTION: DEFAULT_URL + '/api/v1/site/connection/cras',
  GET_CONFITURE_EMAIL_CONNECTION: DEFAULT_URL + '/api/v1/site/connection/email',
  GET_CONFITURE_EMAIL_SEND: DEFAULT_URL + '/api/v1/site/connection/email-send',
  GET_CONFITURE_RSS_CONNECTION: DEFAULT_URL + '/api/v1/site/connection/rss',
  GET_CONFIGURE_LOG_MONITOR_VERSION: DEFAULT_URL + '/api/v1/version',
  GET_CONFIGURE_SITE_JOB_STATUS: (siteId: string | number): string => DEFAULT_URL + `/api/v1/site/${siteId}/jobstatus`,
  GET_CONFIGURE_SITE_STATUS: DEFAULT_URL + `/api/v1/site/status`,
  GET_CONFIGURE_EXPORT: DEFAULT_URL + `/api/v1/upload/site`,
  GET_CONFIGURE_IMPORT: DEFAULT_URL + `/api/v1/upload/site`,

  GET_LOG_MONITOR_OOS: DEFAULT_URL + '/LICENSE.md',

  GET_AUTH_LOGIN: (username: string, password: string): string =>
    DEFAULT_URL + `/api/v1/auth/login?username=${username}&password=${password}`,
  GET_AUTH_ME: DEFAULT_URL + '/api/v1/auth/me',
  GET_AUTH_LOGOUT: DEFAULT_URL + '/api/v1/auth/logout',
  POST_AUTH_REISSUE: DEFAULT_URL + '/api/v1/auth/reissue',

  // Account / Group
  GET_ACCOUNT_GROUP_SUMMARY_LIST: DEFAULT_URL + '/api/v1/user/group',
  GET_ACCOUNT_GROUP_BY_ID: (id: string | number): string => DEFAULT_URL + `/api/v1/user/group/${id}`,
  POST_ACCOUNT_GROUP: DEFAULT_URL + '/api/v1/user/group',
  PUT_ACCOUNT_GROUP: (id: string | number): string => DEFAULT_URL + `/api/v1/user/group/${id}`,
  DELETE_ACCOUNT_GROUP: (id: string | number): string => DEFAULT_URL + `/api/v1/user/group/${id}`,
  // Account / User
  GET_ACCOUNT_USER_SUMMARY_LIST: DEFAULT_URL + '/api/v1/user',
  GET_ACCOUNT_USER_SUMMARY_LIST_WITH_ADMIN: DEFAULT_URL + '/api/v1/user?admin=true',
  GET_ACCOUNT_USER_BY_ID: (id: string | number): string => DEFAULT_URL + `/api/v1/user/${id}`,
  POST_ACCOUNT_USER: DEFAULT_URL + '/api/v1/user',
  PUT_ACCOUNT_USER: (id: string | number): string => DEFAULT_URL + `/api/v1/user/${id}`,
  DELETE_ACCOUNT_USER: (id: string | number): string => DEFAULT_URL + `/api/v1/user/${id}`,

  // Account / User / Change password
  PUT_ACCOUNT_CHANGE_PASSWORD: (userId: number | string) => DEFAULT_URL + `/api/v1/user/password/${userId}`,

  // Account / Import, Export
  POST_ACCOUNT_IMPORT: DEFAULT_URL + '/api/v1/upload/user',
  GET_ACCOUNT_EXPORT: DEFAULT_URL + '/api/v1/upload/user',

  GET_ADDRESS_GROUP_EMAIL_LIST: DEFAULT_URL + '/api/v1/address',
  GET_ADDRESS_GROUP_LIST: DEFAULT_URL + '/api/v1/address/group',
  GET_ADDRESS_GROUP_LIST_IN_EMAIL: (emailId: string | number): string =>
    DEFAULT_URL + `/api/v1/address/email/${emailId}/group`,
  GET_ADDRESS_EMAIL_LIST: DEFAULT_URL + '/api/v1/address/email',
  GET_ADDRESS_EMAIL_LIST_BY_GROUP: (groupId: string | number): string =>
    DEFAULT_URL + `/api/v1/address/group/${groupId}/email/`,
  SEARCH_ADDRESS_EMAIL: (keyword: string): string => DEFAULT_URL + `/api/v1/address/search?keyword=${keyword}`,
  SEARCH_ADDRESS_GROUP_EMAIL: (keyword: string): string =>
    DEFAULT_URL + `/api/v1/address/search?keyword=${keyword}&group=true`,
  POST_ADDRESS_IMPORT: DEFAULT_URL + '/api/v1/upload/address',
  GET_ADDRESS_EXPORT: DEFAULT_URL + '/api/v1/upload/address',

  POST_ADDRESS_ADD_EMAIL: DEFAULT_URL + '/api/v1/address/email',
  DELETE_ADDRESS_DELETE_EMAIL: (emailIds: number[]): string =>
    DEFAULT_URL + `/api/v1/address/email?ids=${emailIds.toString()}`,
  PUT_ADDRESS_EDIT_EMAIL: (emailId: string | number): string => DEFAULT_URL + `/api/v1/address/email/${emailId}`,
  POST_ADDRESS_ADD_GROUP: DEFAULT_URL + '/api/v1/address/group',
  PUT_ADDRESS_EDIT_GROUP: (groupId: string | number): string => DEFAULT_URL + `/api/v1/address/group/${groupId}`,
  DELETE_ADDRESS_DELETE_GROUP: (groupId: string | number): string => DEFAULT_URL + `/api/v1/address/group/${groupId}`,

  GET_CRAS_INFO_LIST: DEFAULT_URL + '/api/v1/rule/cras',
  POST_CRAS_SITE_ADD: DEFAULT_URL + '/api/v1/rule/cras',
  POST_CRAS_SITE_COPY: (siteId: string | number, newSiteId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/cras/copy/${siteId}?newSiteId=${newSiteId}`,
  DELETE_CRAS_SITE_DELETE: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/cras/${id}`,
  GET_CRAS_MANUAL_CREATE_INFO_LIST: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/cras/${id}/create`,
  GET_CRAS_MANUAL_CREATE_INFO_DETAIL: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/cras/${id}/create/${itemId}`,
  GET_CRAS_MANUAL_CREATE_TARGET_TABLE: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/cras/${id}/table`,
  GET_CRAS_MANUAL_CREATE_TARGET_COLUMN: (id: string | number, name: string): string =>
    DEFAULT_URL + `/api/v1/rule/cras/${id}/table/${name}`,
  POST_CRAS_MANUAL_CREATE_TEST_QUERY: DEFAULT_URL + '/api/v1/rule/cras/testquery',
  POST_CRAS_MANUAL_CREATE_ADD: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/cras/${id}/create`,
  PUT_CRAS_MANUAL_CREATE_EDIT: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/cras/${id}/create/${itemId}`,
  DELETE_CRAS_MANUAL_CREATE_DELETE: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/cras/${id}/create/${itemId}`,
  GET_CRAS_MANUAL_JUDGE_INFO_LIST: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/cras/${id}/judge`,
  GET_CRAS_MANUAL_JUDGE_INFO_DETAIL: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/cras/${id}/judge/${itemId}`,
  POST_CRAS_MANUAL_JUDGE_ADD: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/cras/${id}/judge`,
  PUT_CRAS_MANUAL_JUDGE_EDIT: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/cras/${id}/judge/${itemId}`,
  DELETE_CRAS_MANUAL_JUDGE_DELETE: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/cras/${id}/judge/${itemId}`,
  GET_CRAS_MANUAL_CREATE_OPTION: DEFAULT_URL + '/api/v1/rule/cras/option/createlist',
  GET_CRAS_MANUAL_JUDGE_OPTION: DEFAULT_URL + '/api/v1/rule/cras/option/judgelist',
  GET_CRAS_MANUAL_EQUIP_OPTION: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/cras/equipments/${id}`,

  POST_CRAS_IMPORT_FILE: (id: string | number): string => DEFAULT_URL + `/api/v1/upload/crasdatafile/${id}`,
  GET_CRAS_EXPORT_FILE: (id: string | number): string => DEFAULT_URL + `/api/v1/upload/crasdatafile/${id}`,

  // convert rules
  GET_CONVERT_LOG_LIST: (queries: string): string => DEFAULT_URL + `/api/v1/rule/convert/log${queries}`,
  GET_CONVERT_LOG: (id: string | number | undefined): string => DEFAULT_URL + `/api/v1/rule/convert/log/${id}`,
  POST_CONVERT_LOG: DEFAULT_URL + `/api/v1/rule/convert/log`,
  PUT_CONVERT_LOG: (id: string | number | undefined): string => DEFAULT_URL + `/api/v1/rule/convert/log/${id}`,
  GET_CONVERT_ERROR: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/convert/log/${id}/error`,
  DELETE_CONVERT_LOG: (id: string | number | undefined): string => DEFAULT_URL + `/api/v1/rule/convert/log/${id}`,
  POST_CONVERT_LOG_IMPORT: DEFAULT_URL + `/api/v1/rule/convert/log/file/import`,
  GET_CONVERT_LOG_EXPORT: DEFAULT_URL + `/api/v1/rule/convert/log/file/export`,

  GET_CONVERT_RULE: (logId: string | number | undefined): string =>
    DEFAULT_URL + `/api/v1/rule/convert/log/${logId}/rule`,
  POST_CONVERT_RULE: (logId: string | number | undefined): string =>
    DEFAULT_URL + `/api/v1/rule/convert/log/${logId}/rule`,
  PUT_CONVERT_RULE: (logId: string | number | undefined): string =>
    DEFAULT_URL + `/api/v1/rule/convert/log/${logId}/rule`,
  GET_CONVERT_RULE_OPTION: DEFAULT_URL + '/api/v1/rule/convert/rule/option',
  POST_CONVERT_RULE_PREVIEW: (inputType: TypeConvertRule, previewType: TypeConvertRulePreview): string =>
    DEFAULT_URL + `/api/v1/rule/convert/rule/preview/${previewType}/${inputType}`,
  POST_CONVERT_RULE_HEADER_PARSING: (id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/convert/header/${id}/parse`,

  // column define
  GET_COLUMN_DEFINE_LIST: (type: string | number, queries: string): string =>
    DEFAULT_URL + `/api/v1/rule/define/column/${type}${queries}`,
  POST_COLUMN_DEFINE: (type: TypeColumnDefineTab): string => DEFAULT_URL + `/api/v1/rule/define/column/${type}`,
  PUT_COLUMN_DEFINE: (type: TypeColumnDefineTab, id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/define/column/${type}/${id}`,
  DELETE_COLUMN_DEFINE: (type: TypeColumnDefineTab, id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/define/column/${type}/${id}`,
  POST_COLUMN_DEFINE_IMPORT: DEFAULT_URL + `/api/v1/rule/define/column/import`,
  GET_COLUMN_DEFINE_EXPORT: DEFAULT_URL + `/api/v1/rule/define/column/export`,

  // cylinder param define
  GET_DEFINE_CYLINDER_LIST: DEFAULT_URL + `/api/v1/rule/define/cylinder`,
  GET_DEFINE_CYLINDER: (id: string | number) => DEFAULT_URL + `/api/v1/rule/define/cylinder/${id}`,
  POST_DEFINE_CYLINDER: DEFAULT_URL + `/api/v1/rule/define/cylinder`,
  PUT_DEFINE_CYLINDER: (id: string | number) => DEFAULT_URL + `/api/v1/rule/define/cylinder/${id}`,
  DELETE_DEFINE_CYLINDER: (id: string | number) => DEFAULT_URL + `/api/v1/rule/define/cylinder/${id}`,
  POST_DEFINE_CYLINDER_IMPORT: DEFAULT_URL + `/api/v1/rule/define/cylinder/import`,
  GET_DEFINE_CYLINDER_EXPORT: DEFAULT_URL + `/api/v1/rule/define/cylinder/export`,

  // machine data param define
  GET_DEFINE_MACHINE_LIST: DEFAULT_URL + `/api/v1/rule/define/machine`,
  GET_DEFINE_MACHINE: (id: string | number) => DEFAULT_URL + `/api/v1/rule/define/machine/${id}`,
  POST_DEFINE_MACHINE: DEFAULT_URL + `/api/v1/rule/define/machine`,
  PUT_DEFINE_MACHINE: (id: string | number) => DEFAULT_URL + `/api/v1/rule/define/machine/${id}`,
  DELETE_DEFINE_MACHINE: (id: string | number) => DEFAULT_URL + `/api/v1/rule/define/machine/${id}`,
  POST_DEFINE_MACHINE_IMPORT: DEFAULT_URL + `/api/v1/rule/define/machine/import`,
  GET_DEFINE_MACHINE_EXPORT: DEFAULT_URL + `/api/v1/rule/define/machine/export`,

  // arcnet item
  GET_ANALYSIS_ARCNET_ITEM_REGISTER_STATUS: DEFAULT_URL + `/api/v1/status/site/arcnet/items`,
  GET_ANALYSIS_ARCNET_ITEM: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}`,
  GET_ANALYSIS_ARCNET_ITEM_LIST: DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items`,
  POST_ANALYSIS_ARCNET_ITEM: DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items`,
  POST_ANALYSIS_ARCNET_ITEM_COPY: DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/copy`,
  DELETE_ANALYSIS_ARCNET_ITEM: (id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}`,
  GET_ARCNET_ITEM_EXPORT: (id: string | number) => DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/export/${id}`,
  POST_ARCNET_ITEM_IMPORT: (id: string | number) => DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/import/${id}`,

  GET_ANALYSIS_ARCNET_ITEM_ANALYSIS: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}/analysis/${itemId}`,
  GET_ANALYSIS_ARCNET_ITEM_ANALYSIS_LIST: (id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}/analysis-items`,
  POST_ANALYSIS_ARCNET_ITEM_ANALYSIS: (id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}/analysis-items`,
  PUT_ANALYSIS_ARCNET_ITEM_ANALYSIS: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}/analysis-items/${itemId}`,
  DELETE_ANALYSIS_ARCNET_ITEM_ANALYSIS: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}/analysis-items/${itemId}`,

  GET_ANALYSIS_ARCNET_ITEM_CALCULATE: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}/calculate-items/${itemId}`,
  GET_ANALYSIS_ARCNET_ITEM_CALCULATE_LIST: (id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}/calculate-items`,
  POST_ANALYSIS_ARCNET_ITEM_CALCULATE: (id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}/calculate-items`,
  PUT_ANALYSIS_ARCNET_ITEM_CALCULATE: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}/calculate-items/${itemId}`,
  DELETE_ANALYSIS_ARCNET_ITEM_CALCULATE: (id: string | number, itemId: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/items/${id}/calculate-items/${itemId}`,

  GET_ANALYSIS_ARCNET_UNIT_LIST: DEFAULT_URL + `/api/v1/rule/analysis/arcnet/units`,
  GET_ANALYSIS_ARCNET_UNIT: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/analysis/arcnet/units/${id}`,
  POST_ANALYSIS_ARCNET_UNIT: DEFAULT_URL + `/api/v1/rule/analysis/arcnet/units`,
  PUT_ANALYSIS_ARCNET_UNIT: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/analysis/arcnet/units/${id} `,
  DELETE_ANALYSIS_ARCNET_UNIT: (id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/units/${id}`,
  POST_ANALYSIS_ARCNET_UNIT_IMPORT: (id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/units/${id} `,
  GET_ANALYSIS_ARCNET_UNIT_EXPORT: (id: string | number): string =>
    DEFAULT_URL + `/api/v1/rule/analysis/arcnet/units/${id}/file`,

  // mahalanobis
  GET_MAHALANOBIS_LIST: DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis`,
  GET_MAHALANOBIS_SITE_LIST: DEFAULT_URL + `/api/v1/status/site/mahalanobis`,
  POST_MAHALANOBIS_ADD: DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis`,
  DELETE_MAHALANOBIS: (id: string | number): string => DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis/${id}`,
  POST_MAHALANOBIS_UPLOAD_EXPORT_FILE: (pathId: string | number) =>
    DEFAULT_URL + `/api/v1/upload/mahalanobis/${pathId}`,
  POST_MAHALANOBIS_IMPORT_CUSTOMIZE: (pathId: string | number) =>
    DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis/list/${pathId}`,
  POST_MAHALANOBIS_COPY: (pathId: string | number) => DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis/copy/${pathId}`,
  GET_MAHALANOBIS_EXPORT: (pathId: string | number) => DEFAULT_URL + `/api/v1/upload/mahalanobis/${pathId}`,
  GET_MAHALANOBIS_ITEM_LIST: (id: string | number) => DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis/${id}/item`,
  GET_MAHALANOBIS_ITEM_BY_ID: (id: string | number, itemId: string | number) =>
    DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis/${id}/item/${itemId}`,
  GET_MAHALANOBIS_ITEM_OPTIONS: (id: string | number) =>
    DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis/${id}/options`,
  POST_MAHALANOBIS_ITEM_ADD: (id: string | number) => DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis/${id}/item`,
  PUT_MAHALANOBIS_ITEM_EDIT: (id: string | number, itemId: string | number) =>
    DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis/${id}/item/${itemId}`,
  DELETE_MAHALANOBIS_ITEM: (id: string | number, itemId: string | number) =>
    DEFAULT_URL + `/api/v1/rule/analysis/mahalanobis/${id}/item/${itemId}`,

  GET_DOWNLOAD_LOG_MOINITOR_DEBUG_LOG: (path: string): string =>
    DEFAULT_URL + `/api/v1/backup/logmonitor` + encodeURI(`?path=${path}`),
  GET_DOWNLOAD_CRAS_DEBUG_LOG: (siteId: number | string): string => DEFAULT_URL + `/api/v1/backup/crasserver/${siteId}`,
  GET_DOWNLOAD_CONVERT_ERROR_LOG: (logId: number | string, id: string | number) =>
    DEFAULT_URL + `/api/v1/upload/convert/log/${logId}/error/${id}`,

  GET_SYSTEM_CONFIG_DEFAULT_EMAIL: DEFAULT_URL + '/api/v1/setting/email',
  PUT_SYSTEM_CONFIG_DEFAULT_EMAIL: DEFAULT_URL + '/api/v1/setting/email',

  GET_SYSTEM_CONFIG_FTP: DEFAULT_URL + '/api/v1/setting/ftp',
  GET_SYSTEM_CONFIG_FTP_BY_ID: (id: number | string): string => DEFAULT_URL + `/api/v1/setting/ftp/${id}`,
  POST_SYSTEM_CONFIG_FTP: DEFAULT_URL + '/api/v1/setting/ftp',
  PUT_SYSTEM_CONFIG_FTP: (id: number | string): string => DEFAULT_URL + `/api/v1/setting/ftp/${id}`,
  DELETE_SYSTEM_CONFIG_FTP: (id: number | string): string => DEFAULT_URL + `/api/v1/setting/ftp/${id}`,
  POST_SYSTEM_CONFIG_FTP_TEST: DEFAULT_URL + '/api/v1/setting/ftp/test',

  GET_SYSTEM_CONFIG_LICENSE: DEFAULT_URL + '/api/v1/setting/license',
  GET_SYSTEM_CONFIG_LICENSE_EXPORT: DEFAULT_URL + '/api/v1/setting/license/file',
  POST_SYSTEM_CONFIG_LICENSE_IMPORT: DEFAULT_URL + '/api/v1/setting/license/file',

  GET_SYSTEM_CONFIG_RETENTION: DEFAULT_URL + '/api/v1/setting/retention',
  PUT_SYSTEM_CONFIG_RETENTION: DEFAULT_URL + '/api/v1/setting/retention',

  GET_DEBUG_SELECT_CRAS_SERVER: DEFAULT_URL + '/api/v1/backup/crasserver/use',
  PUT_DEBUG_SELECT_CRAS_SERVER: DEFAULT_URL + `/api/v1/backup/crasserver/use`,

  // Cras DB Viewer
  GET_CRAS_DB_VIEWER_TABLE_LIST: DEFAULT_URL + '/api/v1/dbviewer/dbinfo',
  GET_CRAS_DB_VIEWER_DATA_TAB_INFO_FROM_TREE: (siteId: number, queries: string) =>
      DEFAULT_URL + `/api/v1/dbviewer/data/${siteId}?${queries}search`,
  GET_CRAS_DB_VIEWER_COLUMN_TAB_INFO: (siteId: number, schema: string, table: string) =>
      DEFAULT_URL + `/api/v1/dbviewer/columninfo/${siteId}?schema=${schema}&table=${table}`,
  GET_CRAS_DB_VIEWER_DEFAULT_QUERY: (siteId: number, schema: string, table: string) =>
      DEFAULT_URL + `/api/v1/dbviewer/default-sql/${siteId}?schema=${schema}&table=${table}`,
  POST_CRAS_DB_VIEWER_DATA_TAB_INFO_FROM_QUERY: (siteId: number) => DEFAULT_URL + `/api/v1/dbviewer/query/${siteId}`,
};

export enum ERROR_MESSAGE {
  DUPLICATE_USERNAME = 'duplicate username',
  INVALID_PASSWORD = 'invalid password',
  INVALID_USERNAME = 'invalid username',
  INVALID_CURRENT_PASSWORD = 'invalid current password',
  INVALID_ROLES = 'invalid roles',
  INVALID_USER = 'invalid user',
}
