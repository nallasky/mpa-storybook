import { AccountUserRoleType } from '@typesdef/account';
import { ReqRemoteJobStep } from '@typesdef/Job';

export const IS_REFRESH_BTN = false;
export const IS_SYNC_ICON = false;
export const NAV_BAR_HIGHT = 64;

export const MODAL_NAME = {
  HOME: {
    REMOTE_JOB_DETAIL: 'home-remotejob-detail',
  },

  ERROR_LOG: {
    FILTER: 'errorLog-filter',
    SEARCH: 'errorLog-search',
    DOWNLOAD: 'errorLog-download',
    IMPORT: 'errorLog-import',
    ADD_EDIT: 'errorLog-add-edit',
  },
  RULE_CONVERT: {
    LOG_ADD_EDIT: 'rule-convert-log-add-edit',
    ERROR_LOG: 'rule-convert-error-log',
    SEARCH: 'rule-convert-search',
    INFO_SELECT: 'rule-convert-info-select',
    TAG_ADD_EDIT: 'rule-convert-tag-add-edit',
    ITEM_ADD_EDIT: 'rule-convert-item-add-edit',
    FILTER_ADD_EDIT: 'rule-convert-filter-add-edit',
    FILE_IMPORT: 'rule-convert-file-import',
    NO_HEADER_COPY: 'rule-convert-noheader-copy',
  },
  COLUMN_DEFINE: {
    ITEM_ADD_EDIT: 'column-define-item-add-edit',
    SEARCH: 'column-define-search',
    FILE_IMPORT: 'column-define-import',
  },
  REMOTE_JOB: {
    FILE_IMPORT_UPLOAD: 'remote-import-upload',
    FILE_IMPORT_CUSTOMIZE: 'remote-import-customize',
    FILE_EXPORT: 'remote-export',
    COPY_JOB_SELECT: 'remote-copy-job-select',
    COPY_JOB_CUSTOMIZE: 'remote-copy-job-customize',
  },
  CRAS_DATA: {
    COPY: 'cras-data-copy',
  },
  ADDRESS_BOOK: {
    ADD_EDIT: 'address-book-add-edit',
  },
  SYSTEM_CONFIG: {
    FTP: {
      ADD_EDIT: 'system-config-ftp-add-edit',
    },
    LICENSE: {
      FILE_IMPORT: 'system-config-license-file-import',
    },
  },
  ACCOUNT: {
    GROUP: {
      ADD_EDIT: 'account-group-add-edit',
    },
    USER: {
      ADD_EDIT: 'account-user-add-edit',
    },
    FILE_IMPORT: 'account-file-import',
  },
  AUTH: {
    CHANGE_PASSWORD: 'auth-change-password',
    INVALID_LICENSE: 'auth-invalid-license',
  },
  MAHALANOBIS: {
    ADD: 'mahalanobis-add',
    COPY: 'mahalanobis-copy',
    IMPORT_UPLOAD: 'mahalanobis-import-upload',
    IMPORT_CUSTOMIZE: 'mahalanobis-import-customize',
  },
  ARCNET: {
    ITEM: {
      ADD: 'arcnet-item-add',
      IMPORT: 'arcnet-item-import',
      COPY: 'arcnet-item-copy',
    },
    UNIT: {
      ADD: 'arcnet-unit-add',
      FILE_VIEW: 'arcnet-unit-file-view',
      IMPORT: 'arcnet-unit-import',
    },
  },
  DEFINE: {
    CYLINDER: {
      ADD_EDIT: 'define-cylinder-add-edit',
      IMPORT: 'define-cylinder-import',
    },
    MACHINE: {
      ADD_EDIT: 'define-machine-add-edit',
      IMPORT: 'define-machine-import',
    },
  },
};

export const initialReqJobStep: ReqRemoteJobStep = {
  uuid: null,
  stepId: null,
  stepName: null,
  stepType: 'convert',
  enable: false,
  mode: null,
  time: [],
  cycle: null,
  period: null,
  preStep: null,
  nextStep: null,
  isEmail: false,
  customEmails: [],
  emailBookIds: [],
  groupBookIds: [],
  subject: null,
  body: null,
  before: null,
  selectJudgeRuleIds: [],
  description: null,
  scriptType: null,
  script: null,
  fileIndices: [],
  planIds: [],
  retentionPeriod: null,
  isFtp: false,
  ftps: [],
};

export const ACCOUNT_USER_ROLES: {
  [key in AccountUserRoleType]: AccountUserRoleType;
} = {
  ROLE_STATUS: 'ROLE_STATUS',
  ROLE_JOB: 'ROLE_JOB',
  ROLE_CONFIGURE: 'ROLE_CONFIGURE',
  ROLE_RULES: 'ROLE_RULES',
  ROLE_ADDRESS: 'ROLE_ADDRESS',
  ROLE_ACCOUNT: 'ROLE_ACCOUNT',
  ROLE_ERRORLOG: 'ROLE_ERRORLOG',
};

export const accountUserRolesArr = Object.values(ACCOUNT_USER_ROLES);
