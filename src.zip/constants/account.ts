import { AccountUserRoleType } from '@typesdef/account';

export const ACCOUNT_ROLE: Record<
  AccountUserRoleType,
  {
    TITLE: string;
    KEY: AccountUserRoleType;
  }
> = {
  ROLE_STATUS: {
    TITLE: 'STATUS',
    KEY: 'ROLE_STATUS',
  },
  ROLE_JOB: {
    TITLE: 'JOB',
    KEY: 'ROLE_JOB',
  },
  ROLE_CONFIGURE: {
    TITLE: 'SERVER CONFIG',
    KEY: 'ROLE_CONFIGURE',
  },
  ROLE_RULES: {
    TITLE: 'RULES',
    KEY: 'ROLE_RULES',
  },
  ROLE_ADDRESS: {
    TITLE: 'ADDRESS BOOK',
    KEY: 'ROLE_ADDRESS',
  },
  ROLE_ACCOUNT: {
    TITLE: 'ACCOUNT',
    KEY: 'ROLE_ACCOUNT',
  },
  ROLE_ERRORLOG: {
    TITLE: 'ERROR LOG',
    KEY: 'ROLE_ERRORLOG',
  },
};
