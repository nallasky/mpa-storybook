import GlobalModalProvider from '@libs/context/GlobalModalProvider';
import { QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './index.css';
import { queryClient } from './libs/query/configure';
import store from './reducers/store';
import reportWebVitals from './reportWebVitals';

async function main() {
  if (process.env.NODE_ENV === 'development' && process.env.REACT_APP_MSW === 'ENABLE') {
    const { worker } = await import('@libs/msw/worker');

    await worker.start({
      serviceWorker: {
        url: `${process.env.PUBLIC_URL}/mockServiceWorker.js`,
        // options: {
        //   scope: `${process.env.PUBLIC_URL}/api/v1/rule/convert`,
        // },
      },
      onUnhandledRequest: 'bypass',
    });
  }

  const root = ReactDOM.createRoot(document.getElementById('root') as HTMLElement);

  root.render(
    <React.StrictMode>
      <Provider store={store}>
        <GlobalModalProvider>
          <QueryClientProvider client={queryClient}>
            <BrowserRouter>
              <App />
            </BrowserRouter>
            <ReactQueryDevtools initialIsOpen={false} />
          </QueryClientProvider>
        </GlobalModalProvider>
      </Provider>
    </React.StrictMode>,
  );

  // If you want to start measuring performance in your app, pass a function
  // to log results (for example: reportWebVitals(console.log))
  // or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
  reportWebVitals();
}

main();
