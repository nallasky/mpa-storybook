import { useGetAuthMe } from '@libs/query/auth';
import { setLoginUser } from '@reducers/slices/loginUser';
import type { AuthLoginUserData } from '@typesdef/auth';
import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import useModals from './useModal';

export default function useValidateLogin() {
  const dispatch = useDispatch();
  const { openModal } = useModals();
  const navigate = useNavigate();

  const { mutateAsync: mutateAsyncMe } = useGetAuthMe();

  const validateToken = useCallback(async (): Promise<AuthLoginUserData | null> => {
    try {
      const loginUserInfo = await mutateAsyncMe();
      if (loginUserInfo.id && loginUserInfo.roles && loginUserInfo.username) {
        dispatch(setLoginUser({ ...loginUserInfo, isLoggedIn: true }));

        return {
          ...loginUserInfo,
        };
      }
    } catch (error) {
      console.error(error);
    }

    return null;
  }, [dispatch, mutateAsyncMe]);

  return {
    validateToken,
  };
}
