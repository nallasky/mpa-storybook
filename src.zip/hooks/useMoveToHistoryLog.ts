import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { PAGE_URL } from '../constants/constants';
import { JobStepType, JobType } from '../types/Job';

export default function useMoveToHistoryLog() {
  const navigate = useNavigate();

  const moveToHistoryLog = useCallback(
    ({
      jobType,
      stepType,
      jobId,
      jobName,
      stepId,
      stepName,
      historyId,
    }: {
      jobType: JobType;
      stepType: JobStepType;
      jobName?: string | null;
      jobId: number | string;
      stepId: number | string;
      stepName?: string | null;
      historyId?: string | null;
    }) => {
      navigate(
        PAGE_URL.STATUS_REMOTE_LOCAL_BUILD_HISTORY({
          jobType,
          stepType,
          jobId,
          stepId,
          stepName,
          jobName,
          historyId,
        }),
      );
    },

    [navigate],
  );

  return { moveToHistoryLog };
}
