import { SESSION_STORAGE_TIMEOUT_MIN } from './../constants/constants';

import { SESSION_STORAGE_EXPIRED, SESSION_STORAGE_TIMEOUT } from '@constants/constants';
import { openNotification } from '@libs/util/notification';
import { useEffect } from 'react';
export default function useCoreEffect() {
  useEffect(() => {
    if (window.sessionStorage.getItem(SESSION_STORAGE_EXPIRED) === 'true') {
      openNotification('info', 'Notice', ['Refresh token is expired.', 'Please log in again.']);
      window.sessionStorage.removeItem(SESSION_STORAGE_EXPIRED);
    }

    if (window.sessionStorage.getItem(SESSION_STORAGE_TIMEOUT) === 'true') {
      const timeout = window.sessionStorage.getItem(SESSION_STORAGE_TIMEOUT_MIN) ?? '30';
      openNotification('info', 'Session Timeout', `You have been logged out due to inactivity for ${timeout} minutes.`);
      window.sessionStorage.removeItem(SESSION_STORAGE_TIMEOUT);
      window.sessionStorage.removeItem(SESSION_STORAGE_TIMEOUT_MIN);
    }
  }, []);
}
