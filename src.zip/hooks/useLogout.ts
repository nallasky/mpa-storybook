import { PAGE_URL } from '@constants/constants';
import { useGetLogOut } from '@libs/query/auth';
import { useCallback } from 'react';

export default function useLogout() {
  const { mutateAsync: mutateLogoutAsync } = useGetLogOut();

  const onLogout = useCallback(() => {
    mutateLogoutAsync().finally(() => {
      window.location.replace(PAGE_URL.LOGIN);
    });
  }, [mutateLogoutAsync]);

  return { onLogout } as const;
}
