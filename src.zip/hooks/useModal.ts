import { useContext, useCallback } from 'react';
import { GlobalModalDispatchContext } from '@libs/context/GlobalModalContext';
import { GlobalModalProps } from '@typesdef/modal';

export default function useModals() {
  const { open = undefined, close = undefined } = useContext(GlobalModalDispatchContext) ?? {};

  if (!open || !close) {
    throw new Error('useCount must be used within a GlobalModalProvider');
  }

  const openModal = useCallback(
    <T>(key: string, Component: GlobalModalProps<T>['Component'], props?: GlobalModalProps<T>['props']) => {
      open(key, Component, props);
    },
    [open],
  );

  const closeModal = useCallback(
    (key: string) => {
      close(key);
    },
    [close],
  );

  return {
    openModal,
    closeModal,
  };
}
