import { useCallback } from 'react';
import { createGlobalState } from 'react-use';

export type ResponseUploadFile = {
  name: string | undefined;
  fileIndex: number | undefined;
  uid: string | undefined;
  status: string | undefined;
};

const useGlobalUpload = {
  useFiles: createGlobalState<any>([]),
  useResponseFiles: createGlobalState<ResponseUploadFile[]>([]),
};

export default function useUploadFiles() {
  const [files, setFiles] = useGlobalUpload.useFiles();
  const [resFiles, setResFiles] = useGlobalUpload.useResponseFiles();

  const initUploadFiles = useCallback(() => {
    setFiles([]);
    setResFiles([]);
  }, [setFiles, setResFiles]);

  const setUploadFiles = useCallback(
    (value: any) => {
      setFiles(value);
    },
    [setFiles],
  );

  const setResponseFiles = useCallback(
    (value: ResponseUploadFile[]) => {
      setResFiles(value);
    },
    [setResFiles],
  );

  return {
    uploadFiles: files,
    responseFiles: resFiles,
    initUploadFiles,
    setResponseFiles,
    setUploadFiles,
  } as const;
}
