import { CustomPagination, ReqFilterParam, ReqSearchParam } from '@typesdef/common';
import { TableProps } from 'antd/es/table';
import { SorterResult } from 'antd/es/table/interface';
import { useCallback, useReducer } from 'react';

type ReducerAction =
  | { type: 'searchParam'; payload: ReqSearchParam }
  | { type: 'filterParam'; payload: ReqFilterParam }
  | { type: 'pagination'; payload: Partial<CustomPagination> }
  | { type: 'isRequesting'; payload: boolean };

export interface ReducerSearchState {
  searchParam: ReqSearchParam;
  filterParam: ReqFilterParam;
  pagination: CustomPagination;
  isRequesting: boolean;
}

const initialState: ReducerSearchState = {
  searchParam: {},
  filterParam: {},
  pagination: {
    current: 1,
    pageSize: 10,
    total: 0,
    sort: {},
  },
  isRequesting: false,
};

function reducer(state: ReducerSearchState, action: ReducerAction): ReducerSearchState {
  switch (action.type) {
    case 'searchParam':
      if (JSON.stringify(state.searchParam) !== JSON.stringify(action.payload)) {
        return {
          ...state,
          isRequesting: true,
          searchParam: action.payload,
          pagination: { ...state.pagination, current: 1 },
        };
      }
      return state;
    case 'filterParam':
      if (JSON.stringify(state.filterParam) !== JSON.stringify(action.payload)) {
        return {
          ...state,
          isRequesting: true,
          filterParam: action.payload,
          pagination: { ...state.pagination, current: 1 },
        };
      }
      return state;
    case 'pagination':
      return { ...state, isRequesting: true, pagination: { ...state.pagination, ...action.payload } };
    case 'isRequesting':
      return { ...state, isRequesting: action.payload };
    default:
      return state;
  }
}

export default function useTableSortSearch() {
  const [{ isRequesting, pagination, searchParam, filterParam }, dispatch] = useReducer(reducer, initialState);
  const hasSearchParam = Object.keys(searchParam).length > 0;
  const hasFilterParam = Object.keys(filterParam).length > 0;

  const setPagination = (value: Partial<CustomPagination>) => {
    dispatch({ type: 'pagination', payload: value });
  };

  const setSearchParam = (value: ReqSearchParam) => {
    dispatch({ type: 'searchParam', payload: value });
  };

  const setFilterParam = (value: ReqFilterParam) => {
    dispatch({ type: 'filterParam', payload: value });
  };

  const setRequesting = (value: boolean) => {
    dispatch({ type: 'isRequesting', payload: value });
  };

  const onChangeTable = useCallback<NonNullable<TableProps<any>['onChange']>>((pagination, filters, sorter, extra) => {
    const { current, pageSize } = pagination;
    const { column, columnKey, order } = sorter as SorterResult<any>;

    const sort: CustomPagination['sort'] = {};

    const convertKeys: Record<string, string[]> = { companyFabName: ['fabName', 'companyName'] };

    if (column && columnKey && order) {
      if (convertKeys[columnKey]) {
        convertKeys[columnKey].forEach((item) => {
          sort[item] = order === 'ascend' ? 'asc' : 'desc';
        });
      } else {
        sort[columnKey.toString()] = order === 'ascend' ? 'asc' : 'desc';
      }
    }
    dispatch({ type: 'pagination', payload: { current: current as number, pageSize: pageSize as number, sort } });
  }, []);

  return {
    isRequesting,
    pagination,
    searchParam,
    hasSearchParam,
    filterParam,
    hasFilterParam,
    setPagination,
    setSearchParam,
    setFilterParam,
    setRequesting,
    onChangeTable,
  } as const;
}
