import AddressBook from '@components/AddressBook';
import { PAGE_URL } from '@constants/constants';
import React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';

export type AddressPageProps = {
  children?: React.ReactNode;
};

export default function AddressPage({ children }: AddressPageProps): JSX.Element {
  return (
    <Routes>
      <Route index element={<AddressBook />} />
      <Route path="*" element={<Navigate replace to={PAGE_URL.NOT_FOUND} />} />
    </Routes>
  );
}
