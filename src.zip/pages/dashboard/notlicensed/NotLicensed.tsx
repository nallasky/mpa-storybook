import { themeisle_not_licensed } from '@assets/images';
import { MotionDivWrapper } from '@components/common/atoms/Wrapper';
import { PAGE_URL } from '@constants/constants';
import { css } from '@emotion/react';
import { loginUserHasLicenseRoleSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { Button } from 'antd';
import { useNavigate } from 'react-router-dom';

export default function NotLicensedPage() {
  const navigate = useNavigate();
  const hasLicenseRole = useTypedSelector(loginUserHasLicenseRoleSelector);
  const goToSystemConfig = () => {
    navigate(PAGE_URL.SYSTEM_CONFIG);
  };

  return (
    <MotionDivWrapper cssStyle={style}>
      <img alt="page not found" src={themeisle_not_licensed} />
      <div className="text">Not Licensed</div>
      {hasLicenseRole && (
        <Button className="btn" onClick={goToSystemConfig}>
          Go to License
        </Button>
      )}
    </MotionDivWrapper>
  );
}

const style = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  justify-content: center;
  min-height: 53.25rem;
  width: 100%;
  img {
    width: 40rem;
    height: auto;
  }
  .text {
    font-size: 2rem;
    font-weight: 700;
  }
  .btn {
    margin-top: 1rem;
  }
`;
