export { default } from './NotLicensed';
