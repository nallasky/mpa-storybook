import { V_SPACE } from '@components/common/atoms/Space';
import { ContentWrapper } from '@components/common/atoms/Wrapper';
import ErrorLogDownload from '@components/ErrorLog/ErrorLogDownload';
import ErrorLogSetting from '@components/ErrorLog/ErrorLogSetting';
import ErrorLogStatus from '@components/ErrorLog/ErrorLogStatus';
import ErrorLogUserFabName from '@components/ErrorLog/ErrorLogUserFabName';
import { PAGE_URL } from '@constants/constants';
import styled from '@emotion/styled';

import { Navigate, Outlet, Route, Routes } from 'react-router-dom';

export type ErrorLogPageProps = {};

export default function ErrorLogPage({}: ErrorLogPageProps) {
  return (
    <Routes>
      <Route
        element={
          <ContentWrapper>
            <ErrorLogUserFabName />
            <V_SPACE rem={3} />
            <Outlet />
          </ContentWrapper>
        }
      >
        <Route path="download" element={<ErrorLogDownload />} />
        <Route path="status" element={<ErrorLogStatus />} />
        <Route path="setting" element={<ErrorLogSetting />} />
      </Route>

      <Route path="*" element={<Navigate replace to={PAGE_URL.NOT_FOUND} />} />
    </Routes>
  );
}
