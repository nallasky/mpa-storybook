import ConfigSetting from '@components/ConfigSetting';
import { PAGE_URL } from '@constants/constants';
import React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';

export type ConfigurePageProps = {
  children?: React.ReactNode;
};

export default function ConfigurePage({ children }: ConfigurePageProps) {
  return (
    <Routes>
      <Route index element={<ConfigSetting />} />
      <Route path="*" element={<Navigate replace to={PAGE_URL.NOT_FOUND} />} />
    </Routes>
  );
}
