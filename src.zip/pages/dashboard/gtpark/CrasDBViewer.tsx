import React from 'react';
import { default as CrasDBViewerComponent } from '../../../components/gtpark/CrasDBViewer';

export default function CrasDBViewer() {
  return <CrasDBViewerComponent />;
}