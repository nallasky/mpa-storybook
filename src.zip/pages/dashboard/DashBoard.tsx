import PrivateRoute from '@components/common/atoms/PrivateRoute';
import RoleRoute from '@components/common/atoms/RoleRoute';
import { MotionDivWrapper } from '@components/common/atoms/Wrapper';
import AppLayout from '@components/common/templates/AppLayout';
import DashBoardBreadcrumb from '@components/DashBoardBreadcrumb';
import DashBoardFooter from '@components/DashBoardFooter';
import DashBoardNavBar from '@components/DashBoardHeader';
import DebugLog from '@components/DebugLog/DebugLog';
import Home from '@components/Home';
import { ACCOUNT_ROLE } from '@constants/account';
import { PAGE_URL } from '@constants/constants';
import { Fragment } from 'react';
import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import AccountPage from './account';
import AddressPage from './address';
import ConfigurePage from './configure';
import ErrorLogPage from './errorlog';
import NotLicensedPage from './notlicensed';
import RulesPage from './rules';
import StatusPage from './status';
import SystemConfigPage from './system';
import CrasDBViewer from "./gtpark";

export type DashBoardPageProps = {};

function DashBoardPage({}: DashBoardPageProps) {
  return (
    <Routes>
      <Route
        element={
          <PrivateRoute>
            <DashBoardWrapper />
          </PrivateRoute>
        }
      >
        <Route index element={<Navigate replace to={PAGE_URL.HOME} />} />
        <Route path="home/*" element={<Home />} />
        <Route path="status/*" element={<StatusPage />} />
        <Route path="errorlog/*" element={<ErrorLogPage />} />
        <Route
          path="configure/*"
          element={
            <RoleRoute role={ACCOUNT_ROLE.ROLE_CONFIGURE.KEY}>
              <ConfigurePage />
            </RoleRoute>
          }
        />
        <Route
          path="rules/*"
          element={
            <RoleRoute role={ACCOUNT_ROLE.ROLE_RULES.KEY}>
              <RulesPage />
            </RoleRoute>
          }
        />
        <Route
          path="address/*"
          element={
            <RoleRoute role={ACCOUNT_ROLE.ROLE_ADDRESS.KEY}>
              <AddressPage />
            </RoleRoute>
          }
        />
        <Route
          path="account/*"
          element={
            <RoleRoute role={ACCOUNT_ROLE.ROLE_ACCOUNT.KEY}>
              <AccountPage />
            </RoleRoute>
          }
        />

        <Route
          path="system/*"
          element={
            <RoleRoute role={ACCOUNT_ROLE.ROLE_CONFIGURE.KEY}>
              <SystemConfigPage />
            </RoleRoute>
          }
        />

        <Route path="test" element={<CrasDBViewer />} />
        <Route path="debug" element={<DebugLog />} />
        <Route path="notlicensed" element={<NotLicensedPage />} />
        <Route path="*" element={<Navigate replace to={PAGE_URL.NOT_FOUND} />} />
      </Route>
    </Routes>
  );
}

function DashBoardWrapper({}: DashBoardPageProps) {
  const { key } = useLocation();

  return (
    <Fragment>
      <AppLayout.Header>
        <DashBoardNavBar />
      </AppLayout.Header>
      <AppLayout.Main>
        <AppLayout.Main.BreadCrumb>
          <DashBoardBreadcrumb />
        </AppLayout.Main.BreadCrumb>
        <AppLayout.Main.Contents>
          <MotionDivWrapper>
            <Outlet key={key} />
          </MotionDivWrapper>
        </AppLayout.Main.Contents>
      </AppLayout.Main>
      <AppLayout.Footer>
        <DashBoardFooter />
      </AppLayout.Footer>
    </Fragment>
  );
}
export default DashBoardPage;
