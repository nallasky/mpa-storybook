export { default } from './System';
