import SystemConfig from '@components/SystemConfig';
import { PAGE_URL } from '@constants/constants';
import React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';

export type SystemConfigPageProps = {
  children?: React.ReactNode;
};

export default function SystemConfigPage({ children }: SystemConfigPageProps) {
  return (
    <Routes>
      <Route index element={<SystemConfig />} />
      <Route path="*" element={<Navigate replace to={PAGE_URL.NOT_FOUND} />} />
    </Routes>
  );
}
