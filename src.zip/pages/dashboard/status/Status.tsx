import BuildHistory from '@components/BuildHistory';
import LocalJob from '@components/LocalJob';
import LocalJobStatus from '@components/LocalJobStatus';
import RemoteJob from '@components/RemoteJob';
import RemoteJobStatus from '@components/RemoteJobStatus';
import RemoteJobStatusStep from '@components/RemoteJobStatus/RemoteJobStatusStep';
import { PAGE_URL } from '@constants/constants';
import { Navigate, Route, Routes } from 'react-router-dom';

export type StatusPageProps = {};

export default function StatusPage({}: StatusPageProps): JSX.Element {
  return (
    <Routes>
      <Route path="local" element={<LocalJobStatus />} />
      <Route path="local/add" element={<LocalJob />} />

      <Route path="remote" element={<RemoteJobStatus />} />
      <Route path="remote/step/:jobId" element={<RemoteJobStatusStep />} />
      <Route path="remote/add" element={<RemoteJob type={'add'} />} />
      <Route path="remote/edit" element={<RemoteJob type={'edit'} />} />

      <Route path="remote/history/:stepType/:jobId" element={<BuildHistory />} />
      <Route path="local/history/:stepType/:jobId" element={<BuildHistory />} />

      <Route path="*" element={<Navigate replace to={PAGE_URL.NOT_FOUND} />} />
    </Routes>
  );
}
