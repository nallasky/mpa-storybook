import Account from '@components/Account';
import { PAGE_URL } from '@constants/constants';
import React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';

export type AccountPageProps = {
  children?: React.ReactNode;
};

export default function AccountPage({ children }: AccountPageProps) {
  return (
    <Routes>
      <Route index element={<Account />} />
      <Route path="*" element={<Navigate replace to={PAGE_URL.NOT_FOUND} />} />
    </Routes>
  );
}
