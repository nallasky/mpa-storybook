import ArcnetItemAnalysis from '@components/Arcnet/ArcnetItemAnalysis';
import ArcnetItemCalculate from '@components/Arcnet/ArcnetItemCalculate';
import ArcnetItemSetting from '@components/Arcnet/ArcnetItemSetting';
import ArcnetUnitSetting from '@components/Arcnet/ArcnetUnitSetting';
import ColumnDefine from '@components/ColumnDefine';
import Convert from '@components/Convert';
import ConvertRule from '@components/Convert/ConvertRule';
import CrasData from '@components/CrasData';
import CrasDataEdit from '@components/CrasData/CrasDataEdit';
import DefineParam from '@components/DefineParam';

import Mahalanobis from '@components/Mahalanobis';
import MahalanobisEdit from '@components/Mahalanobis/MahalanobisEdit';
import { PAGE_URL } from '@constants/constants';
import { Navigate, Route, Routes } from 'react-router-dom';

export type RulesPageProps = {};

export default function RulesPage({}: RulesPageProps) {
  return (
    <Routes>
      <Route path="convert" element={<Convert />} />
      <Route path="convert/:id/:mode" element={<ConvertRule />} />
      <Route path="cras-data" element={<CrasData />} />
      <Route path="cras-data/create/:id" element={<CrasDataEdit type="create" />} />
      <Route path="cras-data/judge/:id" element={<CrasDataEdit type="judge" />} />
      <Route path="define/column" element={<ColumnDefine />} />
      <Route path="define/cylinder" element={<DefineParam type="cylinder" />} />
      <Route path="define/machine" element={<DefineParam type="machine" />} />
      <Route path="analysis/mahalanobis" element={<Mahalanobis />} />
      <Route path="analysis/mahalanobis/:id" element={<MahalanobisEdit />} />
      <Route path="analysis/arcnet/item" element={<ArcnetItemSetting />} />
      <Route path="analysis/arcnet/unit" element={<ArcnetUnitSetting />} />
      <Route path="analysis/arcnet/item/:id/analysis" element={<ArcnetItemAnalysis />} />
      <Route path="analysis/arcnet/item/:id/calculate" element={<ArcnetItemCalculate />} />
      <Route path="*" element={<Navigate replace to={PAGE_URL.NOT_FOUND} />} />
    </Routes>
  );
}
