import { themeisle_page_not_found } from '@assets/images';
import { MotionDivWrapper } from '@components/common/atoms/Wrapper';
import { PAGE_URL } from '@constants/constants';
import { css } from '@emotion/react';
import { Button } from 'antd';
import { useNavigate } from 'react-router-dom';

export type NotFoundPageProps = {};

export default function NotFoundPage({}: NotFoundPageProps): JSX.Element {
  const navigate = useNavigate();

  const goToHome = () => {
    navigate(PAGE_URL.HOME);
  };

  return (
    <MotionDivWrapper cssStyle={style}>
      <img alt="page not found" src={themeisle_page_not_found} />
      <div className="text">Page not found</div>
      <Button className="btn" onClick={goToHome}>
        Go to Home
      </Button>
    </MotionDivWrapper>
  );
}

const style = css`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  height: 100vh;
  img {
    width: 40rem;
    height: auto;
  }
  .text {
    font-size: 2rem;
    font-weight: 700;
  }
  .btn {
    margin-top: 1rem;
  }
`;
