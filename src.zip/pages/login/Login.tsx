import { MotionDivWrapper } from '@components/common/atoms/Wrapper';
import AppLayout from '@components/common/templates/AppLayout';
import UserLogin from '@components/UserLogin';
import React from 'react';

export type LoginPageProps = {
  children?: React.ReactNode;
};

export default function LoginPage({ children }: LoginPageProps) {
  return (
    <AppLayout.FullContents>
      <MotionDivWrapper>
        <UserLogin />
      </MotionDivWrapper>
    </AppLayout.FullContents>
  );
}
