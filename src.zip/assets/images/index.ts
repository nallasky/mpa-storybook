export { default as themeisle_not_licensed } from './themeisle_not_licensed.svg';
export { default as themeisle_page_not_found } from './themeisle_page_not_found.svg';
export { default as undraw_create } from './undraw_create.svg';
export { default as undraw_page_forbidden } from './undraw_page_forbidden.svg';
export { default as undraw_selection } from './undraw_selection.svg';
export { default as themeisle_change_password } from './themeisle_change_password.svg';
