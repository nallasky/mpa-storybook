import { ScrollToTop } from '@components/common/atoms/Common/Common';
import GlobalModal from '@components/common/atoms/GlobalModal';
import AppLayout from '@components/common/templates/AppLayout';
import SessionTimeoutV2 from '@components/SessionTimeout/SessionTimeoutV2';
import { DEFAULT_URL, PAGE_URL } from '@constants/constants';
import { css, Global } from '@emotion/react';
import useCoreEffect from '@hooks/useCoreEffect';
import ChangePassword from '@pages/changePassword';
import Dashboard from '@pages/dashboard';
import Forbidden from '@pages/forbidden';
import Login from '@pages/login';
import NotFound from '@pages/notfound';
import { zIndexStyle } from '@styles/emotion/common';
import { BackTop } from 'antd';
import { AnimatePresence } from 'framer-motion';
import { Fragment } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import './App.css';
import globalStyle from './globalStyle';

export default function App() {
  useCoreEffect();

  return (
    <Fragment>
      <AppLayout>
        <AnimatePresence mode="wait">
          <Routes>
            <Route index element={<Navigate replace to={PAGE_URL.HOME} />} />
            <Route path={`${DEFAULT_URL}/*`}>
              <Route index element={<Navigate replace to={PAGE_URL.HOME} />} />
              <Route path="login" element={<Login />} />
              <Route path="dashboard/*" element={<Dashboard />} />
              <Route path="forbidden" element={<Forbidden />} />
              <Route path="notfound" element={<NotFound />} />
              <Route path="change-password" element={<ChangePassword />} />
              <Route path="*" element={<Navigate replace to={PAGE_URL.NOT_FOUND} />} />
            </Route>
          </Routes>
        </AnimatePresence>
      </AppLayout>
      <SessionTimeoutV2 />
      <Global styles={globalStyle} />
      <ScrollToTop />
      <BackTop css={zIndexStyle} />
      <GlobalModal />
      <iframe
        title="download-iframe"
        id="download-iframe"
        css={css`
          display: none;
        `}
      />
    </Fragment>
  );
}
