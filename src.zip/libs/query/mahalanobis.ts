import { API_URL } from '@constants/constants';
import { deleteRequest, downloadBlobRequest, getRequest, postRequest, putRequest } from '@libs/axios/requests';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import { ResDownloadBlob } from '@typesdef/common';
import type {
  MahalanobisData,
  MahalanobisItemData,
  MahalanobisItemOptions,
  MahalanobisRegisterStatusData,
  MahalanobisRegisterStatusItemData,
  MahalanobisSiteLabeledData,
  ReqAddMahalanobisData,
  ReqImportMahalanobisItem,
  ReqMahalanobisItemData,
  ResMahalanobisItemOptions,
  ResUploadMahalanobisData,
} from '@typesdef/mahalanobis';
import { LabeledValue } from 'antd/es/select';
import { AxiosError } from 'axios';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const useGetMahalanobisList = (
  options?: UseQueryOptions<MahalanobisData[], AxiosError, MahalanobisData[], QueryKey>,
): UseQueryResult<MahalanobisData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_MAHALANOBIS_LIST] as QueryKey,
    ({ signal }) => getRequest<MahalanobisData[]>({ url: API_URL.GET_MAHALANOBIS_LIST, options: { signal } }),
    {
      ...options,
    },
  );

export const useGetMahalanobisRegisterStatusList = (
  valueKey: keyof MahalanobisRegisterStatusItemData,
  options?: UseQueryOptions<MahalanobisRegisterStatusData, AxiosError, MahalanobisSiteLabeledData, QueryKey>,
): UseQueryResult<MahalanobisSiteLabeledData, AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_MAHALANOBIS_SITE_LIST, valueKey] as QueryKey,
    ({ signal }) =>
      getRequest<MahalanobisRegisterStatusData>({ url: API_URL.GET_MAHALANOBIS_SITE_LIST, options: { signal } }),
    {
      ...options,
      select: (data) => {
        const registered =
          data?.registered?.map((item) => ({ key: `${item.siteId}`, label: item.name, value: item[valueKey] })) ?? [];
        const unregistered =
          data?.unregistered?.map((item) => ({ key: `${item.siteId}`, label: item.name, value: item[valueKey] })) ?? [];
        return { registered, unregistered };
      },
    },
  );

export const usePostMahalanobisAdd = (
  options?: UseMutationOptions<unknown, AxiosError, ReqAddMahalanobisData, unknown>,
): UseMutationResult<unknown, AxiosError, ReqAddMahalanobisData, unknown> =>
  useMutation(
    (reqData) =>
      postRequest<ReqAddMahalanobisData>({
        url: API_URL.POST_MAHALANOBIS_ADD,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_MAHALANOBIS_ADD] as QueryKey,
      ...options,
    },
  );

export const useDeleteMahalanobis = (
  options?: UseMutationOptions<unknown, AxiosError, number, unknown>,
): UseMutationResult<unknown, AxiosError, number, unknown> =>
  useMutation(
    (id) =>
      deleteRequest({
        url: API_URL.DELETE_MAHALANOBIS(id),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_MAHALANOBIS_DELETE] as QueryKey,
      ...options,
    },
  );

export const useGetMahalanobisItemList = (
  id: number,
  options?: UseQueryOptions<MahalanobisItemData[], AxiosError, MahalanobisItemData[], QueryKey>,
): UseQueryResult<MahalanobisItemData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_MAHALANOBIS_ITEM_LIST, id] as QueryKey,
    ({ signal }) =>
      getRequest<MahalanobisItemData[]>({ url: API_URL.GET_MAHALANOBIS_ITEM_LIST(id), options: { signal } }),
    {
      ...options,
    },
  );

export const useGetMahalanobisItemById = (
  id: number,
  itemId: number,
  options?: UseQueryOptions<MahalanobisItemData, AxiosError, MahalanobisItemData, QueryKey>,
): UseQueryResult<MahalanobisItemData, AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_MAHALANOBIS_ITEM_BY_ID, id, itemId] as QueryKey,
    ({ signal }) =>
      getRequest<MahalanobisItemData>({ url: API_URL.GET_MAHALANOBIS_ITEM_BY_ID(id, itemId), options: { signal } }),
    {
      ...options,
    },
  );

export const useGetMahalanobisItemOptions = (
  id: number,
  options?: UseQueryOptions<ResMahalanobisItemOptions, AxiosError, MahalanobisItemOptions, QueryKey>,
): UseQueryResult<MahalanobisItemOptions, AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_MAHALANOBIS_ITEM_OPTIONS, id] as QueryKey,
    ({ signal }) =>
      getRequest<ResMahalanobisItemOptions>({
        url: API_URL.GET_MAHALANOBIS_ITEM_OPTIONS(id),
        options: { signal },
      }),

    {
      ...options,
      select: ({ equipment, target }) => {
        const newColName: MahalanobisItemOptions['colname'] = {};
        Object.entries(target).forEach(([key, options]) => {
          newColName[key] = options?.map((option) => ({
            key: option,
            label: option,
            value: option,
          }));
        });

        return {
          equipment:
            equipment?.map(({ equipment_id, equipment_name }) => ({
              key: equipment_id,
              label: equipment_name,
              value: equipment_id,
            })) ?? [],
          target:
            Object.keys(target)?.map(
              (key): LabeledValue => ({
                key,
                label: key,
                value: key,
              }),
            ) ?? [],
          colname: newColName,
        };
      },
    },
  );

export const usePostMahalanobisItemAdd = (
  options?: UseMutationOptions<unknown, AxiosError, ReqMahalanobisItemData, unknown>,
): UseMutationResult<unknown, AxiosError, ReqMahalanobisItemData, unknown> =>
  useMutation(
    (reqData) => {
      const { parentId, ...restData } = reqData;
      return postRequest<MahalanobisItemData>({
        url: API_URL.POST_MAHALANOBIS_ITEM_ADD(parentId),
        reqData: restData,
      });
    },
    {
      mutationKey: [MUTATION_KEY.RULES_MAHALANOBIS_ITEM_ADD] as QueryKey,
      ...options,
    },
  );

export const usePutMahalanobisItemEdit = (
  options?: UseMutationOptions<unknown, AxiosError, ReqMahalanobisItemData, unknown>,
): UseMutationResult<unknown, AxiosError, ReqMahalanobisItemData, unknown> =>
  useMutation(
    (reqData) => {
      const { parentId, ...restData } = reqData;
      return putRequest<MahalanobisItemData>({
        url: API_URL.PUT_MAHALANOBIS_ITEM_EDIT(parentId, reqData.id),
        reqData: restData,
      });
    },
    {
      mutationKey: [MUTATION_KEY.RULES_MAHALANOBIS_ITEM_EDIT] as QueryKey,
      ...options,
    },
  );

export const useDeleteMahalanobisItem = (
  options?: UseMutationOptions<unknown, AxiosError, Pick<ReqMahalanobisItemData, 'parentId' | 'id'>, unknown>,
): UseMutationResult<unknown, AxiosError, Pick<ReqMahalanobisItemData, 'parentId' | 'id'>, unknown> =>
  useMutation(
    ({ parentId, id }) =>
      deleteRequest({
        url: API_URL.DELETE_MAHALANOBIS_ITEM(parentId, id),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_MAHALANOBIS_ITEM_DELETE] as QueryKey,
      ...options,
    },
  );

export const usePostMahalanobisImportCustomize = (
  options?: UseMutationOptions<unknown, AxiosError, ReqImportMahalanobisItem, unknown>,
): UseMutationResult<unknown, AxiosError, ReqImportMahalanobisItem, unknown> =>
  useMutation(
    ({ pathId, reqData }: ReqImportMahalanobisItem) =>
      postRequest({
        url: API_URL.POST_MAHALANOBIS_IMPORT_CUSTOMIZE(pathId),
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_MAHALANOBIS_IMPORT_CUSTOMIZE] as QueryKey,
      ...options,
    },
  );

export const useGetMahalanobisExport = (
  options?: UseMutationOptions<ResDownloadBlob, AxiosError, number, unknown>,
): UseMutationResult<ResDownloadBlob, AxiosError, number, unknown> =>
  useMutation(
    (pathId) =>
      downloadBlobRequest({
        url: API_URL.GET_MAHALANOBIS_EXPORT(pathId),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_MAHALANOBIS_EXPORT] as QueryKey,
      ...options,
    },
  );

export const usePostMahalanobisJobCopy = (
  options?: UseMutationOptions<ResUploadMahalanobisData[], AxiosError, number, unknown>,
): UseMutationResult<ResUploadMahalanobisData[], AxiosError, number, unknown> =>
  useMutation(
    (sourceId) =>
      postRequest({
        url: API_URL.POST_MAHALANOBIS_COPY(sourceId),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_MAHALANOBIS_COPY] as QueryKey,
      ...options,
    },
  );
