import { ErrorDescriptionError } from '@components/common/atoms/ErrorDescription/ErrorDescription';
import { API_URL } from '@constants/constants';
import { deleteRequest, getRequest, postRequest, putRequest } from '@libs/axios/requests';
import { getQueriesParam } from '@libs/util/convert';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import { ReqParam, ResDownloadBlob, ResPagination } from '@typesdef/common';
import {
  ConvertLogItem,
  ConvertRuleItem,
  ConvertRuleItemErrorMsg,
  ConvertRuleOption,
  CrasError,
  MutationPostConvertPreviewConvert,
  MutationPostConvertPreviewFilter,
  MutationPostConvertPreviewSample,
  ReqConvertHeaderParsing,
  ReqConvertLog,
  ReqConvertPreviewConvert,
  ReqConvertPreviewFilter,
  ReqConvertRule,
  ResConvertPreview,
  ResConvertRule,
  ResConvertRuleError,
} from '@typesdef/convertRules';
import { AxiosError } from 'axios';
import { downloadBlobRequest } from './../axios/requests';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const useGetConvertLogList = (
  params: ReqParam,
  options?: UseQueryOptions<ResPagination<ConvertLogItem[]>, AxiosError, ResPagination<ConvertLogItem[]>, QueryKey>,
): UseQueryResult<ResPagination<ConvertLogItem[]>, AxiosError> => {
  const { query, pagination, search } = params;

  return useQuery(
    [QUERY_KEY.RULES_CONVERT_LIST, { ...query, ...pagination, ...search }] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_CONVERT_LOG_LIST(
          getQueriesParam({
            query,
            pagination,
            search,
          }),
        ),
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

export const useGetConvertLog = (
  id: string | number | undefined,
  options?: UseQueryOptions<ConvertLogItem, AxiosError, ConvertLogItem, QueryKey>,
): UseQueryResult<ConvertLogItem, AxiosError> => {
  return useQuery(
    [QUERY_KEY.RULES_CONVERT_ITEM, id] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_CONVERT_LOG(id),
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

export const usePostConvertLog = (
  options?: UseMutationOptions<unknown, AxiosError, ReqConvertLog, unknown>,
): UseMutationResult<unknown, AxiosError, ReqConvertLog, unknown> =>
  useMutation(
    (reqData) =>
      postRequest<ReqConvertLog['data']>({
        url: API_URL.POST_CONVERT_LOG,
        reqData: reqData.data,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_CONVERT_ADD_LOG] as QueryKey,
      ...options,
    },
  );

export const usePutConvertLog = (
  options?: UseMutationOptions<unknown, AxiosError, ReqConvertLog, unknown>,
): UseMutationResult<unknown, AxiosError, ReqConvertLog, unknown> =>
  useMutation(
    (reqData) =>
      putRequest<ReqConvertLog['data']>({
        url: API_URL.PUT_CONVERT_LOG(reqData.id),
        reqData: reqData.data,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_CONVERT_EDIT_LOG] as QueryKey,
      ...options,
    },
  );

export const useDeleteConvertLog = (
  options?: UseMutationOptions<unknown, AxiosError, number, unknown>,
): UseMutationResult<unknown, AxiosError, number, unknown> =>
  useMutation(
    (id) =>
      deleteRequest({
        url: API_URL.DELETE_CONVERT_LOG(id),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_CONVERT_DELETE_LOG] as QueryKey,
      ...options,
    },
  );

export const useGetConvertLogExport = (
  options?: UseMutationOptions<ResDownloadBlob, AxiosError, void, unknown>,
): UseMutationResult<ResDownloadBlob, AxiosError, void, unknown> =>
  useMutation(
    () =>
      downloadBlobRequest({
        url: API_URL.GET_CONVERT_LOG_EXPORT,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_CONVERT_EXPORT] as QueryKey,
      ...options,
    },
  );

export const useGetConvertRule = (
  logId: string | number | undefined,
  options?: UseQueryOptions<ResConvertRule, AxiosError, ResConvertRule, QueryKey>,
): UseQueryResult<ResConvertRule, AxiosError> => {
  return useQuery(
    [QUERY_KEY.RULES_CONVERT_RULE_ITEM, logId] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_CONVERT_RULE(logId),
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

export const usePostConvertRule = (
  options?: UseMutationOptions<unknown, AxiosError, ReqConvertRule, unknown>,
): UseMutationResult<unknown, AxiosError, ReqConvertRule, unknown> =>
  useMutation(
    (reqData) =>
      postRequest<ReqConvertRule>({
        url: API_URL.POST_CONVERT_RULE(reqData.id),
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_CONVERT_ADD_RULE] as QueryKey,
      ...options,
    },
  );

export const usePutConvertRule = (
  options?: UseMutationOptions<unknown, AxiosError, ReqConvertRule, unknown>,
): UseMutationResult<unknown, AxiosError, ReqConvertRule, unknown> =>
  useMutation(
    (reqData) =>
      putRequest<ReqConvertRule>({
        url: API_URL.PUT_CONVERT_RULE(reqData.id),
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_CONVERT_EDIT_RULE] as QueryKey,
      ...options,
    },
  );

export const useGetConvertRuleOption = (
  options?: UseQueryOptions<ConvertRuleOption, AxiosError, ConvertRuleOption, QueryKey>,
): UseQueryResult<ConvertRuleOption, AxiosError> => {
  return useQuery(
    [QUERY_KEY.RULE_CONVERT_RULE_OPTION] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_CONVERT_RULE_OPTION,
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

export const usePostConvertPreviewSample = (
  options?: UseMutationOptions<
    ResConvertPreview,
    AxiosError<{ cras_error: ErrorDescriptionError }>,
    MutationPostConvertPreviewSample,
    unknown
  >,
): UseMutationResult<
  ResConvertPreview,
  AxiosError<{ cras_error: ErrorDescriptionError }>,
  MutationPostConvertPreviewSample,
  unknown
> =>
  useMutation(
    (reqData) =>
      postRequest<FormData, ResConvertPreview>({
        url: API_URL.POST_CONVERT_RULE_PREVIEW(reqData.inputType, reqData.previewType),
        reqData: reqData.formData,
        options: {
          headers: { 'Content-Type': 'multipart/form-data' },
        },
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_CONVERT_PREVIEW_SAMPLE] as QueryKey,
      ...options,
    },
  );

export const usePostConvertPreviewConvert = (
  options?: UseMutationOptions<ResConvertPreview, AxiosError<CrasError>, MutationPostConvertPreviewConvert, unknown>,
): UseMutationResult<ResConvertPreview, AxiosError<CrasError>, MutationPostConvertPreviewConvert, unknown> =>
  useMutation(
    (reqData) =>
      postRequest<ReqConvertPreviewConvert, ResConvertPreview>({
        url: API_URL.POST_CONVERT_RULE_PREVIEW(reqData.inputType, reqData.previewType),
        reqData: {
          data: reqData.data,
          convert: reqData.convert,
        },
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_CONVERT_PREVIEW_CONVERT] as QueryKey,
      ...options,
    },
  );

export const usePostConvertPreviewFilter = (
  options?: UseMutationOptions<ResConvertPreview, AxiosError<CrasError>, MutationPostConvertPreviewFilter, unknown>,
): UseMutationResult<ResConvertPreview, AxiosError<CrasError>, MutationPostConvertPreviewFilter, unknown> =>
  useMutation(
    (reqData) =>
      postRequest<ReqConvertPreviewFilter, ResConvertPreview>({
        url: API_URL.POST_CONVERT_RULE_PREVIEW(reqData.inputType, reqData.previewType),
        reqData: {
          data: reqData.data,
          filter: reqData.filter,
        },
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_CONVERT_PREVIEW_CONVERT] as QueryKey,
      ...options,
    },
  );

export const usePostConvertParingHeader = (
  options?: UseMutationOptions<ConvertRuleItem[], AxiosError<CrasError>, ReqConvertHeaderParsing, unknown>,
): UseMutationResult<ConvertRuleItem[], AxiosError<CrasError>, ReqConvertHeaderParsing, unknown> =>
  useMutation(
    (reqData) =>
      postRequest<Omit<ReqConvertHeaderParsing, 'id'>, ConvertRuleItem[]>({
        url: API_URL.POST_CONVERT_RULE_HEADER_PARSING(reqData.id),
        reqData: {
          data: reqData.data,
          header: reqData.header,
        },
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_COL_DEFINE_HEADER_PARSING] as QueryKey,
      ...options,
    },
  );

export const useGetConvertError = (
  logId: number,
  options?: UseQueryOptions<ResConvertRuleError, AxiosError, ConvertRuleItemErrorMsg[], QueryKey>,
): UseQueryResult<ConvertRuleItemErrorMsg[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_CONVERT_ERROR, logId] as QueryKey,
    ({ signal }) =>
      getRequest<ResConvertRuleError>({
        url: API_URL.GET_CONVERT_ERROR(logId),
        options: { signal },
      }),
    {
      ...options,
      select: (data) => data.error.map((item, index) => ({ ...item, index })) ?? [],
    },
  );
