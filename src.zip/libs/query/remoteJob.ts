import { API_URL } from '@constants/constants';
import { postRequest } from '@libs/axios/requests';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import { ResDownloadBlob } from '@typesdef/common';
import {
  BuildHistoryState,
  RemoteJobImportData,
  RemoteJobImportError,
  RemoteJobPlanDetailState,
  RemoteJobStatusState,
  RemoteJobStepStatus,
} from '@typesdef/Job';
import { AxiosError } from 'axios';
import {
  downloadBlobRequest,
  getRemoteJobPlans,
  getRemoteJobStepFiles,
  postRemoteJobStepFiles,
} from '../axios/requests';
import { getRequest } from './../axios/requests';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const useGetRemoteJobList = (
  options?: UseQueryOptions<
    Omit<RemoteJobStatusState, 'index' | 'lastSuccessDate' | 'lastFailureDate'>[],
    AxiosError,
    RemoteJobStatusState[],
    QueryKey
  >,
): UseQueryResult<RemoteJobStatusState[], AxiosError> =>
  useQuery(
    [QUERY_KEY.STATUS_REMOTE_LIST] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_STATUS_REMOTE_JOB_LIST,
        options: {
          signal,
        },
      }),
    {
      ...options,
      select: (data) =>
        data.map((item, index) => ({
          ...item,
          index: index,
          companyFabName: `${item.companyName}-${item.fabName}`,
          lastSuccessDate: {
            key: 'lastSuccess',
            date: item.lastSuccess?.date ?? null,
          },
          lastFailureDate: {
            key: 'lastFailure',
            date: item.lastFailure?.date ?? null,
          },
        })),
    },
  );

interface GetRemoteJobStopStatus {
  stop: boolean;
}
export const useGetRemoteJobStopStatus = (
  jobId: number | string,
  options?: UseQueryOptions<GetRemoteJobStopStatus, AxiosError, GetRemoteJobStopStatus, QueryKey>,
): UseQueryResult<GetRemoteJobStopStatus, AxiosError> =>
  useQuery(
    [QUERY_KEY.STATUS_REMOTE_STOP, jobId] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_STATUS_REMOTE_JOB_STOP_STATUS(jobId),
        options: {
          signal,
        },
      }),
    { ...options },
  );

export const useGetRemoteJobStepBuildQueue = (
  jobId: number | string,
  options?: UseQueryOptions<BuildHistoryState[], AxiosError, BuildHistoryState[], QueryKey>,
): UseQueryResult<BuildHistoryState[], AxiosError> =>
  useQuery(
    [QUERY_KEY.STATUS_REMOTE_BUILD_QUEUE, jobId] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_STATUS_REMOTE_JOB_BUILD_QUEUE(jobId),
        options: {
          signal,
        },
      }),
    {
      ...options,
      select: (data) => data.map((item, index) => ({ ...item, index })),
    },
  );

export const useGetRemoteJobStepBuildExecutor = (
  jobId: number | string,
  options?: UseQueryOptions<BuildHistoryState[], AxiosError, BuildHistoryState[], QueryKey>,
): UseQueryResult<BuildHistoryState[], AxiosError> =>
  useQuery(
    [QUERY_KEY.STATUS_REMOTE_BUILD_EXECUTOR, jobId] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_STATUS_REMOTE_JOB_BUILD_EXECUTOR(jobId),
        options: {
          signal,
        },
      }),
    {
      ...options,
      select: (data) => data.map((item, index) => ({ ...item, index })),
    },
  );

export const useGetRemoteJobStepStatus = (
  jobId: number | string,
  options?: UseQueryOptions<RemoteJobStepStatus[], AxiosError, RemoteJobStepStatus[], QueryKey>,
): UseQueryResult<RemoteJobStepStatus[], AxiosError> =>
  useQuery(
    [QUERY_KEY.STATUS_REMOTE_STEP_LIST, jobId] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_STATUS_REMOTE_JOB_STEP_LIST(jobId),
        options: {
          signal,
        },
      }),
    {
      ...options,
      select: (data) =>
        data
          .filter((item) => item.stepType !== 'notice')
          .map((item) => ({
            ...item,
            lastSuccessDate: {
              key: 'lastSuccess',
              date: item.lastSuccess?.date ?? null,
            },
            lastFailureDate: {
              key: 'lastFailure',
              date: item.lastFailure?.date ?? null,
            },
          })),
    },
  );

export const useGetRemoteJobPlans = (
  siteId: number | string,
  options?: UseQueryOptions<RemoteJobPlanDetailState[], AxiosError, RemoteJobPlanDetailState[], QueryKey>,
): UseQueryResult<RemoteJobPlanDetailState[], AxiosError> =>
  useQuery([QUERY_KEY.JOB_REMOTE_PLANS, siteId] as QueryKey, () => getRemoteJobPlans(+siteId), options);

export const usePostRemoteJobStepFiles = (
  options?: UseMutationOptions<unknown, AxiosError, FormData, unknown>,
): UseMutationResult<unknown, AxiosError, FormData, unknown> =>
  useMutation((formData: FormData) => postRemoteJobStepFiles(formData), {
    mutationKey: [MUTATION_KEY.JOB_REMOTE_STEP_FILES] as QueryKey,
    ...options,
  });

interface GetRemoteJobStepFiles {
  data: any;
  fileName: string;
}
export const useGetRemoteJobStepFiles = (
  jobId: number | string,
  stepId: string,
  options?: UseQueryOptions<GetRemoteJobStepFiles, AxiosError, GetRemoteJobStepFiles, QueryKey>,
): UseQueryResult<GetRemoteJobStepFiles, AxiosError> =>
  useQuery(
    [QUERY_KEY.JOB_REMOTE_STEP_FILES, jobId, stepId] as QueryKey,
    () => getRemoteJobStepFiles(jobId, stepId),
    options,
  );

export const useGetRemoteJobExport = (
  options?: UseMutationOptions<ResDownloadBlob, AxiosError, void, unknown>,
): UseMutationResult<ResDownloadBlob, AxiosError, void, unknown> =>
  useMutation(
    () =>
      downloadBlobRequest({
        url: API_URL.GET_STATUS_REMOTE_JOB_EXPORT,
      }),
    {
      mutationKey: [MUTATION_KEY.JOB_REMOTE_IMPORT_UPLOAD] as QueryKey,
      ...options,
    },
  );

export const useGetRemoteJobIsCustom = (
  options?: UseQueryOptions<{ custom: boolean }, AxiosError, { custom: boolean }, QueryKey>,
): UseQueryResult<{ custom: boolean }, AxiosError> => {
  return useQuery(
    [QUERY_KEY.STATUS_REMOTE_IS_CUSTOM] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_STATUS_REMOTE_JOB_IS_CUSTOM,
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

export const usePostRemoteJobImportCustomize = (
  options?: UseMutationOptions<unknown, AxiosError<RemoteJobImportError[]>, RemoteJobImportData, unknown>,
): UseMutationResult<unknown, AxiosError<RemoteJobImportError[]>, RemoteJobImportData, unknown> =>
  useMutation(
    (reqData: RemoteJobImportData) =>
      postRequest({
        url: API_URL.POST_STATUS_REMOTE_JOB_IMPORT_CUSTOMIZE,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.JOB_REMOTE_IMPORT_CUSTOMIZE] as QueryKey,
      ...options,
    },
  );

export const useGetRemoteJobCopy = (
  siteId: number,
  options?: UseQueryOptions<RemoteJobImportData, AxiosError, RemoteJobImportData, QueryKey>,
): UseQueryResult<RemoteJobImportData, AxiosError> => {
  return useQuery(
    [QUERY_KEY.STATUS_REMOTE_COPY, siteId] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_STATUS_REMOTE_JOB_COPY(siteId),
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

export const usePostRemoteJobCopyCustomize = (
  options?: UseMutationOptions<unknown, AxiosError<RemoteJobImportError[]>, RemoteJobImportData, unknown>,
): UseMutationResult<unknown, AxiosError<RemoteJobImportError[]>, RemoteJobImportData, unknown> =>
  useMutation(
    (reqData: RemoteJobImportData) =>
      postRequest({
        url: API_URL.POST_STATUS_REMOTE_JOB_COPY,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.JOB_REMOTE_COPY_CUSTOMIZE] as QueryKey,
      ...options,
    },
  );
