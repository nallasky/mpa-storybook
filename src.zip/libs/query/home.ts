import { API_URL } from '@constants/constants';
import { getRequest } from '@libs/axios/requests';
import { getQueriesParam } from '@libs/util/convert';
import { QueryKey, useQuery, UseQueryOptions, UseQueryResult } from '@tanstack/react-query';
import { ReqParam, ResPagination } from '@typesdef/common';
import { HomeRemoteJobDetailItem, HomeRemoteJobItem } from '@typesdef/home';
import { AxiosError } from 'axios';
import { QUERY_KEY } from './queryKey';

export const useGetHomeRemoteJob = (
  options?: UseQueryOptions<HomeRemoteJobItem[], AxiosError, HomeRemoteJobItem[], QueryKey>,
): UseQueryResult<HomeRemoteJobItem[], AxiosError> =>
  useQuery(
    [QUERY_KEY.HOME_REMOTE_JOB_LIST] as QueryKey,
    ({ signal }) => getRequest<HomeRemoteJobItem[]>({ url: API_URL.GET_HOME_REMOTE_JOB_LIST, options: { signal } }),
    {
      ...options,
    },
  );

export const useGetHomeRemoteJobDetail = (
  params: ReqParam<'siteId'>,
  options?: UseQueryOptions<
    ResPagination<HomeRemoteJobDetailItem[]>,
    AxiosError,
    ResPagination<HomeRemoteJobDetailItem[]>,
    QueryKey
  >,
): UseQueryResult<ResPagination<HomeRemoteJobDetailItem[]>, AxiosError> => {
  const { paths, query, pagination, search } = params;
  const { siteId } = paths ?? { siteId: '' };

  return useQuery(
    [QUERY_KEY.HOME_REMOTE_JOB_DETAIL_LIST, siteId, { ...query, ...pagination, ...search }] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_HOME_REMOTE_JOB_DETAIL_LIST(
          siteId,
          getQueriesParam({
            query,
            pagination,
            search,
          }),
        ),
        options: { signal },
      }),
    {
      ...options,
    },
  );
};
