import { API_URL } from '@constants/constants';
import { getQueriesParam } from '@libs/util/convert';
import { ReqParam, ResPagination } from '@typesdef/common';
import { LocalJobStatusState } from '@typesdef/Job';
import { AxiosError } from 'axios';
import { QueryKey, useQuery, UseQueryOptions, UseQueryResult } from '@tanstack/react-query';
import { getRequest } from '../axios/requests';
import { QUERY_KEY } from './queryKey';

export const useGetLocalJobStatus = (
  params: ReqParam,
  options?: UseQueryOptions<
    ResPagination<LocalJobStatusState[]>,
    AxiosError,
    ResPagination<LocalJobStatusState[]>,
    QueryKey
  >,
): UseQueryResult<ResPagination<LocalJobStatusState[]>, AxiosError> => {
  const { query, pagination, search } = params;

  return useQuery(
    [QUERY_KEY.STATUS_LOCAL_LIST, { ...query, ...pagination, ...search }] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_STATUS_LOCAL_JOB_LIST(
          getQueriesParam({
            query,
            pagination,
            search,
          }),
        ),
        options: { signal },
      }),
    {
      ...options,
      select: (data) => {
        return {
          ...data,
          content: data.content.map((item) => ({
            ...item,
            companyFabName: `${item.companyName}-${item.fabName}`,
          })),
        };
      },
    },
  );
};
