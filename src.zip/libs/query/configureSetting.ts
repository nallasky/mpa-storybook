import { AxiosError } from 'axios';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import { getSiteDBInfo, postConfigureImport } from '../axios/requests';
import { SiteDBInfo } from '../axios/types';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const useGetConfigureSites = (
  options?: UseQueryOptions<SiteDBInfo[], AxiosError, SiteDBInfo[], QueryKey>,
): UseQueryResult<SiteDBInfo[], AxiosError> =>
  useQuery([QUERY_KEY.CONFIGURE_SITES] as QueryKey, getSiteDBInfo, options);

export const usePostConfigureImport = (
  options?: UseMutationOptions<unknown, AxiosError, FormData, unknown>,
): UseMutationResult<unknown, AxiosError, FormData, unknown> =>
  useMutation((formData: FormData) => postConfigureImport(formData), {
    mutationKey: [MUTATION_KEY.CONFIGURE_IMPORT_SITE] as QueryKey,
    ...options,
  });
