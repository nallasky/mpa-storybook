import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import { AxiosError } from 'axios';
import { getStatusSiteList, postRequest } from '../axios/requests';
import { ResGetSiteName } from '../axios/types';
import { QUERY_KEY } from './queryKey';

export const useGetUserFabNameList = (
  options?: UseQueryOptions<ResGetSiteName[], AxiosError, ResGetSiteName[], QueryKey>,
): UseQueryResult<ResGetSiteName[], AxiosError> => {
  return useQuery([QUERY_KEY.STATUS_SITE_LIST] as QueryKey, getStatusSiteList, {
    ...options,
  });
};

export const usePostFileImport = (
  mutationKey: QueryKey,
  options?: UseMutationOptions<unknown, AxiosError, { url: string; data: FormData }, unknown>,
): UseMutationResult<unknown, AxiosError, { url: string; data: FormData }, unknown> =>
  useMutation(
    (reqData) =>
      postRequest({
        url: reqData.url,
        reqData: reqData.data,
        options: {
          headers: { 'Content-Type': 'multipart/form-data' },
        },
      }),
    {
      mutationKey,
      ...options,
    },
  );
