import { API_URL } from '@constants/constants';
import { deleteRequest, getRequest, postRequest, putRequest } from '@libs/axios/requests';
import { getQueriesParam } from '@libs/util/convert';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import { ReqParam, ResPagination } from '@typesdef/common';
import {
  ErrorLogReqDownload,
  ErrorLogSettingState,
  ErrorLogState,
  ErrorLogStatusState,
  ReqAddErrorLogSetting,
  ReqDeleteErrorLogSetting,
  ReqEditErrorLogSetting,
} from '@typesdef/errorLog';
import { DefaultOptionType } from 'antd/es/select';
import { AxiosError } from 'axios';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const useGetErrorLogList = (
  params: ReqParam<'siteId'>,
  options?: UseQueryOptions<ResPagination<ErrorLogState[]>, AxiosError, ResPagination<ErrorLogState[]>, QueryKey>,
): UseQueryResult<ResPagination<ErrorLogState[]>, AxiosError> => {
  const { paths, ...rest } = params;
  const { siteId } = paths ?? { siteId: '' };

  return useQuery(
    [QUERY_KEY.ERROR_LOG_LIST, siteId, { ...rest }] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_ERROR_LOG_LIST(
          siteId,
          getQueriesParam({
            ...rest,
          }),
        ),
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

export const useGetErrorLogSettingList = (
  params: ReqParam<'siteId' | 'userId'>,
  options?: UseQueryOptions<
    ResPagination<ErrorLogSettingState[]>,
    AxiosError,
    ResPagination<ErrorLogSettingState[]>,
    QueryKey
  >,
): UseQueryResult<ResPagination<ErrorLogSettingState[]>, AxiosError> => {
  const { paths, query, pagination, search } = params;
  const { siteId, userId } = paths ?? { siteId: '', userId: '' };

  return useQuery(
    [QUERY_KEY.ERROR_LOG_SETTING_LIST, siteId, userId, { ...query, ...pagination, ...search }] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_ERROR_LOG_SETTING_LIST(
          siteId,
          userId,
          getQueriesParam({
            query,
            pagination,
            search,
          }),
        ),
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

export const useGetErrorLogStatus = (
  params: ReqParam<'siteId' | 'userId'>,
  options?: UseQueryOptions<
    ResPagination<ErrorLogStatusState[]>,
    AxiosError,
    ResPagination<ErrorLogStatusState[]>,
    QueryKey
  >,
): UseQueryResult<ResPagination<ErrorLogStatusState[]>, AxiosError> => {
  const { paths, ...rest } = params;
  const { siteId, userId } = paths ?? { siteId: '', userId: '' };

  return useQuery(
    [QUERY_KEY.ERROR_LOG_STATUS_LIST, siteId, userId, { ...rest }] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_ERROR_LOG_STATUS_LIST(
          siteId,
          userId,
          getQueriesParam({
            ...rest,
          }),
        ),
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

interface UsePostErrorLogImport {
  siteId: number | string;
  userId: number | string;
  formData: FormData;
}

export const usePostErrorLogImport = (
  options?: UseMutationOptions<unknown, AxiosError, UsePostErrorLogImport, unknown>,
): UseMutationResult<unknown, AxiosError, UsePostErrorLogImport, unknown> =>
  useMutation(
    (reqData: UsePostErrorLogImport) =>
      postRequest<FormData>({
        url: API_URL.GET_ERROR_LOG_IMPORT(reqData.siteId, reqData.userId),
        reqData: reqData.formData,
        options: {
          headers: { 'Content-Type': 'multipart/form-data' },
        },
      }),
    {
      mutationKey: [MUTATION_KEY.ERROR_LOG_IMPORT] as QueryKey,
      ...options,
    },
  );

export const usePostErrorLogReqDownload = (
  options?: UseMutationOptions<unknown, AxiosError, ErrorLogReqDownload, unknown>,
): UseMutationResult<unknown, AxiosError, ErrorLogReqDownload, unknown> =>
  useMutation(
    (reqData: ErrorLogReqDownload) =>
      postRequest<ErrorLogReqDownload>({
        url: API_URL.POST_ERROR_LOG_DOWNLOAD(reqData.siteId, reqData.userId),
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.ERROR_LOG_REQ_DOWNLOAD] as QueryKey,
      ...options,
    },
  );

export const useGetErrorLogCategoryOptions = (
  siteId: number,
  options?: UseQueryOptions<string[], AxiosError, DefaultOptionType[], QueryKey>,
): UseQueryResult<DefaultOptionType[], AxiosError> =>
  useQuery(
    [QUERY_KEY.ERROR_LOG_CATEGORY_OPTIONS, siteId] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_ERROR_LOG_CATEGORY_OPTIONS(siteId),
        options: { signal },
      }),
    {
      select: (data) =>
        data.map((item) => ({
          key: item,
          label: item,
          value: item,
        })),
      ...options,
    },
  );

export const usePostErrorLogSettingAdd = (
  options?: UseMutationOptions<unknown, AxiosError, ReqAddErrorLogSetting, unknown>,
): UseMutationResult<unknown, AxiosError, ReqAddErrorLogSetting, unknown> =>
  useMutation(
    (reqData: ReqAddErrorLogSetting) =>
      postRequest<ReqAddErrorLogSetting['data']>({
        url: API_URL.POST_ERROR_LOG_SETTING_ADD(reqData.siteId, reqData.userId),
        reqData: reqData.data,
      }),
    {
      mutationKey: [MUTATION_KEY.ERROR_LOG_SETTING_ADD] as QueryKey,
      ...options,
    },
  );

export const usePutErrorLogSettingEdit = (
  options?: UseMutationOptions<unknown, AxiosError, ReqEditErrorLogSetting, unknown>,
): UseMutationResult<unknown, AxiosError, ReqEditErrorLogSetting, unknown> =>
  useMutation(
    (reqData: ReqEditErrorLogSetting) =>
      putRequest<ReqEditErrorLogSetting['data']>({
        url: API_URL.PUT_ERROR_LOG_SETTING_EDIT(reqData.siteId, reqData.userId, reqData.itemId),
        reqData: reqData.data,
      }),
    {
      mutationKey: [MUTATION_KEY.ERROR_LOG_SETTING_ADD] as QueryKey,
      ...options,
    },
  );

export const useDeleteErrorLogSetting = (
  options?: UseMutationOptions<unknown, AxiosError, ReqDeleteErrorLogSetting, unknown>,
): UseMutationResult<unknown, AxiosError, ReqDeleteErrorLogSetting, unknown> =>
  useMutation(
    (reqData: ReqDeleteErrorLogSetting) =>
      deleteRequest({
        url: API_URL.DELETE_ERROR_LOG_SETTING(reqData.siteId, reqData.userId, reqData.itemId),
      }),
    {
      mutationKey: [MUTATION_KEY.ERROR_LOG_SETTING_DELETE] as QueryKey,
      ...options,
    },
  );
