import { API_URL } from '@constants/constants';
import { deleteRequest, downloadBlobRequest, getRequest, postRequest, putRequest } from '@libs/axios/requests';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import {
  AddArcnetUnitData,
  ArcnetItemAnalysisData,
  ArcnetItemCalculateData,
  ArcnetItemData,
  ArcnetItemRegisterStatusData,
  ArcnetUnitData,
  ArcnetUnitJsonData,
  MutateArcnetItemAddData,
  MutateArcnetItemAnalysisData,
  MutateArcnetItemCalculateData,
  MutateArcnetItemCopyData,
  MutateArcnetUnitData,
} from '@typesdef/arcnet';
import { ResDownloadBlob } from '@typesdef/common';
import { AxiosError } from 'axios';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const useGetArcnetItemList = (
  options?: UseQueryOptions<ArcnetItemData[], AxiosError, ArcnetItemData[], QueryKey>,
): UseQueryResult<ArcnetItemData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_LIST] as QueryKey,
    ({ signal }) => getRequest<ArcnetItemData[]>({ url: API_URL.GET_ANALYSIS_ARCNET_ITEM_LIST, options: { signal } }),
    {
      ...options,
    },
  );

export const useGetArcnetItemRegisterStatus = (
  options?: UseQueryOptions<ArcnetItemRegisterStatusData, AxiosError, ArcnetItemRegisterStatusData, QueryKey>,
): UseQueryResult<ArcnetItemRegisterStatusData, AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_REGISTER_STATUS] as QueryKey,
    ({ signal }) =>
      getRequest<ArcnetItemRegisterStatusData>({
        url: API_URL.GET_ANALYSIS_ARCNET_ITEM_REGISTER_STATUS,
        options: { signal },
      }),
    {
      ...options,
    },
  );

export const usePostArcnetItem = (
  options?: UseMutationOptions<unknown, AxiosError, MutateArcnetItemAddData, unknown>,
): UseMutationResult<unknown, AxiosError, MutateArcnetItemAddData, unknown> =>
  useMutation(
    (reqData) =>
      postRequest({
        url: API_URL.POST_ANALYSIS_ARCNET_ITEM,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_ADD] as QueryKey,
      ...options,
    },
  );

export const usePostArcnetItemCopy = (
  options?: UseMutationOptions<unknown, AxiosError, MutateArcnetItemCopyData, unknown>,
): UseMutationResult<unknown, AxiosError, MutateArcnetItemCopyData, unknown> =>
  useMutation(
    (reqData) =>
      postRequest({
        url: API_URL.POST_ANALYSIS_ARCNET_ITEM_COPY,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_COPY] as QueryKey,
      ...options,
    },
  );

export const useDeleteArcnetItem = (
  options?: UseMutationOptions<unknown, AxiosError, number, unknown>,
): UseMutationResult<unknown, AxiosError, number, unknown> =>
  useMutation(
    (id) =>
      deleteRequest({
        url: API_URL.DELETE_ANALYSIS_ARCNET_ITEM(id),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_DELETE] as QueryKey,
      ...options,
    },
  );

export const useGetArcnetItemExport = (
  options?: UseMutationOptions<ResDownloadBlob, AxiosError, number, unknown>,
): UseMutationResult<ResDownloadBlob, AxiosError, number, unknown> =>
  useMutation(
    (pathId) =>
      downloadBlobRequest({
        url: API_URL.GET_ARCNET_ITEM_EXPORT(pathId),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_EXPORT] as QueryKey,
      ...options,
    },
  );

export const useGetArcnetItemAnalysisList = (
  id: number,
  options?: UseQueryOptions<ArcnetItemAnalysisData[], AxiosError, ArcnetItemAnalysisData[], QueryKey>,
): UseQueryResult<ArcnetItemAnalysisData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_ANALYSIS_LIST, id] as QueryKey,
    ({ signal }) =>
      getRequest<ArcnetItemAnalysisData[]>({
        url: API_URL.GET_ANALYSIS_ARCNET_ITEM_ANALYSIS_LIST(id),
        options: { signal },
      }),
    {
      ...options,
    },
  );

export const useGetArcnetItemAnalysis = (
  id: number,
  itemId: number,
  options?: UseQueryOptions<ArcnetItemAnalysisData, AxiosError, ArcnetItemAnalysisData, QueryKey>,
): UseQueryResult<ArcnetItemAnalysisData, AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_ANALYSIS, id, itemId] as QueryKey,
    ({ signal }) =>
      getRequest<ArcnetItemAnalysisData>({
        url: API_URL.GET_ANALYSIS_ARCNET_ITEM_ANALYSIS(id, itemId),
        options: { signal },
      }),
    {
      ...options,
    },
  );

export const usePostArcnetItemAnalysis = (
  options?: UseMutationOptions<unknown, AxiosError, MutateArcnetItemAnalysisData, unknown>,
): UseMutationResult<unknown, AxiosError, MutateArcnetItemAnalysisData, unknown> =>
  useMutation(
    (reqData) =>
      postRequest({
        url: API_URL.POST_ANALYSIS_ARCNET_ITEM_ANALYSIS(reqData.id),
        reqData: reqData.data,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_ANALYSIS_ADD] as QueryKey,
      ...options,
    },
  );

export const usePutArcnetItemAnalysis = (
  options?: UseMutationOptions<unknown, AxiosError, MutateArcnetItemAnalysisData, unknown>,
): UseMutationResult<unknown, AxiosError, MutateArcnetItemAnalysisData, unknown> =>
  useMutation(
    (reqData) =>
      putRequest({
        url: API_URL.PUT_ANALYSIS_ARCNET_ITEM_ANALYSIS(reqData.id, reqData.itemId),
        reqData: reqData.data,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_ANALYSIS_EDIT] as QueryKey,
      ...options,
    },
  );

export const useDeleteArcnetItemAnalysis = (
  options?: UseMutationOptions<unknown, AxiosError, { id: number; itemId: number }, unknown>,
): UseMutationResult<unknown, AxiosError, { id: number; itemId: number }, unknown> =>
  useMutation(
    (reqData) =>
      deleteRequest({
        url: API_URL.DELETE_ANALYSIS_ARCNET_ITEM_ANALYSIS(reqData.id, reqData.itemId),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_ANALYSIS_DELETE] as QueryKey,
      ...options,
    },
  );

export const useGetArcnetItemCalculateList = (
  id: number,
  options?: UseQueryOptions<ArcnetItemCalculateData[], AxiosError, ArcnetItemCalculateData[], QueryKey>,
): UseQueryResult<ArcnetItemCalculateData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_CALCULATE_LIST, id] as QueryKey,
    ({ signal }) =>
      getRequest<ArcnetItemCalculateData[]>({
        url: API_URL.GET_ANALYSIS_ARCNET_ITEM_CALCULATE_LIST(id),
        options: { signal },
      }),
    {
      ...options,
    },
  );

export const useGetArcnetItemCalculate = (
  id: number,
  itemId: number,
  options?: UseQueryOptions<ArcnetItemCalculateData, AxiosError, ArcnetItemCalculateData, QueryKey>,
): UseQueryResult<ArcnetItemCalculateData, AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_CALCULATE, id, itemId] as QueryKey,
    ({ signal }) =>
      getRequest<ArcnetItemCalculateData>({
        url: API_URL.GET_ANALYSIS_ARCNET_ITEM_CALCULATE(id, itemId),
        options: { signal },
      }),
    {
      ...options,
    },
  );

export const usePostArcnetItemCalculate = (
  options?: UseMutationOptions<unknown, AxiosError, MutateArcnetItemCalculateData, unknown>,
): UseMutationResult<unknown, AxiosError, MutateArcnetItemCalculateData, unknown> =>
  useMutation(
    (reqData) =>
      postRequest({
        url: API_URL.POST_ANALYSIS_ARCNET_ITEM_CALCULATE(reqData.id),
        reqData: reqData.data,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_CALCULATE_ADD] as QueryKey,
      ...options,
    },
  );

export const usePutArcnetItemCalculate = (
  options?: UseMutationOptions<unknown, AxiosError, MutateArcnetItemCalculateData, unknown>,
): UseMutationResult<unknown, AxiosError, MutateArcnetItemCalculateData, unknown> =>
  useMutation(
    (reqData) =>
      putRequest({
        url: API_URL.PUT_ANALYSIS_ARCNET_ITEM_CALCULATE(reqData.id, reqData.itemId),
        reqData: reqData.data,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_CALCULATE_EDIT] as QueryKey,
      ...options,
    },
  );

export const useDeleteArcnetItemCalculate = (
  options?: UseMutationOptions<unknown, AxiosError, { id: number; itemId: number }, unknown>,
): UseMutationResult<unknown, AxiosError, { id: number; itemId: number }, unknown> =>
  useMutation(
    (reqData) =>
      deleteRequest({
        url: API_URL.DELETE_ANALYSIS_ARCNET_ITEM_CALCULATE(reqData.id, reqData.itemId),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_CALCULATE_DELETE] as QueryKey,
      ...options,
    },
  );

export const useGetArcnetUnitList = (
  options?: UseQueryOptions<ArcnetUnitData[], AxiosError, ArcnetUnitData[], QueryKey>,
): UseQueryResult<ArcnetUnitData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_ANALYSIS_ARCNET_UNIT_LIST] as QueryKey,
    ({ signal }) =>
      getRequest<ArcnetUnitData[]>({
        url: API_URL.GET_ANALYSIS_ARCNET_UNIT_LIST,
        options: { signal },
      }),
    {
      ...options,
    },
  );

export const useGetArcnetUnit = (
  id: number,
  options?: UseQueryOptions<ArcnetUnitJsonData, AxiosError, ArcnetUnitJsonData, QueryKey>,
): UseQueryResult<ArcnetUnitJsonData, AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_ANALYSIS_ARCNET_UNIT, id] as QueryKey,
    ({ signal }) =>
      getRequest<ArcnetUnitJsonData>({
        url: API_URL.GET_ANALYSIS_ARCNET_UNIT(id),
        options: { signal },
      }),
    {
      ...options,
    },
  );

export const usePostArcnetUnit = (
  options?: UseMutationOptions<unknown, AxiosError, MutateArcnetUnitData, unknown>,
): UseMutationResult<unknown, AxiosError, MutateArcnetUnitData, unknown> =>
  useMutation(
    (reqData) =>
      postRequest<AddArcnetUnitData>({
        url: API_URL.POST_ANALYSIS_ARCNET_UNIT,
        reqData: {
          tool_type: reqData.tool_type,
        },
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_UNIT_ADD] as QueryKey,
      ...options,
    },
  );

export const usePutArcnetUnit = (
  options?: UseMutationOptions<unknown, AxiosError, MutateArcnetUnitData, unknown>,
): UseMutationResult<unknown, AxiosError, MutateArcnetUnitData, unknown> =>
  useMutation(
    (reqData) =>
      putRequest<MutateArcnetUnitData>({
        url: API_URL.PUT_ANALYSIS_ARCNET_UNIT(reqData.id),
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_UNIT_EDIT] as QueryKey,
      ...options,
    },
  );

export const useDeleteArcnetUnit = (
  options?: UseMutationOptions<unknown, AxiosError, number, unknown>,
): UseMutationResult<unknown, AxiosError, number, unknown> =>
  useMutation(
    (id) =>
      deleteRequest({
        url: API_URL.DELETE_ANALYSIS_ARCNET_UNIT(id),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_UNIT_DELETE] as QueryKey,
      ...options,
    },
  );

export const useGetArcnetUnitExport = (
  options?: UseMutationOptions<ResDownloadBlob, AxiosError, number, unknown>,
): UseMutationResult<ResDownloadBlob, AxiosError, number, unknown> =>
  useMutation(
    (id) =>
      downloadBlobRequest({
        url: API_URL.GET_ANALYSIS_ARCNET_UNIT_EXPORT(id),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_UNIT_EXPORT] as QueryKey,
      ...options,
    },
  );
