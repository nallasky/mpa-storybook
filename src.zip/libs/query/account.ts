import { API_URL } from '@constants/constants';
import { deleteRequest, downloadBlobRequest, getRequest, postRequest, putRequest } from '@libs/axios/requests';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import {
  AccountGroupData,
  AccountGroupSummaryData,
  AccountUserData,
  AccountUserSummaryData,
  ReqAccountChangePasswordData,
  ReqAccountGroupData,
  ReqAccountUserData,
} from '@typesdef/account';
import { ResDownloadBlob } from '@typesdef/common';
import { AxiosError } from 'axios';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const usePutAccountChangePassword = (
  options?: UseMutationOptions<unknown, AxiosError, ReqAccountChangePasswordData, unknown>,
): UseMutationResult<unknown, AxiosError, ReqAccountChangePasswordData, unknown> =>
  useMutation(
    (reqData: ReqAccountChangePasswordData) =>
      putRequest<Omit<ReqAccountChangePasswordData, 'id'>>({
        url: API_URL.PUT_ACCOUNT_CHANGE_PASSWORD(reqData.id),
        reqData: {
          currentPassword: reqData.currentPassword,
          newPassword: reqData.newPassword,
        },
      }),
    {
      mutationKey: [MUTATION_KEY.ACCOUNT_USER_CHANGE_PASSWORD] as QueryKey,
      ...options,
    },
  );

export const useGetAccountExport = (
  options?: UseMutationOptions<ResDownloadBlob, AxiosError, void, unknown>,
): UseMutationResult<ResDownloadBlob, AxiosError, void, unknown> =>
  useMutation(
    () =>
      downloadBlobRequest({
        url: API_URL.GET_ACCOUNT_EXPORT,
      }),
    {
      mutationKey: [MUTATION_KEY.ACCOUNT_EXPORT] as QueryKey,
      ...options,
    },
  );

export const useGetAccountGroupSummaryList = (
  options?: UseQueryOptions<AccountGroupSummaryData[], AxiosError, AccountGroupSummaryData[], QueryKey>,
): UseQueryResult<AccountGroupSummaryData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.ACCOUNT_GROUP_SUMMARY_LIST] as QueryKey,
    ({ signal }) =>
      getRequest<AccountGroupSummaryData[]>({ url: API_URL.GET_ACCOUNT_GROUP_SUMMARY_LIST, options: { signal } }),
    {
      ...options,
    },
  );

export const useGetAccountGroupSummaryListInModal = (
  options?: UseQueryOptions<AccountGroupSummaryData[], AxiosError, AccountGroupSummaryData[], QueryKey>,
): UseQueryResult<AccountGroupSummaryData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.ACCOUNT_GROUP_SUMMARY_LIST, 'IN_MODAL'] as QueryKey,
    ({ signal }) =>
      getRequest<AccountGroupSummaryData[]>({ url: API_URL.GET_ACCOUNT_GROUP_SUMMARY_LIST, options: { signal } }),
    {
      ...options,
    },
  );

export const useGetAccountGroupById = (
  id: number,
  options?: UseQueryOptions<AccountGroupData, AxiosError, AccountGroupData, QueryKey>,
): UseQueryResult<AccountGroupData, AxiosError> =>
  useQuery(
    [QUERY_KEY.ACCOUNT_GROUP_BY_ID, id] as QueryKey,
    ({ signal }) => getRequest<AccountGroupData>({ url: API_URL.GET_ACCOUNT_GROUP_BY_ID(id), options: { signal } }),
    {
      ...options,
    },
  );

export const usePostAccountGroup = (
  options?: UseMutationOptions<unknown, AxiosError, ReqAccountGroupData, unknown>,
): UseMutationResult<unknown, AxiosError, ReqAccountGroupData, unknown> =>
  useMutation(
    (reqData) =>
      postRequest<ReqAccountGroupData>({
        url: API_URL.POST_ACCOUNT_GROUP,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.ACCOUNT_GROUP_ADD] as QueryKey,
      ...options,
    },
  );

export const usePutAccountGroup = (
  options?: UseMutationOptions<unknown, AxiosError, ReqAccountGroupData, unknown>,
): UseMutationResult<unknown, AxiosError, ReqAccountGroupData, unknown> =>
  useMutation(
    (reqData) =>
      putRequest<ReqAccountGroupData>({
        url: API_URL.PUT_ACCOUNT_GROUP(reqData.id),
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.ACCOUNT_GROUP_EDIT] as QueryKey,
      ...options,
    },
  );

export const useDeleteAccountGroup = (
  options?: UseMutationOptions<unknown, AxiosError, number, unknown>,
): UseMutationResult<unknown, AxiosError, number, unknown> =>
  useMutation(
    (id) =>
      deleteRequest({
        url: API_URL.DELETE_ACCOUNT_GROUP(id),
      }),
    {
      mutationKey: [MUTATION_KEY.ACCOUNT_GROUP_DELETE] as QueryKey,
      ...options,
    },
  );

export const useGetAccountUserSummaryList = (
  options?: UseQueryOptions<AccountUserSummaryData[], AxiosError, AccountUserSummaryData[], QueryKey>,
): UseQueryResult<AccountUserSummaryData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.ACCOUNT_USER_SUMMARY_LIST] as QueryKey,
    ({ signal }) =>
      getRequest<AccountUserSummaryData[]>({ url: API_URL.GET_ACCOUNT_USER_SUMMARY_LIST, options: { signal } }),
    {
      ...options,
    },
  );

export const useGetAccountUserSummaryListInModal = (
  options?: UseQueryOptions<AccountUserSummaryData[], AxiosError, AccountUserSummaryData[], QueryKey>,
): UseQueryResult<AccountUserSummaryData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.ACCOUNT_USER_SUMMARY_LIST, 'IN_MODAL'] as QueryKey,
    ({ signal }) =>
      getRequest<AccountUserSummaryData[]>({ url: API_URL.GET_ACCOUNT_USER_SUMMARY_LIST, options: { signal } }),
    {
      ...options,
    },
  );

export const useGetAccountUserSummaryListWithAdmin = (
  options?: UseQueryOptions<AccountUserSummaryData[], AxiosError, AccountUserSummaryData[], QueryKey>,
): UseQueryResult<AccountUserSummaryData[], AxiosError> =>
  useQuery(
    [QUERY_KEY.ACCOUNT_USER_SUMMARY_LIST_WITH_ADMIN] as QueryKey,
    ({ signal }) =>
      getRequest<AccountUserSummaryData[]>({
        url: API_URL.GET_ACCOUNT_USER_SUMMARY_LIST_WITH_ADMIN,
        options: { signal },
      }),
    {
      ...options,
    },
  );

export const useGetAccountUserById = (
  id: number,
  options?: UseQueryOptions<AccountUserData, AxiosError, AccountUserData, QueryKey>,
): UseQueryResult<AccountUserData, AxiosError> =>
  useQuery(
    [QUERY_KEY.ACCOUNT_GROUP_BY_ID, id] as QueryKey,
    ({ signal }) => getRequest<AccountUserData>({ url: API_URL.GET_ACCOUNT_USER_BY_ID(id), options: { signal } }),
    {
      ...options,
    },
  );

export const usePostAccountUser = (
  options?: UseMutationOptions<unknown, AxiosError, ReqAccountUserData, unknown>,
): UseMutationResult<unknown, AxiosError, ReqAccountUserData, unknown> =>
  useMutation(
    (reqData) =>
      postRequest<ReqAccountUserData>({
        url: API_URL.POST_ACCOUNT_USER,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.ACCOUNT_USER_ADD] as QueryKey,
      ...options,
    },
  );

export const usePutAccountUser = (
  options?: UseMutationOptions<unknown, AxiosError, ReqAccountUserData, unknown>,
): UseMutationResult<unknown, AxiosError, ReqAccountUserData, unknown> =>
  useMutation(
    (reqData) =>
      putRequest<ReqAccountUserData>({
        url: API_URL.PUT_ACCOUNT_USER(reqData.id),
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.ACCOUNT_USER_EDIT] as QueryKey,
      ...options,
    },
  );

export const useDeleteAccountUser = (
  options?: UseMutationOptions<unknown, AxiosError, number, unknown>,
): UseMutationResult<unknown, AxiosError, number, unknown> =>
  useMutation(
    (id) =>
      deleteRequest({
        url: API_URL.DELETE_ACCOUNT_USER(id),
      }),
    {
      mutationKey: [MUTATION_KEY.ACCOUNT_USER_DELETE] as QueryKey,
      ...options,
    },
  );
