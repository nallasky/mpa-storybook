import { API_URL } from '@constants/constants';
import { deleteRequest, downloadBlobRequest, getRequest, postRequest, putRequest } from '@libs/axios/requests';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import { ResDownloadBlob } from '@typesdef/common';
import { DefineParamData, DefineParamType, MutateDefineParamData } from '@typesdef/defineParam';
import { AxiosError } from 'axios';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

type DefineParamRequestInfoMap = {
  [key in DefineParamType]: {
    getList: {
      key: string;
      url: string;
    };
    getItem: {
      key: string;
      url: (id: string | number) => string;
    };
    addItem: {
      key: string;
      url: string;
    };
    editItem: {
      key: string;
      url: (id: string | number) => string;
    };
    deleteItem: {
      key: string;
      url: (id: string | number) => string;
    };
    importList: {
      key: string;
      url: string;
    };
    exportList: {
      key: string;
      url: string;
    };
  };
};

export const DEFINE_PARAM_REQUEST_MAP: DefineParamRequestInfoMap = {
  cylinder: {
    getList: {
      key: QUERY_KEY.RULES_DEFINE_CYLINDER_LIST,
      url: API_URL.GET_DEFINE_CYLINDER_LIST,
    },
    getItem: {
      key: QUERY_KEY.RULES_DEFINE_CYLINDER,
      url: API_URL.GET_DEFINE_CYLINDER,
    },
    addItem: {
      key: MUTATION_KEY.RULES_DEFINE_CYLINDER_ADD,
      url: API_URL.POST_DEFINE_CYLINDER,
    },
    editItem: {
      key: MUTATION_KEY.RULES_DEFINE_CYLINDER_EDIT,
      url: API_URL.PUT_DEFINE_CYLINDER,
    },
    deleteItem: {
      key: MUTATION_KEY.RULES_DEFINE_CYLINDER_DELETE,
      url: API_URL.DELETE_DEFINE_CYLINDER,
    },
    importList: {
      key: MUTATION_KEY.RULES_DEFINE_CYLINDER_IMPORT,
      url: API_URL.POST_DEFINE_CYLINDER_IMPORT,
    },
    exportList: {
      key: MUTATION_KEY.RULES_DEFINE_CYLINDER_EXPORT,
      url: API_URL.GET_DEFINE_CYLINDER_EXPORT,
    },
  },
  machine: {
    getList: {
      key: QUERY_KEY.RULES_DEFINE_MACHINE_LIST,
      url: API_URL.GET_DEFINE_MACHINE_LIST,
    },
    getItem: {
      key: QUERY_KEY.RULES_DEFINE_MACHINE,
      url: API_URL.GET_DEFINE_MACHINE,
    },
    addItem: {
      key: MUTATION_KEY.RULES_DEFINE_MACHINE_ADD,
      url: API_URL.POST_DEFINE_MACHINE,
    },
    editItem: {
      key: MUTATION_KEY.RULES_DEFINE_MACHINE_EDIT,
      url: API_URL.PUT_DEFINE_MACHINE,
    },
    deleteItem: {
      key: MUTATION_KEY.RULES_DEFINE_MACHINE_DELETE,
      url: API_URL.DELETE_DEFINE_MACHINE,
    },
    importList: {
      key: MUTATION_KEY.RULES_DEFINE_MACHINE_IMPORT,
      url: API_URL.POST_DEFINE_MACHINE_IMPORT,
    },
    exportList: {
      key: MUTATION_KEY.RULES_DEFINE_MACHINE_EXPORT,
      url: API_URL.GET_DEFINE_MACHINE_EXPORT,
    },
  },
};

export const useGetDefineParamList = (
  type: DefineParamType,
  options?: UseQueryOptions<DefineParamData[], AxiosError, DefineParamData[], QueryKey>,
): UseQueryResult<DefineParamData[], AxiosError> =>
  useQuery(
    [DEFINE_PARAM_REQUEST_MAP[type].getList.key] as QueryKey,
    ({ signal }) =>
      getRequest<DefineParamData[]>({ url: DEFINE_PARAM_REQUEST_MAP[type].getList.url, options: { signal } }),
    {
      ...options,
    },
  );

export const useGetDefineParam = (
  type: DefineParamType,
  id: number,
  options?: UseQueryOptions<DefineParamData, AxiosError, DefineParamData, QueryKey>,
): UseQueryResult<DefineParamData, AxiosError> =>
  useQuery(
    [DEFINE_PARAM_REQUEST_MAP[type].getItem.key, id] as QueryKey,
    ({ signal }) =>
      getRequest<DefineParamData>({
        url: DEFINE_PARAM_REQUEST_MAP[type].getItem.url(id),
        options: { signal },
      }),
    {
      ...options,
    },
  );

export const usePostDefineParam = (
  type: DefineParamType,
  options?: UseMutationOptions<unknown, AxiosError, MutateDefineParamData, unknown>,
): UseMutationResult<unknown, AxiosError, MutateDefineParamData, unknown> =>
  useMutation(
    (reqData) =>
      postRequest({
        url: DEFINE_PARAM_REQUEST_MAP[type].addItem.url,
        reqData: reqData.data,
      }),
    {
      mutationKey: [DEFINE_PARAM_REQUEST_MAP[type].addItem.key] as QueryKey,
      ...options,
    },
  );

export const usePutDefineParam = (
  type: DefineParamType,
  options?: UseMutationOptions<unknown, AxiosError, MutateDefineParamData, unknown>,
): UseMutationResult<unknown, AxiosError, MutateDefineParamData, unknown> =>
  useMutation(
    (reqData) =>
      putRequest({
        url: DEFINE_PARAM_REQUEST_MAP[type].editItem.url(reqData.id),
        reqData: reqData.data,
      }),
    {
      mutationKey: [DEFINE_PARAM_REQUEST_MAP[type].editItem.key] as QueryKey,
      ...options,
    },
  );

export const useDeleteDefineParam = (
  type: DefineParamType,
  options?: UseMutationOptions<unknown, AxiosError, number, unknown>,
): UseMutationResult<unknown, AxiosError, number, unknown> =>
  useMutation(
    (id) =>
      deleteRequest({
        url: DEFINE_PARAM_REQUEST_MAP[type].deleteItem.url(id),
      }),
    {
      mutationKey: [DEFINE_PARAM_REQUEST_MAP[type].deleteItem.key] as QueryKey,
      ...options,
    },
  );

export const useGetDefineParamExport = (
  type: DefineParamType,
  options?: UseMutationOptions<ResDownloadBlob, AxiosError, void, unknown>,
): UseMutationResult<ResDownloadBlob, AxiosError, void, unknown> =>
  useMutation(
    () =>
      downloadBlobRequest({
        url: DEFINE_PARAM_REQUEST_MAP[type].exportList.url,
      }),
    {
      mutationKey: [DEFINE_PARAM_REQUEST_MAP[type].exportList.key] as QueryKey,
      ...options,
    },
  );
