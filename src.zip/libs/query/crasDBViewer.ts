import { API_URL } from '@constants/constants';
import { getRequest, postRequest } from '@libs/axios/requests';
import { AxiosError } from 'axios';
import {
  QueryKey,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';

import {
  CrasDBViewerTableListItem,
  CrasDBViewerGetTableDataFromTreeParams,
  CrasDBViewerResPagination,
  CrasDBViewerQueryRequest,
  CrasDBViewerCommonRequestParams,
  CrasDBViewerDefaultQuery,
  CrasDBViewerColumnTableColumn,
} from '@/types/crasDBViewer';

export const useGetCrasDBViewerTableList = (
  options?: UseQueryOptions<CrasDBViewerTableListItem[], AxiosError, CrasDBViewerTableListItem[], QueryKey>,
): UseQueryResult<CrasDBViewerTableListItem[], AxiosError> => {
  return useQuery(
    ['cras-db-viewer-get-table-list'] as QueryKey,
    ({ signal }) =>
      getRequest<CrasDBViewerTableListItem[]>({ url: API_URL.GET_CRAS_DB_VIEWER_TABLE_LIST, options: { signal } }),
    {
      ...options,
    }
  );
};

export const useGetCrasDBViewerTableDataFromTree = (
  params: CrasDBViewerGetTableDataFromTreeParams,
  options?: UseQueryOptions<CrasDBViewerResPagination, AxiosError, CrasDBViewerResPagination, QueryKey>,
): UseQueryResult<CrasDBViewerResPagination, AxiosError> => {
  const { siteId, schema, table, page, size, sort } = params;
  const queryString: string = Object.entries(params).reduce((acc, [k, v]) => {
    if (k === 'siteId') {
      return acc;
    }
    return v === null ? `${acc}${k}=&` : `${acc}${k}=${v}&`;
  }, '');
  return useQuery(
    ['cras-db-viewer-get-table-data-from-tree', siteId, schema, table, page, size, sort] as QueryKey,
    ({ signal }) => {
      return getRequest<CrasDBViewerResPagination>(
        {
          url: API_URL.GET_CRAS_DB_VIEWER_DATA_TAB_INFO_FROM_TREE(
            siteId as number,
            queryString
          ),
          options: { signal }
        }
      );
    },
    {
      ...options,
    }
  );
};

export const usePostCrasDBViewerTableDataFromQuery = (
  params: CrasDBViewerQueryRequest,
  options?: UseQueryOptions<CrasDBViewerResPagination, AxiosError, CrasDBViewerResPagination, QueryKey>,
): UseQueryResult<CrasDBViewerResPagination, AxiosError> => {
  const { siteId, ...rest } = params;
  return useQuery(
    ['cras-db-viewer-get-table-data-from-query', rest.page, rest.size, rest.sort] as QueryKey,
    ({ signal }) => {
      return postRequest<CrasDBViewerQueryRequest, CrasDBViewerResPagination>(
        {
          url: API_URL.POST_CRAS_DB_VIEWER_DATA_TAB_INFO_FROM_QUERY(
            siteId as number,
          ),
          reqData: rest,
          options: { signal }
        }
      );
    },
    {
      ...options,
    }
  );
};

export const useGetCrasDBViewerDefaultQuery = (
  params: CrasDBViewerCommonRequestParams,
  options?: UseQueryOptions<CrasDBViewerDefaultQuery, AxiosError, CrasDBViewerDefaultQuery, QueryKey>,
): UseQueryResult<CrasDBViewerDefaultQuery, AxiosError> => {
  const { siteId, schema, table } = params;
  return useQuery(
    ['cras-db-viewer-get-default-query', siteId, schema, table] as QueryKey,
    ({ signal }) => {
      return getRequest<CrasDBViewerDefaultQuery>(
        {
          url: API_URL.GET_CRAS_DB_VIEWER_DEFAULT_QUERY(
              siteId as number,
              schema as string,
              table as string,
          ),
          options: { signal }
        }
      );
    },
    {
      ...options,
    }
  );
};

export const useGetCrasDBViewerColumnTableData = (
  params: CrasDBViewerCommonRequestParams,
  options?: UseQueryOptions<CrasDBViewerColumnTableColumn[], AxiosError, CrasDBViewerColumnTableColumn[], QueryKey>,
): UseQueryResult<CrasDBViewerColumnTableColumn[], AxiosError> => {
  const { siteId, schema, table } = params;
  return useQuery(
      ['cras-db-viewer-get-column-table-data', siteId, schema, table] as QueryKey,
      ({ signal }) => {
        return getRequest<CrasDBViewerColumnTableColumn[]>(
          {
            url: API_URL.GET_CRAS_DB_VIEWER_COLUMN_TAB_INFO(
              siteId as number,
              schema as string,
              table as string,
            ),
            options: { signal }
          }
        );
      },
      {
        ...options,
      }
  );
};