import { API_URL } from '@constants/constants';
import { getRequest } from '@libs/axios/requests';
import { QueryKey, useMutation, UseMutationOptions, UseMutationResult } from '@tanstack/react-query';
import type { AuthLoginUserData, ReqAuthLoginData } from '@typesdef/auth';
import { AxiosError } from 'axios';
import { MUTATION_KEY } from './mutationKey';

export const useGetAuthLogin = (
  options?: UseMutationOptions<AuthLoginUserData, AxiosError, ReqAuthLoginData, unknown>,
): UseMutationResult<AuthLoginUserData, AxiosError, ReqAuthLoginData, unknown> =>
  useMutation(
    (reqData: ReqAuthLoginData) =>
      getRequest<AuthLoginUserData>({
        url: API_URL.GET_AUTH_LOGIN(reqData.username, reqData.password),
      }),
    {
      mutationKey: [MUTATION_KEY.AUTH_LOGIN] as QueryKey,
      ...options,
    },
  );

export const useGetAuthMe = (
  options?: UseMutationOptions<AuthLoginUserData, AxiosError, void, unknown>,
): UseMutationResult<AuthLoginUserData, AxiosError, void, unknown> =>
  useMutation(
    () =>
      getRequest<AuthLoginUserData>({
        url: API_URL.GET_AUTH_ME,
      }),
    {
      mutationKey: [MUTATION_KEY.AUTH_ME] as QueryKey,
      ...options,
    },
  );

export const useGetLogOut = (
  options?: UseMutationOptions<unknown, AxiosError, void, unknown>,
): UseMutationResult<unknown, AxiosError, void, unknown> =>
  useMutation(
    () =>
      getRequest({
        url: API_URL.GET_AUTH_LOGOUT,
      }),
    {
      mutationKey: [MUTATION_KEY.AUTH_LOGOUT] as QueryKey,
      ...options,
    },
  );
