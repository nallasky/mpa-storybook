import { API_URL } from '@constants/constants';
import { deleteRequest, downloadBlobRequest, getRequest, postRequest, putRequest } from '@libs/axios/requests';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import { ResDownloadBlob } from '@typesdef/common';
import type {
  ReqSystemConfigDefaultEmail,
  ReqSystemConfigFtpTest,
  ReqSystemConfigRetention,
  ResSystemConfigDefaultEmail,
  ResSystemConfigFtpMutation,
  SystemConfigDefaultEmailState,
  SystemConfigFtp,
  SystemConfigFtpSummary,
  SystemConfigLicense,
} from '@typesdef/systemConfig';

import { AxiosError } from 'axios';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const useGetSystemConfigDefaultEmail = (
  options?: UseQueryOptions<ResSystemConfigDefaultEmail, AxiosError, SystemConfigDefaultEmailState, QueryKey>,
): UseQueryResult<SystemConfigDefaultEmailState, AxiosError> =>
  useQuery(
    [QUERY_KEY.SYSTEM_CONFIG_DEFAULT_EMAIL] as QueryKey,
    ({ signal }) =>
      getRequest<ResSystemConfigDefaultEmail>({ url: API_URL.GET_SYSTEM_CONFIG_DEFAULT_EMAIL, options: { signal } }),
    {
      ...options,
      select: (data) => ({
        ...data,
        recipient: {
          emailBook: data.recipient.emailBook.map((item) => ({ ...item, label: item.email, value: item.email })),
          groupBook: data.recipient.groupBook.map((item) => ({ ...item, label: item.email, value: item.email })),
          customEmails: data.recipient.customEmails,
        },
      }),
    },
  );

export const usePutSystemConfigDefaultEmail = (
  options?: UseMutationOptions<unknown, AxiosError, ReqSystemConfigDefaultEmail, unknown>,
): UseMutationResult<unknown, AxiosError, ReqSystemConfigDefaultEmail, unknown> =>
  useMutation(
    (reqData: ReqSystemConfigDefaultEmail) =>
      putRequest<ReqSystemConfigDefaultEmail>({
        url: API_URL.PUT_SYSTEM_CONFIG_DEFAULT_EMAIL,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.SYSTEM_CONFIG_DEFAULT_EMAIL] as QueryKey,
      ...options,
    },
  );

export const useGetSystemConfigFtpList = (
  options?: UseQueryOptions<SystemConfigFtpSummary[], AxiosError, SystemConfigFtpSummary[], QueryKey>,
): UseQueryResult<SystemConfigFtpSummary[], AxiosError> =>
  useQuery(
    [QUERY_KEY.SYSTEM_CONFIG_FTP_LIST] as QueryKey,
    ({ signal }) => getRequest<SystemConfigFtpSummary[]>({ url: API_URL.GET_SYSTEM_CONFIG_FTP, options: { signal } }),
    {
      ...options,
    },
  );

export const useGetSystemConfigFtpById = (
  siteId: number | string,
  options?: UseQueryOptions<SystemConfigFtp, AxiosError, SystemConfigFtp, QueryKey>,
): UseQueryResult<SystemConfigFtp, AxiosError> =>
  useQuery(
    [QUERY_KEY.SYSTEM_CONFIG_FTP_ITEM, siteId] as QueryKey,
    ({ signal }) =>
      getRequest<SystemConfigFtp>({ url: API_URL.GET_SYSTEM_CONFIG_FTP_BY_ID(siteId), options: { signal } }),
    {
      ...options,
    },
  );

export const usePostSystemConfigFtp = (
  options?: UseMutationOptions<ResSystemConfigFtpMutation, AxiosError, SystemConfigFtp, unknown>,
): UseMutationResult<ResSystemConfigFtpMutation, AxiosError, SystemConfigFtp, unknown> =>
  useMutation(
    (reqData: SystemConfigFtp) =>
      postRequest<SystemConfigFtp, ResSystemConfigFtpMutation>({
        url: API_URL.POST_SYSTEM_CONFIG_FTP,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.SYSTEM_CONFIG_FTP_ADD] as QueryKey,
      ...options,
    },
  );

export const usePutSystemConfigFtp = (
  options?: UseMutationOptions<ResSystemConfigFtpMutation, AxiosError, SystemConfigFtp, unknown>,
): UseMutationResult<ResSystemConfigFtpMutation, AxiosError, SystemConfigFtp, unknown> =>
  useMutation(
    (reqData: SystemConfigFtp) =>
      putRequest<SystemConfigFtp, ResSystemConfigFtpMutation>({
        url: API_URL.PUT_SYSTEM_CONFIG_FTP(reqData.id),
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.SYSTEM_CONFIG_FTP_EDIT] as QueryKey,
      ...options,
    },
  );

export const useDeleteSystemConfigFtp = (
  options?: UseMutationOptions<ResSystemConfigFtpMutation, AxiosError, number, unknown>,
): UseMutationResult<ResSystemConfigFtpMutation, AxiosError, number, unknown> =>
  useMutation(
    (id: number) =>
      deleteRequest({
        url: API_URL.DELETE_SYSTEM_CONFIG_FTP(id),
      }),
    {
      mutationKey: [MUTATION_KEY.SYSTEM_CONFIG_FTP_DELETE] as QueryKey,
      ...options,
    },
  );

export const usePostSystemConfigFtpTest = (
  options?: UseMutationOptions<unknown, AxiosError, ReqSystemConfigFtpTest, unknown>,
): UseMutationResult<unknown, AxiosError, ReqSystemConfigFtpTest, unknown> =>
  useMutation(
    (reqData: ReqSystemConfigFtpTest) =>
      postRequest<ReqSystemConfigFtpTest>({
        url: API_URL.POST_SYSTEM_CONFIG_FTP_TEST,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.SYSTEM_CONFIG_FTP_TEST] as QueryKey,
      ...options,
    },
  );

export const useGetSystemConfigLicense = (
  options?: UseQueryOptions<SystemConfigLicense, AxiosError, SystemConfigLicense, QueryKey>,
): UseQueryResult<SystemConfigLicense, AxiosError> =>
  useQuery(
    [QUERY_KEY.SYSTEM_CONFIG_LICENSE] as QueryKey,
    ({ signal }) => getRequest<SystemConfigLicense>({ url: API_URL.GET_SYSTEM_CONFIG_LICENSE, options: { signal } }),
    {
      ...options,
    },
  );

export const useGetSystemConfigLicenseExport = (
  options?: UseMutationOptions<ResDownloadBlob, AxiosError, void, unknown>,
): UseMutationResult<ResDownloadBlob, AxiosError, void, unknown> =>
  useMutation(
    () =>
      downloadBlobRequest({
        url: API_URL.GET_SYSTEM_CONFIG_LICENSE_EXPORT,
      }),
    {
      mutationKey: [MUTATION_KEY.SYSTEM_CONFIG_LICENSE_EXPORT] as QueryKey,
      ...options,
    },
  );

export const useGetSystemConfigRetention = (
  options?: UseQueryOptions<ReqSystemConfigRetention, AxiosError, ReqSystemConfigRetention, QueryKey>,
): UseQueryResult<ReqSystemConfigRetention, AxiosError> =>
  useQuery(
    [QUERY_KEY.SYSTEM_CONFIG_RETENTION] as QueryKey,
    ({ signal }) =>
      getRequest<ReqSystemConfigRetention>({ url: API_URL.GET_SYSTEM_CONFIG_RETENTION, options: { signal } }),
    {
      ...options,
    },
  );

export const usePutSystemConfigRetention = (
  options?: UseMutationOptions<unknown, AxiosError, ReqSystemConfigRetention, unknown>,
): UseMutationResult<unknown, AxiosError, ReqSystemConfigRetention, unknown> =>
  useMutation(
    (reqData: ReqSystemConfigRetention) =>
      putRequest<ReqSystemConfigRetention>({
        url: API_URL.PUT_SYSTEM_CONFIG_RETENTION,
        reqData,
      }),
    {
      mutationKey: [MUTATION_KEY.SYSTEM_CONFIG_RETENTION_EDIT] as QueryKey,
      ...options,
    },
  );
