import { API_URL } from '@constants/constants';
import { postRequest } from '@libs/axios/requests';
import { AxiosError } from 'axios';
import { QueryKey, useMutation, UseMutationOptions, UseMutationResult } from '@tanstack/react-query';
import { MUTATION_KEY } from './mutationKey';

export const usePostAddressImport = (
  options?: UseMutationOptions<unknown, AxiosError, FormData, unknown>,
): UseMutationResult<unknown, AxiosError, FormData, unknown> =>
  useMutation(
    (formData: FormData) =>
      postRequest<FormData>({
        url: API_URL.POST_ADDRESS_IMPORT,
        reqData: formData,
        options: {
          headers: { 'Content-Type': 'multipart/form-data' },
        },
      }),
    {
      mutationKey: [MUTATION_KEY.ADDRESS_IMPORT] as QueryKey,
      ...options,
    },
  );
