import { API_URL } from '@constants/constants';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import {
  CrasDataCreateInfo,
  CrasDataCreateOption,
  CrasDataInfo,
  CrasDataJudgeInfo,
  CrasDataJudgeOption,
  CrasDataManualInfo,
  CrasDataSiteInfo,
  CrasDataSiteOptionData,
  CrasDataSiteOptionLabeledData,
  ReqCrasDataCopy,
} from '@typesdef/crasData';
import { AxiosError } from 'axios';
import {
  deleteCrasManualCreateDelete,
  deleteCrasManualJudgeDelete,
  getCrasManualCreateInfoDetail,
  getCrasManualCreateInfoList,
  getCrasManualCreateOption,
  getCrasManualCreateTargetColumn,
  getCrasManualCreateTargetTable,
  getCrasManualEquipOption,
  getCrasManualJudgeInfoDetail,
  getCrasManualJudgeInfoList,
  getCrasManualJudgeOption,
} from '../axios/requests';
import { getRequest, postRequest } from './../axios/requests';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const useGetCrasDataList = (
  options?: UseQueryOptions<CrasDataInfo[], AxiosError, CrasDataInfo[], QueryKey>,
): UseQueryResult<CrasDataInfo[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_CRAS_LIST] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_CRAS_INFO_LIST,
        options: {
          signal,
        },
      }),
    {
      ...options,
      select: (data) => data.map((item, index) => ({ ...item, index })),
    },
  );

export const useGetCrasDataRegisterStatusList = (
  valueKey: keyof CrasDataSiteInfo,
  options?: UseQueryOptions<CrasDataSiteOptionData, AxiosError, CrasDataSiteOptionLabeledData, QueryKey>,
): UseQueryResult<CrasDataSiteOptionLabeledData, AxiosError> =>
  useQuery(
    [QUERY_KEY.STATUS_SITE_LIST_NOT_ADDED_CRAS_DATA, valueKey] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_STATUS_SITE_LIST_NOT_ADDED_CRAS_DATA,
        options: {
          signal,
        },
      }),
    {
      ...options,
      select: (data) => {
        const registered =
          data?.registered?.map((item) => ({ key: `${item.siteId}`, label: item.name, value: item[valueKey] })) ?? [];
        const unregistered =
          data?.unregistered?.map((item) => ({ key: `${item.siteId}`, label: item.name, value: item[valueKey] })) ?? [];
        return { registered, unregistered };
      },
    },
  );

export const usePostCrasDataCopy = (
  options?: UseMutationOptions<unknown, AxiosError, ReqCrasDataCopy, unknown>,
): UseMutationResult<unknown, AxiosError, ReqCrasDataCopy, unknown> =>
  useMutation(
    (reqData: ReqCrasDataCopy) =>
      postRequest({
        url: API_URL.POST_CRAS_SITE_COPY(reqData.siteId, reqData.newSiteId),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_CRAS_COPY_SITE] as QueryKey,
      ...options,
    },
  );

export const useGetCrasDataCrasList = (
  selectId: number,
  options?: UseQueryOptions<CrasDataManualInfo[], AxiosError, CrasDataManualInfo[], QueryKey>,
): UseQueryResult<CrasDataManualInfo[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_CRAS_MANUAL_CREATE_LIST, selectId] as QueryKey,
    () => getCrasManualCreateInfoList(selectId as number),
    options,
  );

export const useGetCrasDataJudgeList = (
  selectId: number,
  options?: UseQueryOptions<CrasDataManualInfo[], AxiosError, CrasDataManualInfo[], QueryKey>,
): UseQueryResult<CrasDataManualInfo[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_CRAS_MANUAL_JUDGE_LIST, selectId] as QueryKey,
    () => getCrasManualJudgeInfoList(selectId as number),
    options,
  );

export const useGetCrasDataCreateOption = (
  options?: UseQueryOptions<CrasDataCreateOption, AxiosError, CrasDataCreateOption, QueryKey>,
): UseQueryResult<CrasDataCreateOption, AxiosError> =>
  useQuery([QUERY_KEY.RULES_CRAS_MANUAL_CREATE_OPTION] as QueryKey, getCrasManualCreateOption, options);

export const useGetCrasDataJudgeOption = (
  options?: UseQueryOptions<CrasDataJudgeOption, AxiosError, CrasDataJudgeOption, QueryKey>,
): UseQueryResult<CrasDataJudgeOption, AxiosError> =>
  useQuery([QUERY_KEY.RULES_CRAS_MANUAL_JUDGE_OPTION] as QueryKey, getCrasManualJudgeOption, options);

export const useDeleteCrasDataCreate = (
  options?: UseMutationOptions<unknown, AxiosError, { id: number; itemId: number }, unknown>,
): UseMutationResult<unknown, AxiosError, { id: number; itemId: number }, unknown> =>
  useMutation(({ id, itemId }: { id: number; itemId: number }) => deleteCrasManualCreateDelete(id, itemId), {
    mutationKey: [MUTATION_KEY.RULES_CRAS_CREATE_DELETE] as QueryKey,
    ...options,
  });

export const useDeleteCrasDataJudge = (
  options?: UseMutationOptions<unknown, AxiosError, { id: number; itemId: number }, unknown>,
): UseMutationResult<unknown, AxiosError, { id: number; itemId: number }, unknown> =>
  useMutation(({ id, itemId }: { id: number; itemId: number }) => deleteCrasManualJudgeDelete(id, itemId), {
    mutationKey: [MUTATION_KEY.RULES_CRAS_JUDGE_DELETE] as QueryKey,
    ...options,
  });

export const useGetCrasDataEquipOption = (
  selectId: number,
  type: 'create' | 'judge',
  options?: UseQueryOptions<string[], AxiosError, string[], QueryKey>,
): UseQueryResult<string[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_CRAS_MANUAL_EQUIP_OPTION, type, selectId] as QueryKey,
    () => getCrasManualEquipOption(selectId as number),
    options,
  );

export const useGetCrasDataCreateInfo = (
  selectId: number,
  selectItemId: number,
  options?: UseQueryOptions<CrasDataCreateInfo, AxiosError, CrasDataCreateInfo, QueryKey>,
): UseQueryResult<CrasDataCreateInfo, AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_CRAS_MANUAL_CREATE_DETAIL, selectId, selectItemId] as QueryKey,
    () => getCrasManualCreateInfoDetail(selectId as number, selectItemId as number),
    options,
  );

export const useGetCrasDataCreateTargetTable = (
  selectId: number,
  options?: UseQueryOptions<string[], AxiosError, string[], QueryKey>,
): UseQueryResult<string[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_CRAS_MANUAL_CREATE_TARGET_TABLE_LIST, selectId] as QueryKey,
    () => getCrasManualCreateTargetTable(selectId as number),
    {
      ...options,
    },
  );

export const useGetCrasDataCreateColumnList = (
  selectId: number,
  selectTable: string,
  options?: UseQueryOptions<string[], AxiosError, string[], QueryKey>,
): UseQueryResult<string[], AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_CRAS_MANUAL_CREATE_TARGET_COLUMN_LIST, selectId, selectTable] as QueryKey,
    () => getCrasManualCreateTargetColumn(selectId, selectTable),
    {
      ...options,
    },
  );

export const useGetCrasDataJudgeInfo = (
  selectId: number,
  selectItemId: number,
  options?: UseQueryOptions<CrasDataJudgeInfo, AxiosError, CrasDataJudgeInfo, QueryKey>,
): UseQueryResult<CrasDataJudgeInfo, AxiosError> =>
  useQuery(
    [QUERY_KEY.RULES_CRAS_MANUAL_JUDGE_DETAIL, selectId, selectItemId] as QueryKey,
    () => getCrasManualJudgeInfoDetail(selectId, selectItemId),
    options,
  );
