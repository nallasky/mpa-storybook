import { API_URL } from '@constants/constants';
import { deleteRequest, downloadBlobRequest, getRequest, postRequest, putRequest } from '@libs/axios/requests';
import { getQueriesParam } from '@libs/util/convert';
import {
  QueryKey,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
  useMutation,
} from '@tanstack/react-query';
import { ReqColumDefine, TypeColumnDefineTab } from '@typesdef/columnDefine';
import { ReqParam, ResDownloadBlob, ResPagination } from '@typesdef/common';
import { ConvertRuleItem } from '@typesdef/convertRules';
import { AxiosError } from 'axios';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const useGetColumnDefine = (
  params: ReqParam<'type'>,
  options?: UseQueryOptions<ResPagination<ConvertRuleItem[]>, AxiosError, ResPagination<ConvertRuleItem[]>, QueryKey>,
): UseQueryResult<ResPagination<ConvertRuleItem[]>, AxiosError> => {
  const { paths, query, pagination, search } = params;

  const { type } = paths ?? { type: '' };

  return useQuery(
    [QUERY_KEY.RULES_COL_DEFINE_LIST, type, { ...query, ...pagination, ...search }] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_COLUMN_DEFINE_LIST(
          type,
          getQueriesParam({
            query,
            pagination,
            search,
          }),
        ),
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

export const usePostColumnDefine = (
  options?: UseMutationOptions<unknown, AxiosError, ReqColumDefine, unknown>,
): UseMutationResult<unknown, AxiosError, ReqColumDefine, unknown> =>
  useMutation(
    (reqData) =>
      postRequest<ConvertRuleItem>({
        url: API_URL.POST_COLUMN_DEFINE(reqData.type),
        reqData: reqData.data,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_COL_DEFINE_ADD] as QueryKey,
      ...options,
    },
  );

export const usePutColumnDefine = (
  options?: UseMutationOptions<unknown, AxiosError, ReqColumDefine, unknown>,
): UseMutationResult<unknown, AxiosError, ReqColumDefine, unknown> =>
  useMutation(
    (reqData) =>
      putRequest<ConvertRuleItem>({
        url: API_URL.PUT_COLUMN_DEFINE(reqData.type, reqData.id as number),
        reqData: reqData.data,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_COL_DEFINE_EDIT] as QueryKey,
      ...options,
    },
  );

export const useDeleteColumnDefine = (
  options?: UseMutationOptions<unknown, AxiosError, Pick<ReqColumDefine, 'id' | 'type'>, unknown>,
): UseMutationResult<unknown, AxiosError, Pick<ReqColumDefine, 'id' | 'type'>, unknown> =>
  useMutation(
    (reqData) =>
      deleteRequest({
        url: API_URL.DELETE_COLUMN_DEFINE(reqData.type, reqData.id as number),
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_COL_DEFINE_DELETE] as QueryKey,
      ...options,
    },
  );

export const useGetColumnDefineExport = (
  options?: UseMutationOptions<ResDownloadBlob, AxiosError, void, unknown>,
): UseMutationResult<ResDownloadBlob, AxiosError, void, unknown> =>
  useMutation(
    () =>
      downloadBlobRequest({
        url: API_URL.GET_COLUMN_DEFINE_EXPORT,
      }),
    {
      mutationKey: [MUTATION_KEY.RULES_COL_DEFINE_EXPORT] as QueryKey,
      ...options,
    },
  );
