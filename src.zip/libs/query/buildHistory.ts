import { API_URL } from '@constants/constants';
import { getQueriesParam } from '@libs/util/convert';
import {
  QueryKey,
  useMutation,
  UseMutationOptions,
  UseMutationResult,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from '@tanstack/react-query';
import { ReqParam, ResPagination } from '@typesdef/common';
import { AxiosError } from 'axios';
import { deleteRequest, getHistoryBuildData, getHistoryBuildStatus, getRequest } from '../axios/requests';
import { ResGetBuildHistoryData, ResGetBuildHistoryItem } from '../axios/types';
import { MUTATION_KEY } from './mutationKey';
import { QUERY_KEY } from './queryKey';

export const useGetHistoryLogData = (
  url: string,
  start: number,
  options?: UseQueryOptions<ResGetBuildHistoryData, AxiosError, ResGetBuildHistoryData, QueryKey>,
): UseQueryResult<ResGetBuildHistoryData, AxiosError> =>
  useQuery(
    [QUERY_KEY.HISTORY_DATA, url] as QueryKey,
    ({ signal }) => getHistoryBuildData({ url, start, signal }),
    options,
  );

export const useGetHistoryLogStatus = (
  id: string,
  options?: UseQueryOptions<ResGetBuildHistoryItem, AxiosError, ResGetBuildHistoryItem, QueryKey>,
): UseQueryResult<ResGetBuildHistoryItem, AxiosError> =>
  useQuery([QUERY_KEY.HISTORY_STATUS, id] as QueryKey, () => getHistoryBuildStatus(id), options);

export const useGetHistoryLogList = (
  params: ReqParam<'type' | 'stepType' | 'jobId' | 'stepId'>,
  options?: UseQueryOptions<
    ResPagination<ResGetBuildHistoryItem[]>,
    AxiosError,
    ResPagination<ResGetBuildHistoryItem[]>,
    QueryKey
  >,
): UseQueryResult<ResPagination<ResGetBuildHistoryItem[]>, AxiosError> => {
  const { paths, query, pagination, search } = params;
  const { type, stepType, jobId, stepId } = paths ?? { type: '', stepType: '', jobId: '', stepId: '' };

  return useQuery(
    [QUERY_KEY.STATUS_LOCAL_LIST, type, stepType, jobId, stepId, { ...query, ...pagination, ...search }] as QueryKey,
    ({ signal }) =>
      getRequest({
        url: API_URL.GET_STATUS_BUILD_HISTORY_LIST(
          type as string,
          jobId as string,
          stepId as string,
          getQueriesParam({
            query,
            pagination,
            search,
          }),
        ),
        options: { signal },
      }),
    {
      ...options,
    },
  );
};

export const useDeleteHistoryLog = (
  options?: UseMutationOptions<unknown, AxiosError, string, unknown>,
): UseMutationResult<unknown, AxiosError, string, unknown> =>
  useMutation(
    (historyId: string) =>
      deleteRequest({
        url: API_URL.DELETE_STATUS_BUILD_HISTORY_LOG(historyId),
      }),
    {
      mutationKey: [MUTATION_KEY.BUILD_HISTORY_LOG_DELETE] as QueryKey,
      ...options,
    },
  );
