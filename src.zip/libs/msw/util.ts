export const setUrl = (url: string) => `${process.env.PUBLIC_URL}${url}`;
