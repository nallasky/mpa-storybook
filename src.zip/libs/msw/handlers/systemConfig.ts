import { sleep } from '@libs/util/sleep';
import type { ReqSystemConfigRetention, SystemConfigFtp } from '@typesdef/systemConfig';
import type { DefaultBodyType, MockedRequest, RestHandler } from 'msw';
import { rest } from 'msw';
import { MockSystemConfigFTP, mockSystemConfigFTPData, MockSystemConfigRetention } from '../data/systemConfig';
import { setUrl } from '../util';

const systemConfigMock = new MockSystemConfigFTP(mockSystemConfigFTPData);
const mockRetention = new MockSystemConfigRetention();

const systemConfigHandler: RestHandler<MockedRequest<DefaultBodyType>>[] = [
  // get ftp summary list
  rest.get(setUrl('/api/v1/setting/ftp'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200), ctx.json(systemConfigMock.getSummaryFtpList()));
  }),

  // get specific ftp
  rest.get(setUrl('/api/v1/setting/ftp/:id'), async (req, res, ctx) => {
    const { id } = req.params;

    await sleep(1000);

    try {
      const ftp = systemConfigMock.getFtpById(Number(id));
      return res(ctx.status(200), ctx.json(ftp));
    } catch (e) {
      return res(ctx.status(404));
    }
  }),

  // add ftp
  rest.post<SystemConfigFtp>(setUrl('/api/v1/setting/ftp'), async (req, res, ctx) => {
    await sleep(1000);
    const body = await req.json<SystemConfigFtp>();

    const { id, name, type } = systemConfigMock.addFtp(body);

    return res(
      ctx.status(200),
      ctx.json({
        id,
        name,
        type,
      }),
    );
  }),

  // edit ftp
  rest.put<SystemConfigFtp>(setUrl('/api/v1/setting/ftp/:id'), async (req, res, ctx) => {
    await sleep(1000);
    const { id } = req.params;
    const body = await req.json<SystemConfigFtp>();

    try {
      const { id: editId, name, type } = systemConfigMock.editFtp(Number(id), body);

      return res(
        ctx.status(200),
        ctx.json({
          id: editId,
          name,
          type,
        }),
      );
    } catch (err) {
      return res(ctx.status(404));
    }
  }),

  rest.delete(setUrl('/api/v1/setting/ftp/:id'), async (req, res, ctx) => {
    await sleep(1000);
    const { id } = req.params;

    try {
      const { id: deleteId, name, type } = systemConfigMock.delete(Number(id));
      return res(
        ctx.status(200),
        ctx.json({
          id: deleteId,
          name,
          type,
        }),
      );
    } catch (error) {
      return res(ctx.status(404));
    }
  }),

  // test specific ftp connection
  rest.post(setUrl('/api/v1/setting/ftp/test'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200));
  }),

  // build history delete
  rest.delete(setUrl('/api/v1/upload/job/history/:historyId'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200));
  }),

  rest.get(setUrl('/api/v1/setting/retention'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200), ctx.json(mockRetention.getRetention()));
  }),

  rest.put(setUrl('/api/v1/setting/retention'), async (req, res, ctx) => {
    const body = await req.json<ReqSystemConfigRetention>();
    mockRetention.setRetention(body);

    await sleep(1000);
    return res(ctx.status(200));
  }),
];

export default systemConfigHandler;
