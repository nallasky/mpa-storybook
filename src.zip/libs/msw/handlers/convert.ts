import tempFile from '@assets/images/themeisle_page_not_found.svg';
import { convertLogData, convertOptionData, convertRuleData, convertSampleData } from '@libs/msw/data/convert';
import { sleep } from '@libs/util/sleep';
import type { ResPagination } from '@typesdef/common';
import type { ConvertLogItem } from '@typesdef/convertRules';
import type { DefaultBodyType, MockedRequest, RestHandler } from 'msw';
import { rest } from 'msw';
import { setUrl } from '../util';
import { convertRuleRegexData, convertSampleRegexData } from './../data/convert';

export const convertHandler: RestHandler<MockedRequest<DefaultBodyType>>[] = [
  // get convert log list
  rest.get(setUrl('/api/v1/rule/convert/log'), async (req, res, ctx) => {
    const search = req.url.searchParams.getAll('search');

    if (search.length > 0) {
      console.log('search', search);
      console.log('convertLogData', convertLogData);
      const searched = convertLogData.filter((item) => {
        return search.every((searchValue) => {
          const [key, value] = searchValue.split(',');
          const newKey = key as keyof ConvertLogItem;
          return `${item[newKey]}`.toLowerCase().includes(value.toLowerCase());
        });
      });

      console.log('searched', searched);

      const resData: Partial<ResPagination<ConvertLogItem[]>> = {
        content: searched,
        totalElements: convertLogData.length,
      };

      return res(ctx.status(200), ctx.json(resData));
    }

    const resData: Partial<ResPagination<ConvertLogItem[]>> = {
      content: convertLogData,
      totalElements: convertLogData.length,
    };

    return res(ctx.status(200), ctx.json(resData));
  }),

  // get convert log specific info
  rest.get(setUrl('/api/v1/rule/convert/log/:id'), async (req, res, ctx) => {
    const findItem = convertLogData.filter((item) => item.id === +req.params.id);

    if (findItem.length === 0) {
      return res(ctx.status(404));
    } else {
      return res(ctx.status(200), ctx.json(findItem[0]));
    }
  }),

  // import convert rules
  rest.post(setUrl('/api/v1/rule/convert/log/file/import'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200));
  }),

  // export convert rules
  rest.get(setUrl('/api/v1/rule/convert/log/file/export'), async (req, res, ctx) => {
    await sleep(1000);
    const imageBuffer = await fetch(tempFile).then((res) => res.arrayBuffer());

    return res(
      ctx.set('Content-Length', imageBuffer.byteLength.toString()),
      ctx.set('Content-Type', 'image/svg+xml'),
      ctx.set('Content-disposition', 'attachment; filename=testImage.svg'),
      // Respond with the "ArrayBuffer".
      ctx.body(imageBuffer),
    );
  }),

  // add convert log
  rest.post(setUrl('/api/v1/rule/convert/log'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200));
  }),

  // edit convert log
  rest.put(setUrl('/api/v1/rule/convert/log/:id'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200));
  }),

  // delete convert log
  rest.delete(setUrl('/api/v1/rule/convert/log/:id'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200));
  }),

  // get convert rule items
  rest.get(setUrl('/api/v1/rule/convert/log/:id/rule'), async (req, res, ctx) => {
    const { id } = req.params;

    const logData = convertLogData.find((item) => item.id === +id);
    if (logData) {
      if (+id === 1) {
        const resData = {
          ...logData,
          ...convertRuleData,
        };
        return res(ctx.status(200), ctx.json(resData));
      } else if (+id === 3) {
        const resData = {
          ...logData,
          ...convertRuleRegexData,
        };
        return res(ctx.status(200), ctx.json(resData));
      } else {
        const resData = {
          ...logData,
          convert: {
            info: [],
            header: [],
            no_header: [],
            custom: [],
          },
          filter: [],
        };
        return res(ctx.status(200), ctx.json(resData));
      }
    } else {
      return res(ctx.status(404));
    }
  }),

  // add convert rule items
  rest.post(setUrl('/api/v1/rule/convert/log/:id/rule'), async (req, res, ctx) => {
    const { id } = req.params;
    await sleep(1000);
    return res(ctx.status(200));
  }),

  // edit convert rule items
  rest.put(setUrl('/api/v1/rule/convert/log/:id/rule'), async (req, res, ctx) => {
    const { id } = req.params;
    await sleep(1000);
    return res(ctx.status(200));
  }),

  // preview convert rule
  rest.post(setUrl('/api/v1/rule/convert/rule/preview/:inputType/:previewType'), async (req, res, ctx) => {
    const { inputType, previewType } = req.params;
    console.log('url', req.url);
    console.log('inputType', inputType, 'previewType', previewType);

    await sleep(1000);

    if (previewType === 'sample') {
      if (inputType === 'regex') {
        return res(ctx.status(200), ctx.json(convertSampleRegexData));
      } else {
        return res(ctx.status(200), ctx.json(convertSampleData));
      }
    }

    return res(ctx.status(200), ctx.json(convertSampleData));
  }),

  // get convert rule option
  rest.get(setUrl('/api/v1/rule/convert/rule/option'), async (req, res, ctx) => {
    return res(ctx.status(200), ctx.json(convertOptionData));
  }),

  // get convert error list
  rest.get(setUrl('/api/v1/rule/convert/log/:logId/error'), async (req, res, ctx) => {
    const logId = req.params.logId;
    console.log('logId', logId);

    return res(ctx.status(200), ctx.json([]));
  }),
];

export default convertHandler;
