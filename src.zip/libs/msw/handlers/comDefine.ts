import tempFile from '@assets/images/themeisle_page_not_found.svg';
import { convertColDefineInfo } from '@libs/msw/data/convert';
import { sleep } from '@libs/util/sleep';
import type { ResPagination } from '@typesdef/common';
import type { ConvertRuleItem } from '@typesdef/convertRules';
import type { DefaultBodyType, MockedRequest, RestHandler } from 'msw';
import { rest } from 'msw';
import { setUrl } from '../util';

export const colDefineHandler: RestHandler<MockedRequest<DefaultBodyType>>[] = [
  // get column define list
  rest.get(setUrl('/api/v1/rule/define/column/:type'), async (req, res, ctx) => {
    const strict = req.url.searchParams.get('strict') ? true : false ?? false;
    const search = req.url.searchParams.get('search') ?? '';
    const [key, value] = search.split(',');
    let filteredData = convertColDefineInfo;

    // 전체 문자 일치
    console.log('strict', strict);

    if (key && value) {
      filteredData = filteredData.filter((item) => {
        if (strict) {
          return (item[key as keyof ConvertRuleItem] as string).toLowerCase() === value.toLowerCase();
        } else {
          const itemValue = `${item[key as keyof ConvertRuleItem]}`.toLowerCase();
          return itemValue.includes(value.toLowerCase());
        }
      });
    }

    const resData: Partial<ResPagination<ConvertRuleItem[]>> = {
      content: filteredData,
      totalElements: convertColDefineInfo.length,
    };

    return res(ctx.status(200), ctx.json(resData));
  }),

  // add column define
  rest.post(setUrl('/api/v1/rule/define/column/:type'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200));
  }),

  // edit column define
  rest.put(setUrl('/api/v1/rule/define/column/:type/:id'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200));
  }),

  // delete column define
  rest.delete(setUrl('/api/v1/rule/define/column/:type/:id'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200));
  }),

  // parse header from column define
  rest.post(setUrl('/api/v1/rule/convert/header/:logId/parse'), async (req, res, ctx) => {
    const logId = req.params.logId;
    console.log('logId', logId);

    const { data, header } = await req.json();

    const resData: ConvertRuleItem[] = convertColDefineInfo.map((item, idx) => ({
      ...item,
      data: data[idx] ?? null,
    }));

    return res(ctx.status(200), ctx.json(resData));
  }),

  // import column define
  rest.post(setUrl('/api/v1/rule/define/column/import'), async (req, res, ctx) => {
    return res(ctx.status(200));
  }),

  // export column define
  rest.get(setUrl('/api/v1/rule/define/column/export'), async (req, res, ctx) => {
    const imageBuffer = await fetch(tempFile).then((res) => res.arrayBuffer());

    return res(
      ctx.set('Content-Length', imageBuffer.byteLength.toString()),
      ctx.set('Content-Type', 'image/svg+xml'),
      ctx.set('Content-disposition', 'attachment; filename=testImage.svg'),
      // Respond with the "ArrayBuffer".
      ctx.body(imageBuffer),
    );
  }),
];

export default colDefineHandler;
