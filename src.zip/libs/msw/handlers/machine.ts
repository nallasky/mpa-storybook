import tempFile from '@assets/images/themeisle_page_not_found.svg';
import { MutateDefineParamData } from '@typesdef/defineParam';
import { DefaultBodyType, MockedRequest, rest, RestHandler } from 'msw';
import { MockMachineParam } from '../data/machine';
import { setUrl } from '../util';

const machineMock = new MockMachineParam();

const machineHandler: RestHandler<MockedRequest<DefaultBodyType>>[] = [
  //get machine list
  rest.get(setUrl('/api/v1/rule/define/machine'), async (req, res, ctx) => {
    return res(ctx.status(200), ctx.json(machineMock.getList()));
  }),

  // get specific machine item
  rest.get(setUrl('/api/v1/rule/define/machine/:id'), async (req, res, ctx) => {
    const { id } = req.params;

    return res(ctx.status(200), ctx.json(machineMock.getItem(+id)));
  }),

  // add machine item
  rest.post(setUrl('/api/v1/rule/define/machine'), async (req, res, ctx) => {
    const reqData = await req.json<MutateDefineParamData['data']>();

    machineMock.addItem(reqData);

    return res(ctx.status(200));
  }),

  // edit machine item
  rest.put(setUrl('/api/v1/rule/define/machine/:id'), async (req, res, ctx) => {
    const { id } = req.params;
    const reqData = await req.json<MutateDefineParamData['data']>();

    machineMock.editItem(+id, reqData);

    return res(ctx.status(200));
  }),

  // delete machine item
  rest.delete(setUrl('/api/v1/rule/define/machine/:id'), async (req, res, ctx) => {
    const { id } = req.params;

    machineMock.deleteItem(+id);

    return res(ctx.status(200));
  }),

  // import machine item
  rest.post(setUrl('/api/v1/rule/define/machine/import'), async (req, res, ctx) => {
    const { id } = req.params;
    return res(ctx.status(200));
  }),

  // export machine item
  rest.get(setUrl('/api/v1/rule/define/machine/export'), async (req, res, ctx) => {
    const imageBuffer = await fetch(tempFile).then((res) => res.arrayBuffer());

    return res(
      ctx.set('Content-Length', imageBuffer.byteLength.toString()),
      ctx.set('Content-Type', 'image/svg+xml'),
      ctx.set('Content-disposition', 'attachment; filename=test1.svg'),
      ctx.body(imageBuffer),
    );
  }),
];

export default machineHandler;
