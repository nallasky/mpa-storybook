import { DefaultBodyType, MockedRequest, RestHandler } from 'msw';
import accountHandler from './accout';
import arcnetHandler from './arcnet';
import colDefineHandler from './comDefine';
import convertHandler from './convert';
import cylinderHandler from './cylinder';
import homeHandler from './home';
import machineHandler from './machine';
import mahalanobisHandler from './mahalanobis';
import systemConfigHandler from './systemConfig';

const handlersMapping: Record<string, RestHandler<MockedRequest<DefaultBodyType>>[]> = {
  convert: convertHandler,
  colDefine: colDefineHandler,
  home: homeHandler,
  systemConfig: systemConfigHandler,
  account: accountHandler,
  maha: mahalanobisHandler,
  arcnet: arcnetHandler,
  cylinder: cylinderHandler,
  machine: machineHandler,
};

const enableHandler =
  process.env.NODE_ENV === 'development' && process.env.REACT_APP_MSW_MODULE
    ? (process.env.REACT_APP_MSW_MODULE as string)?.split(',').map((handler) => handler.trim()) ?? []
    : [];

// const handlers = [
//   // ...convertHandler,
//   // ...colDefineHandler,
//   // ...homeHandler,
//   ...systemConfigHandler,
// ];

const handlers = enableHandler.reduce<RestHandler<MockedRequest<DefaultBodyType>>[]>((acc, cur) => {
  if (!handlersMapping[cur]) {
    throw new Error(`There is no msw handler for ${cur}!`);
  }
  acc.push(...handlersMapping[cur]);
  return acc;
}, []);

console.log('Imported handlers', handlers);

export default handlers;
