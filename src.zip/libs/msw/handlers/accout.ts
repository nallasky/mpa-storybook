import { sleep } from '@libs/util/sleep';
import { ReqAccountGroupData, ReqAccountUserData } from '@typesdef/account';
import type { DefaultBodyType, MockedRequest, RestHandler } from 'msw';
import { rest } from 'msw';
import { accountGroupMockData, MockAccount } from '../data/account';
import { accountUserMockData } from './../data/account';

import { setUrl } from '../util';

const accountMock = new MockAccount({ users: accountUserMockData, groups: accountGroupMockData });

const accountHandler: RestHandler<MockedRequest<DefaultBodyType>>[] = [
  // get user summary list
  rest.get(setUrl('/api/v1/user/group'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200), ctx.json(accountMock.getGroupsSummary()));
  }),

  // get specific group
  rest.get(setUrl('/api/v1/user/group/:id'), async (req, res, ctx) => {
    const { id } = req.params;

    await sleep(1000);

    try {
      const ftp = accountMock.getGroupById(Number(id));
      return res(ctx.status(200), ctx.json(ftp));
    } catch (e) {
      return res(ctx.status(404));
    }
  }),

  // add group
  rest.post<ReqAccountGroupData>(setUrl('/api/v1/user/group'), async (req, res, ctx) => {
    await sleep(1000);

    try {
      const body = await req.json<ReqAccountGroupData>();
      const response = accountMock.addGroup(body);
      return res(ctx.status(200), ctx.json(response));
    } catch (error) {
      return res(ctx.status(404));
    }
  }),

  // edit group
  rest.put<ReqAccountGroupData>(setUrl('/api/v1/user/group/:id'), async (req, res, ctx) => {
    await sleep(1000);
    const { id } = req.params;
    const body = await req.json<ReqAccountGroupData>();

    try {
      const response = accountMock.editGroup(Number(id), body);
      return res(ctx.status(200), ctx.json(response));
    } catch (err) {
      return res(ctx.status(404));
    }
  }),

  // delete group
  rest.delete(setUrl('/api/v1/user/group/:id'), async (req, res, ctx) => {
    await sleep(1000);
    const { id } = req.params;

    try {
      const response = accountMock.deleteGroup(Number(id));
      return res(ctx.status(200), ctx.json(response));
    } catch (error) {
      return res(ctx.status(404));
    }
  }),

  // get user summary list
  rest.get(setUrl('/api/v1/user'), async (req, res, ctx) => {
    await sleep(1000);
    return res(ctx.status(200), ctx.json(accountMock.getUsersSummary()));
  }),

  // get specific user
  rest.get(setUrl('/api/v1/user/:id'), async (req, res, ctx) => {
    const { id } = req.params;

    await sleep(1000);

    try {
      const ftp = accountMock.getUserById(Number(id));
      return res(ctx.status(200), ctx.json(ftp));
    } catch (e) {
      return res(ctx.status(404));
    }
  }),

  // add user
  rest.post<ReqAccountUserData>(setUrl('/api/v1/user/group'), async (req, res, ctx) => {
    await sleep(1000);

    try {
      const body = await req.json<ReqAccountUserData>();
      const response = accountMock.addUser(body);
      return res(ctx.status(200), ctx.json(response));
    } catch (error) {
      return res(ctx.status(404));
    }
  }),

  // edit user
  rest.put<ReqAccountUserData>(setUrl('/api/v1/user/:id'), async (req, res, ctx) => {
    await sleep(1000);
    const { id } = req.params;
    const body = await req.json<ReqAccountUserData>();

    try {
      const response = accountMock.editUser(Number(id), body);
      return res(ctx.status(200), ctx.json(response));
    } catch (err) {
      return res(ctx.status(404));
    }
  }),

  // delete user
  rest.delete(setUrl('/api/v1/user/:id'), async (req, res, ctx) => {
    await sleep(1000);
    const { id } = req.params;

    try {
      const response = accountMock.deleteUser(Number(id));
      return res(ctx.status(200), ctx.json(response));
    } catch (error) {
      return res(ctx.status(404));
    }
  }),
];

export default accountHandler;
