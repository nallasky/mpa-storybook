import { sleep } from '@libs/util/sleep';
import type {
  MahalanobisData,
  MahalanobisItemData,
  MahalanobisItemOptions,
  MahalanobisRegisterStatusData,
  ReqAddMahalanobisData,
} from '@typesdef/mahalanobis';
import { DefaultBodyType, MockedRequest, rest, RestHandler } from 'msw';
import { MahalanobisMock, MahalanobisSiteListMock } from '../data/mahalanobis';
import { setUrl } from '../util';

const mahaMock = new MahalanobisMock();
const mahaSiteMock = new MahalanobisSiteListMock();

const mahalanobisHandler: RestHandler<MockedRequest<DefaultBodyType>>[] = [
  // get maha list
  rest.get<MahalanobisData[]>(setUrl('/api/v1/rule/analysis/mahalanobis'), async (req, res, ctx) => {
    return res(ctx.status(200), ctx.json(mahaMock.getMahaList()));
  }),

  // get maha site list
  rest.get<MahalanobisRegisterStatusData>(setUrl('/api/v1/status/site/mahalanobis'), async (req, res, ctx) => {
    return res(ctx.status(200), ctx.json(mahaSiteMock.getList()));
  }),

  // add maha
  rest.post<ReqAddMahalanobisData>(setUrl('/api/v1/rule/analysis/mahalanobis'), async (req, res, ctx) => {
    await sleep(1000);

    try {
      const { siteId } = await req.json<ReqAddMahalanobisData>();
      const siteData = mahaSiteMock.getBySiteId(siteId);
      const response = mahaMock.addMaha({
        id: -1,
        siteId: siteData.siteId,
        companyFabName: siteData.name,
        itemCnt: 0,
        date: '2023-03-27 00:00:00',
      });
      return res(ctx.status(200));
    } catch (error) {
      console.error(error);
      return res(ctx.status(404));
    }
  }),

  // delete maha
  rest.delete(setUrl('/api/v1/rule/analysis/mahalanobis/:id'), async (req, res, ctx) => {
    await sleep(1000);
    const { id } = req.params;

    try {
      const getMaha = mahaMock.getMahaById(+id);
      mahaSiteMock.unregister(getMaha.siteId);
      mahaMock.deleteMaha(+id);
      return res(ctx.status(200));
    } catch (error) {
      console.error(error);
      return res(ctx.status(404));
    }
  }),

  // copy maha
  rest.post(setUrl('/api/v1/rule/analysis/mahalanobis/copy/:id'), async (req, res, ctx) => {
    await sleep(1000);
    const { id } = req.params;

    try {
      return res(
        ctx.status(200),
        ctx.json(
          mahaMock.getMahaItemList().map((item) => ({
            ...item,
            original_equipment_name: item.equipment_name,
          })),
        ),
      );
    } catch (error) {
      console.error(error);
      return res(ctx.status(404));
    }
  }),

  // get maha item list
  rest.get<MahalanobisData[]>(setUrl('/api/v1/rule/analysis/mahalanobis/:id/item'), async (req, res, ctx) => {
    await sleep(1000);
    const { id } = req.params;

    try {
      return res(ctx.status(200), ctx.json(mahaMock.getMahaItemList()));
    } catch (error) {
      console.error(error);
      return res(ctx.status(404));
    }
  }),

  // get specific maha item
  rest.get<MahalanobisData[]>(setUrl('/api/v1/rule/analysis/mahalanobis/:id/item/:itemId'), async (req, res, ctx) => {
    await sleep(1000);
    const { id, itemId } = req.params;

    console.log('get specific maha item', id, itemId);

    try {
      return res(ctx.status(200), ctx.json(mahaMock.getMahaItemById(+itemId)));
    } catch (error) {
      console.error(error);
      return res(ctx.status(404));
    }
  }),

  // get mahalanobis options
  rest.get<MahalanobisItemOptions>(setUrl('/api/v1/rule/analysis/mahalanobis/:id/options'), async (req, res, ctx) => {
    await sleep(1000);
    return res(
      ctx.status(200),
      ctx.json({
        equipment: [
          {
            equipment_id: '1',
            equipment_name: 'MPA_1',
          },
          {
            equipment_id: '2',
            equipment_name: 'MPA_2',
          },
          {
            equipment_id: '3',
            equipment_name: 'MPA_3',
          },
          {
            equipment_id: '4',
            equipment_name: 'MPA_4',
          },
          {
            equipment_id: '5',
            equipment_name: 'MPA_5',
          },
          {
            equipment_id: '6',
            equipment_name: 'MPA_6',
          },
          {
            equipment_id: '7',
            equipment_name: 'MPA_7',
          },
        ],
        target: {
          chamber_detail_log: [
            '14094',
            '24018',
            'common_after_cool_temperature_mv',
            'test_column1_5',
            'test_column1_4',
            'test_column1_3',
            'test_column1_2',
            'test_column1_1',
          ],
          plate_monitor: [
            '14094',
            '24018',
            'common_after_cool_temperature_mv',
            'test_column1_5',
            'test_column1_4',
            'test_column1_3',
            'test_column1_2',
            'test_column1_1',
          ],
          adc_compensation: [
            '14094',
            '24018',
            'common_after_cool_temperature_mv',
            'test_column1_5',
            'test_column1_4',
            'test_column1_3',
            'test_column1_2',
            'test_column1_1',
          ],
        },
      }),
    );
  }),

  // add mahalanobis item
  rest.post<MahalanobisItemData>(setUrl('/api/v1/rule/analysis/mahalanobis/:id/item'), async (req, res, ctx) => {
    await sleep(1000);

    try {
      const addData = await req.json<MahalanobisItemData>();
      mahaMock.addMahaItem(addData);
    } catch (error) {
      console.error(error);
      return res(ctx.status(404));
    }
  }),

  // edit mahalanobis item
  rest.put<MahalanobisItemData>(setUrl('/api/v1/rule/analysis/mahalanobis/:id/item/:itemId'), async (req, res, ctx) => {
    console.log('edit mahalanobis item');
    await sleep(1000);
    const { id, itemId } = req.params;
    try {
      const editData = await req.json<MahalanobisItemData>();
      mahaMock.editMahaItem(+itemId, editData);
      return res(ctx.status(200));
    } catch (error) {
      console.error(error);
      return res(ctx.status(404));
    }
  }),

  // delete mahalanobis item
  rest.delete(setUrl('/api/v1/rule/analysis/mahalanobis/:id/item/:itemId'), async (req, res, ctx) => {
    await sleep(1000);
    const { id, itemId } = req.params;

    try {
      mahaMock.deleteMahaItem(+itemId);
      return res(ctx.status(200));
    } catch (error) {
      console.error(error);
      return res(ctx.status(404));
    }
  }),
];

export default mahalanobisHandler;
