import tempFile from '@assets/images/themeisle_page_not_found.svg';
import { sleep } from '@libs/util/sleep';
import {
  ArcnetItemAnalysisData,
  ArcnetItemCalculateData,
  ArcnetItemData,
  MutateArcnetItemAddData,
  MutateArcnetItemAnalysisData,
  MutateArcnetItemCalculateData,
  MutateArcnetItemCopyData,
  MutateArcnetUnitData,
} from '@typesdef/arcnet';
import type { DefaultBodyType, MockedRequest, RestHandler } from 'msw';
import { rest } from 'msw';
import { MockArcnetItem } from '../data/arcnet';
import { setUrl } from '../util';

const arcnetMock = new MockArcnetItem();

const arcnetHandler: RestHandler<MockedRequest<DefaultBodyType>>[] = [
  //get arcnet register status
  rest.get(setUrl('/api/v1/status/site/arcnet/items'), async (req, res, ctx) => {
    return res(ctx.status(200), ctx.json(arcnetMock.getRegisterStatus()));
  }),

  // get arcnet item list
  rest.get<ArcnetItemData[]>(setUrl('/api/v1/rule/analysis/arcnet/items'), async (req, res, ctx) => {
    return res(ctx.status(200), ctx.json(arcnetMock.getArcnetItems()));
  }),

  // add arcnet item
  rest.post<MutateArcnetItemAddData>(setUrl('/api/v1/rule/analysis/arcnet/items'), async (req, res, ctx) => {
    const reqData = await req.json<MutateArcnetItemAddData>();
    arcnetMock.addArcnetItems(reqData);
    return res(ctx.status(200));
  }),

  // delete arcnet item
  rest.delete(setUrl('/api/v1/rule/analysis/arcnet/items/:id'), async (req, res, ctx) => {
    const { id } = req.params;
    arcnetMock.deleteArcnetItems(+id);
    return res(ctx.status(200));
  }),

  // copy arcnet item
  rest.post<MutateArcnetItemCopyData>(setUrl('/api/v1/rule/analysis/arcnet/items/copy'), async (req, res, ctx) => {
    const reqData = await req.json<MutateArcnetItemCopyData>();
    arcnetMock.copyArcnetItems(reqData);
    return res(ctx.status(200));
  }),

  // get arcnet analysis item list
  rest.get<ArcnetItemAnalysisData[]>(
    setUrl('/api/v1/rule/analysis/arcnet/items/:id/analysis-items'),
    async (req, res, ctx) => {
      const { id } = req.params;
      return res(ctx.status(200), ctx.json(arcnetMock.getAnalysisItems(+id)));
    },
  ),

  // add arcnet analysis item
  rest.post<MutateArcnetItemAnalysisData['data']>(
    setUrl('/api/v1/rule/analysis/arcnet/items/:id/analysis-items'),
    async (req, res, ctx) => {
      const { id } = req.params;
      const reqData = await req.json<MutateArcnetItemAnalysisData['data']>();
      arcnetMock.addAnalysisItems(+id, reqData);
      return res(ctx.status(200));
    },
  ),
  // edit arcnet analysis item
  rest.put(setUrl('/api/v1/rule/analysis/arcnet/items/:id/analysis-items/:itemId'), async (req, res, ctx) => {
    const { id, itemId } = req.params;
    const reqData = await req.json<MutateArcnetItemAnalysisData['data']>();
    arcnetMock.editAnalysisItems(+id, +itemId, reqData);
    return res(ctx.status(200));
  }),

  // delete arcnet analysis item
  rest.delete(setUrl('/api/v1/rule/analysis/arcnet/items/:id/analysis-items/:itemId'), async (req, res, ctx) => {
    const { id, itemId } = req.params;
    arcnetMock.deleteAnalysisItems(+id, +itemId);
    return res(ctx.status(200));
  }),

  // import arcnet analysis item
  rest.post(setUrl('/api/v1/rule/analysis/arcnet/items/:id'), async (req, res, ctx) => {
    const { id } = req.params;
    return res(ctx.status(200));
  }),

  // export arcnet analysis item
  rest.get(setUrl('/api/v1/upload/analysis/arcnet/items/:id'), async (req, res, ctx) => {
    const imageBuffer = await fetch(tempFile).then((res) => res.arrayBuffer());

    return res(
      ctx.set('Content-Length', imageBuffer.byteLength.toString()),
      ctx.set('Content-Type', 'image/svg+xml'),
      ctx.set('Content-disposition', 'attachment; filename=test1.svg'),
      ctx.body(imageBuffer),
    );
  }),

  // get arcnet calculate item list
  rest.get<ArcnetItemCalculateData[]>(
    setUrl('/api/v1/rule/analysis/arcnet/items/:id/calculate-items'),
    async (req, res, ctx) => {
      const { id } = req.params;
      return res(ctx.status(200), ctx.json(arcnetMock.getCalculateItems(+id)));
    },
  ),

  // add arcnet calculate item
  rest.post<MutateArcnetItemCalculateData['data']>(
    setUrl('/api/v1/rule/analysis/arcnet/items/:id/calculate-items'),
    async (req, res, ctx) => {
      const { id } = req.params;
      const reqData = await req.json<MutateArcnetItemCalculateData['data']>();
      arcnetMock.addCalculateItems(+id, reqData);
      return res(ctx.status(200));
    },
  ),
  // edit arcnet calculate item
  rest.put(setUrl('/api/v1/rule/analysis/arcnet/items/:id/calculate-items/:itemId'), async (req, res, ctx) => {
    const { id, itemId } = req.params;
    const reqData = await req.json<MutateArcnetItemCalculateData['data']>();
    arcnetMock.editCalculateItems(+id, +itemId, reqData);
    return res(ctx.status(200));
  }),

  // delete arcnet calculate item
  rest.delete(setUrl('/api/v1/rule/analysis/arcnet/items/:id/calculate-items/:itemId'), async (req, res, ctx) => {
    const { id, itemId } = req.params;
    arcnetMock.deleteCalculateItems(+id, +itemId);
    return res(ctx.status(200));
  }),

  // get arcnet unit items
  rest.get(setUrl('/api/v1/rule/analysis/arcnet/units'), async (req, res, ctx) => {
    return res(ctx.status(200), ctx.json(arcnetMock.getUnitItems()));
  }),

  // get specific arcnet unit item
  rest.get(setUrl('/api/v1/rule/analysis/arcnet/units/:id'), async (req, res, ctx) => {
    const { id } = req.params;
    await sleep(3000);
    return res(ctx.status(200), ctx.json(arcnetMock.getUnitSpecificItems(+id)));
  }),

  // add arcnet unit item
  rest.post(setUrl('/api/v1/rule/analysis/arcnet/units'), async (req, res, ctx) => {
    const reqData = await req.json<MutateArcnetUnitData>();
    arcnetMock.addUnitItem(reqData);
    return res(ctx.status(200));
  }),

  // delete arcnet unit item
  rest.delete(setUrl('/api/v1/rule/analysis/arcnet/units/:id'), async (req, res, ctx) => {
    const { id } = req.params;
    arcnetMock.deleteUnitItem(+id);
    return res(ctx.status(200));
  }),

  // import arcnet unit item
  rest.post(setUrl('/api/v1/upload/analysis/arcnet/units/:id'), async (req, res, ctx) => {
    const { id } = req.params;
    return res(ctx.status(200));
  }),

  // export arcnet unit item
  rest.get(setUrl('/api/v1/upload/analysis/arcnet/units/:id'), async (req, res, ctx) => {
    const imageBuffer = await fetch(tempFile).then((res) => res.arrayBuffer());

    return res(
      ctx.set('Content-Length', imageBuffer.byteLength.toString()),
      ctx.set('Content-Type', 'image/svg+xml'),
      ctx.set('Content-disposition', 'attachment; filename=test1.svg'),
      ctx.body(imageBuffer),
    );
  }),
];

export default arcnetHandler;
