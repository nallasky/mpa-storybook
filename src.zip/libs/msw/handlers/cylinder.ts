import tempFile from '@assets/images/themeisle_page_not_found.svg';
import { MutateDefineParamData } from '@typesdef/defineParam';
import { DefaultBodyType, MockedRequest, rest, RestHandler } from 'msw';
import { MockCylinderParam } from '../data/cylinder';
import { setUrl } from './../util';

const cylinderMock = new MockCylinderParam();

const cylinderHandler: RestHandler<MockedRequest<DefaultBodyType>>[] = [
  //get cylinder list
  rest.get(setUrl('/api/v1/rule/define/cylinder'), async (req, res, ctx) => {
    return res(ctx.status(200), ctx.json(cylinderMock.getList()));
  }),

  // get specific cylinder item
  rest.get(setUrl('/api/v1/rule/define/cylinder/:id'), async (req, res, ctx) => {
    const { id } = req.params;

    return res(ctx.status(200), ctx.json(cylinderMock.getItem(+id)));
  }),

  // add cylinder item
  rest.post(setUrl('/api/v1/rule/define/cylinder'), async (req, res, ctx) => {
    const reqData = await req.json<MutateDefineParamData['data']>();

    cylinderMock.addItem(reqData);

    return res(ctx.status(200));
  }),

  // edit cylinder item
  rest.put(setUrl('/api/v1/rule/define/cylinder/:id'), async (req, res, ctx) => {
    const { id } = req.params;
    const reqData = await req.json<MutateDefineParamData['data']>();

    cylinderMock.editItem(+id, reqData);

    return res(ctx.status(200));
  }),

  // delete cylinder item
  rest.delete(setUrl('/api/v1/rule/define/cylinder/:id'), async (req, res, ctx) => {
    const { id } = req.params;

    cylinderMock.deleteItem(+id);

    return res(ctx.status(200));
  }),

  // import cylinder item
  rest.post(setUrl('/api/v1/rule/define/cylinder/import'), async (req, res, ctx) => {
    const { id } = req.params;
    return res(ctx.status(200));
  }),

  // export cylinder item
  rest.get(setUrl('/api/v1/rule/define/cylinder/export'), async (req, res, ctx) => {
    const imageBuffer = await fetch(tempFile).then((res) => res.arrayBuffer());

    return res(
      ctx.set('Content-Length', imageBuffer.byteLength.toString()),
      ctx.set('Content-Type', 'image/svg+xml'),
      ctx.set('Content-disposition', 'attachment; filename=test1.svg'),
      ctx.body(imageBuffer),
    );
  }),
];

export default cylinderHandler;
