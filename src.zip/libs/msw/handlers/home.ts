import { sleep } from '@libs/util/sleep';
import type { ResPagination } from '@typesdef/common';
import type { HomeRemoteJobDetailItem } from '@typesdef/home';
import type { DefaultBodyType, MockedRequest, RestHandler } from 'msw';
import { rest } from 'msw';
import { homeRemoteJobDetailData } from '../data/home';
import { setUrl } from '../util';
import { homeRemoteJobData } from './../data/home';

export const homeHandler: RestHandler<MockedRequest<DefaultBodyType>>[] = [
  rest.get(setUrl('/api/v1/home'), async (req, res, ctx) => {
    await sleep(1000);

    return res(ctx.status(200), ctx.json(homeRemoteJobData));
  }),

  rest.get(setUrl('/api/v1/home/:siteId'), async (req, res, ctx) => {
    const page = req.url.searchParams.get('page');
    const size = req.url.searchParams.get('size');
    const siteId = Number.isInteger(Number(req.params.siteId)) ? Number(req.params.siteId) : 0;

    await sleep(1000);

    if (siteId === 0) {
      return res(ctx.status(400));
    }

    if (page && size) {
      const startIdx = +page * +size;
      const endIdx = startIdx + +size;
      const content = homeRemoteJobDetailData[siteId - 1].slice(startIdx, endIdx);
      const totalElements = homeRemoteJobDetailData[siteId - 1].length;
      const resData: Partial<ResPagination<HomeRemoteJobDetailItem[]>> = {
        content,
        totalElements,
      };

      return res(ctx.status(200), ctx.json(resData));
    } else {
      const totalElements = homeRemoteJobDetailData[siteId - 1].length;
      const resData: Partial<ResPagination<HomeRemoteJobDetailItem[]>> = {
        content: homeRemoteJobDetailData[siteId - 1],
        totalElements,
      };

      return res(ctx.status(200), ctx.json(resData));
    }
  }),
];

export default homeHandler;
