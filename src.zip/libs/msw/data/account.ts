import type {
  AccountGroupData,
  AccountGroupSummaryData,
  AccountUserData,
  AccountUserRoleType,
  AccountUserSummaryData,
  ReqAccountGroupData,
  ReqAccountUserData,
} from '@typesdef/account';

interface MockAccountUser {
  id: number;
  username: string;
  groupId: number;
  groupName: string;
  accessAt: string;
  updateAt: string;
  password: string;
}

interface MockAccountGroup {
  id: number;
  groupName: string;
  roles: AccountUserRoleType[];
  isDefault: boolean;
}

export class MockAccount {
  users: MockAccountUser[] = [];
  groups: MockAccountGroup[] = [];

  constructor({ users, groups }: { users: MockAccountUser[]; groups: MockAccountGroup[] }) {
    this.groups.push({
      id: 1,
      groupName: 'Default',
      roles: [],
      isDefault: true,
    });

    this.users.push(...users);
    this.groups.push(...groups);
  }

  getNextUserId() {
    return this.users.length === 0 ? 1 : this.users[this.users.length - 1].id + 1;
  }

  getNextGroupId() {
    return this.groups.length === 0 ? 1 : this.groups[this.groups.length - 1].id + 1;
  }

  getGroupsSummary(): AccountGroupSummaryData[] {
    return this.groups.map((group) => ({
      id: group.id,
      groupName: group.groupName,
      roles: group.roles,
      userCnt: this.users.filter((user) => user.groupId === group.id).length,
      isDefault: group.isDefault,
    }));
  }

  getGroupById(id: number): AccountGroupData {
    const foundGroup = this.groups.find((group) => group.id === id);
    if (!foundGroup) {
      throw new Error('there no id in group list!');
    }

    return {
      id: foundGroup.id,
      groupName: foundGroup.groupName,
      roles: foundGroup.roles,
      isDefault: foundGroup.isDefault,
      users: this.users
        .filter((user) => user.groupId === foundGroup.id)
        .map((newUser) => ({
          ...newUser,
          roles: foundGroup.roles,
        })),
    };
  }

  addGroup(reqGroup: ReqAccountGroupData) {
    const nextId = this.getNextGroupId();

    if (this.groups.find((g) => g.groupName === reqGroup.groupName)) {
      throw new Error('group name already exists!');
    }

    this.users.forEach((user) => {
      if (reqGroup.userIds.includes(user.id)) {
        user.groupId = nextId;
      }
    });

    this.groups.push({
      ...reqGroup,
      id: nextId,
      isDefault: false,
    });

    return {
      ...reqGroup,
      id: nextId,
    };
  }

  editGroup(reqId: number, reqGroup: ReqAccountGroupData) {
    const foundGroupIdx = this.groups.findIndex((g) => g.id === reqId);
    if (foundGroupIdx === -1) {
      throw new Error('there no id in group list!');
    }

    const foundSameName = this.groups.find((g) => g.groupName === reqGroup.groupName);
    if (foundSameName && foundSameName.id !== reqId) {
      throw new Error('group name already exists!');
    }

    this.users.forEach((user) => {
      if (reqGroup.userIds.includes(user.id)) {
        user.groupId = reqId;
      }
    });

    this.groups[foundGroupIdx] = {
      ...this.groups[foundGroupIdx],
      ...reqGroup,
    };

    return {
      ...reqGroup,
    };
  }

  deleteGroup(reqId: number) {
    const foundGroupIdx = this.groups.findIndex((g) => g.id === reqId);
    if (foundGroupIdx === -1) {
      throw new Error('there no id in group list!');
    }

    this.users.forEach((user) => {
      if (user.groupId === reqId) {
        user.groupId = 1;
      }
    });

    this.groups = this.groups.filter((g) => g.id !== reqId);

    return {
      id: reqId,
    };
  }

  getUsersSummary(): AccountUserSummaryData[] {
    return this.users.map(({ id, username, groupId, groupName, accessAt, updateAt }) => ({
      id,
      username,
      groupId,
      groupName,
      accessAt,
      updateAt,
      roles: this.groups.find((group) => group.id === groupId)?.roles || [],
    }));
  }

  getUserById(id: number): AccountUserData {
    const foundUser = this.users.find((user) => user.id === id);
    if (!foundUser) {
      throw new Error('there no id in user list!');
    }

    return {
      id: foundUser.id,
      username: foundUser.username,
      groupId: foundUser.groupId,
      groupName: foundUser.groupName,
      accessAt: foundUser.accessAt,
      updateAt: foundUser.updateAt,
      password: foundUser.password,
      roles: this.groups.find((group) => group.id === foundUser.groupId)?.roles || [],
    };
  }

  addUser(reqUser: ReqAccountUserData) {
    const nextId = this.getNextUserId();

    if (this.users.find((user) => user.username === reqUser.username)) {
      throw new Error('user name already exists!');
    }

    const foundUserIdx = this.users.findIndex((user) => user.id === reqUser.id);
    if (foundUserIdx === -1) {
      throw new Error('there no id in user list!');
    }

    const foundGroupIdx = this.groups.findIndex((group) => group.id === reqUser.groupId);
    if (foundGroupIdx === -1) {
      throw new Error('there no id in group list!');
    }

    this.users.push({
      id: nextId,
      username: reqUser.username,
      groupId: reqUser.groupId,
      groupName: this.groups[foundGroupIdx].groupName,
      accessAt: '',
      updateAt: '',
      password: reqUser.password,
    });

    return {
      id: nextId,
      username: reqUser.username,
      groupId: reqUser.groupId,
      groupName: foundGroupIdx,
    };
  }

  editUser(reqId: number, reqUser: ReqAccountUserData) {
    const foundUserIdx = this.users.findIndex((user) => user.id === reqId);
    if (foundUserIdx === -1) {
      throw new Error('there no id in user list!');
    }

    const foundSameName = this.users.find((user) => user.username === reqUser.username);
    if (foundSameName && foundSameName.id !== reqId) {
      throw new Error('username already exists!');
    }

    this.users[foundUserIdx] = {
      ...this.users[foundUserIdx],
      ...reqUser,
    };

    return {
      ...reqUser,
    };
  }

  deleteUser(reqId: number) {
    const foundUserIdx = this.users.findIndex((user) => user.id === reqId);
    if (foundUserIdx === -1) {
      throw new Error('there no id in user list!');
    }

    this.users = this.users.filter((user) => user.id !== reqId);

    return {
      id: reqId,
    };
  }
}

export const accountGroupMockData: MockAccountGroup[] = [
  {
    id: 2,
    groupName: 'group_02',
    isDefault: false,
    roles: ['ROLE_STATUS', 'ROLE_JOB', 'ROLE_CONFIGURE', 'ROLE_RULES', 'ROLE_ADDRESS', 'ROLE_ACCOUNT', 'ROLE_ERRORLOG'],
  },
  {
    id: 3,
    groupName: 'group_03',
    isDefault: false,
    roles: ['ROLE_STATUS'],
  },
  {
    id: 4,
    groupName: 'group_04',
    isDefault: false,
    roles: ['ROLE_STATUS', 'ROLE_JOB'],
  },
  {
    id: 5,
    groupName: 'group_05',
    isDefault: false,
    roles: ['ROLE_STATUS', 'ROLE_JOB', 'ROLE_ACCOUNT', 'ROLE_ERRORLOG'],
  },
];

export const accountUserMockData: MockAccountUser[] = [
  {
    id: 2,
    username: 'user_02',
    groupId: 1,
    groupName: 'Default',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 3,
    username: 'user_03',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 4,
    username: 'user_04',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 5,
    username: 'user_05',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 6,
    username: 'user_06',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 7,
    username: 'user_07',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 8,
    username: 'user_08',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 9,
    username: 'user_09',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 10,
    username: 'user_010',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 11,
    username: 'user_011',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 12,
    username: 'user_012',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 13,
    username: 'user_013',
    groupId: 3,
    groupName: 'group_03',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
  {
    id: 14,
    username: 'user_014',
    groupId: 1,
    groupName: 'Default',
    accessAt: '2021-01-01 00:00:00',
    updateAt: '2021-01-01 00:00:00',
    password: 'password',
  },
];
