import type { MahalanobisData, MahalanobisItemData, MahalanobisRegisterStatusData } from '@typesdef/mahalanobis';

export class MahalanobisSiteListMock {
  private siteList: MahalanobisRegisterStatusData = {
    registered: [
      { siteId: 1, id: 1, name: 'TEST_FAB1' },
      { siteId: 2, id: 2, name: 'TEST_FAB2' },
    ],
    unregistered: [{ siteId: 3, id: 3, name: 'TEST_FAB3' }],
  };

  getList() {
    return this.siteList;
  }

  getBySiteId(siteId: number) {
    const found = this.siteList.unregistered.find((item) => item.siteId === siteId);
    if (found === undefined) {
      throw new Error('there no siteId in unregistered list!');
    }
    return found;
  }

  register(siteId: number) {
    const foundIdx = this.siteList.unregistered.findIndex((item) => item.siteId === siteId);
    if (foundIdx === -1) {
      throw new Error('there no siteId in unregistered list!');
    }

    const foundItem = this.siteList.unregistered[foundIdx];
    this.siteList.registered.push(foundItem);
    this.siteList.unregistered.splice(foundIdx, 1);
  }

  unregister(siteId: number) {
    const foundIdx = this.siteList.registered.findIndex((item) => item.siteId === siteId);
    if (foundIdx === -1) {
      throw new Error('there no siteId in registered list!');
    }

    const foundItem = this.siteList.registered[foundIdx];
    this.siteList.unregistered.push(foundItem);
    this.siteList.registered.splice(foundIdx, 1);
  }
}

export class MahalanobisMock {
  private mahaList: MahalanobisData[] = [];
  private mahaItemList: MahalanobisItemData[] = [];

  constructor() {
    this.mahaList = [
      {
        id: 1,
        siteId: 1,
        companyFabName: 'TEST_FAB1',
        itemCnt: 1,
        date: '2023-03-27 00:00:00',
      },
      {
        id: 2,
        siteId: 2,
        companyFabName: 'TEST_FAB2',
        itemCnt: 1,
        date: '2023-03-27 00:00:00',
      },
    ];
    this.mahaItemList = [
      {
        id: 1,
        equipment_id: '1',
        equipment_name: 'MPA_1',
        table_name: 'chamber_detail_log',
        item: 'item1',
        colname1: 'common_after_cool_temperature_mv',
        colname2: 'common_evaporation_pressure_mv',
        covariance: -0.050106,
        mean1: 43.80855,
        mean2: 40.61116,
        variance1: 0.087437,
        variance2: 0.04922,
        memo: '',
      },
      {
        id: 2,
        equipment_id: '2',
        equipment_name: 'MPA_2',
        table_name: 'plate_monitor',
        item: 'item2',
        colname1: '14094',
        colname2: '14095',
        covariance: -0.557832,
        mean1: 47.32547,
        mean2: 41.35479,
        variance1: 0.087455,
        variance2: 0.04565,
        memo: '',
      },
      {
        id: 3,
        equipment_id: '3',
        equipment_name: 'MPA_3',
        table_name: 'adc_compensation',
        item: 'item3',
        colname1: '24018',
        colname2: '24019',
        covariance: -0.248796,
        mean1: 45.25478,
        mean2: 40.54789,
        variance1: 0.087832,
        variance2: 0.05578,
        memo: '',
      },
    ];
  }

  private getNextMahaId() {
    return this.mahaList.length === 0 ? 1 : this.mahaList[this.mahaList.length - 1].id + 1;
  }

  private getNextMahaItemtId() {
    return this.mahaItemList.length === 0 ? 1 : this.mahaItemList[this.mahaItemList.length - 1].id + 1;
  }

  getMahaList(): MahalanobisData[] {
    return this.mahaList;
  }

  getMahaById(id: number): MahalanobisData {
    const foundItem = this.mahaList.find((item) => item.id === id);
    if (foundItem === undefined) {
      throw new Error('there no id in maha list!');
    }

    return foundItem;
  }

  addMaha(maha: MahalanobisData) {
    this.mahaList.push({
      ...maha,
      id: this.getNextMahaId(),
    });
  }

  editMaha(id: number, maha: MahalanobisData) {
    const foundIdx = this.mahaList.findIndex((maha) => maha.id === id);

    if (foundIdx === -1) {
      throw new Error('there no id in maha list!');
    }

    this.mahaList[foundIdx] = {
      ...maha,
      id,
    };
  }

  deleteMaha(id: number) {
    const foundIdx = this.mahaList.findIndex((maha) => maha.id === id);

    if (foundIdx === -1) {
      throw new Error('there no id in maha list!');
    }

    this.mahaList.splice(foundIdx, 1);
  }

  getMahaItemList(): MahalanobisItemData[] {
    return this.mahaItemList;
  }

  getMahaItemById(id: number): MahalanobisItemData {
    const foundItem = this.mahaItemList.find((item) => item.id === id);
    if (foundItem === undefined) {
      throw new Error('there no id in maha item list!');
    }

    return foundItem;
  }

  addMahaItem(mahaItem: MahalanobisItemData) {
    this.mahaItemList.push({
      ...mahaItem,
      id: this.getNextMahaItemtId(),
    });
  }

  editMahaItem(id: number, mahaItem: MahalanobisItemData) {
    const foundIdx = this.mahaItemList.findIndex((maha) => maha.id === id);

    if (foundIdx === -1) {
      throw new Error('there no id in maha list!');
    }

    this.mahaItemList[foundIdx] = {
      ...mahaItem,
      id,
    };
  }

  deleteMahaItem(id: number) {
    const foundIdx = this.mahaItemList.findIndex((maha) => maha.id === id);

    if (foundIdx === -1) {
      throw new Error('there no id in maha list!');
    }

    this.mahaItemList.splice(foundIdx, 1);
  }
}
