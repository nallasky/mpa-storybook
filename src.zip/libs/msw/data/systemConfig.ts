import type { ReqSystemConfigRetention, SystemConfigFtp } from '@typesdef/systemConfig';

export const mockSystemConfigFTPData: SystemConfigFtp[] = [
  {
    id: 1,
    name: 'FTP_TEST_1',
    type: 'FTP',
    remoteHost: '10.1.31.143',
    port: 22,
    username: 'root',
    password: 'password',
    recallRoot: '/home/test',
    logServerRoot: '/home/test2',
    logServerTags: ['test', 'test2'],
  },
  {
    id: 2,
    name: 'SFTP_TEST_1',
    type: 'SFTP',
    remoteHost: '10.1.31.143',
    port: 22,
    username: 'root',
    password: 'password',
    recallRoot: '/home/test',
    logServerRoot: '/home/test2',
    logServerTags: ['test', 'test2'],
  },
];

export class MockSystemConfigFTP {
  data: SystemConfigFtp[] = [];

  constructor(data: SystemConfigFtp[] = []) {
    this.data = [...data];
  }

  getNextId() {
    return this.data.length === 0 ? 1 : this.data[this.data.length - 1].id + 1;
  }

  getSummaryFtpList() {
    console.log(this.data);
    return this.data.map((ftp) => ({
      id: ftp.id,
      name: ftp.name,
      type: ftp.type,
      remoteHost: ftp.remoteHost,
      port: ftp.port,
    }));
  }

  getFtpById(id: number) {
    const ftp = this.data.find((ftp) => ftp.id === id);
    if (ftp === undefined) {
      throw new Error('there no id in ftp list!');
    }
    return ftp;
  }

  addFtp(ftp: SystemConfigFtp) {
    const nextId = this.getNextId();
    this.data.push({
      ...ftp,
      id: nextId,
    });

    return {
      ...ftp,
      id: nextId,
    };
  }

  editFtp(id: number, ftp: SystemConfigFtp) {
    const idx = this.data.findIndex((ftp) => ftp.id === id);
    if (idx === -1) {
      throw new Error('there no id in ftp list!');
    }

    this.data[idx] = {
      ...ftp,
      id,
    };

    return {
      ...ftp,
      id,
    };
  }

  delete(id: number) {
    const ftp = this.data.find((ftp) => ftp.id === id);
    if (ftp === undefined) {
      throw new Error('there no id in ftp list!');
    }

    this.data = this.data.filter((ftp) => ftp.id !== id);

    return {
      ...ftp,
      id,
    };
  }
}

export class MockSystemConfigRetention {
  data: ReqSystemConfigRetention = {
    buildHistory: 30,
  };

  getRetention() {
    return this.data;
  }

  setRetention(retention: ReqSystemConfigRetention) {
    this.data = retention;
  }
}
