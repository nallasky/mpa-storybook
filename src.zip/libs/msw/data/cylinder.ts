import { DefineParamData, MutateDefineParamData } from '@typesdef/defineParam';

export class MockCylinderParam {
  list: DefineParamData[] = [
    {
      id: 1,
      setcode: '0F750',
      name: 'ST_TUNE_L',
    },
    {
      id: 2,
      setcode: '0F753',
      name: 'ST_TUNE_R',
    },
  ];

  getNextId() {
    return this.list.length === 0 ? 1 : this.list[this.list.length - 1].id + 1;
  }

  getList() {
    return this.list;
  }

  getItem(id: number) {
    return this.list.find((item) => item.id === id);
  }

  addItem(data: MutateDefineParamData['data']) {
    this.list.push({
      id: this.getNextId(),
      ...data,
    });
  }

  editItem(id: number, data: MutateDefineParamData['data']) {
    const foundIndex = this.list.findIndex((item) => item.id === id);

    if (foundIndex !== -1) {
      this.list[foundIndex] = {
        id: this.list[foundIndex].id,
        ...data,
      };
    }
  }

  deleteItem(id: number) {
    this.list = this.list.filter((item) => item.id !== id);
  }
}
