export function regExpEmail() {
  return new RegExp(
    /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/,
    'g',
  );
}

export function regExpName() {
  // return new RegExp(/^([a-zA-Z0-9])([a-zA-Z0-9._-]{0,28})([a-zA-Z0-9]$)/, 'g');
  return new RegExp(/^([a-zA-Z0-9])([a-zA-Z0-9._-]{0,28})([a-zA-Z0-9]$)/, 'gi');
}

export function regExpIpAddress() {
  return new RegExp('^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?).){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$');
}

export function regExpIpAddressWithLocalhost() {
  return new RegExp(
    '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?).){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$|localhost',
  );
}

export function validateEmail(email: string): boolean {
  if (regExpEmail().test(email)) return true;

  return false;
}

export const regExpVariable = new RegExp(/^[a-zA-Z_$]+([\w_$]*)$/);
export const regExpLambda = new RegExp(/^((?!").)*$/);

export const hasValue = (value: any): boolean => Boolean(value); // 0 is false
export const hasArrayWithData = (value: any): boolean => Array.isArray(value) && value.length > 0;

export const regExpTimestamp = new RegExp(
  /^([12]\d\d\d)(0[1-9]|1[0-2])(0[1-9]|1\d|2\d|3[01])(\s(0\d|1\d|2[0-3])([0-5]\d)([0-5])\d)$|^(0\d|1\d|2[0-3]):[0-5]\d:[0-5]\d(:\d{3,6})?$|^(([12]\d\d\d)[-/])?((0[1-9]|1[0-2])[-/])(0[1-9]|1\d|2\d|3[01])(\s(0\d|1\d|2[0-3]):?[0-5]\d((:?[0-5])\d)?([:.]?\d{3,6})?)?$/,
);

export const regExpFloat = new RegExp(/^[-+]?([0-9]\d*)[.]([0-9]\d*)$/);

export const regExpSpecialCharacter = new RegExp(/[`~!@#$%^&*()|+\-=?;:'"<>.{}[\]\\/ ]/, 'g');

export function validateDBname(name: string) {
  return /^[a-z_][a-z0-9_]*$/.test(name);
}

export const regExpTime = new RegExp(/^([0-1]?[0-9]|2[0-3]):([0-5]?[0-9]|2[0-5]):([0-5]?[0-9]|2[0-5])$/);

export const checkIsEmpty = (value: any): boolean => {
  if (value === null || value === undefined) {
    return true;
  }

  if (typeof value === 'string') {
    return value.length === 0;
  } else if (typeof value === 'number' || typeof value === 'bigint') {
    return false;
  } else if (typeof value === 'boolean') {
    return false;
  } else if (typeof value === 'object') {
    if (Array.isArray(value)) {
      return value.length === 0;
    } else {
      return Object.keys(value).length === 0;
    }
  }

  return Boolean(value);
};

export const regExpFilePath = new RegExp(/^(\/[a-zA-Z0-9_\\-]+)+$/);
