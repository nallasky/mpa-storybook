import { ACCOUNT_ROLE } from '@constants/account';
import type { AccountUserRoleBoolean, AccountUserRoleType } from '@typesdef/account';

export function getLoginUserRoleBoolean(roles: AccountUserRoleType[]): AccountUserRoleBoolean {
  return {
    ROLE_STATUS: true,
    ROLE_JOB: roles.includes(ACCOUNT_ROLE.ROLE_JOB.KEY),
    ROLE_CONFIGURE: roles.includes(ACCOUNT_ROLE.ROLE_CONFIGURE.KEY),
    ROLE_RULES: roles.includes(ACCOUNT_ROLE.ROLE_RULES.KEY),
    ROLE_ADDRESS: roles.includes(ACCOUNT_ROLE.ROLE_ADDRESS.KEY),
    ROLE_ACCOUNT: roles.includes(ACCOUNT_ROLE.ROLE_ACCOUNT.KEY),
    ROLE_ERRORLOG: roles.includes(ACCOUNT_ROLE.ROLE_ERRORLOG.KEY),
  };
}

export function hasLoginUserThisRole(role: AccountUserRoleType, roles: AccountUserRoleType[]): boolean {
  return roles.includes(role);
}

export function getRoleArrFromRoleObj(roles: AccountUserRoleBoolean): AccountUserRoleType[] {
  const convertRoles: AccountUserRoleType[] = [];

  if (roles.ROLE_JOB) convertRoles.push(ACCOUNT_ROLE.ROLE_JOB.KEY);
  if (roles.ROLE_CONFIGURE) convertRoles.push(ACCOUNT_ROLE.ROLE_CONFIGURE.KEY);
  if (roles.ROLE_RULES) convertRoles.push(ACCOUNT_ROLE.ROLE_RULES.KEY);
  if (roles.ROLE_ADDRESS) convertRoles.push(ACCOUNT_ROLE.ROLE_ADDRESS.KEY);
  if (roles.ROLE_ACCOUNT) convertRoles.push(ACCOUNT_ROLE.ROLE_ACCOUNT.KEY);
  if (roles.ROLE_ERRORLOG) convertRoles.push(ACCOUNT_ROLE.ROLE_ERRORLOG.KEY);

  return convertRoles;
}

export const getUsernameRegex = () => /^([a-zA-Z0-9])([a-zA-Z0-9._-]{1,28})([a-zA-Z0-9]$)/g;
export const getPasswordRegex = () => /^[0-9a-zA-Z]{6,30}$/g;
export const getGroupRegex = () => /^([a-zA-Z0-9])([a-zA-Z0-9._-]{1,18})([a-zA-Z0-9]$)/g;
