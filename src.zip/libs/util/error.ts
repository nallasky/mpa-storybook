import { FormErrorStatus } from '@typesdef/common';
import { Rule, RuleObject } from 'antd/es/form';
import { validateDBname } from './validation';

export const initialFormError: FormErrorStatus = { help: '', status: '' };

type TypeErrorStatusRule = 'initial' | 'duplicated' | 'empty' | 'emptySelect' | 'dbNaming' | 'max' | 'min' | 'custom';

type TypeConvertRuleParam = RuleObject & {
  rule: TypeErrorStatusRule;
  name?: string;
};

export const getFormErrorStatus = ({ ...params }: TypeConvertRuleParam): FormErrorStatus => {
  const { name, rule, message } = params;
  const getMessage = (value = '') => {
    if (message !== undefined && typeof message !== 'string') {
      throw new Error('message is not string!');
    }

    return message ? message : value;
  };

  switch (rule) {
    case 'duplicated':
      return {
        help: getMessage(name ? `Duplicated ${name}!` : `Duplicated value!`),
        status: 'error',
      };
    case 'empty':
      return {
        help: getMessage(name ? `Please input a ${name}!` : `Please input a value!`),
        status: 'error',
      };
    case 'emptySelect':
      return {
        help: getMessage(name ? `Please select a ${name}!` : `Please select a value!`),
        status: 'error',
      };
    case 'dbNaming':
      return {
        help: getMessage('Begin without digits, lowercase letters, digits and underscores only!'),
        status: 'error',
      };
    case 'max':
      if (params.max === undefined) {
        throw new Error('max is undefined!');
      }
      return {
        help: getMessage(
          name
            ? `${name[0].toUpperCase() + name.slice(1)} be within ${params.max} characters!`
            : `Must be within ${params.max} characters!`,
        ),
        status: 'error',
      };

    case 'min':
      if (params.min === undefined) {
        throw new Error('min is undefined!');
      }
      return {
        help: getMessage(
          name
            ? `${name[0].toUpperCase() + name.slice(1)} must be at least ${params.min}!`
            : `Must be added at least ${params.min}!`,
        ),
        status: 'error',
      };

    case 'custom':
      if (message === undefined) {
        throw new Error('message is undefined!');
      }
      return {
        help: getMessage(),
        status: 'error',
      };
    case 'initial':
    default:
      return {
        help: '',
        status: '',
      };
  }
};

export const getConvertRuleItem = ({ ...params }: TypeConvertRuleParam): Rule => {
  const { rule, ...rest } = params;
  const message = rest.message ?? getFormErrorStatus({ ...params }).help;

  switch (rule) {
    case 'duplicated': {
      if (rest.validator === undefined) {
        throw new Error('duplicated validator is undefined!');
      }
      return {
        ...rest,
        message,
      };
    }

    case 'empty':
    case 'emptySelect':
      return {
        ...rest,
        required: true,
        message,
      };

    case 'dbNaming':
      return {
        ...rest,
        message,
        validator: rest.validator ?? dbNameValidator,
      };

    case 'max': {
      if (rest.max === undefined && rest.validator === undefined) {
        throw new Error('max requires either max or validator.');
      }
      return {
        ...rest,
        message,
      };
    }

    case 'min': {
      if (rest.min === undefined && rest.validator === undefined) {
        throw new Error('max requires either max or validator.');
      }
      return {
        ...rest,
        message,
      };
    }

    case 'custom':
      return {
        ...rest,
      };

    default:
      throw new Error('[getConvertInputRule] rule is undefined!');
  }
};

export const dbNameValidator: NonNullable<RuleObject['validator']> = (rule, value) =>
  new Promise((resolve, reject) => {
    if (!value) {
      return resolve(true);
    }

    return validateDBname(value) ? resolve(true) : reject(getFormErrorStatus({ rule: 'dbNaming' }).help);
  });
