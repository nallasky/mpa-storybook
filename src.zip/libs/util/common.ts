export const tableScrollTo = ({
  ref,
  rowIndex,
  colIndex,
  click = false,
}: {
  ref: HTMLDivElement;
  rowIndex?: number;
  colIndex?: number;
  click?: boolean;
}) => {
  if (!ref) {
    throw new Error('ref is null or undefined!');
  }

  const tableNode =
    ref.querySelector('.ant-table-body') ?? // with sticky
    ref.querySelector('.ant-table-content'); // without sticky

  if (tableNode) {
    const tableRowArr = tableNode.querySelectorAll('tr');
    if (tableRowArr.length > 0) {
      const newRowIndex = rowIndex === undefined ? tableRowArr.length - 1 : rowIndex + 1;
      const foundRow = tableRowArr[newRowIndex];
      if (!foundRow) {
        throw new Error(`row[${newRowIndex}] not found!`);
      }

      const tableDataArr = foundRow.querySelectorAll('td');
      if (tableDataArr.length > 0) {
        const newColIndex = colIndex === undefined ? 0 : colIndex;
        const foundCell = tableDataArr[newColIndex];
        console.log({ foundCell });
        if (!foundCell) {
          throw new Error(`col[${colIndex}] not found!`);
        }

        foundCell.scrollIntoView({ behavior: 'smooth' });
        if (click) {
          foundCell.click();
        }
      }
    }
  }
};
