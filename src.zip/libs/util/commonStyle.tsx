import styled from '@emotion/styled';

export const TableColumnTitle = styled.div`
  font-weight: 700;
`;
