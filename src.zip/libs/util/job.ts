import {
  RemoteJobFTP,
  RemoteJobFTPWithLabel,
  RemoteJobImportData,
  RemoteJobImportDataStep,
  RemoteJobStepDetailState,
} from '@typesdef/Job';
import { v4 as uuidv4 } from 'uuid';

export const initialJobErrorNotice: RemoteJobStepDetailState = {
  uuid: uuidv4(),
  stepId: null,
  stepName: 'error notice',
  stepType: 'notice',
  enable: true,
  mode: null,
  time: [],
  cycle: null,
  period: null,
  preStep: null,
  nextStep: null,
  isEmail: true,
  customEmails: [],
  emailBook: [],
  groupBook: [],
  subject: null,
  body: null,
  before: null,
  selectJudgeRules: [],
  description: null,
  scriptType: null,
  script: null,
  fileIndices: [],
  planIds: [],
  directory: [],
  retentionPeriod: null,
  ftps: [],
  isFtp: false,
};

export const convertFromFtpToFtpLabel = (ftp: RemoteJobFTP): RemoteJobFTPWithLabel => ({
  id: ftp.id,
  name: ftp.name,
  type: ftp.type,
  key: `${ftp.id}`,
  label: `[${ftp.type}] ${ftp.name}`,
  value: ftp.id,
});

export const convertFromFtpLabelToFtp = (ftp: RemoteJobFTPWithLabel): RemoteJobFTP => ({
  id: ftp.id,
  name: ftp.name,
  type: ftp.type,
});

export const validateJobStepFromServer = (step: RemoteJobStepDetailState): RemoteJobStepDetailState => ({
  uuid: step.uuid ?? null,
  stepId: step.stepId ?? null,
  stepName: step.stepName ?? null,
  stepType: step.stepType ?? 'collect',
  enable: step.enable ?? false,
  mode: step.mode ?? null,
  time: step.time ?? [],
  cycle: step.cycle ?? null,
  period: step.period ?? null,
  preStep: step.preStep ?? null,
  nextStep: step.nextStep ?? null,
  isEmail: step.isEmail,
  customEmails: step.customEmails ?? [],
  emailBook: step.emailBook ?? [],
  groupBook: step.groupBook ?? [],
  subject: step.subject ?? null,
  body: step.body ?? null,
  before: step.before ?? null,
  selectJudgeRules: step.selectJudgeRules ?? [],
  description: step.description ?? null,
  scriptType: step.scriptType ?? null,
  script: step.script ?? null,
  fileIndices: step.fileIndices ?? [],
  planIds: step.planIds ?? [],
  directory: step.directory ?? [],
  retentionPeriod: step.retentionPeriod ?? null,
  isFtp: step.isFtp ?? false,
  ftps: step.ftps ?? [],
});

export const validateImportJobStep = (step: RemoteJobImportDataStep): RemoteJobImportDataStep => ({
  uuid: step.uuid ?? null,
  stepId: step.stepId ?? null,
  stepName: step.stepName ?? null,
  stepType: step.stepType ?? null,
  enable: step.enable,
  mode: step.mode ?? null,
  time: step.time ?? [],
  cycle: step.cycle ?? null,
  period: step.period ?? null,
  preStep: step.preStep ?? null,
  nextStep: step.nextStep ?? null,
  isEmail: step.isEmail ?? false,
  customEmails: step.customEmails ?? [],
  emailBookIds: step.emailBookIds ?? [],
  groupBookIds: step.groupBookIds ?? [],
  subject: step.subject ?? null,
  body: step.body ?? null,
  before: step.before ?? null,
  selectJudgeRuleIds: step.selectJudgeRuleIds ?? [],
  description: step.description ?? null,
  scriptType: step.scriptType ?? null,
  script: step.script ?? null,
  fileIndices: step.fileIndices ?? [],
  planIds: step.planIds ?? [],
  retentionPeriod: step.retentionPeriod ?? null,
  isFtp: step.isFtp ?? false,
  ftps: step.ftps ?? [],
  ftpNames: step.ftpNames ?? [],
  planNames: step.planNames ?? [],
});

export const validateImportJob = (importData: RemoteJobImportData): RemoteJobImportData => {
  return {
    ...importData,
    jobs: importData.jobs.map((job) => {
      return {
        ...job,
        steps: job.steps.map(validateImportJobStep),
      };
    }),
  };
};
