import { ReqQuerySortParam } from '@typesdef/common';
import { ConvertRuleSelectItem } from '@typesdef/convertRules';
import { createSearchParams } from 'react-router-dom';
import { regExpFloat, regExpSpecialCharacter, regExpTime, regExpTimestamp } from './validation';

export function toCamelCase(str: string): string {
  return str.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g, (m, chr) => chr.toUpperCase());
}

export function secondToTime(second: number) {
  let time = 0;
  let unit = 'day';

  const minutes = Math.floor(second / 60);
  const hours = Math.floor(second / (60 * 60));
  const days = Math.floor(second / (60 * 60 * 24));

  if (days > 0) {
    time = days;
    unit = 'day';
  } else if (hours > 0) {
    time = hours;
    unit = 'hour';
  } else {
    time = minutes;
    unit = 'minute';
  }

  return {
    time,
    unit,
  };
}

export function timeToSecond(prevPeriod: { unit: string; time: number }): number {
  if (prevPeriod.unit === 'day') {
    return prevPeriod.time * 60 * 60 * 24;
  } else if (prevPeriod.unit === 'hour') {
    return prevPeriod.time * 60 * 60;
  } else {
    return prevPeriod.time * 60;
  }
}

export function convDateformat(value: string | undefined | null): string {
  if (!value) return '-';
  const year = value.substr(0, 4);
  const month = value.substr(4, 2);
  const day = value.substr(6, 2);
  const hour = value.substr(8, 2);
  const minute = value.substr(10, 2);
  return `${year}-${month}-${day} ${hour}:${minute}`;
}

export function addIndexToArrayObject<T>(data: T[]) {
  return data.map((item, index) => ({
    ...item,
    index: index + 1,
  }));
}

export function getPixelPercent(total: number, value: number, digits = 1) {
  return `${((value / total) * 100).toFixed(digits)}%`;
}

export function convertArrToRangeString(value: string | string[] | number | number[] | boolean) {
  let convert = value;
  if (Array.isArray(value)) {
    const [from, to] = value;
    if (to) {
      convert = `${from}-${to}`;
    } else {
      convert = `${from}`;
    }
  }

  return `${convert}`;
}

export function getQueriesParam({ query, pagination, search, filter }: ReqQuerySortParam) {
  if (!query && !pagination && !search && !filter) {
    return '';
  }

  const params: [string, string][] = [];

  if (query && Object.keys(query).length > 0) {
    params.push(...Object.entries(query).map((item): [string, string] => [item[0], `${item[1]}`]));
  }

  if (pagination) {
    params.push(['page', `${pagination.page}`]);
    params.push(['size', `${pagination.size}`]);
    if (pagination.sort && Object.keys(pagination.sort).length > 0) {
      params.push(
        ...Object.entries(pagination.sort).map(([key, value]): [string, string] => ['sort', `${key},${value}`]),
      );
    }
  }

  if (search && Object.keys(search).length > 0) {
    params.push(
      ...Object.entries(search).map(([key, value]): [string, string] => [
        'search',
        `${key},${Array.isArray(value) ? value.join(',') : value}`,
      ]),
    );
  }

  if (filter && Object.keys(filter).length > 0) {
    params.push(
      ...Object.entries(filter).map(([key, value]): [string, string] => [
        'filter',
        `${key},${Array.isArray(value) ? value.join(',') : value}`,
      ]),
    );
  }

  const queryString = createSearchParams(params).toString();

  return queryString ? '?' + queryString : '';
}

//["integer","float","text","varchar(10)","varchar(30)","varchar(50)","timestamp","time","boolean"]
export const getConvertDataType = (
  value: string | null,
): 'timestamp' | 'time' | 'float' | 'integer' | 'text' | 'boolean' | null => {
  // null
  if (value === undefined || value === null || value === '') {
    return null;
  }

  // boolean
  if (value.toLocaleLowerCase() === 'true' || value.toLocaleLowerCase() === 'false') {
    return 'boolean';
  }

  // date
  if (regExpTimestamp.test(value)) {
    return 'timestamp';
  }

  //time
  if (regExpTime.test(value)) {
    return 'time';
  }

  // number
  if (!Number.isNaN(+value)) {
    if (regExpFloat.test(value)) {
      return 'float';
    } else {
      return 'integer';
    }
  }

  // text
  return 'text';
};

export const getConvertOutputColumn = (
  value: string | null,
  type: 'timestamp' | 'time' | 'float' | 'integer' | 'text' | 'boolean' | null,
) => {
  if (value === undefined || value === null || value === '') {
    return null;
  }

  switch (type) {
    case 'integer':
    case 'float': {
      const conv = value.replaceAll('.', '_').trim();
      return conv.charAt(0) === '+' || conv.charAt(0) === '-' ? '_' + conv.substring(1) : '_' + conv;
    }
    case 'timestamp':
      return 'log_time';
    case 'time':
      return 'time';
    case 'text': {
      const conv = value.replaceAll(regExpSpecialCharacter, '').toLowerCase();
      if (conv === '') {
        return conv;
      } else {
        return Number.isNaN(+conv.charAt(0)) ? conv : '_' + conv;
      }
    }
    case 'boolean':
      return 'boolean';
    default:
      return null;
  }
};

export const convertParsingData = (value: string | null) => {
  const name = value ? value.trim().replaceAll('#', '') : null;
  const data_type = getConvertDataType(name);
  const output_column = getConvertOutputColumn(name, data_type);

  return {
    name,
    output_column,
    data_type,
    def_val: data_type === 'timestamp' ? 'now' : null,
    def_type: data_type === 'timestamp' ? 'now' : null,
  };
};

export const convertDuplicateData = (data: ConvertRuleSelectItem[]) => {
  const duplicateName: Record<string, number> = {};
  const duplicateOutCol: Record<string, number> = {};

  return data.reduce((acc, cur) => {
    const name = cur.name ? cur.name : null;
    const outCol = cur.output_column ? cur.output_column : null;

    const nameCount = name !== null && name in duplicateName ? duplicateName[name] : 0;
    const outColCount = outCol !== null && outCol in duplicateOutCol ? duplicateOutCol[outCol] : 0;

    if (name !== null) {
      cur['name'] = nameCount > 0 ? `${name}_${duplicateName[name]}` : name;
      duplicateName[name] = nameCount + 1;
    }
    if (outCol !== null) {
      cur['output_column'] = outColCount > 0 ? `${outCol}_${duplicateOutCol[outCol]}` : outCol;
      duplicateOutCol[outCol] = outColCount + 1;
    }
    acc.push(cur);

    return acc;
  }, [] as ConvertRuleSelectItem[]);
};

export function getPascalCaseName(data: string[]) {
  return data
    .map((item) => {
      const trimmed = item.trim();
      return trimmed.charAt(0).toUpperCase() + trimmed.slice(1).toLowerCase();
    })
    .join(' ');
}

export const isDuplicateItemFormList = <T>({
  key,
  curName,
  oriName = '',
  content,
}: {
  key: keyof T;
  curName: string;
  oriName?: string;
  content: T[];
}) => {
  if (curName && Array.isArray(content) && content.length > 0) {
    if (!oriName && content.some((item) => `${item[key] ?? ''}`.toLowerCase() === curName.toLowerCase())) {
      return true;
    } else if (
      oriName &&
      curName.toLowerCase() !== oriName.toLowerCase() &&
      content.some((item) => `${item[key] ?? ''}`.toLowerCase() === curName.toLowerCase())
    ) {
      return true;
    }
  }

  return false;
};
