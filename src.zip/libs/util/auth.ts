import type { LicenseStatusType } from '@typesdef/auth';

export const hasValidLicense = (status: LicenseStatusType) => status === 'activated';
