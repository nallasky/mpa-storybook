export const variantsAxisForX = (x = 20) => ({
  enter: (direction: number) => {
    return {
      x: direction > 0 ? x : -x,
      opacity: 0,
    };
  },
  center: {
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => {
    return {
      x: direction < 0 ? x : -x,
      opacity: 0,
    };
  },
});

export const stepTransition = {
  x: { type: 'spring', stiffness: 300, damping: 30 },
  opacity: { duration: 0.3 },
};
