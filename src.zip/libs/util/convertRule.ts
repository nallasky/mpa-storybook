import { ConvertRuleItem, ConvertRuleItemWithKey } from '@typesdef/convertRules';

export function formatConvertRuleItemWithKey({
  rule,
  key,
  row,
}: {
  rule: ConvertRuleItem[];
  key: number;
  row?: number;
}): ConvertRuleItemWithKey {
  return {
    key: key,
    rule: rule.map((ruleItem, index) => formatConvertRuleItem({ rule: ruleItem, index, row })),
  };
}

export function formatConvertRuleItem({ rule, index, row }: { rule: ConvertRuleItem; index?: number; row?: number }) {
  return {
    index: index !== undefined ? index + 1 : null,
    id: rule.id ?? null,
    type: rule.type ?? null,
    row_index: row ? row : null,
    col_index: index !== undefined ? index + 1 : null,
    data: rule.data ?? null,
    name: rule.name ?? null,
    output_column: rule.output_column ?? null,
    data_type: rule.data_type ?? null,
    def_val: rule.def_val ?? null,
    def_type: rule.def_type ?? null,
    coef: rule.coef || null,
    unit: rule.unit ?? null,
    regex_prefix: rule.regex_prefix ?? null,
    regex: rule.regex ?? null,
    re_group: rule.re_group ?? null,
    is_new: rule.is_new ?? null,
    start_state: rule.start_state ?? null,
    end_state: rule.end_state ?? null,
  };
}
