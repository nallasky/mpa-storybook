import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { notification } from 'antd';
import { IconType } from 'antd/es/notification';
import { AxiosError } from 'axios';
import dayjs from 'dayjs';
import React, { Fragment } from 'react';
import { v4 as uuidv4 } from 'uuid';

const DivDate = styled.div`
  text-align: right;
  font-size: 13px;
  color: gray;
`;

export interface OpenNotification {
  (type: IconType, message: React.ReactNode, description: React.ReactNode, error?: AxiosError): void;
}

export const openNotification: OpenNotification = (type, message, description, error) => {
  const status = error?.response?.status;
  const statusText = status ? convertStatusCode(status) : null;
  const reason = (error as AxiosError<{ message: string }>)?.response?.data?.message ?? '';

  let convDescription = description;

  // Service Busy
  if (status === 503) {
    convDescription = 'The server is busy. Please try again later.';
  }

  const key = uuidv4();

  notification[type]({
    message: message,
    key,
    onClick: () => notification.close(key),
    description: (
      <Fragment>
        <div css={style}>
          {Array.isArray(convDescription)
            ? convDescription.map((item, idx) => <div key={idx}>{item}</div>)
            : convDescription}
          {reason && (
            <Fragment>
              <p />
              <div>{`Reason : ${reason}`}</div>
            </Fragment>
          )}
          {status && statusText && <div>{`Status : ${statusText}(${status})`}</div>}
          {status && !statusText && <div>{`Status : ${status}`}</div>}
        </div>
        <p />
        <DivDate>{dayjs().add(1, 'day').format('YYYY-MM-DD HH:mm:ss')}</DivDate>
      </Fragment>
    ),
    duration: type === 'error' ? 4.5 : 3,
  });
};

const style = css`
  display: flex;
  flex-direction: column;
`;

const convertStatusCode = (code: number) => {
  switch (code) {
    case 200:
      return 'OK';
    case 201:
      return 'Created';
    case 202:
      return 'Accepted';
    case 204:
      return 'No Content';
    case 400:
      return 'Bad Request';
    case 401:
      return 'Unauthorized';
    case 403:
      return 'Forbidden';
    case 404:
      return 'Not Found';
    case 405:
      return 'Method Not Allowd';
    case 409:
      return 'Conflict';
    case 429:
      return 'Too many Requests';
    case 500:
      return 'Internal Server Error';
    case 502:
      return 'Bad Gateway';
    case 503:
      return 'Service Unavailable';
    case 504:
      return 'Gateway Timeout';
    default:
      break;
  }
  return null;
};
