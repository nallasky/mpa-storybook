import type { ResUploadMahalanobisData } from '@typesdef/mahalanobis';

export function initializeUploadedMahalanobisData(list: ResUploadMahalanobisData[]): ResUploadMahalanobisData[] {
  return list.map((value) => ({
    ...value,
    id: 0,
    equipment_id: '',
    equipment_name: '',
  }));
}
