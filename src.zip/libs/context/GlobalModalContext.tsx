import { GlobalModalDispatchContextProps, GlobalModalProps } from '@typesdef/modal';
import { createContext } from 'react';

export const GlobalModalDispatchContext = createContext<GlobalModalDispatchContextProps>({
  open: () => {},
  close: () => {},
});

export const GlobalModalStateContext = createContext(new Map<string, GlobalModalProps>());
