import React, { useCallback, useContext, useReducer } from 'react';
import {
  UploadFileAction,
  UploadFileDispatchContext,
  UploadFileState,
  UploadFileStateContext,
} from './UploadFileContext';

const UploadFileProvider = ({ children }: { children: React.ReactNode }) => {
  const [state, dispatch] = useReducer(uploadReducer, {
    files: [],
    resFiles: [],
  });

  return (
    <UploadFileStateContext.Provider value={state}>
      <UploadFileDispatchContext.Provider value={dispatch}>{children}</UploadFileDispatchContext.Provider>
    </UploadFileStateContext.Provider>
  );
};

function uploadReducer(state: UploadFileState, action: UploadFileAction): UploadFileState {
  switch (action.type) {
    case 'SET_FILES':
      return {
        ...state,
        files: action.payload,
      };

    case 'SET_RES_FILES':
      return {
        ...state,
        resFiles: action.payload,
      };
    default:
      throw new Error('Unhandled uploadReducer action');
  }
}

export const useFileUploadContext = () => {
  const state = useContext(UploadFileStateContext);
  const dispatch = useContext(UploadFileDispatchContext);

  if (!state) throw new Error('Cannot find UploadFileProvider');
  if (!dispatch) throw new Error('Cannot find UploadFileDispatchContext');

  const setFiles = useCallback(
    (files: UploadFileState['files']) => {
      dispatch({ type: 'SET_FILES', payload: files });
    },
    [dispatch],
  );

  const setResFiles = useCallback(
    (resFiles: UploadFileState['resFiles']) => {
      dispatch({ type: 'SET_RES_FILES', payload: resFiles });
    },
    [dispatch],
  );

  return {
    files: state.files,
    resFiles: state.resFiles,
    setFiles,
    setResFiles,
  };
};

export default UploadFileProvider;
