import { ResUploadMahalanobisData } from '@typesdef/mahalanobis';
import produce from 'immer';
import React, { useCallback, useContext, useMemo, useState } from 'react';
import { MahalanobisImportDispatchContext, MahalanobisImportStateContext } from './MahalanobisImportContext';

const MahalanobisImportProvider = ({
  pathId,
  data,
  children,
}: {
  pathId: number;
  data: ResUploadMahalanobisData[];
  children: React.ReactNode;
}) => {
  const [itemIndex, setItemState] = useState<number | null>(null);
  const [itemData, setItemData] = useState<ResUploadMahalanobisData[]>(data);

  const errorIndexList: number[] = useMemo(() => {
    const initialArr: number[] = [];
    return itemData.reduce((acc, cur, index) => {
      if (!cur.equipment_name) {
        acc.push(index);
      }
      return acc;
    }, initialArr);
  }, [itemData]);

  const setItemIndex = useCallback((index: number | null) => {
    setItemState(index);
  }, []);

  const curItem = useMemo(
    () => (itemIndex !== null && itemIndex !== undefined ? itemData[itemIndex] : null),
    [itemIndex, itemData],
  );

  const setEquipment = useCallback(
    ({ itemIndex, equipmentId, equipmentName }: { itemIndex: number; equipmentId: string; equipmentName: string }) => {
      console.log({ itemIndex, equipmentId, equipmentName });
      setItemData((prev) =>
        produce(prev, (draft) => {
          if (draft[itemIndex]) {
            draft[itemIndex].equipment_id = equipmentId;
            draft[itemIndex].equipment_name = equipmentName;
          }
        }),
      );
    },
    [],
  );

  const dispatch = useMemo(
    () => ({
      setItemIndex,
      setEquipment,
    }),
    [setItemIndex, setEquipment],
  );

  return (
    <MahalanobisImportStateContext.Provider
      value={{
        pathId,
        originData: data,
        itemData,
        itemIndex,
        curItem,
        errorIndexList,
      }}
    >
      <MahalanobisImportDispatchContext.Provider value={dispatch}>{children}</MahalanobisImportDispatchContext.Provider>
    </MahalanobisImportStateContext.Provider>
  );
};

export const useMahalanobisImportContext = () => {
  const state = useContext(MahalanobisImportStateContext);
  const dispatch = useContext(MahalanobisImportDispatchContext);

  if (!state) throw new Error('Cannot find MahalanobisImportStateContext');
  if (!dispatch) throw new Error('Cannot find MahalanobisImportDispatchContext');

  return {
    pathId: state.pathId,
    originData: state.originData,
    itemData: state.itemData,
    itemIndex: state.itemIndex,
    curItem: state.curItem,
    errorIndexList: state.errorIndexList,
    setItemIndex: dispatch.setItemIndex,
    setEquipment: dispatch.setEquipment,
  };
};

export default MahalanobisImportProvider;
