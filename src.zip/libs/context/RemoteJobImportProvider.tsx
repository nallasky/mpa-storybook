import { RemoteJobFTP, RemoteJobImportData } from '@typesdef/Job';
import produce from 'immer';
import React, { useCallback, useContext, useMemo, useState } from 'react';
import {
  RemoteJobImportDispatchContext,
  RemoteJobImportState,
  RemoteJobImportStateContext,
} from './RemoteJobImportContext';

const RemoteJobImportProvider = ({ data, children }: { data: RemoteJobImportData; children: React.ReactNode }) => {
  const [jobIdx, setJobIdxState] = useState<number | null>(null);
  const [jobData, setJobData] = useState<RemoteJobImportData['jobs']>(data.jobs);

  const errorJobs: RemoteJobImportState['errorJobs'] = useMemo(() => {
    const errorJobsObj: RemoteJobImportState['errorJobs'] = {};

    jobData.forEach(({ jobName, siteId, steps }, index) => {
      let isError = false;
      let isJobName = false;
      let isDupJobName = false;
      let isSiteId = false;

      let collectNames: string[] = [];

      const errorCollectSteps =
        steps.filter(({ stepType }) => stepType === 'collect').filter(({ planIds }) => planIds.length === 0) ?? [];

      const isDuplicateJobName = jobData
        .filter((item, idx) => idx !== index)
        .some((item) => {
          console.log('item.jobName', item.jobName?.toLowerCase().trim());
          console.log('jobName', jobName?.toLowerCase().trim());

          return item.jobName?.toLowerCase().trim() === jobName?.toLowerCase().trim() ?? '';
        });

      if (!jobName) {
        isError = true;
        isJobName = true;
      }

      if (isDuplicateJobName) {
        isError = true;
        isDupJobName = true;
      }

      if (!siteId) {
        isError = true;
        isSiteId = true;
      }

      if (errorCollectSteps.length > 0) {
        isError = true;
        collectNames = errorCollectSteps.map(({ stepName }) => stepName as string);
      }

      errorJobsObj[index] = {
        isError,
        errors: {
          isDupJobName,
          isJobName,
          isSiteId,
          collectNames,
        },
      };
    });

    return errorJobsObj;
  }, [jobData]);

  const setJobIdx = useCallback((index: number | null) => {
    setJobIdxState(index);
  }, []);

  const curJob = useMemo(() => (jobIdx !== null && jobIdx !== undefined ? jobData[jobIdx] : null), [jobIdx, jobData]);

  const setJobName = useCallback((index: number, jobName: string | null) => {
    setJobData((prev) =>
      produce(prev, (draft) => {
        if (draft[index]) {
          draft[index].jobName = jobName;
        }
      }),
    );
  }, []);

  const setSiteId = useCallback((index: number, siteId: number | null) => {
    setJobData((prev) =>
      produce(prev, (draft) => {
        if (draft[index]) {
          draft[index].siteId = siteId;
        }
      }),
    );
  }, []);

  const setPlanIds = useCallback(
    ({ jobIdx, uuid, type, planIds }: { jobIdx: number; uuid: string; type: 'all' | 'one'; planIds: number[] }) => {
      setJobData((prev) =>
        produce(prev, (draft) => {
          if (prev[jobIdx]) {
            const findIndex = prev[jobIdx].steps.findIndex((step) => step.uuid === uuid);
            if (findIndex !== -1) {
              if (type === 'all') {
                draft[jobIdx].steps[findIndex].planIds = planIds;
              } else {
                const newPlans = [...prev[jobIdx].steps[findIndex].planIds];
                for (let i = 0; i < planIds.length; i++) {
                  if (newPlans.includes(planIds[i])) {
                    newPlans.splice(newPlans.indexOf(planIds[i]), 1);
                  } else {
                    newPlans.push(planIds[i]);
                  }
                }
                draft[jobIdx].steps[findIndex].planIds = newPlans;
              }
            }
          }
        }),
      );
    },
    [],
  );

  const setFtps = useCallback(({ jobIdx, uuid, ftp }: { jobIdx: number; uuid: string; ftp: RemoteJobFTP }) => {
    setJobData((prev) =>
      produce(prev, (draft) => {
        if (prev[jobIdx]) {
          const findIndex = prev[jobIdx].steps.findIndex((step) => step.uuid === uuid);
          if (findIndex !== -1) {
            const draftFtps = draft[jobIdx].steps[findIndex].ftps;
            if (draftFtps.some((item) => item.id === ftp.id)) {
              draft[jobIdx].steps[findIndex].ftps = draftFtps.filter((item) => item.id !== ftp.id);
            } else {
              draft[jobIdx].steps[findIndex].ftps.push(ftp);
            }

            draft[jobIdx].steps[findIndex].isFtp = draft[jobIdx].steps[findIndex].ftps.length === 0 ? false : true;
          }
        }
      }),
    );
  }, []);

  const dispatch = useMemo(
    () => ({
      setJobIdx,
      setJobName,
      setSiteId,
      setPlanIds,
      setFtps,
    }),
    [setJobIdx, setJobName, setSiteId, setPlanIds, setFtps],
  );

  return (
    <RemoteJobImportStateContext.Provider
      value={{
        jobData: jobData,
        curJob,
        originData: data,
        jobIdx,
        errorJobs,
      }}
    >
      <RemoteJobImportDispatchContext.Provider value={dispatch}>{children}</RemoteJobImportDispatchContext.Provider>
    </RemoteJobImportStateContext.Provider>
  );
};

export const useRemoteJobImportContext = () => {
  const state = useContext(RemoteJobImportStateContext);
  const dispatch = useContext(RemoteJobImportDispatchContext);

  if (!state) throw new Error('Cannot find RemoteJobImportStateContext');
  if (!dispatch) throw new Error('Cannot find RemoteJobImportDispatchContext');

  return {
    originData: state.originData,
    jobData: state.jobData,
    jobIdx: state.jobIdx,
    curJob: state.curJob,
    errorJobs: state.errorJobs,
    setJobIdx: dispatch.setJobIdx,
    setJobName: dispatch.setJobName,
    setSiteId: dispatch.setSiteId,
    setPlanIds: dispatch.setPlanIds,
    setFtps: dispatch.setFtps,
  };
};

export default RemoteJobImportProvider;
