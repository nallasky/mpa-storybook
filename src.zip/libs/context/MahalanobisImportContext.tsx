import type { ResUploadMahalanobisData } from '@typesdef/mahalanobis';
import { createContext } from 'react';

export interface MahalanobisImportState {
  pathId: number;
  itemIndex: number | null;
  itemData: ResUploadMahalanobisData[];
  originData: ResUploadMahalanobisData[];
  curItem: ResUploadMahalanobisData | null;
  errorIndexList: number[];
}

type MahalanobisImportDispatch = {
  setItemIndex: (index: number | null) => void;
  setEquipment: ({
    itemIndex,
    equipmentId,
    equipmentName,
  }: {
    itemIndex: number;
    equipmentId: string;
    equipmentName: string;
  }) => void;
};

export const MahalanobisImportStateContext = createContext<MahalanobisImportState | undefined>(undefined);
export const MahalanobisImportDispatchContext = createContext<MahalanobisImportDispatch | undefined>(undefined);
