import { RemoteJobFTP, RemoteJobImportData } from '@typesdef/Job';
import { createContext } from 'react';

export type RemoteJobImportStateErrorJobs = Record<
  number,
  {
    isError: boolean;
    errors: {
      isJobName: boolean;
      isDupJobName: boolean;
      isSiteId: boolean;
      collectNames: string[];
    };
  }
>;

export interface RemoteJobImportState {
  jobIdx: number | null;
  jobData: RemoteJobImportData['jobs'];
  curJob: RemoteJobImportData['jobs'][0] | null;
  originData: RemoteJobImportData;
  errorJobs: RemoteJobImportStateErrorJobs;
}

type RemoteJobImportDispatch = {
  setJobIdx: (index: number | null) => void;
  setJobName: (index: number, jobName: string | null) => void;
  setSiteId: (index: number, siteId: number | null) => void;
  setPlanIds: ({
    jobIdx,
    uuid,
    type,
    planIds,
  }: {
    jobIdx: number;
    uuid: string;
    type: 'all' | 'one';
    planIds: number[];
  }) => void;
  setFtps: ({ jobIdx, uuid, ftp }: { jobIdx: number; uuid: string; ftp: RemoteJobFTP }) => void;
};

export const RemoteJobImportStateContext = createContext<RemoteJobImportState | undefined>(undefined);
export const RemoteJobImportDispatchContext = createContext<RemoteJobImportDispatch | undefined>(undefined);
