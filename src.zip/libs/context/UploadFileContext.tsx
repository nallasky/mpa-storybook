import { RcFile } from 'antd/es/upload';
import { createContext, Dispatch } from 'react';

export type ResUploadFile = {
  name: string | undefined;
  fileIndex: number | undefined;
  uid: string | undefined;
  status: string | undefined;
};

export interface UploadFileState {
  files: RcFile[];
  resFiles: ResUploadFile[];
}

export type UploadFileAction =
  | { type: 'SET_FILES'; payload: UploadFileState['files'] }
  | { type: 'SET_RES_FILES'; payload: UploadFileState['resFiles'] };

type UploadFileDispatch = Dispatch<UploadFileAction>;

export const UploadFileStateContext = createContext<UploadFileState | undefined>(undefined);
export const UploadFileDispatchContext = createContext<UploadFileDispatch | undefined>(undefined);
