import { GlobalModalProps } from '@typesdef/modal';
import React, { useMemo, useState } from 'react';
import { flushSync } from 'react-dom';
import { GlobalModalDispatchContext, GlobalModalStateContext } from './GlobalModalContext';

const GlobalModalProvider = ({ children }: { children: React.ReactNode }) => {
  const [openedModals, setOpenedModals] = useState<Map<string, GlobalModalProps>>(new Map());

  const open = (key: string, Component: GlobalModalProps['Component'], props?: GlobalModalProps['props']) => {
    if (props && (props as any)!.isOpenDelay) {
      setTimeout(() => {
        setOpenedModals((prev) => new Map(prev).set(key, { Component, props: { ...props, visible: true } }));
      }, 300);
    } else {
      setOpenedModals((prev) => new Map(prev).set(key, { Component, props: { ...props, visible: true } }));
    }
  };

  const close = (key: string) => {
    flushSync(() => {
      setOpenedModals((modals) => {
        const foundModal = modals.get(key);
        if (foundModal) {
          modals.set(key, { ...foundModal, props: { ...foundModal.props, visible: false } });
        }
        return new Map(modals);
      });
    });

    setTimeout(() => {
      setOpenedModals((modals) => {
        modals.delete(key);
        return new Map(modals);
      });
    }, 300);
  };

  const dispatch = useMemo(() => ({ open, close }), []);

  return (
    <GlobalModalStateContext.Provider value={openedModals}>
      <GlobalModalDispatchContext.Provider value={dispatch}>{children}</GlobalModalDispatchContext.Provider>
    </GlobalModalStateContext.Provider>
  );
};

export default GlobalModalProvider;
