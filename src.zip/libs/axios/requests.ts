import { FormCrasSiteName } from '@components/CrasData/hooks/useCrasDataAdd';
import { API_URL } from '@constants/constants';
import { DEFAULT_ALL_ADDRESS_KEY } from '@reducers/slices/address';
import { ResDownloadBlob } from '@typesdef/common';
import {
  CrasDataCreateInfo,
  CrasDataCreateOption,
  CrasDataJudgeInfo,
  CrasDataJudgeOption,
  CrasDataManualInfo,
  ResCrasDataAdd,
} from '@typesdef/crasData';
import {
  LocalJobStatusState,
  RegisteredJob,
  RemoteJobDetailState,
  RemoteJobJudgeRule,
  RemoteJobPlanDetailState,
  ReqLocalJob,
  ReqRemoteJob,
  // RemoteJobReqData,
  // RemoteJobResData,
  // RemoteJobTimeLine,
  TransferRemoteJobJudgeRule,
} from '@typesdef/Job';
import { AxiosRequestConfig } from 'axios';
import client from './configure';
import {
  AddressInfo,
  ReqGetSiteDBInfo,
  ReqPostAddEmail,
  ReqPostAddGroup,
  ReqPostCrasConnection,
  ReqPostCrasDataCreateAdd,
  ReqPostCrasDataJudgeAdd,
  ReqPostCrasDataTestQuery,
  ReqPostEmailConnection,
  ReqPostHostDBInfo,
  ReqPostRssConnection,
  ReqPostSiteDBInfo,
  ReqPutCrasDataCreateEdit,
  ReqPutCrasDataJudgeEdit,
  ReqPutEditEmail,
  ReqPutEditGroup,
  ReqPutSiteDBInfo,
  ResGetAddressInfo,
  ResGetBuildHistoryData,
  ResGetBuildHistoryItem,
  ResGetCrasDataManualInfo,
  ResGetHostDBInfo,
  ResGetLogMonitorVersion,
  ResGetSiteJobStatus,
  ResGetSiteName,
  SiteDBInfo,
} from './types';

export const getRequest = async <ResData = unknown>({
  url,
  options,
}: {
  url: string;
  options?: AxiosRequestConfig;
}): Promise<ResData> => {
  const { data } = await client.get<ResData>(url, options);
  return data;
};

export const postRequest = async <ReqData, ResData = unknown>({
  url,
  reqData,
  options,
}: {
  url: string;
  reqData?: ReqData;
  options?: AxiosRequestConfig;
}): Promise<ResData> => {
  const { data } = await client.post<ResData>(url, reqData, options);
  return data;
};

export const putRequest = async <ReqData, ResData = unknown>({
  url,
  reqData,
  options,
}: {
  url: string;
  reqData: ReqData;
  options?: AxiosRequestConfig;
}): Promise<ResData> => {
  const { data } = await client.put<ResData>(url, reqData, options);
  return data;
};

export const patchRequest = async <ReqData, ResData = unknown>({
  url,
  reqData,
  options,
}: {
  url: string;
  reqData: ReqData;
  options?: AxiosRequestConfig;
}): Promise<ResData> => {
  const { data } = await client.patch<ResData>(url, reqData, options);
  return data;
};

export const downloadBlobRequest = async ({
  url,
  options,
}: {
  url: string;
  options?: AxiosRequestConfig;
}): Promise<ResDownloadBlob> => {
  const { data, headers } = await client.get<Blob>(url, { ...options, responseType: 'blob' });
  const disposition = headers['content-disposition'];
  const fileName = getFileName(disposition);

  return { data, fileName };
};

export const deleteRequest = async <ResData = unknown>({
  url,
  signal,
}: {
  url: string;
  select?: (data: ResData) => ResData;
  signal?: AbortSignal;
}): Promise<ResData> => {
  const { data } = await client.delete<ResData>(url, { signal });
  return data;
};

export const getStatusSiteList = async (): Promise<ResGetSiteName[]> => {
  const { data } = await client.get<ResGetSiteName[]>(API_URL.GET_STATUS_SITE_LIST);
  return data.map((item, index) => ({
    ...item,
    crasCompanyFabName: `${item.crasCompanyName}-${item.crasFabName}`,
  }));
};

export const getStatusRegisteredJobForSite = async (siteId: number): Promise<RegisteredJob[]> => {
  const { data } = await client.get<RegisteredJob[]>(API_URL.GET_STATUS_REGISTERED_JOB_FOR_SITE(siteId));
  return data;
};

export const getStatusRemoteJobStop = async (jobId: number | string): Promise<{ stop: boolean }> => {
  const { data } = await client.get<{ stop: boolean }>(API_URL.GET_STATUS_REMOTE_JOB_STOP_STATUS(jobId));
  return data;
};

export const getStatusRemoteJobStopAll = async (jobId: number | string): Promise<{ stop: boolean }> => {
  const { data } = await client.get<{ stop: boolean }>(API_URL.GET_STATUS_REMOTE_JOB_STOP_STATUS_ALL(jobId));
  return data;
};

export const getRemoteJobInfo = async (jobId: number | string): Promise<RemoteJobDetailState> => {
  const { data } = await client.get<RemoteJobDetailState>(API_URL.GET_STATUS_REMOTE_JOB_INFO(jobId));

  return {
    ...data,
    steps: data.steps.map((item, idx) => ({
      ...item,
      index: idx,
    })),
  };
};

export const getRemoteJobPlans = async (siteId: number): Promise<RemoteJobPlanDetailState[]> => {
  const { data } = await client.get<RemoteJobPlanDetailState[]>(API_URL.GET_STATUS_REMOTE_PLAN_LIST(siteId));
  return data.map((item, index) => ({
    ...item,
    index: index,
    machineCount: item.machineNames.length,
    targetCount: item.targetNames.length,
  }));
};

export const stopRemoteJob = async (jobId: string | number) => {
  const { data } = await client.patch(API_URL.STOP_STATUS_REMOTE_JOB(jobId));
  return data;
};

export const startRemoteJob = async (jobId: string | number) => {
  const { data } = await client.patch(API_URL.RUN_STATUS_REMOTE_JOB(jobId));
  return data;
};

export const executeManualRemoteStep = async (jobId: string | number, stepId: string | number) => {
  const { data } = await client.patch(API_URL.EXECUTE_MANUAL_STATUS_REMOTE_STEP(jobId, stepId));
  return data;
};

export const postRemoteJobStepFiles = async (formData: FormData) => {
  const { data } = await client.post(API_URL.POST_STATUS_REMOTE_JOB_STEP_FILES, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return data;
};

export const getRemoteJobStepFiles = async (jobId: number | string, stepId: string) => {
  const { data, headers } = await client.get(API_URL.GET_STATUS_REMOTE_JOB_STEP_FILES(jobId, stepId), {
    responseType: 'blob',
  });

  const disposition = headers['content-disposition'];
  const fileName = getFileName(disposition);

  return { data, fileName };
};

export const postRemoteJob = async (reqData: ReqRemoteJob) => {
  const { data } = await client.post(API_URL.POST_STATUS_REMOTE_JOB, reqData);
  return data;
};

export const putRemoteJob = async ({ jobId, reqData }: { jobId: number; reqData: ReqRemoteJob }) => {
  const { data } = await client.put(API_URL.PUT_STATUS_REMOTE_JOB(jobId), reqData);
  return data;
};

export const deleteRemoteJob = async (jobId: string | number) => {
  const { data } = await client.delete(API_URL.DELETE_STATUS_REMOTE_JOB(jobId));
  return data;
};

export const getStatusLocalJob = async (): Promise<LocalJobStatusState[]> => {
  const { data } = await client.get<LocalJobStatusState[]>(API_URL.GET_STATUS_LOCAL_JOB_LIST());
  return data.map((item, index) => ({
    ...item,
    index: index,
    companyFabName: `${item.companyName}-${item.fabName}`,
  }));
};

export const postLocalJob = async (reqData: ReqLocalJob) => {
  const { data } = await client.post(API_URL.POST_STATUS_LOCAL_JOB, reqData);
  return data;
};

export const deleteLocalJob = async (jobId: number) => {
  const { data } = await client.delete(API_URL.DELETE_STATUS_LOCAL_JOB(jobId));
  return data;
};

export const getRemoteJobJudgeRuleList = async (siteId: string | number): Promise<TransferRemoteJobJudgeRule[]> => {
  const { data } = await client.get<RemoteJobJudgeRule[]>(API_URL.GET_STATUS_REMOTE_JOB_JUDGE_RULE_LIST(siteId));

  return data.map((item) => ({ key: `${item.itemId}`, ...item }));
};

export const getHostDBInfo = async (): Promise<ResGetHostDBInfo> => {
  const { data } = await client.get<ResGetHostDBInfo>(API_URL.GET_CONFIGURE_HOST_DB);
  return data;
};

export const postHostDBInfo = async (reqData: ReqPostHostDBInfo) => {
  const { data } = await client.post(API_URL.POST_CONFIGURE_HOST_DB, reqData);
  return data;
};

export const getSiteDBInfo = async (): Promise<SiteDBInfo[]> => {
  const { data } = await client.get<ReqGetSiteDBInfo[]>(API_URL.GET_CONFIGURE_SITE_DB);
  return data.map((item, index) => ({
    ...item,
    index: index,
    crasCompanyFabName: `${item.crasCompanyName}-${item.crasFabName}`,
  }));
};

export const postSiteDBInfo = async (reqData: ReqPostSiteDBInfo) => {
  const { data } = await client.post(API_URL.POST_CONFIGURE_SITE_DB, reqData);
  return data;
};

export const putSiteDBInfo = async (reqData: ReqPutSiteDBInfo) => {
  const { data } = await client.put(API_URL.PUT_CONFIGURE_SITE_DB(reqData.siteId), reqData);
  return data;
};

export const deleteSiteDBInfo = async (siteId: string | number) => {
  const { data } = await client.delete(API_URL.DELETE_CONFIGURE_SITE_DB(siteId));
  return data;
};

export const postCrasConnection = async (reqData: ReqPostCrasConnection) => {
  const { data } = await client.post(API_URL.GET_CONFITURE_CRAS_CONNECTION, reqData);
  return data;
};

export const postEmailConnection = async (reqData: ReqPostEmailConnection) => {
  const { data } = await client.post(API_URL.GET_CONFITURE_EMAIL_CONNECTION, reqData);
  return data;
};

export const postEmailSend = async (reqData: ReqPostEmailConnection) => {
  const { data } = await client.post(API_URL.GET_CONFITURE_EMAIL_SEND, reqData);
  return data;
};

export const postRssConnection = async (reqData: ReqPostRssConnection) => {
  const { data } = await client.post(API_URL.GET_CONFITURE_RSS_CONNECTION, reqData);
  return data;
};

export const getConfigureExport = async () => {
  const { data, headers } = await client.get(API_URL.GET_CONFIGURE_EXPORT, {
    responseType: 'blob',
  });

  const disposition = headers['content-disposition'];
  const fileName = getFileName(disposition);

  return { data, fileName };
};

export const postConfigureImport = async (formData: FormData) => {
  const { data } = await client.post(API_URL.GET_CONFIGURE_IMPORT, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return data;
};

export const getHistoryBuildStatus = async (id: string): Promise<ResGetBuildHistoryItem> => {
  const { data } = await client.get(API_URL.GET_STATUS_BUILD_HISTORY_STATUS(id));
  return data;
};

export const getHistoryBuildData = async ({
  url,
  start,
  signal,
}: {
  url: string;
  start: number;
  signal?: AbortSignal;
}): Promise<ResGetBuildHistoryData> => {
  const { data } = await client.get(`${url}?start=${start}`, { signal });
  return data;
};

export const getLogMonitorServerVersion = async (): Promise<ResGetLogMonitorVersion> => {
  const { data } = await client.get(API_URL.GET_CONFIGURE_LOG_MONITOR_VERSION);
  return data;
};

export const getSiteJobStatus = async (siteId: string | number): Promise<ResGetSiteJobStatus> => {
  const { data } = await client.get(API_URL.GET_CONFIGURE_SITE_JOB_STATUS(siteId));
  return data;
};

export const getSiteStatus = async (): Promise<ResGetSiteJobStatus> => {
  const { data } = await client.get(API_URL.GET_CONFIGURE_SITE_STATUS);
  return data;
};

export const getLogMonitorOos = async (): Promise<string> => {
  const { data } = await client.get(API_URL.GET_LOG_MONITOR_OOS);
  return data;
};

export const getAddressGroupList = async (): Promise<AddressInfo[]> => {
  const { data } = await client.get<ResGetAddressInfo[]>(API_URL.GET_ADDRESS_GROUP_LIST);
  // return data.map((res, idx) => ({
  //   index: idx,
  //   ...res,
  // }));
  return data;
};

export const getAddressGroupListInEmail = async (emailId: number | string): Promise<AddressInfo[]> => {
  const { data } = await client.get<ResGetAddressInfo[]>(API_URL.GET_ADDRESS_GROUP_LIST_IN_EMAIL(emailId));
  // return data.map((res, idx) => ({
  //   index: idx,
  //   ...res,
  // }));
  return data;
};

export const getAddressEmailList = async (gorupId: string | number | undefined): Promise<AddressInfo[]> => {
  if (!gorupId || +gorupId === DEFAULT_ALL_ADDRESS_KEY) {
    const { data } = await client.get<ResGetAddressInfo[]>(API_URL.GET_ADDRESS_EMAIL_LIST);
    // return data.map((res, idx) => ({
    //   index: idx,
    //   ...res,
    // }));
    return data;
  } else {
    const { data } = await client.get<ResGetAddressInfo[]>(API_URL.GET_ADDRESS_EMAIL_LIST_BY_GROUP(gorupId));
    // return data.map((res, idx) => ({
    //   index: idx,
    //   ...res,
    // }));
    return data;
  }
};

export const deleteAddressEmail = async (emailIds: number[]) => {
  const { data } = await client.delete(API_URL.DELETE_ADDRESS_DELETE_EMAIL(emailIds));
  return data;
};

export const searchAddressEmail = async (keyword: string): Promise<AddressInfo[]> => {
  const { data } = await client.get<ResGetAddressInfo[]>(API_URL.SEARCH_ADDRESS_EMAIL(keyword));
  // return data.map((res, idx) => ({
  //   index: idx,
  //   ...res,
  // }));
  return data;
};

export const searchAddressEmailAndGroup = async (keyword: string): Promise<AddressInfo[]> => {
  const { data } = await client.get<ResGetAddressInfo[]>(API_URL.SEARCH_ADDRESS_GROUP_EMAIL(keyword));
  // return data.map((res, idx) => ({
  //   index: idx,
  //   ...res,
  // }));
  return data;
};

export const postAddressAddEmail = async (reqData: ReqPostAddEmail) => {
  const { data } = await client.post(API_URL.POST_ADDRESS_ADD_EMAIL, reqData);
  return data;
};

export const putAddressEditEmail = async (reqData: ReqPutEditEmail) => {
  const { id, name, email, groupIds } = reqData;
  const { data } = await client.put(API_URL.PUT_ADDRESS_EDIT_EMAIL(id), { name, email, groupIds });
  return data;
};

export const postAddressAddGroup = async (reqData: ReqPostAddGroup) => {
  const { data } = await client.post(API_URL.POST_ADDRESS_ADD_GROUP, reqData);
  return data;
};

export const putAddressEditGroup = async (reqData: ReqPutEditGroup) => {
  const { id, name, emailIds } = reqData;
  const { data } = await client.put(API_URL.PUT_ADDRESS_EDIT_GROUP(id!), { name, emailIds });
  return data;
};

export const deleteAddressGroup = async (groupId: number | string) => {
  const { data } = await client.delete(API_URL.DELETE_ADDRESS_DELETE_GROUP(groupId));
  return data;
};

export const getAddressGroupEmailList = async (): Promise<AddressInfo[]> => {
  const { data } = await client.get<ResGetAddressInfo[]>(API_URL.GET_ADDRESS_GROUP_EMAIL_LIST);
  return data;
};

export const postCrasAddSite = async (reqData: FormCrasSiteName) => {
  const { data } = await client.post<Promise<ResCrasDataAdd>>(API_URL.POST_CRAS_SITE_ADD, reqData);
  return data;
};

export const DeleteCrasDeleteSite = async (id: number) => {
  const { data } = await client.delete(API_URL.DELETE_CRAS_SITE_DELETE(id));
  return data;
};

export const getCrasManualCreateInfoList = async (id: number): Promise<CrasDataManualInfo[]> => {
  const { data } = await client.get<ResGetCrasDataManualInfo[]>(API_URL.GET_CRAS_MANUAL_CREATE_INFO_LIST(id));
  return data.map((item, idx) => ({
    index: idx,
    ...item,
  }));
};

export const getCrasManualCreateInfoDetail = async (id: number, itemId: number): Promise<CrasDataCreateInfo> => {
  const { data } = await client.get<CrasDataCreateInfo>(API_URL.GET_CRAS_MANUAL_CREATE_INFO_DETAIL(id, itemId));
  return data;
};

export const getCrasManualCreateTargetTable = async (id: number): Promise<string[]> => {
  const { data } = await client.get<string[]>(API_URL.GET_CRAS_MANUAL_CREATE_TARGET_TABLE(id));
  return data;
};

export const getCrasManualCreateTargetColumn = async (id: number, tableName: string): Promise<string[]> => {
  const { data } = await client.get<string[]>(API_URL.GET_CRAS_MANUAL_CREATE_TARGET_COLUMN(id, tableName));
  return data;
};

export const getCrasManualJudgeInfoList = async (id: number): Promise<CrasDataManualInfo[]> => {
  const { data } = await client.get<ResGetCrasDataManualInfo[]>(API_URL.GET_CRAS_MANUAL_JUDGE_INFO_LIST(id));
  return data.map((item, idx) => ({
    index: idx,
    ...item,
  }));
};

export const getCrasManualJudgeInfoDetail = async (id: number, itemId: number): Promise<CrasDataJudgeInfo> => {
  const { data } = await client.get<CrasDataJudgeInfo>(API_URL.GET_CRAS_MANUAL_JUDGE_INFO_DETAIL(id, itemId));
  return data;
};

export const postCrasManualCreateTestQuery = async (reqData: ReqPostCrasDataTestQuery) => {
  const { data } = await client.post(API_URL.POST_CRAS_MANUAL_CREATE_TEST_QUERY, reqData);
  return data;
};

export const postCrasManualCreateAdd = async (id: number, reqData: ReqPostCrasDataCreateAdd) => {
  const { data } = await client.post(API_URL.POST_CRAS_MANUAL_CREATE_ADD(id), reqData);
  return data;
};

export const putCrasManualCreateEdit = async (id: number, itemId: number, reqData: ReqPutCrasDataCreateEdit) => {
  const { data } = await client.put(API_URL.PUT_CRAS_MANUAL_CREATE_EDIT(id, itemId), reqData);
  return data;
};

export const deleteCrasManualCreateDelete = async (id: number, itemId: number) => {
  const { data } = await client.delete(API_URL.DELETE_CRAS_MANUAL_CREATE_DELETE(id, itemId));
  return data;
};

export const postCrasManualJudgeAdd = async (id: number, reqData: ReqPostCrasDataJudgeAdd) => {
  const { data } = await client.post(API_URL.POST_CRAS_MANUAL_JUDGE_ADD(id), reqData);
  return data;
};

export const putCrasManualJudgeEdit = async (id: number, itemId: number, reqData: ReqPutCrasDataJudgeEdit) => {
  const { data } = await client.put(API_URL.PUT_CRAS_MANUAL_JUDGE_EDIT(id, itemId), reqData);
  return data;
};

export const deleteCrasManualJudgeDelete = async (id: number, itemId: number) => {
  const { data } = await client.delete(API_URL.DELETE_CRAS_MANUAL_JUDGE_DELETE(id, itemId));
  return data;
};

export const getCrasManualCreateOption = async (): Promise<CrasDataCreateOption> => {
  const { data } = await client.get(API_URL.GET_CRAS_MANUAL_CREATE_OPTION);
  return data;
};

export const getCrasManualJudgeOption = async (): Promise<CrasDataJudgeOption> => {
  const { data } = await client.get(API_URL.GET_CRAS_MANUAL_JUDGE_OPTION);
  return data;
};

export const getCrasManualEquipOption = async (id: number): Promise<string[]> => {
  const { data } = await client.get<string[]>(API_URL.GET_CRAS_MANUAL_EQUIP_OPTION(id));
  return data;
};
export const postCrasImportFile = async (id: number, formData: FormData) => {
  const { data } = await client.post(API_URL.POST_CRAS_IMPORT_FILE(id), formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return data;
};

export const getCrasExportFile = async (id: number) => {
  const { data, headers } = await client.get(API_URL.GET_CRAS_EXPORT_FILE(id), {
    responseType: 'blob',
  });

  const disposition = headers['content-disposition'];
  const fileName = getFileName(disposition);

  return { data, fileName };
};

export const getDownloadLogMonitorDebugLog = async (path: string) => {
  const { data, headers } = await client.get(API_URL.GET_DOWNLOAD_LOG_MOINITOR_DEBUG_LOG(path), {
    responseType: 'blob',
  });

  const disposition = headers['content-disposition'];
  const fileName = getFileName(disposition);

  return { data, fileName };
};

export const getDownloadCrasDebugLog = async (siteId: number) => {
  const { data, headers } = await client.get(API_URL.GET_DOWNLOAD_CRAS_DEBUG_LOG(siteId), {
    responseType: 'blob',
  });

  const disposition = headers['content-disposition'];
  const fileName = getFileName(disposition);

  return { data, fileName };
};

export const getFileName = (disposition: string): string => {
  if (disposition) {
    const fileMatch = disposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
    if (Array.isArray(fileMatch)) {
      return decodeURI(fileMatch[1].replace(/['"]/g, ''));
    }
  }

  return 'download_file';
};
