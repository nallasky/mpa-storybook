import { combineReducers } from '@reduxjs/toolkit';
import address from './slices/address';
import buildHistory from './slices/buildHistory';
import columnDefine from './slices/columnDefine';
import configure from './slices/configure';
import convert from './slices/convert';
import crasData from './slices/crasData';
import errorLog from './slices/errorLog';
import localJob from './slices/localJob';
import loginUser from './slices/loginUser';
import remoteJob from './slices/remoteJob';
import debugMode from './slices/debugMode';
import crasDBViewer from './slices/GtparkCrasDBViewer';

const rootReducer = combineReducers({
  localJob,
  remoteJob,
  configure,
  buildHistory,
  loginUser,
  address,
  crasData,
  convert,
  errorLog,
  columnDefine,
  debugMode,
  crasDBViewer
});

export default rootReducer;

export type RootState = ReturnType<typeof rootReducer>;
