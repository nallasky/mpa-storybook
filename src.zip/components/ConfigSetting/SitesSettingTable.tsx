import { DeleteOutlined, EditOutlined, ExportOutlined, ImportOutlined, PlusOutlined } from '@ant-design/icons';
import RefreshBtn from '@components/common/atoms/RefreshBtn';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { css } from '@emotion/react';
import { SiteDBInfo } from '@libs/axios/types';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { AntdTableOnRow } from '@typesdef/antd';
import { TableColumnPropsType } from '@typesdef/common';
import { SiteDBInfoColumnName } from '@typesdef/configure';
import { Button, Table } from 'antd';
import { useCallback } from 'react';
import useSiteDBInfoTable from './hooks/useSiteDBInfoTable';
import SitesSettingImportModal from './Modal/SitesSettingImportModal';

export type SitesSettingTableProps = {};

export default function SitesSettingTable({}: SitesSettingTableProps): JSX.Element {
  const {
    isFetchingSiteList,
    siteList,
    siteListLen,
    refreshSiteList,
    openAddDrawer,
    openEditModal,
    openDeleteModal,
    openExportModal,
    openImportModal,
    openInfoDrawer,
  } = useSiteDBInfoTable();

  const handleClickEdit = useCallback(
    (record: SiteDBInfo) => {
      openEditModal(record);
    },
    [openEditModal],
  );

  const editRender = useCallback(
    (value: number, record: SiteDBInfo, index: number) => (
      <EditOutlined css={hoverActiveStyle} onClick={() => handleClickEdit(record)} />
    ),
    [handleClickEdit],
  );

  const handleClickAdd = useCallback(() => {
    openAddDrawer();
  }, [openAddDrawer]);

  const deleteRender = useCallback(
    (value: number, record: SiteDBInfo, index: number) => {
      const { siteId, crasCompanyFabName } = record;
      return <DeleteOutlined css={hoverActiveStyle} onClick={() => openDeleteModal(siteId, crasCompanyFabName)} />;
    },
    [openDeleteModal],
  );

  const onRow: AntdTableOnRow<SiteDBInfo> = useCallback(
    (record, rowIndex) => {
      return {
        onClick: (event) => {
          if ((event.target as HTMLElement).classList.contains('view-info')) {
            openInfoDrawer(record);
          }
        },
      };
    },
    [openInfoDrawer],
  );

  const renderTitle = useCallback(
    () => (
      <TableHeader title={<TableHeaderTitle total={siteListLen} />}>
        <Button type="primary" icon={<PlusOutlined />} onClick={handleClickAdd} disabled={isFetchingSiteList}>
          Add
        </Button>
        <Button type="primary" icon={<ImportOutlined />} onClick={openImportModal}>
          Import
        </Button>
        <Button type="primary" icon={<ExportOutlined />} onClick={openExportModal}>
          Export
        </Button>
        <RefreshBtn
          type="primary"
          onClick={refreshSiteList}
          disabled={isFetchingSiteList}
          loading={isFetchingSiteList}
        />
      </TableHeader>
    ),
    [siteListLen, openImportModal, openExportModal, handleClickAdd, refreshSiteList, isFetchingSiteList],
  );

  return (
    <div css={style}>
      <Table<SiteDBInfo>
        title={renderTitle}
        onRow={onRow}
        rowKey="index"
        dataSource={siteList}
        bordered
        size="small"
        tableLayout="fixed"
        css={tableStyle}
        // scroll={{ x: 1304 }} // Full View
        sticky={true}
        loading={isFetchingSiteList}
        pagination={{
          position: ['bottomCenter'],
          total: siteListLen,
          showSizeChanger: true,
        }}
      >
        <Table.ColumnGroup<SiteDBInfo> {...siteDBInfoColumnProps.crasServer}>
          <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.crasCompanyFabName}></Table.Column>
          <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.crasAddress} />
          <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.crasPort}></Table.Column>
        </Table.ColumnGroup>
        <Table.ColumnGroup<SiteDBInfo> {...siteDBInfoColumnProps.emailServer}>
          <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.emailAddress}></Table.Column>
          <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.emailPort}></Table.Column>
        </Table.ColumnGroup>
        <Table.ColumnGroup<SiteDBInfo> {...siteDBInfoColumnProps.rapidCollector}>
          <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.rssAddress}></Table.Column>
          <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.rssPort}></Table.Column>
        </Table.ColumnGroup>
        <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.edit} render={editRender}></Table.Column>
        <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.delete} render={deleteRender}></Table.Column>
        {/* Full View */}
        {/* <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.index} width={100} render={numberRender}></Table.Column>
          <Table.ColumnGroup<SiteDBInfo> {...siteDBInfoColumnProps.crasServer}>
            <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.crasCompanyFabName} width={250}></Table.Column>
            <Table.Column<SiteDBInfo>
              {...siteDBInfoColumnProps.crasAddress}
              width={184}
              render={crasAddressRender}
            ></Table.Column>
            <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.crasPort} width={100}></Table.Column>
          </Table.ColumnGroup>
          <Table.ColumnGroup<SiteDBInfo> {...siteDBInfoColumnProps.emailServer}>
            <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.emailAddress} width={184}></Table.Column>
            <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.emailPort} width={100}></Table.Column>
            <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.emailUserName} width={250}></Table.Column>
            <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.emailFrom} width={250}></Table.Column>
          </Table.ColumnGroup>
          <Table.ColumnGroup<SiteDBInfo> {...siteDBInfoColumnProps.rapidCollector}>
            <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.rssAddress} width={184}></Table.Column>
            <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.rssPort} width={100}></Table.Column>
            <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.rssUserName} width={250}></Table.Column>
          </Table.ColumnGroup>
          <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.edit} width={84} render={editRender}></Table.Column>
          <Table.Column<SiteDBInfo> {...siteDBInfoColumnProps.delete} width={84} render={deleteRender}></Table.Column> */}
      </Table>
      <SitesSettingImportModal />
    </div>
  );
}

const style = css`
  width: 100%;
`;

const siteDBInfoColumnProps: TableColumnPropsType<SiteDBInfo, SiteDBInfoColumnName> = {
  crasServer: {
    key: 'none',
    title: <TableColumnTitle>Cras Server</TableColumnTitle>,
  },
  crasCompanyFabName: {
    key: 'crasCompanyFabName',
    title: <TableColumnTitle>User-Fab Name</TableColumnTitle>,
    dataIndex: 'crasCompanyFabName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'crasCompanyFabName'),
    },
    className: 'view-info',
    width: getPixelPercent(1360, 270),
  },
  crasAddress: {
    key: 'crasAddress',
    title: <TableColumnTitle>IP Address</TableColumnTitle>,
    dataIndex: 'crasAddress',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'crasAddress'),
    },
    className: 'view-info',
    width: getPixelPercent(1360, 210),
  },
  crasPort: {
    key: 'crasPort',
    title: <TableColumnTitle>Port</TableColumnTitle>,
    dataIndex: 'crasPort',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'crasPort'),
    },
    className: 'view-info',
    width: getPixelPercent(1360, 100),
  },
  emailServer: {
    title: <TableColumnTitle>Email Server</TableColumnTitle>,
  },
  emailAddress: {
    key: 'emailAddress',
    title: <TableColumnTitle>IP Address</TableColumnTitle>,
    dataIndex: 'emailAddress',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'emailAddress'),
    },
    className: 'view-info',
    width: getPixelPercent(1360, 210),
  },
  emailPort: {
    key: 'emailPort',
    title: <TableColumnTitle>Port</TableColumnTitle>,
    dataIndex: 'emailPort',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'emailPort'),
    },
    className: 'view-info',
    width: getPixelPercent(1360, 100),
  },
  emailUserName: {
    key: 'emailUserName',
    title: <TableColumnTitle>User</TableColumnTitle>,
    dataIndex: 'emailUserName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'emailUserName'),
    },
    className: 'view-info',
  },
  emailFrom: {
    key: 'emailFrom',
    title: <TableColumnTitle>{`Sender's E-mail`}</TableColumnTitle>,
    dataIndex: 'emailFrom',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'emailFrom'),
    },
    className: 'view-info',
  },
  rapidCollector: {
    title: <TableColumnTitle>Rapid Collector Server</TableColumnTitle>,
  },
  rssAddress: {
    key: 'rssAddress',
    title: <TableColumnTitle>IP Address</TableColumnTitle>,
    dataIndex: 'rssAddress',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'rssAddress'),
    },
    className: 'view-info',
    width: getPixelPercent(1360, 210),
  },
  rssPort: {
    key: 'rssPort',
    title: <TableColumnTitle>Port</TableColumnTitle>,
    dataIndex: 'rssPort',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'rssPort'),
    },
    className: 'view-info',
    width: getPixelPercent(1360, 100),
  },
  rssUserName: {
    key: 'rssUserName',
    title: <TableColumnTitle>User</TableColumnTitle>,
    dataIndex: 'rssUserName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'rssUserName'),
    },
    className: 'view-info',
  },
  edit: {
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    // fixed: 'right',
    width: getPixelPercent(1360, 80),
  },
  delete: {
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    // fixed: 'right',
    width: getPixelPercent(1360, 80),
  },
};

const tableStyle = css`
  .ant-table-body {
    table {
      tr {
        td.view-info {
          cursor: pointer;
        }
      }
    }
  }
`;
