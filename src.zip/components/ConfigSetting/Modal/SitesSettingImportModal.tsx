import { InboxOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { usePostConfigureImport } from '@libs/query/configureSetting';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { setSiteInfoIsImport, siteInfoIsImport } from '@reducers/slices/configure';
import useTypedSelector from '@reducers/useTypedSelector';
import { Modal } from 'antd';
import Dragger from 'antd/es/upload/Dragger';
import { AxiosError } from 'axios';
import { Fragment, useCallback, useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useDispatch } from 'react-redux';

export default function SitesSettingImportModal(): JSX.Element {
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const [importFile, setImportFile] = useState<File | undefined>(undefined);
  const visible = useTypedSelector(siteInfoIsImport);

  const { mutate: mutateImportFile, isLoading: isImporting } = usePostConfigureImport({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to import configure file!`, error);
    },
    onSuccess: () => {
      openNotification('success', 'Success', 'Succeed to import configure file');
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.CONFIGURE_SITES], {
        exact: true,
      });
      dispatch(setSiteInfoIsImport(false));
    },
  });

  const handleOk = useCallback(async () => {
    const formData = new FormData();
    formData.append('file', importFile as File);
    mutateImportFile(formData);
  }, [mutateImportFile, importFile]);

  const handleCancel = useCallback(() => {
    dispatch(setSiteInfoIsImport(false));
  }, [dispatch]);

  const draggerProps = useMemo(
    () => ({
      name: 'file',
      multiple: false,
      maxCount: 1,
      beforeUpload: (file: File) => {
        setImportFile(file);
        return false;
      },
      onRemove: () => {
        setImportFile(undefined);
      },
    }),
    [],
  );

  useEffect(() => {
    if (visible) {
      setImportFile(undefined);
    }
  }, [visible]);

  return (
    <Modal
      title="Import Configure"
      visible={visible}
      okText="Import"
      onOk={handleOk}
      okButtonProps={{ loading: isImporting, disabled: isImporting || !importFile }}
      onCancel={handleCancel}
      cancelButtonProps={{
        disabled: isImporting,
      }}
      closable={!isImporting}
      maskClosable={!isImporting}
      destroyOnClose // TODO: 다른 방법이 있을까???
    >
      <Fragment>
        <div css={warningStyle}>
          <div>All saved Jobs will be stopped and deleted.</div>
          <div> Are you sure to import server configuration file?</div>
        </div>
        <Dragger {...draggerProps}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">Click or drag file to this area to upload</p>
        </Dragger>
      </Fragment>
    </Modal>
  );
}

export const warningStyle = css`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  color: red;
  /* font-size: 1rem; */
  margin-bottom: 1rem;
`;
