import { ApiOutlined, ContainerOutlined, MailOutlined } from '@ant-design/icons';
import FormEmail from '@components/common/atoms/CustomForm/FormEmail';
import FormIpAddress from '@components/common/atoms/CustomForm/FormIpAddress';
import FormIpAddressWithLocalhost from '@components/common/atoms/CustomForm/FormIpAddressWithLocalhost';
import FormName from '@components/common/atoms/CustomForm/FormName';
import FormPassword from '@components/common/atoms/CustomForm/FormPassword';
import FormPort from '@components/common/atoms/CustomForm/FormPort';
import CustomIcon from '@components/common/atoms/CustomIcon';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { convertRemToPixels } from '@libs/util/remToPixels';
import { hoverActiveStyle } from '@styles/emotion/common';
import { Badge, Button, Checkbox, Col, Divider, Drawer, Form, Row, Space, Spin, Tooltip } from 'antd';
import React, { Fragment, ReactNode, useMemo } from 'react';
import useSiteDBSetting, { TestConnStatusType } from './hooks/useSiteDBSetting';

export type SitesSettingAddEditProps = {};

export default function SitesSettingAddEdit({}: SitesSettingAddEditProps): JSX.Element {
  const {
    form,
    onFinish,
    crasStatus,
    emailStatus,
    rssStatus,
    isDrawer,
    drawerType,
    closeDrawer,
    isRequestAddEdit,
    localhostCras,
    onClickLocalhostCras,
    localhostRss,
    onClickLocalhostRss,
    requestCrasStatus,
    requestEmailStatus,
    requestSendEmail,
    requestRssStatus,
    disabledCrasInput,
    disabledCrasIPAddressInput,
    disabledRssIPAddressInput,
    disabledCrasLocalHost,
    disabledRssLocalHost,
    disabledEmailInput,
    disabledRssInput,
    resetRssPassword,
    resetEmailPassword,
    disabledApply,
    emailAuth,
    onChangeEmailAuth,
  } = useSiteDBSetting();

  const DrawerTitle = useMemo(() => {
    let icon: React.ReactNode = <ContainerOutlined className="icon" />;
    let typeName = 'Server Configuration';

    switch (drawerType) {
      case 'add':
        icon = <CustomIcon name="circle_plus" className="icon" />;
        typeName = 'Add Server Configuration';
        break;
      case 'edit':
        icon = <CustomIcon name="circle_edit" className="icon" />;
        typeName = 'Edit Server Configuration';
        break;
      case 'info':
      default:
        break;
    }

    return (
      <div
        css={css`
          display: flex;
          align-items: center;
          .icon {
            margin-right: 0.5rem;
          }
        `}
      >
        {icon}
        <span>{typeName}</span>
      </div>
    );
  }, [drawerType]);

  return (
    <Drawer
      title={DrawerTitle}
      placement="right"
      width={convertRemToPixels(67.25)}
      closable={true}
      onClose={closeDrawer}
      open={isDrawer}
      destroyOnClose
      // getContainer={false}
      forceRender
    >
      <Form form={form} onFinish={onFinish} layout="vertical">
        <FormInnerContainer>
          <FormInnerSection>
            <SettingTitle title="Cras Server Setting" status={crasStatus} requestStatus={requestCrasStatus} />
            <FormName label="User Name" name="crasCompanyName" disabled={disabledCrasInput} />
            <FormName label="Fab Name" name="crasFabName" disabled={disabledCrasInput} />
            <FormIpAddressWithLocalhost
              label="Address"
              name="crasAddress"
              disabled={disabledCrasIPAddressInput}
              disabledLocalhost={disabledCrasLocalHost}
              localhost={localhostCras}
              onClickLocalhost={onClickLocalhostCras}
            />
            <FormPort label="Port" name="crasPort" disabled={disabledCrasInput} />
          </FormInnerSection>
          <Divider type="vertical" css={formDividerVStyle} />
          <FormInnerSection>
            <SettingTitle title="Email Server Setting" status={emailStatus} requestStatus={requestEmailStatus}>
              <Tooltip title="Send test email">
                <MailOutlined css={hoverActiveStyle} onClick={requestSendEmail} />
              </Tooltip>
            </SettingTitle>
            <FormIpAddress label="Address" name="emailAddress" disabled={disabledEmailInput} />
            <FormPort label="Port" name="emailPort" disabled={disabledEmailInput} />
            <FormEmail label={`Sender's E-mail`} name="emailFrom" disabled={disabledEmailInput} />
            <Form.Item name="emailAuth" valuePropName="checked">
              <Checkbox disabled={drawerType === 'info'} onChange={onChangeEmailAuth}>
                Authentication
              </Checkbox>
            </Form.Item>
            {emailAuth && (
              <Fragment>
                <FormName label="User Name" name="emailUserName" disabled={disabledEmailInput} />
                <FormPassword
                  label="Password"
                  name="emailPassword"
                  disabled={disabledEmailInput}
                  onClick={resetEmailPassword}
                />
              </Fragment>
            )}
          </FormInnerSection>
          <Divider type="vertical" css={formDividerVStyle} />
          <FormInnerSection>
            <Form.Item css={settingTitleFormStyle}>
              <SettingTitle
                title="Rapid Collector Server Setting"
                status={rssStatus}
                requestStatus={requestRssStatus}
              />
            </Form.Item>
            <FormIpAddressWithLocalhost
              label="Address"
              name="rssAddress"
              disabled={disabledRssIPAddressInput}
              disabledLocalhost={disabledRssLocalHost}
              localhost={localhostRss}
              onClickLocalhost={onClickLocalhostRss}
            />
            <FormPort label="Port" name="rssPort" disabled={disabledRssInput} />
            <FormName label="User Name" name="rssUserName" disabled={disabledRssInput} />
            <FormPassword label="Password" name="rssPassword" disabled={disabledRssInput} onClick={resetRssPassword} />
          </FormInnerSection>
        </FormInnerContainer>

        <Divider type="horizontal" css={formDividerHStyle} />

        {drawerType !== 'info' && (
          <Form.Item css={formSubmitStyle}>
            <Button
              type="primary"
              htmlType="submit"
              css={applyBtnstyle}
              loading={isRequestAddEdit}
              disabled={disabledApply}
            >
              {drawerType == 'add' ? 'Add' : 'Edit'}
            </Button>
          </Form.Item>
        )}

        <Form.Item hidden noStyle name="siteId" />
      </Form>
    </Drawer>
  );
}

const formSubmitStyle = css`
  .ant-form-item-control-input-content {
    display: flex;
    justify-content: center;
    align-items: center;
  }
`;

const applyBtnstyle = css`
  width: 20rem;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 10px;
  margin-top: 1rem;
`;

const FormInnerContainer = styled(Row)`
  flex-direction: row;
  flex-wrap: nowrap;
  /* width: 41rem; */
`;
const FormInnerSection = styled(Col)`
  width: 20rem;
`;

const formDividerHStyle = css``;

const formDividerVStyle = css`
  height: auto;
  margin-left: 1rem;
  margin-right: 1rem;
`;

interface SettingTitleProps {
  title: string;
  status: TestConnStatusType;
  requestStatus(): void;
  children?: ReactNode;
}
function SettingTitle({ title, status, requestStatus, children }: SettingTitleProps) {
  const statusText = useMemo(() => {
    switch (status) {
      case 'success':
        return 'Success';
      case 'processing':
        return 'Processing';
      case 'error':
        return 'Error';
      case 'error(cras_info)':
        return "Error (Please input 'Cras Server Setting Info'.)";
      default:
        return 'Click the Icon to test the connection';
    }
  }, [status]);

  const statusIcon = useMemo(() => {
    switch (status) {
      case 'error(cras_info)':
        return 'error';
      default:
        return status;
    }
  }, [status]);

  return (
    <Form.Item css={settingTitleFormStyle}>
      <div css={settingTitleStyle}>
        <Space>
          <div className="title-text">{title}</div>
          {status === 'processing' ? (
            <Spin size={'small'} />
          ) : (
            <ApiOutlined css={hoverActiveStyle} onClick={requestStatus} />
          )}
          {children}
        </Space>
        <div>
          <Badge status={statusIcon} text={statusText} css={settingTitleBadgeStyle} />
        </div>
      </div>
    </Form.Item>
  );
}

const settingTitleFormStyle = css`
  margin-bottom: 0;
`;

const settingTitleStyle = css`
  display: flex;
  flex-direction: column;
  .title-text {
    font-weight: 700;
    font-size: 1rem;
  }
  margin-bottom: 0.5rem;
`;

const settingTitleBadgeStyle = css`
  margin-left: 0.5rem;
`;
