import { DatabaseOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { Descriptions, Row, Space } from 'antd';
import React from 'react';
import RefreshBtn from '../common/atoms/RefreshBtn/RefreshBtn';
import TableHeader from '../common/atoms/TableHeader';
import { useHostDBinfo } from './hooks/useHostDBinfo';
export type HostDBSettingProps = {};

export default function HostDBSetting({}: HostDBSettingProps): JSX.Element {
  const { data, isFetching, refreshHostDBinfo } = useHostDBinfo();

  return (
    <DbInfo>
      <TableHeader
        title={
          <Space>
            <DatabaseOutlined />
            <div>Settings Database Information</div>
          </Space>
        }
        cssStyle={tableHeaderStyle}
      >
        <RefreshBtn type="primary" onClick={refreshHostDBinfo} disabled={isFetching} loading={isFetching} />
      </TableHeader>
      <DBInfoSection css={descriptionsStyle}>
        <Descriptions
          bordered
          column={4}
          size="small"
          contentStyle={{ textAlign: 'center' }}
          labelStyle={{ textAlign: 'center' }}
        >
          <Descriptions.Item label="IP Address">{data?.address ?? '-'}</Descriptions.Item>
          <Descriptions.Item label="Port">{data?.port || '-'}</Descriptions.Item>
          <Descriptions.Item label="User">{data?.user || '-'}</Descriptions.Item>
        </Descriptions>
      </DBInfoSection>
    </DbInfo>
  );
}

const tableHeaderStyle = css`
  background: linear-gradient(90deg, #bae7ff 0.87%, rgba(255, 255, 255, 0) 100%);
  height: 3.125rem;
  .title {
    font-size: 1.125rem;
    margin-left: 0.5rem;
  }
`;

const DbInfo = styled(Row)`
  padding-left: 0.5rem;
  padding-right: 0.5rem;
  padding-top: 0.5rem;
  flex-direction: column;
  width: 100%;
`;

const DBInfoSection = styled(Row)``;

const descriptionsStyle = css`
  margin-left: 0.8rem;
  margin-right: 0.8rem;
  margin-top: 0.8rem;
  .ant-descriptions-item-label {
    /* width: 10.4375rem; */
    width: 13.917rem;
  }
  .ant-descriptions-item-content {
    /* width: 10.4375rem; */
    width: 13.917rem;
  }
`;
