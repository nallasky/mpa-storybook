import { css } from '@emotion/react';
import SitesSetting from './SitesSetting';

export type ConfigSettingProps = {};

export default function ConfigSetting({}: ConfigSettingProps): JSX.Element {
  return (
    <div css={style}>
      {/* <div>
        <HostDBSetting />
      </div> */}
      <div>
        <SitesSetting />
      </div>
    </div>
  );
}

const style = css`
  width: 100%;
`;
