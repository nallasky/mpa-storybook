export { default } from './ConfigSetting';
