import { useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { getHostDBInfo } from '../../../libs/axios/requests';
import { ResGetHostDBInfo } from '../../../libs/axios/types';
import { openNotification } from '../../../libs/util/notification';

export function useHostDBinfo() {
  const { data, isFetching, isError } = useQuery<ResGetHostDBInfo>(['get_config_host_db'], getHostDBInfo, {
    refetchOnWindowFocus: false,
    onError: () => {
      openNotification('error', 'Error', 'Failed to response setting database information.');
    },
  });
  const queryClient = useQueryClient();

  const refreshHostDBinfo = useCallback(() => {
    queryClient.fetchQuery(['get_config_host_db']);
  }, [queryClient]);

  return {
    data,
    isFetching,
    refreshHostDBinfo,
    isError,
  };
}
