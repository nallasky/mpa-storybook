import { openAntdModal } from '@components/common/atoms/AntdModal';
import { css } from '@emotion/react';
import { deleteSiteDBInfo, getConfigureExport, getSiteJobStatus } from '@libs/axios/requests';
import { SiteDBInfo } from '@libs/axios/types';
import { useGetConfigureSites } from '@libs/query/configureSetting';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import {
  setSiteInfoDrawer,
  setSiteInfoDrawerType,
  setSiteInfoHasRunningJobs,
  setSiteInfoIsImport,
  setSiteInfoSelectedSite,
} from '@reducers/slices/configure';
import { useQueryClient } from '@tanstack/react-query';
import { AxiosError } from 'axios';
import { saveAs } from 'file-saver';
import { useCallback, useMemo } from 'react';
import { batch, useDispatch } from 'react-redux';

export default function useSiteDBInfoTable() {
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const { data, isFetching } = useGetConfigureSites({
    onError: (error) => {
      openNotification('error', 'Error', 'Failed to response setting database information.', error);
    },
  });

  const refreshSiteList = useCallback(() => {
    queryClient.fetchQuery([QUERY_KEY.CONFIGURE_SITES]);
  }, [queryClient]);

  const siteListLen = useMemo(() => (data?.length ? data.length : 0), [data?.length]);

  const openAddDrawer = useCallback(() => {
    batch(() => {
      dispatch(setSiteInfoSelectedSite(undefined));
      dispatch(setSiteInfoDrawerType('add'));
      dispatch(setSiteInfoDrawer(true));
    });
  }, [dispatch]);

  const openEditDrawer = useCallback(
    (selectedSite: SiteDBInfo) => {
      batch(() => {
        dispatch(setSiteInfoSelectedSite(selectedSite));
        dispatch(setSiteInfoDrawerType('edit'));
        dispatch(setSiteInfoDrawer(true));
      });
    },
    [dispatch],
  );

  const openInfoDrawer = useCallback(
    (selectedSite: SiteDBInfo) => {
      batch(() => {
        dispatch(setSiteInfoSelectedSite(selectedSite));
        dispatch(setSiteInfoDrawerType('info'));
        dispatch(setSiteInfoDrawer(true));
      });
    },
    [dispatch],
  );

  const executeEditModal = useCallback(
    (selectedSite: SiteDBInfo) => {
      openAntdModal('confirm', {
        className: 'edit-site-setting',
        title: 'Edit Site Information',
        content: `Are you sure to edit a site '${selectedSite.crasCompanyFabName}'?`,
        okText: 'Edit',
        onOk: async () => {
          try {
            const { status } = await getSiteJobStatus(selectedSite.siteId);
            if (status === 'running') {
              dispatch(setSiteInfoHasRunningJobs(true));
              // If there is a job, it is modified so that only email settings are possible.
              // openNotification(
              //   'error',
              //   'Error',
              //   `Before editing the site, stop the registered job '${selectedSite.crasCompanyFabName}'!`,
              // );
              // refreshSiteList();
              // return;
            } else {
              dispatch(setSiteInfoHasRunningJobs(false));
            }
          } catch (e) {
            openNotification(
              'error',
              'Error',
              `Failed to edit a site '${selectedSite.crasCompanyFabName}'!`,
              e as AxiosError,
            );
            refreshSiteList();
          }
          openEditDrawer(selectedSite);
        },
      });
    },
    [refreshSiteList, openEditDrawer, dispatch],
  );

  const executeEditWarnModal = useCallback((selectedSite: SiteDBInfo) => {
    openAntdModal('warning', {
      className: 'edit-site-warn-setting',
      title: 'Edit Site Warning',
      content: `After deleting all the jobs registered in '${selectedSite.crasCompanyFabName}', execute Edit again!`,
      okText: 'Close',
    });
  }, []);

  const openEditModal = useCallback(
    (selectedSite: SiteDBInfo) => {
      executeEditModal(selectedSite);
    },
    [executeEditModal],
    // async (selectedSite: SiteDBInfo) => {
    //   try {
    //     const registeredJobs = await getStatusRegisteredJobForSite(selectedSite.siteId);
    //     if (Array.isArray(registeredJobs) && registeredJobs.length > 0) {
    //       executeEditWarnModal(selectedSite);
    //     } else {
    //       executeEditModal(selectedSite);
    //     }
    //   } catch (e) {
    //     openNotification(
    //       'error',
    //       'Error',
    //       `Failed to get registered job for '${selectedSite.crasCompanyFabName}'!`,
    //       e as AxiosError,
    //     );
    //   }
    // },
    // [executeEditModal, executeEditWarnModal],
  );

  const openDeleteModal = useCallback(
    (siteId: number, crasCompanyFabName: string) => {
      openAntdModal('confirm', {
        className: 'delete-site-setting',
        title: 'Delete Site Information',
        content: (
          <div css={warningStyle}>
            <div>All saved Jobs will be stopped and deleted.</div>
            <div>{`Are you sure to delete a site '${crasCompanyFabName}'?`}</div>
          </div>
        ),
        okText: 'Delete',
        onOk: async () => {
          try {
            // const { status } = await getSiteJobStatus(siteId);
            // if (status === 'running') {
            //   openNotification(
            //     'error',
            //     'Error',
            //     `Before deleting the site, stop the registered job '${crasCompanyFabName}'!`,
            //   );
            //   refreshSiteList();
            //   return;
            // }

            await deleteSiteDBInfo(siteId);
            openNotification('success', 'Success', `Succeed to delete a site '${crasCompanyFabName}'.`);
          } catch (e) {
            openNotification('error', 'Error', `Failed to delete a site '${crasCompanyFabName}'!`, e as AxiosError);
          } finally {
            refreshSiteList();
          }
        },
      });
    },
    [refreshSiteList],
  );

  const openExportModal = () => {
    openAntdModal('confirm', {
      className: 'export-configure',
      title: 'Export Configure',
      content: 'Are you sure to export configure?',
      okText: 'Export',
      onOk: async () => {
        try {
          const { data, fileName } = await getConfigureExport();
          saveAs(data, fileName);
          openNotification('success', 'Success', `Succeed to export configure '${fileName}'.`);
        } catch (e) {
          console.error(e);
          openNotification('error', 'Error', 'Failed to export configure!', e as AxiosError);
        }
      },
    });
  };

  const openImportModal = useCallback(async () => {
    // try {
    //   const { status } = await getSiteStatus();
    //   if (status === 'running') {
    //     openNotification('error', 'Error', `Before deleting the site, stop the registered job!`);
    //     refreshSiteList();
    //   } else {
    //     dispatch(setSiteInfoIsImport(true));
    //   }
    // } catch (e) {
    //   openNotification('error', 'Error', `Failed to get configure status!`, e as AxiosError);
    // }
    dispatch(setSiteInfoIsImport(true));
  }, [dispatch]);

  return {
    isFetchingSiteList: isFetching,
    siteList: data,
    siteListLen,
    refreshSiteList,
    openAddDrawer,
    openEditModal,
    openDeleteModal,
    openExportModal,
    openImportModal,
    openInfoDrawer,
  };
}

const warningStyle = css`
  display: flex;
  flex-direction: column;
  color: red;
`;
