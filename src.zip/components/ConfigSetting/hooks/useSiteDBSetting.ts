import { DEFAULT_PASSWORD_VALUE, DISPLAY_LOCALHOST_NAME } from '@constants/constants';
import {
  postCrasConnection,
  postEmailConnection,
  postEmailSend,
  postRssConnection,
  postSiteDBInfo,
  putSiteDBInfo,
} from '@libs/axios/requests';
import {
  ClientError,
  ReqPostCrasConnection,
  ReqPostEmailConnection,
  ReqPostRssConnection,
  ReqPostSiteDBInfo,
  ReqPutSiteDBInfo,
  SiteDBInfo,
} from '@libs/axios/types';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import {
  setSiteInfoDrawer,
  setSiteInfoHasRunningJobs,
  SiteDrawerOpenType,
  siteInfoDrawerType,
  siteInfoHasRunningJobs,
  siteInfoIsDrawer,
  siteInfoSelectedSite,
} from '@reducers/slices/configure';
import useTypedSelector from '@reducers/useTypedSelector';
import { useIsMutating, useMutation, useQueryClient } from '@tanstack/react-query';
import { AntdFieldData } from '@typesdef/antd';
import { Form } from 'antd';
import { CheckboxChangeEvent } from 'antd/es/checkbox';
import { SwitchClickEventHandler } from 'antd/es/switch';
import { PresetStatusColorType } from 'antd/es/_util/colors';
import { useWatch } from 'antd/es/form/Form';
import axios, { AxiosError } from 'axios';
import md5 from 'md5';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';

export type TestConnStatusType = PresetStatusColorType | 'error(cras_info)';

export default function useSiteDBSetting() {
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const [crasStatus, setCrasStatus] = useState<TestConnStatusType>('default');
  const [emailStatus, setEmailStatus] = useState<TestConnStatusType>('default');
  const [rssStatus, setRssStatus] = useState<TestConnStatusType>('default');
  const [localRssPassword, setLocalRssPassword] = useState('');
  const [localEmailPassword, setLocalEmailPassword] = useState('');
  const isDrawer = useTypedSelector(siteInfoIsDrawer);
  const drawerType = useTypedSelector(siteInfoDrawerType);
  const selectedSite = useTypedSelector(siteInfoSelectedSite);
  const [form] = Form.useForm<SiteDBInfo>();
  const [localhostCras, setLocalhostCras] = useState(false);
  const [localhostRss, setLocalhostRss] = useState(false);
  const isPrevDrawerRef = useRef<boolean | undefined>();
  const hasRunningJobs = useTypedSelector(siteInfoHasRunningJobs);
  const emailAuth = useWatch<boolean>('emailAuth', form);

  const crasMutation = useMutation((postData: ReqPostCrasConnection) => postCrasConnection(postData), {
    mutationKey: ['connection_test_cras_server'],
    onError: (error) => {
      setCrasStatus('error');
      if (axios.isAxiosError(error)) {
        const reason = (error as AxiosError<{ message: string }>)?.response?.data?.message ?? '';
        if (reason) {
          openNotification('error', 'Error', `Failed to connect to cras server!`, error);
        }
      }
    },
    onSuccess: () => {
      setCrasStatus('success');
    },
  });
  const emailMutation = useMutation((postData: ReqPostEmailConnection) => postEmailConnection(postData), {
    mutationKey: ['connection_test_email_server'],
    onError: (error) => {
      setEmailStatus('error');
      if (axios.isAxiosError(error)) {
        const reason = (error as AxiosError<{ message: string }>)?.response?.data?.message ?? '';
        if (reason) {
          openNotification('error', 'Error', `Failed to connect to email server!`, error);
        }
      }
    },
    onSuccess: () => {
      setEmailStatus('success');
    },
  });

  const emailSendMutation = useMutation((postData: ReqPostEmailConnection) => postEmailSend(postData), {
    mutationKey: ['send_test_email_server'],
    onError: (error) => {
      let axiosError: AxiosError | undefined;
      if (axios.isAxiosError(error)) {
        const reason = (error as AxiosError<{ message: string }>)?.response?.data?.message ?? '';
        if (reason) {
          axiosError = error;
        }
      }
      openNotification('error', 'Error', `Failed to send test email!`, axiosError);
    },
    onSuccess: () => {
      openNotification('success', 'Success', 'Succeed to send test email.');
    },
  });

  const rssMutation = useMutation((postData: ReqPostRssConnection) => postRssConnection(postData), {
    mutationKey: ['connection_test_rss_server'],
    onError: () => {
      setRssStatus('error');
    },
    onSuccess: () => {
      setRssStatus('success');
    },
  });
  const addMutation = useMutation((postData: ReqPostSiteDBInfo) => postSiteDBInfo(postData), {
    mutationKey: ['add_config_site_db_info'],
    onError: (resData: AxiosError<ClientError>) => {
      openNotification('error', 'Error', resData.response?.data.errorMsg ?? 'Failed to add settings server info.');
      if (resData.response?.status !== 400) {
        // not bad request
        dispatch(setSiteInfoDrawer(false));
      }
    },
    onSuccess: () => {
      dispatch(setSiteInfoDrawer(false));
      openNotification('success', 'Success', 'Succeed to add settings server info.');
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.CONFIGURE_SITES], {
        exact: true,
      });
    },
  });
  const editMutation = useMutation((reqData: ReqPutSiteDBInfo) => putSiteDBInfo(reqData), {
    mutationKey: ['modify_config_site_db_info'],
    onError: (resData: AxiosError<ClientError>) => {
      openNotification('error', 'Error', resData.response?.data.errorMsg ?? 'Failed to edit settings server info.');
      if (resData.response?.status !== 400) {
        // not bad request
        dispatch(setSiteInfoDrawer(false));
      }
    },
    onSuccess: () => {
      dispatch(setSiteInfoDrawer(false));
      openNotification('success', 'Success', 'Succeed to edit settings server info.');
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.CONFIGURE_SITES], {
        exact: true,
      });
    },
  });

  const isMutatingEdit = useIsMutating({ mutationKey: ['modify_config_site_db_info'] }) > 0 ? true : false;
  const isMutatingAdd = useIsMutating({ mutationKey: ['add_config_site_db_info'] }) > 0 ? true : false;
  const isRequestAddEdit = isMutatingEdit || isMutatingAdd;

  const testCrasServer = useCallback(
    (postData: ReqPostCrasConnection) => {
      setCrasStatus('processing');
      crasMutation.mutate(postData);
    },
    [crasMutation, setCrasStatus],
  );

  const testEmailServer = useCallback(
    (postData: ReqPostEmailConnection) => {
      setEmailStatus('processing');
      if (postData.emailPassword === DEFAULT_PASSWORD_VALUE) postData.emailPassword = localEmailPassword;
      emailMutation.mutate(postData);
    },
    [emailMutation, setEmailStatus, localEmailPassword],
  );

  const testRssServer = useCallback(
    (postData: ReqPostRssConnection) => {
      setRssStatus('processing');
      if (postData.rssPassword === DEFAULT_PASSWORD_VALUE) {
        postData.rssPassword = localRssPassword;
      } else {
        if (postData.rssPassword) postData.rssPassword = md5(postData.rssPassword);
        else postData.rssPassword = '';
      }
      rssMutation.mutate(postData);
    },
    [rssMutation, setRssStatus, localRssPassword],
  );

  const closeDrawer = useCallback(() => {
    if (isMutatingEdit || isMutatingAdd) return;
    dispatch(setSiteInfoDrawer(false));
  }, [dispatch, isMutatingEdit, isMutatingAdd]);

  const requestAdd = useCallback(
    (reqData: ReqPostSiteDBInfo) => {
      // MD5 encryption
      reqData.rssPassword = md5(reqData.rssPassword);
      addMutation.mutate(reqData);
    },
    [addMutation],
  );

  const requestEdit = useCallback(
    (reqData: ReqPutSiteDBInfo) => {
      if (reqData.emailPassword === DEFAULT_PASSWORD_VALUE) {
        reqData.emailPassword = localEmailPassword;
      }

      if (reqData.rssPassword === DEFAULT_PASSWORD_VALUE) {
        reqData.rssPassword = localRssPassword;
      } else {
        // MD5 encryption
        reqData.rssPassword = md5(reqData.rssPassword);
      }

      editMutation.mutate(reqData);
    },
    [editMutation, localRssPassword, localEmailPassword],
  );

  const serverRequest = useCallback(
    (type: SiteDrawerOpenType, data: SiteDBInfo) => {
      if (type === 'add') {
        requestAdd(data);
      } else {
        requestEdit(data);
      }
    },
    [requestAdd, requestEdit],
  );

  const requestCrasStatus = useCallback(() => {
    const crasAddress = form.getFieldValue('crasAddress');
    const crasPort = form.getFieldValue('crasPort');
    testCrasServer({ crasAddress, crasPort });
  }, [form, testCrasServer]);

  const requestEmailStatus = useCallback(() => {
    const { emailAddress, emailPort, emailPassword, emailUserName, emailFrom, emailAuth } = form.getFieldsValue();
    testEmailServer({ emailAddress, emailPort, emailUserName, emailPassword, emailFrom, emailAuth });
  }, [form, testEmailServer]);

  const requestSendEmail = useCallback(() => {
    const { emailAddress, emailPort, emailPassword, emailUserName, emailFrom, emailAuth } = form.getFieldsValue();
    const requestData = {
      emailAddress,
      emailPort,
      emailPassword,
      emailUserName,
      emailFrom,
      emailAuth,
    };
    if (requestData.emailPassword === DEFAULT_PASSWORD_VALUE) {
      requestData.emailPassword = localEmailPassword;
    }
    emailSendMutation.mutate(requestData);
  }, [emailSendMutation, localEmailPassword, form]);

  const requestRssStatus = useCallback(() => {
    const rssAddress = form.getFieldValue('rssAddress');
    const rssPort = form.getFieldValue('rssPort');
    const rssUserName = form.getFieldValue('rssUserName');
    const rssPassword = form.getFieldValue('rssPassword');
    const crasAddress = form.getFieldValue('crasAddress');
    const crasPort = form.getFieldValue('crasPort');

    if (!crasAddress || !crasPort) {
      setRssStatus('error(cras_info)');
    } else {
      testRssServer({ rssAddress, rssPort, rssUserName, rssPassword, crasAddress, crasPort });
    }
  }, [form, testRssServer, setRssStatus]);

  const disabledCrasInput = useMemo(
    () => crasStatus === 'processing' || rssStatus === 'processing' || drawerType === 'info' || hasRunningJobs,
    [crasStatus, rssStatus, drawerType, hasRunningJobs],
  );

  const disabledCrasIPAddressInput = useMemo(
    () =>
      crasStatus === 'processing' ||
      rssStatus === 'processing' ||
      localhostCras ||
      drawerType === 'info' ||
      hasRunningJobs,
    [localhostCras, crasStatus, rssStatus, drawerType, hasRunningJobs],
  );

  const disabledCrasLocalHost = useMemo(
    () => crasStatus === 'processing' || rssStatus === 'processing' || drawerType === 'info' || hasRunningJobs,
    [crasStatus, rssStatus, drawerType, hasRunningJobs],
  );

  const disabledRssIPAddressInput = useMemo(
    () =>
      crasStatus === 'processing' ||
      rssStatus === 'processing' ||
      localhostRss ||
      drawerType === 'info' ||
      hasRunningJobs,
    [localhostRss, crasStatus, rssStatus, drawerType, hasRunningJobs],
  );

  const disabledRssLocalHost = useMemo(
    () => crasStatus === 'processing' || rssStatus === 'processing' || drawerType === 'info' || hasRunningJobs,
    [crasStatus, rssStatus, drawerType, hasRunningJobs],
  );

  const disabledRssInput = useMemo(
    () => rssStatus === 'processing' || drawerType === 'info' || hasRunningJobs,
    [rssStatus, drawerType, hasRunningJobs],
  );

  const disabledEmailInput = useMemo(
    () => emailStatus === 'processing' || drawerType === 'info',
    [emailStatus, drawerType],
  );

  const disabledApply = useMemo(
    () => crasStatus === 'processing' || emailStatus === 'processing' || rssStatus === 'processing' || isRequestAddEdit,
    [crasStatus, emailStatus, rssStatus, isRequestAddEdit],
  );

  const onFinish = useCallback(
    (value: SiteDBInfo) => {
      serverRequest(drawerType, value);
    },
    [drawerType, serverRequest],
  );

  const resetRssPassword = () => {
    form.setFieldsValue({
      rssPassword: '',
    });
  };

  const resetEmailPassword = () => {
    form.setFieldsValue({
      emailPassword: '',
    });
  };

  const onClickLocalhostCras: SwitchClickEventHandler = useCallback(
    (check, event) => {
      if (check) {
        setLocalhostCras(true);
        form.setFieldsValue({
          crasAddress: DISPLAY_LOCALHOST_NAME,
        });
      } else {
        form.resetFields(['crasAddress']);
        setLocalhostCras(false);
      }
    },
    [setLocalhostCras, form],
  );

  const onClickLocalhostRss: SwitchClickEventHandler = useCallback(
    (check, event) => {
      if (check) {
        setLocalhostRss(true);
        form.setFieldsValue({
          rssAddress: DISPLAY_LOCALHOST_NAME,
        });
      } else {
        form.resetFields(['rssAddress']);
        setLocalhostRss(false);
      }
    },
    [setLocalhostRss, form],
  );

  const initStatus = () => {
    setCrasStatus('default');
    setEmailStatus('default');
    setRssStatus('default');
  };

  const setFormData = useCallback((selectedSite: SiteDBInfo | undefined): AntdFieldData[] => {
    if (selectedSite === undefined) {
      return [];
    }
    return Object.entries(selectedSite).map(([key, value]) => {
      if (key === 'emailPassword') {
        setLocalEmailPassword(value);
        value = DEFAULT_PASSWORD_VALUE;
      }
      if (key === 'rssPassword') {
        setLocalRssPassword(value);
        value = DEFAULT_PASSWORD_VALUE;
      }
      if (key === 'crasAddress')
        if (value === DISPLAY_LOCALHOST_NAME) {
          setLocalhostCras(true);
        } else {
          setLocalhostCras(false);
        }
      if (key === 'rssAddress') {
        if (value === DISPLAY_LOCALHOST_NAME) {
          setLocalhostRss(true);
        } else {
          setLocalhostRss(false);
        }
      }

      return {
        name: key,
        value: value,
      };
    });
  }, []);

  const onChangeEmailAuth = ({ target: { checked } }: CheckboxChangeEvent) => {
    form.setFieldsValue({
      emailAuth: checked,
      emailUserName: '',
      emailPassword: '',
    });
  };

  useEffect(() => {
    if (isPrevDrawerRef.current !== isDrawer) {
      if (isDrawer) {
        if (drawerType !== 'add') {
          const formData = setFormData(selectedSite);
          if (formData.length > 0) {
            form.setFields(formData);
          }
        }
      } else {
        setLocalRssPassword('');
        setLocalEmailPassword('');
        setLocalhostCras(false);
        setLocalhostRss(false);
        form.resetFields();
        form.setFieldValue('emailAuth', false);
        initStatus();
        dispatch(setSiteInfoHasRunningJobs(false));
      }
      isPrevDrawerRef.current = isDrawer;
    }
  }, [isDrawer, drawerType, form, selectedSite, setFormData, dispatch]);

  return {
    form,
    onFinish,
    crasStatus,
    emailStatus,
    rssStatus,
    initStatus,
    isDrawer,
    drawerType,
    closeDrawer,
    isRequestAddEdit,
    localhostCras,
    localhostRss,
    onClickLocalhostCras,
    onClickLocalhostRss,
    requestCrasStatus,
    requestEmailStatus,
    requestSendEmail,
    requestRssStatus,
    disabledCrasInput,
    disabledCrasIPAddressInput,
    disabledRssIPAddressInput,
    disabledCrasLocalHost,
    disabledRssLocalHost,
    disabledEmailInput,
    disabledRssInput,
    resetRssPassword,
    resetEmailPassword,
    disabledApply,
    emailAuth,
    onChangeEmailAuth,
  };
}
