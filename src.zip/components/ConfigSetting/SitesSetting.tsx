import { css } from '@emotion/react';
import SitesSettingAddEdit from './SitesSettingAddEdit';
import SitesSettingTable from './SitesSettingTable';

export type SitesSettingProps = {};

export default function SitesSetting({}: SitesSettingProps): JSX.Element {
  return (
    <div css={style}>
      <SitesSettingTable />
      <SitesSettingAddEdit />
    </div>
  );
}

const style = css`
  width: 100%;
`;
