import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { RemoteJobType } from '@typesdef/Job';
import { Button, Col, Space } from 'antd';
import React, { useCallback, useState } from 'react';

export type StopButtonProps = {
  current: number;
  onNext: () => void;
  onPrev: () => void;
  lastStep: number;
  onLast?: () => void;
  nextAction?: () => boolean;
  nextActionPromise?: () => Promise<boolean>;
  type?: RemoteJobType;
  title?: string;
  disabled?: boolean;
};

const Container = styled(Col)`
  /* display: flex;
  justify-content: space-between;
  width: 47.125rem;
  margin-left: 29.375rem;
  margin-right: 1.75rem; */
`;

function StepButton({
  current,
  onNext,
  onPrev,
  lastStep,
  onLast,
  nextAction,
  nextActionPromise,
  type = 'add',
  title,
  disabled = false,
}: StopButtonProps): JSX.Element {
  const [loading, setLoading] = useState(false);

  const onHandleNext = useCallback(() => {
    if (current <= lastStep && nextAction && nextAction()) {
      if (current !== lastStep) {
        onNext();
      } else {
        onLast && onLast();
      }
    }
  }, [current, onNext, nextAction, lastStep, onLast]);

  const onHandleNextPromise = useCallback(async () => {
    setLoading(true);
    if (current <= lastStep && nextActionPromise && (await nextActionPromise())) {
      if (current !== lastStep) {
        onNext();
      } else {
        onLast && onLast();
      }
    }

    setLoading(false);
  }, [current, onNext, nextActionPromise, lastStep, onLast]);

  const onHandlePrev = useCallback(() => {
    if (current > 0) onPrev();
  }, [current, onPrev]);

  return (
    <Container>
      {title ? (
        <div css={titleStepStyle}>
          <div className="prev">
            {current > 0 ? (
              <Button
                type="primary"
                css={btnStyle}
                onClick={onHandlePrev}
                loading={loading}
                disabled={loading || disabled}
              >
                Prev
              </Button>
            ) : (
              <div className="prev-empty"></div>
            )}
          </div>
          <div className="title">{title}</div>
          <div className="next">
            {current < lastStep ? (
              <Button
                type="primary"
                css={btnStyle}
                onClick={nextActionPromise ? onHandleNextPromise : onHandleNext}
                loading={loading}
                disabled={loading || disabled}
              >
                Next
              </Button>
            ) : (
              <Button
                type="primary"
                css={btnStyle}
                onClick={nextActionPromise ? onHandleNextPromise : onHandleNext}
                loading={loading}
                disabled={loading || disabled}
              >
                {type === 'add' ? 'Add' : 'Edit'}
              </Button>
            )}
          </div>
        </div>
      ) : (
        <Space>
          {current > 0 && (
            <Button type="primary" css={btnStyle} disabled={loading || disabled} onClick={onHandlePrev}>
              Prev
            </Button>
          )}
          {current < lastStep && (
            <Button
              type="primary"
              css={btnStyle}
              loading={loading}
              disabled={loading || disabled}
              onClick={nextActionPromise ? onHandleNextPromise : onHandleNext}
            >
              Next
            </Button>
          )}
          {current >= lastStep && (
            <Button
              type="primary"
              css={btnStyle}
              loading={loading}
              disabled={loading || disabled}
              onClick={nextActionPromise ? onHandleNextPromise : onHandleNext}
            >
              {type === 'add' ? 'Add' : 'Edit'}
            </Button>
          )}
        </Space>
      )}
    </Container>
  );
}

export default React.memo(StepButton);

const btnStyle = css`
  border-radius: 0.625rem;
  width: 5rem;
`;

const titleStepStyle = css`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  .title {
    font-size: 1.5rem;
  }
  .prev {
    margin-left: 0.5rem;
    .prev-empty {
      width: 4rem;
      height: 2rem;
      margin-right: 0.5rem;
    }
  }
  .next {
    margin-right: 0.5rem;
  }
`;
