import { css } from '@emotion/react';
import { Steps } from 'antd';
import React, { useCallback } from 'react';

export type SideStepsProps = {
  current: number;
  stepList: string[];
  direction?: 'horizontal' | 'vertical';
};

function SideSteps({ current, stepList, direction = 'vertical' }: SideStepsProps): JSX.Element {
  const getDescription = useCallback(
    (step: number) => {
      if (current === step) {
        return 'Processing';
      } else if (current < step) {
        return 'Waiting';
      } else if (current > step) {
        return 'Finished';
      }
    },
    [current],
  );

  return (
    <Steps current={current} direction={direction} css={stepStyle(direction)}>
      {stepList && stepList.map((item, idx) => <Steps.Step key={idx} title={item} description={getDescription(idx)} />)}
    </Steps>
  );
}

const verticalStyle = css`
  height: 40rem;
  flex-wrap: nowrap;
  border-right: 1px solid #d9d9d9;
  width: 15rem;
  .ant-steps-item {
    width: 15rem;
  }
`;

const horizontalStyle = css`
  padding-left: 1.5rem;
  padding-right: 1.5rem;
`;

const stepStyle = (direction: 'horizontal' | 'vertical') => css`
  ${direction === 'vertical' ? verticalStyle : horizontalStyle}
`;

export default React.memo(SideSteps);
