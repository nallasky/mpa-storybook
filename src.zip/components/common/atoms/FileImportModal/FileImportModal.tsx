import { InboxOutlined } from '@ant-design/icons';
import CustomIcon from '@components/common/atoms/CustomIcon';
import { css } from '@emotion/react';
import { QueryKey } from '@tanstack/react-query';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Modal, Space } from 'antd';
import Dragger from 'antd/es/upload/Dragger';
import { AxiosError } from 'axios';
import { Fragment, memo } from 'react';
import useConvertFileImport from './hooks/useFileImportModal';

export interface FileImportModalProps<T = unknown> {
  title?: string;
  okText?: string;
  url: string;
  uploadText?: string;
  mutationKey: QueryKey;
  afterError?: (error: AxiosError) => void;
  afterSuccess?: (data: T) => void;
  afterSettled?: () => void;
}

export default memo(function FileImportModal<T>({
  visible,
  onClose,
  title = 'Import',
  okText = 'Import',
  uploadText = 'Click or drag file to this area to upload.',
  url,
  mutationKey,
  afterError,
  afterSuccess,
  afterSettled,
}: GlobalModalDefaultProps<FileImportModalProps<T>>): JSX.Element {
  const { importFile, isImporting, handleOk, draggerProps } = useConvertFileImport({
    visible,
    onClose,
    title,
    url,
    mutationKey,
    afterError,
    afterSuccess,
    afterSettled,
  });

  return (
    <Modal
      title={title}
      open={visible}
      okText={okText}
      onOk={handleOk}
      okButtonProps={{ loading: isImporting, disabled: isImporting || !importFile }}
      onCancel={() => onClose()}
      cancelButtonProps={{
        disabled: isImporting,
      }}
      closable={!isImporting}
      maskClosable={!isImporting}
    >
      <Fragment>
        <div css={warningStyle}>
          <Space>
            <CustomIcon name="warning" />
            <div>All saved data will be deleted and replaced</div>
          </Space>
          <div>with data from the uploaded file.</div>
        </div>
        <Dragger {...draggerProps}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">{uploadText}</p>
        </Dragger>
      </Fragment>
    </Modal>
  );
});

const warningStyle = css`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  color: red;
  font-size: 1rem;
  margin-bottom: 1rem;
`;
