import { usePostFileImport } from '@libs/query/common';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { AxiosError } from 'axios';
import { useState } from 'react';
import { FileImportModalProps } from '../FileImportModal';

export default function useConvertFileImport<T>({
  visible,
  onClose,
  title,
  url,
  mutationKey,
  afterError,
  afterSuccess,
  afterSettled,
}: GlobalModalDefaultProps<FileImportModalProps<T>>) {
  const [importFile, setImportFile] = useState<File | undefined>(undefined);

  const { mutate: mutateImport, isLoading: isImporting } = usePostFileImport(mutationKey, {
    onError: (error: AxiosError) => {
      if (afterError) {
        afterError(error);
      }
    },
    onSuccess: (data) => {
      if (afterSuccess) {
        afterSuccess(data as T);
      }
    },
    onSettled: () => {
      if (afterSettled) {
        afterSettled();
      }
      onClose();
    },
  });

  const draggerProps = {
    name: 'file',
    multiple: false,
    maxCount: 1,
    beforeUpload: (file: File) => {
      setImportFile(file);
      return false;
    },
    onRemove: () => {
      setImportFile(undefined);
    },
  };

  const handleOk = () => {
    const formData = new FormData();
    formData.append('file', importFile as File);
    mutateImport({
      url,
      data: formData,
    });
  };

  return {
    importFile,
    isImporting,
    handleOk,
    draggerProps,
  };
}
