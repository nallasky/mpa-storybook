import { ClearOutlined } from '@ant-design/icons';
import { css, SerializedStyles } from '@emotion/react';
import { Badge, Button, Space } from 'antd';
import { PresetColorType } from 'antd/es/_util/colors';
import { LiteralUnion } from 'antd/es/_util/type';
import React, { Fragment } from 'react';
import { H_SPACE } from '../Space';

export type TableHeaderProps = {
  title?: React.ReactNode;
  cssStyle?: SerializedStyles;
  children?: React.ReactNode;
  isSeparated?: boolean;
};

const TableHeader = React.memo(function TableHeaderFunc({
  title,
  cssStyle,
  children,
  isSeparated = false,
}: TableHeaderProps): JSX.Element {
  return (
    <div css={[style(Boolean(title), isSeparated), cssStyle]}>
      <div className="left">{title}</div>
      <Space className="btns">{children}</Space>
    </div>
  );
});

const style = (isTitle = false, isSeparated: boolean) => css`
  display: flex;
  align-items: center;
  justify-content: ${isTitle ? 'space-between' : 'flex-end'};
  width: 100%;

  .left {
    font-size: 0.875rem;
  }

  .btns {
    .ant-btn {
      border-radius: 0.625rem;
    }
  }

  ${isSeparated &&
  css`
    border-top-width: 1px;
    border: 1px solid #f0f0f0;
    border-bottom: 0px;
    padding: 8px;
    border-radius: 2px 2px 0 0;
  `}
`;

export default TableHeader;

interface TableHeaderTitleProps {
  total: number;
  isSearched?: boolean;
  searchedText?: string;
  onResetSearch?: () => void;
  isFiltered?: boolean;
  FilteredText?: string;
  onResetFilter?: () => void;
  color?: LiteralUnion<PresetColorType, string>;
}

export const TableHeaderTitle = React.memo(function TableHeaderTitleFunc({
  total,
  isSearched = false,
  searchedText = '',
  onResetSearch,
  isFiltered,
  FilteredText,
  onResetFilter,
  color = 'blue',
}: TableHeaderTitleProps) {
  let totalText = 'Total';

  if (isSearched && isFiltered) {
    totalText = 'Searched & Filtered Total';
  } else if (isSearched) {
    totalText = 'Searched Total';
  } else if (isFiltered) {
    totalText = 'Filtered Total';
  }

  return (
    <div css={tableHeaderTitleStyle}>
      <Space size={2}>
        <Badge color={color} />
        <div>{`${totalText} : ${total}`}</div>
      </Space>
      {searchedText && (
        <Space size={2}>
          <Badge color={color} />
          <div className="text" title={searchedText}>{`Searched : ${searchedText}`}</div>
          {onResetSearch && (
            <Fragment>
              <H_SPACE rem={0.25} />
              <Button size="small" icon={<ClearOutlined />} shape="circle" onClick={onResetSearch} />
            </Fragment>
          )}
        </Space>
      )}
      {FilteredText && (
        <Space size={2}>
          <Badge color={color} />
          <div className="text" title={FilteredText}>{`Filtered : ${FilteredText}`}</div>
          {onResetFilter && (
            <Fragment>
              <H_SPACE rem={0.25} />
              <Button size="small" icon={<ClearOutlined />} shape="circle" onClick={onResetFilter} />
            </Fragment>
          )}
        </Space>
      )}
    </div>
  );
});

const tableHeaderTitleStyle = css`
  display: flex;
  flex-direction: column;
  button {
    border: 0;
  }
  .text {
    max-width: 50rem;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
  }
`;
