export { default } from './TableScrollTitle';
