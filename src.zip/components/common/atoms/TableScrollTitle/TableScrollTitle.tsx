import { DoubleLeftOutlined, DoubleRightOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { Button, Space } from 'antd';
import { forwardRef, ReactNode, useRef } from 'react';

interface TableScrollTitleProps {
  title: ReactNode;
  direction: 'left' | 'right';
}

const TableScrollTitle = forwardRef<HTMLDivElement, TableScrollTitleProps>(function TableScrollTitleFunc(
  { title, direction },
  ref,
) {
  const buttonRef = useRef<HTMLButtonElement>(null);

  return (
    <Space css={style}>
      {direction === 'right' && <TableColumnTitle>{title}</TableColumnTitle>}
      <Button
        ref={buttonRef}
        size="small"
        shape="circle"
        icon={direction === 'left' ? <DoubleLeftOutlined /> : <DoubleRightOutlined />}
        onClick={(e) => {
          e.stopPropagation();
          const tableNode =
            (ref as React.RefObject<HTMLDivElement>).current!.querySelector('.ant-table-body') ?? // with sticky
            (ref as React.RefObject<HTMLDivElement>).current!.querySelector('.ant-table-content'); // without sticky

          console.log(ref, (ref as React.RefObject<HTMLDivElement>).current!.querySelector('.ant-table-body'));
          if (tableNode) {
            if (direction === 'left') {
              tableNode.scrollBy({ left: -1000, behavior: 'smooth' });
            } else {
              tableNode.scrollBy({ left: 1000, behavior: 'smooth' });
            }
          }
          buttonRef.current?.blur();
        }}
      />
      {direction === 'left' && <TableColumnTitle>{title}</TableColumnTitle>}
    </Space>
  );
});

const style = css`
  button {
    border: 0;
  }
`;

export default TableScrollTitle;
