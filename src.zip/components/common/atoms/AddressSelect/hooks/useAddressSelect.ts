import AddressBookModal, { AddressBookModalProps } from '@components/common/atoms/AddressBookModal/AddressBookModal';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { searchAddressEmailAndGroup } from '@libs/axios/requests';
import { AddressOption } from '@typesdef/address';
import { useCallback, useRef } from 'react';
import { useDebouncedCallback } from 'use-debounce';
import { AddressSelectProps } from '../AddressSelect';

export default function useAddressSelect({ recipients, setRecipients, setEachRecipients }: AddressSelectProps) {
  const selectRef = useRef<any>(null);
  const { openModal } = useModals();

  if (!setRecipients && !setEachRecipients) {
    throw new Error('useAddressSelect: setRecipient or setEachRecipients is required');
  }

  const debouncedSearch = useDebouncedCallback((value: string, callback: any) => {
    if (!value) {
      callback([]);
    } else {
      searchAddressEmailAndGroup(value).then((res) => {
        const newList = res.map((item) => ({
          ...item,
          label: item.group ? `@${item.name}` : `${item.name} <${item.email}>`,
          value: `${item.id}`,
        }));
        callback(newList);
      });
    }
  }, 300);

  const onChangeSelectEmail = (recipients: any) => {
    const groupBook = (recipients as AddressOption[]).filter((item) => item.group);
    const emailBook = (recipients as AddressOption[]).filter((item) => !item.group && item.id);
    const customEmails = (recipients as AddressOption[]).filter((item) => !item.group && !item.id);

    if (setRecipients) {
      setRecipients([...groupBook, ...emailBook, ...customEmails]);
    }

    if (setEachRecipients) {
      setEachRecipients({
        groupBook,
        emailBook,
        customEmails: customEmails.map((item) => item.email),
      });
    }
  };

  const onCreateCustomEmail = (value: string) => {
    const newCustomEmail: AddressOption = {
      id: 0,
      name: value,
      email: value,
      group: false,
      label: value,
      value: value,
    };

    if (setRecipients) {
      setRecipients([...recipients, newCustomEmail]);
    }

    if (setEachRecipients) {
      const groupBook = recipients.filter((item) => item.group);
      const emailBook = recipients.filter((item) => !item.group && item.id);
      const customEmails = recipients.filter((item) => !item.group && !item.id).map((item) => item.email);

      setEachRecipients({ groupBook, emailBook, customEmails: [...customEmails, value] });
    }
  };

  const openAddrBookModal = () => {
    openModal<AddressBookModalProps>(MODAL_NAME.ADDRESS_BOOK.ADD_EDIT, AddressBookModal, {
      recipients,
      setRecipients,
      setEachRecipients,
    });
  };

  const onSelectEscKeyPress = useCallback((e: React.KeyboardEvent<HTMLElement>) => {
    if (e.key === 'Escape') selectRef.current.blur();
  }, []);

  return {
    selectRef,
    debouncedSearch,
    onChangeSelectEmail,
    onCreateCustomEmail,
    onSelectEscKeyPress,
    openAddrBookModal,
  };
}
