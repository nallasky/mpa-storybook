import { BookOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { AddressOption } from '@typesdef/address';
import { Button } from 'antd';
import Highlighter from 'react-highlight-words';
import AsyncCreatableSelect from 'react-select/async-creatable';
import { H_SPACE } from '../Space';
import useAddressSelect from './hooks/useAddressSelect';

export interface AddressSelectProps {
  recipients: AddressOption[];
  disabled?: boolean;
  isLoading?: boolean;
  placeholder?: string;
  setRecipients?: (recipients: AddressOption[]) => void;
  setEachRecipients?: ({
    emailBook,
    groupBook,
    customEmails,
  }: {
    emailBook: AddressOption[];
    groupBook: AddressOption[];
    customEmails: string[];
  }) => void;
}

export default function AddressSelect({
  recipients,
  disabled = false,
  isLoading = false,
  placeholder,
  setRecipients,
  setEachRecipients,
}: AddressSelectProps): JSX.Element {
  const {
    selectRef,
    debouncedSearch,
    onChangeSelectEmail,
    onCreateCustomEmail,
    onSelectEscKeyPress,
    openAddrBookModal,
  } = useAddressSelect({ recipients, setRecipients, setEachRecipients });
  return (
    <div
      css={css`
        display: flex;
        flex-direction: row;
        align-items: center;
      `}
    >
      <AsyncCreatableSelect
        classNamePrefix="address"
        placeholder={placeholder ?? 'Input additional emails other than the default.'}
        styles={colourStyles}
        isMulti
        formatOptionLabel={formatOptionLabel}
        value={recipients as any}
        cacheOptions
        formatCreateLabel={(userInput) => `Add custom email address '${userInput}'`}
        isSearchable
        loadOptions={debouncedSearch}
        onChange={onChangeSelectEmail}
        onCreateOption={onCreateCustomEmail}
        defaultValue={[]}
        ref={selectRef}
        onKeyDown={onSelectEscKeyPress}
        css={css`
          border-radius: 2px;
          z-index: 100;
          &:hover {
            border-color: #40a9ff;
          }
        `}
        isDisabled={disabled}
        isLoading={isLoading}
      />
      <H_SPACE />
      <Button type="primary" shape="circle" icon={<BookOutlined />} onClick={openAddrBookModal} disabled={disabled} />
    </div>
  );
}

function formatOptionLabel(
  { label, name, __isNew__ }: { label: string; name: string; email: string; group: boolean; __isNew__: boolean },
  { inputValue }: { inputValue: string },
) {
  if (__isNew__) {
    return <div>{label}</div>;
  } else {
    // const newLable = group ? `@${name}` : `${name} <${email}>`;
    return (
      <Highlighter
        searchWords={[inputValue]}
        textToHighlight={label}
        autoEscape={true}
        highlightStyle={{ padding: 0, fontWeight: 700, backgroundColor: 'transparent' }}
      />
    );
  }
}

const colourStyles: any = {
  control: (styles: any) => {
    return {
      ...styles,
      // width: '49.25rem',
      width: '46rem',
      borderRadius: 0,
    };
  },
  multiValue: (styles: any, { data }: { data: any }) => {
    let color = '#d9d9d9';
    if (data.group) {
      color = '#ffe7ba';
    } else {
      if (data.id) {
        color = '#d6e4ff';
      }
    }

    return {
      ...styles,
      backgroundColor: color,
      fontSize: '1rem',
    };
  },
};
