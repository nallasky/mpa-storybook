import { Modal, ModalFuncProps } from 'antd';

type AntdModalType = 'info' | 'success' | 'error' | 'warn' | 'warning' | 'confirm';

export const openAntdModal = (type: AntdModalType, props: ModalFuncProps) => {
  const modal = Modal[type]({
    ...props,
    onOk: async () => {
      if (props.onOk) {
        disableCancelBtn();
        await props.onOk();
      }
    },
    onCancel: async () => {
      if (props.onCancel) {
        await props.onCancel();
      }
    },
    // maskClosable: true,
  });
  const disableCancelBtn = () => {
    if (modal) {
      modal.update({
        cancelButtonProps: {
          disabled: true,
        },
        maskClosable: false,
      });
    }
  };
};
