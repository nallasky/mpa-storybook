import { ClearOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { checkIsEmpty } from '@libs/util/validation';
import { ReqFilterParam } from '@typesdef/common';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { FilterModalItem, FilterModalItemParam } from '@typesdef/search';
import { Button, Form, Modal } from 'antd';
import { useForm } from 'antd/es/form/Form';
import { Fragment, useEffect, useRef } from 'react';
import { FormItemLabel } from '../SearchModal/SearchModalItems';
import { FilterGroupCheckbox } from './FilterModalItems';

export interface FilterModalProps {
  items: FilterModalItem[];
  param: ReqFilterParam;
  setParam: (param: ReqFilterParam) => void;
}

export default function SearchModal({
  visible,
  onClose,
  items,
  param,
  setParam,
}: GlobalModalDefaultProps<FilterModalProps>): JSX.Element {
  const [form] = useForm();
  const buttonRef = useRef<HTMLButtonElement>(null);

  const onOk = async () => {
    try {
      await form.validateFields();

      const fieldValues = Object.entries(form.getFieldsValue()).reduce((acc, [key, value]) => {
        if (checkIsEmpty(value)) {
          return acc;
        }

        if (Array.isArray(value)) {
          acc[key] = value.join(',');
        } else {
          acc[key] = value as ReqFilterParam['value'];
        }

        acc[key] = value as ReqFilterParam['value'];

        return acc;
      }, {} as ReqFilterParam);

      setParam(fieldValues);
      onClose();
    } catch (e) {
      console.log(e);
    }
  };

  const onCancel = () => {
    onClose();
  };

  const onFieldClear = (name?: string) => {
    if (name) {
      form.setFieldsValue({
        [name]: undefined,
      });
    } else {
      form.resetFields();
      buttonRef.current?.blur();
    }
  };

  useEffect(() => {
    if (visible) {
      if (Object.keys(param ?? {}).length > 0) {
        form.setFieldsValue(param ?? {});
      } else {
        form.resetFields();
      }
    }
  }, [visible, form, param]);

  return (
    <Modal
      title={'Filter'}
      open={visible}
      onOk={onOk}
      okText={'Filter'}
      okButtonProps={{ disabled: false }}
      onCancel={onCancel}
      closable={true}
      maskClosable={true}
      destroyOnClose
      bodyStyle={{
        maxHeight: '38rem',
        overflowY: 'auto',
      }}
      width={'480px'}
    >
      <div css={style}>
        <div className="reset">
          {items.length > 1 && (
            <Button ref={buttonRef} type="dashed" icon={<ClearOutlined />} size="small" onClick={() => onFieldClear()}>
              All
            </Button>
          )}
        </div>
        <Form form={form} layout="vertical">
          {items.map(({ name, label, type, options, rules }) => (
            <Form.Item key={name} name={name} label={<FormItemLabel name={label} />} rules={rules ?? []}>
              <FilterItem type={type} options={options} onReset={onFieldClear} />
            </Form.Item>
          ))}
        </Form>
        {/* <Button onClick={() => console.log(form.getFieldsValue())}>Get</Button> */}
      </div>
    </Modal>
  );
}

const style = css`
  .reset {
    margin-top: -1rem;
    display: flex;
    justify-content: flex-end;
  }
`;

function FilterItem({ type, options, onReset, ...rest }: FilterModalItemParam) {
  if (!type) {
    throw new Error('FilterModalItem type is required');
  }

  switch (type) {
    case 'group_checkbox':
      return <FilterGroupCheckbox onReset={onReset} options={options} {...rest} />;

    default:
      return <Fragment />;
  }
}

export const getFilteredText = (itemList: FilterModalItem[], filterParam: ReqFilterParam) => {
  const searchText = Object.entries(filterParam ?? {}).reduce((acc, [key, value]) => {
    const foundItem = itemList.find((item) => item.name === key);

    if (!foundItem) {
      return acc;
    }

    let convert = value;

    if (Array.isArray(value)) {
      convert = value.join(', ');
    }

    return acc.concat(`${acc.length > 0 ? ' | ' : ''}[${foundItem.label}] ${convert}`);
  }, '');

  return searchText;
};
