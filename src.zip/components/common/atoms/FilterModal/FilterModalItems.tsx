import { ClearOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { FilterModalItemParam } from '@typesdef/search';
import { Button, Checkbox } from 'antd';
import { CheckboxValueType } from 'antd/es/checkbox/Group';
import { useRef } from 'react';

export function FilterGroupCheckbox<T>({
  options = [],
  id,
  value,
  onChange,
  onReset,
  ...rest
}: FilterModalItemParam<T>) {
  const resetRef = useRef<HTMLElement>(null);

  const onResetField = () => {
    if (id && onReset) {
      onReset(id);
      resetRef.current?.blur();
    }
  };

  return (
    <div
      css={css`
        display: flex;
        align-items: center;
        justify-content: space-between;
      `}
    >
      <Checkbox.Group
        value={value as CheckboxValueType[] | undefined}
        onChange={(value: CheckboxValueType[]) => {
          onChange?.(value as unknown as T);
        }}
        options={options.map((item) => ({
          label: item.label,
          value: item.value as CheckboxValueType,
          key: item.value,
        }))}
      />
      <Button ref={resetRef} size="small" type="dashed" icon={<ClearOutlined />} onClick={onResetField} />
    </div>
  );
}
