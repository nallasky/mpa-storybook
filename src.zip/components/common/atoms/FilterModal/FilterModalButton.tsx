import { SearchOutlined } from '@ant-design/icons';
import AntdButton from '../AntdButton';

interface FilterModalButtonProps {
  hasParam: boolean;
  onClick: () => void;
}

export default function FilterModalButton({ hasParam, onClick }: FilterModalButtonProps) {
  return (
    <AntdButton icon={<SearchOutlined />} type={hasParam ? 'primary' : 'default'} onClick={onClick}>
      Filter
    </AntdButton>
  );
}
