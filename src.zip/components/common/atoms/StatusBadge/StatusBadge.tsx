import { css } from '@emotion/react';
import { hoverActiveStyle } from '@styles/emotion/common';
import { JobStatusType } from '@typesdef/Job';
import { Badge } from 'antd';
import { PresetStatusColorType } from 'antd/es/_util/colors';

export type StatusBadgeProps = {
  value: JobStatusType;
  onClick?: () => void;
};

export default function StatusBadge({ value, onClick }: StatusBadgeProps) {
  const { badgeStatus, textStatus } = convertBadgeProps(value);

  if (value === 'notbuild' || !onClick) {
    return <Badge status={badgeStatus} text={textStatus} />;
  }

  return (
    <div
      onClick={onClick}
      css={css`
        .ant-badge-status-text {
          ${hoverActiveStyle}
        }
      `}
    >
      <Badge status={badgeStatus} text={textStatus} />
    </div>
  );
}

export const convertBadgeProps = (
  value: JobStatusType,
): { badgeStatus: PresetStatusColorType | undefined; textStatus: string } => {
  switch (value) {
    case 'success':
      return {
        badgeStatus: 'success',
        textStatus: 'Success',
      };

    case 'failure':
      return {
        badgeStatus: 'error',
        textStatus: 'Failure',
      };
    case 'processing':
      return {
        badgeStatus: 'processing',
        textStatus: 'Processing',
      };
    case 'canceled':
      return {
        badgeStatus: 'warning',
        textStatus: 'Canceled',
      };
    case 'notbuild':
      return {
        badgeStatus: 'default',
        textStatus: 'Not Build',
      };
    case 'nodata':
      return {
        badgeStatus: 'success',
        textStatus: 'No Data',
      };
    case 'downloaded':
      return {
        badgeStatus: 'default',
        textStatus: 'Downloaded',
      };

    default:
      return { badgeStatus: undefined, textStatus: 'Unknown' };
  }
};
