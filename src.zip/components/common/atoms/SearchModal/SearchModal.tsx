import { ClearOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { checkIsEmpty } from '@libs/util/validation';
import { ReqSearchParam } from '@typesdef/common';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { SearchModalItem, TypeSearchItem } from '@typesdef/search';
import { Button, Form, Modal } from 'antd';
import { useForm } from 'antd/es/form/Form';
import { DefaultOptionType } from 'antd/es/select';
import { Fragment, useEffect, useRef } from 'react';
import { SearchItemDateRange, SearchItemErrorCode, SearchItemInput, SearchItemSelect } from './SearchModalItems';

export interface SearchModalProps {
  items: SearchModalItem[];
  param: ReqSearchParam;
  setParam: (param: ReqSearchParam) => void;
}

export default function SearchModal({
  visible,
  onClose,
  items,
  param,
  setParam,
}: GlobalModalDefaultProps<SearchModalProps>): JSX.Element {
  const [form] = useForm();
  const buttonRef = useRef<HTMLButtonElement>(null);

  const onOk = async () => {
    try {
      await form.validateFields();

      const fieldValues = Object.entries(form.getFieldsValue()).reduce((acc, [key, value]) => {
        if (checkIsEmpty(value)) {
          return acc;
        }

        if (Array.isArray(value)) {
          if (value.some((item) => !item && !Number.isInteger(item))) {
            return acc;
          }
        }

        acc[key] = value as ReqSearchParam['value'];

        return acc;
      }, {} as ReqSearchParam);

      setParam(fieldValues);
      onClose();
    } catch (e) {
      console.log(e);
    }
  };

  const onCancel = () => {
    onClose();
  };

  const onFieldClear = (name?: string) => {
    if (name) {
      form.setFieldsValue({
        [name]: undefined,
      });
    } else {
      form.resetFields();
      buttonRef.current?.blur();
    }
  };

  useEffect(() => {
    if (visible) {
      if (Object.keys(param ?? {}).length > 0) {
        form.setFieldsValue(param ?? {});
      } else {
        form.resetFields();
      }
    }
  }, [visible, form, param]);

  return (
    <Modal
      title={'Search'}
      visible={visible}
      onOk={onOk}
      okText={'Search'}
      okButtonProps={{ disabled: false }}
      onCancel={onCancel}
      closable={true}
      maskClosable={true}
      destroyOnClose
      bodyStyle={{
        maxHeight: '38rem',
        overflowY: 'auto',
      }}
      width={'480px'}
    >
      <div css={style}>
        <div className="reset">
          {items.length > 1 && (
            <Button ref={buttonRef} type="dashed" icon={<ClearOutlined />} size="small" onClick={() => onFieldClear()}>
              All
            </Button>
          )}
        </div>
        <Form form={form} layout="vertical">
          {items.map(({ name, label, type, options }) => (
            <SearchItem key={name} name={name} label={label} type={type} options={options} onReset={onFieldClear} />
          ))}
        </Form>
        {/* <Button onClick={() => console.log(form.getFieldsValue())}>Get</Button> */}
      </div>
    </Modal>
  );
}

const style = css`
  .reset {
    margin-top: -1rem;
    display: flex;
    justify-content: flex-end;
  }
`;

interface SearchItemProps {
  name: string;
  label: string;
  type: TypeSearchItem;
  options?: DefaultOptionType[];
  onReset: (name?: string) => void;
}

const SearchItem = ({ name, label, type, options, onReset }: SearchItemProps) => {
  switch (type) {
    case 'code':
      return <SearchItemErrorCode name={name} label={label} onReset={onReset} />;
    case 'text':
      return <SearchItemInput name={name} label={label} onReset={onReset} />;
    case 'select':
      return <SearchItemSelect name={name} label={label} options={options} onReset={onReset} />;
    case 'date_range':
      return <SearchItemDateRange name={name} label={label} onReset={onReset} />;
    default:
      return <Fragment />;
  }
};

export const getSearchedText = (itemList: SearchModalItem[], searchParam: ReqSearchParam) => {
  const searchText = Object.entries(searchParam ?? {}).reduce((acc, [key, value]) => {
    const foundItem = itemList.find((item) => item.name === key);

    if (!foundItem) {
      return acc;
    }

    let convert = value;

    if (foundItem.type === 'code' || foundItem.type === 'date_range') {
      if (Array.isArray(value) && value.length === 2) {
        convert = value.join(' ~ ');
      }
    }

    return acc.concat(`${acc.length > 0 ? ' | ' : ''}[${foundItem.label}] ${convert}`);
  }, '');

  return searchText;
};
