import { ClearOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { Badge, Button, DatePicker, Form, Input, Select, Space } from 'antd';
import Checkbox, { CheckboxChangeEvent } from 'antd/es/checkbox';
import { RangePickerProps } from 'antd/es/date-picker';
import { DefaultOptionType } from 'antd/es/select';
import moment from 'moment';
import { ChangeEvent, Fragment, useEffect, useRef, useState } from 'react';

export function FormItemLabel({ name }: { name: string }) {
  return (
    <div css={formItemLabelStyle}>
      <Badge color="blue" />
      <div>{name}</div>
    </div>
  );
}

const formItemLabelStyle = css`
  display: flex;
  align-items: center;

  button {
    margin-left: 0.5rem;
  }
`;

interface SearchFormItemProps {
  onReset: (name?: string) => void;
  name: string;
  label: string;
  options?: DefaultOptionType[];
}

interface SearchFormItemInputProps<T> {
  value?: T;
  onChange?: (value: T) => void;
  onReset?: (name?: string) => void;
  id?: string;
  options?: DefaultOptionType[];
}

export function SearchItemErrorCode({ name, label, onReset }: SearchFormItemProps) {
  return (
    <Form.Item name={name} label={<FormItemLabel name={label} />} rules={[errorCodeInputRangeRule()]}>
      <ErrorCodeInput onReset={onReset} />
    </Form.Item>
  );
}

interface SearchFormItemCodeInputProps<T> {
  value?: T;
  onChange?: (value: T) => void;
  onReset?: (name?: string) => void;
  id?: string;
  allowAsterisk?: boolean;
}

export function ErrorCodeInput({
  value,
  onChange,
  onReset,
  id,
  allowAsterisk = true,
}: SearchFormItemCodeInputProps<string[]>) {
  const [isRange, setRange] = useState(false);
  const resetRef = useRef<HTMLElement>(null);
  const [min, setMin] = useState('');
  const [max, setMax] = useState('');

  const onChangeRange = ({ target: { checked } }: CheckboxChangeEvent) => {
    setRange(checked);
    if (checked) {
      onChange?.([min, max]);
    } else {
      onChange?.([min]);
    }
  };

  const onChangeMin = ({ target: { value } }: ChangeEvent<HTMLInputElement>) => {
    let regex = new RegExp('^[a-fA-F0-9]{0,7}$');
    if (allowAsterisk && !isRange) {
      regex = new RegExp('^[a-fA-F0-9*]{0,7}$');
    }

    if (regex.test(value)) {
      if (isRange) {
        onChange?.([value, max]);
      } else {
        onChange?.([value]);
      }
      setMin(value);
    }
  };

  const onChangeMax = ({ target: { value } }: ChangeEvent<HTMLInputElement>) => {
    const regex = new RegExp('^[a-fA-F0-9]{0,7}$');
    if (regex.test(value)) {
      onChange?.([min, value]);
      setMax(value);
    }
  };

  const onResetField = () => {
    if (id && onReset) {
      onReset(id);
      setMin('');
      setMax('');
      resetRef.current?.blur();
    }
  };

  useEffect(() => {
    if (Array.isArray(value) && value.length > 1) {
      setRange(true);
    } else {
      setRange(false);
    }

    setMin(value ? value[0] : '');
    setMax(value ? value[1] : '');
  }, [value]);

  return (
    <Space css={style} size={16}>
      <Input.Group compact>
        <Input className="input__left" placeholder={isRange ? 'From' : ''} value={min} onChange={onChangeMin} />
        {isRange && (
          <Fragment>
            <Input className="input__split" placeholder="~" disabled />
            <Input className="input__right" placeholder="To" value={max} onChange={onChangeMax} />
          </Fragment>
        )}
      </Input.Group>

      <Checkbox checked={isRange} onChange={onChangeRange}>
        Range
      </Checkbox>
      {onReset && <Button ref={resetRef} size="small" type="dashed" icon={<ClearOutlined />} onClick={onResetField} />}
    </Space>
  );
}

export const errorCodeInputRangeRule = (allowEmpty = true) => ({
  validator(_: any, value: string[]) {
    const newValue = value && Array.isArray(value) ? value : [];
    const [min = '', max = ''] = newValue;
    const length = newValue.length;

    if (length === 0) {
      return allowEmpty ? Promise.resolve() : Promise.reject('Please fill in all 7-digit hexadecimal values!');
    }

    if (allowEmpty) {
      if (length === 1 && !min) {
        return Promise.resolve();
      }
      if (length === 2 && !min && !max) {
        return Promise.resolve();
      }
    }

    if (length > 1) {
      if (min.length < 7 || max.length < 7) {
        return Promise.reject(new Error(`Please fill in all 7-digit hexadecimal values 'From' and 'To'!`));
      }
      if (parseInt(min, 16) >= +parseInt(max, 16)) {
        return Promise.reject(new Error(`The 'From' value must be more than the 'To' value!`));
      }
    } else {
      if (min.length < 7) {
        if (min.includes('*')) {
          return Promise.resolve();
        } else {
          return Promise.reject(new Error(`Please fill in all 7-digit hexadecimal values!`));
        }
      }
    }

    return Promise.resolve();
  },
});

const style = css`
  display: flex;
  align-items: center;

  .ant-input-group {
    .input__left,
    .input__right {
      width: 8.5rem;
      /* text-align: center; */
    }

    .input__right {
      border-left-width: 0;
      &:hover,
      &:focus {
        border-left-width: 1px;
      }
    }

    .input__left.ant-input-status-error {
      z-index: 1;
    }

    .input__right.ant-input-status-error {
      border-left-width: 1px;
    }

    .input__split {
      background-color: #fff;
      width: 1.875rem;
      border-left: 0;
      border-right: 0;
      pointer-events: 'none';
    }
  }
`;

export function SearchItemInput({ name, label, onReset }: SearchFormItemProps) {
  return (
    <Form.Item name={name} label={<FormItemLabel name={label} />}>
      <TextInput onReset={onReset} />
    </Form.Item>
  );
}

function TextInput({ value, onChange, onReset, id }: SearchFormItemInputProps<string>) {
  const resetRef = useRef<HTMLElement>(null);

  const onResetField = () => {
    if (id && onReset) {
      onReset(id);
      resetRef.current?.blur();
    }
  };

  const onChangeInput = ({ target: { value } }: ChangeEvent<HTMLInputElement>) => {
    onChange?.(value);
  };

  return (
    <Space>
      <Input
        value={value}
        onChange={onChangeInput}
        css={css`
          width: 25rem;
        `}
      />
      <Button ref={resetRef} size="small" type="dashed" icon={<ClearOutlined />} onClick={onResetField} />
    </Space>
  );
}

export function SearchItemSelect({ name, label, options = [], onReset }: SearchFormItemProps) {
  return (
    <Form.Item name={name} label={<FormItemLabel name={label} />}>
      <SelectInput onReset={onReset} options={options} />
    </Form.Item>
  );
}

function SelectInput({ value, options = [], onChange, onReset, id }: SearchFormItemInputProps<string>) {
  const resetRef = useRef<HTMLElement>(null);

  const onResetField = () => {
    if (id && onReset) {
      onReset(id);
      resetRef.current?.blur();
    }
  };

  const onChangeCommand = (value: string) => {
    onChange?.(value);
  };

  return (
    <Space>
      <Select<string>
        value={value}
        onChange={onChangeCommand}
        options={options}
        css={css`
          width: 25rem !important;
        `}
      ></Select>
      <Button ref={resetRef} size="small" type="dashed" icon={<ClearOutlined />} onClick={onResetField} />
    </Space>
  );
}

export function SearchItemDateRange({ name, label, onReset }: SearchFormItemProps) {
  return (
    <Form.Item name={name} label={<FormItemLabel name={label} />}>
      <DateRangeInput onReset={onReset} />
    </Form.Item>
  );
}

function DateRangeInput({ value, onChange, onReset, id }: SearchFormItemInputProps<string[]>) {
  const resetRef = useRef<HTMLElement>(null);
  const [from, to] = value ?? [];

  const onResetField = () => {
    if (id && onReset) {
      onReset(id);
      resetRef.current?.blur();
    }
  };
  const onChangeDate = (value: RangePickerProps['value'], dateString: [string, string] | string) => {
    onChange?.(dateString as string[]);
  };

  return (
    <Space>
      <DatePicker.RangePicker
        showTime={{ format: 'HH:mm', defaultValue: [moment().startOf('day'), moment().endOf('day')] }}
        format="YYYY-MM-DD HH:mm"
        value={from && to ? [moment(from), moment(to)] : undefined}
        onChange={onChangeDate}
        allowClear={false}
        css={css`
          width: 25rem;
        `}
      />
      <Button ref={resetRef} size="small" type="dashed" icon={<ClearOutlined />} onClick={onResetField} />
    </Space>
  );
}
