import { SearchOutlined } from '@ant-design/icons';
import AntdButton from '../AntdButton';

interface SearchModalButtonProps {
  hasParam: boolean;
  onClick: () => void;
}

export default function SearchModalButton({ hasParam, onClick }: SearchModalButtonProps) {
  return (
    <AntdButton icon={<SearchOutlined />} type={hasParam ? 'primary' : 'default'} onClick={onClick}>
      Search
    </AntdButton>
  );
}
