import { css, SerializedStyles } from '@emotion/react';
import { Tag } from 'antd';
import React, { useCallback } from 'react';
import { animated, useTransition } from 'react-spring';

export interface MarkUpTagsProps {
  tags: string[];
  setTags: (value: string[]) => void;
  tagsStyle?: SerializedStyles;
}
export default function MarkUpTags({ tags, setTags, tagsStyle }: MarkUpTagsProps): JSX.Element {
  const transitions = useTransition(tags, {
    keys: (item) => item,
    from: { opacity: 0, transform: 'scale(0)' },
    enter: { opacity: 1, transform: 'scale(1)' },
    leave: { opacity: 0, transform: 'scale(0)' },
  });

  const handleClose = useCallback(
    (removedTag: string) => {
      setTags(tags.filter((tag) => tag !== removedTag));
    },
    [tags, setTags],
  );

  const forMapTags = useCallback(
    (tag: string) => {
      const tagElem = (
        <Tag
          color="green"
          closable
          onClose={(e) => {
            e.preventDefault();
            handleClose(tag);
          }}
          css={css`
            margin-bottom: 0.25rem;
          `}
        >
          {tag}
        </Tag>
      );
      return (
        <span key={tag} style={{ display: 'inline-block' }}>
          {tagElem}
        </span>
      );
    },
    [handleClose],
  );

  return (
    <div css={containerStyle}>
      {transitions((style, item) => (
        <animated.div key={item} style={style}>
          {forMapTags(item)}
        </animated.div>
      ))}
    </div>
  );
}

const containerStyle = css`
  display: flex;
  flex-wrap: wrap;
`;
