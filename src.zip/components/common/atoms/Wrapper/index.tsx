import { css, Interpolation, Theme } from '@emotion/react';
import styled from '@emotion/styled';
import { motion } from 'framer-motion';
import { ReactNode } from 'react';
import { useLocation } from 'react-router-dom';

export const ContentWrapper = styled.div`
  display: flex;
  width: inherit;
  flex-direction: column;
`;

interface MotionDivWrapperProps {
  children: ReactNode;
  cssStyle?: Interpolation<Theme>;
}

export function MotionDivWrapper({ children, cssStyle }: MotionDivWrapperProps) {
  const { key } = useLocation();

  return (
    <motion.div
      className="motion__div__wrapper"
      key={key}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{
        duration: 1,
      }}
      css={[motionDivStyle, cssStyle]}
    >
      {children}
    </motion.div>
  );
}

const motionDivStyle = css`
  width: 100%;
  height: 100%;
  display: flex;
`;
