import { css, Theme } from '@emotion/react';
import { Interpolation } from '@emotion/styled';
import { Button } from 'antd';
import { ButtonProps } from 'antd/es/button';
import { memo } from 'react';

interface AntdButtonProps extends ButtonProps {
  css?: Interpolation<Theme>;
}

export const AntdButton = memo(function AntdButton2Func({ children, type = 'primary', css, ...rest }: AntdButtonProps) {
  return (
    <Button {...rest} type={type} css={[css, buttonStyle]}>
      {children}
    </Button>
  );
});

export default AntdButton;

const buttonStyle = css`
  border-radius: 0.625rem;
`;
