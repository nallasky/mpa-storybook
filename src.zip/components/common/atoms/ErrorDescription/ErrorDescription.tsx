import type { TypeConvertRuleErrorPosition } from '@typesdef/convertRules';

export interface ErrorDescriptionError {
  path?: string;
  error?: string;
  error_list?: ErrorDescriptionErrorList[];
  type?: TypeConvertRuleErrorPosition;
}

export interface ErrorDescriptionErrorList {
  index?: number;
  table?: 'header' | 'info' | 'custom' | 'filter';
  key: string;
  name: string;
  reason: string;
}

export interface ErrorDescriptionProps {
  msg: string;
  error?: ErrorDescriptionError;
}

export default function ErrorDescription({ msg, error }: ErrorDescriptionProps) {
  return (
    <div>
      <div>{msg}</div>
      <div>{error?.error ? `error : ${error.error}` : undefined}</div>
      {error?.error_list?.map((item, idx) => (
        <div key={item.key}>
          <div>{`[error #${idx + 1}]`}</div>
          <div>{`key : ${item.key ?? ''}`}</div>
          <div>{`name : ${item.name ?? ''}`}</div>
          <div>{`reason : ${item.reason ?? ''}`}</div>
        </div>
      ))}
    </div>
  );
}
