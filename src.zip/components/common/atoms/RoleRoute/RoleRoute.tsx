import { PAGE_URL } from '@constants/constants';
import { loginUserSelector } from '@reducers/slices/loginUser';
import { AccountUserRoleType } from '@typesdef/account';
import React, { Fragment } from 'react';
import { useSelector } from 'react-redux';
import { Navigate } from 'react-router-dom';

export type PrivateRouteProps = {
  role: AccountUserRoleType;
  children: React.ReactNode;
};

export default function RoleRoute({ role, children }: PrivateRouteProps): JSX.Element {
  const { roles: userRoles } = useSelector(loginUserSelector);

  if (userRoles.includes(role)) {
    return <Fragment>{children}</Fragment>;
  } else {
    return <Navigate replace to={PAGE_URL.FORBIDDEN} />;
  }
}
