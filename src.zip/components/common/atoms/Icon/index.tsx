export { default } from "./Icon";
