import { SearchOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { disabledStyle, hoverActiveStyle } from '@styles/emotion/common';
import { Button, Divider, Form, Popover, PopoverProps, Select } from 'antd';
import { DefaultOptionType } from 'antd/es/select';
import { useEffect } from 'react';

type SearchPopoverPopoverProps<T> = PopoverProps & {
  width: number | string;
  options: DefaultOptionType[];
  onSave: (value: T) => void;
  onOpen: (open: boolean) => void;
  disabled?: boolean;
};

export default function SearchPopover<T>({
  open = false,
  onOpen,
  width,
  options,
  title,
  placement = 'left',
  onSave,
  disabled = false,
}: SearchPopoverPopoverProps<T>) {
  const [form] = Form.useForm<{ select: string }>();

  const onClickOk = async () => {
    try {
      const { select } = await form.validateFields();
      onSave(select as unknown as T);
      onOpen(false);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (!open) {
      form.resetFields();
    }
  }, [open, form]);

  return (
    <Popover
      open={open}
      onOpenChange={onOpen}
      destroyTooltipOnHide
      title={title}
      placement={placement}
      content={
        <div
          css={css`
            display: flex;
            flex-direction: column;
            .ant-divider {
              margin-top: 0.5rem;
              margin-bottom: 0.5rem;
            }
            .buttons {
              display: flex;
              justify-content: flex-end;
              gap: 0.5rem;
            }
          `}
        >
          <Form form={form}>
            <Form.Item
              name="select"
              rules={[
                {
                  required: true,
                  message: 'Please select a option!',
                },
              ]}
            >
              <Select<T> options={options} style={{ width }} placeholder="Select a option." />
            </Form.Item>
          </Form>
          <Divider />
          <div className="buttons">
            <Button size="small" onClick={() => onOpen(false)}>
              Cancel
            </Button>
            <Button size="small" type="primary" onClick={onClickOk}>
              Ok
            </Button>
          </div>
        </div>
      }
      trigger="click"
    >
      <SearchOutlined css={disabled ? disabledStyle : hoverActiveStyle} />
    </Popover>
  );
}
