import AccountChangePasswordModal, {
  AccountChangePasswordModalProps,
} from '@components/Account/Modal/AccountChangePasswordModal';
import AccountInvalidLicenseModal from '@components/Account/Modal/AccountInvalidLicenseModal';
import { PAGE_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useLogout from '@hooks/useLogout';
import useModals from '@hooks/useModal';
import useValidateLogin from '@hooks/useValidateLogin';
import { hasValidLicense } from '@libs/util/auth';
import { loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import React, { Fragment, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export type PrivateRouteProps = {
  children: React.ReactNode;
};

export default function PrivateRoute({ children }: PrivateRouteProps): JSX.Element | null {
  const { validateToken } = useValidateLogin();
  const { onLogout } = useLogout();
  const { isLoggedIn } = useTypedSelector(loginUserSelector);
  const { openModal } = useModals();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoggedIn) {
      validateToken().then((result) => {
        if (result === null) {
          onLogout();
        } else {
          const { licenseStatus, isInitialPassword } = result;
          if (!hasValidLicense(licenseStatus)) {
            openModal(MODAL_NAME.AUTH.INVALID_LICENSE, AccountInvalidLicenseModal);
            navigate(PAGE_URL.NOT_LICENSED);
            return;
          }

          if (isInitialPassword) {
            openModal<AccountChangePasswordModalProps>(MODAL_NAME.AUTH.CHANGE_PASSWORD, AccountChangePasswordModal, {
              shouldChangePassword: true,
            });
            navigate(PAGE_URL.CHANGE_PASSWORD);
            return;
          }
        }
      });
    }
  }, [isLoggedIn, validateToken, onLogout, navigate, openModal]);

  if (!isLoggedIn) {
    return null;
  }

  return <Fragment>{children}</Fragment>;
}
