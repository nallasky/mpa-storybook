import { SyncOutlined } from '@ant-design/icons';
import { IS_REFRESH_BTN } from '@constants/globalValue';
import { Button, ButtonProps } from 'antd';
import React, { Fragment } from 'react';

export default React.memo(function RefreshBtn(props: ButtonProps & React.RefAttributes<HTMLElement>): JSX.Element {
  if (!IS_REFRESH_BTN) {
    return <Fragment></Fragment>;
  }

  return <Button type="primary" icon={<SyncOutlined />} {...props} />;
});

export function refreshBtnProps<T>(data: T): T | undefined {
  return IS_REFRESH_BTN ? data : undefined;
}
