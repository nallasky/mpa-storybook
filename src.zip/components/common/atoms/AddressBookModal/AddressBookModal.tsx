import { AddressOption, TransferJobAddressInfo } from '@typesdef/address';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Modal, Transfer } from 'antd';
import { memo } from 'react';
import useAddressBookModal from './hooks/useAddressBookModal';

export interface AddressBookModalProps {
  recipients: AddressOption[];
  setRecipients?: (recipients: AddressOption[]) => void;
  setEachRecipients?: ({
    emailBook,
    groupBook,
    customEmails,
  }: {
    emailBook: AddressOption[];
    groupBook: AddressOption[];
    customEmails: string[];
  }) => void;
}

export default memo(function AddressBookModal({
  visible,
  onClose,
  recipients,
  setRecipients,
  setEachRecipients,
}: GlobalModalDefaultProps<AddressBookModalProps>): JSX.Element {
  const { addressList, isFetching, targetKeys, selectedKeys, handleOk, handleChange, handleSelectChange } =
    useAddressBookModal({ visible, onClose, recipients, setRecipients, setEachRecipients });

  const filterOption = (inputValue: string, item: TransferJobAddressInfo) =>
    item.name.toLowerCase().indexOf(inputValue.toLowerCase()) > -1 ||
    item.email.toLowerCase().indexOf(inputValue.toLowerCase()) > -1;

  return (
    <Modal
      title={'Address Book'}
      visible={visible}
      okText="Edit"
      onOk={handleOk}
      okButtonProps={{ disabled: isFetching }}
      onCancel={onClose}
      maskClosable
      width={'1000px'}
    >
      <Transfer<TransferJobAddressInfo>
        dataSource={isFetching ? [] : addressList}
        titles={['All Emails', 'Recipients']}
        showSearch
        listStyle={{
          width: 500,
          height: 500,
        }}
        targetKeys={isFetching ? [] : targetKeys}
        onChange={handleChange}
        render={(item) => item.label}
        filterOption={filterOption}
        disabled={isFetching}
        onSelectChange={handleSelectChange}
        selectedKeys={selectedKeys}
      />
    </Modal>
  );
});
