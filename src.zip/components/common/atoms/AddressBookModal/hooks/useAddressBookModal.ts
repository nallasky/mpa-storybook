import { getAddressGroupEmailList } from '@libs/axios/requests';
import { AddressInfo } from '@libs/axios/types';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQuery } from '@tanstack/react-query';
import { AddressOption, TransferJobAddressInfo } from '@typesdef/address';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { TransferDirection } from 'antd/es/transfer';
import { AxiosError } from 'axios';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { AddressBookModalProps } from '../AddressBookModal';

export default function useAddressBookModal({
  onClose,
  recipients,
  setRecipients,
  setEachRecipients,
}: GlobalModalDefaultProps<AddressBookModalProps>) {
  const [targetKeys, setTargetKeys] = useState<string[] | undefined>(undefined);
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [customEmails, setCustomEmails] = useState<AddressOption[]>([]);

  const { data, isFetching } = useQuery<AddressInfo[], AxiosError>(
    [QUERY_KEY.ADDRESS_GROUPS_EMAILS],
    () => getAddressGroupEmailList(),
    {
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to response the list of group and email!`, error);
      },
    },
  );

  const addressList: TransferJobAddressInfo[] = useMemo(
    () =>
      data?.map((item: AddressInfo) => {
        const { name, group, id, email } = item;
        return {
          key: id.toString(),
          ...item,
          label: group ? `@${name}` : `${name} <${email}>`,
          value: id.toString(),
        };
      }) ?? [],
    [data],
  );

  const handleOk = () => {
    const groupBook: AddressOption[] = [];
    const emailBook: AddressOption[] = [];
    targetKeys?.map((item) => {
      const foundItem = addressList.find((innerItem) => innerItem.id === +item);
      if (foundItem) {
        const { id, name, email, group, label, value } = foundItem;
        if (foundItem.group) {
          groupBook.push({ id, name, email, group, label, value });
        } else {
          emailBook.push({ id, name, email, group, label, value });
        }
      }
    });

    if (setRecipients) {
      setRecipients([...groupBook, ...emailBook, ...customEmails]);
    }

    if (setEachRecipients) {
      setEachRecipients({
        emailBook,
        groupBook,
        customEmails: customEmails.map((item) => item.email),
      });
    }

    onClose();
  };

  const handleChange = useCallback((targetKeys: string[], direction: TransferDirection, moveKeys: string[]) => {
    setTargetKeys(targetKeys);
  }, []);

  const handleSelectChange = useCallback((sourceSelectedKeys: string[], targetSelectedKeys: string[]) => {
    setSelectedKeys([...sourceSelectedKeys, ...targetSelectedKeys]);
  }, []);

  useEffect(() => {
    const groups = recipients.filter((item) => item.group).map((item) => item.value);
    const emails = recipients.filter((item) => !item.group && item.id).map((item) => item.value);
    const custom = recipients.filter((item) => !item.group && !item.id);

    setSelectedKeys([]);
    setTargetKeys([...groups, ...emails]);
    setCustomEmails(custom);
  }, []);

  return {
    addressList,
    isFetching,
    targetKeys,
    selectedKeys,
    handleOk,
    handleChange,
    handleSelectChange,
  };
}
