export { default } from './GlobalModal';
