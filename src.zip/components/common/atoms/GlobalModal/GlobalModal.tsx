import { GlobalModalDispatchContext, GlobalModalStateContext } from '@libs/context/GlobalModalContext';
import { Fragment, useContext, useMemo } from 'react';

export const GlobalModal = () => {
  const openedModals = useContext(GlobalModalStateContext);
  const { close } = useContext(GlobalModalDispatchContext);

  const renderModals = useMemo(
    () =>
      Array.from(openedModals).map(([key, value]) => {
        const { Component, props } = value;
        return (
          <Component
            key={key}
            {...props}
            onClose={() => {
              close(key);
            }}
          />
        );
      }),
    [openedModals, close],
  );

  return <Fragment>{renderModals}</Fragment>;
};

export default GlobalModal;
