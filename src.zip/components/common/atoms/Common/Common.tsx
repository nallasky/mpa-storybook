import { css, SerializedStyles } from '@emotion/react';
import { Empty, Result } from 'antd';
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export function CommonTableEmpty({
  isError,
  size = 'large',
}: {
  isError: boolean;
  size?: 'small' | 'large';
}): JSX.Element {
  return isError ? (
    <Result css={commonTableEmptyStyle({ size })} title="Failed to response data" status="warning" />
  ) : (
    <Empty description="No Data" />
  );
}

const commonTableEmptyStyle = ({ size }: { size: 'small' | 'large' }) => css`
  ${size === 'small' &&
  css`
    .ant-result-icon {
      .anticon {
        font-size: 2rem;
      }
    }
    .ant-result-title {
      font-size: 1rem;
    }
  `}
`;

export const ellipsisLineStyle = ({ line = 0 }: { line?: number }): SerializedStyles => css`
  ${line > 0 &&
  css`
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: ${line};
    -webkit-box-orient: vertical;
  `}
`;

export function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    // window.scrollTo(0, 0);
    document.documentElement.scrollTo({
      top: 0,
      left: 0,
      behavior: 'auto', // Optional if you want to skip the scrolling animation
    });
  }, [pathname]);

  return null;
}
