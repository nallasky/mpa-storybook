export { default } from './SearchText';
