import { css } from '@emotion/react';
import { Input } from 'antd';
import React, { memo, useCallback, useEffect, useState } from 'react';

type SearchTextProps = {
  value: string | undefined;
  onSearch: (value: string | undefined) => void;
  placeholder?: string;
  disabled?: boolean;
};

const SearchText = ({ placeholder = '', value, onSearch, disabled = false }: SearchTextProps): JSX.Element => {
  const [search, setSearch] = useState<string>();

  const onChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
  }, []);

  const onSearchInput = useCallback(
    (value: string) => {
      onSearch(value);
    },
    [onSearch],
  );

  useEffect(() => {
    setSearch((prev) => (prev !== value ? value : prev));
  }, [value]);

  return (
    <Input.Search
      css={style}
      placeholder={placeholder}
      value={search}
      onChange={onChange}
      onSearch={onSearchInput}
      enterButton
      allowClear
      disabled={disabled}
    />
  );
};

export default memo(SearchText);

const style = css`
  .ant-input-affix-wrapper {
    border-radius: 0.625rem 0 0 0.625rem !important;
  }
  .ant-input-search-button {
    border-radius: 0 0.625rem 0.625rem 0 !important;
  }
`;
