import { Form, Input } from 'antd';
import { Rule } from 'antd/es/form';
import { LabelTooltipType } from 'antd/es/form/FormItemLabel';
import React from 'react';

export type FormPasswordProps = {
  label: string;
  name: string;
  disabled?: boolean;
  onClick?: () => void;
  tooltip?: LabelTooltipType;
  rules?: Rule[];
};

function FormPassword({ label, name, disabled = false, onClick, tooltip, rules }: FormPasswordProps): JSX.Element {
  // const Tooltip = () => (
  //   <div>
  //     <p>{`Characters that can be entered: alphabet, number, Special Characters !@#$%^&*()_-+=<>?`}</p>
  //     <p>Allowed to be at least 6 characters long and up to 30 characters long.</p>
  //   </div>
  // );

  const mergeRules = () => {
    const merge: Rule[] = [];
    merge.push({ required: true, message: `Please input ${label.toLocaleLowerCase()}!` });
    if (Array.isArray(rules) && rules.length > 0) {
      rules.forEach((rule) => {
        merge.push(rule);
      });
    }
    return merge;
  };

  return (
    <Form.Item label={label} name={name} rules={mergeRules()} tooltip={tooltip}>
      <Input.Password disabled={disabled} visibilityToggle={false} onClick={onClick} />
    </Form.Item>
  );
}

export default React.memo(FormPassword);
