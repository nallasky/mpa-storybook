import { regExpIpAddressWithLocalhost } from '@libs/util/validation';
import { Form, Input, Space, Switch } from 'antd';
import { SwitchClickEventHandler } from 'antd/lib/switch';
import React from 'react';

export type FormIpAddressWithLocalhostProps = {
  label: string;
  name: string;
  disabled?: boolean;
  disabledLocalhost?: boolean;
  onClick?: () => void;
  localhost: boolean;
  onClickLocalhost: SwitchClickEventHandler;
};

function FormIpAddressWithLocalhost({
  label,
  name,
  disabled = false,
  disabledLocalhost = false,
  localhost,
  onClickLocalhost,
}: FormIpAddressWithLocalhostProps): JSX.Element {
  return (
    <Form.Item
      label={<Label localhost={localhost} onClickLocalhost={onClickLocalhost} disabled={disabledLocalhost} />}
      name={name}
      rules={[
        {
          required: true,
          message: `Please input ${label.toLocaleLowerCase()}!`,
        },
        {
          message: `The address must be in the form of xxx.xxx.xxx.xxx!`,
          pattern: regExpIpAddressWithLocalhost(),
        },
      ]}
    >
      <Input disabled={disabled} />
    </Form.Item>
  );
}

export type LabelProps = {
  localhost: boolean;
  onClickLocalhost: SwitchClickEventHandler;
  disabled?: boolean;
};
function Label({ localhost, onClickLocalhost, disabled = false }: LabelProps): JSX.Element {
  return (
    <Space size="middle">
      <div>IP Address</div>
      <Switch
        size="small"
        checkedChildren="localhost"
        unCheckedChildren="localhost"
        checked={localhost}
        onClick={onClickLocalhost}
        disabled={disabled}
      />
    </Space>
  );
}

export default React.memo(FormIpAddressWithLocalhost);
