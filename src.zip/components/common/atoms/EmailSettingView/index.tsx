export { default } from './EmailSettingView';
