export { default } from './CustomIcon';
