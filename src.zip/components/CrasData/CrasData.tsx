import {
  CopyOutlined,
  DeleteOutlined,
  EditOutlined,
  ExportOutlined,
  ImportOutlined,
  PlusOutlined,
} from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import RefreshBtn from '@components/common/atoms/RefreshBtn/RefreshBtn';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { enableHoverActiveStyle, hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { CrasDataInfo } from '@typesdef/crasData';
import { Empty, Space, Table } from 'antd';
import { useCallback } from 'react';
import CrasDataAddModal from './CrasDataAddModal';
import CrasDataImportModal from './CrasDataImportModal';
import useCrasDataList from './hooks/useCrasDataList';

export type CrasDataStatusProps = {};

export default function CrasDataStatus({}: CrasDataStatusProps): JSX.Element {
  const {
    list,
    openDeleteModal,
    openImportModal,
    openExportModal,
    openEditModal,
    openAddModal,
    isFetching,
    refreshStatusList,
    onCopy,
  } = useCrasDataList();

  const titleRender = useCallback(
    () => (
      <TableHeader title={<TableHeaderTitle total={list?.length ?? 0} />}>
        <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddModal}>
          Add
        </AntdButton>
        <AntdButton icon={<CopyOutlined />} type="primary" onClick={() => onCopy()}>
          Copy
        </AntdButton>
        <RefreshBtn onClick={refreshStatusList} loading={isFetching} />
      </TableHeader>
    ),
    [list, openAddModal, refreshStatusList, isFetching, onCopy],
  );

  const ImportRender = useCallback(
    (value: number, record: CrasDataInfo, index: number) => {
      const onClick = () => openImportModal(value);
      return <ImportOutlined css={hoverActiveStyle} onClick={onClick} />;
    },
    [openImportModal],
  );

  const exportRender = useCallback(
    (value: number, record: CrasDataInfo, index: number) => {
      const onClick = () => openExportModal(value);
      const disabled = false;
      // const disabled = record.crasDataJudgeRulesItemCount <= 0 && record.createCrasDataItemCount <= 0 ? true : false;
      return (
        <div css={enableHoverActiveStyle(true)}>
          <ExportOutlined onClick={onClick} />
        </div>
      );
    },
    [openExportModal],
  );

  const createEditRender = useCallback(
    (value: number, record: CrasDataInfo, index: number) => {
      const onClick = () => openEditModal('create', record.id, record.companyFabName);
      return (
        <Space>
          <div>{value} Items</div>
          <EditOutlined css={hoverActiveStyle} onClick={onClick} />
        </Space>
      );
    },
    [openEditModal],
  );

  const judgeEditRender = useCallback(
    (value: number, record: CrasDataInfo, index: number) => {
      const onClick = () => openEditModal('judge', record.id, record.companyFabName);
      return (
        <Space>
          <div>{value} Items</div>
          <EditOutlined css={hoverActiveStyle} onClick={onClick} />
        </Space>
      );
    },
    [openEditModal],
  );

  const deleteRender = useCallback(
    (value: number, record: CrasDataInfo, index: number) => {
      const onClick = () => openDeleteModal(value);
      return <DeleteOutlined css={hoverActiveStyle} onClick={onClick} />;
    },
    [openDeleteModal],
  );

  return (
    <div css={style}>
      <Table<CrasDataInfo>
        rowKey={'id'}
        dataSource={isFetching ? undefined : list}
        bordered
        title={titleRender}
        size="small"
        pagination={{
          position: ['bottomCenter'],
          total: list?.length ?? 0,
          showSizeChanger: true,
        }}
        loading={isFetching}
        locale={{
          emptyText: isFetching ? <Empty description="Loading" /> : <Empty description="No Data" />,
        }}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<CrasDataInfo> {...columnProps.companyFabName} />
        <Table.Column<CrasDataInfo> {...columnProps.createCrasDataItemCount} render={createEditRender} />
        <Table.Column<CrasDataInfo> {...columnProps.crasDataJudgeRulesItemCount} render={judgeEditRender} />
        <Table.Column<CrasDataInfo> {...columnProps.date} />
        <Table.Column<CrasDataInfo> {...columnProps.import} render={ImportRender} />
        <Table.Column<CrasDataInfo> {...columnProps.export} render={exportRender} />
        <Table.Column<CrasDataInfo> {...columnProps.delete} render={deleteRender} />
      </Table>
      <CrasDataAddModal />
      <CrasDataImportModal />
    </div>
  );
}

const style = css`
  width: 100%;
`;

type ColumnName =
  | 'companyFabName'
  | 'createCrasDataItemCount'
  | 'crasDataJudgeRulesItemCount'
  | 'date'
  | 'import'
  | 'export'
  | 'delete';

const columnProps: TableColumnPropsType<CrasDataInfo, ColumnName> = {
  companyFabName: {
    key: 'companyFabName',
    title: <TableColumnTitle>User-Fab Name</TableColumnTitle>,
    dataIndex: 'companyFabName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'companyFabName'),
    },
    shouldCellUpdate: (cur, prev) => cur.companyFabName !== prev.companyFabName,
    width: getPixelPercent(1360, 320),
  },
  createCrasDataItemCount: {
    key: 'createCrasDataItemCount',
    title: <TableColumnTitle>Create Cras Data Item</TableColumnTitle>,
    dataIndex: 'createCrasDataItemCount',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'createCrasDataItemCount'),
    },
    shouldCellUpdate: (cur, prev) =>
      cur.createCrasDataItemCount !== prev.createCrasDataItemCount ||
      cur.id !== prev.id ||
      cur.companyFabName !== prev.companyFabName,
    width: getPixelPercent(1360, 280),
  },
  crasDataJudgeRulesItemCount: {
    key: 'crasDataJudgeRulesItemCount',
    title: <TableColumnTitle>Cras Data Judge Rules Item</TableColumnTitle>,
    dataIndex: 'crasDataJudgeRulesItemCount',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'crasDataJudgeRulesItemCount'),
    },
    shouldCellUpdate: (cur, prev) =>
      cur.crasDataJudgeRulesItemCount !== prev.crasDataJudgeRulesItemCount ||
      cur.id !== prev.id ||
      cur.companyFabName !== prev.companyFabName,
    width: getPixelPercent(1360, 280),
  },
  date: {
    key: 'date',
    title: <TableColumnTitle>Last Updated</TableColumnTitle>,
    dataIndex: 'date',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'date'),
    },
    shouldCellUpdate: (cur, prev) => cur.date !== prev.date,
    width: getPixelPercent(1360, 180),
  },
  import: {
    key: 'id',
    dataIndex: 'id',
    title: <TableColumnTitle>Import</TableColumnTitle>,
    align: 'center',
    shouldCellUpdate: (cur, prev) => cur.id !== prev.id,
    width: getPixelPercent(1360, 100),
  },
  export: {
    key: 'export',
    dataIndex: 'id',
    title: <TableColumnTitle>Export</TableColumnTitle>,
    align: 'center',
    shouldCellUpdate: (cur, prev) =>
      cur.id !== prev.id ||
      cur.createCrasDataItemCount !== prev.createCrasDataItemCount ||
      cur.crasDataJudgeRulesItemCount !== prev.crasDataJudgeRulesItemCount,
    width: getPixelPercent(1360, 100),
  },
  delete: {
    key: 'delete',
    dataIndex: 'id',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    shouldCellUpdate: (cur, prev) => cur.id !== prev.id,
    width: getPixelPercent(1360, 100),
  },
};
