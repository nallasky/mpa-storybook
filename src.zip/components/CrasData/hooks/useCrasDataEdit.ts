import { openAntdModal } from '@components/common/atoms/AntdModal';
import {
  useDeleteCrasDataCreate,
  useDeleteCrasDataJudge,
  useGetCrasDataCrasList,
  useGetCrasDataCreateOption,
  useGetCrasDataJudgeList,
  useGetCrasDataJudgeOption,
} from '@libs/query/crasData';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import {
  crasIdSelector,
  setCrasCreateFixedOption,
  setCrasDrawerTypeReducer,
  setCrasIdReducer,
  setCrasItemIdReducer,
  setCrasJudgeFixedOption,
  setCrasShowCreateDrawerReducer,
  setCrasShowJudgeDrawerReducer,
} from '@reducers/slices/crasData';
import { CrasDataCreateOption, CrasDataJudgeOption } from '@typesdef/crasData';
import { AxiosError } from 'axios';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';

interface useCrasDataEditCreateProps {
  type: 'create' | 'judge';
}

export default function useCrasDataEdit({ type }: useCrasDataEditCreateProps) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const selectId = useSelector(crasIdSelector);
  const { id } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const siteName = searchParams.get('name');
  const [search, setSearch] = useState<string | undefined>();

  const onSearch = useCallback((value: string | undefined) => {
    setSearch(value);
  }, []);

  const {
    data: createData,
    isFetching: isFetchingCreate,
    refetch: refetchCreateList,
  } = useGetCrasDataCrasList(selectId as number, {
    initialData: [],
    placeholderData: [],
    enabled: type === 'create' && !!selectId,
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to response the list of create cras data!`, error);
    },
  });

  const createList = useMemo(() => {
    if (!search) {
      return createData ?? [];
    }

    return createData?.filter((item) => item.itemName.toLowerCase().includes(search.toLowerCase())) ?? [];
  }, [search, createData]);

  const {
    data: judgeData,
    isFetching: isFetchingJudge,
    refetch: refetchJudgeList,
  } = useGetCrasDataJudgeList(selectId as number, {
    initialData: [],
    placeholderData: [],
    enabled: type === 'judge' && !!selectId,
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to response the list of cras judge rules!`, error);
    },
  });

  const judgeList = useMemo(() => {
    if (!search) {
      return judgeData ?? [];
    }

    return judgeData?.filter((item) => item.itemName.toLowerCase().includes(search.toLowerCase())) ?? [];
  }, [search, judgeData]);

  useGetCrasDataCreateOption({
    enabled: type === 'create' && !!selectId,
    onSuccess: (data) => {
      dispatch(setCrasCreateFixedOption(data as CrasDataCreateOption));
    },
  });

  useGetCrasDataJudgeOption({
    enabled: type === 'judge' && !!selectId,
    onSuccess: (data) => {
      dispatch(setCrasJudgeFixedOption(data as CrasDataJudgeOption));
    },
  });

  const { mutateAsync: deleteCreateMutateAsync, isLoading: isCreateDeleting } = useDeleteCrasDataCreate({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to delete create cras data!`, error);
    },
    onSuccess: () => {
      openNotification('success', 'Success', 'Succeed to delete create cras data');
    },
    onSettled: () => {
      //refetchCreateList();
      queryClient.invalidateQueries([QUERY_KEY.RULES_CRAS_MANUAL_CREATE_LIST, selectId], {
        exact: true,
      });
    },
  });

  const { mutateAsync: deleteJudgeMutateAsync, isLoading: isJudgeDeleting } = useDeleteCrasDataJudge({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to delete cras judge rules!`, error);
    },
    onSuccess: () => {
      openNotification('success', 'Success', 'Succeed to delete cras judge rules');
    },
    onSettled: () => {
      //refetchJudgeList();
      queryClient.invalidateQueries([QUERY_KEY.RULES_CRAS_MANUAL_JUDGE_LIST, selectId], { exact: true });
    },
  });

  const openDeleteModal = useCallback(
    (itemId: number) => {
      const className = type === 'create' ? 'delete-cras-create-item' : 'delete-cras-judge-item';
      const title = type === 'create' ? 'Delete create cras data item' : 'Delete cras judge rules item';
      const content =
        type === 'create'
          ? 'Are you sure to delete create cras data item?'
          : 'Are you sure to delete cras judge rules item?';
      openAntdModal('confirm', {
        className,
        title,
        content,
        okText: 'Delete',
        onOk: async () => {
          try {
            if (type === 'create') {
              await deleteCreateMutateAsync({ id: selectId as number, itemId: itemId });
            } else {
              await deleteJudgeMutateAsync({ id: selectId as number, itemId: itemId });
            }
          } catch (e) {
            console.error(e);
          }
        },
      });
    },
    [type, selectId, deleteCreateMutateAsync, deleteJudgeMutateAsync],
  );

  const openEditModal = useCallback(
    (itemId: number) => {
      openAntdModal('confirm', {
        className: type === 'create' ? 'edit-cras-data-create' : 'edit-cras-data-judge',
        title: type === 'create' ? 'Edit Create Cras Data Item' : 'Edit Cras Data Judge Rules Item',
        content:
          type === 'create'
            ? 'Are you sure to edit create cras data item?'
            : 'Are you sure to edit cras data judge rules item?',
        okText: 'Edit',
        onOk: () => {
          dispatch(setCrasDrawerTypeReducer('edit'));
          dispatch(setCrasItemIdReducer(itemId));
          if (type === 'create') {
            dispatch(setCrasShowCreateDrawerReducer(true));
          } else {
            dispatch(setCrasShowJudgeDrawerReducer(true));
          }
        },
      });
    },
    [type, dispatch],
  );

  const openAddModal = useCallback(() => {
    dispatch(setCrasDrawerTypeReducer('add'));
    dispatch(setCrasItemIdReducer(undefined));
    if (type === 'create') {
      dispatch(setCrasShowCreateDrawerReducer(true));
    } else {
      dispatch(setCrasShowJudgeDrawerReducer(true));
    }
  }, [type, dispatch]);

  const refreshList = useCallback(() => {
    if (type === 'create') {
      refetchCreateList();
    } else {
      refetchJudgeList();
    }
  }, [type, refetchCreateList, refetchJudgeList]);

  const goBack = () => {
    navigate(-1);
  };

  useEffect(() => {
    dispatch(setCrasIdReducer(id ? +id : undefined));
  }, [id, dispatch]);

  return {
    manualList: type === 'create' ? createList : judgeList,
    isFetchingList: type === 'create' ? isFetchingCreate : isFetchingJudge,
    openDeleteModal,
    openEditModal,
    openAddModal,
    refreshList,
    goBack,
    siteName,
    search,
    onSearch,
  } as const;
}
