import { postCrasManualJudgeAdd, putCrasManualJudgeEdit } from '@libs/axios/requests';
import { ReqPostCrasDataJudgeAdd, ReqPutCrasDataJudgeEdit } from '@libs/axios/types';
import { useGetCrasDataEquipOption, useGetCrasDataJudgeInfo } from '@libs/query/crasData';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useForm } from 'antd/es/form/Form';
import { PresetStatusColorType } from 'antd/es/_util/colors';
import { AxiosError } from 'axios';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useDispatch } from 'react-redux';
import {
  crasDrawerTypeSelector,
  crasEquipOptionSelector,
  crasIdSelector,
  crasItemIdSelector,
  crasJudgeOptionSelector,
  crasShowJudgeDrawerSelector,
  setCrasEquipOption,
  setCrasShowJudgeDrawerReducer,
} from '../../../reducers/slices/crasData';
import useTypedSelector from '../../../reducers/useTypedSelector';
import { CrasDataJudgeInfo } from '../../../types/crasData';

export interface FormCrasDataJudgeInfo extends Omit<CrasDataJudgeInfo, 'itemId'> {}

export interface TestQueryStatusInfo {
  status: PresetStatusColorType;
  error: string;
}
export default function useCrasDataEditJudge() {
  const queryClient = useQueryClient();
  const [form] = useForm<FormCrasDataJudgeInfo>();
  const dispatch = useDispatch();
  const isDrawer = useTypedSelector(crasShowJudgeDrawerSelector);
  const drawerType = useTypedSelector(crasDrawerTypeSelector);
  const selectId = useTypedSelector(crasIdSelector);
  const selectItemId = useTypedSelector(crasItemIdSelector);
  const judgeOptions = useTypedSelector(crasJudgeOptionSelector);
  const equipOptions = useTypedSelector(crasEquipOptionSelector);
  const [isAllEquip, setIsAllEquip] = useState(true);

  const setAllEquip = useCallback(
    (checked: boolean) => {
      console.log('checked', checked);
      setIsAllEquip(checked);
      if (checked) {
        form.setFieldsValue({ equipments: [] });
      }
    },
    [form],
  );

  const { isFetching: isFetchingEquipOption } = useGetCrasDataEquipOption(selectId as number, 'judge', {
    // TODO: disable equipments
    // enabled: Boolean(selectId) && isDrawer,
    enabled: false,
    onSuccess: (data) => {
      dispatch(setCrasEquipOption(data ?? []));
    },
    onError: (error: AxiosError) => {
      dispatch(setCrasEquipOption([]));
      openNotification('error', 'Error', `Failed to response the list of equipment options!`, error);
    },
  });

  const { isFetching: isFetchingItems } = useGetCrasDataJudgeInfo(selectId as number, selectItemId as number, {
    enabled: drawerType === 'edit' && isDrawer && Boolean(selectId) && Boolean(selectItemId),
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to response the list of cras data judge rules item`, error);
    },
    onSuccess: (resData) => {
      // TODO: disable equipments
      // const equipments = resData.equipments ?? [];
      form.setFieldsValue({
        ...resData,
        // equipments,
      });
      // setIsAllEquip(equipments.length === 0);
    },
  });

  const { mutate: addMutate, isLoading: isAdding } = useMutation(
    ({ id, postData }: { id: number; postData: ReqPostCrasDataJudgeAdd }) => postCrasManualJudgeAdd(id, postData),
    {
      mutationKey: [MUTATION_KEY.RULES_CRAS_JUDGE_ADD],
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to add cras data judge rules item!`, error);
      },
      onSuccess: () => {
        openNotification('success', 'Success', 'Succeed to add cras data judge rules item.');
      },
      onSettled: () => {
        //queryClient.fetchQuery([QUERY_KEY.RULES_CRAS_GET_MANUAL_JUDGE, selectSiteId]);
        queryClient.invalidateQueries([QUERY_KEY.RULES_CRAS_MANUAL_JUDGE_LIST, selectId], { exact: true });
        dispatch(setCrasShowJudgeDrawerReducer(false));
      },
    },
  );
  const { mutate: editMutate, isLoading: isEditing } = useMutation(
    ({ id, itemId, postData }: { id: number; itemId: number; postData: ReqPutCrasDataJudgeEdit }) =>
      putCrasManualJudgeEdit(id, itemId, postData),
    {
      mutationKey: [MUTATION_KEY.RULES_CRAS_JUDGE_EDIT],
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to edit cras data judge rules item!`, error);
      },
      onSuccess: () => {
        openNotification('success', 'Success', 'Succeed to edit cras data judge rules item.');
      },
      onSettled: () => {
        //queryClient.fetchQuery([QUERY_KEY.RULES_CRAS_GET_MANUAL_JUDGE, selectSiteId];
        queryClient.invalidateQueries([QUERY_KEY.RULES_CRAS_MANUAL_JUDGE_LIST, selectId], { exact: true });
        dispatch(setCrasShowJudgeDrawerReducer(false));
      },
    },
  );

  const isDisableItems = useMemo(
    () => isFetchingItems || isAdding || isEditing,

    [isFetchingItems, isAdding, isEditing],
  );

  const closeDrawer = () => {
    dispatch(setCrasShowJudgeDrawerReducer(false));
  };

  const onFinish = useCallback(() => {
    const reqData = form.getFieldsValue();
    if (drawerType === 'add') {
      selectId && addMutate({ id: selectId, postData: reqData });
    } else {
      selectId && selectItemId && editMutate({ id: selectId, itemId: selectItemId, postData: reqData });
    }
  }, [drawerType, selectId, selectItemId, addMutate, editMutate, form]);

  const initData = useCallback(() => {
    if (drawerType === 'add') {
      form.setFieldsValue({ enable: true });
    }
    setIsAllEquip(true);
  }, [drawerType, form]);

  useEffect(() => {
    if (isDrawer) {
      initData();
    } else {
      form.resetFields();
    }
  }, [isDrawer, initData, form]);

  return {
    form,
    drawerType,
    isDrawer,
    closeDrawer,
    onFinish,
    initData,
    judgeOptions,
    equipOptions,
    isDisableItems,
    isFetchingItems,
    isAdding,
    isEditing,
    isFetchingEquipOption,
    isAllEquip,
    setAllEquip,
  };
}
