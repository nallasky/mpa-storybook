import { postCrasManualCreateAdd, postCrasManualCreateTestQuery, putCrasManualCreateEdit } from '@libs/axios/requests';
import { ReqPostCrasDataCreateAdd, ReqPostCrasDataTestQuery, ReqPutCrasDataCreateEdit } from '@libs/axios/types';
import {
  useGetCrasDataCreateColumnList,
  useGetCrasDataCreateInfo,
  useGetCrasDataCreateTargetTable,
  useGetCrasDataEquipOption,
} from '@libs/query/crasData';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import {
  crasCreateOptionSelector,
  crasCreateTableSelector,
  crasDrawerTypeSelector,
  crasEquipOptionSelector,
  crasIdSelector,
  crasItemIdSelector,
  crasShowCreateDrawerSelector,
  setCrasCreateColumnTableOption,
  setCrasCreateSelectTable,
  setCrasCreateTargetTableOption,
  setCrasEquipOption,
  setCrasShowCreateDrawerReducer,
} from '@reducers/slices/crasData';
import useTypedSelector from '@reducers/useTypedSelector';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { CrasDataCreateInfo } from '@typesdef/crasData';
import { useForm } from 'antd/es/form/Form';
import { SelectValue } from 'antd/es/select';
import { PresetStatusColorType } from 'antd/es/_util/colors';
import { AxiosError } from 'axios';
import { useCallback, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';

export interface FormCrasDataCreateInfo extends Omit<CrasDataCreateInfo, 'itemId' | 'targetCol'> {
  targetCol1: string;
  targetCol2: string;
}

export interface TestQueryStatusInfo {
  status: PresetStatusColorType;
  error: string;
}
export default function useCrasDataEditCreate() {
  const queryClient = useQueryClient();
  const [form] = useForm<FormCrasDataCreateInfo>();
  const dispatch = useDispatch();
  const isDrawer = useTypedSelector(crasShowCreateDrawerSelector);
  const drawerType = useTypedSelector(crasDrawerTypeSelector);
  const selectId = useTypedSelector(crasIdSelector);
  const selectItemId = useTypedSelector(crasItemIdSelector);
  const selectTable = useTypedSelector(crasCreateTableSelector);
  const createOptions = useTypedSelector(crasCreateOptionSelector);
  const equipOptions = useTypedSelector(crasEquipOptionSelector);
  const [testQueryStatus, setTestQueryStatus] = useState<TestQueryStatusInfo>({
    status: 'default',
    error: '',
  });
  const [isAllEquip, setIsAllEquip] = useState(true);
  const [isOpenSelect, setIsOpenSelect] = useState({ targetCol1: false, targetCol2: false });

  const setAllEquip = useCallback(
    (checked: boolean) => {
      setIsAllEquip(checked);
      if (checked) {
        form.setFieldsValue({ equipments: [] });
      }
    },
    [form],
  );

  const { isFetching: isFetchingEquipOption } = useGetCrasDataEquipOption(selectId as number, 'create', {
    // TODO: disable equipments
    // enabled: Boolean(selectId) && isDrawer,
    enabled: false,
    onSuccess: (data) => {
      dispatch(setCrasEquipOption(data ?? []));
    },
    onError: (error: AxiosError) => {
      dispatch(setCrasEquipOption([]));
      openNotification('error', 'Error', `Failed to response the list of equipment options!`, error);
    },
  });

  const { isFetching: isFetchingItems } = useGetCrasDataCreateInfo(selectId as number, selectItemId as number, {
    enabled: drawerType === 'edit' && isDrawer && Boolean(selectId) && Boolean(selectItemId),
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to response the list of create cras data item`, error);
    },
    onSuccess: (resData) => {
      // TODO: disable equipments
      // const equipments = resData.equipments ?? [];

      const { targetCol, ...rest } = resData;
      const [targetCol1, targetCol2] = targetCol;

      form.setFieldsValue({
        ...rest,
        targetCol1,
        targetCol2,
      });
      // setIsAllEquip(equipments.length === 0);
      dispatch(setCrasCreateSelectTable(resData.targetTable));
    },
  });

  const { isFetching: isFetchingTargetTable } = useGetCrasDataCreateTargetTable(selectId as number, {
    enabled: isDrawer && Boolean(selectId),
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to response the list of target table!`, error);
      dispatch(setCrasCreateTargetTableOption([]));
    },
    onSuccess: (resData) => {
      dispatch(setCrasCreateTargetTableOption(resData));
    },
  });

  const { isFetching: isFetchingTargetColumn } = useGetCrasDataCreateColumnList(
    selectId as number,
    selectTable as string,
    {
      enabled: isDrawer && Boolean(selectId) && Boolean(selectTable),
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to response the list of target table!`, error);
        dispatch(setCrasCreateColumnTableOption([]));
      },
      onSuccess: (resData) => {
        dispatch(setCrasCreateColumnTableOption(resData));
      },
    },
  );

  const { mutate: testQueryMutate, isLoading: isTestQuerying } = useMutation(
    (postData: ReqPostCrasDataTestQuery) => postCrasManualCreateTestQuery(postData),
    {
      mutationKey: [MUTATION_KEY.RULES_CRAS_CREATE_TEST_QUERY],
      onError: (error: AxiosError) => {
        setTestQueryStatus({ status: 'error', error: error.message });
      },
      onSuccess: () => {
        setTestQueryStatus({ status: 'success', error: '' });
      },
    },
  );

  const { mutate: addMutate, isLoading: isAdding } = useMutation(
    ({ id, postData }: { id: number; postData: ReqPostCrasDataCreateAdd }) => postCrasManualCreateAdd(id, postData),
    {
      mutationKey: [MUTATION_KEY.RULES_CRAS_CREATE_ADD],
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to add cras create data!`, error);
      },
      onSuccess: () => {
        openNotification('success', 'Success', 'Succeed to add cras create data.');
      },
      onSettled: () => {
        //queryClient.fetchQuery([QUERY_KEY.RULES_CRAS_GET_MANUAL_CREATE, selectId]);
        queryClient.invalidateQueries([QUERY_KEY.RULES_CRAS_MANUAL_CREATE_LIST, selectId], {
          exact: true,
        });
        dispatch(setCrasShowCreateDrawerReducer(false));
      },
    },
  );
  const { mutate: editMutate, isLoading: isEditing } = useMutation(
    ({ id, itemId, postData }: { id: number; itemId: number; postData: ReqPutCrasDataCreateEdit }) =>
      putCrasManualCreateEdit(id, itemId, postData),
    {
      mutationKey: [MUTATION_KEY.RULES_CRAS_CREATE_EDIT],
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to edit cras create data!`, error);
      },
      onSuccess: () => {
        openNotification('success', 'Success', 'Succeed to edit create cras data.');
      },
      onSettled: () => {
        //queryClient.fetchQuery([QUERY_KEY.RULES_CRAS_GET_MANUAL_CREATE, selectId]);
        queryClient.invalidateQueries([QUERY_KEY.RULES_CRAS_MANUAL_CREATE_LIST, selectId], {
          exact: true,
        });
        dispatch(setCrasShowCreateDrawerReducer(false));
      },
    },
  );

  const isFetching = isFetchingItems || isFetchingTargetTable || isFetchingTargetColumn || isFetchingEquipOption;
  const isMutating = isTestQuerying || isAdding || isEditing;

  const closeDrawer = () => {
    dispatch(setCrasShowCreateDrawerReducer(false));
  };

  const onSelectTargetTable = useCallback(
    (value: SelectValue) => {
      dispatch(setCrasCreateSelectTable(value as string));
      form.setFieldsValue({
        targetTable: value as string,
        targetCol1: undefined,
        targetCol2: undefined,
      });
    },
    [dispatch, form],
  );

  const onFinish = useCallback(async () => {
    try {
      const response = await form.validateFields();
      const { targetCol1, targetCol2, ...rest } = response;
      const targetCol = [targetCol1, targetCol2].filter((col) => Boolean(col));
      const reqData = {
        ...rest,
        targetCol,
      };

      if (drawerType === 'add') {
        selectId && addMutate({ id: selectId, postData: reqData });
      } else {
        selectId && selectItemId && editMutate({ id: selectId, itemId: selectItemId, postData: reqData });
      }
    } catch (e) {
      console.error(e);
    }
  }, [drawerType, selectId, selectItemId, addMutate, editMutate, form]);

  const testQuery = async () => {
    try {
      const { manualWhere, targetCol1, targetCol2, targetTable } = await form.validateFields([
        'targetTable',
        'targetCol1',
        'manualWhere',
      ]);
      const targetCol = [targetCol1, targetCol2].filter((col) => Boolean(col));
      setTestQueryStatus({ status: 'processing', error: '' });
      testQueryMutate({ id: selectId as number, manualWhere, targetCol, targetTable });
    } catch (e) {
      console.error(e);
      setTestQueryStatus({ status: 'default', error: '' });
    }
  };

  const initData = useCallback(() => {
    if (drawerType === 'add') {
      form.setFieldsValue({ enable: true });
    }
    setIsAllEquip(true);
  }, [drawerType, form]);

  const setOpenTargetColumn = (name: 'targetCol1' | 'targetCol2') => (open: boolean) => {
    setIsOpenSelect((prev) => ({ ...prev, [name]: open }));
  };

  const onSaveTargetColumn = (name: 'targetCol1' | 'targetCol2') => (value: string) => {
    form.setFieldValue(name, value);
  };

  useEffect(() => {
    if (isDrawer) {
      initData();
    } else {
      form.resetFields();
      setTestQueryStatus({ status: 'default', error: '' });
    }
  }, [isDrawer, initData, form]);

  return {
    form,
    drawerType,
    isDrawer,
    closeDrawer,
    onFinish,
    initData,
    createOptions,
    equipOptions,
    onSelectTargetTable,
    isOpenSelect,
    setOpenTargetColumn,
    onSaveTargetColumn,
    selectTable,
    testQuery,
    testQueryStatus,
    isAllEquip,
    setAllEquip,
    isFetching,
    isMutating,
  };
}
