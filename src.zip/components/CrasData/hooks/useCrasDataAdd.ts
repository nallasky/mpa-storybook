import { postCrasAddSite } from '@libs/axios/requests';
import { useGetCrasDataRegisterStatusList } from '@libs/query/crasData';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { crasShowAddSelector, setCrasAddVisibleReducer } from '@reducers/slices/crasData';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'antd/es/form/Form';
import { AxiosError } from 'axios';
import { useCallback, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

export interface FormCrasSiteName {
  siteId: number;
}

export default function useCrasDataAdd() {
  const [form] = useForm<FormCrasSiteName>();
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const visible = useSelector(crasShowAddSelector);
  const setVisible = useCallback(
    (visible: boolean) => {
      dispatch(setCrasAddVisibleReducer(visible));
    },
    [dispatch],
  );

  const {
    data,
    isFetching: isFetchingNames,
    refetch: refetchNames,
  } = useGetCrasDataRegisterStatusList('siteId', {
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to response the list of user-fab name`, error);
    },
  });

  const { mutate, isLoading: isFetchingAdd } = useMutation((reqData: FormCrasSiteName) => postCrasAddSite(reqData), {
    mutationKey: [MUTATION_KEY.RULES_CRAS_ADD_SITE],
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to add cras data!`, error);
    },
    onSuccess: () => {
      openNotification('success', 'Success', `Success to add cras data.`);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_CRAS_LIST], { exact: true });
      setVisible(false);
    },
  });

  const handleOk = useCallback(
    (reqData: FormCrasSiteName) => {
      mutate(reqData);
    },
    [mutate],
  );

  const handleCancel = () => {
    setVisible(false);
  };

  useEffect(() => {
    if (visible) {
      refetchNames();
      form.resetFields();
    }
  }, [visible]);

  return {
    form,
    visible,
    setVisible,
    unregisterSiteIdList: data?.unregistered ?? [],
    isFetchingNames,
    isFetchingAdd,
    handleOk,
    handleCancel,
  };
}
