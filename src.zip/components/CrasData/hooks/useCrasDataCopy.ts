import { useGetCrasDataRegisterStatusList, usePostCrasDataCopy } from '@libs/query/crasData';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { useForm } from 'antd/es/form/Form';
import { AxiosError } from 'axios';

export default function useCrasDataCopy({ visible, onClose }: GlobalModalDefaultProps) {
  const [form] = useForm<{
    source: number;
    target: number;
  }>();
  const queryClient = useQueryClient();

  const { data, isFetching } = useGetCrasDataRegisterStatusList('id', {
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to response the list of user-fab name`, error);
    },
  });

  const { mutate: mutateCopy, isLoading: isLoadingCopy } = usePostCrasDataCopy({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to copy cras data.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', 'Failed to copy cras data!', error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_CRAS_LIST], { exact: true });
      onClose();
    },
  });

  const onOk = async () => {
    if (!(await form.validateFields())) {
      return;
    }
    const { source, target } = form.getFieldsValue();
    mutateCopy({
      siteId: source,
      newSiteId: target,
    });
  };

  return { form, onOk, registeredIdOptions: data?.registered ?? [], isFetching, isLoadingCopy };
}
