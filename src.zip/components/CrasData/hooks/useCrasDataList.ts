import { openAntdModal } from '@components/common/atoms/AntdModal';
import { PAGE_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { DeleteCrasDeleteSite, getCrasExportFile } from '@libs/axios/requests';
import { useGetCrasDataList } from '@libs/query/crasData';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import {
  initCrasReducer,
  setCrasAddVisibleReducer,
  setCrasIdReducer,
  setCrasImportVisibleReducer,
} from '@reducers/slices/crasData';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { AxiosError } from 'axios';
import { saveAs } from 'file-saver';
import { useCallback, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import CrasDataCopy from '../Modal/CrasDataCopy';

export default function useCrasDataList() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const { openModal } = useModals();

  const {
    data: list,
    isFetching: isFetching,
    refetch: refetchList,
  } = useGetCrasDataList({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to response the list of cras data!`, error);
    },
  });

  const { mutateAsync: deleteMutateAsync, isLoading: isDeleting } = useMutation(
    (id: number) => DeleteCrasDeleteSite(id),
    {
      mutationKey: [MUTATION_KEY.RULES_CRAS_DELETE],
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to delete cras data!`, error);
      },
      onSuccess: () => {
        openNotification('success', 'Success', 'Succeed to delete cras data');
      },
      onSettled: () => {
        //refetchList();
        queryClient.invalidateQueries([QUERY_KEY.RULES_CRAS_LIST], { exact: true });
      },
    },
  );

  const openDeleteModal = useCallback(
    (id: number) => {
      openAntdModal('confirm', {
        className: 'edit-cras-data',
        title: 'Delete Cras Data',
        content: 'Are you sure to delete cras data?',
        okText: 'Delete',
        onOk: async () => {
          await deleteMutateAsync(id);
        },
      });
    },
    [deleteMutateAsync],
  );

  const openImportModal = (id: number) => {
    dispatch(setCrasIdReducer(+id ?? undefined));
    dispatch(setCrasImportVisibleReducer(true));
  };

  const openExportModal = (id: number) => {
    openAntdModal('confirm', {
      className: 'export-cras-data',
      title: 'Export Cras Data',
      content: 'Are you sure to export cras data?',
      okText: 'Export',
      onOk: async () => {
        try {
          const { data, fileName } = await getCrasExportFile(id);
          saveAs(data, fileName);
          openNotification('success', 'Success', `Succeed to export cras data '${fileName}'.`);
        } catch (e) {
          console.error(e);
          openNotification('error', 'Error', 'Failed to export cras data!');
        }
      },
    });
  };

  const openEditModal = useCallback(
    (type: 'create' | 'judge', id: number, siteName: string) => {
      if (type === 'create') {
        navigate(`${PAGE_URL.RULES_CRAS_DATA_EDIT_CREATE(id, siteName)}`);
      } else {
        navigate(`${PAGE_URL.RULES_CRAS_DATA_EDIT_JUDGE(id, siteName)}`);
      }
    },
    [navigate],
  );

  const openAddModal = () => {
    dispatch(setCrasAddVisibleReducer(true));
  };
  const refreshStatusList = () => {
    queryClient.fetchQuery([QUERY_KEY.RULES_CRAS_LIST]);
  };

  const onCopy = useCallback(() => {
    openModal(MODAL_NAME.CRAS_DATA.COPY, CrasDataCopy);
  }, [openModal]);

  useEffect(() => {
    dispatch(initCrasReducer());
  }, []);

  return {
    list,
    openDeleteModal,
    openImportModal,
    openExportModal,
    openEditModal,
    openAddModal,
    isFetching,
    refreshStatusList,
    onCopy,
  };
}
