import { CheckOutlined, CloseOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import FormInput from '@components/common/atoms/CustomForm/FormInput';
import FormNumber from '@components/common/atoms/CustomForm/FormNumber';
import FormSelectMultiple from '@components/common/atoms/CustomForm/FormSelectMultiple';
import SearchPopover from '@components/common/atoms/SelectPopover';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { convertRemToPixels } from '@libs/util/remToPixels';
import { Badge, Col, Divider, Drawer, Form, Input, Row, Space, Spin, Switch } from 'antd';
import { Rule } from 'antd/es/form';
import { LabeledValue } from 'antd/lib/select';
import { useMemo } from 'react';
import useCrasDataEditCreate, { TestQueryStatusInfo } from './hooks/useCrasDataEditCreate';

export type CrasDataEditCreateDrawerProps = {};

export default function CrasDataEditCreateDrawer({}: CrasDataEditCreateDrawerProps): JSX.Element {
  const {
    form,
    drawerType,
    isDrawer,
    closeDrawer,
    onFinish,
    createOptions,
    equipOptions,
    onSelectTargetTable,
    isOpenSelect,
    setOpenTargetColumn,
    onSaveTargetColumn,
    selectTable,
    testQuery,
    testQueryStatus,
    isAllEquip,
    setAllEquip,
    isFetching,
    isMutating,
  } = useCrasDataEditCreate();

  const equipRules: Rule[] = useMemo(
    () => [
      {
        message: `Please select equipments!`,
        validator: (rule, value) =>
          new Promise((resolve, reject) => {
            if (isAllEquip) {
              return resolve(true);
            } else {
              return value.length > 0 ? resolve(true) : reject(false);
            }
          }),
      },
    ],
    [isAllEquip],
  );

  const modeText = drawerType === 'add' ? 'Add' : 'Edit';

  return (
    <Drawer
      title={
        <Space>
          <div>{`${modeText} Create Cras Data Item`}</div>
          {isFetching && <Spin size="small" />}
        </Space>
      }
      placement="right"
      width={convertRemToPixels(45)}
      closable={true}
      onClose={closeDrawer}
      visible={isDrawer}
      destroyOnClose={true}
      // getContainer={false}
      // forceRender
      extra={
        <Space>
          <AntdButton onClick={closeDrawer} disabled={isMutating} type="default">
            Cancel
          </AntdButton>
          <AntdButton type="primary" onClick={onFinish} disabled={isMutating}>
            {modeText}
          </AntdButton>
        </Space>
      }
    >
      <Form form={form} onFinish={onFinish} layout="vertical" disabled={isFetching || isMutating}>
        <FormInnerContainer>
          <FormInnerSection>
            <Form.Item label="Enable" name="enable" valuePropName="checked" required css={formEnableStyle}>
              <Switch checkedChildren={<CheckOutlined />} unCheckedChildren={<CloseOutlined />} />
            </Form.Item>
          </FormInnerSection>
          <Divider type="vertical" css={formUpperDividerVStyle} />
          <FormInnerSection
            css={css`
              display: flex;
              align-items: flex-end;
              flex-direction: column;
            `}
          >
            <AntdButton
              type="primary"
              css={testQueryBtnStyle}
              disabled={isFetching || isMutating}
              loading={isMutating}
              onClick={testQuery}
            >
              Test Query
            </AntdButton>
            <TestQueryStatus statusInfo={testQueryStatus} />
          </FormInnerSection>
        </FormInnerContainer>
        <Divider type="horizontal" css={formDividerHStyle} />
        <FormInnerContainer>
          <FormInnerSection>
            {/* TODO: disable equipments */}
            {/* <FormSelectMultiple
              label="Equipments"
              labelExtra={
                <Switch
                  checkedChildren="All"
                  unCheckedChildren="All"
                  size="small"
                  checked={isAllEquip}
                  onClick={setAllEquip}
                  disabled={isFetchingEquipOption || isDisableItems}
                />
              }
              name="equipments"
              placeholder={isAllEquip ? 'All equipments are selected.' : 'Select the equipments.'}
              options={equipOptions}
              disabled={isDisableItems || isAllEquip}
              loading={isFetchingEquipOption}
              mode="multiple"
              rules={equipRules}
            /> */}
            <FormInput label="Item Name" name="itemName" placeholder="Enter the item name." required />
            <FormSelectMultiple
              label="Target Table"
              name="targetTable"
              placeholder="Select the target table."
              options={createOptions?.targetTable}
              onSelect={onSelectTargetTable}
            />
            <Form.Item
              label="Target Column 1"
              name="targetCol1"
              required
              rules={[
                {
                  required: true,
                  message: `Please input target column 1!`,
                },
              ]}
            >
              <Input
                addonAfter={
                  <SearchPopover<string>
                    title="Column Name 1"
                    open={isOpenSelect.targetCol1}
                    onOpen={setOpenTargetColumn('targetCol1')}
                    onSave={onSaveTargetColumn('targetCol1')}
                    width="15rem"
                    options={
                      createOptions?.columnTable?.map(
                        (item): LabeledValue => ({ key: item, label: item, value: item }),
                      ) ?? []
                    }
                    disabled={Boolean(!selectTable)}
                  />
                }
                placeholder={selectTable ? 'Select the target column.' : 'Select the target table first.'}
                disabled={Boolean(!selectTable)}
              />
            </Form.Item>
            <Form.Item label="Target Column 2" name="targetCol2">
              <Input
                addonAfter={
                  <SearchPopover<string>
                    title="Column Name 2"
                    open={isOpenSelect.targetCol2}
                    onOpen={setOpenTargetColumn('targetCol2')}
                    onSave={onSaveTargetColumn('targetCol2')}
                    width="15rem"
                    options={
                      createOptions?.columnTable?.map(
                        (item): LabeledValue => ({ key: item, label: item, value: item }),
                      ) ?? []
                    }
                    disabled={Boolean(!selectTable)}
                  />
                }
                placeholder={selectTable ? 'Select the target column.' : 'Select the target table first.'}
                disabled={Boolean(!selectTable)}
              />
            </Form.Item>
            <FormInput label="Comments" name="comments" placeholder="Enter the comments." />
          </FormInnerSection>

          <Divider type="vertical" css={formDividerVStyle} />

          <FormInnerSection>
            <FormSelectMultiple
              label="Operations"
              name="operations"
              placeholder="Select the operations."
              options={createOptions?.operations}
            />
            <FormSelectMultiple
              label="Calculate Period Unit"
              name="calPeriodUnit"
              placeholder="Select the calculate period unit."
              options={createOptions?.calPeriodUnit}
            />
            <FormSelectMultiple
              label="Calculate Result Type"
              name="calResultType"
              placeholder="Select the calculate result type."
              options={createOptions?.calResultType}
            />
            <FormNumber label="Coefficient" name="coef" placeholder="Enter the number of coefficient" required />
            <FormInput
              label="Manual Input Search Condition"
              name="manualWhere"
              placeholder="Select the manual input search condition."
              required={false}
            />
          </FormInnerSection>
        </FormInnerContainer>

        <Divider type="horizontal" css={formDividerHStyle} />
      </Form>
    </Drawer>
  );
}

const FormInnerContainer = styled(Row)`
  flex-direction: row;
  flex-wrap: nowrap;
`;

const FormInnerSection = styled(Col)`
  width: 20rem;
`;

const formSubmitStyle = css`
  .ant-form-item-control-input-content {
    display: flex;
    justify-content: center;
    align-items: center;
  }
`;

const testQueryBtnStyle = css`
  width: 9.375rem;
`;

const applyBtnStyle = css`
  width: 20rem;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 10px;
  margin-top: 1rem;
`;

const formDividerHStyle = css``;

const formDividerVStyle = css`
  height: auto;
  margin-left: 1rem;
  margin-right: 1rem;
`;

const formUpperDividerVStyle = css`
  height: auto;
  margin-left: 1rem;
  margin-right: 1rem;
  border-color: white;
`;

const formEnableStyle = css`
  flex-direction: row !important;
  align-items: center;
  margin-bottom: 0;
  .ant-form-item-label {
    padding: 0;
  }
  .ant-form-item-control {
    margin-left: 1rem;
  }
`;

const FormHidden = styled(Form.Item)`
  width: 0;
  height: 0;
  margin: 0;
  padding: 0;
`;

function TestQueryStatus({ statusInfo }: { statusInfo: TestQueryStatusInfo }) {
  const statusText = useMemo(() => {
    switch (statusInfo.status) {
      case 'default':
        return 'Not tested yet';
      case 'success':
        return 'Success';
      case 'processing':
        return 'Processing';
      case 'error':
        return 'Error';
    }
  }, [statusInfo.status]);

  return (
    <div
      css={css`
        width: 20rem;
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        .error-msg {
          width: 20rem;
          text-align: right;
        }
      `}
    >
      <Badge status={statusInfo.status} text={statusText} />
      {statusInfo.error && <div className="error-msg">{statusInfo.error}</div>}
    </div>
  );
}
