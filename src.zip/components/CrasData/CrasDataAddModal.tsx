import { Form, Modal, Select } from 'antd';
import useCrasDataAdd from './hooks/useCrasDataAdd';

export default function CrasDataAddModal(): JSX.Element {
  const { form, handleOk, handleCancel, isFetchingNames, isFetchingAdd, unregisterSiteIdList, visible } =
    useCrasDataAdd();

  return (
    <Modal
      title="Add Cras Data"
      visible={visible}
      okText="Add"
      onOk={form.submit}
      okButtonProps={{ loading: isFetchingAdd, disabled: isFetchingAdd || isFetchingNames }}
      onCancel={handleCancel}
      cancelButtonProps={{
        disabled: isFetchingAdd,
      }}
      closable={!isFetchingAdd}
      maskClosable={!isFetchingAdd}
    >
      <Form form={form} onFinish={handleOk} layout="vertical">
        <Form.Item
          label="User-Fab Name"
          name="siteId"
          required
          rules={[{ required: true, message: 'Please select a user-fab name!' }]}
        >
          <Select
            placeholder="Select a user-fab name."
            showSearch
            filterOption={(input, option) =>
              option ? (option.label as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
            }
            options={unregisterSiteIdList}
            loading={isFetchingAdd}
            disabled={isFetchingNames || isFetchingAdd}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
}
