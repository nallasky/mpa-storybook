import { CheckOutlined, DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import { ellipsisLineStyle } from '@components/common/atoms/Common/Common';
import RefreshBtn from '@components/common/atoms/RefreshBtn';
import SearchText from '@components/common/atoms/SearchText';
import TableHeader, { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { CrasDataManualInfo } from '@typesdef/crasData';
import { Button, Empty, PageHeader, Table } from 'antd';
import { useCallback } from 'react';
import CrasDataEditCreateDrawer from './CrasDataEditCreateDrawer';
import CrasDataEditJudgeDrawer from './CrasDataEditJudgeDrawer';
import useCrasDataEdit from './hooks/useCrasDataEdit';

export type CrasDataEditCreateProps = {
  type: 'create' | 'judge';
};

export default function CrasDataEdit({ type }: CrasDataEditCreateProps): JSX.Element {
  const {
    manualList,
    isFetchingList,
    openDeleteModal,
    openEditModal,
    openAddModal,
    refreshList,
    goBack,
    siteName,
    search,
    onSearch,
  } = useCrasDataEdit({ type });

  const titleRender = useCallback(() => {
    return (
      <TableHeader title={<TableHeaderTitle total={manualList.length} isSearched={search ? true : false} />}>
        <SearchText value={search} onSearch={onSearch} placeholder="Item Name" />
        <Button icon={<PlusOutlined />} type="primary" onClick={openAddModal}>
          Add
        </Button>
        <RefreshBtn onClick={refreshList} loading={isFetchingList} />
      </TableHeader>
    );
  }, [manualList, openAddModal, refreshList, isFetchingList, onSearch, search]);

  const equipRender = useCallback((value: string[], record: CrasDataManualInfo, index: number) => {
    const item = Array.isArray(value) && value.length > 0 ? value.join(', ') : 'All';
    return (
      <div css={ellipsisLineStyle({ line: 2 })} title={item}>
        {item}
      </div>
    );
  }, []);

  const enableRender = useCallback(
    (value: boolean, record: CrasDataManualInfo, index: number) => (value ? <CheckOutlined /> : ''),
    [],
  );

  const editRenter = useCallback(
    (value: number, record: CrasDataManualInfo, index: number) => {
      const onClick = () => openEditModal(value);
      return <EditOutlined css={hoverActiveStyle} onClick={onClick} />;
    },
    [openEditModal],
  );

  const deleteRender = useCallback(
    (value: number, record: CrasDataManualInfo, index: number) => {
      const onClick = () => openDeleteModal(value);
      return <DeleteOutlined css={hoverActiveStyle} onClick={onClick} />;
    },
    [openDeleteModal],
  );

  return (
    <div css={style}>
      <PageHeader
        onBack={goBack}
        title={
          type === 'create'
            ? `Edit Create Cras Data Item (${siteName})`
            : `Edit Cras Data Judge Rules Item (${siteName})`
        }
        css={css`
          padding: 0 0 0.5rem 0;
        `}
      />
      <Table<CrasDataManualInfo>
        rowKey={'itemId'}
        dataSource={isFetchingList ? undefined : manualList}
        bordered
        title={titleRender}
        size="small"
        pagination={{
          position: ['bottomCenter'],
          total: manualList?.length ?? 0,
          showSizeChanger: true,
        }}
        loading={isFetchingList}
        css={tableStyle}
        tableLayout="fixed"
        locale={{
          emptyText: isFetchingList ? <Empty description="Loading" /> : <Empty description="No Data" />,
        }}
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<CrasDataManualInfo> {...columnProps.enable} render={enableRender} />
        {/* TODO: disable equipments */}
        {/* <Table.Column<CrasDataManualInfo> {...createCrasColumnProps.equipments} render={equipRender} /> */}
        <Table.Column<CrasDataManualInfo> {...columnProps.itemName} />
        <Table.Column<CrasDataManualInfo> {...columnProps.edit} render={editRenter} />
        <Table.Column<CrasDataManualInfo> {...columnProps.delete} render={deleteRender} />
      </Table>
      <CrasDataEditCreateDrawer />
      <CrasDataEditJudgeDrawer />
    </div>
  );
}

const style = css`
  width: 100%;
`;

const tableStyle = css``;

type ColumnName = 'equipments' | 'itemName' | 'enable' | 'edit' | 'delete';

const columnProps: TableColumnPropsType<CrasDataManualInfo, ColumnName> = {
  equipments: {
    key: 'equipments',
    title: <TableColumnTitle>Equipments</TableColumnTitle>,
    dataIndex: 'equipments',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'equipments'),
    },
    shouldCellUpdate: (cur, prev) => cur.equipments !== prev.equipments,
  },
  itemName: {
    key: 'itemName',
    title: <TableColumnTitle>Item Name</TableColumnTitle>,
    dataIndex: 'itemName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'itemName'),
    },
    shouldCellUpdate: (cur, prev) => cur.itemName !== prev.itemName,
    width: getPixelPercent(1360, 1060),
  },

  enable: {
    key: 'enable',
    title: <TableColumnTitle>Enable</TableColumnTitle>,
    dataIndex: 'enable',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'itemName'),
    },
    shouldCellUpdate: (cur, prev) => cur.enable !== prev.enable,
    width: getPixelPercent(1360, 100),
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    dataIndex: 'itemId',
    align: 'center',
    shouldCellUpdate: (cur, prev) => cur.itemId !== prev.itemId,
    width: getPixelPercent(1360, 100),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    dataIndex: 'itemId',
    align: 'center',
    shouldCellUpdate: (cur, prev) => cur.itemId !== prev.itemId,
    width: getPixelPercent(1360, 100),
  },
};
