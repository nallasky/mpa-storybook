import React from 'react';
import styled from '@emotion/styled';

import CrasDBViewerTree from './CrasDBViewerTree';
import CrasDBViewerTitle from './CrasDBViewerTitle';
import CrasDBViewerQueryTab from './CrasDBViewerQueryTab';
import CrasDBViewerDataColumnTab from './CrasDBViewerDataColumnTab';

const CrasDBViewerWrapper = styled.div`
  display: flex;
  width: 100%;
  column-gap: 1rem;
  height: 820px;
`;

const CrasDBViewerInfoWrapper = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  row-gap: 1rem;
  & > h1 {
    margin: 0;
    line-height: 1;
  }
`;

const CrasDBViewerDataQueryWrapper = styled.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  row-gap: 1rem;
  justify-content: space-between;
  overflow: hidden;
`;

export default function CrasDBViewer() {
  return (
    <CrasDBViewerWrapper>
      <CrasDBViewerTree />
      <CrasDBViewerInfoWrapper>
        <CrasDBViewerTitle />
        <CrasDBViewerDataQueryWrapper>
          <CrasDBViewerDataColumnTab />
          <CrasDBViewerQueryTab />
        </CrasDBViewerDataQueryWrapper>
      </CrasDBViewerInfoWrapper>
    </CrasDBViewerWrapper>
  );
}