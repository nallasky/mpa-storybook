import React, { useMemo, useCallback } from 'react';
import { AxiosError } from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import { v4 as uuidv4 } from 'uuid';
import { SorterResult } from 'antd/es/table/interface';
import { TableProps } from 'antd/es/table';

import {
  CrasDBViewerDataTabInfo,
  CrasDBViewerCommonRequestParams,
  CrasDBViewerDataTableInfo,
  CrasDBViewerDataTableRowColumnItem,
  CrasDBViewerDataTableRowColumnData,
  CrasDBViewerResPagination,
} from '@/types/crasDBViewer';
import {
  CRAS_DB_VIEWER_GET_DATA_METHOD_TREE,
  CRAS_DB_VIEWER_GET_DATA_METHOD_QUERY,
  CRAS_DB_VIEWER_DATA_TAB_KEY,
  CRAS_DB_VIEWER_TABLE_ROW_UNIQUE_KEY,
} from '@constants/crasDBViewer';
import {
  crasDBViewerDataTabInfoSelector,
  setCrasDBViewerDataTableInfoReducer,
} from '@reducers/slices/GtparkCrasDBViewer';
import {
  useGetCrasDBViewerTableDataFromTree,
  usePostCrasDBViewerTableDataFromQuery,
} from '@libs/query/crasDBViewer';
import { openNotification } from '@libs/util/notification';

export default function useCrasDBViewerDataTable() {
  const dispatch = useDispatch();
  const dataTabInfo: CrasDBViewerDataTabInfo = useSelector(crasDBViewerDataTabInfoSelector);

  const { siteId, schema, table }: CrasDBViewerCommonRequestParams = dataTabInfo.selectedTreeInfo;
  const { page, size, sort }: CrasDBViewerDataTableInfo = dataTabInfo.dataTableInfo;
  const {
    getDataMethod,
    selectedTab,
    userQuery,
    selectedSource,
    isQueryOpen
  }: CrasDBViewerDataTabInfo = dataTabInfo;

  const { data: dataFromTree } = useGetCrasDBViewerTableDataFromTree(
    {
      siteId,
      schema,
      table,
      page: page - 1,
      size,
      sort,
    },
    {
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to get status of jobs!`, error);
      },
      keepPreviousData: true,
      retry: false,
      enabled:
        getDataMethod === CRAS_DB_VIEWER_GET_DATA_METHOD_TREE
          && selectedTab === CRAS_DB_VIEWER_DATA_TAB_KEY
    }
  );

  const {
    data: dataFromQuery, refetch: refetchDataFromQuery } = usePostCrasDBViewerTableDataFromQuery(
    {
      serial_nos: [],
      result_type: 0,
      siteId: selectedSource,
      sql: userQuery,
      page: page - 1,
      size,
      sort,
    },
    {
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to get status of jobs!`, error);
      },
      keepPreviousData: true,
      retry: false,
      enabled:
        getDataMethod === CRAS_DB_VIEWER_GET_DATA_METHOD_QUERY
        && selectedTab === CRAS_DB_VIEWER_DATA_TAB_KEY
    }
  );

  const tableRowColumnData: CrasDBViewerDataTableRowColumnData = useMemo(() => {
    const result: CrasDBViewerDataTableRowColumnData = {
      rows: [],
      columns: []
    };

    const currentData: CrasDBViewerResPagination | undefined =
      getDataMethod === CRAS_DB_VIEWER_GET_DATA_METHOD_TREE ? dataFromTree : dataFromQuery;

    if (!currentData || !currentData?.content.length) {
      return result;
    }

    currentData.content.forEach((v: CrasDBViewerDataTableRowColumnItem, i: number) => {
      if (!i) {
        Object.keys(v).forEach((key: string) => {
          result.columns.push({
            key,
            title: key,
            dataIndex: key,
            align: 'center',
            sorter: true,
          });
        });
      }
      result.rows.push({
        ...v,
        [CRAS_DB_VIEWER_TABLE_ROW_UNIQUE_KEY]: uuidv4()
      });
    });

    return result;
  }, [dataFromTree, dataFromQuery, getDataMethod]);

  const totalElements: number | undefined = useMemo(() => {
    if (getDataMethod === CRAS_DB_VIEWER_GET_DATA_METHOD_TREE) {
      return dataFromTree?.totalElements;
    }
    return getDataMethod === CRAS_DB_VIEWER_GET_DATA_METHOD_QUERY ?
      dataFromQuery?.totalElements : 0;
  }, [dataFromTree, dataFromQuery, getDataMethod]);

  const onChangeTable = useCallback<NonNullable<TableProps<any>['onChange']>>(
    (pagination, filters, sorter, extra) => {
      const { current, pageSize } = pagination;
      const { columnKey, order } = sorter as SorterResult<any>;

      switch (extra.action) {
        case 'paginate':
          dispatch(setCrasDBViewerDataTableInfoReducer({
            page: current ?? 1,
            size: pageSize ?? 100,
            sort,
          }))
          break;

        case 'sort':
          dispatch(setCrasDBViewerDataTableInfoReducer({
            page: 1,
            size: 100,
            sort: order ?`${columnKey},${order.replace('end', '')}` : null,
          }));
          break;

        case 'filter':
        default:
          break;
      }
  }, [sort]);

  const onExecuteQuery = useCallback(() => {
    refetchDataFromQuery();
  }, [refetchDataFromQuery]);

  return {
    tableRowColumnData,
    isQueryOpen,
    getDataMethod,
    pagination: {
      current: page,
      pageSize: size,
      total: totalElements ?? 0,
    },
    onChangeTable,
    onExecuteQuery,
  };
};