import React from 'react';
import { Table } from 'antd';

import {
  CRAS_DB_VIEWER_TABLE_ROW_UNIQUE_KEY,
  CRAS_DB_VIEWER_GET_DATA_METHOD_NONE,
  CRAS_DB_VIEWER_TABLE_MIN_HEIGHT,
  CRAS_DB_VIEWER_TABLE_MAX_HEIGHT,
  CRAS_DB_VIEWER_TABLE_COLUMN_COMMON_WIDTH,
  CRAS_DB_VIEWER_DATA_TABLE_PAGE_SIZE_OPTIONS,
} from '@constants/crasDBViewer';
import CrasDBViewerEmptyMessage from '../CrasDBViewerEmptyMessage';
import useCrasDBViewerDataTable from './hooks/useCrasDBViewerDataTable';

export default function CrasDBViewerDataTable() {
  const {
    tableRowColumnData: { rows, columns },
    getDataMethod,
    isQueryOpen,
    pagination,
    onChangeTable,
  } = useCrasDBViewerDataTable();

  if (getDataMethod === CRAS_DB_VIEWER_GET_DATA_METHOD_NONE) {
    return <CrasDBViewerEmptyMessage />;
  }

  return (
    <Table
      dataSource={rows}
      columns={columns}
      bordered
      size="small"
      tableLayout="fixed"
      rowKey={CRAS_DB_VIEWER_TABLE_ROW_UNIQUE_KEY}
      scroll={{
        x: CRAS_DB_VIEWER_TABLE_COLUMN_COMMON_WIDTH * column.length,
        y: isQueryOpen ? CRAS_DB_VIEWER_TABLE_MIN_HEIGHT : CRAS_DB_VIEWER_TABLE_MAX_HEIGHT,
      }}
      pagination={{
        ...pagination,
        position: ['bottomCenter'],
        showSizeChanger: true,
        pageSizeOptions: CRAS_DB_VIEWER_DATA_TABLE_PAGE_SIZE_OPTIONS,
      }}
      onChange={onChangeTable}
    />
  );
};
