import { useDispatch, useSelector } from 'react-redux';

import {
  crasDBViewerDataColumnTabInfoSelector,
  crasDBViewerDataTableInfoInitialState,
  setCrasDBViewerSelectedTabReducer,
  setCrasDBViewerDataTableInfoReducer,
} from '@reducers/slices/GtparkCrasDBViewer';
import {
  CRAS_DB_VIEWER_GET_DATA_METHOD_NONE,
  CRAS_DB_VIEWER_GET_DATA_METHOD_TREE,
  CRAS_DB_VIEWER_GET_DATA_METHOD_QUERY,
  CRAS_DB_VIEWER_DATA_TAB_KEY,
} from '@constants/crasDBViewer';
import { CrasDBViewerDataColumnTabInfo, CrasDBViewerSelectedTab } from '@/types/crasDBViewer';
import useCrasDBViewerColumnTable from '../../CrasDBViewerColumnTable/hooks/useCrasDBViewerColumnTable';

export default function useCrasDBViewerDataColumnTab() {
  const dispatch = useDispatch();
  const { getDataMethod, selectedTab }: CrasDBViewerDataColumnTabInfo =
      useSelector(crasDBViewerDataColumnTabInfoSelector);
  const { refetchColumnTable } = useCrasDBViewerColumnTable();

  const onChangeTab = (key: string) => {
    dispatch(setCrasDBViewerSelectedTabReducer(key as CrasDBViewerSelectedTab));
  };

  const onClickRefresh = () => {
    if (getDataMethod === CRAS_DB_VIEWER_GET_DATA_METHOD_NONE) {
      return;
    }

    switch(getDataMethod) {
      case CRAS_DB_VIEWER_GET_DATA_METHOD_TREE:
        if (selectedTab === CRAS_DB_VIEWER_DATA_TAB_KEY) {
          dispatch(setCrasDBViewerDataTableInfoReducer(crasDBViewerDataTableInfoInitialState));
        } else {
          refetchColumnTable();
        }
        break;

      case CRAS_DB_VIEWER_GET_DATA_METHOD_QUERY:
        dispatch(setCrasDBViewerDataTableInfoReducer(crasDBViewerDataTableInfoInitialState));
        break;

      default:
        break;
    }
  };

  return {
    isShowColumnTab: getDataMethod === CRAS_DB_VIEWER_GET_DATA_METHOD_TREE,
    selectedTab,
    onChangeTab,
    onClickRefresh,
  };
};