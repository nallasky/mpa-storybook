import React from 'react';
import styled from '@emotion/styled';
import { SyncOutlined } from '@ant-design/icons';
import { Button, Tabs } from 'antd';

import {
  CRAS_DB_VIEWER_DATA_TAB_NAME,
  CRAS_DB_VIEWER_COLUMN_TAB_NAME,
  CRAS_DB_VIEWER_DATA_TAB_KEY,
  CRAS_DB_VIEWER_COLUMN_TAB_KEY,
} from '@constants/crasDBViewer';
import useCrasDBViewerDataColumnTab from './hooks/useCrasDBViewerDataColumnTab';
import CrasDBViewerDataTable from '../CrasDBViewerDataTable/CrasDBViewerDataTable';
import CrasDBViewerColumnTable from '../CrasDBViewerColumnTable/CrasDBViewerColumnTable';

const CrasDBViewerTableColumnWrapper = styled.div`
  position: relative;
  flex-grow: 2;
  max-width: 1047px;
  & > .ant-tabs,
  & .ant-tabs-content,
  & .ant-tabs-content > div {
    height: 100%;
  }
  & > button {
    position: absolute;
    top: 0;
    right: 0;
  }
  & .ant-table-column-title,
  & .ant-table-thead .ant-table-cell {
    word-break: break-word;
    font-weight: bold;
  }
  & .ant-table-body {
    overflow: auto !important;
    &::-webkit-scrollbar {
      height: 8px;
      width: 8px;
    }
    &::-webkit-scrollbar-track {
      background-color: transparent;
    }
    &::-webkit-scrollbar-thumb {
      background-color: rgba(0, 0, 0, 0.2);
    }
    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }
  }
`;

export default function CrasDBViewerDataColumnTab() {
  const {
    isShowColumnTab,
    selectedTab,
    onChangeTab,
    onClickRefresh,
  } = useCrasDBViewerDataColumnTab();

  return (
    <CrasDBViewerTableColumnWrapper>
      <Tabs
        type="card"
        activeKey={selectedTab}
        onTabClick={(key: string) => onChangeTab(key)}
      >
        <Tabs.TabPane tab={CRAS_DB_VIEWER_DATA_TAB_NAME} key={CRAS_DB_VIEWER_DATA_TAB_KEY}>
          <CrasDBViewerDataTable />
        </Tabs.TabPane>
        {isShowColumnTab && (
          <Tabs.TabPane tab={CRAS_DB_VIEWER_COLUMN_TAB_NAME} key={CRAS_DB_VIEWER_COLUMN_TAB_KEY}>
            <CrasDBViewerColumnTable />
          </Tabs.TabPane>
        )}
      </Tabs>
      <Button shape="circle" icon={<SyncOutlined />} onClick={onClickRefresh} />
    </CrasDBViewerTableColumnWrapper>
  );
}
