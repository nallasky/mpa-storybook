import React, { useState, useMemo, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { AxiosError } from 'axios';
import { DatabaseOutlined, TableOutlined } from '@ant-design/icons';

import type { DataNode } from 'antd/es/tree';

import {
  CrasDBViewerTableListItem,
  CrasDBViewerOptionList,
  CrasDBViewerCommonRequestParams,
  CrasDBViewerGetDataMethod,
} from '@/types/crasDBViewer';
import {
  setCrasDBViewerQuerySourceOptionListReducer,
  setCrasDBViewerTreeRefreshReducer,
  setCrasDBViewerSelectedTreeInfoReducer,
  initializeCrasDBViewer,
  crasDBViewerGetDataMethodSelector,
} from '@reducers/slices/GtparkCrasDBViewer';
import { useGetCrasDBViewerTableList } from '@libs/query/crasDBViewer';
import { CRAS_DB_VIEWER_TREE_SPLIT_TEXT, CRAS_DB_VIEWER_GET_DATA_METHOD_TREE } from '@constants/crasDBViewer';
import { openNotification } from '@libs/util/notification';

const transformData = (inputArray: any[]) => {
  const transformedArray: DataNode[] = [];

  const createChildren = (parentKey: string, schema: string[], siteId: number) => {
    const children: DataNode[] = [];
    for (const tableName of schema) {
      const table: DataNode = {
        title: tableName,
        key: `${parentKey}${CRAS_DB_VIEWER_TREE_SPLIT_TEXT}${tableName}${CRAS_DB_VIEWER_TREE_SPLIT_TEXT}${siteId}`,
        icon: <TableOutlined />,
        selectable: true,
        children: [],
      };
      children.push(table);
    }
    return children;
  };

  const createDatabase = (parentKey: string, database: CrasDBViewerTableListItem) => {
    const { dbname, schema, siteId } = database;

    const databaseNode: DataNode = {
      title: dbname,
      key: `${parentKey}${CRAS_DB_VIEWER_TREE_SPLIT_TEXT}${dbname}`,
      icon: <DatabaseOutlined />,
      selectable: false,
      children: [],
    };

    for (const schemaEntry of Object.entries(schema)) {
      const schemaName: string = schemaEntry[0];
      const schemaKey = `${databaseNode.key}${CRAS_DB_VIEWER_TREE_SPLIT_TEXT}${schemaName}`;
      const schemaChildren: DataNode[] = createChildren(schemaKey, schemaEntry[1], siteId);

      const schemaNode: DataNode = {
        title: schemaName,
        key: schemaKey,
        icon: <DatabaseOutlined />,
        selectable: false,
        children: schemaChildren,
      };

      if (databaseNode.children) {
        databaseNode.children.push(schemaNode);
      }
    }

    return databaseNode;
  };

  inputArray.forEach((entry: CrasDBViewerTableListItem) => {
    const siteNode: DataNode | undefined =
        transformedArray.find((node: DataNode) => node.title === entry.userFab);

    if (siteNode) {
      const databaseNode: DataNode = createDatabase(siteNode.key as string, entry);
      if (siteNode.children) {
        siteNode.children.push(databaseNode);
      }
    } else {
      const newNode: DataNode = {
        title: entry.userFab,
        key: `0${CRAS_DB_VIEWER_TREE_SPLIT_TEXT}${entry.userFab}`,
        icon: <DatabaseOutlined />,
        selectable: false,
        children: [],
      };

      const databaseNode: DataNode = createDatabase(newNode.key as string, entry);
      if (newNode.children) {
        newNode.children.push(databaseNode);
      }
      transformedArray.push(newNode);
    }
  });

  return transformedArray;
};

const createCommonRequestParams = (key: string) => {
  const splitKey: string[] = key.split(CRAS_DB_VIEWER_TREE_SPLIT_TEXT).slice(3);
  return {
    siteId: Number(splitKey[2]),
    schema: splitKey[0],
    table: splitKey[1],
  };
};

export default function useCrasDBViewerTree() {
  const dispatch = useDispatch();
  const getDataMethod: CrasDBViewerGetDataMethod = useSelector(crasDBViewerGetDataMethodSelector);
  const [selectedKeys, setSelectedKeys] = useState<React.Key[]>([]);

  const { data, isLoading, refetch } = useGetCrasDBViewerTableList({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to get status of jobs!`, error);
    },
    structuralSharing:
      (oldData: CrasDBViewerTableListItem[] | undefined, newData: CrasDBViewerTableListItem[] | undefined) => {
        if (newData && JSON.stringify(oldData) !== JSON.stringify(newData)) {
          const optionList: CrasDBViewerOptionList[] = [];

          newData.forEach((item: CrasDBViewerTableListItem) => {
            const { userFab, siteId } = item;
            const isAdded = optionList.find(({ value }: CrasDBViewerOptionList) => {
              return value === siteId;
            });

            if (!isAdded) {
              optionList.push({ value: siteId, label: userFab });
            }
          });

          dispatch(setCrasDBViewerQuerySourceOptionListReducer(optionList));
          return newData;
        }
        return oldData ?? [];
      },
  });

  const convertedTreeData: DataNode[] = useMemo(() => {
    if (!data || !data.length) {
      return [];
    }
    return transformData(data);
  }, [data]);

  const refreshCallback = () => {
    refetch();
  };

  const onTableSelectCallback = (key: React.Key[]) => {
    if (key[0] === selectedKeys[0] || !key.length) {
      return;
    }
    setSelectedKeys(key);
    dispatch(setCrasDBViewerSelectedTreeInfoReducer(createCommonRequestParams(key[0] as string)));
  };

  useEffect(() => {
    if (getDataMethod !== CRAS_DB_VIEWER_GET_DATA_METHOD_TREE) {
      setSelectedKeys([]);
    }
  }, [getDataMethod]);

  useEffect(() => {
    if (selectedKeys.length) {
      const { siteId, schema, table }: CrasDBViewerCommonRequestParams =
        createCommonRequestParams(selectedKeys[0] as string);

      const findTable: CrasDBViewerTableListItem | undefined =
        data?.find(({ siteId: fSiteId, schema: fSchema }: CrasDBViewerTableListItem) => {
          if (siteId !== fSiteId) {
            return false;
          }
          if (!Object.keys(fSchema).find((v: string) => v === schema)) {
            return false;
          }
          return fSchema[schema].includes(table);
        });

      if (!findTable) {
        dispatch(setCrasDBViewerTreeRefreshReducer());
      }
    }
  }, [data]);

  useEffect(() => {
    return () => dispatch(initializeCrasDBViewer());
  }, []);

  return {
    convertedTreeData,
    isLoading,
    refreshCallback,
    selectedKeys,
    onTableSelectCallback
  };
}