import React from 'react';
import styled from '@emotion/styled';
import { DownOutlined, SyncOutlined } from '@ant-design/icons';
import { Tree, Button } from 'antd';

import useCrasDBViewerTree from './hooks/useCrasDBViewerTree';

const ViewerTreeWrapper = styled.div`
  border-right: 1px solid #dadada;
  display: flex;
  flex-direction: column;
  row-gap: 0.5rem;
  padding-right: 1rem;
  & > .button-wrapper {
    text-align: right;
  }
  & > .tree-wrapper {
    height: 100%;
    width: 280px;
    overflow: auto;
    &::-webkit-scrollbar {
      height: 6px;
      width: 6px;
    }
    &::-webkit-scrollbar-track {
      background-color: transparent;
    }
    &::-webkit-scrollbar-thumb {
      background-color: rgba(0, 0, 0, 0.2);
    }
    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }
    & .ant-tree .ant-tree-node-content-wrapper {
      display: flex;
    }
  }
`;

export default function CrasDBViewerTree(): JSX.Element {
  const { convertedTreeData, refreshCallback, selectedKeys, onTableSelectCallback } = useCrasDBViewerTree();

  return (
    <ViewerTreeWrapper>
      <div className="button-wrapper">
        <Button shape="circle" icon={<SyncOutlined />} onClick={refreshCallback} />
      </div>
      <div className="tree-wrapper">
        <Tree
          showIcon
          showLine={{
            showLeafIcon: false,
          }}
          switcherIcon={<DownOutlined />}
          treeData={convertedTreeData}
          selectedKeys={selectedKeys}
          defaultExpandedKeys={selectedKeys}
          onSelect={(key: React.Key[]) => {
            onTableSelectCallback(key);
          }}
        />
      </div>
    </ViewerTreeWrapper>
  );
}