import React from 'react';
import styled from '@emotion/styled';

const CrasDBViewerEmptyMessageWrapper = styled.div`
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  font-weight: 500;
`;

export default function CrasDBViewerEmptyMessage() {
  return (
    <CrasDBViewerEmptyMessageWrapper>
      Please Select a Table or Enter a query.
    </CrasDBViewerEmptyMessageWrapper>
  );
}