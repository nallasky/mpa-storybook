import React from 'react';
import styled from '@emotion/styled';
import { Button, Tabs, Select, Input } from 'antd';

import useCrasDBViewerQueryTab from './hooks/useCrasDBViewerQueryTab';

const QueryExpand = styled.div`
  height: ${({ isExpand }: { isExpand: boolean }) => (isExpand ? "224px" : "39px")};
  overflow: hidden;
`;

const QueryWrapper = styled.div`
  display: flex;
  flex-direction: column;
  row-gap: 0.5rem;
  & > .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    & > .select-wrapper {
      & > .title {
        display: inline-block;
        margin-right: 0.5rem;
        &::after {
          content: ":";
        }
      }
      & > button {
        margin-left: 1rem;
      }
    }
  }
  & > .main {
    & > textarea {
      resize: unset;
      &::-webkit-scrollbar {
        height: 6px;
        width: 6px;
      }
      &::-webkit-scrollbar-track {
        background-color: transparent;
      }
      &::-webkit-scrollbar-thumb {
        background-color: rgba(0, 0, 0, 0.2);
      }
      &::-webkit-scrollbar-button {
        width: 0;
        height: 0;
      }
    }
  }
  & > .footer {
    text-align: right;
  }
`;

export default function CrasDBViewerQueryTab() {
  const {
    optionList,
    selectedSource,
    isQueryOpen,
    onClickTab,
    onSourceChange,
    innerUserQuery,
    onChangeUserQuery,
    onClickDefaultQuery,
    onClickExecute,
  } = useCrasDBViewerQueryTab();

  return (
    <QueryExpand isExpand={isQueryOpen}>
      <Tabs type="card" onTabClick={onClickTab}>
        <Tabs.TabPane tab="Query" key="query">
          <QueryWrapper>
            <div className="header">
              <div className="select-wrapper">
                <span className="title">Source</span>
                <Select
                  style={{
                    width: "300px"
                  }}
                  value={selectedSource}
                  options={optionList}
                  onChange={(value: number) => onSourceChange(value)}
                  placeholder="test"
                />
                <Button type="primary" onClick={onClickDefaultQuery}>Default Query</Button>
              </div>
              <div className="button-wrapper">
                <Button type="primary" onClick={onClickExecute}>Execute</Button>
              </div>
            </div>
            <div className="main">
              <Input.TextArea
                rows={4}
                value={innerUserQuery}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>{
                  onChangeUserQuery(e.target.value);
                }}
              />
            </div>
            <div className="footer">Query Executed</div>
          </QueryWrapper>
        </Tabs.TabPane>
      </Tabs>
    </QueryExpand>
  );
}