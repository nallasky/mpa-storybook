import { useState, useEffect, useRef } from 'react';
import { AxiosError } from 'axios';
import { useDispatch, useSelector } from 'react-redux';

import {
  CrasDBViewerQueryTabInfo,
  CrasDBViewerDefaultQuery,
} from '@/types/crasDBViewer';
import { CRAS_DB_VIEWER_USER_QUERY_START_WORD } from '@constants/crasDBViewer';
import {
  crasDBViewerQueryTabInfoSelector,
  setCrasDBViewerOpenQueryReducer,
  setCrasDBViewerSelectedSourceReducer,
  setCrasDBViewerExecuteQueryReducer,
} from '@reducers/slices/GtparkCrasDBViewer';
import { useGetCrasDBViewerDefaultQuery } from '@libs/query/crasDBViewer';
import { openNotification } from '@libs/util/notification';

export default function useCrasDBViewerQueryTab() {
  const dispatch = useDispatch();
  const {
    selectedTreeInfo,
    querySourceOptionList,
    isQueryOpen,
    selectedSource,
  }: CrasDBViewerQueryTabInfo = useSelector(crasDBViewerQueryTabInfoSelector);

  const [innerUserQuery, setInnerUserQuery] = useState<string>("");
  const [isExecuteDefaultQuery, setIsExecuteDefaultQuery] = useState<boolean>(false);

  useGetCrasDBViewerDefaultQuery(
    selectedTreeInfo,
    {
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to get status of jobs!`, error);
      },
      onSuccess: (newData: CrasDBViewerDefaultQuery) => {
        setInnerUserQuery(newData.query);
      },
      onSettled: () => {
        setIsExecuteDefaultQuery(false);
      },
      enabled: isExecuteDefaultQuery,
      retry: false,
    }
  );

  const onSourceChange = (value: number) => {
    dispatch(setCrasDBViewerSelectedSourceReducer(value));
  };

  const onClickTab = () => {
    dispatch(setCrasDBViewerOpenQueryReducer());
  };

  const onChangeUserQuery = (query: string) => {
    setInnerUserQuery(query);
  };

  const onClickDefaultQuery = () => {
    if (selectedTreeInfo.siteId === null) {
      openNotification('error', 'Error', `Failed to get status of jobs!`);
      return;
    }
    setIsExecuteDefaultQuery(true);
  };

  const onClickExecute = () => {
    if (
      !innerUserQuery.length ||
      !innerUserQuery.startsWith(CRAS_DB_VIEWER_USER_QUERY_START_WORD) ||
      selectedSource === null
    ) {
      openNotification('error', 'Error', `Failed to get status of jobs!`);
      return;
    }

    dispatch(setCrasDBViewerExecuteQueryReducer(innerUserQuery));
  };

  return {
    optionList: querySourceOptionList,
    selectedSource,
    isQueryOpen,
    innerUserQuery,
    onSourceChange,
    onClickTab,
    onChangeUserQuery,
    onClickDefaultQuery,
    onClickExecute,
  };
};