import React from 'react';
import { Table } from 'antd';

import {
  CRAS_DB_VIEWER_TABLE_MIN_HEIGHT,
  CRAS_DB_VIEWER_TABLE_MAX_HEIGHT,
  CRAS_DB_VIEWER_TABLE_COLUMN_COMMON_WIDTH,
} from '@constants/crasDBViewer';
import useCrasDBViewerColumnTable from './hooks/useCrasDBViewerColumnTable';

export default function CrasDBViewerColumnTable() {
  const { tableRows, tableColumns, isQueryOpen } = useCrasDBViewerColumnTable();

  return (
    <Table
      dataSource={tableRows}
      columns={tableColumns}
      bordered
      size="small"
      tableLayout="fixed"
      scroll={{
        x: CRAS_DB_VIEWER_TABLE_COLUMN_COMMON_WIDTH * tableColumns.length,
        y: isQueryOpen ? CRAS_DB_VIEWER_TABLE_MIN_HEIGHT : CRAS_DB_VIEWER_TABLE_MAX_HEIGHT
      }}
      pagination={false}
    />
  );
};