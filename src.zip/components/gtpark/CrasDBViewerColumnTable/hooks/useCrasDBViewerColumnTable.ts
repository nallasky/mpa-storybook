import { useMemo } from 'react';
import { AxiosError } from 'axios';
import { useSelector } from 'react-redux';
import { v4 as uuidv4 } from 'uuid';
import { ColumnsType } from 'antd/es/table';

import {
  CRAS_DB_VIEWER_COLUMN_TABLE_DEFAULT_COLUMN_TITLES,
  CRAS_DB_VIEWER_GET_DATA_METHOD_TREE,
  CRAS_DB_VIEWER_COLUMN_TAB_KEY
} from '@constants/crasDBViewer';
import {
  CrasDBViewerColumnTableTitle,
  CrasDBViewerColumnTableColumn,
  CrasDBViewerColumnTabInfo,
} from '@/types/crasDBViewer';
import { useGetCrasDBViewerColumnTableData } from '@libs/query/crasDBViewer';
import { crasDBViewerColumnTabInfoSelector } from '@reducers/slices/GtparkCrasDBViewer';
import { openNotification } from '@libs/util/notification';

export default function useCrasDBViewerColumnTable() {
  const { selectedTreeInfo, getDataMethod, selectedTab, isQueryOpen }: CrasDBViewerColumnTabInfo =
    useSelector(crasDBViewerColumnTabInfoSelector);

  const { data, refetch: refetchColumnTable } = useGetCrasDBViewerColumnTableData(
    selectedTreeInfo,
    {
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to get status of jobs!`, error);
      },
      enabled: getDataMethod === CRAS_DB_VIEWER_GET_DATA_METHOD_TREE
        && selectedTab === CRAS_DB_VIEWER_COLUMN_TAB_KEY,
      retry: false,
      keepPreviousData: true,
    },
  );

  const tableRows: CrasDBViewerColumnTableColumn[] = useMemo(() => {
    if (!data) {
      return [];
    }

    return data.map((v: CrasDBViewerColumnTableColumn) => {
      return {
        ...v,
        key: uuidv4(),
      }
    });
  }, [data]);

  const tableColumns: ColumnsType<CrasDBViewerColumnTableColumn> = useMemo(() => {
    return CRAS_DB_VIEWER_COLUMN_TABLE_DEFAULT_COLUMN_TITLES.map((v: CrasDBViewerColumnTableTitle) => {
      return {
        key: v,
        title: v,
        dataIndex: v,
        align: 'center',
      };
    });
  }, []);

  return { tableColumns, tableRows, isQueryOpen, refetchColumnTable };
}