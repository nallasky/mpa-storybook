import React from 'react';

export default function CrasDBViewerTitle() {
  return <h1>Title</h1>;
}