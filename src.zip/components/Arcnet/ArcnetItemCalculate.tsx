import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { ArcnetItemCalculateData } from '@typesdef/arcnet';
import { TableColumnPropsType } from '@typesdef/common';
import { PageHeader, Popconfirm, Table } from 'antd';
import { useRef } from 'react';
import ArcnetItemCalculateAddEditDrawer from './Drawer/ArcnetItemCalculateAddEditDrawer';
import useArcnetItemCalculate from './hooks/useArcnetItemCalculate';

export default function ArcnetItemCalculate() {
  const tableRef = useRef<HTMLDivElement>(null);
  const {
    name,
    calculateList,
    isFetchingCalculateList,
    drawerState,
    openAddDrawer,
    openEditDrawer,
    onCloseEditDrawer,
    onDelete,
    backToParentPage,
  } = useArcnetItemCalculate();

  const renderTitle = () => (
    <TableHeader title={<TableHeaderTitle total={calculateList?.length ?? 0} />}>
      <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddDrawer}>
        Add
      </AntdButton>
    </TableHeader>
  );

  const renderEdit = (value: number, record: ArcnetItemCalculateData, index: number) => {
    return (
      <Popconfirm title="Are you sure to edit calculate item?" onConfirm={() => openEditDrawer(record)} okText="Edit">
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ArcnetItemCalculateData, index: number) => {
    return (
      <Popconfirm title="Are you sure to delete calculate item?" onConfirm={() => onDelete(record)} okText="Delete">
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div
      css={css`
        width: 100%;
        display: flex;
        flex-direction: column;
      `}
    >
      <PageHeader
        onBack={backToParentPage}
        title={`Calculate Items (${name})`}
        css={css`
          padding: 0 0 0.5rem 0;
        `}
      />
      <Table<ArcnetItemCalculateData>
        ref={tableRef}
        rowKey={'id'}
        dataSource={calculateList ?? []}
        bordered
        title={renderTitle}
        size="small"
        pagination={{
          position: ['bottomCenter'],
        }}
        loading={isFetchingCalculateList}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<ArcnetItemCalculateData> {...columnProps.calculate_name} />
        <Table.Column<ArcnetItemCalculateData> {...columnProps.items} />
        <Table.Column<ArcnetItemCalculateData> {...columnProps.edit} render={renderEdit} />
        <Table.Column<ArcnetItemCalculateData> {...columnProps.delete} render={renderDelete} />
      </Table>
      <ArcnetItemCalculateAddEditDrawer state={drawerState} onClose={onCloseEditDrawer} />
    </div>
  );
}

const TdContent = styled.div<{ width: number }>`
  width: ${({ width }) => width}px;
  text-overflow: ellipsis;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
`;

type ColumnName = 'calculate_name' | 'items' | 'edit' | 'delete';

const columnProps: TableColumnPropsType<ArcnetItemCalculateData, ColumnName> = {
  calculate_name: {
    key: 'calculate_name',
    title: <TableColumnTitle>Calculate Name</TableColumnTitle>,
    dataIndex: 'calculate_name',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'calculate_name'),
    },
    render: (value, record) => <TdContent width={500}>{record.calculate_name}</TdContent>,
    width: getPixelPercent(1360, 500),
  },
  items: {
    key: 'items',
    title: <TableColumnTitle>Items</TableColumnTitle>,
    dataIndex: 'items',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'items'),
    },
    render: (value, record) => (
      <TdContent title={`${record.items}`} width={660}>
        {record.items}
      </TdContent>
    ),
    width: getPixelPercent(1360, 660),
  },
  edit: {
    key: 'edit',
    dataIndex: 'id',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    width: 100,
  },

  delete: {
    key: 'delete',
    dataIndex: 'id',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: 100,
  },
};
