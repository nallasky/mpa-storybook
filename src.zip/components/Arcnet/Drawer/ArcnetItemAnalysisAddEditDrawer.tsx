import AntdButton from '@components/common/atoms/AntdButton';
import { css } from '@emotion/react';
import { ArcnetItemAnalysisData } from '@typesdef/arcnet';
import { Checkbox, Col, Drawer, Form, Input, InputNumber, Row, Space, Spin } from 'antd';
import { ArcnetItemAnalysisAddEditDrawerState } from '../hooks/useArcnetItemAnalysis';
import useArcnetItemAnalysisAddEditDrawer from '../hooks/useArcnetItemAnalysisAddEditDrawer';

export interface ArcnetItemAnalysisAddEditDrawerProps {
  state: ArcnetItemAnalysisAddEditDrawerState;
  onClose: () => void;
}

export default function ArcnetItemAnalysisAddEditDrawer({
  state,
  onClose,
}: ArcnetItemAnalysisAddEditDrawerProps): JSX.Element {
  const { mode, open } = state;
  const modeText = mode === 'add' ? 'Add' : 'Edit';
  const { form, onSave, isLoadingAddEdit } = useArcnetItemAnalysisAddEditDrawer({ state, onClose });

  return (
    <Drawer
      title={
        <Space>
          <div>{`${modeText} Analysis Item`}</div>
          {isLoadingAddEdit && <Spin size="small" />}
        </Space>
      }
      open={open}
      onClose={onClose}
      width={700}
      maskClosable={!isLoadingAddEdit}
      destroyOnClose
      extra={
        <Space>
          <AntdButton onClick={onClose} disabled={isLoadingAddEdit} type="default">
            Cancel
          </AntdButton>
          <AntdButton type="primary" onClick={onSave} disabled={isLoadingAddEdit}>
            {modeText}
          </AntdButton>
        </Space>
      }
    >
      <div css={style}>
        <Form form={form} disabled={isLoadingAddEdit} layout="vertical">
          <Row gutter={[16, 16]}>
            <FormInputNumber<ArcnetItemAnalysisData> label="No" name="no" required />
            <FormInput<ArcnetItemAnalysisData> label="Start IO" name="start_io" maxLength={32} />
            <FormCheckBox<ArcnetItemAnalysisData> label="Target" name="target" required />
            <FormInput<ArcnetItemAnalysisData> label="End CMD" name="end_command" maxLength={32} />
            <FormInput<ArcnetItemAnalysisData> label="Unit" name="unit" required maxLength={8} />
            <FormInput<ArcnetItemAnalysisData> label="End IO" name="end_io" maxLength={32} />
            <FormInput<ArcnetItemAnalysisData> label="Name" name="name" required maxLength={128} />
            <FormInput<ArcnetItemAnalysisData> label="Cancel CMD" name="cancel_command" maxLength={32} />
            <FormInput<ArcnetItemAnalysisData>
              label="Start Condition CMD"
              name="start_condition_command"
              maxLength={32}
            />
            <FormInput<ArcnetItemAnalysisData> label="Cancel IO" name="cancel_io" maxLength={32} />
            <FormInput<ArcnetItemAnalysisData> label="Start Condition IO" name="start_condition_io" maxLength={32} />
            <FormInput<ArcnetItemAnalysisData> label="Description" name="description" />
            <FormInput<ArcnetItemAnalysisData> label="Start CMD" name="start_command" maxLength={32} />
          </Row>
        </Form>
      </div>
    </Drawer>
  );
}

const style = css``;

interface FormInputNumberProps<T> {
  label: string;
  name: Extract<keyof T, string>;
  min?: number;
  max?: number;
  required?: boolean;
}

function FormInputNumber<T>({ label, name, min = 1, max = 9999999, required = false }: FormInputNumberProps<T>) {
  return (
    <Col span={12}>
      <Form.Item
        label={label}
        name={name}
        required={required}
        rules={
          required
            ? [
                {
                  type: 'number',
                  required: true,
                  message: `Please input a ${label}!`,
                },
              ]
            : undefined
        }
      >
        <InputNumber
          min={min}
          max={max}
          maxLength={max.toString().length}
          placeholder={`Input a ${label}.`}
          style={{ width: '100%' }}
        />
      </Form.Item>
    </Col>
  );
}

interface FormInputProps<T> {
  label: string;
  name: Extract<keyof T, string>;
  required?: boolean;
  maxLength?: number;
}

function FormInput<T>({ label, name, maxLength, required = false }: FormInputProps<T>) {
  return (
    <Col span={12}>
      <Form.Item
        label={label}
        name={name}
        required={required}
        rules={
          required
            ? [
                {
                  type: 'string',
                  required: true,
                  message: `Please input a ${label}!`,
                },
              ]
            : undefined
        }
      >
        <Input maxLength={maxLength} placeholder={`Input a ${label}.`} />
      </Form.Item>
    </Col>
  );
}

interface FormCheckBoxProps<T> {
  label: string;
  name: Extract<keyof T, string>;
  min?: number;
  required?: boolean;
}

function FormCheckBox<T>({ label, name, required = false }: FormCheckBoxProps<T>) {
  return (
    <Col span={12}>
      <Form.Item label={label} name={name} required={required} valuePropName="checked">
        <Checkbox>Enable</Checkbox>
      </Form.Item>
    </Col>
  );
}
