import AntdButton from '@components/common/atoms/AntdButton';
import { css } from '@emotion/react';
import { ArcnetItemCalculateData } from '@typesdef/arcnet';
import { Drawer, Form, Input, Space, Spin } from 'antd';
import { ArcnetItemCalculateAddEditDrawerState } from '../hooks/useArcnetItemCalculate';
import useArcnetItemCalculateAddEditDrawer from '../hooks/useArcnetItemCalculateAddEditDrawer';

export interface ArcnetItemCalculateAddEditDrawerProps {
  state: ArcnetItemCalculateAddEditDrawerState;
  onClose: () => void;
}

export default function ArcnetItemCalculateAddEditDrawer({
  state,
  onClose,
}: ArcnetItemCalculateAddEditDrawerProps): JSX.Element {
  const { mode, open } = state;
  const modeText = mode === 'add' ? 'Add' : 'Edit';
  const { form, onSave, isLoadingAddEdit } = useArcnetItemCalculateAddEditDrawer({ state, onClose });

  return (
    <Drawer
      title={
        <Space>
          <div>{`${modeText} Calculate Item`}</div>
          {isLoadingAddEdit && <Spin size="small" />}
        </Space>
      }
      open={open}
      onClose={onClose}
      width={500}
      maskClosable={!isLoadingAddEdit}
      destroyOnClose
      extra={
        <Space>
          <AntdButton onClick={onClose} disabled={isLoadingAddEdit} type="default">
            Cancel
          </AntdButton>
          <AntdButton type="primary" onClick={onSave} disabled={isLoadingAddEdit}>
            {modeText}
          </AntdButton>
        </Space>
      }
    >
      <div css={style}>
        <Form form={form} disabled={isLoadingAddEdit} layout="vertical">
          <FormInput<ArcnetItemCalculateData> label="Calculate Name" name="calculate_name" required />
          <FormInput<ArcnetItemCalculateData> label="Items" name="items" required />
        </Form>
      </div>
    </Drawer>
  );
}

const style = css``;

interface FormInputProps<T> {
  label: string;
  name: Extract<keyof T, string>;
  required?: boolean;
  maxLength?: number;
}

function FormInput<T>({ label, name, maxLength, required = false }: FormInputProps<T>) {
  return (
    <Form.Item
      label={label}
      name={name}
      required={required}
      rules={
        required
          ? [
              {
                type: 'string',
                required: true,
                message: `Please input a ${label}!`,
              },
            ]
          : undefined
      }
    >
      <Input maxLength={maxLength} placeholder={`Input a ${label}.`} />
    </Form.Item>
  );
}
