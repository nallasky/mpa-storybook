import { useGetArcnetItemRegisterStatus, usePostArcnetItem } from '@libs/query/arcnet';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { MutateArcnetItemAddData } from '@typesdef/arcnet';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { useForm } from 'antd/es/form/Form';
import { LabeledValue } from 'antd/es/select';
import { AxiosError } from 'axios';

export interface FormArcnetItemAdd extends Omit<MutateArcnetItemAddData, 'id' | 'company_fab_name'> {}

export default function useArcnetItemAddModal({ onClose, visible }: GlobalModalDefaultProps) {
  const [form] = useForm<FormArcnetItemAdd>();
  const queryClient = useQueryClient();

  const { data: registerStatus, isFetching: isFetchingRegisterStatus } = useGetArcnetItemRegisterStatus({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to get user-fab name list!`, error);
    },
  });

  const unregisteredList: LabeledValue[] =
    registerStatus?.unregistered?.map((item) => ({
      key: item.site_id.toString(),
      label: item.company_fab_name,
      value: item.site_id,
    })) ?? [];

  const { mutate: mutateAdd, isLoading: isLoadingAdd } = usePostArcnetItem({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to add arcnet item!`, error);
    },
    onSuccess: () => {
      openNotification('success', 'Success', `Success to add arcnet item.`);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_LIST], { exact: true });
      onClose();
    },
  });

  const onFinish = (values: FormArcnetItemAdd) => {
    const { site_id } = values;

    const foundItem = registerStatus?.unregistered?.find((item) => site_id === item.site_id);

    if (foundItem) {
      mutateAdd(foundItem);
    }
  };

  return {
    form,
    onFinish,
    isFetchingRegisterStatus,
    isLoadingAdd,
    unregisteredList,
  };
}
