import { usePostArcnetItemAnalysis, usePutArcnetItemAnalysis } from '@libs/query/arcnet';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { ArcnetItemAnalysisData } from '@typesdef/arcnet';
import { useForm } from 'antd/es/form/Form';
import { useEffect } from 'react';
import type { ArcnetItemAnalysisAddEditDrawerProps } from '../Drawer/ArcnetItemAnalysisAddEditDrawer';

export default function ArcnetItemAnalysisAddEditDrawer({ state, onClose }: ArcnetItemAnalysisAddEditDrawerProps) {
  const { mode, parentId, open, data } = state;
  const [form] = useForm<ArcnetItemAnalysisData>();
  const queryClient = useQueryClient();

  const mutation = mode === 'edit' ? usePutArcnetItemAnalysis : usePostArcnetItemAnalysis;

  const { mutate: mutateAddEdit, isLoading: isLoadingAddEdit } = mutation({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to ${mode} analysis item.`);
      queryClient.invalidateQueries([QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_ANALYSIS_LIST, parentId]);
      onClose();
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to ${mode} analysis item!`, error);
    },
  });

  const onSave = async () => {
    try {
      const reqData = await form.validateFields();
      mutateAddEdit({
        id: parentId,
        itemId: data?.id ?? 0,
        data: reqData,
      });
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    form.resetFields();
    if (open) {
      if (data) {
        const { id, ...editData } = data;
        form.setFieldsValue(editData);
      } else {
        form.setFieldsValue({
          target: true,
        });
      }
    }
  }, [open, form, data]);

  return {
    form,
    onSave,
    isLoadingAddEdit,
  };
}
