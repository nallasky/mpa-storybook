import { PAGE_URL } from '@constants/constants';
import { useDeleteArcnetItemCalculate, useGetArcnetItemCalculateList } from '@libs/query/arcnet';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { ArcnetItemCalculateData } from '@typesdef/arcnet';
import { AxiosError } from 'axios';
import { useReducer } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';

export interface ArcnetItemCalculateAddEditDrawerState {
  mode: 'add' | 'edit';
  parentId: number;
  open: boolean;
  data?: ArcnetItemCalculateData;
}

const initialDrawerState: ArcnetItemCalculateAddEditDrawerState = {
  mode: 'add',
  parentId: 0,
  open: false,
  data: undefined,
};

export default function useArcnetItemCalculate() {
  const { id } = useParams();
  const parentId = id ? +id : 0;
  const [searchParams] = useSearchParams();
  const name = searchParams.get('name');
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const [drawerState, setDrawerState] = useReducer(
    (state: ArcnetItemCalculateAddEditDrawerState, newState: Partial<ArcnetItemCalculateAddEditDrawerState>) => {
      return { ...state, ...newState };
    },
    initialDrawerState,
  );

  const { data: calculateList, isFetching: isFetchingCalculateList } = useGetArcnetItemCalculateList(parentId, {
    enabled: !!parentId,
    onError: (error) => {
      const newError = error instanceof AxiosError ? error : undefined;
      openNotification('error', 'Error', `Failed to get calculate item list!`, newError);
    },
  });

  const { mutateAsync: mutateDeleteAsync } = useDeleteArcnetItemCalculate({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to delete calculate item.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete calculate item!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_CALCULATE_LIST, parentId]);
    },
  });

  const openAddDrawer = () => {
    setDrawerState({ open: true, mode: 'add', parentId, data: undefined });
  };

  const openEditDrawer = (data: ArcnetItemCalculateData) => {
    setDrawerState({ open: true, mode: 'edit', parentId, data });
  };

  const onCloseEditDrawer = () => {
    setDrawerState(initialDrawerState);
  };

  const onDelete = ({ id }: ArcnetItemCalculateData) => mutateDeleteAsync({ id: parentId, itemId: id });

  const backToParentPage = () => {
    navigate(PAGE_URL.RULES_ANALYSIS_ARCNET_ITEM);
  };

  return {
    name,
    calculateList,
    isFetchingCalculateList,
    drawerState,
    openAddDrawer,
    openEditDrawer,
    onCloseEditDrawer,
    onDelete,
    backToParentPage,
  };
}
