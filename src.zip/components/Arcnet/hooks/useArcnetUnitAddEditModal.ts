import { usePostArcnetUnit, usePutArcnetUnit } from '@libs/query/arcnet';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { MutateArcnetUnitData } from '@typesdef/arcnet';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { useForm } from 'antd/es/form/Form';
import { AxiosError } from 'axios';
import { useEffect } from 'react';
import { ArcnetUnitAddEditModalProps } from '../Modal/ArcnetUnitAddEditModal';

export default function useArcnetUnitAddEditModal({
  mode,
  data,
  onClose,
  visible,
}: GlobalModalDefaultProps<ArcnetUnitAddEditModalProps>) {
  const [form] = useForm<MutateArcnetUnitData>();
  const queryClient = useQueryClient();

  const mutationQuery = mode === 'add' ? usePostArcnetUnit : usePutArcnetUnit;

  const { mutate: mutate, isLoading: isLoading } = mutationQuery({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to ${mode} unit setting!`, error);
    },
    onSuccess: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_ANALYSIS_ARCNET_UNIT_LIST], { exact: true });
      openNotification('success', 'Success', `Success to ${mode} unit setting.`);
      onClose();
    },
  });

  const onFinish = (values: MutateArcnetUnitData) => {
    const { tool_type } = values;

    if (tool_type) {
      mutate({
        id: data?.id ?? 0,
        tool_type,
      });
    }
  };

  useEffect(() => {
    if (mode === 'edit' && data) {
      form.setFieldsValue({
        tool_type: data.tool_type,
      });
    }
  }, [mode, data, form]);

  return {
    form,
    onFinish,
    isLoading,
  };
}
