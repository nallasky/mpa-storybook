import { PAGE_URL } from '@constants/constants';
import { useDeleteArcnetItemAnalysis, useGetArcnetItemAnalysisList } from '@libs/query/arcnet';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { ArcnetItemAnalysisData } from '@typesdef/arcnet';
import { AxiosError } from 'axios';
import { useReducer } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';

export interface ArcnetItemAnalysisAddEditDrawerState {
  mode: 'add' | 'edit';
  parentId: number;
  open: boolean;
  data?: ArcnetItemAnalysisData;
}

const initialDrawerState: ArcnetItemAnalysisAddEditDrawerState = {
  mode: 'add',
  parentId: 0,
  open: false,
  data: undefined,
};

export default function useArcnetItemAnalysis() {
  const { id } = useParams();
  const parentId = id ? +id : 0;
  const [searchParams] = useSearchParams();
  const name = searchParams.get('name');
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const [drawerState, setDrawerState] = useReducer(
    (state: ArcnetItemAnalysisAddEditDrawerState, newState: Partial<ArcnetItemAnalysisAddEditDrawerState>) => {
      return { ...state, ...newState };
    },
    initialDrawerState,
  );

  const { data: analysisList, isFetching: isFetchingAnalysisList } = useGetArcnetItemAnalysisList(parentId, {
    enabled: !!parentId,
    onError: (error) => {
      const newError = error instanceof AxiosError ? error : undefined;
      openNotification('error', 'Error', `Failed to get analysis item list!`, newError);
    },
  });

  const { mutateAsync: mutateDeleteAsync } = useDeleteArcnetItemAnalysis({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to delete analysis item.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete analysis item!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_ANALYSIS_LIST, parentId]);
    },
  });

  const openAddDrawer = () => {
    setDrawerState({ open: true, mode: 'add', parentId, data: undefined });
  };

  const openEditDrawer = (data: ArcnetItemAnalysisData) => {
    setDrawerState({ open: true, mode: 'edit', parentId, data });
  };

  const onCloseEditDrawer = () => {
    setDrawerState(initialDrawerState);
  };

  const onDelete = ({ id }: ArcnetItemAnalysisData) => mutateDeleteAsync({ id: parentId, itemId: id });

  const backToParentPage = () => {
    navigate(PAGE_URL.RULES_ANALYSIS_ARCNET_ITEM);
  };

  return {
    name,
    analysisList,
    isFetchingAnalysisList,
    drawerState,
    openAddDrawer,
    openEditDrawer,
    onCloseEditDrawer,
    onDelete,
    backToParentPage,
  };
}
