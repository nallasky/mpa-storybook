import { useGetArcnetItemRegisterStatus, usePostArcnetItemCopy } from '@libs/query/arcnet';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { useForm } from 'antd/es/form/Form';
import { LabeledValue } from 'antd/es/select';
import type { AxiosError } from 'axios';
import { useMemo } from 'react';

export default function useArcnetItemCopyModal({ visible, onClose }: GlobalModalDefaultProps) {
  const [form] = useForm<{
    source: number;
    target: number;
  }>();
  const queryClient = useQueryClient();

  const { data: registerStatus, isFetching } = useGetArcnetItemRegisterStatus({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to get user-fab name list!`, error);
    },
  });

  const registerList: LabeledValue[] = useMemo(
    () =>
      registerStatus?.registered?.map((item) => ({
        key: item.id.toString(),
        label: item.company_fab_name,
        value: item.id,
      })) ?? [],
    [registerStatus?.registered],
  );

  const { mutate: mutateCopy, isLoading: isMutating } = usePostArcnetItemCopy({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Success to copy item setting.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', 'Failed to copy item setting!', error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_LIST], { exact: true });
      onClose();
    },
  });

  const onOk = async () => {
    try {
      const { source, target } = await form.validateFields();

      const foundSource = registerStatus?.registered?.find((item) => item.id === source);
      const foundTarget = registerStatus?.registered?.find((item) => item.id === target);

      if (foundSource && foundTarget) {
        mutateCopy({
          source: foundSource,
          target: foundTarget,
        });
      } else {
        throw new Error('Invalid source or target');
      }
    } catch (e) {
      console.error(e);
    }
  };

  return { form, onOk, registerList, isFetching, isMutating };
}
