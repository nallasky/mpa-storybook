import FileImportModal, { FileImportModalProps } from '@components/common/atoms/FileImportModal/FileImportModal';
import { API_URL, PAGE_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { useDeleteArcnetItem, useGetArcnetItemExport, useGetArcnetItemList } from '@libs/query/arcnet';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { ArcnetItemData } from '@typesdef/arcnet';
import { AxiosError } from 'axios';
import saveAs from 'file-saver';
import { useNavigate } from 'react-router-dom';
import ArcnetItemAddModal from '../Modal/ArcnetItemAddModal';
import ArcnetItemCopyModal from '../Modal/ArcnetItemCopyModal';

export default function useArcnetItemSetting() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { openModal } = useModals();

  const { data: itemList, isFetching: isFetchingItemList } = useGetArcnetItemList({
    onError: (error) => {
      openNotification('error', 'Error', 'Failed to get item setting list!', error as AxiosError);
    },
  });

  const { mutateAsync: mutateAsyncDelete } = useDeleteArcnetItem({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to delete item setting.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete item setting!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_LIST], { exact: true });
    },
  });

  const { mutateAsync: mutateAsyncExport } = useGetArcnetItemExport({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to export item setting.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to export item setting!`, error);
    },
  });

  const onDelete = async ({ id }: ArcnetItemData) => {
    try {
      await mutateAsyncDelete(id);
    } catch (e) {
      console.error(e);
    }
  };

  const onExport = async ({ id }: ArcnetItemData) => {
    try {
      const { data, fileName } = await mutateAsyncExport(id);
      saveAs(data, fileName);
    } catch (e) {
      console.error(e);
    }
  };

  const openImportModal = ({ id, company_fab_name }: ArcnetItemData) => {
    openModal<FileImportModalProps<{ id: number }>>(MODAL_NAME.ARCNET.ITEM.IMPORT, FileImportModal, {
      title: `[${company_fab_name}] Import Item Setting File`,
      url: API_URL.POST_ARCNET_ITEM_IMPORT(id),
      uploadText: 'Please import the excel file for item setting.',
      afterError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to upload item setting file!`, error);
      },
      afterSuccess: (data) => {
        openNotification('success', 'Success', `Succeed to upload item setting file.`);
      },
      afterSettled: () => {
        queryClient.invalidateQueries([QUERY_KEY.RULES_ANALYSIS_ARCNET_ITEM_LIST], { exact: true });
      },
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_ITEM_IMPORT],
    });
  };

  const openAddModal = () => {
    openModal(MODAL_NAME.ARCNET.ITEM.ADD, ArcnetItemAddModal);
  };

  const openCopyModal = () => {
    openModal(MODAL_NAME.ARCNET.ITEM.COPY, ArcnetItemCopyModal);
  };

  const moveEditPage = (type: 'analysis' | 'calculate', { id, company_fab_name }: ArcnetItemData) => {
    navigate(
      PAGE_URL.RULES_ANALYSIS_ARCNET_ITEM_EDIT({
        type,
        id,
        name: company_fab_name,
      }),
    );
  };

  return {
    itemList,
    isFetchingItemList,
    openAddModal,
    onDelete,
    onExport,
    openImportModal,
    moveEditPage,
    openCopyModal,
  };
}
