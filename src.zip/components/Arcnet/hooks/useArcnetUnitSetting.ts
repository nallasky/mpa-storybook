import FileImportModal, { FileImportModalProps } from '@components/common/atoms/FileImportModal/FileImportModal';
import { API_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { useDeleteArcnetUnit, useGetArcnetUnitExport, useGetArcnetUnitList } from '@libs/query/arcnet';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { ArcnetUnitData } from '@typesdef/arcnet';
import { AxiosError } from 'axios';
import saveAs from 'file-saver';
import ArcnetUnitAddEditModal, { ArcnetUnitAddEditModalProps } from '../Modal/ArcnetUnitAddEditModal';
import ArcnetUnitJsonModal from '../Modal/ArcnetUnitJsonModal';

export default function useArcnetUnitSetting() {
  const queryClient = useQueryClient();
  const { openModal } = useModals();

  const { data: unitList, isFetching: isFetchingUnitList } = useGetArcnetUnitList({
    onError: (error) => {
      openNotification('error', 'Error', 'Failed to get unit setting list!', error as AxiosError);
    },
  });

  const { mutateAsync: mutateAsyncDelete } = useDeleteArcnetUnit({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to delete unit setting.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete unit setting!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_ANALYSIS_ARCNET_UNIT_LIST], { exact: true });
    },
  });

  const { mutateAsync: mutateAsyncExport } = useGetArcnetUnitExport({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to export unit setting.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to export unit setting!`, error);
    },
  });

  const onDelete = async ({ id }: ArcnetUnitData) => {
    try {
      await mutateAsyncDelete(id);
    } catch (e) {
      console.error(e);
    }
  };

  const onExport = async ({ id }: ArcnetUnitData) => {
    try {
      const { data, fileName } = await mutateAsyncExport(id);
      saveAs(data, fileName);
    } catch (e) {
      console.error(e);
    }
  };

  const openImportModal = ({ id, tool_type }: ArcnetUnitData) => {
    openModal<FileImportModalProps<{ id: number }>>(MODAL_NAME.ARCNET.UNIT.IMPORT, FileImportModal, {
      title: `[${tool_type}] Import Unit Json File`,
      url: API_URL.POST_ANALYSIS_ARCNET_UNIT_IMPORT(id),
      uploadText: 'Please import the json file for unit setting.',
      afterError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to upload unit json file!`, error);
      },
      afterSuccess: (data) => {
        openNotification('success', 'Success', `Succeed to upload json file.`);
      },
      afterSettled: () => {
        queryClient.invalidateQueries([QUERY_KEY.RULES_ANALYSIS_ARCNET_UNIT_LIST], { exact: true });
      },
      mutationKey: [MUTATION_KEY.RULES_ANALYSIS_ARCNET_UNIT_IMPORT],
    });
  };

  const openAddModal = () => {
    openModal<ArcnetUnitAddEditModalProps>(MODAL_NAME.ARCNET.UNIT.ADD, ArcnetUnitAddEditModal, {
      mode: 'add',
    });
  };

  const openEditModal = (data: ArcnetUnitData) => {
    openModal<ArcnetUnitAddEditModalProps>(MODAL_NAME.ARCNET.UNIT.ADD, ArcnetUnitAddEditModal, {
      mode: 'edit',
      data,
    });
  };

  const openFileViewModal = (id: number) => {
    openModal(MODAL_NAME.ARCNET.UNIT.FILE_VIEW, ArcnetUnitJsonModal, { id });
  };

  return {
    unitList,
    isFetchingUnitList,
    openAddModal,
    openEditModal,
    onDelete,
    onExport,
    openImportModal,
    openFileViewModal,
  };
}
