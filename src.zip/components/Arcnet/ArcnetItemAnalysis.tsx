import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import TableScrollTitle from '@components/common/atoms/TableScrollTitle';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { hoverActiveStyle } from '@styles/emotion/common';
import { ArcnetItemAnalysisData } from '@typesdef/arcnet';
import { TableColumnPropsType } from '@typesdef/common';
import { PageHeader, Popconfirm, Table } from 'antd';
import { useRef } from 'react';
import ArcnetItemAnalysisAddEditDrawer from './Drawer/ArcnetItemAnalysisAddEditDrawer';
import useArcnetItemAnalysis from './hooks/useArcnetItemAnalysis';

export default function ArcnetItemAnalysis() {
  const tableRef = useRef<HTMLDivElement>(null);
  const {
    name,
    analysisList,
    isFetchingAnalysisList,
    drawerState,
    openAddDrawer,
    openEditDrawer,
    onCloseEditDrawer,
    onDelete,
    backToParentPage,
  } = useArcnetItemAnalysis();

  const renderTitle = () => (
    <TableHeader title={<TableHeaderTitle total={analysisList?.length ?? 0} />}>
      <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddDrawer}>
        Add
      </AntdButton>
    </TableHeader>
  );

  const renderEdit = (value: number, record: ArcnetItemAnalysisData, index: number) => {
    return (
      <Popconfirm title="Are you sure to edit analysis item?" onConfirm={() => openEditDrawer(record)} okText="Edit">
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ArcnetItemAnalysisData, index: number) => {
    return (
      <Popconfirm title="Are you sure to delete analysis item?" onConfirm={() => onDelete(record)} okText="Delete">
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div
      css={css`
        width: 100%;
        display: flex;
        flex-direction: column;
      `}
    >
      <PageHeader
        onBack={backToParentPage}
        title={`Analysis Items (${name})`}
        css={css`
          padding: 0 0 0.5rem 0;
        `}
      />
      <Table<ArcnetItemAnalysisData>
        ref={tableRef}
        rowKey={'id'}
        dataSource={analysisList ?? []}
        bordered
        title={renderTitle}
        size="small"
        pagination={{
          position: ['bottomCenter'],
        }}
        loading={isFetchingAnalysisList}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
        scroll={{ x: 'max-content' }}
      >
        <Table.Column<ArcnetItemAnalysisData>
          {...columnProps.no}
          title={<TableScrollTitle title="No" ref={tableRef} direction="left" />}
        />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.name} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.target} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.unit} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.start_condition_command} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.start_condition_io} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.start_command} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.start_io} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.end_command} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.end_io} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.cancel_command} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.cancel_io} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.description} />
        <Table.Column<ArcnetItemAnalysisData> {...columnProps.edit} render={renderEdit} />
        <Table.Column<ArcnetItemAnalysisData>
          {...columnProps.delete}
          render={renderDelete}
          title={<TableScrollTitle title="Delete" ref={tableRef} direction="right" />}
        />
      </Table>
      <ArcnetItemAnalysisAddEditDrawer state={drawerState} onClose={onCloseEditDrawer} />
    </div>
  );
}

const TdContent = styled.div<{ width: number }>`
  width: ${({ width }) => width}px;
  text-overflow: ellipsis;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
`;

type ColumnName =
  | 'no'
  | 'name'
  | 'unit'
  | 'target'
  | 'start_condition_command'
  | 'start_condition_io'
  | 'start_command'
  | 'start_io'
  | 'end_command'
  | 'end_io'
  | 'cancel_command'
  | 'cancel_io'
  | 'description'
  | 'edit'
  | 'delete';

const columnProps: TableColumnPropsType<ArcnetItemAnalysisData, ColumnName> = {
  no: {
    key: 'no',
    title: <TableColumnTitle>No</TableColumnTitle>,
    dataIndex: 'no',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'no'),
    },
    render: (value, record) => <TdContent width={80}>{record.no}</TdContent>,
    fixed: 'left',
    width: 80,
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'name'),
    },
    render: (value, record) => (
      <TdContent title={`${record.name}`} width={200}>
        {record.name}
      </TdContent>
    ),
    width: 200,
    fixed: 'left',
  },
  target: {
    key: 'target',
    title: <TableColumnTitle>Target</TableColumnTitle>,
    dataIndex: 'unit',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'target'),
    },
    render: (value, record) => <TdContent width={70}>{record.target ? 'True' : 'False'}</TdContent>,
    width: 70,
    fixed: 'left',
  },
  unit: {
    key: 'unit',
    title: <TableColumnTitle>Unit</TableColumnTitle>,
    dataIndex: 'unit',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'unit'),
    },
    render: (value, record) => (
      <TdContent title={`${record.unit}`} width={80}>
        {record.unit}
      </TdContent>
    ),
    width: 80,
  },
  start_condition_command: {
    key: 'start_condition_command',
    title: <TableColumnTitle>Start Condition CMD</TableColumnTitle>,
    dataIndex: 'start_condition_command',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'start_condition_command'),
    },
    render: (value, record) => (
      <TdContent title={`${record.start_condition_command}`} width={150}>
        {record.start_condition_command}
      </TdContent>
    ),
    width: 150,
  },
  start_condition_io: {
    key: 'start_condition_io',
    dataIndex: 'start_condition_io',
    title: <TableColumnTitle>Start Condition IO</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'start_condition_io'),
    },
    render: (value, record) => (
      <TdContent title={`${record.start_condition_io}`} width={150}>
        {record.start_condition_io}
      </TdContent>
    ),
    width: 150,
  },
  start_command: {
    key: 'start_command',
    dataIndex: 'start_command',
    title: <TableColumnTitle>Start CMD</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'start_command'),
    },
    render: (value, record) => (
      <TdContent title={`${record.start_command}`} width={150}>
        {value}
      </TdContent>
    ),
    width: 150,
  },
  start_io: {
    key: 'start_io',
    dataIndex: 'start_io',
    title: <TableColumnTitle>Start IO</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'start_io'),
    },
    render: (value, record) => (
      <TdContent title={`${record.start_io}`} width={150}>
        {value}
      </TdContent>
    ),
    width: 150,
  },
  end_command: {
    key: 'end_command',
    dataIndex: 'end_command',
    title: <TableColumnTitle>End CMD</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'end_command'),
    },
    render: (value, record) => (
      <TdContent title={`${record.end_command}`} width={150}>
        {value}
      </TdContent>
    ),
    width: 150,
  },
  end_io: {
    key: 'end_io',
    dataIndex: 'end_io',
    title: <TableColumnTitle>End IO</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'end_io'),
    },
    render: (value, record) => (
      <TdContent title={`${record.end_io}`} width={150}>
        {value}
      </TdContent>
    ),
    width: 150,
  },
  cancel_command: {
    key: 'cancel_command',
    dataIndex: 'cancel_command',
    title: <TableColumnTitle>Cancel CMD</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'cancel_command'),
    },
    render: (value, record) => (
      <TdContent title={`${record.cancel_command}`} width={150}>
        {value}
      </TdContent>
    ),
    width: 150,
  },
  cancel_io: {
    key: 'cancel_io',
    dataIndex: 'cancel_io',
    title: <TableColumnTitle>Cancel IO</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'cancel_io'),
    },
    render: (value, record) => (
      <TdContent title={`${record.cancel_io}`} width={150}>
        {value}
      </TdContent>
    ),
    width: 150,
  },
  description: {
    key: 'description',
    dataIndex: 'description',
    title: <TableColumnTitle>Description</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'description'),
    },
    render: (value, record) => (
      <TdContent title={`${record.description}`} width={250}>
        {value}
      </TdContent>
    ),
    width: 250,
  },
  edit: {
    key: 'edit',
    dataIndex: 'id',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    fixed: 'right',
    width: 60,
  },

  delete: {
    key: 'delete',
    dataIndex: 'id',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    fixed: 'right',
    width: 100,
  },
};
