import {
  CopyOutlined,
  DeleteOutlined,
  EditOutlined,
  ExportOutlined,
  ImportOutlined,
  PlusOutlined,
} from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { ArcnetItemData } from '@typesdef/arcnet';
import type { TableColumnPropsType } from '@typesdef/common';
import { Popconfirm, Space, Table } from 'antd';
import { Fragment } from 'react';
import useArcnetItemSetting from './hooks/useArcnetItemSetting';

export default function ArcnetItemSetting() {
  const {
    itemList,
    isFetchingItemList,
    openAddModal,
    onDelete,
    onExport,
    openImportModal,
    moveEditPage,
    openCopyModal,
  } = useArcnetItemSetting();

  const renderTitle = () => (
    <TableHeader title={<TableHeaderTitle total={itemList?.length ?? 0} />}>
      <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddModal}>
        Add
      </AntdButton>
      <AntdButton icon={<CopyOutlined />} type="primary" onClick={openCopyModal}>
        Copy
      </AntdButton>
    </TableHeader>
  );

  const renderImport = (value: number, record: ArcnetItemData, index: number) => (
    <ImportOutlined css={hoverActiveStyle} onClick={() => openImportModal(record)} />
  );

  const renderExport = (value: number, record: ArcnetItemData, index: number) => {
    return (
      <Popconfirm
        title={
          <Fragment>
            <div>Are you sure to export item setting for</div>
            <div>{`'${record.company_fab_name}'?`}</div>
          </Fragment>
        }
        onConfirm={() => onExport(record)}
        okText="Export"
      >
        <ExportOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderAnalysisItemEdit = (value: number, record: ArcnetItemData, index: number) => (
    <Space>
      <div>{value} Items</div>
      <EditOutlined css={hoverActiveStyle} onClick={() => moveEditPage('analysis', record)} />
    </Space>
  );

  const renderCalculateItemEdit = (value: number, record: ArcnetItemData, index: number) => (
    <Space>
      <div>{value} Items</div>
      <EditOutlined css={hoverActiveStyle} onClick={() => moveEditPage('calculate', record)} />
    </Space>
  );

  const renderDelete = (value: number, record: ArcnetItemData, index: number) => {
    return (
      <Popconfirm
        title={
          <Fragment>
            <div>Are you sure to delete item setting for</div>
            <div>{`'${record.company_fab_name}'?`}</div>
          </Fragment>
        }
        onConfirm={() => onDelete(record)}
        okText="Delete"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div>
      <Table<ArcnetItemData>
        rowKey={'id'}
        dataSource={itemList ?? []}
        bordered
        title={renderTitle}
        size="middle"
        pagination={{
          position: ['bottomCenter'],
        }}
        loading={isFetchingItemList}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<ArcnetItemData> {...columnProps.company_fab_name} />
        <Table.Column<ArcnetItemData> {...columnProps.analysis_item_count} render={renderAnalysisItemEdit} />
        <Table.Column<ArcnetItemData> {...columnProps.calculate_item_count} render={renderCalculateItemEdit} />
        <Table.Column<ArcnetItemData> {...columnProps.updated} />
        <Table.Column<ArcnetItemData> {...columnProps.import} render={renderImport} />
        <Table.Column<ArcnetItemData> {...columnProps.export} render={renderExport} />
        <Table.Column<ArcnetItemData> {...columnProps.delete} render={renderDelete} />
      </Table>
    </div>
  );
}

type ColumnName =
  | 'company_fab_name'
  | 'analysis_item_count'
  | 'calculate_item_count'
  | 'updated'
  | 'import'
  | 'export'
  | 'delete';

const columnProps: TableColumnPropsType<ArcnetItemData, ColumnName> = {
  company_fab_name: {
    key: 'company_fab_name',
    title: <TableColumnTitle>User-Fab Name</TableColumnTitle>,
    dataIndex: 'company_fab_name',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'company_fab_name'),
    },
    width: getPixelPercent(1360, 310),
  },
  analysis_item_count: {
    key: 'analysis_item_count',
    title: <TableColumnTitle>Analysis Item</TableColumnTitle>,
    dataIndex: 'analysis_item_count',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'analysis_item_count'),
    },

    width: getPixelPercent(1360, 250),
  },
  calculate_item_count: {
    key: 'calculate_item_count',
    title: <TableColumnTitle>Calculate Item</TableColumnTitle>,
    dataIndex: 'calculate_item_count',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'calculate_item_count'),
    },

    width: getPixelPercent(1360, 250),
  },
  updated: {
    key: 'updated',
    title: <TableColumnTitle>Last Updated</TableColumnTitle>,
    dataIndex: 'updated',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'updated'),
    },

    width: getPixelPercent(1360, 250),
  },
  import: {
    key: 'id',
    dataIndex: 'id',
    title: <TableColumnTitle>Import</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 100),
  },
  export: {
    key: 'export',
    dataIndex: 'id',
    title: <TableColumnTitle>Export</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 100),
  },
  delete: {
    key: 'delete',
    dataIndex: 'id',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 100),
  },
};
