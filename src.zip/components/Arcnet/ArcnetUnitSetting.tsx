import { DeleteOutlined, EditOutlined, ExportOutlined, ImportOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { ArcnetUnitData } from '@typesdef/arcnet';
import type { TableColumnPropsType } from '@typesdef/common';
import { Popconfirm, Table } from 'antd';
import { Fragment } from 'react';
import useArcnetUnitSetting from './hooks/useArcnetUnitSetting';

export default function ArcnetUnitSetting() {
  const {
    unitList,
    isFetchingUnitList,
    openAddModal,
    openEditModal,
    onDelete,
    onExport,
    openImportModal,
    openFileViewModal,
  } = useArcnetUnitSetting();

  const renderTitle = () => (
    <TableHeader title={<TableHeaderTitle total={unitList?.length ?? 0} />}>
      <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddModal}>
        Add
      </AntdButton>
    </TableHeader>
  );

  const renderFileName = (value: string, record: ArcnetUnitData, index: number) => {
    const isFile = record?.filename ? true : false;

    if (!isFile) return <div>-</div>;

    return (
      <div css={hoverActiveStyle} onClick={() => openFileViewModal(record.id)}>
        {record.filename}
      </div>
    );
  };

  const renderEdit = (value: number, record: ArcnetUnitData, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to edit MPA Tool Type?"
        onConfirm={() => {
          return openEditModal(record);
        }}
        okText="Edit"
      >
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderImport = (value: number, record: ArcnetUnitData, index: number) => (
    <ImportOutlined css={hoverActiveStyle} onClick={() => openImportModal(record)} />
  );

  const renderExport = (value: number, record: ArcnetUnitData, index: number) => {
    const isFile = record?.filename ? true : false;
    if (!isFile) return <div>-</div>;

    return (
      <Popconfirm
        title={
          <Fragment>
            <div>Are you sure to export unit setting for</div>
            <div>{`'${record.tool_type}'?`}</div>
          </Fragment>
        }
        onConfirm={() => onExport(record)}
        okText="Export"
      >
        <ExportOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ArcnetUnitData, index: number) => {
    return (
      <Popconfirm
        title={
          <Fragment>
            <div>Are you sure to delete unit setting for</div>
            <div>{`'${record.tool_type}'?`}</div>
          </Fragment>
        }
        onConfirm={() => onDelete(record)}
        okText="Delete"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div>
      <Table<ArcnetUnitData>
        rowKey={'id'}
        dataSource={unitList ?? []}
        bordered
        title={renderTitle}
        size="middle"
        pagination={{
          position: ['bottomCenter'],
        }}
        loading={isFetchingUnitList}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<ArcnetUnitData> {...columnProps.tool_type} />
        <Table.Column<ArcnetUnitData> {...columnProps.filename} render={renderFileName} />
        <Table.Column<ArcnetUnitData> {...columnProps.import} render={renderImport} />
        <Table.Column<ArcnetUnitData> {...columnProps.export} render={renderExport} />
        <Table.Column<ArcnetUnitData> {...columnProps.edit} render={renderEdit} />
        <Table.Column<ArcnetUnitData> {...columnProps.delete} render={renderDelete} />
      </Table>
    </div>
  );
}

type ColumnName = 'tool_type' | 'filename' | 'import' | 'export' | 'edit' | 'delete';

const columnProps: TableColumnPropsType<ArcnetUnitData, ColumnName> = {
  tool_type: {
    key: 'tool_type',
    title: <TableColumnTitle>MPA Tool Type</TableColumnTitle>,
    dataIndex: 'tool_type',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'tool_type'),
    },
    width: getPixelPercent(1360, 500),
  },
  filename: {
    key: 'filename',
    title: <TableColumnTitle>Filename</TableColumnTitle>,
    dataIndex: 'filename',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'filename'),
    },

    width: getPixelPercent(1360, 470),
  },
  import: {
    key: 'id',
    dataIndex: 'id',
    title: <TableColumnTitle>Import</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 470),
  },
  export: {
    key: 'export',
    dataIndex: 'id',
    title: <TableColumnTitle>Export</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 100),
  },
  edit: {
    key: 'edit',
    dataIndex: 'id',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 100),
  },
  delete: {
    key: 'delete',
    dataIndex: 'id',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 100),
  },
};
