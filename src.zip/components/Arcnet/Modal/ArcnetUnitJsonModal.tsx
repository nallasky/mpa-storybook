import { css } from '@emotion/react';
import { useGetArcnetUnit } from '@libs/query/arcnet';
import { openNotification } from '@libs/util/notification';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Badge, Modal, Skeleton, Space } from 'antd';
import { AxiosError } from 'axios';
import AceEditor from 'react-ace';

import 'ace-builds/src-noconflict/ext-language_tools';
import 'ace-builds/src-noconflict/mode-json';
import 'ace-builds/src-noconflict/theme-github';

interface ArcnetUnitJsonModalProps {
  id: number;
}

export default function ArcnetUnitJsonModal({
  onClose,
  visible,
  id,
}: GlobalModalDefaultProps<ArcnetUnitJsonModalProps>): JSX.Element {
  const { data, isFetching } = useGetArcnetUnit(id, {
    enabled: Boolean(visible && id),
    onError(error: AxiosError) {
      openNotification('error', 'Error', `Failed to get json view!`, error);
    },
  });

  return (
    <Modal
      title="JSON File View"
      open={visible}
      okText="Close"
      onOk={onClose}
      okButtonProps={{ loading: false }}
      onCancel={onClose}
      cancelButtonProps={{
        hidden: true,
      }}
      closable={!false}
      maskClosable={!false}
      width={800}
    >
      {isFetching ? (
        <div css={style}>
          <Skeleton active paragraph={{ rows: 17 }} />
        </div>
      ) : (
        <div css={style}>
          <Space>
            <Badge text="MPA Tool Type:" color="blue" />
            <span>{data?.tool_type}</span>
          </Space>
          <Space>
            <Badge text="Filename:" color="blue" />
            <span>{data?.filename}</span>
          </Space>

          <AceEditor
            mode="json"
            theme="github"
            name="json-view"
            editorProps={{ $blockScrolling: true }}
            fontSize={14}
            showPrintMargin={true}
            showGutter={true}
            highlightActiveLine={true}
            value={data?.json}
            width={'100%'}
            readOnly
          />
        </div>
      )}
    </Modal>
  );
}

const style = css`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  height: 36rem;
`;
