import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Modal, Select } from 'antd';
import useArcnetItemAddModal, { FormArcnetItemAdd } from '../hooks/useArcnetItemAddModal';

export default function ArcnetItemAddModal({ onClose, visible }: GlobalModalDefaultProps): JSX.Element {
  const { form, onFinish, isFetchingRegisterStatus, isLoadingAdd, unregisteredList } = useArcnetItemAddModal({
    onClose,
    visible,
  });

  return (
    <Modal
      title="Add Item Setting"
      open={visible}
      okText="Add"
      onOk={form.submit}
      okButtonProps={{ loading: isLoadingAdd, disabled: isFetchingRegisterStatus }}
      onCancel={onClose}
      cancelButtonProps={{
        disabled: isLoadingAdd,
      }}
      closable={!isLoadingAdd}
      maskClosable={!isLoadingAdd}
    >
      <Form<FormArcnetItemAdd>
        form={form}
        onFinish={onFinish}
        layout="vertical"
        disabled={isFetchingRegisterStatus || isLoadingAdd}
      >
        <Form.Item
          label="User-Fab Name"
          name="site_id"
          required
          rules={[
            {
              required: true,
              type: 'integer',
              message: 'Please select a User-Fab Name!',
            },
          ]}
        >
          <Select
            options={unregisteredList}
            showSearch
            filterOption={(input, option) =>
              option ? (option.label as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
            }
            placeholder="Select a User-Fab Name."
          />
        </Form.Item>
      </Form>
    </Modal>
  );
}
