import { ArcnetUnitData, MutateArcnetUnitData } from '@typesdef/arcnet';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Input, Modal } from 'antd';
import useArcnetUnitAddEditModal from '../hooks/useArcnetUnitAddEditModal';

export interface ArcnetUnitAddEditModalProps {
  mode: 'add' | 'edit';
  data?: ArcnetUnitData;
}

export default function ArcnetUnitAddEditModal({
  onClose,
  visible,
  mode,
  data,
}: GlobalModalDefaultProps<ArcnetUnitAddEditModalProps>): JSX.Element {
  const { form, onFinish, isLoading } = useArcnetUnitAddEditModal({
    onClose,
    visible,
    mode,
    data,
  });
  const modeText = mode === 'add' ? 'Add' : 'Edit';

  return (
    <Modal
      title={`${modeText} Unit Setting`}
      open={visible}
      okText={modeText}
      onOk={form.submit}
      okButtonProps={{ loading: isLoading, disabled: isLoading }}
      onCancel={onClose}
      cancelButtonProps={{
        disabled: isLoading,
      }}
      closable={!isLoading}
      maskClosable={!isLoading}
    >
      <Form<MutateArcnetUnitData> form={form} onFinish={onFinish} layout="vertical" disabled={isLoading}>
        <FormInput<MutateArcnetUnitData> label="MPA Tool Type" name="tool_type" required />
      </Form>
    </Modal>
  );
}

interface FormInputProps<T> {
  label: string;
  name: Extract<keyof T, string>;
  required?: boolean;
  maxLength?: number;
}

function FormInput<T>({ label, name, maxLength, required = false }: FormInputProps<T>) {
  return (
    <Form.Item
      label={label}
      name={name}
      required={required}
      rules={
        required
          ? [
              {
                type: 'string',
                required: true,
                message: `Please input a ${label}!`,
              },
            ]
          : undefined
      }
    >
      <Input maxLength={maxLength} placeholder={`Input a ${label}.`} />
    </Form.Item>
  );
}
