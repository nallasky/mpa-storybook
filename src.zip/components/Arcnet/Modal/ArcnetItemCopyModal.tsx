import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Modal, Select, Space, Spin } from 'antd';
import React from 'react';
import useArcnetItemCopyModal from '../hooks/useArcnetItemCopyModal';

export default React.memo(function ArcnetItemCopyModal({ visible, onClose }: GlobalModalDefaultProps): JSX.Element {
  const { form, onOk, registerList, isFetching, isMutating } = useArcnetItemCopyModal({
    visible,
    onClose,
  });
  return (
    <Modal
      title={
        <Space>
          <div>Copy Item Setting</div> {isFetching && <Spin size="small" />}
        </Space>
      }
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width="550px"
      destroyOnClose
      cancelButtonProps={{
        disabled: isMutating,
      }}
      okText="Copy"
      okButtonProps={{
        loading: isMutating,
        disabled: isFetching,
      }}
      maskClosable={!isMutating}
    >
      <Form form={form} labelCol={{ span: 8 }} wrapperCol={{ span: 16 }} disabled={isFetching || isMutating}>
        <Form.Item
          label="Select Source"
          name="source"
          required
          rules={[{ required: true, message: 'Please select a source!' }]}
        >
          <Select
            placeholder="Select a Source"
            showSearch
            filterOption={(input, option) =>
              option ? (option.label as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
            }
            options={registerList}
            loading={isFetching}
          />
        </Form.Item>
        <Form.Item
          label="Select Target"
          name="target"
          required
          rules={[{ required: true, message: 'Please select a target!' }]}
        >
          <Select
            placeholder="Select a Target"
            showSearch
            filterOption={(input, option) =>
              option ? (option.label as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
            }
            options={registerList}
            loading={isFetching}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
});
