import {
  AlertOutlined,
  ApartmentOutlined,
  BookOutlined,
  FileProtectOutlined,
  FileZipOutlined,
  HomeOutlined,
  LaptopOutlined,
  PartitionOutlined,
} from '@ant-design/icons';
import CustomIcon from '@components/common/atoms/CustomIcon';
import { DEFAULT_URL } from '@constants/constants';
import { css } from '@emotion/react';
import { Breadcrumb } from 'antd';
import { useLocation } from 'react-router-dom';

export type DashBoardBreadcrumbProps = {};

export default function DashBoardBreadcrumb({}: DashBoardBreadcrumbProps): JSX.Element {
  const location = useLocation();
  const { icon, locations } = getBreadcrumb(location);

  return (
    <Breadcrumb css={breadcrumbStyle} separator=">">
      <Breadcrumb.Item>
        <HomeOutlined />
      </Breadcrumb.Item>
      {locations.map(
        (item: string, idx: number) =>
          item && (
            <Breadcrumb.Item key={item}>
              {idx === 0 && icon}
              <span>{item}</span>
            </Breadcrumb.Item>
          ),
      )}
    </Breadcrumb>
  );
}

const breadcrumbStyle = css`
  padding-top: 1rem;
  padding-bottom: 1rem;
  /* width: 84rem;  */
  /* background-color: #eff2f5; */
`;

const getHomeName = (value: string) =>
  ({
    home: 'Home',
  }[value] ?? null);

const statusPathNameMap: Record<string, string> = {
  remote: 'Job',
  local: 'Local Import',
  add: 'Add',
  edit: 'Edit',
  collect: 'Collect',
  convert: 'Convert/Insert',
  summary: 'Send Error Summary',
  cras: 'Cras Data',
  version: 'MPA Version Check',
  purge: 'Database Purge',
  custom: 'Custom',
  notice: 'Error Notice',
  mahalanobis: 'Mahalanobis',
};

const getStatusName = (pathname: string) => {
  // job, local import
  const jobPath = /^status\/(remote|local)$/g.exec(pathname);
  if (jobPath && jobPath[1]) {
    const jobType = statusPathNameMap[jobPath[1]] ?? '';

    return [jobType];
  }

  // job step
  const stepPath = /^status\/(remote)\/step\/\d+/g.exec(pathname);
  if (stepPath && stepPath[1]) {
    const jobType = statusPathNameMap[stepPath[1] ?? ''];
    return [jobType, 'Step'];
  }

  // job, local import add/edit
  const addEditPath = /^status\/(remote|local)\/(add|edit)$/g.exec(pathname);
  if (addEditPath && addEditPath[1] && addEditPath[2]) {
    const jobType = statusPathNameMap[addEditPath[1] ?? ''];
    const jobAction = statusPathNameMap[addEditPath[2] ?? ''];
    return [jobType, jobAction];
  }

  // job, local build history
  const historyPath = /^status\/(remote|local)\/history\/(\S+)\/\d+/g.exec(pathname);
  if (historyPath && historyPath[1] && historyPath[2]) {
    const jobType = statusPathNameMap[historyPath[1] ?? ''];
    const StepType = statusPathNameMap[historyPath[2] ?? ''];

    return [jobType, 'Build History', StepType];
  }

  return [];
};

const getErrorLog = (value: string) =>
  ({
    errorlog: 'Error Log',
    download: 'Download',
    status: 'Status',
    setting: 'Setting',
  }[value] ?? null);

const getConfigureName = (value: string) =>
  ({
    configure: 'Server Config',
  }[value] ?? null);

const getAddressName = (value: string) =>
  ({
    address: 'Address',
  }[value] ?? null);

const getAccountName = (value: string) =>
  ({
    account: 'Account',
  }[value] ?? null);

const getSystemConfigName = (value: string) =>
  ({
    system: 'System Config',
  }[value] ?? null);

const getBreadCrumbLocation = (pathname: string, getName: (value: string) => string | null) => {
  const pathArr = pathname.split('/');
  const convPathArr: string[] = [];

  pathArr.forEach((item) => {
    const name = getName(item);
    if (name) {
      convPathArr.push(name);
    }
  });

  return convPathArr;
};

const getBreadcrumb = (location: any) => {
  const { pathname } = location;
  const newPathname = pathname.replace(`${DEFAULT_URL}/dashboard/`, '');

  if (newPathname === 'home') {
    return {
      locations: getBreadCrumbLocation(newPathname, getHomeName),
    };
  } else if (newPathname.startsWith('status/remote')) {
    return {
      icon: <PartitionOutlined />,
      locations: getStatusName(newPathname),
    };
  } else if (newPathname.startsWith('status/local')) {
    return {
      icon: <FileZipOutlined />,
      locations: getStatusName(newPathname),
    };
  } else if (newPathname.startsWith('errorlog')) {
    return {
      icon: <AlertOutlined />,
      locations: getBreadCrumbLocation(newPathname, getErrorLog),
    };
  } else if (newPathname.startsWith('configure')) {
    return {
      icon: <ApartmentOutlined />,
      locations: getBreadCrumbLocation(newPathname, getConfigureName),
    };
  } else if (newPathname.startsWith('rules')) {
    return {
      icon: <FileProtectOutlined />,
      locations: getBreadCrumbLocationRules(newPathname),
    };
  } else if (newPathname.startsWith('address')) {
    return {
      icon: <BookOutlined />,
      locations: getBreadCrumbLocation(newPathname, getAddressName),
    };
  } else if (newPathname.startsWith('account')) {
    return {
      icon: <CustomIcon name="idcard" />,
      locations: getBreadCrumbLocation(newPathname, getAccountName),
    };
  } else if (newPathname.startsWith('system')) {
    return {
      icon: <LaptopOutlined />,
      locations: getBreadCrumbLocation(newPathname, getSystemConfigName),
    };
  }

  return {
    icon: null,
    locations: [],
  };
};

function getBreadCrumbLocationRules(pathname: string) {
  if (/^rules\/convert$/g.test(pathname)) {
    return ['Rules', 'Convert Rules'];
  } else if (/^rules\/convert\/\d+\/edit$/g.test(pathname)) {
    return ['Rules', 'Convert Rules', 'Edit'];
  } else if (/^rules\/cras-data$/g.test(pathname)) {
    return ['Rules', 'Analysis', 'Cras Data'];
  } else if (/^rules\/cras-data\/create\/\d+$/g.test(pathname)) {
    return ['Rules', 'Analysis', 'Cras Data', 'Create Cras Data'];
  } else if (/^rules\/cras-data\/judge\/\d+$/g.test(pathname)) {
    return ['Rules', 'Analysis', 'Cras Data', 'Judge Rules'];
  } else if (/^rules\/define\/column$/g.test(pathname)) {
    return ['Rules', 'Define', 'Column Define'];
  } else if (/^rules\/define\/cylinder$/g.test(pathname)) {
    return ['Rules', 'Define', 'Cylinder Param Define'];
  } else if (/^rules\/define\/machine$/g.test(pathname)) {
    return ['Rules', 'Define', 'Machine Param Define'];
  } else if (/^rules\/analysis\/mahalanobis$/g.test(pathname)) {
    return ['Rules', 'Analysis', 'Mahalanobis'];
  } else if (/^rules\/analysis\/mahalanobis\/\d+$/g.test(pathname)) {
    return ['Rules', 'Analysis', 'Mahalanobis', 'Items'];
  } else if (/^rules\/analysis\/arcnet\/item$/g.test(pathname)) {
    return ['Rules', 'Analysis', 'Arcnet', 'Item Setting'];
  } else if (/^rules\/analysis\/arcnet\/item\/\d+\/analysis$/g.test(pathname)) {
    return ['Rules', 'Analysis', 'Arcnet', 'Item Setting', 'Analysis Item'];
  } else if (/^rules\/analysis\/arcnet\/item\/\d+\/calculate$/g.test(pathname)) {
    return ['Rules', 'Analysis', 'Arcnet', 'Item Setting', 'Calculate Item'];
  } else if (/^rules\/analysis\/arcnet\/unit$/g.test(pathname)) {
    return ['Rules', 'Analysis', 'Arcnet', 'Unit Setting'];
  }

  return [];
}
