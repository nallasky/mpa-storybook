import { LoadingOutlined } from '@ant-design/icons';
import { undraw_selection } from '@assets/images';
import AntdButton from '@components/common/atoms/AntdButton';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { JobStatusType } from '@typesdef/Job';
import { Radio, Space, Spin } from 'antd';
import { LazyLog, ScrollFollow } from 'react-lazylog';
import useBuildHistoryViewLog from './hooks/useBuildHistoryViewLog';

export type BuildHistoryViewLogProps = {};

export default function BuildHistoryViewLog({}: BuildHistoryViewLogProps): JSX.Element {
  const {
    requestUrl,
    status,
    name,
    serverType,
    onChangeServerType,
    logData,
    openDownloadModal,
    isDone,
    openDeleteModal,
  } = useBuildHistoryViewLog();

  if (!requestUrl) {
    return (
      <InitialScreen>
        <img alt="select a log history" src={undraw_selection} />
        <div className="text">Please select a log history.</div>
      </InitialScreen>
    );
  }

  return (
    <div
      css={[
        logViewStyle(status),
        css`
          .ReactVirtualized__Grid {
            /* !important is needed here to override react-virtualized inline style attribute */
            overflow-x: scroll !important;
          }
        `,
      ]}
    >
      <div className="title-section">
        <Space>
          <div>{status && <span className="status">●</span>}</div>
          <div>{name && <span className="name">{name}</span>}</div>
          <div
            css={css`
              width: 20px;
            `}
          >
            {!isDone && <Spin size="small" indicator={<LoadingOutlined spin />} />}
          </div>
          <Radio.Group value={serverType} onChange={onChangeServerType}>
            <Radio value={'logmonitor'}>Log Monitor Server</Radio>
            <Radio value={'cras'}>Cras Server</Radio>
          </Radio.Group>
        </Space>
        <Space>
          <AntdButton type="primary" onClick={openDeleteModal} disabled={!isDone || status === 'processing'}>
            Delete
          </AntdButton>
          <AntdButton type="primary" onClick={openDownloadModal} disabled={!isDone || status === 'processing'}>
            Download
          </AntdButton>
        </Space>
      </div>
      <ScrollFollow
        startFollowing
        render={({ onScroll, follow, startFollowing, stopFollowing }) => (
          <LazyLog extraLines={1} enableSearch caseInsensitive follow={follow} text={logData} />
        )}
      />
    </div>
  );
}

const InitialScreen = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-top: 0.25rem;
  margin-left: 1rem;
  width: 71.4375rem;
  height: 47.34375rem;
  .img {
    width: 25rem;
    height: auto;
  }
  .text {
    padding-top: 1rem;
    font-size: 2rem;
  }
`;

const logViewStyle = (status: JobStatusType | null) => css`
  margin-top: 0.25rem;
  margin-left: 1rem;
  width: 71.4375rem;
  height: 47.34375rem;
  .title-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 2.3rem;
    .status {
      color: ${status && getColor(status)};
    }
  }
`;

function getColor(status: JobStatusType) {
  switch (status) {
    case 'success':
    case 'nodata':
      return '#52c41a';
    case 'failure':
      return '#ff4d4f';
    case 'notbuild':
      return '#d9d9d9';
    case 'processing':
      return '#1890ff';
    case 'canceled':
      return '#faad14';
    default:
      return undefined;
  }
}
