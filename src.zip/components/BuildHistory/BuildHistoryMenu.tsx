import { blue } from '@ant-design/colors';
import StatusBadge from '@components/common/atoms/StatusBadge';
import { LOG_HISTORY_MAX_LIST_COUNT } from '@constants/constants';
import { css } from '@emotion/react';
import { BuildHistorySelectedLogState } from '@reducers/slices/buildHistory';
import { CustomItemType } from '@typesdef/antdExtends';
import { Empty, Menu, Pagination, Spin } from 'antd';
import { ItemType } from 'antd/es/menu/hooks/useItems';
import { Fragment, useCallback, useLayoutEffect, useMemo } from 'react';
import useBuildHistoryMenu from './hooks/useBuildHistoryMenu';

export type BuildHistoryMenuProps = {};

export default function BuildHistoryMenu({}: BuildHistoryMenuProps): JSX.Element {
  const {
    isFetching,
    selectedLog,
    setSelectedLog,
    currentPage,
    onChangeCurrentPage,
    menuRef,
    doneToSelect,
    setDoneToSelect,
    data,
  } = useBuildHistoryMenu();

  const onSelectHistory = useCallback(
    ({ id, status, name }: BuildHistorySelectedLogState) =>
      () => {
        setSelectedLog({ id, status, name });
      },
    [setSelectedLog],
  );

  const renderHistory = useMemo(() => {
    const items: CustomItemType[] =
      data?.content.map(({ id, status, name }) => ({
        key: id,
        onClick: onSelectHistory({ id, status, name }),
        label:
          id === selectedLog?.id ? (
            <div ref={menuRef}>
              <StatusBadge value={status} />
              <div className="name">{name}</div>
            </div>
          ) : (
            <div>
              <StatusBadge value={status} />
              <div className="name">{name}</div>
            </div>
          ),
      })) ?? [];
    return items;
  }, [data, onSelectHistory, menuRef, selectedLog]);

  useLayoutEffect(() => {
    if (!doneToSelect && renderHistory.length > 0) {
      if (menuRef.current) {
        menuRef.current.scrollIntoView({ block: 'center' });
        window.window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
      }
      setDoneToSelect(true);
    }
  }, [renderHistory, doneToSelect, menuRef, setDoneToSelect]);

  return (
    <div>
      <div css={siderStyle}>
        {isFetching && (
          <div css={spinStyle}>
            <div className="section">
              <Spin />
            </div>
          </div>
        )}
        <Fragment>
          {renderHistory.length > 0 ? (
            <Menu
              mode="inline"
              className="Sider-Menu"
              selectedKeys={[`${selectedLog?.id}`]}
              items={renderHistory as ItemType[]}
              css={newMenuItemStyle}
            />
          ) : (
            <div css={emptyDataStyle}>
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            </div>
          )}

          <div css={pageNationStyle}>
            <Pagination
              defaultCurrent={1}
              total={data?.totalElements ?? 0}
              current={currentPage}
              pageSize={LOG_HISTORY_MAX_LIST_COUNT}
              simple
              hideOnSinglePage
              size={'small'}
              onChange={onChangeCurrentPage}
            />
          </div>
        </Fragment>
      </div>
    </div>
  );
}

const spinStyle = css`
  position: absolute;
  background: rgba(255, 255, 255, 0.5);
  height: 52.28125rem;
  width: 12.5rem;
  z-index: 400;
  .section {
    display: flex;
    justify-content: center;
    align-items: center;

    border-right: 1px solid #f0f0f0;
    width: 100%;
    height: 100%;
  }
`;

const siderStyle = css`
  width: 12.5rem;
  height: 100%;
  .Sider-Menu {
    height: 49.78125rem;
    overflow: auto;
    border-right: 1px solid #f0f0f0;
  }
`;

const menuItemStyle = css`
  line-height: 30px !important;
  height: 60px !important;
  width: 100% !important;

  .name {
    font-size: 0.8rem;
  }

  &:hover {
    .ant-badge-status-text,
    .name {
      color: ${blue[4]};
    }
  }
  &:active {
    .ant-badge-status-text,
    .name {
      color: ${blue[6]};
    }
  }
`;

const newMenuItemStyle = css`
  .ant-menu-item {
    ${menuItemStyle}
  }
`;

const emptyDataStyle = css`
  display: flex;
  align-items: center;
  justify-content: center;
  border-right: 1px solid #f0f0f0;
  height: 49.78125rem;
`;

const pageNationStyle = css`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 0.5rem;
  margin-bottom: 0.5rem;
`;
