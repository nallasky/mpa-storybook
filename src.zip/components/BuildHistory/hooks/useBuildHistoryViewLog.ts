import { openAntdModal } from '@components/common/atoms/AntdModal';
import { API_URL } from '@constants/constants';
import { useDeleteHistoryLog, useGetHistoryLogData, useGetHistoryLogStatus } from '@libs/query/buildHistory';
import { QUERY_KEY } from '@libs/query/queryKey';
import { downloadFileUrl } from '@libs/util/download';
import { openNotification } from '@libs/util/notification';
import {
  historySelectLogReducer,
  selectHistorySelectLog,
  selectHistorySelectStep,
} from '@reducers/slices/buildHistory';
import useTypedSelector from '@reducers/useTypedSelector';
import { useQueryClient } from '@tanstack/react-query';
import { RadioChangeEvent } from 'antd';
import { AxiosError } from 'axios';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';

export default function useBuildHistoryViewLog() {
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const selectedStep = useTypedSelector(selectHistorySelectStep);
  const selectedLog = useTypedSelector(selectHistorySelectLog);
  const [serverType, setServerType] = useState<'logmonitor' | 'cras'>('logmonitor');
  const status = useMemo(() => selectedLog?.status, [selectedLog?.status]);
  const name = useMemo(() => selectedLog?.name, [selectedLog?.name]);
  const [logData, setLogData] = useState('\n');
  const [logStartIdx, setLogStartIdx] = useState(0);
  const [isDone, setDone] = useState(false);
  const { pathname, search } = useLocation();
  const navigate = useNavigate();

  const { mutateAsync: mutateAsyncDelete } = useDeleteHistoryLog({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to delete build history log!`);
      const newSearch = search.split('&historyId')[0];
      navigate(pathname + newSearch, { replace: true });
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete build history log!`, error as AxiosError);
    },
  });

  const requestUrl = useMemo(() => {
    const { type, jobId, stepId, stepType } = selectedStep;
    const { id } = selectedLog;

    if (type && jobId && stepId && stepType && id && serverType) {
      return API_URL.GET_STATUS_BUILD_HISTORY_LOG({
        type,
        jobId,
        stepId,
        historyId: id,
        serverType,
      });
    } else {
      return null;
    }
  }, [selectedStep, selectedLog, serverType]);

  useGetHistoryLogStatus(selectedLog.id as string, {
    enabled: Boolean(
      selectedLog.id && (selectedLog.status == null || ['processing', 'notbuild'].includes(selectedLog.status)),
    ),
    refetchInterval: 1000,
    onSuccess: (data) => {
      dispatch(
        historySelectLogReducer({
          name: data.name,
          status: data.status,
        }),
      );
    },
  });

  useGetHistoryLogData(requestUrl as string, logStartIdx, {
    enabled: Boolean(requestUrl) && !isDone,
    refetchInterval: 300,
    onSuccess: (data) => {
      const { line, log, isLast } = data;

      if (line !== undefined && line !== 0) {
        setLogData((prev) => prev + log);
        setLogStartIdx(line);
      }

      if (isLast) {
        setDone(true);
      }
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to get build history log data!`, error as AxiosError);
      setDone(true);
    },
  });

  const onChangeServerType = useCallback(
    (e: RadioChangeEvent) => {
      queryClient.cancelQueries([QUERY_KEY.HISTORY_DATA]);
      setServerType(e.target.value);
      setDone(true);
    },
    [queryClient],
  );

  const openDownloadModal = useCallback(() => {
    const serverText = serverType === 'cras' ? 'Cras' : 'Log Monitor';

    openAntdModal('confirm', {
      className: 'download-history-log',
      title: `Download History ${serverText} Log`,
      content: `Are you sure to download ${serverText.toLocaleLowerCase()} log?`,
      okText: 'Download',
      onOk: async () => {
        downloadFileUrl(
          API_URL.GET_STATUS_BUILD_HISTORY_LOG_DOWNLOAD({
            historyId: selectedLog.id as string,
            serverType,
          }),
        );
      },
    });
  }, [selectedLog.id, serverType]);

  const openDeleteModal = useCallback(() => {
    openAntdModal('confirm', {
      className: 'delete-history-log',
      title: `Delete History Log`,
      content: `Are you sure to delete history log?`,
      okText: 'Delete',
      onOk: async () => {
        try {
          if (selectedLog.id) {
            await mutateAsyncDelete(selectedLog.id);
          }
        } catch (error) {
          console.error(error);
        }
      },
    });
  }, [selectedLog.id, mutateAsyncDelete]);

  useEffect(() => {
    setDone(false);
    setLogData('\n');
    setLogStartIdx(0);
  }, [requestUrl]);

  return {
    requestUrl,
    status,
    name,
    serverType,
    onChangeServerType,
    logData,
    openDownloadModal,
    isDone,
    openDeleteModal,
  };
}
