import { PAGE_URL } from '@constants/constants';
import { useGetHistoryLogList } from '@libs/query/buildHistory';
import { openNotification } from '@libs/util/notification';
import {
  BuildHistorySelectedLogState,
  BuildHistorySelectedStepState,
  historyCurPageReducer,
  historyInitReducer,
  historySelectLogReducer,
  historySelectStepReudcer,
  selectHistoryCurPage,
  selectHistorySelectLog,
  selectHistorySelectStep,
} from '@reducers/slices/buildHistory';
import useTypedSelector from '@reducers/useTypedSelector';
import { JobStepType, JobType } from '@typesdef/Job';
import queryString from 'query-string';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useLocation, useParams } from 'react-router-dom';

export default function useBuildHistoryMenu() {
  const dispatch = useDispatch();
  const { pathname, search } = useLocation();
  const { stepId, jobName, stepName, historyId } = queryString.parse(search);
  const { stepType, jobId } = useParams();
  const isViewFetching = useRef(false);

  const paramInfo = useMemo<BuildHistorySelectedStepState>(
    () => ({
      stepId: stepId as string,
      jobName: jobName as string,
      stepName: stepName as string,
      stepType: stepType as JobStepType,
      jobId: jobId as string,
      type: getHistoryType(pathname),
      historyId: (historyId as string) ?? null,
    }),
    [stepId, jobName, stepName, stepType, jobId, pathname, historyId],
  );

  const selectedStep = useTypedSelector(selectHistorySelectStep);
  const selectedLog = useTypedSelector(selectHistorySelectLog);
  const currentPage = useTypedSelector(selectHistoryCurPage);

  const menuRef = useRef<HTMLDivElement>(null);
  const [doneToSelect, setDoneToSelect] = useState(false);
  const [isError, setError] = useState(false);

  const { data, isFetching, refetch } = useGetHistoryLogList(
    {
      paths: {
        jobId: selectedStep?.jobId as string,
        type: selectedStep?.type as string,
        stepType: stepType as string,
        stepId: selectedStep.stepId as string,
      },
      pagination: {
        page: currentPage - 1,
        size: 50,
      },
    },
    {
      refetchInterval: 3000,
      enabled: Boolean(selectedStep.stepId),
      onSettled: () => {
        isViewFetching.current = true;
      },
      onError: () => {
        if (!isError) {
          setError(true);
          openNotification('error', 'Error', `Failed to get build history list`);
        }
      },
      onSuccess: (data) => {
        setError(false);
      },
    },
  );

  const setCurrentPage = useCallback(
    (page: number) => {
      dispatch(historyCurPageReducer(page));
    },
    [dispatch],
  );

  const onChangeCurrentPage = useCallback(
    (page: number, pageSize?: number) => {
      setCurrentPage(page);
    },
    [setCurrentPage],
  );

  const setSelectedLog = useCallback(
    (value: BuildHistorySelectedLogState) => {
      dispatch(historySelectLogReducer(value));
    },
    [dispatch],
  );

  useEffect(() => {
    return () => {
      dispatch(historyInitReducer());
    };
  }, [dispatch]);

  useEffect(() => {
    dispatch(historySelectStepReudcer(paramInfo));
  }, [paramInfo, dispatch]);

  useEffect(() => {
    if (historyId) {
      dispatch(
        historySelectLogReducer({
          id: historyId as string,
        }),
      );
    }
  }, [historyId, dispatch]);

  useEffect(() => {
    const { jobId, type, stepId } = selectedStep;
    if (jobId && type && stepId) {
      isViewFetching.current = false;
      refetch();
    }
  }, [currentPage, selectedStep, refetch]);

  return {
    selectedLog,
    setSelectedLog,
    isFetching: isFetching && !isViewFetching.current,
    currentPage,
    onChangeCurrentPage,
    menuRef,
    doneToSelect,
    setDoneToSelect,
    data,
  };
}

function getHistoryType(pathname: string): JobType {
  if (pathname.startsWith(PAGE_URL.STATUS_REMOTE_BUILD_HISTORY_TYPE)) {
    return 'remote';
  } else {
    return 'local';
  }
}
