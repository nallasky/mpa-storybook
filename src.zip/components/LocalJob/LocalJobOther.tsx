import { MailOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { isLocalJobErrorNoticeEnable, setLocalJobErrorNotice } from '@reducers/slices/localJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { Checkbox, Collapse, Space } from 'antd';
import { CheckboxChangeEvent } from 'antd/es/checkbox';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useDispatch } from 'react-redux';
import LocalJobNoticeEmail from './LocalJobOtherNoticeEmail';

export default function LocalJobOther(): JSX.Element {
  return (
    <div css={style}>
      <ErrorNotice />
    </div>
  );
}

const style = css`
  font-size: 1rem;
  flex-wrap: nowrap;
  display: flex;
  flex-direction: column;
  margin-bottom: 2rem;
`;

const ErrorNotice = React.memo(function ErrorNoticeMemo() {
  const dispatch = useDispatch();
  const isNotice = useTypedSelector(isLocalJobErrorNoticeEnable);
  const [active, setActive] = useState(false);

  const setIsNotice = useCallback(
    (e: CheckboxChangeEvent) => {
      setActive(e.target.checked);
      dispatch(
        setLocalJobErrorNotice({
          isEmail: e.target.checked,
        }),
      );
    },
    [dispatch],
  );

  useEffect(() => {
    setActive(isNotice);
  }, []);

  const Header = useMemo(
    () => (
      <div onClick={() => setActive((prev) => !prev)}>
        <Space>
          <MailOutlined />
          <div>Error Notice</div>
        </Space>
      </div>
    ),
    [setActive],
  );
  return (
    <div css={errorNoticeStyle}>
      <div className="execute-checkbox">
        <Checkbox checked={isNotice} onChange={setIsNotice} />
      </div>
      <Collapse
        collapsible={isNotice ? 'header' : 'disabled'}
        activeKey={active ? 'errorNotice' : ''}
        css={collapseStyle(isNotice)}
      >
        <Collapse.Panel header={Header} key={'errorNotice'}>
          <LocalJobNoticeEmail />
        </Collapse.Panel>
      </Collapse>
    </div>
  );
});

const errorNoticeStyle = css`
  display: flex;

  .execute-checkbox {
    display: inherit;
    margin-right: 1rem;
    height: 3rem;
    align-items: center;

    .empty {
      width: 1rem;
      height: 3rem;
    }
  }
  .ant-collapse-item {
    width: 61.375rem;
    .ant-collapse-content-box {
      display: flex;
      flex-direction: column;
    }
  }
`;

export const collapseStyle = (enable: boolean) => css`
  width: 61.5rem;
  cursor: ${!enable && 'not-allowed'};
  .ant-collapse-header {
    pointer-events: ${!enable && 'none'};
  }
`;
