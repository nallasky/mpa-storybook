import AddressSelect from '@components/common/atoms/AddressSelect';
import { css } from '@emotion/react';
import { getLocalJobErrorNotice, setLocalJobErrorNotice } from '@reducers/slices/localJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { AddressOption } from '@typesdef/address';
import { Badge } from 'antd';
import React, { useCallback } from 'react';
import { useDispatch } from 'react-redux';

export default React.memo(function LocalJobOtherNoticeEmail(): JSX.Element {
  const dispatch = useDispatch();
  const { recipient: recipients } = useTypedSelector(getLocalJobErrorNotice);

  const setRecipients = useCallback(
    (recipients: AddressOption[]) => {
      dispatch(
        setLocalJobErrorNotice({
          recipient: recipients,
        }),
      );
    },
    [dispatch],
  );

  return (
    <div css={style}>
      <div className="recipients">
        <div className="recipients-title">
          <Badge color="blue" />
          <span>Recipients</span>
        </div>
        <div className="recipients-value">
          <AddressSelect recipients={recipients} setRecipients={setRecipients} />
        </div>
      </div>
    </div>
  );
});

const style = css`
  display: flex;
  flex-direction: column;

  .recipients-title,
  .subject-title,
  .body-title {
    display: flex;
    width: 10rem;
  }

  .recipients {
    display: flex;
    .recipients-value {
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
    }
  }

  .subject {
    display: flex;
    .subject-value {
      display: flex;
      width: 50rem;
    }
  }

  .body {
    display: flex;
    .body-value {
      display: flex;
      width: 50rem;
    }
  }
`;
