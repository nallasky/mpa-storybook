import { PaperClipOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import useUploadFiles from '@hooks/useUploadFiles';
import { getLocalJobErrorNotice, getLocalJobSiteInfo } from '@reducers/slices/localJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { Badge, Row, Space, Tooltip } from 'antd';
import { ReactNode, useMemo } from 'react';

export default function LocalJobCheck(): JSX.Element {
  const { responseFiles } = useUploadFiles();
  const siteInfo = useTypedSelector(getLocalJobSiteInfo);
  const { isEmail, recipient } = useTypedSelector(getLocalJobErrorNotice);
  const doneFilesCount = useMemo(() => responseFiles.filter((item) => item.status === 'done').length, [responseFiles]);

  const errorNoticeRecipients = useMemo(() => {
    if (!isEmail) {
      return <div>Disable</div>;
    }

    if (recipient.length === 0) {
      return <div>Default Recipients</div>;
    } else {
      return (
        <Tooltip title={recipient.map((item) => (item.group ? item.label : item.email))} placement="right" color="blue">
          {`${recipient.length} Recipients (with default)`}
        </Tooltip>
      );
    }
  }, [isEmail, recipient]);

  return (
    <div
      css={css`
        display: flex;
        flex-direction: column;
        gap: 2rem;
      `}
    >
      <CheckItem title="Local Import Name" value={siteInfo.jobName ?? ''} />
      <CheckItem title="User-Fab Name" value={siteInfo.siteName ?? ''} />
      <CheckItem
        title="Files"
        value={`${doneFilesCount} Files`}
        subValue={responseFiles.map((item) => (
          <UploadFileList key={item.uid}>
            <div css={loadFileStyle(item.status)}>
              <PaperClipOutlined className="icon" />
              <span title={item.name} className="text">{`${item.name} ${
                item.status === 'error' ? '(Error)' : ''
              }`}</span>
            </div>
          </UploadFileList>
        ))}
      />
      <CheckItem title="Error Notice" value={errorNoticeRecipients} />
    </div>
  );
}

const CheckItem = ({ title, value, subValue }: { title: string; value: ReactNode; subValue?: ReactNode }) => {
  return (
    <div css={checkItemStyle}>
      <div className="title">
        <Space>
          <Badge color="blue" />
          <div>{title}</div>
        </Space>
      </div>
      <div className="value">
        <div>{value}</div>
        <div>{subValue}</div>
      </div>
    </div>
  );
};

const checkItemStyle = css`
  display: flex;
  font-size: 1rem;
  .title {
    display: flex;
    width: 12.5rem;
  }
`;

const UploadFileList = styled(Row)`
  margin-left: 0.5rem;
`;

const loadFileStyle = (status: string | undefined) => css`
  .icon {
    margin-right: 0.5rem;
    color: rgba(0, 0, 0, 0.45);
  }
  .text {
    color: ${status === 'error' && 'red'};
    text-decoration-line: ${status === 'error' && 'line-through'};
    width: 49rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: block;
  }
  display: flex;
  align-items: center;
`;
