import { openAntdModal } from '@components/common/atoms/AntdModal';
import { PAGE_URL } from '@constants/constants';
import useUploadFiles, { ResponseUploadFile } from '@hooks/useUploadFiles';
import { postLocalJob } from '@libs/axios/requests';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { hasValue } from '@libs/util/validation';
import { getLocalJob, initLocalJob, LocalJobReduxState } from '@reducers/slices/localJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { useIsFetching, useMutation } from '@tanstack/react-query';
import { LOCAL_JOB_STEP, LOCAL_JOB_VALIDATION_ERROR, ReqLocalJob, ReqRemoteJobStep } from '@typesdef/Job';
import { AxiosError } from 'axios';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';

export default function useLocalJob() {
  const [[current, direction], setCurrent] = useState([LOCAL_JOB_STEP.CONFIGURE, 0]);
  const localJob = useTypedSelector(getLocalJob);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  // TODO: There is an error that cannot save the filelist of the upload component of antd to the store of redux.
  // Alternatively, use use-global-hook to share values between hooks.
  // In the future, you will need to move to redux when this problem is resolved.
  const { responseFiles, initUploadFiles } = useUploadFiles();

  const isFetchingSiteListData = Boolean(useIsFetching([QUERY_KEY.STATUS_SITE_LIST]));

  const { mutateAsync: mutateAsyncAdd } = useMutation((reqData: ReqLocalJob) => postLocalJob(reqData), {
    mutationKey: [MUTATION_KEY.JOB_LOCAL_ADD],
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', 'Failed to add local import!', error);
    },
    onSuccess: () => {
      openNotification('success', 'Success', 'Succeed to add local import.');
    },
    onSettled: () => {
      onBack();
    },
  });
  const onBack = useCallback(() => {
    navigate(PAGE_URL.STATUS_LOCAL);
  }, [navigate]);

  const openAddModal = useCallback(() => {
    openAntdModal('confirm', {
      className: 'add-local-job',
      title: 'Add Local Import',
      content: 'Are you sure to add local import?',
      okText: 'Add',
      onOk: async () => {
        try {
          const reqData = makeRequestData({ localJob, responseFiles });
          await mutateAsyncAdd(reqData);
        } catch (e) {
          // errors are handled by mutate.
        }
      },
    });
  }, [localJob, responseFiles, mutateAsyncAdd]);

  const openWarningModal = useCallback((code: LOCAL_JOB_VALIDATION_ERROR) => {
    if (code !== LOCAL_JOB_VALIDATION_ERROR.NO_ERROR) {
      openAntdModal('warning', {
        title: 'Warning',
        okText: 'Close',
        content: getLocalJobErrorReasonText(code),
      });
    }
  }, []);

  const onNextAction = useCallback(async () => {
    if (current === LOCAL_JOB_STEP.CONFIGURE) {
      const errCode = configureValidation(localJob, responseFiles);
      if (errCode !== LOCAL_JOB_VALIDATION_ERROR.NO_ERROR) {
        openWarningModal(errCode);
        return false;
      }
    } else if (current === LOCAL_JOB_STEP.OTHER) {
      const errCode = otherValidation(localJob);
      if (errCode !== LOCAL_JOB_VALIDATION_ERROR.NO_ERROR) {
        openWarningModal(errCode);
        return false;
      }
    } else {
      openAddModal();
    }

    return true;
  }, [current, localJob, responseFiles, openWarningModal, openAddModal]);

  const disabledNext = useMemo(() => isFetchingSiteListData, [isFetchingSiteListData]);

  const onNext = () => {
    setCurrent((prev) => [prev[0] + 1, 1]);
  };

  const onPrev = () => {
    setCurrent((prev) => [prev[0] - 1, -1]);
  };

  useEffect(() => {
    dispatch(initLocalJob());
    initUploadFiles();
  }, []);

  return {
    current,
    direction,
    onNextAction,
    onBack,
    disabledNext,
    onNext,
    onPrev,
  };
}

const configureValidation = (jobInfo: LocalJobReduxState, files: ResponseUploadFile[]) => {
  if (!hasValue(jobInfo.siteInfo.jobName)) {
    return LOCAL_JOB_VALIDATION_ERROR.CONFIG_NO_JOB_NAME;
  }

  if (!hasValue(jobInfo.siteInfo.siteId)) {
    return LOCAL_JOB_VALIDATION_ERROR.CONFIG_NO_SITE;
  }

  if (files.filter((item) => item.status === 'uploading').length > 0) {
    return LOCAL_JOB_VALIDATION_ERROR.CONFIG_UPLOADING_FILES;
  }
  if (files.filter((item) => item.status === 'done').length === 0) {
    return LOCAL_JOB_VALIDATION_ERROR.CONFIG_NO_FILES;
  }

  return LOCAL_JOB_VALIDATION_ERROR.NO_ERROR;
};

const otherValidation = (jobInfo: LocalJobReduxState) => {
  // if (jobInfo.errorNotice.isEmail) {
  //   if (jobInfo.errorNotice.recipient.length === 0) {
  //     return LOCAL_JOB_VALIDATION_ERROR.OTHER_NO_RECIPIENTS;
  //   }
  // }

  return LOCAL_JOB_VALIDATION_ERROR.NO_ERROR;
};

const getLocalJobErrorReasonText = (code: LOCAL_JOB_VALIDATION_ERROR) =>
  ({
    // Configure
    [LOCAL_JOB_VALIDATION_ERROR.CONFIG_NO_JOB_NAME]: 'Please select a local import name!',
    [LOCAL_JOB_VALIDATION_ERROR.CONFIG_NO_SITE]: 'Please select a user-fab name!',
    [LOCAL_JOB_VALIDATION_ERROR.CONFIG_UPLOADING_FILES]:
      'File is being uploaded. Please wait until the upload is finished!',
    [LOCAL_JOB_VALIDATION_ERROR.CONFIG_NO_FILES]: 'Please upload at least one file!',

    // Other
    [LOCAL_JOB_VALIDATION_ERROR.OTHER_NO_RECIPIENTS]: 'Please add recipients of error notice!',
  }[code as number] ?? 'Unknown Error!');

const initialReqLocalStep: ReqRemoteJobStep = {
  uuid: null,
  stepId: null,
  stepName: null,
  stepType: 'convert',
  enable: false,
  mode: null,
  time: [],
  cycle: null,
  period: null,
  preStep: null,
  nextStep: null,
  isEmail: false,
  customEmails: [],
  emailBookIds: [],
  groupBookIds: [],
  subject: null,
  body: null,
  before: null,
  selectJudgeRuleIds: [],
  description: null,
  scriptType: null,
  script: null,
  fileIndices: [],
  planIds: [],
  retentionPeriod: null,
  isFtp: false,
  ftps: [],
};

const makeRequestData = ({
  localJob,
  responseFiles,
}: {
  localJob: LocalJobReduxState;
  responseFiles: ResponseUploadFile[];
}): ReqLocalJob => {
  const { siteInfo, errorNotice } = localJob;

  const convertStep: ReqRemoteJobStep = {
    ...initialReqLocalStep,
    stepType: 'convert',
    uuid: uuidv4(),
    enable: true,
    fileIndices: responseFiles.reduce((acc, cur) => {
      if (cur.status === 'done' && cur.fileIndex !== undefined) return acc.concat(cur.fileIndex);
      else return acc;
    }, <number[]>[]),
  };

  const noticeStep: ReqRemoteJobStep = {
    ...initialReqLocalStep,
    stepType: 'notice',
    uuid: uuidv4(),
    enable: errorNotice.isEmail,
    isEmail: errorNotice.isEmail,
    customEmails: errorNotice.recipient?.filter((item) => item.id <= 0).map((filtered) => filtered.email) ?? [],
    emailBookIds:
      errorNotice.recipient?.filter((item) => !item.group && item.id > 0).map((filtered) => filtered.id) ?? [],
    groupBookIds: errorNotice.recipient?.filter((item) => item.group).map((filtered) => filtered.id) ?? [],
    fileIndices: responseFiles.reduce((acc, cur) => {
      if (cur.status === 'done' && cur.fileIndex !== undefined) return acc.concat(cur.fileIndex);
      else return acc;
    }, <number[]>[]),
  };

  return {
    jobName: siteInfo.jobName as string,
    siteId: siteInfo.siteId as number,
    steps: [convertStep, noticeStep],
  };
};
