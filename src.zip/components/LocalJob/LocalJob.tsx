import { AppstoreOutlined, ControlOutlined } from '@ant-design/icons';
import CustomIcon from '@components/common/atoms/CustomIcon';
import SideSteps from '@components/common/atoms/SideSteps';
import StepButton from '@components/common/atoms/StepButton';
import { css } from '@emotion/react';
import { stepTransition, variantsAxisForX } from '@libs/util/framerMotion';
import { LOCAL_JOB_STEP } from '@typesdef/Job';
import { PageHeader, Space } from 'antd';
import { AnimatePresence, motion } from 'framer-motion';
import useLocalJob from './hooks/useLocalJob';
import LocalJobCheck from './LocalJobCheck';
import LocalConfigure from './LocalJobConfigure';
import LocalJobOther from './LocalJobOther';

export type LocalJobProps = {};
export default function LocalJob(): JSX.Element {
  const { current, direction, onNextAction, onBack, disabledNext, onNext, onPrev } = useLocalJob();

  return (
    <div css={style}>
      <PageHeader
        onBack={onBack}
        title="Add Local Import Setting"
        css={css`
          padding: 0 0 0 0;
          margin-bottom: 1rem;
        `}
      />
      <div className="setting__wrapper">
        <SideSteps current={current} stepList={localStepList} />
        <div className="setting__context">
          <div className="setting__context__title">
            <Title current={current} />
            <StepButton
              current={current}
              onNext={onNext}
              onPrev={onPrev}
              lastStep={LOCAL_JOB_STEP.CHECK}
              nextActionPromise={onNextAction}
              disabled={disabledNext}
            />
          </div>
          <AnimatePresence mode="popLayout" initial={false} custom={direction}>
            <motion.div
              key={current}
              custom={direction}
              variants={variantsAxisForX(20)}
              initial="enter"
              animate="center"
              exit="exit"
              transition={stepTransition}
              className="setting__context__main"
            >
              {current === LOCAL_JOB_STEP.CONFIGURE && <LocalConfigure />}
              {current === LOCAL_JOB_STEP.OTHER && <LocalJobOther />}
              {current >= LOCAL_JOB_STEP.CHECK && <LocalJobCheck />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

interface TitleProps {
  current: number;
}
function Title({ current }: TitleProps) {
  const { icon, text } = getTitle(current);

  return (
    <Space>
      {icon}
      <span>{text}</span>
    </Space>
  );
}

function getTitle(current: number) {
  switch (current) {
    case LOCAL_JOB_STEP.CONFIGURE:
      return {
        icon: <ControlOutlined />,
        text: 'Configure',
      };
    case LOCAL_JOB_STEP.OTHER:
      return {
        icon: <AppstoreOutlined />,
        text: 'Other Settings',
      };
    case LOCAL_JOB_STEP.CHECK:
    default:
      return {
        icon: <CustomIcon name="check_setting" />,
        text: 'Check Settings',
      };
  }
}

const style = css`
  display: flex;
  flex-direction: column;
  width: 100%;
  .setting__wrapper {
    display: flex;
    width: 100%;
    padding-left: 1rem;
    .setting__context {
      display: flex;
      flex-direction: column;
      width: 100%;
      padding-left: 1rem;
      .setting__context__title {
        display: flex;
        justify-content: space-between;
        width: 100%;
        font-size: 1.125rem;
      }
      .setting__context__main {
        display: flex;
        flex-direction: column;
        width: 100%;
        padding-top: 2rem;
        padding-left: 2rem;
      }
    }
  }
`;

export const localStepList = ['Configure', 'Other', 'Check'];
