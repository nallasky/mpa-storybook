import { FieldTimeOutlined, LoadingOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import { css } from '@emotion/react';
import { Badge, Form, InputNumber, Space, Spin, Typography } from 'antd';
import { ReactNode } from 'react';
import useSystemConfigRetention from './hooks/useSystemConfigRetention';

export function SystemConfigRetention() {
  const { form, onSave, isFetching } = useSystemConfigRetention();
  return (
    <div css={style}>
      <div className="header">
        <div className="title">
          <FieldTimeOutlined width={'20px'} />
          <Typography.Title level={4}>Data Retention</Typography.Title>
          {isFetching && <Spin indicator={<LoadingOutlined spin />} />}
        </div>
        <Space>
          <AntdButton onClick={onSave}>Save</AntdButton>
        </Space>
      </div>
      <Form
        form={form}
        layout="horizontal"
        labelCol={{ span: 6 }}
        wrapperCol={{ span: 18 }}
        colon={false}
        requiredMark={false}
        disabled={isFetching}
      >
        <Form.Item
          name="buildHistory"
          label={<PurgeLabel>Build History</PurgeLabel>}
          rules={[
            {
              required: true,
              message: `Please input a number between 1 to 9999!`,
            },
          ]}
        >
          <InputNumber
            min={1}
            max={9999}
            maxLength={4}
            precision={0}
            addonAfter="Days"
            css={css`
              width: 8.375rem;
            `}
          />
        </Form.Item>
      </Form>
    </div>
  );
}

const PurgeLabel = ({ children }: { children: ReactNode }) => (
  <Space size={0.5}>
    <Badge color="blue" />
    {children}
  </Space>
);

const style = css`
  display: flex;
  flex-direction: column;
  gap: 1rem;

  .header {
    display: flex;
    justify-content: space-between;
    .title {
      display: flex;
      align-items: center;
      .anticon {
        font-size: 1.3rem;
        margin-right: 0.5rem;
      }
      .ant-typography {
        margin-bottom: 0;
      }
      .ant-spin {
        margin-left: 0.5rem;
      }
    }
  }

  .ant-form {
    width: 100%;
    .ant-form-item-label {
      text-align: left;
    }
  }
`;
