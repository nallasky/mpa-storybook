import { DeleteOutlined, EditOutlined, FileProtectOutlined, LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import { undraw_create } from '@assets/images';
import AntdButton from '@components/common/atoms/AntdButton';
import { V_SPACE } from '@components/common/atoms/Space';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { useGetUserFabNameList } from '@libs/query/common';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { openNotification } from '@libs/util/notification';
import { hoverActiveStyle } from '@styles/emotion/common';
import type { TableColumnPropsType } from '@typesdef/common';
import type { SystemConfigFtpSummary } from '@typesdef/systemConfig';
import { Popconfirm, Spin, Table, Typography } from 'antd';
import useSystemConfigFTP from './hooks/useSystemConfigFTP';

export default function SystemConfigFtp() {
  const { data: crasList, isFetching: isFetchingCrasList } = useGetUserFabNameList({
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response the list of convert rule(user-fab name)`, error);
    },
  });

  const hasCrasServer = Boolean(crasList?.length ?? 0);

  return (
    <div css={style}>
      <div className="header">
        <div className="title">
          <FileProtectOutlined width={'20px'} />
          <Typography.Title level={4}>FTP/SFTP</Typography.Title>
          {isFetchingCrasList && <Spin indicator={<LoadingOutlined spin />} />}
        </div>
      </div>
      {hasCrasServer ? (
        <SystemConfigFtpContent />
      ) : (
        <div className="not-registered" css={emptyStyle}>
          <img alt="register " src={undraw_create} />
          <V_SPACE rem={2} />
          <div className="text">Please register at least one Cras Server in Server Config.</div>
        </div>
      )}
    </div>
  );
}

const style = css`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  .header {
    display: flex;
    justify-content: space-between;
    .title {
      display: flex;
      align-items: center;
      .anticon {
        font-size: 1.3rem;
        margin-right: 0.5rem;
      }
      .ant-typography {
        margin-bottom: 0;
      }
      .ant-spin {
        margin-left: 0.5rem;
      }
    }
  }
`;

export function SystemConfigFtpContent() {
  const { ftpList, isFetchingFtpList, openViewModal, openAddModal, onDelete, openEditModal } = useSystemConfigFTP();

  const renderTitle = () => (
    <TableHeader title={<TableHeaderTitle total={ftpList?.length ?? 0} />}>
      <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddModal}>
        Add
      </AntdButton>
    </TableHeader>
  );

  const renderName = (value: string, record: SystemConfigFtpSummary, index: number) => {
    const { id, name, type } = record;
    return (
      <div css={hoverActiveStyle} onClick={() => openViewModal({ id, name, type })}>
        {value}
      </div>
    );
  };

  const renderEdit = (value: number, record: SystemConfigFtpSummary, index: number) => {
    const { id, name, type } = record;
    return <EditOutlined css={hoverActiveStyle} onClick={() => openEditModal({ id, name, type })} />;
  };

  const renderDelete = (value: number, record: SystemConfigFtpSummary, index: number) => {
    const { id, name, type } = record;

    return (
      <Popconfirm title="Are you sure to delete Log?" onConfirm={() => onDelete({ id, name, type })} okText="Delete">
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div>
      <Table<SystemConfigFtpSummary>
        rowKey={'id'}
        dataSource={ftpList ?? []}
        bordered
        title={renderTitle}
        size="middle"
        pagination={{
          position: ['bottomCenter'],
        }}
        loading={isFetchingFtpList}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<SystemConfigFtpSummary> {...columnProps.name} render={renderName} />
        <Table.Column<SystemConfigFtpSummary> {...columnProps.type} />
        <Table.Column<SystemConfigFtpSummary> {...columnProps.remoteHost} />
        <Table.Column<SystemConfigFtpSummary> {...columnProps.port} />
        <Table.Column<SystemConfigFtpSummary> {...columnProps.edit} render={renderEdit} />
        <Table.Column<SystemConfigFtpSummary> {...columnProps.delete} render={renderDelete} />
      </Table>
    </div>
  );
}

type ColumnName = 'name' | 'type' | 'remoteHost' | 'port' | 'edit' | 'delete';

const columnProps: TableColumnPropsType<SystemConfigFtpSummary, ColumnName> = {
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'name'),
    },
    width: getPixelPercent(1124, 384),
  },
  type: {
    key: 'type',
    title: <TableColumnTitle>Type</TableColumnTitle>,
    dataIndex: 'type',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'type'),
    },
    width: getPixelPercent(1124, 130),
  },
  remoteHost: {
    key: 'remoteHost',
    title: <TableColumnTitle>Remote Host</TableColumnTitle>,
    dataIndex: 'remoteHost',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'remoteHost'),
    },
    width: getPixelPercent(1124, 260),
  },
  port: {
    key: 'port',
    title: <TableColumnTitle>Port</TableColumnTitle>,
    dataIndex: 'port',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'port'),
    },
    width: getPixelPercent(1124, 130),
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    dataIndex: 'id',
    align: 'center',
    width: getPixelPercent(1124, 110),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    dataIndex: 'id',
    align: 'center',
    width: getPixelPercent(1124, 110),
  },
};

const emptyStyle = css`
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  margin-top: 4rem;
  img {
    width: 40rem;
  }
  .text {
    font-size: 1.6rem;
  }
`;
