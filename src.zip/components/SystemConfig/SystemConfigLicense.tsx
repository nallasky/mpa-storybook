import { AuditOutlined, LoadingOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import { css } from '@emotion/react';
import { Badge, Space, Spin, Typography } from 'antd';
import { ReactNode } from 'react';
import useSystemConfigLicense from './hooks/useSystemConfigLicense';

export function SystemConfigLicense() {
  const { licenseData, isFetchingLicense, openDownloadModal, openRegisterModal } = useSystemConfigLicense();

  return (
    <div css={style}>
      <div className="header">
        <div className="title">
          <AuditOutlined width={'20px'} />
          <Typography.Title level={4}>License</Typography.Title>
          {isFetchingLicense && <Spin indicator={<LoadingOutlined spin />} />}
        </div>
        <Space>
          <AntdButton disabled={licenseData.path === 'Unknown' || isFetchingLicense} onClick={openDownloadModal}>
            Download
          </AntdButton>
          <AntdButton disabled={isFetchingLicense} onClick={openRegisterModal}>
            Register
          </AntdButton>
        </Space>
      </div>
      <LicenseItem title="Status">
        <div>{licenseData.status}</div>
      </LicenseItem>
      <LicenseItem title="Expiration Date">
        <div>{licenseData.expirationDate}</div>
      </LicenseItem>
      <LicenseItem title="Path">
        <div>{licenseData.path}</div>
      </LicenseItem>
    </div>
  );
}

const style = css`
  display: flex;
  flex-direction: column;
  gap: 1rem;

  .header {
    display: flex;
    justify-content: space-between;
    .title {
      display: flex;
      align-items: center;
      .anticon {
        font-size: 1.3rem;
        margin-right: 0.5rem;
      }
      .ant-typography {
        margin-bottom: 0;
      }
      .ant-spin {
        margin-left: 0.5rem;
      }
    }
  }
`;

function LicenseItem({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div css={licenseItemStyle}>
      <div className="name">
        <Badge color="blue" />
        <div>{title}</div>
      </div>
      <div className="value">{children}</div>
    </div>
  );
}

const licenseItemStyle = css`
  display: flex;
  height: 2rem;
  align-items: center;
  .name {
    display: flex;
    width: 20rem;
  }
  .value {
    display: flex;
    align-items: center;
  }
`;
