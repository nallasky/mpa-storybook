import { QUERY_KEY } from '@libs/query/queryKey';
import {
  useGetSystemConfigFtpById,
  usePostSystemConfigFtp,
  usePostSystemConfigFtpTest,
  usePutSystemConfigFtp,
} from '@libs/query/systemConfig';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import type { SystemConfigFtp } from '@typesdef/systemConfig';
import type { BadgeProps } from 'antd';
import { RuleObject } from 'antd/es/form';
import { useForm, useWatch } from 'antd/es/form/Form';
import { useEffect, useState } from 'react';
import type { SystemConfigFtpModalProps } from '../Modal/SystemConfigFTPModal';
import { defaultRootPath } from './../Modal/SystemConfigFTPModal';

export default function useSystemConfigFtpModal({
  id,
  onClose,
  visible,
  mode,
  ftpList,
}: GlobalModalDefaultProps<SystemConfigFtpModalProps>) {
  const queryClient = useQueryClient();
  const [form] = useForm<SystemConfigFtp>();
  const [logServerTags, setStateLogServerTags] = useState<string[]>([]);
  const watchLogServerRoot = useWatch('logServerRoot', form);
  const watchRecallRoot = useWatch('recallRoot', form);

  const { isFetching: isFetchingFtp } = useGetSystemConfigFtpById(id as number, {
    enabled: (mode === 'view' || mode === 'edit') && id !== undefined,
    onSuccess: (data) => {
      form.setFieldsValue({
        ...data,
      });
      setStateLogServerTags(data.logServerTags);
      console.log(form.getFieldsValue());
    },
  });

  const { mutateAsync: mutateAsyncAdd, isLoading: isMutatingAdd } = usePostSystemConfigFtp({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to ${mode} ftp server.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to ${mode} ftp server!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.SYSTEM_CONFIG_FTP_LIST]);
      onClose();
    },
  });
  const { mutateAsync: mutateAsyncEdit, isLoading: isMutatingEdit } = usePutSystemConfigFtp({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to ${mode} ftp server.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to ${mode} ftp server!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.SYSTEM_CONFIG_FTP_LIST]);
      onClose();
    },
  });

  const { mutate: mutateRecallTest, status: recallTestStatus } = usePostSystemConfigFtpTest();
  const { mutate: mutateLogServerTest, status: logServerTestStatus } = usePostSystemConfigFtpTest();

  const recallTestBadgeProps = testStatus[recallTestStatus];
  const logServerTestBadgeStatus = testStatus[logServerTestStatus];

  const isRequestingServer =
    isMutatingAdd ||
    isMutatingEdit ||
    recallTestStatus === 'loading' ||
    logServerTestStatus === 'loading' ||
    isFetchingFtp;

  const isSubmitting = isMutatingAdd || isMutatingEdit;

  const setLogServerTags = (logServerTags: string[]) => {
    setStateLogServerTags(logServerTags);
    form.setFieldsValue({
      logServerTags,
    });
    form.validateFields(['logServerRoot']);
  };

  const onOk = async () => {
    if (mode === 'view') {
      onClose();
      return;
    }

    try {
      if (!watchRecallRoot && !watchLogServerRoot) {
        throw new Error('Please select at least one root path.');
      }

      await form.validateFields();

      if (mode === 'add') {
        await mutateAsyncAdd({
          ...form.getFieldsValue(),
          id: -1,
        });
      } else {
        await mutateAsyncEdit(form.getFieldsValue());
      }
    } catch (e) {
      console.error(e);
    }
  };

  const onTestRecall = async () => {
    try {
      await form.validateFields(['type', 'remoteHost', 'port', 'username', 'password', 'recallRoot']);
      const { type, remoteHost, port, username, password, recallRoot } = form.getFieldsValue();
      mutateRecallTest({
        type,
        remoteHost,
        port,
        username,
        password,
        rootPath: recallRoot,
      });
    } catch (e) {
      console.error(e);
    }
  };

  const onTestLogServer = async () => {
    try {
      await form.validateFields(['type', 'remoteHost', 'port', 'username', 'password', 'logServerRoot']);
      const { type, remoteHost, port, username, password, logServerRoot } = form.getFieldsValue();
      mutateLogServerTest({
        type,
        remoteHost,
        port,
        username,
        password,
        rootPath: logServerRoot,
      });
    } catch (e) {
      console.error(e);
    }
  };

  const validateName = async (rule: RuleObject, value: string) => {
    const trimmedValue = (value ?? '').trim();

    if (!trimmedValue) {
      throw new Error('Please input a name!');
    }

    const foundName = ftpList.find((ftpList) => ftpList.name === trimmedValue);
    if (foundName) {
      if (mode === 'add') {
        throw new Error('Duplicated name!');
      } else {
        if (foundName.id !== id) {
          throw new Error('Duplicated name!');
        }
      }
    }
  };

  useEffect(() => {
    if (mode === 'add') {
      form.resetFields();
      form.setFieldsValue({
        recallRoot: defaultRootPath.recall,
        logServerRoot: defaultRootPath.logServer,
      });
    }
  }, [mode, form]);

  return {
    mode,
    form,
    logServerTags,
    setLogServerTags,
    onTestRecall,
    onTestLogServer,
    recallTestBadgeProps,
    logServerTestBadgeStatus,
    isRequestingServer,
    isSubmitting,
    isFetchingFtp,
    onOk,
    watchLogServerRoot,
    watchRecallRoot,
    validateName,
  };
}

const testStatus: Record<'error' | 'idle' | 'loading' | 'success', Pick<BadgeProps, 'status' | 'text'>> = {
  loading: { status: 'processing', text: 'Processing' },
  error: { status: 'error', text: 'Error' },
  success: { status: 'success', text: 'Success' },
  idle: { status: 'default', text: 'Not Tested' },
};
