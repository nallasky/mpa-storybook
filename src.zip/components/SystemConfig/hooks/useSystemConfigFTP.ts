import { openAntdModal } from '@components/common/atoms/AntdModal';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { QUERY_KEY } from '@libs/query/queryKey';
import { useDeleteSystemConfigFtp, useGetSystemConfigFtpList } from '@libs/query/systemConfig';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { SystemConfigFtpSummary } from '@typesdef/systemConfig';
import SystemConfigFtpModal, { SystemConfigFtpModalProps } from '../Modal/SystemConfigFTPModal';

export default function useSystemConfigFTP() {
  const { openModal } = useModals();
  const queryClient = useQueryClient();

  const { data: ftpList, isFetching: isFetchingFtpList } = useGetSystemConfigFtpList({
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response the list of ftp!`, error);
    },
  });

  const { mutateAsync: mutateDeleteAsync } = useDeleteSystemConfigFtp({
    onSuccess: (data) => {
      const { name, type } = data;
      openNotification('success', 'Success', `Succeed to Delete the ${name} of ${type}.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete ftp/stp!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.SYSTEM_CONFIG_FTP_LIST]);
    },
  });

  const openViewModal = ({ id, name, type }: Pick<SystemConfigFtpSummary, 'id' | 'name' | 'type'>) => {
    openModal<SystemConfigFtpModalProps>(MODAL_NAME.SYSTEM_CONFIG.FTP.ADD_EDIT, SystemConfigFtpModal, {
      id,
      mode: 'view',
      ftpList: [],
    });
  };

  const openAddModal = () => {
    openModal<SystemConfigFtpModalProps>(MODAL_NAME.SYSTEM_CONFIG.FTP.ADD_EDIT, SystemConfigFtpModal, {
      mode: 'add',
      ftpList: ftpList ?? [],
    });
  };

  const onDelete = async ({ id, name, type }: Pick<SystemConfigFtpSummary, 'id' | 'name' | 'type'>) => {
    try {
      await mutateDeleteAsync(id);
    } catch (e) {
      console.error(e);
    }
  };

  const openEditModal = ({ id, name, type }: Pick<SystemConfigFtpSummary, 'id' | 'name' | 'type'>) => {
    openAntdModal('confirm', {
      title: 'Edit FTP/SFTP Server',
      content: `Are you sure to edit the ${name} of ${type}'?`,
      okText: 'Edit',
      onOk: () => {
        openModal<SystemConfigFtpModalProps>(MODAL_NAME.SYSTEM_CONFIG.FTP.ADD_EDIT, SystemConfigFtpModal, {
          id,
          mode: 'edit',
          ftpList: ftpList ?? [],
        });
      },
    });
  };

  return {
    ftpList,
    isFetchingFtpList,
    openViewModal,
    openAddModal,
    onDelete,
    openEditModal,
  };
}
