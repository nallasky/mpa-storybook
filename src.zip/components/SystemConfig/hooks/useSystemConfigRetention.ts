import { openAntdModal } from '@components/common/atoms/AntdModal';
import { useGetSystemConfigRetention, usePutSystemConfigRetention } from '@libs/query/systemConfig';
import { openNotification } from '@libs/util/notification';
import { ReqSystemConfigRetention } from '@typesdef/systemConfig';
import { useForm } from 'antd/es/form/Form';
import { AxiosError } from 'axios';

export default function useSystemConfigRetention() {
  const [form] = useForm<ReqSystemConfigRetention>();
  const { isFetching, refetch } = useGetSystemConfigRetention({
    onSuccess: (data) => {
      form.setFieldsValue(data);
    },
  });
  const { mutateAsync: mutateAsyncSave } = usePutSystemConfigRetention();

  const onSave = async () => {
    try {
      await form.validateFields();
      openSaveModal();
    } catch (error) {
      console.error(error);
    }
  };

  const openSaveModal = () => {
    openAntdModal('confirm', {
      title: 'Save Data retention',
      content: `Are you sure to save data retention?`,
      okText: 'Save',
      onOk: async () => {
        try {
          const values = form.getFieldsValue();
          await mutateAsyncSave(values);
        } catch (e) {
          openNotification('error', 'Error', `Failed to save data retention!`, e as AxiosError);
        } finally {
          refetch();
        }
      },
    });
  };

  return {
    form,
    onSave,
    isFetching,
  };
}
