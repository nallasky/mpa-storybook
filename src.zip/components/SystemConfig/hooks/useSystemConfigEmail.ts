import { openAntdModal } from '@components/common/atoms/AntdModal';
import { convertRecipientState } from '@components/RemoteJob/hooks/useRemoteJobSteps';
import { useGetSystemConfigDefaultEmail, usePutSystemConfigDefaultEmail } from '@libs/query/systemConfig';
import { openNotification } from '@libs/util/notification';
import { AddressOption } from '@typesdef/address';
import { SystemConfigDefaultEmailState } from '@typesdef/systemConfig';
import { AxiosError } from 'axios';
import { produce } from 'immer';
import { useCallback, useMemo, useReducer, useState } from 'react';
import { useDebounce } from 'react-use';

type ReducerAction =
  | { type: 'save_from_server'; payload: SystemConfigDefaultEmailState }
  | { type: 'recipient'; payload: SystemConfigDefaultEmailState['recipient'] }
  | { type: 'add_recipient_custom'; payload: string }
  | { type: 'subject_summary'; payload: SystemConfigDefaultEmailState['subject']['summary'] }
  | { type: 'subject_cras'; payload: SystemConfigDefaultEmailState['subject']['cras'] }
  | { type: 'subject_version'; payload: SystemConfigDefaultEmailState['subject']['version'] }
  | { type: 'subject_notice'; payload: SystemConfigDefaultEmailState['subject']['notice'] }
  | { type: 'password'; payload: SystemConfigDefaultEmailState['password'] };

const initialReducerState: SystemConfigDefaultEmailState = {
  recipient: {
    emailBook: [],
    groupBook: [],
    customEmails: [],
  },
  subject: {
    summary: '',
    cras: '',
    version: '',
    notice: '',
  },
  password: '',
};

function reducer(state: SystemConfigDefaultEmailState, action: ReducerAction): SystemConfigDefaultEmailState {
  switch (action.type) {
    case 'save_from_server':
      return produce(state, (draft) => {
        const {
          recipient: { emailBook, customEmails, groupBook },
          subject: { summary, cras, version, notice },
          password,
        } = action.payload;
        draft.recipient = {
          emailBook: emailBook ?? [],
          groupBook: groupBook ?? [],
          customEmails: customEmails ?? [],
        };

        draft.password = password ?? '';

        draft.subject = {
          summary: summary ?? '',
          cras: cras ?? '',
          version: version ?? '',
          notice: notice ?? '',
        };
      });
    case 'recipient':
      return produce(state, (draft) => {
        const { emailBook, customEmails, groupBook } = action.payload;
        draft.recipient.emailBook = emailBook ?? [];
        draft.recipient.customEmails = customEmails ?? [];
        draft.recipient.groupBook = groupBook ?? [];
      });
    case 'add_recipient_custom':
      return produce(state, (draft) => {
        if (action.payload) {
          draft.recipient.customEmails.push(action.payload);
        }
      });

    case 'subject_summary':
      return produce(state, (draft) => {
        draft.subject.summary = action.payload;
      });
    case 'subject_cras':
      return produce(state, (draft) => {
        draft.subject.cras = action.payload;
      });
    case 'subject_version':
      return produce(state, (draft) => {
        draft.subject.version = action.payload;
      });
    case 'subject_notice':
      return produce(state, (draft) => {
        draft.subject.notice = action.payload;
      });
    case 'password':
      return produce(state, (draft) => {
        draft.password = action.payload;
      });
    default:
      return state;
  }
}

export default function useSystemConfigEmail() {
  const [
    {
      recipient: { emailBook, groupBook, customEmails },
      subject: { summary, cras, version, notice },
      password,
    },
    setEmail,
  ] = useReducer(reducer, initialReducerState);

  const [{ summary: inputSummary, cras: inputCras, version: inputVersion, notice: inputNotice }, setInputSubject] =
    useState<SystemConfigDefaultEmailState['subject']>({
      summary: '',
      cras: '',
      version: '',
      notice: '',
    });

  const { isFetching, refetch } = useGetSystemConfigDefaultEmail({
    onSuccess: (payload) => {
      setEmail({ type: 'save_from_server', payload });

      const {
        subject: { summary, cras, version, notice },
      } = payload;
      setInputSubject({
        summary,
        cras,
        version,
        notice,
      });
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response the default email!`, error);
      setEmail({ type: 'save_from_server', payload: initialReducerState });
      setInputSubject({
        summary: '',
        cras: '',
        version: '',
        notice: '',
      });
    },
  });

  const { mutateAsync: mutateAsyncSave, isLoading: isLoadingSave } = usePutSystemConfigDefaultEmail({});

  useDebounce(
    () => {
      setEmail({ type: 'subject_summary', payload: inputSummary });
    },
    300,
    [inputSummary],
  );

  useDebounce(
    () => {
      setEmail({ type: 'subject_cras', payload: inputCras });
    },
    300,
    [inputCras],
  );

  useDebounce(
    () => {
      setEmail({ type: 'subject_version', payload: inputVersion });
    },
    300,
    [inputVersion],
  );

  useDebounce(
    () => {
      setEmail({ type: 'subject_notice', payload: inputNotice });
    },
    300,
    [inputNotice],
  );

  const recipients = useMemo(
    () =>
      convertRecipientState({
        emailBook,
        groupBook,
        customEmails,
      }),
    [emailBook, groupBook, customEmails],
  );

  const setEachRecipients = useCallback(
    ({
      emailBook,
      groupBook,
      customEmails,
    }: {
      emailBook: AddressOption[];
      groupBook: AddressOption[];
      customEmails: string[];
    }) => {
      setEmail({ type: 'recipient', payload: { emailBook, groupBook, customEmails } });
    },
    [],
  );

  const onChangeInput = ({ type, value }: { type: 'summary' | 'cras' | 'version' | 'notice'; value: string }) => {
    setInputSubject((prev) => ({ ...prev, [type]: value }));
  };

  const onChangePassword: React.ChangeEventHandler<HTMLInputElement> = ({ target: { value } }) => {
    setEmail({ type: 'password', payload: value });
  };

  const openSaveModal = () => {
    openAntdModal('confirm', {
      title: 'Save Default Email',
      content: `Are you sure to save default email?`,
      okText: 'Save',
      onOk: async () => {
        try {
          await mutateAsyncSave({
            recipient: {
              emailBookIds: emailBook.map(({ id }) => +id),
              groupBookIds: groupBook.map(({ id }) => +id),
              customEmails,
            },
            subject: {
              summary,
              cras,
              notice,
              version,
            },
            password,
          });
        } catch (e) {
          openNotification('error', 'Error', `Failed to save default email!`, e as AxiosError);
        } finally {
          refetch();
        }
      },
    });
  };

  return {
    disabled: isFetching || isLoadingSave,
    isFetching: isFetching,
    recipients,
    setEachRecipients,
    password,
    onChangePassword,
    inputSummary,
    inputCras,
    inputVersion,
    inputNotice,
    onChangeInput,
    openSaveModal,
  };
}
