import { openAntdModal } from '@components/common/atoms/AntdModal';
import FileImportModal, { FileImportModalProps } from '@components/common/atoms/FileImportModal/FileImportModal';
import { API_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { useGetSystemConfigLicense, useGetSystemConfigLicenseExport } from '@libs/query/systemConfig';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { LicenseStatusType } from '@typesdef/auth';
import { AxiosError } from 'axios';
import saveAs from 'file-saver';
import { useMemo } from 'react';

export default function useSystemConfigLicense() {
  const { data: license, isFetching: isFetchingLicense } = useGetSystemConfigLicense({
    onError: (error) => {
      openNotification(
        'error',
        'Error',
        getAxiosErrorMessage(error, 'Failed to get license information!'),
        error as AxiosError,
      );
    },
  });
  const { openModal } = useModals();
  const queryClient = useQueryClient();

  const { mutateAsync: mutateAsyncExport } = useGetSystemConfigLicenseExport();

  const licenseData = useMemo(
    () => ({
      path: getLicenseText.path(license?.path),
      status: getLicenseText.status(license?.status),
      expirationDate: getLicenseText.expirationDate(license?.end),
    }),
    [license],
  );

  const openDownloadModal = () => {
    openAntdModal('confirm', {
      title: 'Download License',
      content: 'Are you sure to download license file?',
      okText: 'Download',
      onOk: async () => {
        try {
          const { data, fileName } = await mutateAsyncExport();
          saveAs(data, fileName);
          openNotification('success', 'Success', `Succeed to download license file '${fileName}'.`);
        } catch (error) {
          openNotification(
            'error',
            'Error',
            getAxiosErrorMessage(error, 'Failed to download license file!'),
            error as AxiosError,
          );
        }
      },
    });
  };

  const openRegisterModal = () => {
    openModal<FileImportModalProps>(MODAL_NAME.SYSTEM_CONFIG.LICENSE.FILE_IMPORT, FileImportModal, {
      title: 'Register License',
      okText: 'Register',
      url: API_URL.POST_SYSTEM_CONFIG_LICENSE_IMPORT,
      afterError: (error: AxiosError) => {
        openNotification(
          'error',
          'Error',
          getAxiosErrorMessage(error, 'Failed to register license file!'),
          error as AxiosError,
        );
      },
      afterSuccess: () => {
        openNotification(
          'success',
          'Success',
          'Succeed to register license file.  After logging out, please log in again.',
        );
      },
      afterSettled: () => {
        queryClient.invalidateQueries([QUERY_KEY.SYSTEM_CONFIG_LICENSE]);
      },
      mutationKey: [MUTATION_KEY.SYSTEM_CONFIG_LICENSE_IMPORT],
    });
  };

  return {
    licenseData,
    isFetchingLicense,
    openDownloadModal,
    openRegisterModal,
  };
}

const getLicenseText = {
  path: (path?: string) => (path ? path : 'Unknown'),
  status: (status?: LicenseStatusType) =>
    ({
      activated: 'Activated',
      expired: 'Expired',
      notRegistered: 'Not Registered',
    }[status as string] ?? 'Unknown'),
  expirationDate: (end?: string) => (end ? end : 'Unknown'),
};

function getAxiosErrorMessage(error: any, defaultMessage: string) {
  if (error instanceof AxiosError && error.response?.data?.message) {
    return error.response.data.message;
  }

  return defaultMessage;
}
