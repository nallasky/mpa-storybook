import { ApiOutlined } from '@ant-design/icons';
import FormTag from '@components/common/atoms/CustomForm/FormTag';
import { css } from '@emotion/react';
import { regExpFilePath, regExpIpAddress } from '@libs/util/validation';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { SystemConfigFtpSummary } from '@typesdef/systemConfig';
import { Badge, Button, Form, Input, InputNumber, Modal, Select, Space, Spin } from 'antd';
import type { Rule } from 'antd/es/form';
import useSystemConfigFtpModal from '../hooks/useSystemConfigFtpModal';

export const defaultRootPath = {
  recall: '/home/rssuser/log',
  logServer: '/home/rssuser/demss_tool_work/tmp_logVFTP',
};

export interface SystemConfigFtpModalProps {
  id?: number;
  mode: 'view' | 'add' | 'edit';
  ftpList: SystemConfigFtpSummary[];
}

export default function SystemConfigFtpModal({
  id,
  onClose,
  visible,
  mode,
  ftpList,
}: GlobalModalDefaultProps<SystemConfigFtpModalProps>) {
  const {
    form,
    logServerTags,
    setLogServerTags,
    onTestRecall,
    onTestLogServer,
    recallTestBadgeProps,
    logServerTestBadgeStatus,
    isRequestingServer,
    isSubmitting,
    isFetchingFtp,
    watchLogServerRoot,
    watchRecallRoot,
    onOk,
    validateName,
  } = useSystemConfigFtpModal({ id, onClose, visible, mode, ftpList });
  const modeText = mode.charAt(0).toUpperCase() + mode.slice(1);
  const isViewMode = mode === 'view';
  const isViewPlaceholder = !isViewMode && !isFetchingFtp;
  const hasRootPath = watchLogServerRoot || watchRecallRoot;

  return (
    <Modal
      title={
        <Space>
          <div>{`${modeText} FTP/SFTP Server`}</div>
          {isFetchingFtp && <Spin size="small" />}
        </Space>
      }
      open={visible}
      width="600px"
      onCancel={onClose}
      destroyOnClose
      footer={[
        <span
          css={css`
            margin-right: 1rem;
            color: red;
          `}
          key="error"
        >
          {!hasRootPath && 'At least one of Recall Root and Log Server Root must be input.'}
        </span>,
        <Button key="cancel" disabled={isRequestingServer} hidden={isViewMode} onClick={onClose}>
          Cancel
        </Button>,
        <Button key="submit" type="primary" onClick={onOk} loading={isSubmitting} disabled={isRequestingServer}>
          {isViewMode ? 'Close' : modeText}
        </Button>,
      ]}
    >
      <div
        css={css`
          height: 37rem;
          overflow-y: auto;
          padding-left: 1rem;
          padding-right: 1rem;
        `}
      >
        <Form disabled={isRequestingServer} form={form} labelCol={{ span: 8 }} wrapperCol={{ span: 18 }} css={css``}>
          <Form.Item name="id" hidden>
            <Input />
          </Form.Item>
          <Form.Item
            name="name"
            label="Name"
            required
            rules={[
              {
                required: true,
                validator: validateName,
              },
            ]}
          >
            <Input
              placeholder={isViewPlaceholder ? 'Please input a name!' : undefined}
              maxLength={30}
              disabled={isViewMode}
            />
          </Form.Item>
          <Form.Item name="type" label="Type" required rules={[ruleInput('ftp type')]}>
            <Select placeholder={isViewPlaceholder ? 'Please select a type!' : undefined} disabled={isViewMode}>
              <Select.Option value="FTP">FTP</Select.Option>
              <Select.Option value="SFTP">SFTP</Select.Option>
            </Select>
          </Form.Item>
          <Form.Item
            name="remoteHost"
            label="Remote Host"
            required
            rules={[
              ruleInput('remote host'),
              {
                message: `The remote host must be in the form of xxx.xxx.xxx.xxx!`,
                pattern: regExpIpAddress(),
              },
            ]}
          >
            <Input placeholder={isViewPlaceholder ? 'Please input a remote host!' : undefined} disabled={isViewMode} />
          </Form.Item>
          <Form.Item name="port" label="Port" required rules={[ruleInputNumber('port')]}>
            <InputNumber
              placeholder={isViewPlaceholder ? 'Please input a port!' : undefined}
              css={css`
                width: 100%;
              `}
              min={1}
              max={65535}
              disabled={isViewMode}
            />
          </Form.Item>
          <Form.Item name="username" label="Username" required rules={[ruleInput('username')]}>
            <Input placeholder={isViewPlaceholder ? 'Please input a username!' : undefined} disabled={isViewMode} />
          </Form.Item>
          <Form.Item name="password" label="Password" required rules={[ruleInput('password')]}>
            <Input.Password
              placeholder={isViewPlaceholder ? 'Please input a password!' : undefined}
              disabled={isViewMode}
              visibilityToggle={!isViewMode}
            />
          </Form.Item>
          <Form.Item
            name="recallRoot"
            label="Recall Root"
            rules={[
              {
                pattern: regExpFilePath,
                message: 'Please follow the directory rules.',
              },
            ]}
            extra={
              <Space
                css={css`
                  margin-top: 0.25rem;
                  margin-bottom: 0.25rem;
                `}
              >
                <Button
                  icon={<ApiOutlined />}
                  size="small"
                  type="dashed"
                  onClick={() => {
                    onTestRecall();
                  }}
                  disabled={!watchRecallRoot}
                >
                  Test Connection
                </Button>
                <Badge {...recallTestBadgeProps} />
              </Space>
            }
          >
            <Input
              placeholder={isViewPlaceholder ? `e.g. ${defaultRootPath.recall}` : undefined}
              disabled={isViewMode}
            />
          </Form.Item>

          <Form.Item
            name="logServerRoot"
            label="Log Server Root"
            rules={[
              {
                pattern: regExpFilePath,
                message: 'Please follow the directory rules.',
              },
            ]}
            extra={
              <Space
                css={css`
                  margin-top: 0.25rem;
                  margin-bottom: 0.25rem;
                `}
              >
                <Button
                  icon={<ApiOutlined />}
                  size="small"
                  type="dashed"
                  onClick={() => onTestLogServer()}
                  disabled={!watchLogServerRoot}
                >
                  Test Connection
                </Button>
                <Badge {...logServerTestBadgeStatus} />
              </Space>
            }
          >
            <Input
              placeholder={isViewPlaceholder ? `e.g. ${defaultRootPath.logServer}` : undefined}
              disabled={isViewMode}
            />
          </Form.Item>
          <FormTag
            label="Log Server Root Tags"
            name="logServerTags"
            tag={logServerTags}
            setTag={setLogServerTags}
            addText="Add Tag"
            rules={[
              {
                validator: async (rule, value, callback) => {
                  if (watchLogServerRoot) {
                    if (value === undefined || (Array.isArray(value) && value.length === 0))
                      throw new Error('Please input log server root tags!');
                  }
                },
              },
            ]}
            disabled={isRequestingServer || isViewMode}
            cssStyle={css`
              .ant-form-item-control-input {
                margin-top: ${logServerTags.length > 0 && '0.25rem'};
              }
            `}
          />
        </Form>
      </div>
    </Modal>
  );
}

const placeHolder = (action: 'input' | 'select', name: string, isFetching = false): string =>
  isFetching ? '' : `Please ${action} a ${name}.`;

const ruleInput = (name: string): Rule => ({
  required: true,
  message: `Please input a ${name}!`,
  whitespace: true,
  type: 'string',
});

const ruleInputNumber = (name: string): Rule => ({
  required: true,
  message: `Please input a ${name}!`,
  type: 'number',
});
