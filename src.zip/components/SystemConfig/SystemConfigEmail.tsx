import { LoadingOutlined, MailOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import AddressSelect from '@components/common/atoms/AddressSelect';
import AntdButton from '@components/common/atoms/AntdButton';
import { css } from '@emotion/react';
import { hoverStyle } from '@styles/emotion/common';
import { Badge, Input, Spin, Tooltip, Typography } from 'antd';
import useSystemConfigEmail from './hooks/useSystemConfigEmail';

export default function SystemConfigEmail() {
  const {
    disabled,
    isFetching,
    recipients,
    setEachRecipients,
    password,
    onChangePassword,
    inputSummary,
    inputCras,
    inputVersion,
    inputNotice,
    onChangeInput,
    openSaveModal,
  } = useSystemConfigEmail();

  return (
    <div css={style}>
      <div className="save">
        <div className="title">
          <MailOutlined width={'20px'} />
          <Typography.Title level={4}>Default Email</Typography.Title>
          {isFetching && <Spin indicator={<LoadingOutlined spin />} />}
        </div>
        <AntdButton disabled={disabled} onClick={openSaveModal}>
          Save
        </AntdButton>
      </div>
      <div className="def-recipients">
        <div className="title">
          <Badge color="blue" />
          <div>Default Recipients</div>
        </div>
        <div className="value">
          <AddressSelect
            recipients={recipients}
            setEachRecipients={setEachRecipients}
            placeholder={'Input a default email address.'}
            disabled={disabled}
          />
        </div>
      </div>
      <div className="def-password">
        <div className="title">
          <Badge color="blue" />
          <div>Default Password</div>
        </div>
        <div className="value">
          <Input.Password
            placeholder="input a default password."
            value={password}
            onChange={onChangePassword}
            disabled={disabled}
          />
        </div>
      </div>
      <div className="def-subject">
        <div className="title">
          <Badge color="blue" />
          <div>Default Subject</div>
          <Tooltip
            placement="right"
            title={
              <div>
                <div>[Subject Variable]</div>
                <br />
                <div>{'${date} : Email sending time'}</div>
                <div>{'${userfabname} : User-Fab Name'}</div>
                <div>{'${jobname} : Job name'}</div>
              </div>
            }
          >
            <QuestionCircleOutlined />
          </Tooltip>
        </div>
        <div className="value">
          <div className="sub-title">
            <Badge color="green" />
            <div>Error Summary</div>
          </div>
          <div className="sub-value">
            <Input
              placeholder="input a default subject of error summary."
              value={inputSummary}
              onChange={({ target: { value } }) =>
                onChangeInput({
                  type: 'summary',
                  value,
                })
              }
              disabled={disabled}
            />
          </div>
        </div>
        <div className="value">
          <div className="sub-title">
            <Badge color="green" />
            <div>Cras Data</div>
          </div>
          <div className="sub-value">
            <Input
              placeholder="input a default subject of cras data."
              value={inputCras}
              onChange={({ target: { value } }) =>
                onChangeInput({
                  type: 'cras',
                  value,
                })
              }
              disabled={disabled}
            />
          </div>
        </div>
        <div className="value">
          <div className="sub-title">
            <Badge color="green" />
            <div>MPA Version</div>
          </div>
          <div className="sub-value">
            <Input
              placeholder="input a default subject of mpa version."
              value={inputVersion}
              onChange={({ target: { value } }) =>
                onChangeInput({
                  type: 'version',
                  value,
                })
              }
              disabled={disabled}
            />
          </div>
        </div>
        <div className="value">
          <div className="sub-title">
            <Badge color="green" />
            <div>Error Notice</div>
          </div>
          <div className="sub-value">
            <Input
              placeholder="input a default subject of error notice."
              value={inputNotice}
              onChange={({ target: { value } }) =>
                onChangeInput({
                  type: 'notice',
                  value,
                })
              }
              disabled={disabled}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

const style = css`
  display: flex;
  flex-direction: column;

  .save {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1rem;
    .title {
      display: flex;
      align-items: center;
      .anticon {
        font-size: 1.3rem;
        margin-right: 0.5rem;
      }
      .ant-typography {
        margin-bottom: 0;
      }
      .ant-spin {
        margin-left: 0.5rem;
      }
    }
  }

  .def-recipients {
    display: flex;
    .title {
      display: flex;
      margin-top: 0.5rem;
      width: 15rem;
    }
    margin-bottom: 2rem;
  }

  .def-password {
    display: flex;
    .title {
      display: flex;
      margin-top: 0.5rem;
      width: 15rem;
    }
    .value {
      width: 46rem;
    }
    margin-bottom: 2rem;
  }
  .def-subject {
    display: flex;
    flex-direction: column;
    .title {
      display: flex;
      align-items: center;
      width: 15rem;
      .anticon {
        margin-left: 0.5rem;
        ${hoverStyle}
      }
    }
    .value {
      display: flex;
      margin-top: 1rem;
      .sub-title {
        padding-left: 2rem;
        display: flex;
        align-items: center;
        width: 15rem;
      }
      .sub-value {
        width: 46rem;
      }
    }
  }
`;
