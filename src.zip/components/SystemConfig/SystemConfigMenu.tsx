import { AuditOutlined, FieldTimeOutlined, FileProtectOutlined, MailOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { hasValidLicense } from '@libs/util/auth';
import { loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import type { TypeSystemConfigMenu } from '@typesdef/systemConfig';
import { Menu, MenuProps } from 'antd';
import { Dispatch, useMemo } from 'react';

interface SystemConfigMenuProps {
  curMenu: string | null;
  setCurMenu: Dispatch<React.SetStateAction<TypeSystemConfigMenu | null>>;
}

export default function SystemConfigMenu({ curMenu, setCurMenu }: SystemConfigMenuProps) {
  const { licenseStatus } = useTypedSelector(loginUserSelector);

  const menuItems: MenuItem[] = useMemo(() => {
    const menus: MenuItem[] = [];
    const validLicense = hasValidLicense(licenseStatus);

    Object.entries(menuMap).forEach(([key, value]) => {
      if (key === 'license') {
        menus.push(value);
      }

      if (key !== 'license' && validLicense) {
        menus.push(value);
      }
    });

    return menus;
  }, [licenseStatus]);

  return (
    <Menu
      items={menuItems}
      selectedKeys={curMenu ? [curMenu] : []}
      onClick={(value) => setCurMenu(value.key as TypeSystemConfigMenu)}
      mode="inline"
      css={style}
    />
  );
}

const style = css`
  width: 220px;
  height: 51.25rem;
  overflow-x: hidden;
  overflow-y: auto;
`;

type MenuItem = Required<MenuProps>['items'][number];

function getItem(
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[],
  type?: 'group',
): MenuItem {
  return {
    key,
    icon,
    children,
    label,
    type,
  } as MenuItem;
}

const menuMap = {
  email: getItem('Default Email', 'email', <MailOutlined />),
  ftp: getItem('FTP/SFTP', 'ftp', <FileProtectOutlined />),
  license: getItem('License', 'license', <AuditOutlined />),
  retention: getItem('Data Retention', 'retention', <FieldTimeOutlined />),
};
