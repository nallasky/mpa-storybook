import { H_SPACE } from '@components/common/atoms/Space';
import { css } from '@emotion/react';
import type { TypeSystemConfigMenu } from '@typesdef/systemConfig';
import { useState } from 'react';
import SystemConfigEmail from './SystemConfigEmail';
import SystemConfigFtp from './SystemConfigFtp';
import { SystemConfigLicense } from './SystemConfigLicense';
import SystemConfigMenu from './SystemConfigMenu';
import { SystemConfigRetention } from './SystemConfigRetention';

export default function SystemConfig() {
  const [curMenu, setCurMenu] = useState<TypeSystemConfigMenu | null>(null);

  return (
    <div css={style}>
      <SystemConfigMenu curMenu={curMenu} setCurMenu={setCurMenu} />
      <H_SPACE />
      <div className="content">{viewComponent(curMenu)}</div>
    </div>
  );
}

const viewComponent = (curMenu: TypeSystemConfigMenu | null) =>
  ({
    email: <SystemConfigEmail />,
    ftp: <SystemConfigFtp />,
    license: <SystemConfigLicense />,
    retention: <SystemConfigRetention />,
  }[curMenu as string] ?? <div></div>);

const style = css`
  display: flex;
  .content {
    width: 70.25rem;
    margin-top: 0.5rem;
  }
`;
