export { default } from './VersionInfo';
