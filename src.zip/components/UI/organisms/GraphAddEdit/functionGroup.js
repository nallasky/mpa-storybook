export const compareErrorCheck = (min, max) => {
  if (min.toString().length === 0 && max.toString().length === 0) return false;
  const parseMin =
    typeof min === 'number'
      ? min
      : min.indexOf('.') !== -1
      ? parseFloat(min)
      : parseInt(min);
  const parseMax =
    typeof max === 'number'
      ? max
      : max.indexOf('.') !== -1
      ? parseFloat(max)
      : parseInt(max);

  return isNaN(parseMin) || isNaN(parseMax) ? true : parseMax <= parseMin;
};
