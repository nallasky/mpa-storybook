import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { Empty } from 'antd';
import ReactTable from '../../../UI/atoms/Table/ReactTable';
import HeaderSetting from './HeaderSetting';
import * as fn from './functionGroup';
import * as sg from './styleGroup';

const AnalysisTable = ({
  period,
  filter,
  aggregation,
  tableOrder,
  tableData,
  type,
  onLoad,
  useUpdate,
}) => {
  const columnData = useMemo(() => fn.createColumns(tableOrder), [
    JSON.stringify(tableOrder),
  ]);
  const rowData = useMemo(() => {
    return type === 'analysis' || useUpdate
      ? fn.createDataSource(tableData)
      : fn.filteringData(
          fn.createDataSource(tableData),
          fn.initFilterValue(filter),
        );
  }, [JSON.stringify(tableData), JSON.stringify(filter)]);

  return (
    <div css={sg.mainWrapper}>
      {filter !== undefined &&
      filter.length === 0 &&
      aggregation !== undefined &&
      Object.keys(aggregation).length === 0 &&
      period.start === null &&
      period.end === null &&
      period.select.length === 0 ? (
        ''
      ) : (
        <HeaderSetting
          period={period}
          filter={filter}
          aggregation={aggregation}
          type={type}
          loadingSet={onLoad}
          useUpdate={useUpdate}
        />
      )}
      {rowData?.length > 0 && columnData?.length > 0 ? (
        <div className="table-wrapper">
          <div>{type === 'analysis' ? 'Analysis Result' : 'Original Data'}</div>
          <div>
            <ReactTable
              columns={columnData}
              data={rowData}
              disableSelectRows={type !== 'analysis'}
            />
          </div>
        </div>
      ) : (
        <div css={sg.emptyWrapper}>
          <Empty />
        </div>
      )}
    </div>
  );
};

AnalysisTable.displayName = 'AnalysisTable';
AnalysisTable.propTypes = {
  period: PropTypes.object.isRequired,
  filter: PropTypes.array.isRequired,
  aggregation: PropTypes.object,
  tableOrder: PropTypes.array.isRequired,
  tableData: PropTypes.object.isRequired,
  type: PropTypes.string.isRequired,
  onLoad: PropTypes.func,
  useUpdate: PropTypes.bool.isRequired,
};

export default AnalysisTable;
