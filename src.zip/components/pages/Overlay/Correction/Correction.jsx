import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { css, keyframes } from '@emotion/react';
import {
  Select,
  Upload,
  DatePicker,
  Input,
  Switch,
  Button,
  InputNumber,
  Radio,
} from 'antd';
import {
  //InboxOutlined,
  PlayCircleOutlined,
  TableOutlined,
  CloudDownloadOutlined,
  DownOutlined,
  UploadOutlined,
} from '@ant-design/icons';

const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 0.4fr 0.6fr;
  gap: 1rem;
  width: 100%;
  padding: 1rem;
`;

const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 400px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  &.stretch {
    align-self: stretch;
  }
  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 2rem;
    grid-column: 1 / span 2;
  }
`;

const componentTitleStyle = css`
  font-size: 24px;
  color: #1890ff;
`;

const contentWrapperStyle = css`
  position: relative;
  margin-top: 3rem;
  &.mg-bottom {
    margin-bottom: 13px;
  }
`;

const contentStyle = css`
  margin: 0 auto;
  width: 60%;
  &.full-width {
    width: 100%;
  }
  & > div + div {
    margin-top: 2rem;
  }
`;

const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column-2 {
    grid-template-columns: 0.4fr 1fr;
  }
  &.column-3 {
    grid-template-columns: 0.4fr 1fr 1fr;
  }
  &.etc {
    display: flex;
    justify-content: space-between;
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      &.label::before {
        display: inline-block;
        color: red;
        font-size: 16px;
        content: '*';
        margin-right: 0.3rem;
      }
    }
    &.switch-wrapper {
      text-align: center;
    }
  }
  &.upload {
    & > span {
      &:first-of-type {
        align-self: start;
      }
      &:last-of-type {
        width: 100%;
      }
    }
    & .full-width {
      & > .ant-upload-select-text,
      & button {
        width: 100%;
      }
    }
  }
  & > .title {
    width: 100%;
    text-align: center;
    font-size: 20px;
  }
  & > .preset-setting {
    display: flex;
    column-gap: 1rem;
  }
  & .radio-cp-vs {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    column-gap: 1rem;
    grid-column: span 2;
  }
  & .margin-lr {
    margin: 0 1rem;
  }
  & .margin-r {
    margin-right: 1rem;
  }
  & .tx-right {
    text-align: right;
  }
  & ~ div {
    margin-top: 2rem;
    &.table-wrapper {
      margin-top: 1rem;
    }
  }
`;

const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: #1890ff;
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: -5px;
    right: 10px;
    & > span:first-of-type {
      color: #52c41a;
    }
  }
`;

const controlStyle = css`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
`;

const radioGroupStyle = css`
  & > label {
    display: inline-block;
    & + label {
      margin-left: 1rem;
    }
    & > input[type='radio'] {
      display: none;
      &:checked {
        & + .button {
          background-color: #f5f5f5;
          &::after {
            opacity: 1;
          }
        }
      }
    }
    & > .button {
      position: relative;
      z-index: 1;
      padding: 0.5rem 1rem;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease-in-out;
      &::after {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        content: '';
        opacity: 0;
        border-radius: 8px;
        box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
        transition: opacity 0.3s ease-in-out;
      }
      & svg {
        margin-right: 0.3rem;
      }
    }
  }
`;

const settingStyle = css`
  position: relative;
  padding-bottom: 1rem;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  & > .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1rem;
    & > span {
      font-size: 18px;
    }
    & > div > button + button {
      margin-left: 1rem;
    }
  }
  & > .main {
    & > div + div {
      margin-top: 0.1rem;
    }
  }
`;

const antdButtonStyle = css`
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: white;
    border: 1px dashed #d9d9d9;
  }
  &.blue {
    color: white;
    background-color: #1890ff;
    border: 1px solid #1890ff;
  }
`;

const settingContentStyle = css`
  position: relative;
  margin: 0 auto;
  width: 60%;
  &.etc {
    width: 40%;
  }
  &.full-width {
    width: 100%;
  }
  &.correction-cp-vs {
    width: 70%;
  }
  & .table-wrapper ~ div {
    margin-top: 1rem;
  }
`;

const resultStyle = css`
  position: relative;
  min-height: 300px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  padding: 1rem;
`;

const tableStyle = css`
  margin: 0 auto;
  border: 1px solid #d9d9d9;
  border-collapse: collapse;
  table-layout: auto;
  text-align: center;
  & th,
  td {
    border: 1px solid #d9d9d9;
    padding: 0.5rem;
  }
  & th {
    background-color: #fafafa;
  }
`;

const bounce = keyframes`
  50% {
    transform: scale(1.2);
  }
  75% {
    transform: scale(.9);
  }
  100% {
    transform: scale(1);
  }
`;

const controlTableStyle = css`
  margin: 0 auto;
  border-top: 1px solid #d9d9d9;
  table-layout: auto;
  border-collapse: collapse;
  & input[type='checkbox'] {
    display: none;
  }
  & label.only-checkbox {
    cursor: pointer;
    text-align: center;
    & > input[type='checkbox'] {
      &:checked ~ .mode-slider-wrapper > .slider {
        transform: translateY(-17px);
      }
    }
    & > .mode-slider-wrapper {
      overflow: hidden;
      height: 17px;
      font-weight: normal;
      text-transform: uppercase;
      & > .slider {
        display: flex;
        flex-direction: column;
        align-items: center;
        transition: transform 0.3s ease-in-out;
        row-gap: 2px;
        & > div {
          font-size: 10px;
          border-radius: 4px;
          width: fit-content;
          padding: 0 0.2rem;
          color: white;
          &:first-of-type {
            background-color: red;
          }
          &:last-of-type {
            background-color: #1890ff;
          }
        }
      }
    }
  }
  & svg {
    display: block;
    pointer-events: none;
    fill: none;
    stroke-width: 2px;
    stroke-linecap: round;
    stroke-linejoin: round;
    stroke: #1890ff;
    position: absolute;
    transform: scale(0) translateZ(0);
  }
  & th {
    position: relative;
    padding: 0.5rem;
    border-bottom: 1px solid #d9d9d9;
    background-color: #f0f5ff;
    text-transform: uppercase;
    font-size: 12px;
    line-height: initial;
    & svg {
      top: 10px !important;
      left: 40px !important;
      width: 24px !important;
      height: 24px !important;
    }
  }
  & td {
    position: relative;
    border: none;
    border-bottom: 1px solid #d9d9d9;
    font-size: 12px;
    color: rgba(0, 0, 0, 0.8);
    line-height: initial;
    & > .text-checkbox {
      position: relative;
      & > input[type='text'] {
        font-family: Saira, sans-serif;
        border: none;
        outline: none !important;
        font-size: 12px;
        max-width: 125px;
        padding: 0.7rem 2rem 0.7rem 0.7rem;
        transition: background-color 0.3s ease-in-out;
        &:read-only {
          background-color: #f5f5f5;
        }
      }
      & > label {
        cursor: pointer;
        & > input[type='checkbox'] {
          &:checked ~ {
            & .svg-wrapper > svg {
              animation: ${bounce} 0.4s linear forwards;
            }
          }
        }
        & > .svg-wrapper {
          position: absolute;
          top: 6px;
          right: 3px;
          width: 24px;
          height: 24px;
          padding: 1px;
          border-radius: 4px;
          border: 1px solid #dadada;
          background-color: white;
        }
      }
    }
  }
`;

const Correction = () => {
  const [resultType, setResultType] = useState('img');
  const [tab, setTab] = useState('measurement');
  const [tmpArray, setTmpArray] = useState([]);

  const createDummyData = () => {
    const tmpBuf = [];

    for (let i = 0; i < 6; i++) {
      const flag = i < 3;
      tmpBuf.push({
        shot: {
          id: i + 1,
          mode: flag ? 'manual' : 'auto',
        },
        cp1: {
          checked: flag,
          value: '-600.000000',
        },
        'cp12`': {
          checked: !flag,
          value: '-450.000000',
        },
        'cp1`': {
          checked: flag,
          value: '-300.000000',
        },
        'cp21`': {
          checked: !flag,
          value: '-150.000000',
        },
        cp2: {
          checked: flag,
          value: '0.000000',
        },
        'cp23`': {
          checked: !flag,
          value: '150.000000',
        },
        'cp3`': {
          checked: flag,
          value: '300.000000',
        },
        'cp32`': {
          checked: !flag,
          value: '450.000000',
        },
        cp3: {
          checked: flag,
          value: '600.000000',
        },
      });
    }

    setTmpArray(tmpBuf);
  };

  useEffect(() => {
    createDummyData();
  }, []);

  return (
    <section css={sectionStyle}>
      <div css={componentStyle} className="stretch">
        <div css={componentTitleStyle}>Select Source</div>
        <div css={contentWrapperStyle}>
          <div css={contentStyle} className="full-width">
            <div css={contentItemStyle} className="column-2">
              <span className="label">From:</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Local</Select.Option>
                <Select.Option value="2">Remote</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="upload column-2">
              <span className="label">Log Files:</span>
              <Upload className="full-width">
                <Button icon={<UploadOutlined />}>Upload zip only</Button>
              </Upload>
            </div>
          </div>
        </div>
      </div>
      <div css={componentStyle}>
        <div css={componentTitleStyle}>Select Target</div>
        <div css={contentWrapperStyle} className="mg-bottom">
          <div css={contentStyle}>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Fab:</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Fab1600</Select.Option>
                <Select.Option value="2">Fab1700</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Equipment:</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Tool1600_1</Select.Option>
                <Select.Option value="2">Tool1700_1</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Period:</span>
              <DatePicker.RangePicker style={{ width: '100%' }} />
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Job:</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Job1</Select.Option>
                <Select.Option value="2">Job2</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Lot ID:</span>
              <Select
                defaultValue="1"
                style={{ width: '100%' }}
                mode="multiple"
              >
                <Select.Option value="1">item 1</Select.Option>
                <Select.Option value="2">item 2</Select.Option>
                <Select.Option value="3">item 3</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Mean Deviation Diff.:</span>
              <Select
                defaultValue="1"
                style={{ width: '100%' }}
                mode="multiple"
              >
                <Select.Option value="1">item 1</Select.Option>
                <Select.Option value="2">item 2</Select.Option>
                <Select.Option value="3">item 3</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">AE Correction:</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Off</Select.Option>
                <Select.Option value="2">On</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Stage Correction:</span>
              <Select
                defaultValue="1"
                style={{ width: '100%' }}
                mode="multiple"
              >
                <Select.Option value="1">item 1</Select.Option>
                <Select.Option value="2">item 2</Select.Option>
                <Select.Option value="3">item 3</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">ADC Correction:</span>
              <Select
                defaultValue="1"
                style={{ width: '100%' }}
                mode="multiple"
              >
                <Select.Option value="1">item 1</Select.Option>
                <Select.Option value="2">item 2</Select.Option>
                <Select.Option value="3">item 3</Select.Option>
              </Select>
            </div>
          </div>
          <div css={customButtonStyle} className="absolute">
            <PlayCircleOutlined />
            <span>Start</span>
          </div>
        </div>
      </div>
      <div css={componentStyle} className="span">
        <div css={controlStyle}>
          <div css={radioGroupStyle}>
            <label htmlFor="img">
              <input
                type="radio"
                name="map-option"
                id="img"
                checked={resultType === 'img'}
                onChange={() => setResultType('img')}
              />
              <div className="button">
                <TableOutlined />
                Correction Image Map
              </div>
            </label>
            <label htmlFor="comp">
              <input
                type="radio"
                name="map-option"
                id="comp"
                checked={resultType === 'comp'}
                onChange={() => setResultType('comp')}
              />
              <div className="button">
                <TableOutlined />
                Correction Component Map
              </div>
            </label>
          </div>
          <div css={customButtonStyle}>
            <CloudDownloadOutlined />
            <span>Download</span>
          </div>
        </div>
        <div css={settingStyle}>
          <div className="header">
            <span>Map Setting</span>
            <div>
              <button css={antdButtonStyle} className="blue">
                Apply
              </button>
            </div>
          </div>
          <div className="main">
            <CorrectionSettingAccordion title="Offset X/Y" defaultValue={false}>
              <div css={settingContentStyle}>
                <div className="content">
                  <div css={contentItemStyle} className="column-3">
                    <span className="switch-wrapper">
                      <Switch
                        checkedChildren="Auto"
                        unCheckedChildren="Manual"
                        defaultChecked
                      />
                    </span>
                    <span className="title">Offset X</span>
                    <span className="title">Offset Y</span>
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 1:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 2:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 3:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 4:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 5:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 6:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                </div>
              </div>
            </CorrectionSettingAccordion>
            <CorrectionSettingAccordion title="CP / VS">
              <div css={settingContentStyle} className="full-width">
                <div className="content">
                  <div>
                    <div css={radioGroupStyle}>
                      <label htmlFor="measurement" className="cp-vs">
                        <input
                          type="radio"
                          name="cp-vs-option"
                          id="measurement"
                          checked={tab === 'measurement'}
                          onChange={() => setTab('measurement')}
                        />
                        <div className="button cp-vs">ADC Measurement</div>
                      </label>
                      <label htmlFor="comp-exposure" className="cp-vs">
                        <input
                          type="radio"
                          name="cp-vs-option"
                          id="comp-exposure"
                          checked={tab === 'comp-exposure'}
                          onChange={() => setTab('comp-exposure')}
                        />
                        <div className="button cp-vs">
                          Correction component of exposure
                        </div>
                      </label>
                    </div>
                  </div>
                  <div
                    css={settingContentStyle}
                    className={
                      'tab ' + (tab === 'measurement' ? '' : 'correction-cp-vs')
                    }
                  >
                    {tab === 'measurement' ? (
                      <>
                        <div css={contentItemStyle} className="column-3">
                          <span className="label">Preset:</span>
                          <Select defaultValue="1" style={{ width: '100%' }}>
                            <Select.Option value="1">Job1</Select.Option>
                            <Select.Option value="2">Job2</Select.Option>
                          </Select>
                          <div className="preset-setting">
                            <Input placeholder="Enter preset name." />
                            <button css={antdButtonStyle} className="blue">
                              Save Preset
                            </button>
                          </div>
                        </div>
                        <div css={contentItemStyle} className="column-3">
                          <span className="label">CP/VS:</span>
                          <Radio.Group value="1" className="radio-cp-vs">
                            <Radio value="1">Set CP/VS for each shot</Radio>
                            <Radio value="2">
                              Reflect the CP/VS of shot1 on all shots
                            </Radio>
                          </Radio.Group>
                        </div>
                        <div className="table-wrapper">
                          <table css={tableStyle}>
                            <thead>
                              <tr>
                                <th>SHOT</th>
                                <th>CP1</th>
                                <th>CP2</th>
                                <th>CP3</th>
                                <th>VS1</th>
                                <th>VS2</th>
                                <th>VS3</th>
                                <th>DISPLAY</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>01</td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Select
                                    defaultValue="1"
                                    style={{ width: '100%' }}
                                  >
                                    <Select.Option value="1">
                                      Job1
                                    </Select.Option>
                                    <Select.Option value="2">
                                      Job2
                                    </Select.Option>
                                  </Select>
                                </td>
                              </tr>
                              <tr>
                                <td>02</td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Select
                                    defaultValue="1"
                                    style={{ width: '100%' }}
                                  >
                                    <Select.Option value="1">
                                      Job1
                                    </Select.Option>
                                    <Select.Option value="2">
                                      Job2
                                    </Select.Option>
                                  </Select>
                                </td>
                              </tr>
                              <tr>
                                <td>03</td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Select
                                    defaultValue="1"
                                    style={{ width: '100%' }}
                                  >
                                    <Select.Option value="1">
                                      Job1
                                    </Select.Option>
                                    <Select.Option value="2">
                                      Job2
                                    </Select.Option>
                                  </Select>
                                </td>
                              </tr>
                              <tr>
                                <td>04</td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Input type="text" />
                                </td>
                                <td>
                                  <Select
                                    defaultValue="1"
                                    style={{ width: '100%' }}
                                  >
                                    <Select.Option value="1">
                                      Job1
                                    </Select.Option>
                                    <Select.Option value="2">
                                      Job2
                                    </Select.Option>
                                  </Select>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                        <div css={contentItemStyle} className="column-3">
                          <span className="label">Job data file:</span>
                          <Upload>
                            <Button icon={<UploadOutlined />}>Load</Button>
                          </Upload>
                        </div>
                      </>
                    ) : (
                      <div>
                        {tmpArray.length > 0 ? (
                          <>
                            <div css={contentItemStyle} className="column-3">
                              <span className="label">Preset:</span>
                              <Select
                                defaultValue="1"
                                style={{ width: '100%' }}
                              >
                                <Select.Option value="1">Job1</Select.Option>
                                <Select.Option value="2">Job2</Select.Option>
                              </Select>
                              <div className="preset-setting">
                                <Input placeholder="Enter preset name." />
                                <button css={antdButtonStyle} className="blue">
                                  Save Preset
                                </button>
                              </div>
                            </div>
                            <div css={contentItemStyle} className="column-3">
                              <span className="label">CP/VS:</span>
                              <Radio.Group value="1" className="radio-cp-vs">
                                <Radio value="1">Set CP/VS for each shot</Radio>
                                <Radio value="2">
                                  Reflect the CP/VS of shot1 on all shots
                                </Radio>
                              </Radio.Group>
                            </div>
                            <div className="table-wrapper">
                              <table css={controlTableStyle}>
                                <thead>
                                  <tr>
                                    {Object.keys(tmpArray[0]).map((v, i) => {
                                      return (
                                        <th key={i}>
                                          {v === 'shot' ? (
                                            v
                                          ) : (
                                            <CustomTextCheckBox
                                              id={`header_${v}`}
                                              label={v}
                                            />
                                          )}
                                        </th>
                                      );
                                    })}
                                  </tr>
                                </thead>
                                <tbody>
                                  {tmpArray.map((v, idx) => {
                                    return (
                                      <tr key={idx}>
                                        {Object.keys(v).map((x, i) => {
                                          return (
                                            <td key={i}>
                                              <CustomTextCheckBox
                                                id={`${idx}_${i}`}
                                                isChecked={
                                                  x === 'shot'
                                                    ? v[x].mode === 'auto'
                                                    : v[x].checked
                                                }
                                                label={
                                                  x === 'shot'
                                                    ? v[x].id
                                                    : undefined
                                                }
                                                useText={x !== 'shot'}
                                                value={
                                                  x !== 'shot'
                                                    ? v[x].value
                                                    : undefined
                                                }
                                                onText="auto"
                                                offText="manual"
                                              />
                                            </td>
                                          );
                                        })}
                                      </tr>
                                    );
                                  })}
                                </tbody>
                              </table>
                            </div>
                          </>
                        ) : (
                          ''
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </CorrectionSettingAccordion>
            <CorrectionSettingAccordion title="Etc.">
              <div css={settingContentStyle} className="etc">
                <div className="content">
                  <div css={contentItemStyle} className="etc">
                    <span className="label">Display Map</span>
                    <div>
                      <InputNumber />
                      <span className="margin-lr">~</span>
                      <InputNumber />
                    </div>
                  </div>
                  <div css={contentItemStyle} className="etc">
                    <span className="label">Number of Columns to Display:</span>
                    <InputNumber />
                  </div>
                  <div css={contentItemStyle} className="etc">
                    <span className="label">Div:</span>
                    <div className="tx-right">
                      <span className="margin-r">Upper Row</span>
                      <Input style={{ width: '40%' }} />
                    </div>
                  </div>
                  <div css={contentItemStyle} className="etc">
                    <span className="label">Plate Size:</span>
                    <div className="tx-right">
                      <span className="margin-r">Size_X</span>
                      <Input style={{ width: '30%' }} />
                      <span className="margin-lr">Size_Y</span>
                      <Input style={{ width: '30%' }} />
                    </div>
                  </div>
                </div>
              </div>
            </CorrectionSettingAccordion>
          </div>
        </div>
        <div css={resultStyle}>result</div>
      </div>
    </section>
  );
};

const accordionStyle = css`
  position: relative;
  width: 100%;
  & > div {
    width: 100%;
    &:first-of-type {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem;
      background-color: #f5f5f5;
      cursor: pointer;
      & > .title {
        font-size: 18px;
      }
      & svg {
        transition: all 0.5s;
      }
    }
    &:last-of-type {
      max-height: 800px;
      transition: all 0.7s;
      overflow: hidden;
      & > .contents {
        padding: 1rem;
      }
    }
  }
  &.collapsed {
    & > div {
      &:first-of-type {
        & svg {
          transform: rotate(180deg);
        }
      }
      &:last-of-type {
        max-height: 0;
      }
    }
  }
`;

const CorrectionSettingAccordion = ({ title, children, defaultValue }) => {
  const [isCollapsed, setIsCollapsed] = useState(defaultValue);

  return (
    <div css={accordionStyle} className={isCollapsed ? 'collapsed' : ''}>
      <div
        onClick={() => setIsCollapsed(!isCollapsed)}
        onKeyDown={() => setIsCollapsed(!isCollapsed)}
        role="button"
        tabIndex="-1"
      >
        <span className="title">{title}</span>
        <DownOutlined />
      </div>
      <div>
        <div className="contents">{children}</div>
      </div>
    </div>
  );
};
CorrectionSettingAccordion.displayName = 'OverlaySettingAccordion';
CorrectionSettingAccordion.propTypes = {
  title: PropTypes.string,
  children: PropTypes.node.isRequired,
  defaultValue: PropTypes.bool,
};
CorrectionSettingAccordion.defaultProps = {
  defaultValue: true,
};

const CustomTextCheckBox = ({
  value,
  isChecked,
  id,
  useText,
  label,
  onText,
  offText,
}) => {
  const [checked, setChecked] = useState(isChecked);
  const [textVal, setTextVal] = useState(value);

  useEffect(() => {
    if (useText) {
      setTextVal(value);
    }
  }, [value]);

  useEffect(() => {
    setChecked(isChecked);
  }, [isChecked]);

  return !useText ? (
    <label htmlFor={id} className="only-checkbox">
      <input
        type="checkbox"
        id={id}
        checked={checked}
        onChange={() => setChecked(!checked)}
      />
      <div>{label}</div>
      <div className="mode-slider-wrapper">
        <div className="slider">
          <div>{offText}</div>
          <div>{onText}</div>
        </div>
      </div>
    </label>
  ) : (
    <div className="text-checkbox">
      <input
        type="text"
        value={textVal}
        onChange={(e) => setTextVal(e.target.value)}
        readOnly={!checked}
      />
      <label htmlFor={id}>
        <input
          type="checkbox"
          id={id}
          checked={checked}
          onChange={() => setChecked(!checked)}
        />
        <div className="svg-wrapper">
          <svg viewBox="0 1 21 21">
            <polyline points="5 10.75 8.5 14.25 14 7.8" />
          </svg>
        </div>
      </label>
    </div>
  );
};
CustomTextCheckBox.propTypes = {
  value: PropTypes.string,
  isChecked: PropTypes.bool,
  id: PropTypes.string.isRequired,
  useText: PropTypes.bool,
  label: PropTypes.string,
  onText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  offText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
CustomTextCheckBox.defaultProps = {
  value: '',
  isChecked: false,
  useText: false,
  onText: 'on',
  offText: 'off',
};

export default Correction;
