import { convertDataTypeNumber, convertDefTypeCustom } from '@components/Convert/ConvertCommon';
import { css } from '@emotion/react';
import { getPascalCaseName } from '@libs/util/convert';
import { getConvertRuleItem } from '@libs/util/error';
import { TypeColumnDefineTab } from '@typesdef/columnDefine';
import { ConvertRuleItem, ConvertRuleSelectItemKey } from '@typesdef/convertRules';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Input, InputNumber, Modal, Select } from 'antd';
import React from 'react';

import useColumnDefineTableItemAddEdit from '../hooks/useColumnDefineTableItemAddEdit';

export interface ColumnDefineTableItemAddEditProps {
  index?: number;
  data?: ConvertRuleItem;
  type: TypeColumnDefineTab;
  mode: 'edit' | 'add';
  itemList: ConvertRuleSelectItemKey[];
}

export default React.memo(function ColumnDefineTableItemAddEdit({
  visible,
  onClose,
  index,
  data,
  type,
  mode,
  itemList,
}: GlobalModalDefaultProps<ColumnDefineTableItemAddEditProps>): JSX.Element {
  const {
    form,
    onOk,
    onChangeDefType,
    divRef,
    formDefType,
    formDataType,
    formNameValid,
    formOutColValid,
    typeOptions,
    isLoading,
  } = useColumnDefineTableItemAddEdit({
    index,
    data,
    mode,
    type,
    itemList,
    onClose,
  });

  const title = getPascalCaseName([mode, ...type.split('_'), 'define']);

  return (
    <Modal
      title={title}
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width="700px"
      destroyOnClose
      cancelButtonProps={{
        disabled: isLoading,
      }}
      okButtonProps={{
        loading: isLoading,
        disabled: isLoading,
      }}
      maskClosable={!isLoading}
    >
      <div ref={divRef}>
        <Form form={form} labelCol={{ span: 7 }} wrapperCol={{ span: 19 }} css={formStyle} onFinish={onOk}>
          {itemList.includes('name') && (
            <Form.Item
              name="name"
              label="Name"
              className="name"
              required
              help={formNameValid.help}
              validateStatus={formNameValid.status}
              // hasFeedback
            >
              <Input maxLength={50} />
            </Form.Item>
          )}
          {itemList.includes('output_column') && (
            <Form.Item
              label="Output Column"
              name="output_column"
              className="output_column"
              required
              help={formOutColValid.help}
              validateStatus={formOutColValid.status}
              // hasFeedback
            >
              <Input maxLength={50} />
            </Form.Item>
          )}
          {itemList.includes('regex_prefix') && (
            <Form.Item
              name="regex_prefix"
              label="Regex Prefix"
              className="regex_prefix"
              required
              rules={[getConvertRuleItem({ rule: 'empty', type: 'string' })]}
            >
              <Input />
            </Form.Item>
          )}
          {itemList.includes('regex') && (
            <Form.Item
              name="regex"
              label="Regex"
              className="regex"
              required
              rules={[getConvertRuleItem({ rule: 'empty', type: 'string' })]}
            >
              <Input />
            </Form.Item>
          )}
          {itemList.includes('re_group') && (
            <Form.Item name="re_group" label="Group" className="re_group">
              <InputNumber
                css={css`
                  width: 100%;
                `}
                min={0}
                max={999}
                maxLength={999}
                precision={0}
              />
            </Form.Item>
          )}
          {itemList.includes('data_type') && (
            <Form.Item
              label="Data Type"
              name="data_type"
              className="data_type"
              required
              rules={[getConvertRuleItem({ rule: 'emptySelect', type: 'string' })]}
            >
              <Select
                showSearch
                filterOption={(input, option) =>
                  option?.value
                    ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase())
                    : false
                }
                options={typeOptions.dataType}
              />
            </Form.Item>
          )}
          {itemList.includes('def_val') && (
            <Form.Item label="Default Value" className="default_wrapper">
              <Form.Item
                name="def_val"
                className="def_val"
                // rules={[{ required: true, message: 'Please input a default value!' }]}
              >
                <Input disabled={!convertDefTypeCustom.includes(formDefType ?? '')} />
              </Form.Item>
              <Form.Item name="def_type" className="def_type">
                <Select
                  showSearch
                  allowClear
                  filterOption={(input, option) =>
                    option?.value
                      ? (option.children as unknown as string).toLowerCase().includes(input.toLowerCase())
                      : false
                  }
                  onChange={onChangeDefType}
                  options={typeOptions.defType}
                />
              </Form.Item>
            </Form.Item>
          )}
          {itemList.includes('coef') && (
            <Form.Item name="coef" label="Coefficient" className="coef">
              <InputNumber
                css={css`
                  width: 100%;
                `}
                min={-99999999}
                max={99999999}
                maxLength={8}
                disabled={!convertDataTypeNumber.includes(formDataType ?? '')}
              />
            </Form.Item>
          )}
          {itemList.includes('unit') && (
            <Form.Item name="unit" label="Unit" className="unit">
              <Input />
            </Form.Item>
          )}
        </Form>
      </div>
    </Modal>
  );
});

const formStyle = css`
  .def_val,
  .def_type {
    display: inline-block;
    width: 11.05rem;
  }
  .def_type {
    margin-left: 0.9rem;
  }
  .default_wrapper {
    margin-bottom: 0;
  }

  .def_val {
    .ant-form-item-explain-error {
      width: 368px;
    }
  }

  .ant-form-item.ant-form-item-with-help.name,
  .ant-form-item.ant-form-item-with-help.output_column {
    height: 32px;
  }
`;
