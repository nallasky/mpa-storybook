import SearchModal, { SearchModalProps } from '@components/common/atoms/SearchModal/SearchModal';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import useTableSortSearch from '@hooks/useTableSortSearch';
import { useDeleteColumnDefine, useGetColumnDefine } from '@libs/query/columnDefine';
import { openNotification } from '@libs/util/notification';
import { getColDefineRuleOption } from '@reducers/slices/columnDefine';
import useTypedSelector from '@reducers/useTypedSelector';
import { TypeColumnDefineTab } from '@typesdef/columnDefine';
import { ConvertRuleItem, ConvertRuleSelectItemKey } from '@typesdef/convertRules';
import { SearchModalItem } from '@typesdef/search';
import { useState } from 'react';
import { ColumnDefineTableProps } from '../ColumnDefineTable';
import ColumnDefineTableItemAddEdit, { ColumnDefineTableItemAddEditProps } from '../Modal/ColumnDefineTableItemAddEdit';

export default function useColumnDefineTable({ type }: ColumnDefineTableProps) {
  const { data_type } = useTypedSelector(getColDefineRuleOption);
  const [viewMode, setViewMode] = useState<'simple' | 'detail'>('simple');
  const { openModal } = useModals();
  const {
    isRequesting,
    pagination,
    searchParam,
    hasSearchParam,
    setPagination,
    setSearchParam,
    setRequesting,
    onChangeTable,
  } = useTableSortSearch();

  const { data, isFetching, refetch } = useGetColumnDefine(
    {
      paths: {
        type,
      },
      pagination: {
        size: pagination.pageSize,
        page: pagination.current - 1,
        sort: pagination.sort,
      },
      search: searchParam,
    },
    {
      onSuccess: (data) => {
        setPagination({
          total: data.totalElements,
        });
      },
      onError: () => {
        openNotification('error', 'Error', `Failed to get list of column define for ${type}!`);
      },
      onSettled: () => {
        setRequesting(false);
      },
      keepPreviousData: true,
    },
  );

  const { mutateAsync: mutateAsyncDelete } = useDeleteColumnDefine({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to delete ${type} define!`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete ${type} define!`);
    },
  });

  const onChangeViewMode = (value: string) => {
    setViewMode(value as 'simple' | 'detail');
  };

  const onAdd = () => {
    openModal<ColumnDefineTableItemAddEditProps>(MODAL_NAME.COLUMN_DEFINE.ITEM_ADD_EDIT, ColumnDefineTableItemAddEdit, {
      type,
      mode: 'add',
      itemList: itemList(type),
    });
  };

  const onEdit = (data: ConvertRuleItem, index: number) => {
    openModal<ColumnDefineTableItemAddEditProps>(MODAL_NAME.COLUMN_DEFINE.ITEM_ADD_EDIT, ColumnDefineTableItemAddEdit, {
      type,
      data,
      mode: 'edit',
      itemList: itemList(type),
    });
  };

  const onDelete = async (record: ConvertRuleItem) => {
    try {
      const { type, id } = record;
      if (!type && !id) {
        throw new Error('Invalid type or id!');
      }
      await mutateAsyncDelete({ type: type as TypeColumnDefineTab, id: id as number });
    } catch (error) {
      console.error(error);
    } finally {
      refetch();
    }
  };

  const searchItems: SearchModalItem[] = [
    {
      type: 'text',
      name: 'name',
      label: 'Name',
    },
    {
      type: 'text',
      name: 'output_column',
      label: 'Output Column',
    },
    {
      type: 'select',
      name: 'data_type',
      label: 'Data Type',
      options: data_type.map((item) => ({
        label: item,
        key: item,
        value: item,
      })),
    },
  ];

  const openSearchModal = () => {
    openModal<SearchModalProps>(MODAL_NAME.COLUMN_DEFINE.SEARCH, SearchModal, {
      items: searchItems,
      param: searchParam,
      setParam: setSearchParam,
    });
  };

  return {
    data,
    isFetching,
    viewMode,
    onChangeViewMode,
    isRequesting,
    pagination,
    searchParam,
    hasSearchParam,
    setPagination,
    setSearchParam,
    setRequesting,
    onChangeTable,
    onAdd,
    onEdit,
    openSearchModal,
    searchItems,
    onDelete,
  };
}

const itemList = (type: TypeColumnDefineTab) => {
  const matchedList: Record<TypeColumnDefineTab, ConvertRuleSelectItemKey[]> = {
    info: ['name', 'output_column', 'data_type', 'def_val'],
    header: ['name', 'output_column', 'data_type', 'def_val', 'coef', 'unit'],
    regex: ['name', 'output_column', 'data_type', 'regex_prefix', 'regex', 're_group', 'def_val', 'coef', 'unit'],
  };

  return matchedList[type] ?? [];
};
