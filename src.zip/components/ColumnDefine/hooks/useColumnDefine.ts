import { openAntdModal } from '@components/common/atoms/AntdModal';
import FileImportModal, { FileImportModalProps } from '@components/common/atoms/FileImportModal/FileImportModal';
import { API_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { useGetColumnDefineExport } from '@libs/query/columnDefine';
import { useGetConvertRuleOption } from '@libs/query/convert';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { initColDefine, setColDefineRuleOptions } from '@reducers/slices/columnDefine';
import { useQueryClient } from '@tanstack/react-query';
import { TypeColumnDefineTab } from '@typesdef/columnDefine';
import { AxiosError } from 'axios';
import saveAs from 'file-saver';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';

export default function useColumnDefine() {
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const [activeKey, setActiveKey] = useState<TypeColumnDefineTab>('info');
  const { openModal } = useModals();

  const { isFetching: isFetchingOption } = useGetConvertRuleOption({
    onSuccess: (data) => {
      dispatch(setColDefineRuleOptions(data));
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to get rule options`, error);
    },
  });

  const { mutateAsync: mutateAsyncExport, isLoading: isLoadingImport } = useGetColumnDefineExport();

  const onExport = () => {
    openAntdModal('confirm', {
      title: 'Export Column Define',
      content: 'Are you sure to export column define?',
      okText: 'Export',
      onOk: async () => {
        try {
          const { data, fileName } = await mutateAsyncExport();
          saveAs(data, fileName);
          openNotification('success', 'Success', `Succeed to export column define '${fileName}'.`);
        } catch (e) {
          console.error(e);
          openNotification('error', 'Error', 'Failed to export column define!');
        }
      },
    });
  };

  const onImport = () => {
    openModal<FileImportModalProps>(MODAL_NAME.COLUMN_DEFINE.FILE_IMPORT, FileImportModal, {
      title: 'Import Column Define',
      url: API_URL.POST_COLUMN_DEFINE_IMPORT,
      afterError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to import column define!`, error);
      },
      afterSuccess: () => {
        openNotification('success', 'Success', 'Succeed to import column define.');
      },
      afterSettled: () => {
        queryClient.invalidateQueries([QUERY_KEY.RULES_COL_DEFINE_LIST], {
          exact: false,
        });
      },
      mutationKey: [MUTATION_KEY.RULES_COL_DEFINE_IMPORT],
    });
  };

  useEffect(() => {
    dispatch(initColDefine());
  }, []);

  return {
    activeKey,
    setActiveKey,
    onExport,
    onImport,
  };
}
