import { convertDefTypeCustom, initialConvertRuleItem } from '@components/Convert/ConvertCommon';
import { API_URL } from '@constants/constants';
import { getRequest } from '@libs/axios/requests';
import { usePostColumnDefine, usePutColumnDefine } from '@libs/query/columnDefine';
import { QUERY_KEY } from '@libs/query/queryKey';
import { getQueriesParam, isDuplicateItemFormList } from '@libs/util/convert';
import { formatConvertRuleItem } from '@libs/util/convertRule';
import { getFormErrorStatus, initialFormError } from '@libs/util/error';
import { openNotification } from '@libs/util/notification';
import { validateDBname } from '@libs/util/validation';
import { getColDefineRuleOption } from '@reducers/slices/columnDefine';
import useTypedSelector from '@reducers/useTypedSelector';
import { useQueryClient } from '@tanstack/react-query';
import { ResPagination } from '@typesdef/common';
import { ConvertRuleItem } from '@typesdef/convertRules';
import { FormItemProps } from 'antd';
import { useForm, useWatch } from 'antd/es/form/Form';
import { DefaultOptionType } from 'antd/es/select';
import { useEffect, useMemo, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import { useDebounce } from 'react-use';
import { ColumnDefineTableItemAddEditProps } from '../Modal/ColumnDefineTableItemAddEdit';

interface Props extends ColumnDefineTableItemAddEditProps {
  onClose: () => void;
}

export default function useColumnDefineTableItemAddEdit({ onClose, index, data, type, mode, itemList }: Props) {
  const queryClient = useQueryClient();
  const [form] = useForm<ConvertRuleItem>();
  const ruleOptions = useTypedSelector(getColDefineRuleOption);
  const divRef = useRef<HTMLDivElement>(null);
  const formDefType = useWatch('def_type', form);
  const formDataType = useWatch('data_type', form);
  const formName = useWatch('name', form);
  const formOutCol = useWatch('output_column', form);
  const [formNameValid, setFormNameValid] = useState<{
    help: string;
    status: FormItemProps['validateStatus'];
  }>({ ...initialFormError });
  const [formOutColValid, setFormOutColValid] = useState<{
    help: string;
    status: FormItemProps['validateStatus'];
  }>({ ...initialFormError });

  const typeOptions: {
    dataType: DefaultOptionType[];
    defType: DefaultOptionType[];
    filterType: DefaultOptionType[];
  } = useMemo(
    () => ({
      dataType: ruleOptions.data_type.map((item) => ({
        label: item,
        value: item,
        key: item,
      })),
      defType: ruleOptions.def_type.map((item) => ({
        label: item,
        value: item,
        key: item,
      })),
      filterType: ruleOptions.filter_type.map((item) => ({
        label: item,
        value: item,
        key: item,
      })),
    }),
    [ruleOptions],
  );

  const { mutateAsync: mutateAsyncAdd, isLoading: isLoadingAdd } = usePostColumnDefine({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to add ${type} define.`);
      queryClient.invalidateQueries([QUERY_KEY.RULES_COL_DEFINE_LIST], { exact: false });
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to add ${type} define!`, error);
    },
  });

  const { mutateAsync: mutateAsyncEdit, isLoading: isLoadingEdit } = usePutColumnDefine({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to edit ${type} define.`);
      queryClient.invalidateQueries([QUERY_KEY.RULES_COL_DEFINE_LIST], { exact: false });
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to edit ${type} define!`, error);
    },
  });

  const isLoading = useMemo(() => isLoadingAdd || isLoadingEdit, [isLoadingAdd, isLoadingEdit]);

  const onValidateData = async () => {
    let isError = false;
    try {
      await form.validateFields();
    } catch (error) {
      isError = true;
      console.error(error);
    } finally {
      if (!formName) {
        setFormNameValid(getFormErrorStatus({ rule: 'empty' }));
        isError = true;
        console.error('Please input a name!');
      }

      if (formNameValid.status === 'error') {
        isError = true;
        console.error(formNameValid.help);
      }

      if (!formOutCol) {
        setFormOutColValid(getFormErrorStatus({ rule: 'empty' }));
        isError = true;
        console.error('Please input a output column!');
      }

      if (formOutColValid.status === 'error') {
        isError = true;
        console.error(formNameValid.help);
      }
    }

    return isError;
  };

  const onOk = async () => {
    try {
      if (!(await onValidateData())) {
        if (mode === 'add') {
          await mutateAsyncAdd({
            type,
            data: formatConvertRuleItem({ rule: form.getFieldsValue() }),
          });
        } else if (mode === 'edit') {
          await mutateAsyncEdit({
            type,
            id: form.getFieldValue('id'),
            data: formatConvertRuleItem({ rule: form.getFieldsValue() }),
          });
        }
        onClose();
      }
    } catch (error) {
      console.error(error);
    }
  };

  const onChangeDefType = (value: string) => {
    form.setFieldsValue({
      def_type: value,
      def_val: convertDefTypeCustom.includes(value) ? '' : value,
    });
  };

  useDebounce(
    async () => {
      if (formName) {
        if (formName.length > 50) {
          setFormNameValid(getFormErrorStatus({ rule: 'max', max: 50 }));
          return;
        }

        try {
          flushSync(() => {
            setFormNameValid(getFormErrorStatus({ rule: 'initial' }));
          });
          const { content } = await getRequest<ResPagination<ConvertRuleItem[]>>({
            url: API_URL.GET_COLUMN_DEFINE_LIST(
              type,
              getQueriesParam({
                query: {
                  strict: true,
                },
                search: {
                  ['name']: formName as string,
                },
              }),
            ),
          });

          if (
            isDuplicateItemFormList<ConvertRuleItem>({
              key: 'name',
              curName: formName,
              oriName: data?.name ?? undefined,
              content,
            })
          ) {
            flushSync(() => {
              setFormNameValid(getFormErrorStatus({ rule: 'duplicated' }));
            });
          } else {
            flushSync(() => {
              setFormNameValid(getFormErrorStatus({ rule: 'initial' }));
            });
          }
        } catch (e) {
          console.error(e);
        }
      } else {
        if (formName === '') {
          setFormNameValid(getFormErrorStatus({ rule: 'empty' }));
        }
      }
    },
    300,
    [formName],
  );

  useDebounce(
    async () => {
      if (formOutCol) {
        if (formOutCol.length > 50) {
          setFormOutColValid(getFormErrorStatus({ rule: 'max', max: 50 }));
          return;
        }

        if (!validateDBname(formOutCol)) {
          setFormOutColValid(getFormErrorStatus({ rule: 'dbNaming' }));
          return;
        }

        try {
          flushSync(() => {
            setFormOutColValid(getFormErrorStatus({ rule: 'initial' }));
          });
          const { content } = await getRequest<ResPagination<ConvertRuleItem[]>>({
            url: API_URL.GET_COLUMN_DEFINE_LIST(
              type,
              getQueriesParam({
                query: {
                  strict: true,
                },
                search: {
                  ['output_column']: formOutCol as string,
                },
              }),
            ),
          });

          if (
            isDuplicateItemFormList<ConvertRuleItem>({
              key: 'output_column',
              curName: formOutCol,
              oriName: data?.output_column ?? undefined,
              content,
            })
          ) {
            flushSync(() => {
              setFormOutColValid(getFormErrorStatus({ rule: 'duplicated' }));
            });
          } else {
            flushSync(() => {
              setFormOutColValid(getFormErrorStatus({ rule: 'initial' }));
            });
          }
        } catch (e) {
          console.error(e);
        }
      } else {
        if (formOutCol === '') {
          setFormOutColValid(getFormErrorStatus({ rule: 'empty' }));
        }
      }
    },
    300,
    [formOutCol],
  );

  useEffect(() => {
    if (data) {
      form.setFieldsValue({
        ...data,
      });
    } else {
      form.setFieldsValue({
        ...initialConvertRuleItem,
      });
    }
  }, []);

  return {
    form,
    onOk,
    onChangeDefType,
    divRef,
    formDefType,
    formDataType,
    formName,
    formNameValid,
    formOutCol,
    formOutColValid,
    typeOptions,
    isLoading,
  };
}
