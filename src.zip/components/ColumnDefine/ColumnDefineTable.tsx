import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import { getSearchedText } from '@components/common/atoms/SearchModal/SearchModal';
import SearchModalButton from '@components/common/atoms/SearchModal/SearchModalButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import TableScrollTitle from '@components/common/atoms/TableScrollTitle';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TypeColumnDefineTab } from '@typesdef/columnDefine';
import { TableColumnPropsType } from '@typesdef/common';
import { ConvertRuleItem } from '@typesdef/convertRules';
import { Popconfirm, Select, Table } from 'antd';
import { Fragment, useRef } from 'react';
import useColumnDefineTable from './hooks/useColumnDefineTable';

export interface ColumnDefineTableProps {
  type: TypeColumnDefineTab;
}

export default function ColumnDefineTable({ type }: ColumnDefineTableProps) {
  const {
    data,
    isFetching,
    viewMode,
    onChangeViewMode,
    pagination,
    searchParam,
    hasSearchParam,
    setSearchParam,
    onChangeTable,
    onAdd,
    onEdit,
    openSearchModal,
    searchItems,
    onDelete,
  } = useColumnDefineTable({ type });
  const tableRef = useRef<HTMLDivElement>(null);

  const renderTitle = () => (
    <TableHeader
      title={
        <TableHeaderTitle
          total={pagination.total}
          isSearched={hasSearchParam}
          searchedText={getSearchedText(searchItems, searchParam)}
          onResetSearch={() => setSearchParam({})}
          color="green"
        />
      }
    >
      <SearchModalButton hasParam={hasSearchParam} onClick={() => openSearchModal()} />
      {type !== 'info' && (
        <Select
          onChange={onChangeViewMode}
          value={viewMode}
          css={css`
            .ant-select-selector {
              width: 5.5rem;
            }
          `}
        >
          <Select.Option key="simple" value="simple">
            Simple
          </Select.Option>
          <Select.Option key="detail" value="detail">
            Detail
          </Select.Option>
        </Select>
      )}

      <AntdButton icon={<PlusOutlined />} onClick={() => onAdd()}>
        Add
      </AntdButton>
    </TableHeader>
  );

  const renderEdit = (value: number, record: ConvertRuleItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to edit this column?"
        onConfirm={() => onEdit(record, index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ConvertRuleItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to delete this column?"
        onConfirm={() => onDelete(record)}
        okText="Ok"
        cancelText="Cancel"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <Table<ConvertRuleItem>
      ref={tableRef}
      rowKey={(record, index) => index as number}
      dataSource={data?.content ?? []}
      bordered
      size="small"
      tableLayout="fixed"
      title={renderTitle}
      sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      pagination={{
        position: ['bottomCenter'],
        showSizeChanger: true,
        current: pagination.current,
        pageSize: pagination.pageSize,
        total: pagination.total,
      }}
      loading={isFetching}
      onChange={onChangeTable}
      scroll={{ x: 'max-content' }}
    >
      {(type === 'info' || type === 'header') && viewMode === 'simple' && (
        <Fragment>
          <Table.Column<ConvertRuleItem> {...columnProps.name} width={getPixelPercent(1360, 310)} />
          <Table.Column<ConvertRuleItem> {...columnProps.output_column} width={getPixelPercent(1360, 310)} />
          <Table.Column<ConvertRuleItem> {...columnProps.data_type} width={getPixelPercent(1360, 270)} />
          <Table.Column<ConvertRuleItem> {...columnProps.def_val} width={getPixelPercent(1360, 310)} />
          <Table.Column<ConvertRuleItem> {...columnProps.edit} width={getPixelPercent(1360, 80)} render={renderEdit} />
          <Table.Column<ConvertRuleItem>
            {...columnProps.delete}
            width={getPixelPercent(1360, 80)}
            render={renderDelete}
          />
        </Fragment>
      )}
      {type === 'header' && viewMode === 'detail' && (
        <Fragment>
          <Table.Column<ConvertRuleItem> {...columnProps.name} width={getPixelPercent(1360, 260)} />
          <Table.Column<ConvertRuleItem> {...columnProps.output_column} width={getPixelPercent(1360, 260)} />
          <Table.Column<ConvertRuleItem> {...columnProps.data_type} width={getPixelPercent(1360, 220)} />
          <Table.Column<ConvertRuleItem> {...columnProps.def_val} width={getPixelPercent(1360, 260)} />
          <Table.Column<ConvertRuleItem> {...columnProps.coef} width={getPixelPercent(1360, 100)} />
          <Table.Column<ConvertRuleItem> {...columnProps.unit} width={getPixelPercent(1360, 100)} />
          <Table.Column<ConvertRuleItem> {...columnProps.edit} width={getPixelPercent(1360, 80)} render={renderEdit} />
          <Table.Column<ConvertRuleItem>
            {...columnProps.delete}
            width={getPixelPercent(1360, 80)}
            render={renderDelete}
          />
        </Fragment>
      )}
      {type === 'regex' && viewMode === 'simple' && (
        <Fragment>
          <Table.Column<ConvertRuleItem> {...columnProps.name} width={getPixelPercent(1360, 200)} />
          <Table.Column<ConvertRuleItem> {...columnProps.output_column} width={getPixelPercent(1360, 200)} />
          <Table.Column<ConvertRuleItem> {...columnProps.regex_prefix} width={getPixelPercent(1360, 200)} />
          <Table.Column<ConvertRuleItem> {...columnProps.regex} width={getPixelPercent(1360, 260)} />
          <Table.Column<ConvertRuleItem> {...columnProps.data_type} width={getPixelPercent(1360, 140)} />
          <Table.Column<ConvertRuleItem> {...columnProps.def_val} width={getPixelPercent(1360, 200)} />
          <Table.Column<ConvertRuleItem> {...columnProps.edit} width={getPixelPercent(1360, 80)} render={renderEdit} />
          <Table.Column<ConvertRuleItem>
            {...columnProps.delete}
            width={getPixelPercent(1360, 80)}
            render={renderDelete}
          />
        </Fragment>
      )}
      {type === 'regex' && viewMode === 'detail' && (
        <Fragment>
          <Table.Column<ConvertRuleItem>
            {...columnProps.name}
            width={220}
            fixed="left"
            title={<TableScrollTitle title="Name" ref={tableRef} direction="left" />}
          />
          <Table.Column<ConvertRuleItem> {...columnProps.output_column} width={200} />
          <Table.Column<ConvertRuleItem> {...columnProps.regex_prefix} width={200} />
          <Table.Column<ConvertRuleItem> {...columnProps.regex} width={260} />
          <Table.Column<ConvertRuleItem> {...columnProps.group} width={100} />
          <Table.Column<ConvertRuleItem> {...columnProps.data_type} width={140} />
          <Table.Column<ConvertRuleItem> {...columnProps.def_val} width={200} />
          <Table.Column<ConvertRuleItem> {...columnProps.coef} width={100} />
          <Table.Column<ConvertRuleItem> {...columnProps.unit} width={100} />
          <Table.Column<ConvertRuleItem> {...columnProps.edit} width={80} fixed="right" render={renderEdit} />
          <Table.Column<ConvertRuleItem>
            {...columnProps.delete}
            width={getPixelPercent(1360, 100)}
            fixed="right"
            render={renderDelete}
            title={<TableScrollTitle title="Delete" ref={tableRef} direction="right" />}
          />
        </Fragment>
      )}
    </Table>
  );
}

const style = css`
  margin-left: 1rem;
  margin-right: 1rem;
  margin-bottom: 1rem;
`;

const columnNameList = (type: 'info' | 'header' | 'regex', viewMode: 'simple' | 'detail') =>
  ({
    info: {
      simple: ['name', 'output_column', 'data_type', 'def_val'],
    },
    header: {
      simple: ['name', 'output_column', 'data_type', 'def_val'],
      detail: ['name', 'output_column', 'data_type', 'def_val', 'coef', 'unit'],
    },
    regex: {
      simple: ['name', 'output_column', 'data_type', 'regex_prefix', 'regex', 'def_val'],
      detail: ['name', 'output_column', 'data_type', 'regex_prefix', 'regex', 'group', 'def_val', 'coef', 'unit'],
    },
  }[type][viewMode] ?? []);

type ColumnName =
  | 'name'
  | 'output_column'
  | 'data_type'
  | 'regex_prefix'
  | 'regex'
  | 'group'
  | 'def_val'
  | 'coef'
  | 'unit'
  | 'edit'
  | 'delete';

export const columnProps: TableColumnPropsType<ConvertRuleItem, ColumnName> = {
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    sorter: true,
  },
  output_column: {
    key: 'output_column',
    title: <TableColumnTitle>Output Column</TableColumnTitle>,
    dataIndex: 'output_column',
    align: 'center',
    sorter: true,
  },
  regex_prefix: {
    key: 'regex_prefix',
    title: <TableColumnTitle>Regex Prefix</TableColumnTitle>,
    dataIndex: 'regex_prefix',
    align: 'center',
    sorter: true,
  },
  regex: {
    key: 'regex',
    title: <TableColumnTitle>Regex</TableColumnTitle>,
    dataIndex: 'regex',
    align: 'center',
    sorter: true,
  },
  group: {
    key: 'group',
    title: <TableColumnTitle>Group</TableColumnTitle>,
    dataIndex: 'group',
    align: 'center',
    sorter: true,
  },
  data_type: {
    key: 'data_type',
    title: <TableColumnTitle>Data Type</TableColumnTitle>,
    dataIndex: 'data_type',
    align: 'center',
    sorter: true,
  },
  def_val: {
    key: 'def_val',
    title: <TableColumnTitle>Default Value</TableColumnTitle>,
    dataIndex: 'def_val',
    align: 'center',
    sorter: true,
  },
  coef: {
    key: 'coef',
    title: <TableColumnTitle>Coefficient</TableColumnTitle>,
    dataIndex: 'coef',
    align: 'center',
    sorter: true,
  },
  unit: {
    key: 'unit',
    title: <TableColumnTitle>Unit</TableColumnTitle>,
    dataIndex: 'unit',
    align: 'center',
    sorter: true,
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
  },
};
