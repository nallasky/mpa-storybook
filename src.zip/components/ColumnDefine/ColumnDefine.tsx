import { ExportOutlined, ImportOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import { css } from '@emotion/react';
import { TypeColumnDefineTab } from '@typesdef/columnDefine';
import { Space, Tabs } from 'antd';
import { useMemo } from 'react';
import ColumnDefineTable from './ColumnDefineTable';
import useColumnDefine from './hooks/useColumnDefine';

export default function ColumnDefine() {
  const { activeKey, setActiveKey, onExport, onImport } = useColumnDefine();

  const panes = useMemo(
    () => [
      {
        title: 'Info',
        key: 'info',
        contents: <ColumnDefineTable type={activeKey} />,
      },
      {
        title: 'Header',
        key: 'header',
        contents: <ColumnDefineTable type={activeKey} />,
      },
      {
        title: 'Regex',
        key: 'regex',
        contents: <ColumnDefineTable type={activeKey} />,
      },
    ],
    [activeKey],
  );

  return (
    <div css={style}>
      <div className="top">
        <Space>
          <AntdButton icon={<ImportOutlined />} type="primary" onClick={() => onImport()}>
            Import
          </AntdButton>
          <AntdButton icon={<ExportOutlined />} type="primary" onClick={() => onExport()}>
            Export
          </AntdButton>
        </Space>
      </div>
      <Tabs hideAdd onChange={(key) => setActiveKey(key as TypeColumnDefineTab)} activeKey={activeKey} type="card">
        {panes.map((pane) => (
          <Tabs.TabPane key={pane.key} tab={pane.title}>
            {pane.contents}
          </Tabs.TabPane>
        ))}
      </Tabs>
    </div>
  );
}

const style = css`
  width: 85rem;
  .top {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 1rem;
  }
`;
