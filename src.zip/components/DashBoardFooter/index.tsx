export { default } from './DashBoardFooter';
