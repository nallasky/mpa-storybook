import { blue } from '@ant-design/colors';
import { DownloadOutlined } from '@ant-design/icons';
import { openAntdModal } from '@components/common/atoms/AntdModal';
import { API_URL } from '@constants/constants';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { getDownloadCrasDebugLog, getRequest, putRequest } from '@libs/axios/requests';
import { SiteDBInfo } from '@libs/axios/types';
import { useGetConfigureSites } from '@libs/query/configureSetting';
import { QUERY_KEY } from '@libs/query/queryKey';
import { compareTableItem } from '@libs/util/compareTableItem';
import { downloadFileUrl } from '@libs/util/download';
import { openNotification } from '@libs/util/notification';
import { getDebugLogfixedCras, setDebugModeFixedCras } from '@reducers/slices/debugMode';
import useTypedSelector from '@reducers/useTypedSelector';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Input, Select, Table } from 'antd';
import { ColumnType, CompareFn } from 'antd/es/table/interface';
import { AxiosError } from 'axios';
import { saveAs } from 'file-saver';
import React, { ChangeEvent, Key, KeyboardEventHandler, useCallback, useMemo, useState } from 'react';
import { useDispatch } from 'react-redux';
import StatusTableHeader from '../StatusTableHeader';

export type DebugLogProps = {};

export default function DebugLog({}: DebugLogProps): JSX.Element {
  const [path, setPath] = useState<string | undefined>();
  const fixedCras = useTypedSelector(getDebugLogfixedCras);
  const dispatch = useDispatch();
  const queryClient = useQueryClient();

  const {
    data: crasServer,
    isFetching: isFetchingCrasServer,
    refetch: refetchCrasServer,
  } = useGetConfigureSites({
    onError: () => {
      openNotification('error', 'Error', 'Failed to response setting database information.');
    },
  });

  const { isFetching: isFetchingSelectCras } = useQuery(
    [QUERY_KEY.DEBUG_SELECT_CRAS_SERVER],
    () =>
      getRequest<{ siteId: number | null }>({
        url: API_URL.GET_DEBUG_SELECT_CRAS_SERVER,
      }),
    {
      onSuccess: (data) => {
        dispatch(setDebugModeFixedCras(data?.siteId ? +data.siteId : null));
      },
      onError(error) {
        openNotification('error', 'Error', 'Failed to response of select cras server!', error as AxiosError);
        dispatch(setDebugModeFixedCras(null));
      },
    },
  );

  const { mutate: mutateSelectCras, isLoading: isLoadingSelectCras } = useMutation(
    async (siteId: number | null) => {
      await putRequest({
        url: API_URL.PUT_DEBUG_SELECT_CRAS_SERVER,
        reqData: {
          siteId,
        },
      });
    },
    {
      onSuccess: () => {
        openNotification('success', 'Success', 'Succeed to select cras server.');
      },
      onError: (error) => {
        openNotification('error', 'Error', 'Failed to select cras server!', error as AxiosError);
      },
      onSettled: () => {
        queryClient.invalidateQueries([QUERY_KEY.DEBUG_SELECT_CRAS_SERVER]);
      },
    },
  );

  const downloadCras = useCallback((siteId: number, siteName: string, address: string) => {
    openAntdModal('confirm', {
      className: 'download-debug-log',
      title: 'Download Cras Debug Log',
      content: `Are you sure to download cras debug log from ${siteName}?`,
      okText: 'Download',
      onOk: async () => {
        try {
          // downloadFileUrl(API_URL.GET_DOWNLOAD_CRAS_DEBUG_LOG(newSiteId));
          const { data, fileName } = await getDownloadCrasDebugLog(siteId);
          saveAs(data, fileName);

          openNotification('success', 'Success', `Succeed to download cras debug log from ${siteName}'.`);
        } catch (e) {
          console.error(e);
          // openNotification('error', 'Error', `Failed to download cras debug log from ${siteName}!`);
        }
      },
    });
  }, []);

  const indexRender = useCallback((value: number, record: SiteDBInfo, index: number) => value + 1, []);
  const crasDownloadRender = useCallback(
    (value: number, record: SiteDBInfo, index: number) => {
      return (
        <DownloadOutlined
          css={iconStyle}
          onClick={() => {
            downloadCras(record.siteId, record.crasCompanyFabName, record.crasAddress);
          }}
        />
      );
    },
    [downloadCras],
  );

  const crasTitleRender = useCallback(
    () => (
      <StatusTableHeader
        title={{
          name: 'Registered Site',
          count: crasServer?.length ?? 0,
        }}
        refreshBtn={{
          onClick: refetchCrasServer,
        }}
        disabled={isFetchingCrasServer}
        isLoading={isFetchingCrasServer}
      />
    ),
    [isFetchingCrasServer, refetchCrasServer, crasServer],
  );

  const downloadLog = useCallback(() => {
    openAntdModal('confirm', {
      className: 'download-debug-log',
      title: 'Download Log Monitor Debug Log',
      content: `Are you sure to download log monitor debug log from ${path as string}?`,
      okText: 'Download',
      onOk: async () => {
        try {
          downloadFileUrl(API_URL.GET_DOWNLOAD_LOG_MOINITOR_DEBUG_LOG(path as string));

          // const { data, fileName } = await getDownloadLogMonitorDebugLog(path as string);
          // saveAs(data, fileName);

          // openNotification('success', 'Success', `Succeed to download log monitor debug log from ${path}'.`);
        } catch (e) {
          console.error(e);
          // openNotification('error', 'Error', `Failed to download log monitor debug log from ${path}!`);
        }
      },
    });
  }, [path]);

  const logMonitorDownloadRender = useMemo(() => {
    return (
      <DownloadOutlined
        css={logIconStyle(path)}
        onClick={() => {
          downloadLog();
        }}
      />
    );
  }, [downloadLog, path]);

  const onChangePath = useCallback((e: ChangeEvent<HTMLInputElement>) => {
    setPath(e.target.value);
  }, []);

  const onKeyDown: KeyboardEventHandler = useCallback(
    (e) => {
      if (e.key === 'Enter') {
        if (path) {
          downloadLog();
        }
      }
    },
    [downloadLog, path],
  );

  return (
    <div css={style}>
      <div className="log-monitor-log">
        <div className="title">Log Monitor Downlaod</div>
        <Input
          className="log-monitor-log-input"
          value={path}
          suffix={logMonitorDownloadRender}
          placeholder="Input a log monitor's log directory and enter"
          onChange={onChangePath}
          onKeyDown={onKeyDown}
        />
      </div>
      <div className="cras-log">
        <div className="title">Cras Debug Log Download</div>
        <Table<SiteDBInfo>
          rowKey={'siteId'}
          dataSource={crasServer ?? []}
          bordered
          title={crasTitleRender}
          size="small"
          pagination={{
            position: ['bottomCenter'],
            total: crasServer?.length ?? 0,
            showSizeChanger: true,
          }}
          loading={isFetchingCrasServer}
          tableLayout="fixed"
        >
          <Table.Column<SiteDBInfo> {...accountColumnProps.index} width={100} render={indexRender} />
          <Table.Column<SiteDBInfo> {...accountColumnProps.crasCompanyFabName} />
          <Table.Column<SiteDBInfo> {...accountColumnProps.crasAddress} />
          <Table.Column<SiteDBInfo> {...accountColumnProps.crasPort} />
          <Table.Column<SiteDBInfo> {...accountColumnProps.download} render={crasDownloadRender} />
        </Table>
      </div>
      <div className="cras-select">
        <div className="title">Cras Server Select</div>
        <Select
          allowClear
          value={fixedCras}
          onChange={(value: number | undefined) => {
            dispatch(setDebugModeFixedCras(value ?? null));
            mutateSelectCras(value ?? null);
          }}
          css={css`
            width: 20rem;
          `}
          options={
            crasServer?.map((item) => ({ label: item.crasCompanyFabName, value: item.siteId, key: item.siteId })) ?? []
          }
          loading={isFetchingCrasServer || isFetchingSelectCras || isLoadingSelectCras}
          disabled={isFetchingCrasServer || isFetchingSelectCras || isLoadingSelectCras}
        />
      </div>
    </div>
  );
}

const style = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;

  .log-monitor-log,
  .cras-log,
  .cras-select {
    width: 80rem;
    margin-top: 2rem;
    .title {
      font-size: 1.5rem;
    }
  }

  .log-monitor-log {
    .log-monitor-log-input {
      width: 30rem;
    }
  }
`;

const ColumnTitle = styled.div`
  font-weight: 700;
`;

const iconStyle = css`
  /* font-size: 1.25rem; */

  &:hover {
    color: ${blue[4]};
  }
  &:active {
    color: ${blue[6]};
  }
`;

const logIconStyle = (path: string | undefined) => css`
  /* font-size: 1.25rem; */

  pointer-events: ${!path && 'none'};

  color: ${!path && 'gray'};

  &:hover {
    color: ${blue[4]};
  }
  &:active {
    color: ${blue[6]};
  }
`;

export type CrasServerColumnName = 'index' | 'crasCompanyFabName' | 'crasAddress' | 'crasPort' | 'download';

export type CrasServerPropsType = {
  [name in CrasServerColumnName]: {
    key?: Key;
    title?: React.ReactNode;
    dataIndex?: ColumnType<SiteDBInfo>['dataIndex'];
    align?: ColumnType<SiteDBInfo>['align'];
    sorter?:
      | boolean
      | CompareFn<SiteDBInfo>
      | {
          compare?: CompareFn<SiteDBInfo>;
          /** Config multiple sorter order priority */
          multiple?: number;
        };
  };
};

const accountColumnProps: CrasServerPropsType = {
  index: {
    key: 'index',
    title: <ColumnTitle>No</ColumnTitle>,
    dataIndex: 'index',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'index'),
    },
  },
  crasCompanyFabName: {
    key: 'crasCompanyFabName',
    title: <ColumnTitle>User-Fab Name</ColumnTitle>,
    dataIndex: 'crasCompanyFabName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'crasCompanyFabName'),
    },
  },
  crasAddress: {
    key: 'crasAddress',
    title: <ColumnTitle>Address</ColumnTitle>,
    dataIndex: 'crasAddress',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'crasAddress'),
    },
  },
  crasPort: {
    key: 'crasPort',
    title: <ColumnTitle>Port</ColumnTitle>,
    dataIndex: 'crasPort',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'crasPort'),
    },
  },

  download: {
    key: 'download',
    title: <ColumnTitle>Download</ColumnTitle>,
    dataIndex: 'siteId',
    align: 'center',
  },
};
