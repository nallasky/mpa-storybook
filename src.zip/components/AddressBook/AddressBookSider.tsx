import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import CustomIcon from '@components/common/atoms/CustomIcon';
import RefreshBtn from '@components/common/atoms/RefreshBtn';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { DEFAULT_ALL_ADDRESS_KEY } from '@reducers/slices/address';
import { hoverActiveStyle } from '@styles/emotion/common';
import { Button, Menu, Skeleton } from 'antd';
import { ItemType } from 'antd/es/menu/hooks/useItems';
import { useMemo } from 'react';
import useAddressBookSider from './hooks/useAddressBookSider';

export type AddressBookSiderProps = {};

export default function AddressBookSider({}: AddressBookSiderProps): JSX.Element {
  const {
    groups,
    isFetchingGroups,
    onClickMenuItem,
    currentSelect,
    openEmailAddModal,
    openGroupAddModal,
    openGroupEditModal,
    openGroupDeleteModal,
    refreshGroupList,
  } = useAddressBookSider();

  const allAddressItem = useMemo<ItemType>(
    () => ({
      key: DEFAULT_ALL_ADDRESS_KEY,
      label: (
        <div css={groupItemStyle}>
          <div className="name-area">
            <CustomIcon name="all_address" />
            <span className="name">All Address</span>
          </div>
          <div className="btn-area">
            <RefreshBtn type="link" onClick={refreshGroupList} />
          </div>
        </div>
      ),
    }),
    [refreshGroupList],
  );
  const groupItems = useMemo<ItemType[]>(() => {
    if (!groups || !Array.isArray(groups) || groups.length === 0) {
      return [];
    }
    return groups.map((item) => ({
      key: item.id,
      label: (
        <div css={groupItemStyle}>
          <div className="name-area">
            <ItemSpace />
            <CustomIcon name="address_group" />
            <span className="name">{item.name}</span>
          </div>
          <div className="btn-area">
            <EditOutlined onClick={() => openGroupEditModal(item)} css={hoverActiveStyle} />
            <DeleteOutlined onClick={() => openGroupDeleteModal(item)} css={hoverActiveStyle} />
          </div>
        </div>
      ),
    }));
  }, [groups, openGroupEditModal, openGroupDeleteModal]);

  const loadingItem = useMemo<ItemType>(
    () => ({
      key: 'loading',
      disabled: true,
      label: <Skeleton active paragraph={{ rows: 21 }} />,
      className: 'loading-items',
    }),
    [],
  );

  const menuItems = useMemo(() => {
    const newMenuItems: ItemType[] = [];
    if (isFetchingGroups) {
      newMenuItems.push({ ...allAddressItem, disabled: true } as ItemType);
      newMenuItems.push(loadingItem);
    } else {
      newMenuItems.push(allAddressItem);
      groupItems.length > 0 && newMenuItems.push(...groupItems);
    }
    return newMenuItems;
  }, [allAddressItem, groupItems, loadingItem, isFetchingGroups]);

  return (
    <div css={style}>
      <div className="button-contents">
        <Button className="btn" type="primary" onClick={() => openEmailAddModal()}>
          Add Email
        </Button>
        <Button className="btn" type="primary" onClick={() => openGroupAddModal()}>
          Add Group
        </Button>
      </div>

      <Menu
        onClick={onClickMenuItem}
        css={menuStyle}
        defaultSelectedKeys={[`${DEFAULT_ALL_ADDRESS_KEY}`]}
        // mode="inline"
        selectedKeys={[`${currentSelect}`]}
        items={menuItems}
      ></Menu>
    </div>
  );
}

const style = css`
  .button-contents {
    display: flex;
    justify-content: space-between;
    margin-bottom: 1rem;
    .btn {
      width: 9.5rem;
      border-radius: 0.625rem;
    }
  }
`;

const menuStyle = css`
  width: 20rem;
  height: 48.75rem;
  overflow-y: scroll;
  overflow-x: hidden;
  border: 1px solid rgb(240, 240, 240);

  .loading-items {
    height: 45rem;
  }
`;

const ItemSpace = styled.span`
  margin-right: 1rem;
`;

const groupItemStyle = css`
  display: flex;
  align-items: center;
  justify-content: space-between;

  .name-area {
    display: flex;
    align-items: center;
    .name {
      display: block;
      width: 11rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
`;
