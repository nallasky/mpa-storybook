import { openAntdModal } from '@components/common/atoms/AntdModal';
import { deleteAddressGroup, getAddressGroupList } from '@libs/axios/requests';
import { AddressInfo } from '@libs/axios/types';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import {
  AddressGroupSelector,
  AddressVisibleEmailModalSelector,
  AddressVisibleGroupModalSelector,
  DEFAULT_ALL_ADDRESS_KEY,
  DEFAULT_ALL_ADDRESS_NAME,
  initAddressStateReducer,
  setEditEmailReducer,
  setEditGroupReducer,
  setSelectGroupReducer,
  setVisibleEmailModalReducer,
  setVisibleGroupModalReducer,
} from '@reducers/slices/address';
import { AxiosError } from 'axios';
import { useCallback, useEffect, useRef } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useDispatch, useSelector } from 'react-redux';

export default function useAddressBookSider() {
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const { id: currentSelect } = useSelector(AddressGroupSelector);
  const visibleEmailModal = useSelector(AddressVisibleEmailModalSelector);
  const setVisibleEmailModal = useCallback(
    (visible: boolean) => {
      dispatch(setVisibleEmailModalReducer(visible));
    },
    [dispatch],
  );
  const visibleGroupModal = useSelector(AddressVisibleGroupModalSelector);
  const setVisibleGroupModal = useCallback(
    (visible: boolean) => {
      dispatch(setVisibleGroupModalReducer(visible));
    },
    [dispatch],
  );
  const isExecuteModalInSelect = useRef(false);

  const { data: groups, isFetching: isFetchingGroups } = useQuery<AddressInfo[], AxiosError>(
    [QUERY_KEY.ADDRESS_GROUPS],
    getAddressGroupList,
    {
      initialData: [],
      refetchOnWindowFocus: false,
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to response the list of group`, error);
      },
    },
  );

  const onClickMenuItem = useCallback(
    ({ key }: { key: React.Key }) => {
      if (!isExecuteModalInSelect.current) {
        if (+key === DEFAULT_ALL_ADDRESS_KEY) {
          dispatch(setSelectGroupReducer({ id: +key, name: DEFAULT_ALL_ADDRESS_NAME }));
        } else {
          const findGroup = groups?.find((item) => item.id === +key);
          if (findGroup) {
            const { id, name } = findGroup;
            dispatch(setSelectGroupReducer({ id, name }));
            queryClient.refetchQueries([QUERY_KEY.ADDRESS_EMAILS, id]);
          }
        }
      }
      isExecuteModalInSelect.current = false;
    },
    [dispatch, groups, queryClient],
  );

  const refreshEmailGroupList = useCallback(() => {
    queryClient.prefetchQuery([QUERY_KEY.ADDRESS_GROUPS]);
    queryClient.prefetchQuery([QUERY_KEY.ADDRESS_EMAILS, DEFAULT_ALL_ADDRESS_KEY]);
    dispatch(setSelectGroupReducer({ id: DEFAULT_ALL_ADDRESS_KEY, name: DEFAULT_ALL_ADDRESS_NAME }));
  }, [queryClient, dispatch]);

  const refreshGroupList = useCallback(() => {
    isExecuteModalInSelect.current = true;
    refreshEmailGroupList();
  }, [refreshEmailGroupList, isExecuteModalInSelect]);

  const openEmailAddModal = useCallback(() => {
    setVisibleEmailModal(true);
    dispatch(setEditEmailReducer(undefined));
  }, [dispatch, setVisibleEmailModal]);

  const openGroupAddModal = useCallback(() => {
    setVisibleGroupModal(true);
    dispatch(setEditGroupReducer(undefined));
  }, [dispatch, setVisibleGroupModal]);

  const openGroupEditModal = useCallback(
    (editGroup: AddressInfo) => {
      isExecuteModalInSelect.current = true;
      setVisibleGroupModal(true);
      dispatch(setEditGroupReducer(editGroup));
    },
    [dispatch, isExecuteModalInSelect, setVisibleGroupModal],
  );

  const openGroupDeleteModal = useCallback(
    (groupInfo: AddressInfo) => {
      isExecuteModalInSelect.current = true;
      openAntdModal('confirm', {
        className: 'delete_group',
        title: 'Delete Group',
        content: `Are you sure to delete group '${groupInfo.name}'?`,
        okText: 'Delete',
        maskClosable: true,
        onOk: async () => {
          try {
            await deleteAddressGroup(groupInfo.id);
            openNotification('success', 'Success', `Succeed to delete group '${groupInfo.name}'!`);
          } catch (e) {
            console.error(e);
            openNotification('error', 'Error', `Failed to delete group '${groupInfo.name}'!`, e as AxiosError);
          } finally {
            refreshEmailGroupList();
          }
        },
      });
    },
    [refreshEmailGroupList, isExecuteModalInSelect],
  );

  useEffect(() => {
    dispatch(initAddressStateReducer());
  }, []);

  return {
    groups,
    isFetchingGroups,
    onClickMenuItem,
    visibleGroupModal,
    setVisibleGroupModal,
    visibleEmailModal,
    setVisibleEmailModal,
    currentSelect,
    openEmailAddModal,
    openGroupAddModal,
    openGroupEditModal,
    openGroupDeleteModal,
    refreshGroupList,
  };
}
