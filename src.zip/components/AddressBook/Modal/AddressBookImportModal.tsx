import { InboxOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { usePostAddressImport } from '@libs/query/address';
import { openNotification } from '@libs/util/notification';
import { Modal } from 'antd';
import Dragger from 'antd/es/upload/Dragger';
import { AxiosError } from 'axios';
import React, { Fragment, useCallback, useEffect, useMemo, useState } from 'react';

type AddressBookImportModalProps = {
  visible: boolean;
  setVisible: React.Dispatch<React.SetStateAction<boolean>>;
  initialize: () => void;
};

export default function AddressBookImportModal({
  visible,
  setVisible,
  initialize,
}: AddressBookImportModalProps): JSX.Element {
  const [importFile, setImportFile] = useState<File | undefined>(undefined);

  const { mutate: mutateImportFile, isLoading: isImporting } = usePostAddressImport({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to import address book!`, error);
    },
    onSuccess: () => {
      openNotification('success', 'Success', 'Succeed to import address book.');
    },
    onSettled: () => {
      initialize();
      setVisible(false);
    },
  });

  const handleOk = useCallback(async () => {
    const formData = new FormData();
    formData.append('file', importFile as File);
    mutateImportFile(formData);
  }, [mutateImportFile, importFile]);

  const handleCancel = useCallback(() => {
    setVisible(false);
  }, [setVisible]);

  const draggerProps = useMemo(
    () => ({
      name: 'file',
      multiple: false,
      maxCount: 1,
      beforeUpload: (file: File) => {
        setImportFile(file);
        return false;
      },
      onRemove: () => {
        setImportFile(undefined);
      },
    }),
    [],
  );

  useEffect(() => {
    if (!visible) {
      setImportFile(undefined);
    }
  }, [visible]);

  return (
    <Modal
      title="Import Address Book"
      visible={visible}
      okText="Import"
      onOk={handleOk}
      okButtonProps={{ loading: isImporting, disabled: isImporting || !importFile }}
      onCancel={handleCancel}
      cancelButtonProps={{
        disabled: isImporting,
      }}
      closable={!isImporting}
      maskClosable={!isImporting}
      destroyOnClose // TODO: 다른 방법이 있을까???
    >
      <Fragment>
        <div css={warningStyle}>
          <div>All saved data will be deleted.</div>
          <div> Are you sure to import address book?</div>
        </div>
        <Dragger {...draggerProps}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">Click or drag file to this area to upload</p>
        </Dragger>
      </Fragment>
    </Modal>
  );
}

export const warningStyle = css`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  color: red;
  /* font-size: 1rem; */
  margin-bottom: 1rem;
`;
