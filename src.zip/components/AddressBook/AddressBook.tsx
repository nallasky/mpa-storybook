import { css } from '@emotion/react';
import React from 'react';
import AddressBookAddEditEmail from './AddressBookAddEditEmail';
import AddressBookAddEditGroup from './AddressBookAddEditGroup';
import AddressBookContent from './AddressBookContent';
import AddressBookSider from './AddressBookSider';

export type AddressBookProps = {
  children?: React.ReactNode;
};

export default function AddressBook({ children }: AddressBookProps): JSX.Element {
  return (
    <div css={style}>
      <AddressBookSider />
      <AddressBookContent />
      <AddressBookAddEditEmail />
      <AddressBookAddEditGroup />
    </div>
  );
}

const style = css`
  display: flex;
  flex-direction: row;
  width: 100%;
`;
