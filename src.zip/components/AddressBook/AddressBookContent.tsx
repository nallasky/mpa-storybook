import { DeleteOutlined, EditOutlined, ExportOutlined, ImportOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import RefreshBtn from '@components/common/atoms/RefreshBtn/RefreshBtn';
import { V_SPACE } from '@components/common/atoms/Space';
import TableHeader from '@components/common/atoms/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { AddressInfo } from '@libs/axios/types';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { DEFAULT_ALL_ADDRESS_KEY } from '@reducers/slices/address';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { Button, Empty, Space, Table } from 'antd';
import { useCallback, useMemo } from 'react';
import Highlighter from 'react-highlight-words';
import AsyncCreatableSelect from 'react-select/async-creatable';
import useAddressBookContent from './hooks/useAddressBookContent';
import AddressBookImportModal from './Modal/AddressBookImportModal';

export type AddressBookContentProps = {};

export default function AddressBookContent({}: AddressBookContentProps): JSX.Element {
  const {
    addressList,
    isFetchingAddress,
    rowSelection,
    handleChange,
    openEmailModal,
    selectedGroupId,
    selectedGroupName,
    searchedKeyword,
    openEmailDeleteModal,
    openExportModal,
    refreshAddressList,
    selectEmail,
    deboundcedSearch,
    handleCreate,
    onRow,
    selectRef,
    onSelectEscKeyPress,
    visibleImport,
    setVisibleImport,
    initializeData,
  } = useAddressBookContent();

  const titleRender = useCallback(() => {
    return (
      <TableHeader
        title={
          <div>
            {searchedKeyword
              ? `${selectedGroupName} (${addressList?.length ?? 0}) | ${searchedKeyword}`
              : `${selectedGroupName} | ${addressList?.length ?? 0}`}
          </div>
        }
        cssStyle={tableHeaderStyle}
      >
        {selectedGroupId === DEFAULT_ALL_ADDRESS_KEY && (
          <Button
            icon={<DeleteOutlined />}
            type="primary"
            onClick={openEmailDeleteModal}
            disabled={selectEmail.length === 0}
          >
            Delete
          </Button>
        )}
        <RefreshBtn onClick={refreshAddressList} loading={isFetchingAddress} />
      </TableHeader>
    );
  }, [
    selectedGroupId,
    selectedGroupName,
    addressList,
    openEmailDeleteModal,
    selectEmail,
    refreshAddressList,
    searchedKeyword,
    isFetchingAddress,
  ]);

  const deleteRender = useCallback(
    (value: number, record: AddressInfo, index: number) => (
      <EditOutlined css={hoverActiveStyle} onClick={() => openEmailModal(record)} />
    ),
    [openEmailModal],
  );

  const TableRender = useMemo(
    () => (
      <Table<AddressInfo>
        title={titleRender}
        rowKey={'id'}
        dataSource={isFetchingAddress ? undefined : addressList}
        bordered
        size="small"
        pagination={{
          position: ['bottomCenter'],
          total: addressList?.length ?? 0,
          showSizeChanger: true,
        }}
        rowSelection={rowSelection}
        loading={isFetchingAddress}
        tableLayout="fixed"
        locale={{
          emptyText: isFetchingAddress ? (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="Loading" />
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          ),
        }}
        onRow={onRow}
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<AddressInfo> {...columProps.name} />
        <Table.Column<AddressInfo> {...columProps.email} />
        <Table.Column<AddressInfo> {...columProps.edit} render={deleteRender} />
      </Table>
    ),
    [titleRender, isFetchingAddress, addressList, rowSelection, onRow, deleteRender],
  );

  const SelectRender = useMemo(
    () => (
      <div css={searchStyle}>
        <AsyncCreatableSelect
          className="search-address"
          classNamePrefix="address"
          formatOptionLabel={formatOptionLabel}
          placeholder="Search Name/Email Address"
          value={null}
          formatCreateLabel={(userInput) => `Search all list for '${userInput}'`}
          isSearchable
          loadOptions={deboundcedSearch}
          onChange={handleChange}
          onCreateOption={handleCreate}
          // focusDefaultOption={false}

          createOptionPosition="first"
          ref={selectRef}
          onKeyDown={onSelectEscKeyPress}
        />
        <Space>
          <AntdButton icon={<ImportOutlined />} type="primary" onClick={() => setVisibleImport(true)}>
            Import
          </AntdButton>
          <AntdButton icon={<ExportOutlined />} type="primary" onClick={openExportModal}>
            Export
          </AntdButton>
        </Space>
      </div>
    ),
    [deboundcedSearch, handleChange, handleCreate, selectRef, onSelectEscKeyPress, openExportModal, setVisibleImport],
  );

  return (
    <div css={style}>
      {SelectRender}
      <V_SPACE rem={0.6} />
      {TableRender}
      <AddressBookImportModal visible={visibleImport} setVisible={setVisibleImport} initialize={initializeData} />
    </div>
  );
}

function formatOptionLabel(
  { label, __isNew__ }: { label: string; __isNew__: boolean },
  { inputValue }: { inputValue: string },
) {
  return (
    <Highlighter
      searchWords={[inputValue]}
      textToHighlight={label}
      autoEscape={true}
      highlightStyle={{ padding: 0, fontWeight: 700, backgroundColor: 'transparent' }}
    />
  );
}

const style = css`
  display: flex;
  flex-direction: column;
  margin-left: 1rem;
  width: 100%;
`;

const tableHeaderStyle = css`
  .title {
    font-size: 1rem;
  }
`;

const searchStyle = css`
  display: flex;
  align-items: center;
  width: 100%;
  justify-content: space-between;
  .search-address {
    width: 40rem;

    .address__control {
      z-index: 100;
      border-radius: 2px;
      &:hover {
        border-color: #40a9ff;
      }
    }
    .address__menu {
      z-index: 100;
    }
  }
`;

export type ColumnName = 'name' | 'email' | 'edit';

const columProps: TableColumnPropsType<AddressInfo, ColumnName> = {
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'name'),
    },
    shouldCellUpdate: (cur, prev) => cur.name !== prev.name,
    width: getPixelPercent(1024, 437),
  },

  email: {
    key: 'email',
    title: <TableColumnTitle>Email</TableColumnTitle>,
    dataIndex: 'email',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'email'),
    },
    shouldCellUpdate: (cur, prev) => cur.email !== prev.email,
    width: getPixelPercent(1024, 437),
  },

  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    dataIndex: 'jobId',
    align: 'center',
    width: getPixelPercent(1024, 100),
  },
};
