import { CheckOutlined, HistoryOutlined, TagOutlined } from '@ant-design/icons';
import { CommonTableEmpty } from '@components/common/atoms/Common/Common';
import CustomBadgeSync from '@components/common/atoms/CustomBadge/CustomBadgeSync';
import CustomIcon from '@components/common/atoms/CustomIcon';
import StatusBadge from '@components/common/atoms/StatusBadge';
import StepMilestoneModal from '@components/common/atoms/StepMilestoneModal';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { convertStepType } from '@components/RemoteJob/Drawer/RemoteJobStepsDrawerCommon';
import { convertExecuteMode } from '@components/RemoteJob/RemoteJobSteps';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { errorIconStyle, hoverActiveStyle, tableRowErrorStyle } from '@styles/emotion/common';
import { AntdTableRowClassName } from '@typesdef/antd';
import { TableColumnPropsType } from '@typesdef/common';
import {
  AVAILABLE_MANUAL_EXECUTE_STEPS,
  JobModeType,
  JobStatusType,
  JobStepType,
  RemoteJobLastResultDate,
  RemoteJobStepStatus,
} from '@typesdef/Job';
import { Button, Popconfirm, Space, Table, Tooltip } from 'antd';
import { TableLocale } from 'antd/es/table/interface';
import React, { Fragment, useCallback, useMemo } from 'react';
import useRemoteJobStatusStepList from './hooks/useRemoteJobStatusStepList';

export type RemoteJobStatusStepListProps = {};

export default function RemoteJobStatusStepList({}: RemoteJobStatusStepListProps): JSX.Element {
  const {
    data,
    isError,
    loggedInUserRole,
    status,
    isMilestone,
    setMilestone,
    stepMilestone,
    executeManualStep,
    moveToHistoryLog,
    jobName,
  } = useRemoteJobStatusStepList();

  const dataLen = useMemo(() => data?.length ?? 0, [data]);

  const renderTitle = useCallback(
    () => (
      <TableHeader title={<TableHeaderTitle total={dataLen} />}>
        <CustomBadgeSync size="1.25rem" color={isError ? 'gray' : 'green'} marginRight="0.5rem" />
        <Button icon={<HistoryOutlined />} type="primary" onClick={() => setMilestone(true)}>
          Milestone
        </Button>
      </TableHeader>
    ),
    [dataLen, isError, setMilestone],
  );

  const renderEnable = useCallback((value: boolean, record: RemoteJobStepStatus, index: number) => {
    return value ? <CheckOutlined /> : undefined;
  }, []);

  const renderStatus = useCallback(
    (value: JobStatusType, record: RemoteJobStepStatus, index: number) => (
      <StatusBadge
        value={value}
        onClick={() =>
          moveToHistoryLog({
            jobType: 'remote',
            jobName: jobName as string,
            jobId: record.jobId as number,
            stepId: record.stepId as number,
            stepType: record.stepType as JobStepType,
            stepName: record.stepName as string,
          })
        }
      />
    ),
    [moveToHistoryLog, jobName],
  );

  const renderStepType = useCallback((value: JobStepType, record: RemoteJobStepStatus, index: number) => {
    return <div>{convertStepType(value)}</div>;
  }, []);

  const renderExecuteMode = useCallback(
    (value: JobModeType, record: RemoteJobStepStatus, index: number) => {
      let title: React.ReactNode = null;
      let isSuccess = false;
      const { time, period, cycle, preStep, nextStep } = record;

      switch (value) {
        case 'time': {
          isSuccess = Array.isArray(time) && time.length > 0;
          title = isSuccess ? (
            <Fragment>
              {record.time.map((item) => (
                <div key={item}>{item}</div>
              ))}
            </Fragment>
          ) : (
            'No Time Data'
          );
          break;
        }
        case 'cycle': {
          isSuccess = Boolean(period && cycle);
          title = isSuccess ? (
            <Fragment>
              <div>{Array.isArray(time) && time.length > 0 && `Start Time : ${record.time[0]}`}</div>
              <div>
                {record.period &&
                  record.cycle &&
                  `Cycle : ${record.period} ${record.cycle[0].toUpperCase() + record.cycle.slice(1)}`}
              </div>
            </Fragment>
          ) : (
            'No Cycle Data'
          );
          break;
        }
        case 'pre': {
          const stepName = data?.find((item) => item.uuid === record.preStep)?.stepName;
          isSuccess = Boolean(stepName);
          title = isSuccess ? stepName : 'No Previous Step Data';
          break;
        }
        case 'next': {
          const stepName = data?.find((item) => item.uuid === record.nextStep)?.stepName;
          isSuccess = Boolean(stepName);
          title = isSuccess ? stepName : 'No Next Step Data';
          break;
        }
        case 'none':
        default:
          isSuccess = true;
          break;
      }

      return (
        <Tooltip placement="right" title={title} color={isSuccess ? undefined : 'red'}>
          <Space
            css={
              !isSuccess &&
              css`
                color: red;
              `
            }
          >
            {convertExecuteMode(value)}
            {!isSuccess && <CustomIcon name="warning" />}
          </Space>
        </Tooltip>
      );
    },
    [data],
  );

  const renderLast = useCallback(
    (value: RemoteJobLastResultDate, record: RemoteJobStepStatus, index: number) => {
      const lastResult = value.key === 'lastSuccess' ? record.lastSuccess : record.lastFailure;

      if (!lastResult) {
        return <div>-</div>;
      }

      return (
        <Space>
          <div
            css={hoverActiveStyle}
            onClick={() =>
              moveToHistoryLog({
                jobType: 'remote',
                jobName: jobName as string,
                jobId: record.jobId as number,
                stepId: record.stepId as number,
                stepType: record.stepType as JobStepType,
                stepName: record.stepName as string,
                historyId: lastResult.historyId as string,
              })
            }
          >
            {lastResult.date}
          </div>
          {lastResult.error.length > 0 && (
            <Tooltip
              placement="top"
              title={lastResult.error.map((item) => (
                <div key={item}>{item}</div>
              ))}
              color="red"
            >
              <CustomIcon css={errorIconStyle} name="warning" />
              {/* it need to diplay tooltip */}
              <div></div>
            </Tooltip>
          )}
        </Space>
      );
    },
    [moveToHistoryLog, jobName],
  );

  const renderManual = useCallback(
    (value: number, record: RemoteJobStepStatus, index: number) => {
      const { jobId, stepId, stepName } = record;

      if (!loggedInUserRole.ROLE_JOB) {
        return <div>-</div>;
      }

      if (!AVAILABLE_MANUAL_EXECUTE_STEPS.includes(record.stepType)) {
        return (
          <Tooltip title="This step does not support Manual Execute." placement="right" color="gray">
            <div
              css={css`
                color: gray;
                cursor: not-allowed !important;
              `}
            >
              -
            </div>
          </Tooltip>
        );
      }

      return (
        <Popconfirm
          title="Are you sure to execute step manually?"
          okText="Execute"
          // okButtonProps={{ type: 'primary', disabled: (status?.stop ?? true) || !loggedInUser.roles.isRoleJob }}
          okButtonProps={{ type: 'primary', disabled: !loggedInUserRole.ROLE_JOB }}
          onConfirm={() => executeManualStep({ jobId, stepId, stepName })}
          placement="left"
        >
          <TagOutlined css={hoverActiveStyle} />
        </Popconfirm>
      );
    },
    [loggedInUserRole, executeManualStep],
  );

  const tableLocale = useMemo<TableLocale>(
    () => ({
      emptyText: <CommonTableEmpty isError={isError} />,
    }),
    [isError],
  );

  return (
    <div css={style}>
      <RemoteJobStatusStepListTable
        data={data}
        tableLocale={tableLocale}
        renderTitle={renderTitle}
        renderEnable={renderEnable}
        renderStatus={renderStatus}
        renderStepType={renderStepType}
        renderExecuteMode={renderExecuteMode}
        renderLast={renderLast}
        renderManual={renderManual}
      />
      <StepMilestoneModal steps={stepMilestone} visible={isMilestone} setVisible={setMilestone} />
    </div>
  );
}

interface RemoteJobStatusStepListTableProps {
  data: RemoteJobStepStatus[] | undefined;
  tableLocale: TableLocale;
  renderTitle: () => JSX.Element;
  renderEnable: (value: boolean, record: RemoteJobStepStatus, index: number) => JSX.Element | undefined;
  renderStatus: (value: JobStatusType, record: RemoteJobStepStatus, index: number) => JSX.Element;
  renderStepType: (value: JobStepType, record: RemoteJobStepStatus, index: number) => JSX.Element;
  renderExecuteMode: (value: JobModeType, record: RemoteJobStepStatus, index: number) => JSX.Element;
  renderLast: (value: RemoteJobLastResultDate, record: RemoteJobStepStatus, index: number) => JSX.Element;
  renderManual: (value: number, record: RemoteJobStepStatus, index: number) => JSX.Element;
}

const RemoteJobStatusStepListTable = React.memo(function RemoteJobStatusStepListMemo({
  data,
  tableLocale,
  renderTitle,
  renderEnable,
  renderStatus,
  renderStepType,
  renderExecuteMode,
  renderLast,
  renderManual,
}: RemoteJobStatusStepListTableProps) {
  const rowClassName: Exclude<AntdTableRowClassName<RemoteJobStepStatus>, string> = useCallback((record) => {
    if (record.status === 'failure') {
      return 'error-mark';
    }
    return '';
  }, []);

  return (
    <Table<RemoteJobStepStatus>
      rowKey={'stepId'}
      rowClassName={rowClassName}
      dataSource={data ?? []}
      bordered
      title={renderTitle}
      size="small"
      pagination={{
        position: ['bottomCenter'],
        showSizeChanger: true,
      }}
      tableLayout="fixed"
      locale={tableLocale}
      css={tableRowErrorStyle}
      sticky={{ offsetHeader: NAV_BAR_HIGHT }}
    >
      <Table.Column<RemoteJobStepStatus> {...columnProps.enable} render={renderEnable} />
      <Table.Column<RemoteJobStepStatus> {...columnProps.status} render={renderStatus} />
      <Table.Column<RemoteJobStepStatus> {...columnProps.stepName} />
      <Table.Column<RemoteJobStepStatus> {...columnProps.stepType} render={renderStepType} />
      <Table.Column<RemoteJobStepStatus> {...columnProps.executeMode} render={renderExecuteMode} />
      <Table.Column<RemoteJobStepStatus> {...columnProps.lastSuccessDate} render={renderLast} />
      <Table.Column<RemoteJobStepStatus> {...columnProps.lastFailureDate} render={renderLast} />
      <Table.Column<RemoteJobStepStatus> {...columnProps.execute} render={renderManual} />
    </Table>
  );
});

const style = css`
  margin-top: 1rem;
  width: 100%;
  .ant-table {
    .ant-table-tbody {
      .ant-table-cell.stepName,
      .ant-table-cell.stepType,
      .ant-table-cell.mode {
        cursor: default;
      }
    }
  }
`;

type ColumnName =
  | 'enable'
  | 'status'
  | 'stepName'
  | 'stepType'
  | 'executeMode'
  | 'lastSuccessDate'
  | 'lastFailureDate'
  | 'execute';

const columnProps: TableColumnPropsType<RemoteJobStepStatus, ColumnName> = {
  enable: {
    key: 'enable',
    title: <TableColumnTitle>Enable</TableColumnTitle>,
    dataIndex: 'enable',
    className: 'enable',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'enable'),
    },
    width: getPixelPercent(1080, 80),
  },
  status: {
    key: 'status',
    title: <TableColumnTitle>Status</TableColumnTitle>,
    dataIndex: 'status',
    className: 'status',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'status'),
    },
    width: getPixelPercent(1080, 120),
  },
  stepName: {
    key: 'stepName',
    title: <TableColumnTitle>Step Name</TableColumnTitle>,
    dataIndex: 'stepName',
    className: 'stepName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'stepName'),
    },
    width: getPixelPercent(1080, 200),
  },
  stepType: {
    key: 'stepType',
    title: <TableColumnTitle>Step Type</TableColumnTitle>,
    dataIndex: 'stepType',
    className: 'stepType',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'stepType'),
    },
    width: getPixelPercent(1080, 160),
  },
  executeMode: {
    key: 'mode',
    title: <TableColumnTitle>Execute Mode</TableColumnTitle>,
    dataIndex: 'mode',
    className: 'mode',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'mode'),
    },
    width: getPixelPercent(1080, 140),
  },
  lastSuccessDate: {
    key: 'lastSuccessDate',
    title: <TableColumnTitle>Last Success</TableColumnTitle>,
    dataIndex: 'lastSuccessDate',
    className: 'lastSuccessDate',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a.lastSuccessDate, b.lastSuccessDate, 'date'),
    },
    width: getPixelPercent(1080, 150),
  },
  lastFailureDate: {
    key: 'lastFailureDate',
    title: <TableColumnTitle>Last Failure</TableColumnTitle>,
    dataIndex: 'lastFailureDate',
    className: 'lastFailureDate',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a.lastFailureDate, b.lastFailureDate, 'date'),
    },
    width: getPixelPercent(1080, 150),
  },
  execute: {
    key: 'execute',
    title: (
      <TableColumnTitle>
        <div>Manual</div>
        <div>Execute</div>
      </TableColumnTitle>
    ),
    dataIndex: 'stepId',
    className: 'execute',
    align: 'center',
    width: getPixelPercent(1080, 80),
  },
};
