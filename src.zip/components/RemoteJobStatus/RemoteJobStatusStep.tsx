import CustomIcon from '@components/common/atoms/CustomIcon';
import { H_SPACE } from '@components/common/atoms/Space';
import { ContentWrapper } from '@components/common/atoms/Wrapper';
import { css } from '@emotion/react';
import { PageHeader, Popconfirm, Space } from 'antd';
import { useMemo } from 'react';
import useRemoteJobStatusStep from './hooks/useRemoteJobStatusStep';
import RemoteJobStatusStepBuild from './RemoteJobStatusStepBuild';
import RemoteJobStatusStepList from './RemoteJobStatusStepList';

export type RemoteJobStatusStepProps = {};

export default function RemoteJobStatusStep({}: RemoteJobStatusStepProps): JSX.Element {
  const { name, status, onBack, onClickStartStop, loggedInUserRole } = useRemoteJobStatusStep();
  const title = useMemo(() => {
    const isStop = status?.stop;

    if (isStop === undefined) {
      <Space>
        <div>Job Step Status</div>
        <div>|</div>
        <Space css={statusIconStyle}>
          <CustomIcon className="unknown" name="stop" />
          <span>{name}</span>
        </Space>
      </Space>;
    }

    return (
      <Space>
        <div>Job Step Status</div>
        <div>|</div>
        <Space css={statusIconStyle}>
          <Popconfirm
            title={`Are you sure to ${isStop ? 'start' : 'stop'} job?`}
            okText="Ok"
            okButtonProps={{ type: 'primary', disabled: !loggedInUserRole.ROLE_JOB }}
            onConfirm={onClickStartStop}
          >
            <CustomIcon className={isStop ? 'stopped' : 'running'} name={isStop ? 'stop' : 'play'} />
          </Popconfirm>
          <span>{name}</span>
        </Space>
      </Space>
    );
  }, [status, name, onClickStartStop, loggedInUserRole]);

  return (
    <ContentWrapper css={wrapperStyle}>
      <PageHeader
        onBack={onBack}
        title={title}
        css={css`
          padding: 0 0 0.5rem 0;
          width: 85rem;
        `}
      />
      <div className="container">
        <RemoteJobStatusStepBuild />
        <H_SPACE />
        <RemoteJobStatusStepList />
      </div>
    </ContentWrapper>
  );
}

const wrapperStyle = css`
  .container {
    width: 100%;
    display: flex;
    flex-direction: row;
  }
`;

const statusIconStyle = css`
  .running {
    color: #52c41a;
    -webkit-animation: blink 1s ease-in-out infinite alternate;
    animation: blink 1s ease-in-out infinite alternate;
    @keyframes blink {
      0% {
        opacity: 0;
      }
      100% {
        opacity: 1;
      }
    }
  }

  .stopped {
    color: #ff4d4f;
  }

  .unknown {
    color: #b3b3b3;
  }
`;
