import { css } from '@emotion/react';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Modal, Space, Spin } from 'antd';
import React from 'react';
import useRemoteJobStatusExport from '../hooks/useRemoteJobStatusExport';

export default React.memo(function RemoteJobStatusExport({ visible, onClose }: GlobalModalDefaultProps): JSX.Element {
  const { customData, isFetchingCustom, isErrorCustom, onOk, isLoadingExport } = useRemoteJobStatusExport({
    visible,
    onClose,
  });

  return (
    <Modal
      title={'Export Job'}
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width="400px"
      destroyOnClose
      cancelButtonProps={{
        disabled: isFetchingCustom,
      }}
      okText="Export"
      okButtonProps={{
        loading: isLoadingExport,
        disabled: isFetchingCustom || isLoadingExport,
      }}
      maskClosable={!isFetchingCustom}
    >
      <div>
        {isFetchingCustom ? (
          <CheckRemoteJob />
        ) : isErrorCustom ? (
          <CheckRemoteJobError />
        ) : customData && customData.custom ? (
          <Space>
            <ExistCustomStep />
          </Space>
        ) : (
          <div>Are you sure to export job?</div>
        )}
      </div>
    </Modal>
  );
});

const CheckRemoteJob = () => (
  <Space>
    <Spin /> Checking Job Data...
  </Space>
);

const CheckRemoteJobError = () => (
  <Space>
    <div
      css={css`
        color: red;
      `}
    >
      Fail to collecting Job Data!
    </div>
  </Space>
);

const ExistCustomStep = () => (
  <Space>
    <div
      css={css`
        color: red;
      `}
    >
      <div>A custom step exists in the job.</div>
      <div>When exporting, custom steps are excluded.</div>
    </div>
  </Space>
);
