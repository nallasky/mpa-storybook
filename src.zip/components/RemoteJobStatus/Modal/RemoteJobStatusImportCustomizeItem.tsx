import { ExclamationCircleOutlined } from '@ant-design/icons';
import { H_SPACE, V_SPACE } from '@components/common/atoms/Space';
import { NAME_MAX_LENGTH } from '@constants/constants';
import { css } from '@emotion/react';
import { useRemoteJobImportContext } from '@libs/context/RemoteJobImportProvider';
import { useGetUserFabNameList } from '@libs/query/common';
import { useGetRemoteJobPlans } from '@libs/query/remoteJob';
import { useGetSystemConfigFtpList } from '@libs/query/systemConfig';
import { hoverActiveStyleDefColor } from '@styles/emotion/common';
import { RemoteJobFTP, RemoteJobImportDataStep } from '@typesdef/Job';
import { Badge, Checkbox, Input, List, Menu, MenuProps, Select, Space, Tabs, TabsProps } from 'antd';
import { DefaultOptionType } from 'antd/es/select';
import React, { Fragment, useEffect, useMemo } from 'react';

export interface RemoteJobImportContentProps {
  mode: 'import' | 'copy';
}

export function RemoteJobImportContent({ mode }: RemoteJobImportContentProps) {
  const { jobData, jobIdx, setJobIdx, errorJobs } = useRemoteJobImportContext();

  const jobNameItems: MenuProps['items'] = jobData.map(({ jobName }, index) => {
    const { errors, isError } = errorJobs[index] ?? {
      errors: { isJobName: false, isDupJobName: false, isSiteId: false, collectNames: [] },
      isError: false,
    };

    return getItem(
      <div css={menuStyle(isError)}>
        <div className="name">{jobName}</div>
        {isError && (
          <div className="error">
            <ExclamationCircleOutlined css={[styleRed]} />
            <div className="error-msg">{getImportErrorMsg(errors)}</div>
          </div>
        )}
      </div>,
      index,
    );
  });

  useEffect(() => {
    if (mode === 'copy' && jobData.length > 0) {
      setJobIdx(0);
    }
  }, []);

  return (
    <div css={style}>
      <Menu
        selectedKeys={jobIdx !== null ? [jobIdx.toString()] : []}
        onClick={(value) => {
          setJobIdx(+value.key);
        }}
        mode="inline"
        items={jobNameItems}
        css={css`
          .ant-menu-item {
            height: 3rem;
          }
        `}
      />
      <RemoteJobImportContentInfo />
    </div>
  );
}

const getImportErrorMsg = ({
  isJobName,
  isDupJobName,
  isSiteId,
  collectNames,
}: {
  isJobName: boolean;
  isDupJobName: boolean;
  isSiteId: boolean;
  collectNames: string[];
}) => {
  if (isJobName) return 'No Job Name!';
  if (isDupJobName) return 'Duplicate Job Name!';
  if (isSiteId) return 'No User Fab Name!';
  if (collectNames.length > 0) return 'No Collect Plans!';

  return 'Error';
};

const style = css`
  display: flex;
  .ant-menu {
    width: 210px;
    height: 35rem;
    overflow-x: hidden;
    overflow-y: auto;
  }
  .job-info {
    margin-left: 1rem;
  }
`;

const styleRed = css`
  color: red;
`;

type MenuItem = Required<MenuProps>['items'][number];

function getItem(
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[],
  type?: 'group',
): MenuItem {
  return {
    key,
    icon,
    children,
    label,
    type,
  } as MenuItem;
}

const menuStyle = (isError: boolean) => css`
  display: flex;
  flex-direction: column;
  justify-content: center;

  .name {
    width: 170px;
    align-items: center;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    ${isError
      ? css`
          line-height: 1.5rem;
          height: 1.5rem;
        `
      : css`
          line-height: 3rem;
          height: 3rem;
        `}
  }

  .error {
    color: red;
    font-size: 0.75rem;
    display: flex;
    align-items: center;
    height: 1rem;
    .error-msg {
      margin-left: 0.25rem;
      height: 1rem;
      line-height: 1rem;
    }
  }
`;

export function RemoteJobImportContentInfo() {
  const { jobIdx, jobData, curJob, errorJobs, setJobName, setSiteId, setPlanIds } = useRemoteJobImportContext();
  const curJobData =
    jobIdx !== null
      ? jobData[jobIdx]
      : {
          jobId: null,
          jobName: null,
          siteId: null,
          steps: [],
        };

  const { data: siteList, isFetching: isFetchingSiteList } = useGetUserFabNameList({
    enabled: jobIdx !== null,
  });

  const siteOptions: DefaultOptionType[] = useMemo(
    () =>
      siteList?.map((item) => ({
        label: item.crasCompanyFabName,
        value: item.siteId,
        key: item.siteId,
      })) ?? [],
    [siteList],
  );

  const collectSteps = useMemo(
    () => curJob?.steps?.filter((step) => step.stepType === 'collect') ?? [],
    [curJob?.steps],
  );

  const tabPanes: NonNullable<TabsProps['items']> = useMemo(
    () =>
      collectSteps.map((item, idx) => ({
        key: item.uuid ?? String(idx),
        label: item.stepName,
        children: <RemoteJobImportContentInfoPlan stepData={item} />,
      })),
    [collectSteps],
  );

  const getErrorMsgJobName = () => {
    if (jobIdx !== null) {
      if (errorJobs[jobIdx]?.errors.isJobName) {
        return 'Please input a Job Name!';
      }
      if (errorJobs[jobIdx]?.errors.isDupJobName) {
        return 'Duplicate Job Name!';
      }
    }
    return '';
  };

  const getErrorMsgSiteId = () => {
    if (jobIdx !== null && errorJobs[jobIdx]?.errors.isSiteId) {
      return 'Please select a User Fab Name!';
    }
    return '';
  };

  const getErrorMsgCollectNames = () => {
    if (jobIdx !== null && errorJobs[jobIdx].errors.collectNames && errorJobs[jobIdx].errors.collectNames.length > 0) {
      return `Please select plans for ${errorJobs[jobIdx].errors.collectNames[0]}!`;
    }
    return '';
  };

  const onClearCollectPlans = () => {
    if (jobIdx !== null) {
      collectSteps.forEach((step) => {
        if (step.uuid) {
          setPlanIds({
            jobIdx,
            planIds: [],
            type: 'all',
            uuid: step.uuid,
          });
        }
      });
    }
  };

  return (
    <div css={jobInfoStyle}>
      {jobIdx !== null && (
        <Fragment>
          <RemoteJobImportContentInfoItem title="Job Name" errorMsg={getErrorMsgJobName()}>
            <Input
              status={getErrorMsgJobName() ? 'error' : ''}
              value={curJobData.jobName ?? undefined}
              onChange={({ target: { value } }) => jobIdx !== null && setJobName(jobIdx, value)}
              maxLength={NAME_MAX_LENGTH}
            />
          </RemoteJobImportContentInfoItem>
          <RemoteJobImportContentInfoItem title="User Fab Name" errorMsg={getErrorMsgSiteId()}>
            <Select
              value={curJobData.siteId ?? null}
              options={siteOptions}
              onSelect={(value: number) => {
                setSiteId(jobIdx, value);
                if (curJobData.siteId !== value) {
                  onClearCollectPlans();
                }
              }}
              onClear={() => {
                setSiteId(jobIdx, null);
                onClearCollectPlans();
              }}
              allowClear
              status={getErrorMsgSiteId() ? 'error' : ''}
              loading={isFetchingSiteList}
              disabled={isFetchingSiteList}
            />
          </RemoteJobImportContentInfoItem>
          {tabPanes.length > 0 ? (
            <RemoteJobImportContentInfoItem
              title="Collect Plan"
              direction="vertical"
              errorMsg={getErrorMsgCollectNames()}
            >
              <Tabs tabPosition="top" items={tabPanes} />
            </RemoteJobImportContentInfoItem>
          ) : (
            <RemoteJobImportContentInfoItem title="Collect Plan">None</RemoteJobImportContentInfoItem>
          )}
        </Fragment>
      )}
    </div>
  );
}

const jobInfoStyle = css`
  display: flex;
  flex-direction: column;
  margin-left: 1rem;

  .item:not(:nth-last-of-type(1)) {
    margin-bottom: 1rem;
  }
`;

function RemoteJobImportContentInfoItem({
  title,
  children,
  direction = 'horizontal',
  errorMsg,
}: {
  title: string;
  children: React.ReactNode;
  direction?: 'vertical' | 'horizontal';
  errorMsg?: string;
}) {
  return (
    <div css={jobInfoItemStyle(direction)} className="item">
      {direction === 'horizontal' ? (
        <Fragment>
          <div className="set-item">
            <div className="title">
              <Space size={2}>
                <Badge color="blue" />
                {title}
              </Space>
            </div>
            <div className="value">{children}</div>
          </div>
          <div className="error">{errorMsg}</div>
        </Fragment>
      ) : (
        <Fragment>
          <div className="set-item">
            <div className="title">
              <Space size={2}>
                <Badge color="blue" />
                {title}
              </Space>
            </div>
            <div className="error">{errorMsg}</div>
          </div>
          <div className="value">{children}</div>
        </Fragment>
      )}
    </div>
  );
}

const jobInfoItemStyle = (direction: 'vertical' | 'horizontal') => css`
  ${direction === 'horizontal' &&
  css`
    display: flex;
    flex-direction: column;
    .set-item {
      display: flex;
      .title {
        width: 10rem;
      }
      .value {
        width: 25rem;
        .ant-select-selector {
          width: 25rem;
        }
      }
    }
    .error {
      height: 1rem;
      margin-left: 10rem;
      color: red;
    }
  `}
  ${direction === 'vertical' &&
  css`
    display: flex;
    flex-direction: column;
    .set-item {
      display: flex;
      flex-direction: row;
      .title {
        width: 10rem;
      }
      .error {
        width: 25rem;
        color: red;
      }
    }
    .value {
      width: 45rem;
    }
  `}
`;

interface RemoteJobImportContentInfoPlanProps {
  stepData: RemoteJobImportDataStep;
}

export function RemoteJobImportContentInfoPlan({ stepData }: RemoteJobImportContentInfoPlanProps) {
  const { jobIdx, curJob, setPlanIds, setFtps } = useRemoteJobImportContext();

  const { data: plans, isFetching: isFetchingPlans } = useGetRemoteJobPlans(curJob?.siteId as number, {
    enabled: Boolean(curJob?.siteId),
  });

  const { data: ftps, isFetching: isFetchingFtps } = useGetSystemConfigFtpList();

  const planList = plans?.map(
    (item) =>
      ({
        planId: item.planId,
        planName: item.planName,
      } ?? []),
  );

  const ftpList = ftps?.map(
    (ftp) =>
      ({
        id: ftp.id,
        type: ftp.type,
        name: ftp.name,
      } ?? []),
  );

  const onCheckPlan = ({
    jobIdx,
    planId,
    type,
    uuid,
  }: {
    jobIdx: number | null;
    uuid: string | null;
    type: 'all' | 'one';
    planId: number;
  }) => {
    if (uuid !== null && jobIdx !== null) {
      setPlanIds({
        jobIdx,
        planIds: [planId],
        type,
        uuid,
      });
    }
  };

  const onCheckFtp = ({ jobIdx, ftp, uuid }: { jobIdx: number | null; uuid: string | null; ftp: RemoteJobFTP }) => {
    if (uuid !== null && jobIdx !== null) {
      setFtps({
        jobIdx,
        ftp,
        uuid,
      });
    }
  };

  return (
    <div css={jobInfoItemPlanStyle}>
      <div className="section">
        <div className="content">
          <div className="title">
            <Space>
              <Badge color="green" />
              {`Plans (${stepData?.planIds.length ?? 0})`}
            </Space>
          </div>
          <List
            className="plans-list"
            dataSource={planList}
            renderItem={(item, index) => (
              <div className="list-item" key={index}>
                <Space>
                  <Checkbox
                    checked={stepData.planIds.includes(item.planId)}
                    onChange={() => onCheckPlan({ jobIdx, planId: item.planId, type: 'one', uuid: stepData.uuid })}
                  />
                  <div
                    className="name"
                    onClick={() => onCheckPlan({ jobIdx, planId: item.planId, type: 'one', uuid: stepData.uuid })}
                    css={hoverActiveStyleDefColor}
                  >
                    {item.planName}
                  </div>
                </Space>
              </div>
            )}
          />
        </div>
        <div className="content">
          <Space>
            <Badge color="green" />
            {`Origin Plans (${stepData?.planNames?.length ?? 0})`}
          </Space>
          <List
            className="plans-list"
            dataSource={stepData?.planNames ?? []}
            renderItem={(item) => (
              <div>
                <div>{item as any}</div>
              </div>
            )}
          />
        </div>
      </div>
      <div className="section">
        <div className="content">
          <div className="title">
            <Space>
              <Badge color="green" />
              {`FTP/SFTP (${stepData?.ftps?.length ?? 0})`}
            </Space>
          </div>
          <List
            className="ftps-list"
            dataSource={ftpList}
            renderItem={(item, index) => (
              <div className="list-item" key={index}>
                <Space>
                  <Checkbox
                    checked={stepData?.ftps?.some((ftp) => ftp.id === item.id) ?? false}
                    onChange={() => onCheckFtp({ jobIdx, ftp: item, uuid: stepData.uuid })}
                  />
                  <div
                    className="name"
                    onClick={() => onCheckFtp({ jobIdx, ftp: item, uuid: stepData.uuid })}
                    css={hoverActiveStyleDefColor}
                  >
                    {`[${item.type}] ${item.name}`}
                  </div>
                </Space>
              </div>
            )}
          />
        </div>
        <div className="content">
          <Space>
            <Badge color="green" />
            {`Origin FTP/SFTP (${stepData?.ftpNames?.length ?? 0})`}
          </Space>
          <List
            className="ftps-list"
            dataSource={stepData?.ftpNames ?? []}
            renderItem={(item) => (
              <div>
                <div>{item as any}</div>
              </div>
            )}
          />
        </div>
      </div>
    </div>
  );
}

const jobInfoItemPlanStyle = css`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  .section {
    display: flex;
    justify-content: space-around;
    .content {
      width: 21.25rem;
      display: flex;
      flex-direction: column;
      .title {
        margin-bottom: 0.5rem;
      }
      border: 1px solid #f0f0f0;
      padding: 1rem;

      .plans-list.ant-list {
        height: 10rem;
      }

      .ftps-list.ant-list {
        height: 10em;
      }

      .ant-list {
        overflow-y: auto;
        width: 19rem;
        .list-item {
          .name {
            width: 16rem;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
        }
      }
    }
  }
`;
