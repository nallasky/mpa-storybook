import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Input, Modal, Select } from 'antd';
import React from 'react';
import useRemoteJobStatusCopyJob from '../hooks/useRemoteJobStatusCopyJob';

export default React.memo(function RemoteJobStatusCopyJob({ visible, onClose }: GlobalModalDefaultProps): JSX.Element {
  const { form, onOk, jobOptions, isFetchingJobList, isFetchingCopy } = useRemoteJobStatusCopyJob({
    visible,
    onClose,
  });
  return (
    <Modal
      title={'Select Copy Job'}
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width="550px"
      destroyOnClose
      cancelButtonProps={{
        disabled: isFetchingCopy,
      }}
      okText="Copy"
      okButtonProps={{
        loading: isFetchingCopy,
        disabled: isFetchingJobList || isFetchingCopy,
      }}
      maskClosable={!isFetchingCopy}
    >
      <Form form={form} labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
        <Form.Item
          label="Select Job Name"
          name="selectJob"
          required
          rules={[{ required: true, message: 'Please select a job name!' }]}
        >
          <Select
            showSearch
            filterOption={(input, option) =>
              option && option.label
                ? (option.label as unknown as string).toLowerCase().includes(input.toLowerCase())
                : false
            }
            options={jobOptions}
            loading={isFetchingJobList}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
});
