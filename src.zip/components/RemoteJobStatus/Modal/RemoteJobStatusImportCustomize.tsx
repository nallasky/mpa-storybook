import { css } from '@emotion/react';
import RemoteJobImportProvider from '@libs/context/RemoteJobImportProvider';
import { RemoteJobImportData } from '@typesdef/Job';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Modal } from 'antd';
import React from 'react';
import useRemoteJobStatusImportCustomize from '../hooks/useRemoteJobStatusImportCustomize';
import { RemoteJobImportContent } from './RemoteJobStatusImportCustomizeItem';

export interface RemoteJobStatusImportCustomizeProps {
  data: RemoteJobImportData;
  mode?: 'import' | 'copy';
}

export default React.memo(function RemoteJobStatusImportCustomize({
  visible,
  onClose,
  data,
  mode = 'import',
}: GlobalModalDefaultProps<RemoteJobStatusImportCustomizeProps>): JSX.Element {
  return (
    <RemoteJobImportProvider data={data}>
      <ModalWrapper visible={visible} onClose={onClose} mode={mode}>
        <RemoteJobImportContent mode={mode} />
      </ModalWrapper>
    </RemoteJobImportProvider>
  );
});

function ModalWrapper({
  visible,
  onClose,
  mode,
  children,
}: GlobalModalDefaultProps<Omit<RemoteJobStatusImportCustomizeProps, 'data'>> & {
  children: React.ReactNode;
}): JSX.Element {
  const { onOk, isLoadingImport, isError, jobDataLen, modeText } = useRemoteJobStatusImportCustomize({
    visible,
    onClose,
    mode,
  });

  if (jobDataLen === 0) {
    return (
      <Modal
        title={'Clear Job'}
        open={visible}
        onOk={onOk}
        onCancel={onClose}
        width="500px"
        destroyOnClose
        cancelButtonProps={{
          disabled: isLoadingImport,
        }}
        okText="Clear"
        okButtonProps={{
          loading: isLoadingImport,
          disabled: isLoadingImport,
        }}
        maskClosable={!isLoadingImport}
      >
        <div
          css={css`
            display: flex;
            flex-direction: column;
            align-items: center;
            color: red;
          `}
        >
          <div>There are not jobs in imported excel file.</div>
          <div>if you import this file, all jobs are cleared.</div>
        </div>
      </Modal>
    );
  }

  return (
    <Modal
      title={`Customize ${modeText} Job`}
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width="1000px"
      destroyOnClose
      cancelButtonProps={{
        disabled: isLoadingImport,
      }}
      okText={modeText}
      okButtonProps={{
        loading: isLoadingImport,
        disabled: isLoadingImport || isError,
      }}
      maskClosable={!isLoadingImport}
    >
      {children}
    </Modal>
  );
}
