import { openAntdModal } from '@components/common/atoms/AntdModal';
import FileImportModal, { FileImportModalProps } from '@components/common/atoms/FileImportModal/FileImportModal';
import { API_URL, PAGE_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import useMoveToHistoryLog from '@hooks/useMoveToHistoryLog';
import {
  deleteRemoteJob,
  getStatusRemoteJobStop,
  getStatusRemoteJobStopAll,
  patchRequest,
  startRemoteJob,
  stopRemoteJob,
} from '@libs/axios/requests';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { useGetRemoteJobList } from '@libs/query/remoteJob';
import { validateImportJob } from '@libs/util/job';
import { openNotification } from '@libs/util/notification';
import { loginUserRoleBooleanSelector, loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import type { RemoteJobImportData } from '@typesdef/Job';
import { AxiosError } from 'axios';
import { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import RemoteJobStatusCopyJob from '../Modal/RemoteJobStatusCopyJob';
import RemoteJobStatusExport from '../Modal/RemoteJobStatusExport';
import RemoteJobStatusImportCustomize, {
  RemoteJobStatusImportCustomizeProps,
} from '../Modal/RemoteJobStatusImportCustomize';

export default function useRemoteJobStatus() {
  const navigate = useNavigate();
  const [isError, setError] = useState(false);
  const loggedInUser = useTypedSelector(loginUserSelector);
  const loggedInUserRole = useTypedSelector(loginUserRoleBooleanSelector);
  const { moveToHistoryLog } = useMoveToHistoryLog();
  const { openModal } = useModals();

  const { data, isFetching, refetch } = useGetRemoteJobList({
    refetchInterval: 3000,
    onError: () => {
      if (!isError) {
        setError(true);
        openNotification('error', 'Error', `Failed to response the status of job!`);
      }
    },
    onSuccess: () => {
      setError(false);
    },
  });

  const moveToRemoteJobAdd = useCallback(() => {
    navigate(PAGE_URL.STATUS_REMOTE_ADD);
  }, [navigate]);

  const moveToRemoteJobEdit = useCallback(
    ({ jobId, siteId, jobName }: { jobId: number; siteId: number; jobName: string }) => {
      navigate(PAGE_URL.STATUS_REMOTE_EDIT({ jobId, siteId, jobName }));
    },
    [navigate],
  );

  const moveToRemoteJobStep = useCallback(
    ({ jobId, jobName }: { jobId: number; jobName: string }) => {
      navigate(PAGE_URL.STATUS_REMOTE_STEP({ jobId, jobName }));
    },
    [navigate],
  );

  const openStartStopModal = useCallback(
    ({
      action,
      jobId,
      jobName,
      prevStop,
    }: {
      action: 'start' | 'stop';
      jobId: number;
      jobName: string;
      prevStop: boolean;
    }) => {
      const actionText = action === 'start' ? 'Start' : 'End';
      openAntdModal('confirm', {
        className: `${action}_remote_job`,
        title: `${actionText} Job`,
        content: `Are you sure to ${action} job '${jobName}'?`,
        okText: action === 'start' ? 'Start' : 'Stop',
        onOk: async () => {
          try {
            const { stop } = await getStatusRemoteJobStop(jobId);
            if (prevStop !== stop) {
              openNotification(
                'error',
                'Error',
                `The information of job '${jobName}' on the server has been changed. So, run the update. please try again!`,
              );
            } else {
              if (action === 'start') await startRemoteJob(jobId);
              else await stopRemoteJob(jobId);
              openNotification('success', 'Success', `Succeed to ${action} job '${jobName}'.`);
            }
          } catch (e) {
            openNotification('error', 'Error', `Failed to ${action} job '${jobName}'!`, e as AxiosError);
          } finally {
            refetch();
          }
        },
      });
    },
    [refetch],
  );

  const openDeleteModal = useCallback(
    ({ jobId, jobName, prevStop }: { jobId: number; jobName: string; prevStop: boolean }) => {
      openAntdModal('confirm', {
        className: 'delete_remote_job',
        title: 'Delete Job',
        content: `Are you sure to delete job '${jobName}'?`,
        okText: 'Delete',
        onOk: async () => {
          try {
            const { stop } = await getStatusRemoteJobStop(jobId);
            if (prevStop !== stop) {
              openNotification(
                'error',
                'Error',
                `The information of job '${jobName}' on the server has been changed. So, run the update. please try again!`,
              );
            } else {
              if (stop) {
                await deleteRemoteJob(jobId);
                openNotification('success', 'Success', `Succeed to delete job '${jobName}'.`);
              } else {
                openNotification('error', 'Error', `After stop job '${jobName}', please try again!`);
              }
            }
          } catch (e) {
            openNotification('error', 'Error', `Failed to delete job '${jobName}'!`);
          } finally {
            refetch();
          }
        },
      });
    },
    [refetch],
  );

  const openEditModal = useCallback(
    ({ jobId, siteId, jobName, prevStop }: { jobId: number; siteId: number; jobName: string; prevStop: boolean }) => {
      openAntdModal('confirm', {
        className: 'edit_remote_job',
        title: 'Edit Job',
        content: `Are you sure to edit job '${jobName}'?`,
        okText: 'Edit',
        onOk: async () => {
          try {
            const { stop } = await getStatusRemoteJobStop(jobId);
            const { stop: allStop } = await getStatusRemoteJobStopAll(jobId);

            if (stop) {
              if (allStop) {
                moveToRemoteJobEdit({ jobId, siteId, jobName });
              } else {
                openNotification('error', 'Error', `After Stop job '${jobName}', please try again!`);
              }
            } else {
              openNotification(
                'error',
                'Error',
                `After check that all manual execute steps are finished for '${jobName}', please try again!`,
              );
            }
          } catch (e) {
            openNotification('error', 'Error', `Failed to edit job '${jobName}'!`);
          }
        },
      });
    },
    [moveToRemoteJobEdit],
  );

  const openManualExecuteModal = useCallback(
    ({ jobId, jobName }: { jobId: number; jobName: string }) => {
      openAntdModal('confirm', {
        title: `Manual Execute Job`,
        content: `Are you sure to execute job '${jobName}' manually?`,
        okText: `Execute`,
        onOk: async () => {
          try {
            const { stop } = await getStatusRemoteJobStop(jobId);
            if (!stop) {
              openNotification('error', 'Error', `Must be stopped job '${jobName}' before manual execute!`);
            } else {
              await patchRequest({
                url: API_URL.PATCH_STATUS_REMOTE_MANUAL_EXECUTE_JOB(jobId),
                reqData: {},
              });
              openNotification('success', 'Success', `Succeed to execute job '${jobName}' manually.`);
            }
          } catch (e) {
            openNotification('error', 'Error', `Failed to execute job '${jobName}' manually!`, e as AxiosError);
          } finally {
            refetch();
          }
        },
      });
    },
    [refetch],
  );

  const onImport = () => {
    openModal<FileImportModalProps<RemoteJobImportData>>(MODAL_NAME.REMOTE_JOB.FILE_IMPORT_UPLOAD, FileImportModal, {
      title: 'Upload Job File',
      url: API_URL.POST_STATUS_REMOTE_JOB_UPLOAD_IMPORT_FILE,
      afterError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to upload job file!`, error);
      },
      afterSuccess: (data) => {
        onImportCustomize(validateImportJob(data));
      },
      mutationKey: [MUTATION_KEY.JOB_REMOTE_IMPORT_UPLOAD],
    });
  };

  const onImportCustomize = (data: RemoteJobImportData) => {
    openModal<RemoteJobStatusImportCustomizeProps>(
      MODAL_NAME.REMOTE_JOB.FILE_IMPORT_CUSTOMIZE,
      RemoteJobStatusImportCustomize,
      {
        data,
      },
    );
  };

  const onExport = () => {
    openModal(MODAL_NAME.REMOTE_JOB.FILE_EXPORT, RemoteJobStatusExport);
  };

  const onCopy = () => {
    openModal(MODAL_NAME.REMOTE_JOB.COPY_JOB_SELECT, RemoteJobStatusCopyJob);
  };

  return {
    data,
    isFetching,
    isError,
    loggedInUser,
    loggedInUserRole,
    openStartStopModal,
    openDeleteModal,
    openEditModal,
    moveToRemoteJobAdd,
    moveToRemoteJobStep,
    moveToHistoryLog,
    onExport,
    onImport,
    onCopy,
    openManualExecuteModal,
  };
}
