import useMoveToHistoryLog from '@hooks/useMoveToHistoryLog';
import { executeManualRemoteStep } from '@libs/axios/requests';
import { QUERY_KEY } from '@libs/query/queryKey';
import { useGetRemoteJobStepStatus } from '@libs/query/remoteJob';
import { openNotification } from '@libs/util/notification';
import useTypedSelector from '@reducers/useTypedSelector';
import { useQueryClient } from '@tanstack/react-query';
import type { RemoteJobStepMilestone } from '@typesdef/Job';
import { AxiosError } from 'axios';
import queryString from 'query-string';
import { useCallback, useMemo, useState } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import { loginUserRoleBooleanSelector } from '@reducers/slices/loginUser';

export default function useRemoteJobStatusStepList() {
  const [isError, setError] = useState(false);
  const { jobId } = useParams();
  const loggedInUserRole = useTypedSelector(loginUserRoleBooleanSelector);
  const queryClient = useQueryClient();
  const [isMilestone, setIsMilestone] = useState(false);
  const { search } = useLocation();
  const { name: jobName } = queryString.parse(search);
  const { moveToHistoryLog } = useMoveToHistoryLog();

  const { data, isFetching, refetch } = useGetRemoteJobStepStatus(jobId as string, {
    refetchInterval: 3000,
    enabled: Boolean(jobId),
    onError: () => {
      if (!isError) {
        openNotification('error', 'Error', `Failed to response the status of job!`);
        setError(true);
      }
    },
    onSuccess: () => {
      setError(false);
    },
  });

  const stepMilestone = useMemo<RemoteJobStepMilestone[]>(
    () =>
      data?.map((item) => ({
        stepName: item.stepName,
        stepType: item.stepType,
        uuid: item.uuid,
        mode: item.mode,
        time: item.time,
        cycle: item.cycle,
        period: item.period,
        preStep: item.preStep,
        nextStep: item.nextStep,
        enable: item.enable,
      })) ?? [],
    [data],
  );

  const setMilestone = useCallback((value: boolean) => {
    setIsMilestone(value);
  }, []);

  const status = queryClient.getQueryData<{ stop: boolean }>([QUERY_KEY.STATUS_REMOTE_STOP, jobId]);

  const executeManualStep = useCallback(
    async ({ jobId, stepId, stepName }: { jobId: number | null; stepId: number | null; stepName: string | null }) => {
      try {
        if (jobId === null || stepId === null) {
          throw new Error();
        }
        await executeManualRemoteStep(jobId, stepId);
        openNotification('success', 'Success', `Succeed to execute manual step '${stepName}'.`);
      } catch (e) {
        console.error(e);
        openNotification('error', 'Error', `Failed to execute manual step '${stepName}'!`, e as AxiosError);
      }
    },
    [],
  );

  return {
    data,
    isError,
    loggedInUserRole,
    status,
    isMilestone,
    setMilestone,
    stepMilestone,
    executeManualStep,
    moveToHistoryLog,
    jobName,
  };
}
