import { loginUserRoleBooleanSelector } from './../../../reducers/slices/loginUser';
import { PAGE_URL } from '@constants/constants';
import { startRemoteJob, stopRemoteJob } from '@libs/axios/requests';
import { useGetRemoteJobStopStatus } from '@libs/query/remoteJob';
import { openNotification } from '@libs/util/notification';
import { loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { AxiosError } from 'axios';
import queryString from 'query-string';
import { useCallback, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';

export default function useRemoteJobStatusStep() {
  const { jobId } = useParams();
  const { search } = useLocation();
  const { name } = queryString.parse(search);
  const navigate = useNavigate();
  const [isError, setError] = useState(false);
  const loggedInUserRole = useTypedSelector(loginUserRoleBooleanSelector);

  const {
    data: status,
    isFetching,
    refetch,
  } = useGetRemoteJobStopStatus(jobId as string, {
    refetchInterval: 3000,
    enabled: Boolean(jobId),
    onError: () => {
      if (!isError) {
        openNotification('error', 'Error', `Failed to response the status of job!`);
        setError(true);
      }
    },
    onSuccess: () => {
      setError(false);
    },
  });

  const onBack = useCallback(() => {
    navigate(PAGE_URL.STATUS_REMOTE);
  }, [navigate]);

  const onClickStartStop = useCallback(async () => {
    const isStop = status?.stop;
    console.log(isStop);
    try {
      if (isStop !== undefined) {
        isStop ? await startRemoteJob(jobId as string) : await stopRemoteJob(jobId as string);
        openNotification('success', 'Success', `Success to ${isStop ? 'start' : 'stop'} job '${name}'!`);
      }
    } catch (error) {
      openNotification('error', 'Error', `Failed to ${isStop ? 'start' : 'stop'} job '${name}'!`, error as AxiosError);
    } finally {
      refetch();
    }
  }, [jobId, status, name, refetch]);

  return {
    name,
    status,
    onBack,
    onClickStartStop,
    loggedInUserRole,
  };
}
