import { useGetRemoteJobStepBuildExecutor, useGetRemoteJobStepBuildQueue } from '@libs/query/remoteJob';
import { openNotification } from '@libs/util/notification';
import { useState } from 'react';
import { useParams } from 'react-router-dom';

export default function useRemoteJobStatusStepBuild() {
  const [isErrorQueue, setErrorQueue] = useState(false);
  const [isErrorExecutor, setErrorExecutor] = useState(false);
  const { jobId } = useParams();

  const {
    data: queueData,
    isFetching: isFetchingQueue,
    refetch: refetchQueue,
  } = useGetRemoteJobStepBuildQueue(jobId as string, {
    refetchInterval: 3000,
    enabled: Boolean(jobId),
    onError: () => {
      if (!isErrorQueue) {
        openNotification('error', 'Error', `Failed to response the status of build queue`);
        setErrorQueue(true);
      }
    },
    onSuccess: () => {
      setErrorQueue(false);
    },
  });

  const {
    data: executorData,
    isFetching: isFetchingExecutor,
    refetch: refetchExecutor,
  } = useGetRemoteJobStepBuildExecutor(jobId as string, {
    refetchInterval: 3000,
    enabled: Boolean(jobId),
    onError: () => {
      if (!isErrorExecutor) {
        openNotification('error', 'Error', `Failed to response the status of build executor`);
        setErrorExecutor(true);
      }
    },
    onSuccess: () => {
      setErrorExecutor(false);
    },
  });

  return {
    queueData,
    executorData,
    isErrorQueue,
    isErrorExecutor,
  };
}
