import { useGetRemoteJobExport, useGetRemoteJobIsCustom } from '@libs/query/remoteJob';
import { openNotification } from '@libs/util/notification';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { saveAs } from 'file-saver';

export default function useRemoteJobStatusExport({ visible, onClose }: GlobalModalDefaultProps) {
  const { data: customData, isFetching: isFetchingCustom, isError: isErrorCustom } = useGetRemoteJobIsCustom();

  const { mutate: mutateExport, isLoading: isLoadingExport } = useGetRemoteJobExport({
    onSuccess: (res) => {
      const { data, fileName } = res;
      saveAs(data, fileName);
      openNotification('success', 'Success', `Succeed to export job '${fileName}'.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', 'Failed to export job define!', error);
    },
    onSettled: () => {
      onClose();
    },
  });

  const onOk = () => {
    mutateExport();
  };

  return {
    customData,
    isFetchingCustom,
    isErrorCustom,
    isLoadingExport,
    onOk,
  };
}
