import { useRemoteJobImportContext } from '@libs/context/RemoteJobImportProvider';
import { QUERY_KEY } from '@libs/query/queryKey';
import { usePostRemoteJobCopyCustomize, usePostRemoteJobImportCustomize } from '@libs/query/remoteJob';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { RemoteJobStatusImportCustomizeProps } from '../Modal/RemoteJobStatusImportCustomize';

export default function useRemoteJobStatusImportCustomize({
  visible,
  onClose,
  mode = 'import',
}: GlobalModalDefaultProps<Omit<RemoteJobStatusImportCustomizeProps, 'data'>>) {
  const { originData, jobData, errorJobs } = useRemoteJobImportContext();
  const { custom } = originData;
  const queryClient = useQueryClient();
  const isError = Object.entries(errorJobs).some(([key, value]) => value.isError);
  const jobDataLen = originData.jobs.length;
  const modeText = mode === 'import' ? 'Import' : 'Copy';

  const mutateFunc = mode === 'import' ? usePostRemoteJobImportCustomize : usePostRemoteJobCopyCustomize;

  const { mutate: mutateImport, isLoading: isLoadingImport } = mutateFunc({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to ${mode} job.`);
    },
    onError: (error) => {
      if (error?.response?.data && Array.isArray(error.response.data) && error.response.data.length > 0) {
        const errorJobs = error.response.data.reduce((acc, cur) => {
          const { jobName, userName, fabName } = cur;
          const name = `${jobName}(${fabName}-${userName})`;

          return acc ? acc + `, ${name}` : name;
        }, '');
        openNotification('error', 'Error', `Failed to ${mode} job about ${errorJobs}!`, error);
      } else {
        openNotification('error', 'Error', `Failed to ${mode} job!`, error);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.STATUS_REMOTE_LIST]);
      onClose();
    },
  });

  const onOk = () => {
    mutateImport({
      custom,
      jobs: jobData,
    });
  };

  return { onOk, isLoadingImport, isError, jobDataLen, modeText };
}
