import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { QUERY_KEY } from '@libs/query/queryKey';
import { useGetRemoteJobCopy, useGetRemoteJobList } from '@libs/query/remoteJob';
import { validateImportJob } from '@libs/util/job';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { useForm, useWatch } from 'antd/es/form/Form';
import { DefaultOptionType } from 'antd/es/select';
import { useMemo } from 'react';
import RemoteJobStatusImportCustomize, {
  RemoteJobStatusImportCustomizeProps,
} from '../Modal/RemoteJobStatusImportCustomize';

export default function useRemoteJobStatusCopyJob({ visible, onClose }: GlobalModalDefaultProps) {
  const queryClient = useQueryClient();
  const { openModal } = useModals();
  const [form] = useForm<{
    selectJob: number;
  }>();
  const formSelectJob = useWatch('selectJob', form);
  const { data: jobList, isFetching: isFetchingJobList } = useGetRemoteJobList();

  const { isFetching: isFetchingCopy, refetch: refetchCopy } = useGetRemoteJobCopy(formSelectJob, {
    enabled: false,
    onSuccess: (data) => {
      onClose();
      openModal<RemoteJobStatusImportCustomizeProps>(
        MODAL_NAME.REMOTE_JOB.COPY_JOB_CUSTOMIZE,
        RemoteJobStatusImportCustomize,
        {
          data: validateImportJob(data),
          mode: 'copy',
        },
      );
    },
    onError: (error) => {
      openNotification('error', 'Error', 'Failed to get job!', error);
      queryClient.invalidateQueries([QUERY_KEY.STATUS_REMOTE_LIST]);
      onClose();
    },
  });

  const jobOptions: DefaultOptionType[] = useMemo(
    () =>
      jobList?.map((item) => ({
        label: item.jobName,
        value: item.jobId,
        key: item.jobId,
      })) ?? [],
    [jobList],
  );

  const onOk = async () => {
    if (!(await form.validateFields())) {
      return;
    }
    refetchCopy();
  };

  return { form, onOk, jobOptions, isFetchingJobList, isFetchingCopy };
}
