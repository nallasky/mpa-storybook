import {
  CopyOutlined,
  DeleteOutlined,
  EditOutlined,
  ExportOutlined,
  ImportOutlined,
  PlusOutlined,
  TagOutlined,
} from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import { CommonTableEmpty } from '@components/common/atoms/Common/Common';
import CustomBadgeSync from '@components/common/atoms/CustomBadge/CustomBadgeSync';
import CustomIcon from '@components/common/atoms/CustomIcon';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { ContentWrapper } from '@components/common/atoms/Wrapper';
import { ADMINISTRATOR } from '@constants/constants';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { errorIconStyle, hoverActiveStyle, tableRowErrorStyle } from '@styles/emotion/common';
import { AntdTableRowClassName } from '@typesdef/antd';
import { TableColumnPropsType } from '@typesdef/common';
import { JobType, RemoteJobLastResultDate, RemoteJobStatusState } from '@typesdef/Job';
import { Button, Space, Table, Tooltip } from 'antd';
import { TableLocale } from 'antd/es/table/interface';
import dayjs from 'dayjs';
import React, { Fragment, useCallback, useMemo } from 'react';
import useRemoteJobStatus from './hooks/useRemoteJobStatus';

export type RemoteJobStatusProps = {};

export default function RemoteJobStatus({}: RemoteJobStatusProps): JSX.Element {
  const {
    data,
    isError,
    loggedInUser,
    loggedInUserRole,
    openStartStopModal,
    openDeleteModal,
    openEditModal,
    moveToRemoteJobAdd,
    moveToRemoteJobStep,
    moveToHistoryLog,
    onExport,
    onImport,
    onCopy,
    openManualExecuteModal,
  } = useRemoteJobStatus();

  const dataLen = useMemo(() => data?.length ?? 0, [data]);

  const jobNameRender = useCallback(
    (value: string, record: RemoteJobStatusState, index: number) => {
      const { jobId, jobName } = record;
      return (
        <div>
          <div className="value" css={hoverActiveStyle} onClick={() => moveToRemoteJobStep({ jobId, jobName })}>
            {value}
          </div>
        </div>
      );
    },
    [moveToRemoteJobStep],
  );

  const lastResultRender = useCallback(
    (value: RemoteJobLastResultDate, record: RemoteJobStatusState, index: number) => {
      const lastResult = value.key === 'lastSuccess' ? record.lastSuccess : record.lastFailure;

      if (!lastResult) {
        return <div>-</div>;
      }

      const historyParams = {
        jobType: 'remote' as JobType,
        stepType: lastResult.stepType,
        jobId: record.jobId,
        jobName: record.jobName,
        stepId: lastResult.stepId,
        stepName: lastResult.stepName,
        historyId: lastResult.historyId,
      };

      return (
        <Space>
          <div css={hoverActiveStyle}>
            <div className="value" onClick={() => moveToHistoryLog(historyParams)}>
              <div>{lastResult.date}</div>
              <div>{lastResult.stepName}</div>
            </div>
          </div>
          {lastResult.error && lastResult.error.length > 0 && (
            <Tooltip
              placement="top"
              title={lastResult.error.map((item) => (
                <div key={item}>{item}</div>
              ))}
              color="red"
            >
              <CustomIcon css={errorIconStyle} name="warning" />
              {/* it need to diplay tooltip */}
              <div></div>
            </Tooltip>
          )}
        </Space>
      );
    },
    [moveToHistoryLog],
  );

  const statusRender = useCallback(
    (value: boolean, record: RemoteJobStatusState, index: number) => {
      const { jobId, jobName, stop: prevStop } = record;
      if (value)
        return (
          <div css={statusIconStyleWithJob(loggedInUserRole.ROLE_JOB)}>
            <CustomIcon className="stopped" name="stop" />
            <span className="text" onClick={() => openStartStopModal({ action: 'start', jobId, jobName, prevStop })}>
              Stopped
            </span>
          </div>
        );
      else
        return (
          <div
            css={statusIconStyleWithJob(loggedInUserRole.ROLE_JOB)}
            onClick={() => openStartStopModal({ action: 'stop', jobId, jobName, prevStop })}
          >
            <CustomIcon className="running" name="play" />
            <span className="text">Running</span>
          </div>
        );
    },
    [loggedInUserRole, openStartStopModal],
  );

  const executeRender = useCallback(
    (value: number, record: RemoteJobStatusState, index: number) => {
      const { jobId, jobName, stop } = record;

      return (
        <Button
          size="small"
          type="text"
          icon={<TagOutlined />}
          disabled={!stop}
          css={[
            hoverActiveStyle,
            css`
              background: none;
              border: 0;
              box-shadow: none;
            `,
          ]}
          onClick={() => openManualExecuteModal({ jobId, jobName })}
        />
      );
    },
    [openManualExecuteModal],
  );

  const editRender = useCallback(
    (value: number, record: RemoteJobStatusState, index: number) => {
      const { jobId, siteId, jobName, stop: prevStop } = record;
      return loggedInUserRole.ROLE_JOB ? (
        <EditOutlined css={hoverActiveStyle} onClick={() => openEditModal({ jobId, siteId, jobName, prevStop })} />
      ) : (
        <div>-</div>
      );
    },
    [loggedInUserRole, openEditModal],
  );

  const deleteRender = useCallback(
    (value: number, record: RemoteJobStatusState, index: number) => {
      const { jobId, jobName, stop: prevStop } = record;
      return loggedInUserRole.ROLE_JOB ? (
        <DeleteOutlined css={hoverActiveStyle} onClick={() => openDeleteModal({ jobId, jobName, prevStop })} />
      ) : (
        <div>-</div>
      );
    },
    [loggedInUserRole, openDeleteModal],
  );

  const tableLocale = useMemo<TableLocale>(
    () => ({
      emptyText: <CommonTableEmpty isError={isError} />,
    }),
    [isError],
  );

  return (
    <ContentWrapper>
      <TableHeader title={<TableHeaderTitle total={dataLen} />} isSeparated>
        <CustomBadgeSync size="1.25rem" color={isError ? 'gray' : 'green'} marginRight="0.5rem" />

        {loggedInUserRole.ROLE_JOB && (
          <Fragment>
            <AntdButton
              icon={<PlusOutlined />}
              type="primary"
              onClick={moveToRemoteJobAdd}
              disabled={!loggedInUserRole.ROLE_JOB}
            >
              Add
            </AntdButton>
            <AntdButton icon={<CopyOutlined />} type="primary" onClick={() => onCopy()}>
              Copy
            </AntdButton>
            <AntdButton icon={<ImportOutlined />} type="primary" onClick={() => onImport()}>
              Import
            </AntdButton>
            <AntdButton icon={<ExportOutlined />} type="primary" onClick={() => onExport()}>
              Export
            </AntdButton>
          </Fragment>
        )}
      </TableHeader>
      <RemoteJobStatusTable
        isAdmin={loggedInUser.username === ADMINISTRATOR}
        data={data}
        tableLocale={tableLocale}
        jobNameRender={jobNameRender}
        lastResultRender={lastResultRender}
        statusRender={statusRender}
        executeRender={executeRender}
        editRender={editRender}
        deleteRender={deleteRender}
      />
    </ContentWrapper>
  );
}

interface RemoteJobStatusTableProps {
  isAdmin: boolean;
  data: RemoteJobStatusState[] | undefined;
  tableLocale: TableLocale;
  jobNameRender: (value: string, record: RemoteJobStatusState, index: number) => JSX.Element;
  lastResultRender: (value: RemoteJobLastResultDate, record: RemoteJobStatusState, index: number) => JSX.Element;
  statusRender: (value: boolean, record: RemoteJobStatusState, index: number) => JSX.Element;
  executeRender: (value: number, record: RemoteJobStatusState, index: number) => JSX.Element;
  editRender: (value: number, record: RemoteJobStatusState, index: number) => JSX.Element;
  deleteRender: (value: number, record: RemoteJobStatusState, index: number) => JSX.Element;
}
const RemoteJobStatusTable = React.memo(function RemoteJobStatusTableMemo({
  isAdmin,
  data,
  jobNameRender,
  lastResultRender,
  statusRender,
  executeRender,
  editRender,
  deleteRender,
  tableLocale,
}: RemoteJobStatusTableProps): JSX.Element {
  const rowClassName: Exclude<AntdTableRowClassName<RemoteJobStatusState>, string> = useCallback((record) => {
    const {
      lastFailureDate: { date: failure },
      lastSuccessDate: { date: success },
    } = record;

    if (!failure) {
      return '';
    }

    if (!success) {
      return 'error-mark';
    }

    if (dayjs(failure, 'YYYY-MM-DD HH:mm:ss').isAfter(dayjs(success, 'YYYY-MM-DD HH:mm:ss'))) {
      return 'error-mark';
    } else {
      return '';
    }
  }, []);

  return (
    <Table<RemoteJobStatusState>
      rowKey={'jobId'}
      dataSource={data}
      bordered
      size="small"
      pagination={{
        position: ['bottomCenter'],
        showSizeChanger: true,
      }}
      css={[tableStyle, tableRowErrorStyle]}
      tableLayout="fixed"
      rowClassName={rowClassName}
      sticky={{ offsetHeader: NAV_BAR_HIGHT }}
    >
      {isAdmin ? (
        <Fragment>
          <Table.Column<RemoteJobStatusState> {...adminColumnProps.jobName} render={jobNameRender} />
          <Table.Column<RemoteJobStatusState> {...adminColumnProps.companyFabName} />
          <Table.Column<RemoteJobStatusState> {...adminColumnProps.lastSuccessDate} render={lastResultRender} />
          <Table.Column<RemoteJobStatusState> {...adminColumnProps.lastFailureDate} render={lastResultRender} />
          <Table.Column<RemoteJobStatusState> {...adminColumnProps.stop} render={statusRender} />
          <Table.Column<RemoteJobStatusState> {...adminColumnProps.manual} render={executeRender} />
          <Table.Column<RemoteJobStatusState> {...adminColumnProps.edit} render={editRender} />
          <Table.Column<RemoteJobStatusState> {...adminColumnProps.delete} render={deleteRender} />
        </Fragment>
      ) : (
        <Fragment>
          <Table.Column<RemoteJobStatusState> {...userColumnProps.jobName} render={jobNameRender} />
          <Table.Column<RemoteJobStatusState> {...userColumnProps.companyFabName} />
          <Table.Column<RemoteJobStatusState> {...userColumnProps.lastSuccessDate} render={lastResultRender} />
          <Table.Column<RemoteJobStatusState> {...userColumnProps.lastFailureDate} render={lastResultRender} />
          <Table.Column<RemoteJobStatusState> {...userColumnProps.stop} render={statusRender} />
          <Table.Column<RemoteJobStatusState> {...userColumnProps.edit} render={editRender} />
          <Table.Column<RemoteJobStatusState> {...userColumnProps.delete} render={deleteRender} />
        </Fragment>
      )}
    </Table>
  );
});

const tableStyle = css`
  width: 85rem;
`;

type ColumnName =
  | 'jobName'
  | 'companyFabName'
  | 'lastSuccessDate'
  | 'lastFailureDate'
  | 'stop'
  | 'manual'
  | 'edit'
  | 'delete';

const columnProps: TableColumnPropsType<RemoteJobStatusState, ColumnName> = {
  jobName: {
    key: 'jobName',
    title: <TableColumnTitle>Job Name</TableColumnTitle>,
    dataIndex: 'jobName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'jobName'),
    },
  },
  companyFabName: {
    key: 'companyFabName',
    title: <TableColumnTitle>User-Fab Name</TableColumnTitle>,
    dataIndex: 'companyFabName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'companyFabName'),
    },
  },
  lastSuccessDate: {
    key: 'lastSuccessDate',
    title: <TableColumnTitle>Last Success</TableColumnTitle>,
    dataIndex: 'lastSuccessDate',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a.lastSuccessDate, b.lastSuccessDate, 'date'),
    },
  },
  lastFailureDate: {
    key: 'lastFailureDate',
    title: <TableColumnTitle>Last Failure</TableColumnTitle>,
    dataIndex: 'lastFailureDate',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a.lastFailureDate, b.lastFailureDate, 'date'),
    },
  },
  stop: {
    key: 'stop',
    title: <TableColumnTitle>Status</TableColumnTitle>,
    dataIndex: 'stop',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'stop'),
    },
  },
  manual: {
    key: 'manual',
    title: <TableColumnTitle>Manual Execute</TableColumnTitle>,
    dataIndex: 'jobId',
    align: 'center',
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    dataIndex: 'jobId',
    align: 'center',
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    dataIndex: 'jobId',
    align: 'center',
  },
};

const adminColumnProps: TableColumnPropsType<RemoteJobStatusState, ColumnName> = {
  jobName: {
    ...columnProps['jobName'],
    width: getPixelPercent(1360, 245),
  },
  companyFabName: {
    ...columnProps['companyFabName'],
    width: getPixelPercent(1360, 225),
  },
  lastSuccessDate: {
    ...columnProps['lastSuccessDate'],
    width: getPixelPercent(1360, 280),
  },
  lastFailureDate: {
    ...columnProps['lastFailureDate'],
    width: getPixelPercent(1360, 280),
  },
  stop: {
    ...columnProps['stop'],
    width: getPixelPercent(1360, 120),
  },
  manual: {
    ...columnProps['manual'],
    width: getPixelPercent(1360, 80),
  },
  edit: {
    ...columnProps['edit'],
    width: getPixelPercent(1360, 65),
  },
  delete: {
    ...columnProps['delete'],
    width: getPixelPercent(1360, 65),
  },
};

const userColumnProps: TableColumnPropsType<RemoteJobStatusState, Exclude<ColumnName, 'manual'>> = {
  jobName: {
    ...columnProps['jobName'],
    width: getPixelPercent(1360, 245),
  },
  companyFabName: {
    ...columnProps['companyFabName'],
    width: getPixelPercent(1360, 245),
  },
  lastSuccessDate: {
    ...columnProps['lastSuccessDate'],
    width: getPixelPercent(1360, 295),
  },
  lastFailureDate: {
    ...columnProps['lastFailureDate'],
    width: getPixelPercent(1360, 295),
  },
  stop: {
    ...columnProps['stop'],
    width: getPixelPercent(1360, 120),
  },
  edit: {
    ...columnProps['edit'],
    width: getPixelPercent(1360, 80),
  },
  delete: {
    ...columnProps['delete'],
    width: getPixelPercent(1360, 80),
  },
};

export const statusIconStyleWithJob = (isJob: boolean) => css`
  pointer-events: ${!isJob && 'none'};
  .running {
    color: #52c41a;
    -webkit-animation: blink 1s ease-in-out infinite alternate;
    animation: blink 1s ease-in-out infinite alternate;
    @keyframes blink {
      0% {
        opacity: 0;
      }
      100% {
        opacity: 1;
      }
    }
  }

  .stopped {
    color: #ff4d4f;
  }
  .text {
    cursor: default;
    margin-left: 0.3rem;
    ${isJob && hoverActiveStyle};
  }
`;
