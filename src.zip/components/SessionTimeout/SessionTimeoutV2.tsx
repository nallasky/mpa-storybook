import { SESSION_STORAGE_TIMEOUT, SESSION_STORAGE_TIMEOUT_MIN } from '@constants/constants';
import useLogout from '@hooks/useLogout';
import { loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { message } from 'antd';
import moment from 'moment';
import { Fragment, useEffect, useRef, useState } from 'react';
import { useThrottledCallback } from 'use-debounce';

const CHECK_INACTIVITY_MINUTE = 5;
const CHECK_WARN_MESSAGE_MS = 1000; // 1 minute
const LAST_TIME_STAMP_KEY = 'lastTimeStamp';
const WARNING_SECOND = 3 * 60; // 3 minite
const WARNING_MESSEAGE_KEY = 'warning_timeout';

export type SessionTimeoutV2Props = {};
export default function SessionTimeoutV2({}: SessionTimeoutV2Props): JSX.Element {
  const [events] = useState(['scroll', 'mousemove', 'keydown', 'click']); //load
  const { id: loginedId, timeout } = useTypedSelector(loginUserSelector);
  const startTimerInterval = useRef<NodeJS.Timeout | null>(null);
  const warnTimerInterval = useRef<NodeJS.Timeout | null>(null);
  const warnSecond = useRef(WARNING_SECOND);
  const { onLogout } = useLogout();

  const logoutProcess = () => {
    clearSessionTimeout();
    window.sessionStorage.setItem(SESSION_STORAGE_TIMEOUT, 'true');
    window.sessionStorage.setItem(SESSION_STORAGE_TIMEOUT_MIN, `${timeout}`);
    onLogout();
  };

  // start inactive check
  const timeChecker = () => {
    startTimerInterval.current = setInterval(() => {
      const storedTimeStamp = sessionStorage.getItem(LAST_TIME_STAMP_KEY);
      const maxTime = timeout; // Maximum ideal time given before logout

      const diff = moment.duration(moment().diff(moment(storedTimeStamp, 'YYYY-MM-DD HH:mm:ss')));
      const minPast = diff.minutes();
      // const secPast = diff.seconds();

      if (minPast >= maxTime) {
        clearInterval(startTimerInterval.current as NodeJS.Timeout);
        startTimerInterval.current = null;
        warningChecker();
      }
    }, CHECK_INACTIVITY_MINUTE);
  };

  const warningChecker = () => {
    warnTimerInterval.current = setInterval(() => {
      if (warnSecond.current <= 0) {
        // logout
        logoutProcess();
      } else {
        message.warning({
          content: `You will be logged out due to inactivity after ${secondsToTime(warnSecond.current--)}.`,
          key: WARNING_MESSEAGE_KEY,
          duration: 0,
        });
      }
    }, CHECK_WARN_MESSAGE_MS);
  };

  const initEvnetTime = () => {
    clearInterval(startTimerInterval.current as NodeJS.Timeout);
    clearInterval(warnTimerInterval.current as NodeJS.Timeout);
    startTimerInterval.current = null;
    warnTimerInterval.current = null;
    warnSecond.current = WARNING_SECOND;
  };

  const resetEventTime = () => {
    if (loginedId > 0) {
      initEvnetTime();
      sessionStorage.setItem(LAST_TIME_STAMP_KEY, moment().format('YYYY-MM-DD HH:mm:ss'));
      message.destroy(WARNING_MESSEAGE_KEY);
      timeChecker();
    }
  };

  const resetEventTimeThrottled = useThrottledCallback(resetEventTime, 1000);

  const clearSessionTimeout = () => {
    initEvnetTime();
    sessionStorage.removeItem(LAST_TIME_STAMP_KEY);
    message.destroy(WARNING_MESSEAGE_KEY);
    events.forEach((event) => {
      window.removeEventListener(event, resetEventTimeThrottled);
    });
  };

  useEffect(() => {
    if (loginedId > 0) {
      events.forEach((event) => {
        window.addEventListener(event, resetEventTimeThrottled);
      });
      resetEventTime();
    } else {
      clearSessionTimeout();
    }
    return () => clearSessionTimeout();
  }, [loginedId]);

  return <Fragment />;
}

function secondsToTime(e: number): string {
  const h = Math.floor(e / 3600)
      .toString()
      .padStart(2, '0'),
    m = Math.floor((e % 3600) / 60)
      .toString()
      .padStart(2, '0'),
    s = Math.floor(e % 60)
      .toString()
      .padStart(2, '0');

  return `${h}:${m}:${s}`;
}
