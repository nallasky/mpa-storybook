import { SESSION_STORAGE_TIMEOUT, SESSION_STORAGE_TIMEOUT_MIN } from '@constants/constants';
import useLogout from '@hooks/useLogout';
import { loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import moment from 'moment';
import { Fragment, useEffect, useRef, useState } from 'react';
import { useThrottledCallback } from 'use-debounce';

const CHECK_INACTIVITY_MINUTE = 5;

export type SessionTimeoutProps = {};
export default function SessionTimeout({}: SessionTimeoutProps): JSX.Element {
  const [events] = useState(['scroll', 'mousemove', 'keydown', 'click']); //load
  const { id: loginedId, timeout } = useTypedSelector(loginUserSelector);
  const startTimerInterval = useRef<NodeJS.Timeout | null>(null);
  const { onLogout } = useLogout();

  // start inactive check
  const timeChecker = () => {
    startTimerInterval.current = setInterval(() => {
      const storedTimeStamp = sessionStorage.getItem('lastTimeStamp');
      const maxTime = timeout; // Maximum ideal time given before logout

      const diff = moment.duration(moment().diff(moment(storedTimeStamp, 'YYYY-MM-DD HH:mm:ss')));
      const minPast = diff.minutes();

      if (minPast >= maxTime) {
        clearSessionTimeout();
        // your logout function here
        window.sessionStorage.setItem(SESSION_STORAGE_TIMEOUT, 'true');
        window.sessionStorage.setItem(SESSION_STORAGE_TIMEOUT_MIN, `${timeout}`);
        onLogout();
      }
    }, CHECK_INACTIVITY_MINUTE);
  };

  const resetEventTime = () => {
    if (loginedId > 0) {
      sessionStorage.setItem('lastTimeStamp', moment().format('YYYY-MM-DD HH:mm:ss'));
    }
  };

  const resetEventTimeThrottled = useThrottledCallback(resetEventTime, 1000);

  const clearSessionTimeout = () => {
    events.forEach((event) => {
      window.removeEventListener(event, resetEventTimeThrottled);
    });
    sessionStorage.removeItem('lastTimeStamp');
    clearInterval(startTimerInterval.current as NodeJS.Timeout);
  };

  useEffect(() => {
    if (loginedId > 0) {
      events.forEach((event) => {
        window.addEventListener(event, resetEventTimeThrottled);
      });
      resetEventTime();
      timeChecker();
    } else {
      clearSessionTimeout();
    }
    return () => clearSessionTimeout();
  }, [loginedId]);

  return <Fragment />;
}
