import { DeleteOutlined, PlusOutlined } from '@ant-design/icons';
import CustomBadgeSync from '@components/common/atoms/CustomBadge/CustomBadgeSync';
import CustomIcon from '@components/common/atoms/CustomIcon';
import PopupTip from '@components/common/atoms/PopupTip';
import StatusBadge from '@components/common/atoms/StatusBadge';
import TableHeader from '@components/common/atoms/TableHeader';
import { ContentWrapper } from '@components/common/atoms/Wrapper';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { errorIconStyle, hoverActiveStyle, hoverStyle, tableRowErrorStyle } from '@styles/emotion/common';
import type { AntdTableRowClassName } from '@typesdef/antd';
import type { TableColumnPropsType } from '@typesdef/common';
import { JobStatusType, JobStepType, LocalJobStatusState } from '@typesdef/Job';
import { Button, Space, Table, Tooltip } from 'antd';
import { useCallback } from 'react';
import useLocalJobStatus from './hooks/useLocalJobStatus';

export type LocalJobStatusProps = {};

export default function LocalJobStatus({}: LocalJobStatusProps): JSX.Element {
  const {
    data,
    isError,
    openDeleteModal,
    loggedInUserRole,
    moveToAdd,
    moveToHistoryLog,
    isRequesting,
    pagination,
    onChangeTable,
  } = useLocalJobStatus();

  const renderStatus = useCallback(
    (value: JobStatusType, record: LocalJobStatusState, index: number) => {
      const { jobId, stepId, stepType, historyId } = record;
      const errorMsg = record.status === 'failure' && record.error && record.error.length > 0 ? record.error : [];

      return (
        <Space>
          <StatusBadge
            value={value}
            onClick={() =>
              moveToHistoryLog({
                jobType: 'local',
                stepType: stepType as JobStepType,
                jobId: jobId as number,
                stepId: stepId as number,
                historyId,
              })
            }
          />
          {errorMsg.length > 0 && (
            <Tooltip
              placement="top"
              title={errorMsg.map((item) => (
                <div key={item}>{item}</div>
              ))}
              color="red"
            >
              <CustomIcon css={errorIconStyle} name="warning" />
              {/* it need to diplay tooltip */}
              <div></div>
            </Tooltip>
          )}
        </Space>
      );
    },
    [moveToHistoryLog],
  );

  const deleteRender = useCallback(
    (value: LocalJobStatusState, record: LocalJobStatusState, index: number) => {
      return loggedInUserRole.ROLE_JOB ? (
        <DeleteOutlined css={hoverActiveStyle} onClick={() => openDeleteModal(value.jobId)} />
      ) : (
        <div>-</div>
      );
    },
    [openDeleteModal, loggedInUserRole],
  );

  const renderTitle = useCallback(
    () => (
      <TableHeader>
        <CustomBadgeSync size="1.25rem" color={isError ? 'gray' : 'green'} marginRight="0.5rem" />
        <Button icon={<PlusOutlined />} type="primary" onClick={moveToAdd} disabled={!loggedInUserRole.ROLE_JOB}>
          Add
        </Button>
      </TableHeader>
    ),
    [moveToAdd, isError, loggedInUserRole],
  );

  const filesRender = useCallback((value: string[], record: LocalJobStatusState, index: number) => {
    return (
      <div css={hoverStyle}>
        <PopupTip value={`${value.length} files`} list={value} />
      </div>
    );
  }, []);

  const dateRender = useCallback((value: string, record: LocalJobStatusState, index: number) => {
    return <div>{value}</div>;
  }, []);

  const rowClassName: Exclude<AntdTableRowClassName<LocalJobStatusState>, string> = useCallback((record) => {
    return Array.isArray(record.error) && record.error.length > 0 ? 'error-mark' : '';
  }, []);

  return (
    <ContentWrapper>
      <Table<LocalJobStatusState>
        rowKey={'jobId'}
        rowClassName={rowClassName}
        dataSource={data?.content ?? []}
        bordered
        title={renderTitle}
        size="small"
        pagination={{
          position: ['bottomCenter'],
          showSizeChanger: true,
          current: pagination.current,
          pageSize: pagination.pageSize,
          total: pagination.total,
        }}
        onChange={onChangeTable}
        css={[tableRowErrorStyle]}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
        loading={isRequesting}
      >
        <Table.Column<LocalJobStatusState> {...columnProps.jobName} />
        <Table.Column<LocalJobStatusState> {...columnProps.companyFabName} />
        <Table.Column<LocalJobStatusState> {...columnProps.fileOriginalNames} render={filesRender} />
        <Table.Column<LocalJobStatusState> {...columnProps.status} render={renderStatus} />
        <Table.Column<LocalJobStatusState> {...columnProps.registeredDate} render={dateRender} />
        <Table.Column<LocalJobStatusState> {...columnProps.delete} render={deleteRender} />
      </Table>
    </ContentWrapper>
  );
}

type ColumnName = 'jobName' | 'companyFabName' | 'status' | 'fileOriginalNames' | 'registeredDate' | 'delete';

const columnProps: TableColumnPropsType<LocalJobStatusState, ColumnName> = {
  jobName: {
    key: 'jobName',
    title: <TableColumnTitle>Local Import Name</TableColumnTitle>,
    dataIndex: 'jobName',
    align: 'center',
    width: getPixelPercent(1360, 400),
    sorter: true,
  },
  companyFabName: {
    key: 'companyFabName',
    title: <TableColumnTitle>User-Fab Name</TableColumnTitle>,
    dataIndex: 'companyFabName',
    align: 'center',
    width: getPixelPercent(1360, 400),
    sorter: true,
  },
  status: {
    key: 'status',
    title: <TableColumnTitle>Convert & Insert</TableColumnTitle>,
    dataIndex: 'status',
    align: 'center',
    width: getPixelPercent(1360, 150),
    sorter: true,
  },
  fileOriginalNames: {
    key: 'files',
    title: <TableColumnTitle>Files</TableColumnTitle>,
    dataIndex: 'fileOriginalNames',
    align: 'center',
    width: getPixelPercent(1360, 150),
  },
  registeredDate: {
    key: 'registeredDate',
    title: <TableColumnTitle>Date</TableColumnTitle>,
    dataIndex: 'registeredDate',
    align: 'center',
    width: getPixelPercent(1360, 180),
    sorter: true,
  },
  delete: {
    key: 'jobId',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 80),
  },
};
