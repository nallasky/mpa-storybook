import { openAntdModal } from '@components/common/atoms/AntdModal';
import { PAGE_URL } from '@constants/constants';
import useMoveToHistoryLog from '@hooks/useMoveToHistoryLog';
import useTableSortSearch from '@hooks/useTableSortSearch';
import { deleteLocalJob } from '@libs/axios/requests';
import { useGetLocalJobStatus } from '@libs/query/localjob';
import { openNotification } from '@libs/util/notification';
import { loginUserRoleBooleanSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function useLocalJobStatus() {
  const loggedInUserRole = useTypedSelector(loginUserRoleBooleanSelector);
  const [isError, setError] = useState(false);
  const navigate = useNavigate();
  const { moveToHistoryLog } = useMoveToHistoryLog();
  const {
    isRequesting,
    pagination,
    searchParam,
    hasSearchParam,
    setPagination,
    setSearchParam,
    setRequesting,
    onChangeTable,
  } = useTableSortSearch();

  const { data, isFetching, refetch } = useGetLocalJobStatus(
    {
      pagination: {
        size: pagination.pageSize,
        page: pagination.current - 1,
        sort: pagination.sort,
      },
    },
    {
      onSuccess: (data) => {
        setPagination({
          total: data.totalElements,
        });
        setError(false);
      },
      onError: () => {
        if (!isError) {
          setError(true);
          openNotification('error', 'Error', 'Failed to response the status of local import!');
        }
      },
      onSettled: () => {
        setRequesting(false);
      },
      refetchInterval: 3000,
      keepPreviousData: true,
    },
  );

  const openDeleteModal = useCallback(
    (jobId: number) => {
      openAntdModal('confirm', {
        className: 'delete-local-job',
        title: 'Delete Local Import',
        content: 'Are you sure to delete local import?',
        okText: 'Delete',
        onOk: async () => {
          try {
            await deleteLocalJob(jobId);
            openNotification('success', 'Success', 'Succeed to delete local import.');
          } catch (e) {
            openNotification('error', 'Error', 'Failed to delete local import!');
          } finally {
            refetch();
          }
        },
      });
    },
    [refetch],
  );

  const moveToAdd = useCallback(() => {
    navigate(PAGE_URL.STATUS_LOCAL_ADD);
  }, [navigate]);

  return {
    data,
    isFetching,
    isError,
    openDeleteModal,
    loggedInUserRole,
    moveToAdd,
    moveToHistoryLog,
    isRequesting,
    pagination,
    searchParam,
    hasSearchParam,
    setPagination,
    setSearchParam,
    setRequesting,
    onChangeTable,
  } as const;
}
