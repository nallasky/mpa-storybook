import { usePostErrorLogReqDownload } from '@libs/query/errorlog';
import { openNotification } from '@libs/util/notification';
import { errorLogReqDownload, errorLogSiteInfo, setErrorLogReqDownloadReducer } from '@reducers/slices/errorLog';
import { loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { AntdRangeValue } from '@typesdef/antd';
import { PLAN_FTP_TYPE } from '@typesdef/errorLog';
import { LabeledValue } from 'antd/es/select';
import { AxiosError } from 'axios';
import moment, { Moment } from 'moment';
import { useEffect, useMemo, useState } from 'react';
import { useDispatch } from 'react-redux';
import { requestFailureTooMayRequestMessage, requestSuccessMessage } from '../Modal/ErrorLogDownloadRequest';

export default function useErrorLogDownloadRequest({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const dispatch = useDispatch();
  const [date, setDate] = useState<[Moment, Moment]>([moment(), moment()]);
  const siteInfo = useTypedSelector(errorLogSiteInfo);
  const reqDownload = useTypedSelector(errorLogReqDownload);
  const loginUser = useTypedSelector(loginUserSelector);

  const { mutateAsync: mutateDownload, isLoading: isFetchingDownload } = usePostErrorLogReqDownload({
    onError: (error: AxiosError) => {
      const { response } = error;
      if (response && response.status === 429) {
        openNotification('error', 'Error', requestFailureTooMayRequestMessage, error);
      } else {
        openNotification('error', 'Error', 'Failed to request error log download!', error);
      }
    },
    onSuccess: () => {
      openNotification('success', 'Success', requestSuccessMessage);
    },
    onSettled: () => {
      onClose();
    },
  });

  const curCommand = useMemo(() => {
    if (!reqDownload.command) {
      return [];
    }

    if (reqDownload.type !== 'FTP') {
      const startDate = date[0].format('YYYYMMDD_HHmmss');
      const endDate = date[1].format('YYYYMMDD_HHmmss');
      const dateRange = `${startDate}-${endDate}`;
      return [reqDownload.command[0].trim().replace(/YYYYMMDD_HHmmss-YYYYMMDD_HHmmss/gi, dateRange)];
    }
    return reqDownload.command;
  }, [date, reqDownload]);

  const onOk = async () => {
    const { siteId } = siteInfo;
    const { error_code, occurred_date, type, equipment_name, device, process, equipment_id, logServerCategoryName } =
      reqDownload;

    await mutateDownload({
      siteId: siteId as number,
      userId: loginUser.id,
      error_code: error_code as string,
      occurred_date: occurred_date as string,
      equipment_name: equipment_name as string,
      type: type as PLAN_FTP_TYPE,
      command: curCommand,
      start: date[0].format('YYYY-MM-DD HH:mm:ss'),
      end: date[1].format('YYYY-MM-DD HH:mm:ss'),
      device: device as string,
      process: process as string,
      equipment_id: equipment_id as string,
      logServerCategoryName: logServerCategoryName ?? '',
    });

    onClose();
  };

  function onChangeDate(value: AntdRangeValue | null, dateString: [string, string]) {
    if (value && value[0] && value[1]) {
      setDate([value[0], value[1]]);
    }
  }

  const onChangeSetting = (data: LabeledValue) => {
    const foundData = reqDownload.selectList.find((item) => item.value === data.value);
    if (foundData) {
      dispatch(
        setErrorLogReqDownloadReducer({
          select: data,
          type: foundData.type,
          command: foundData.command,
          before: foundData.before,
          after: foundData.after,
          logServerCategoryName: foundData.logServerCategoryName,
        }),
      );
    }
  };

  const onClearSetting = () => {
    dispatch(
      setErrorLogReqDownloadReducer({
        select: null,
      }),
    );
  };

  useEffect(() => {
    if (visible) {
      const { occurred_date, before, after } = reqDownload;

      let occurrence_date = occurred_date;
      if (moment(occurrence_date, 'YYYY-MM-DD HH:mm:ss').toString() === 'Invalid date') {
        occurrence_date = moment().format('YYYY-MM-DD HH:mm:ss');
      }

      if (before && after) {
        const newBefore =
          before.trim().toLowerCase() === 'now'
            ? moment().hour(0).minute(0).second(0)
            : moment(occurrence_date, 'YYYY-MM-DD HH:mm:ss')
                .hour(0)
                .minute(0)
                .second(0)
                .subtract(moment.duration(+before, 'd'));

        const newAfter =
          after.trim().toLowerCase() === 'now'
            ? moment().hour(23).minute(59).second(59)
            : moment(occurrence_date, 'YYYY-MM-DD HH:mm:ss')
                .hour(23)
                .minute(59)
                .second(59)
                .add(moment.duration(+after, 'd'));

        setDate([newBefore, newAfter]);
      }
    }
  }, [reqDownload, visible]);

  return {
    siteInfo,
    visible,
    onOk,
    onClose,
    date,
    onChangeDate,
    curCommand,
    reqDownload,
    isFetchingDownload,
    onChangeSetting,
    onClearSetting,
  };
}
