import { openAntdModal } from '@components/common/atoms/AntdModal';
import SearchModal, { SearchModalProps } from '@components/common/atoms/SearchModal/SearchModal';
import { ADMINISTRATOR, API_URL, ERROR_LOG_ALL_SETTING, ERROR_LOG_DEFAULT_SETTING } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import useTableSortSearch from '@hooks/useTableSortSearch';
import { downloadBlobRequest } from '@libs/axios/requests';
import { useDeleteErrorLogSetting, useGetErrorLogSettingList } from '@libs/query/errorlog';
import { openNotification } from '@libs/util/notification';
import { errorLogReqSetting, errorLogSiteInfo, setErrorLogReqSettingReducer } from '@reducers/slices/errorLog';
import { loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { ErrorLogSettingState, ErrorLogTagType } from '@typesdef/errorLog';
import { AxiosError } from 'axios';
import saveAs from 'file-saver';
import { useCallback, useEffect, useMemo } from 'react';
import { useDispatch } from 'react-redux';
import { errorLogSettingSearchItems } from '../ErrorLogCommon';
import ErrorLogSettingAddEdit, { ErrorLogSettingAddEditProps } from '../Modal/ErrorLogSettingAddEdit';

interface UseErrorLogSettingTableProps {
  type: ErrorLogTagType;
}

export default function useErrorLogSettingTable({ type }: UseErrorLogSettingTableProps) {
  const selectedSite = useTypedSelector(errorLogSiteInfo);
  const loginUser = useTypedSelector(loginUserSelector);
  const reqSetting = useTypedSelector(errorLogReqSetting);
  const dispatch = useDispatch();
  const isAdmin = loginUser.username === ADMINISTRATOR;
  const isDefault = type === 'default' ? true : false;
  const {
    isRequesting,
    pagination,
    searchParam,
    hasSearchParam,
    setPagination,
    setSearchParam,
    setRequesting,
    onChangeTable,
  } = useTableSortSearch();
  const { openModal } = useModals();

  const { data, isFetching, refetch } = useGetErrorLogSettingList(
    {
      paths: {
        siteId: selectedSite.siteId as number,
        userId: reqSetting?.value as string | number,
      },
      query: {
        isDefault,
      },
      pagination: {
        size: pagination.pageSize,
        page: pagination.current - 1,
        sort: pagination.sort,
      },
      search: searchParam,
    },
    {
      enabled: Boolean(selectedSite.siteId) && Boolean(reqSetting?.value),
      onSuccess: (data) => {
        setPagination({
          total: data.totalElements,
        });
      },
      onError: () => {
        openNotification('error', 'Error', `Failed to get list of error log setting list!`);
      },
      onSettled: () => {
        setRequesting(false);
      },
      keepPreviousData: true,
    },
  );

  const { mutateAsync: mutateAsyncDelete } = useDeleteErrorLogSetting();

  const onExport = useCallback(() => {
    openAntdModal('confirm', {
      title: 'Export Error Log Setting',
      content: `Are you sure to export error log setting for '${reqSetting?.label}'?`,
      okText: 'Export',
      onOk: async () => {
        try {
          if (selectedSite.siteId && reqSetting?.value) {
            const { data, fileName } = await downloadBlobRequest({
              url: API_URL.GET_ERROR_LOG_EXPORT(selectedSite.siteId, reqSetting.value),
            });
            saveAs(data, fileName);
            openNotification('success', 'Success', `Succeed to export error log setting '${fileName}'.`);
          } else {
            throw new Error('Not selected User-Fab Name or Setting');
          }
        } catch (e) {
          console.error(e);
          openNotification('error', 'Error', `Failed to export error log setting for '${reqSetting?.label}!`);
        }
      },
    });
  }, [selectedSite, reqSetting]);

  const onAdd = () => {
    openModal<ErrorLogSettingAddEditProps>(MODAL_NAME.ERROR_LOG.ADD_EDIT, ErrorLogSettingAddEdit, {
      siteId: selectedSite.siteId as number,
      userId: reqSetting?.value as string | number,
    });
  };

  const onEdit = (record: ErrorLogSettingState) => {
    openModal<ErrorLogSettingAddEditProps>(MODAL_NAME.ERROR_LOG.ADD_EDIT, ErrorLogSettingAddEdit, {
      data: record,
      siteId: selectedSite.siteId as number,
      userId: reqSetting?.value as string | number,
      itemId: record.id,
    });
  };

  const onDelete = async (record: ErrorLogSettingState) => {
    try {
      await mutateAsyncDelete({
        siteId: selectedSite.siteId as number,
        userId: reqSetting?.value as string | number,
        itemId: record.id,
      });
      openNotification('success', 'Success', `Succeed to delete error log setting for ${record.error_code}.`);
    } catch (error) {
      console.error(error);
      openNotification(
        'error',
        'Error',
        `Failed to delete error log setting for ${record.error_code}!`,
        error as AxiosError,
      );
    } finally {
      refetch();
    }
  };

  const isDisableModify = useMemo(() => {
    if (type === 'default') {
      return !isAdmin;
    } else {
      if (isAdmin) {
        if (reqSetting?.value.toString() === ERROR_LOG_ALL_SETTING.value.toString()) {
          return true;
        }
      } else {
        if (reqSetting?.value.toString() !== loginUser.id.toString()) {
          return true;
        }
      }
    }

    return false;
  }, [isAdmin, loginUser.id, reqSetting?.value, type]);

  const openSearchModal = () => {
    openModal<SearchModalProps>(MODAL_NAME.ERROR_LOG.SEARCH, SearchModal, {
      items: errorLogSettingSearchItems,
      param: searchParam,
      setParam: setSearchParam,
    });
  };

  useEffect(() => {
    if (type === 'default') {
      dispatch(setErrorLogReqSettingReducer(ERROR_LOG_DEFAULT_SETTING));
    } else {
      if (isAdmin) {
        dispatch(setErrorLogReqSettingReducer(ERROR_LOG_ALL_SETTING));
      } else {
        dispatch(
          setErrorLogReqSettingReducer({ key: `${loginUser.id}`, value: `${loginUser.id}`, label: loginUser.username }),
        );
      }
    }
  }, [type, isAdmin, loginUser, dispatch]);

  return {
    data,
    isFetching,
    refetch,
    isAdmin,
    reqSetting,
    onExport,
    loginUser,
    isRequesting,
    pagination,
    searchParam,
    hasSearchParam,
    setPagination,
    setSearchParam,
    setRequesting,
    onChangeTable,
    onAdd,
    onEdit,
    onDelete,
    isDisableModify,
    openSearchModal,
  } as const;
}
