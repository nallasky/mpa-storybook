import FilterModal, { FilterModalProps } from '@components/common/atoms/FilterModal/FilterModal';
import SearchModal, { SearchModalProps } from '@components/common/atoms/SearchModal/SearchModal';
import { ADMINISTRATOR, API_URL, ERROR_LOG_ALL_SETTING } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import useTableSortSearch from '@hooks/useTableSortSearch';
import { useGetErrorLogStatus } from '@libs/query/errorlog';
import { downloadFileUrl } from '@libs/util/download';
import { openNotification } from '@libs/util/notification';
import { errorLogReqStatus, errorLogSiteInfo, setErrorLogReqStatusReducer } from '@reducers/slices/errorLog';
import { loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { useCallback, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { errorLogFilterItems, errorLogStatusSearchItems } from '../ErrorLogCommon';

export default function useErrorLogStatusTable() {
  const selectedSite = useTypedSelector(errorLogSiteInfo);
  const loginUser = useTypedSelector(loginUserSelector);
  const reqStatus = useTypedSelector(errorLogReqStatus);
  const dispatch = useDispatch();
  const [isError, setError] = useState(false);
  const isAdmin = loginUser.username === ADMINISTRATOR;
  const {
    isRequesting,
    pagination,
    searchParam,
    filterParam,
    hasSearchParam,
    hasFilterParam,
    setPagination,
    setSearchParam,
    setFilterParam,
    setRequesting,
    onChangeTable,
  } = useTableSortSearch();
  const { openModal } = useModals();

  const { data, isFetching, refetch } = useGetErrorLogStatus(
    {
      paths: {
        siteId: selectedSite.siteId as number,
        userId: reqStatus?.value as string | number,
      },
      pagination: {
        size: pagination.pageSize,
        page: pagination.current - 1,
        sort: pagination.sort,
      },
      search: searchParam,
      filter: filterParam,
    },
    {
      refetchInterval: 3000,
      enabled: Boolean(selectedSite.siteId) && Boolean(reqStatus?.value),
      onError: () => {
        if (!isError) {
          openNotification('error', 'Error', `Failed to get list of error log!`);
          setError(true);
        }
      },
      onSuccess: (data) => {
        setPagination({
          total: data.totalElements,
        });
        setError(false);
      },
      onSettled: () => {
        setRequesting(false);
      },
    },
  );

  const onClickDownload = useCallback(
    (id: string) => {
      downloadFileUrl(API_URL.GET_ERROR_LOG_DOWNLOAD_FILE(id));
      refetch();
    },
    [refetch],
  );

  const openSearchModal = () => {
    openModal<SearchModalProps>(MODAL_NAME.ERROR_LOG.SEARCH, SearchModal, {
      items: errorLogStatusSearchItems,
      param: searchParam,
      setParam: setSearchParam,
    });
  };

  const openFilterModal = () => {
    openModal<FilterModalProps>(MODAL_NAME.ERROR_LOG.FILTER, FilterModal, {
      items: errorLogFilterItems,
      param: filterParam,
      setParam: setFilterParam,
    });
  };

  useEffect(() => {
    if (isAdmin) {
      dispatch(setErrorLogReqStatusReducer(ERROR_LOG_ALL_SETTING));
    } else {
      const { id, username } = loginUser;
      dispatch(setErrorLogReqStatusReducer({ key: `${id}`, value: id, label: username }));
    }
  }, [isAdmin, loginUser, dispatch]);

  return {
    data,
    isFetching,
    onClickDownload,
    isAdmin,
    isRequesting,
    pagination,
    setPagination,
    searchParam,
    filterParam,
    hasSearchParam,
    hasFilterParam,
    setSearchParam,
    setFilterParam,
    setRequesting,
    onChangeTable,
    openSearchModal,
    openFilterModal,
  } as const;
}
