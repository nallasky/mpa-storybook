import { ResGetSiteName } from '@libs/axios/types';
import { QUERY_KEY } from '@libs/query/queryKey';
import { errorLogSiteInfo } from '@reducers/slices/errorLog';
import useTypedSelector from '@reducers/useTypedSelector';
import { useQueryClient } from '@tanstack/react-query';
import { useMemo } from 'react';

export default function useErrorLogCheckSite() {
  const queryClient = useQueryClient();
  const selectSite = useTypedSelector(errorLogSiteInfo);
  const siteList = queryClient.getQueryData<ResGetSiteName[]>([QUERY_KEY.STATUS_SITE_LIST]);

  const isExistSite = useMemo(() => {
    if (!siteList || !selectSite?.siteId) {
      return false;
    }
    return siteList.some((item) => item.siteId === selectSite.siteId);
  }, [siteList, selectSite]);

  return {
    isExistSite,
  };
}
