import FilterModal, { FilterModalProps } from '@components/common/atoms/FilterModal/FilterModal';
import SearchModal, { SearchModalProps } from '@components/common/atoms/SearchModal/SearchModal';
import { ADMINISTRATOR, ERROR_LOG_ALL_SETTING, ERROR_LOG_DEFAULT_USER, PAGE_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import useTableSortSearch from '@hooks/useTableSortSearch';
import { useGetErrorLogList, useGetErrorLogSettingList } from '@libs/query/errorlog';
import { openNotification } from '@libs/util/notification';
import {
  errorLogReqSetting,
  errorLogSiteInfo,
  setErrorLogReqDownloadReducer,
  setErrorLogReqSettingReducer,
} from '@reducers/slices/errorLog';
import { loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { ErrorLogSettingLabelState, ErrorLogSettingState, ErrorLogState } from '@typesdef/errorLog';
import { useCallback, useEffect, useMemo } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import { errorLogFilterItems, errorLogSearchItems } from '../ErrorLogCommon';
import ErrorLogDownloadRequest from '../Modal/ErrorLogDownloadRequest';

export default function useErrorLogDownloadTable() {
  const dispatch = useDispatch();
  const selectedSite = useTypedSelector(errorLogSiteInfo);
  const reqSetting = useTypedSelector(errorLogReqSetting);
  const loginUser = useTypedSelector(loginUserSelector);
  const navigate = useNavigate();
  const {
    isRequesting,
    pagination,
    searchParam,
    hasSearchParam,
    filterParam,
    hasFilterParam,
    setPagination,
    setSearchParam,
    setFilterParam,
    setRequesting,
    onChangeTable,
  } = useTableSortSearch();
  const { openModal } = useModals();

  const {
    data: list,
    isFetching: isFetchingList,
    refetch: refetchList,
  } = useGetErrorLogList(
    {
      paths: {
        siteId: selectedSite.siteId as number,
      },
      pagination: {
        size: pagination.pageSize,
        page: pagination.current - 1,
        sort: pagination.sort,
      },
      search: searchParam,
      filter: filterParam,
    },
    {
      enabled: Boolean(selectedSite.siteId) && Boolean(reqSetting?.value),
      onSuccess: (data) => {
        setPagination({ total: data.totalElements });
      },
      onError: () => {
        openNotification('error', 'Error', `Failed to get list of error log!`);
      },
      onSettled: () => {
        setRequesting(false);
      },
      keepPreviousData: true,
    },
  );

  const {
    data: settingList,
    isFetching: isFetchingSettingList,
    refetch: refetchSettingList,
  } = useGetErrorLogSettingList(
    {
      paths: {
        siteId: selectedSite.siteId as number,
        userId: reqSetting?.value as string | number,
      },
      query: {
        isDefault: true,
      },
    },
    {
      enabled: Boolean(selectedSite.siteId) && Boolean(reqSetting?.value),
      onError: () => {
        openNotification('error', 'Error', `Failed to get list of error log setting list!`);
      },
    },
  );

  const isFetching = useMemo(() => isFetchingList || isFetchingSettingList, [isFetchingList, isFetchingSettingList]);

  const isMatchedBySettingCode = useCallback(
    (record: ErrorLogState) => isMatchedByCode(record, settingList?.content),
    [settingList],
  );

  const onClickReqDownload = (record: ErrorLogState) => {
    const filteredList = filteredByCode(record, settingList?.content);
    if (filteredList) {
      const selectList: ErrorLogSettingLabelState[] = filteredList.map((item) => {
        if (item.userName === ADMINISTRATOR) {
          const uuid = uuidv4();
          return {
            key: `${uuid}_${ERROR_LOG_DEFAULT_USER.userId}`,
            value: `${uuid}_${ERROR_LOG_DEFAULT_USER.userId}`,
            label: `${ERROR_LOG_DEFAULT_USER.username} (${item.error_code})`,
            ...item,
          };
        } else {
          const uuid = uuidv4();
          return {
            key: `${uuid}_${item.userId}`,
            value: `${uuid}_${item.userId}`,
            label: `${item.userName} (${item.error_code})`,
            ...item,
          };
        }
      });

      let select: ErrorLogSettingLabelState;
      let selectData: ErrorLogSettingState;
      const defaultSetIdx = selectList.findIndex((item) => item.key === `${ERROR_LOG_DEFAULT_USER.userId}`);

      if (loginUser.username === ADMINISTRATOR) {
        select = defaultSetIdx !== -1 ? selectList[defaultSetIdx] : selectList[0];
        selectData = defaultSetIdx !== -1 ? filteredList[defaultSetIdx] : filteredList[0];
      } else {
        const userSetIdx = selectList.findIndex((item) => item.key === `${loginUser.id}`);
        select = userSetIdx !== -1 ? selectList[userSetIdx] : selectList[0];
        selectData = userSetIdx !== -1 ? filteredList[userSetIdx] : filteredList[0];
      }

      dispatch(
        setErrorLogReqDownloadReducer({
          select,
          selectList,
          error_code: record.error_code,
          occurred_date: record.occurred_date,
          equipment_name: record.equipment_name,
          type: selectData.type,
          command: selectData.command,
          before: selectData.before,
          after: selectData.after,
          device: record.device,
          process: record.process,
          equipment_id: record.equipment_id,
          logServerCategoryName: selectData.logServerCategoryName,
        }),
      );

      openModal(MODAL_NAME.ERROR_LOG.DOWNLOAD, ErrorLogDownloadRequest);
    }
  };

  const onClickDownloadList = () => {
    navigate(PAGE_URL.ERROR_LOG_STATUS);
  };

  const onClickRefresh = () => {
    refetchList();
    refetchSettingList();
  };

  const openSearchModal = () => {
    openModal<SearchModalProps>(MODAL_NAME.ERROR_LOG.SEARCH, SearchModal, {
      items: errorLogSearchItems,
      param: searchParam,
      setParam: setSearchParam,
    });
  };

  const openFilterModal = () => {
    openModal<FilterModalProps>(MODAL_NAME.ERROR_LOG.FILTER, FilterModal, {
      items: errorLogFilterItems,
      param: filterParam,
      setParam: setFilterParam,
    });
  };

  useEffect(() => {
    if (loginUser.username === ADMINISTRATOR) {
      dispatch(setErrorLogReqSettingReducer(ERROR_LOG_ALL_SETTING));
    } else {
      const { id, username } = loginUser;
      dispatch(
        setErrorLogReqSettingReducer({
          key: `${id}`,
          value: id,
          label: username,
        }),
      );
    }
  }, [dispatch, loginUser]);

  return {
    list,
    settingList,
    isFetching,
    selectedSite,
    onClickReqDownload,
    onClickDownloadList,
    onClickRefresh,
    isMatchedBySettingCode,
    isRequesting,
    pagination,
    searchParam,
    filterParam,
    hasSearchParam,
    hasFilterParam,
    setPagination,
    setSearchParam,
    setFilterParam,
    setRequesting,
    onChangeTable,
    openSearchModal,
    openFilterModal,
  };
}

const isInCludedCode = (code: string | null, range: string | null) => {
  if (code && range) {
    const [start, end] = range.split('-');
    const startCode = start ? parseInt(start, 16) : -1;
    const endCode = end ? parseInt(end, 16) : -1;
    const targetCode = parseInt(code, 16);

    if (startCode !== -1 && endCode !== -1) {
      return targetCode >= startCode && targetCode <= endCode;
    }

    if (startCode !== -1 && endCode === -1) {
      return targetCode === startCode;
    }
  }
  return false;
};

const isMatchedByCode = (record: ErrorLogState, list: ErrorLogSettingState[] | undefined) =>
  list?.some((item) => isInCludedCode(record.error_code, item.error_code)) ?? false;

const filteredByCode = (record: ErrorLogState, list: ErrorLogSettingState[] | undefined) =>
  list?.filter((item) => isInCludedCode(record.error_code, item.error_code));
