import {
  useGetErrorLogCategoryOptions,
  usePostErrorLogSettingAdd,
  usePutErrorLogSettingEdit,
} from '@libs/query/errorlog';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { ErrorLogSettingState } from '@typesdef/errorLog';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { useForm, useWatch } from 'antd/lib/form/Form';
import { useEffect } from 'react';
import { ErrorLogSettingAddEditProps } from '../Modal/ErrorLogSettingAddEdit';

export interface FormErrorLogSettingAddEdit extends ErrorLogSettingState {
  error_code_arr: string[];
  command_vftp: string;
  before_now: boolean;
  after_now: boolean;
}

export default function useErrorLogSettingAddEdit({
  visible,
  onClose,
  data,
  siteId,
  userId,
  itemId,
}: GlobalModalDefaultProps<ErrorLogSettingAddEditProps>) {
  const queryClient = useQueryClient();
  const [form] = useForm<FormErrorLogSettingAddEdit>();
  const modeText = data ? 'Edit' : 'Add';
  const formErrorCodeArr = useWatch('error_code_arr', form);
  const formType = useWatch('type', form);
  const formBeforeNow = useWatch('before_now', form);
  const formAfterNow = useWatch('after_now', form);

  const { data: categoryOptions, isFetching: isFetchingOptions } = useGetErrorLogCategoryOptions(siteId as number, {
    onError: (error) => {
      openNotification('error', 'Error', `Failed to get list of category list!`, error);
    },
  });

  const { mutate: mutateAdd, isLoading: isLoadingAdd } = usePostErrorLogSettingAdd({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to add error log setting item!`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to add error log setting item!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.ERROR_LOG_SETTING_LIST], {
        exact: false,
      });
      onClose();
    },
  });

  const { mutate: mutateEdit, isLoading: isLoadingEdit } = usePutErrorLogSettingEdit({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to edit error log setting item!`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to edit error log setting item!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.ERROR_LOG_SETTING_LIST], {
        exact: false,
      });
      onClose();
    },
  });

  const onOk = async () => {
    try {
      const {
        type,
        command,
        before,
        after,
        error_code_arr,
        command_vftp,
        before_now,
        after_now,
        logServerCategoryName,
      } = form.getFieldsValue();
      const reqErrorCode = error_code_arr.length > 1 ? `${error_code_arr.join('-')}` : error_code_arr[0];
      const reqCommand = type === 'FTP' ? command : [command_vftp];
      const reqBefore = before_now ? 'NOW' : before;
      const reqAfter = after_now ? 'NOW' : after;

      await form.validateFields();

      if (modeText === 'Add') {
        if (!siteId || !userId) {
          throw new Error('siteId and userId are required!');
        }

        mutateAdd({
          siteId,
          userId,
          data: {
            error_code: reqErrorCode,
            type,
            after: reqAfter,
            before: reqBefore,
            command: reqCommand,
            logServerCategoryName,
          },
        });
      } else {
        if (!siteId || !userId || !itemId) {
          throw new Error('siteId, userId and itemId are required!');
        }
        mutateEdit({
          siteId,
          userId,
          itemId,
          data: {
            error_code: reqErrorCode,
            type,
            after: reqAfter,
            before: reqBefore,
            command: reqCommand,
            logServerCategoryName,
          },
        });
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (data) {
      const { error_code, type, command, before, after, logServerCategoryName } = data;
      form.setFieldsValue({
        error_code,
        error_code_arr: error_code.split('-').map((item) => item.trim()),
        type,
        command: type === 'FTP' ? command : [],
        command_vftp: type === 'FTP' ? '' : command[0].trim(),
        before: before.toLowerCase().trim() === 'now' ? undefined : before,
        after: after.toLowerCase().trim() === 'now' ? undefined : after,
        before_now: before.toLowerCase().trim() === 'now',
        after_now: after.toLowerCase().trim() === 'now',
        logServerCategoryName: logServerCategoryName ?? '',
      });
    } else {
      form.setFieldsValue({
        error_code: '',
        error_code_arr: [''],
        type: 'FTP',
        command: [],
        command_vftp: '',
        before: '0',
        after: '0',
        before_now: false,
        after_now: false,
        logServerCategoryName: '',
      });
    }
  }, [data, form]);

  return {
    form,
    modeText,
    formErrorCodeArr,
    formType,
    formBeforeNow,
    formAfterNow,
    categoryOptions,
    isLoadingAddEdit: isLoadingAdd || isLoadingEdit,
    isFetchingOptions,
    onOk,
  };
}
