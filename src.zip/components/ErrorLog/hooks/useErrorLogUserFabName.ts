import { useGetUserFabNameList } from '@libs/query/common';
import { openNotification } from '@libs/util/notification';
import { errorLogSiteInfo, setErrorLogSite } from '@reducers/slices/errorLog';
import useTypedSelector from '@reducers/useTypedSelector';
import { LabeledValue } from 'antd/es/select';
import { useCallback, useMemo } from 'react';
import { useDispatch } from 'react-redux';

export default function useErrorLogUserFabName() {
  const selectedSite = useTypedSelector(errorLogSiteInfo);
  const dispatch = useDispatch();

  const {
    data: siteList,
    isFetching: isFetchingSiteList,
    refetch: refetchSiteList,
  } = useGetUserFabNameList({
    onSuccess: (data) => {
      if (selectedSite && selectedSite.siteId && !data.some((item) => item.siteId === selectedSite.siteId)) {
        dispatch(
          setErrorLogSite({
            siteId: null,
            siteName: null,
          }),
        );
      }
    },
    onError: () => {
      dispatch(
        setErrorLogSite({
          siteId: null,
          siteName: null,
        }),
      );
      openNotification('error', 'Error', `Failed to get user-fab name list.`);
    },
  });

  const refreshSiteList = useCallback(() => {
    refetchSiteList();
  }, [refetchSiteList]);

  const onChangeSiteInfo = useCallback(
    ({ value, label }: LabeledValue) => {
      dispatch(
        setErrorLogSite({
          siteId: (value as number) ?? null,
          siteName: (label as string) ?? null,
        }),
      );
    },
    [dispatch],
  );

  const onClearSiteInfo = useCallback(() => {
    dispatch(
      setErrorLogSite({
        siteId: null,
        siteName: null,
      }),
    );
  }, [dispatch]);

  const labeledSiteInfo = useMemo(
    (): LabeledValue => ({
      key: `${selectedSite.siteId}`,
      value: selectedSite.siteId as number,
      label: selectedSite.siteName,
    }),
    [selectedSite],
  );

  return {
    siteList,
    isFetchingSiteList,
    refreshSiteList,
    labeledSiteInfo,
    onChangeSiteInfo,
    onClearSiteInfo,
  };
}
