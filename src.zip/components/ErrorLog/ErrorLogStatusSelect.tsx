import { ERROR_LOG_ALL_SETTING } from '@constants/constants';
import { css } from '@emotion/react';
import { useGetAccountUserSummaryListWithAdmin } from '@libs/query/account';
import { errorLogReqStatus, setErrorLogReqStatusReducer } from '@reducers/slices/errorLog';
import useTypedSelector from '@reducers/useTypedSelector';
import { Select } from 'antd';
import { LabeledValue } from 'antd/es/select';
import { useCallback } from 'react';
import { useDispatch } from 'react-redux';

export type ErrorLogStatusSelectProps = {};

export default function ErrorLogStatusSelect({}: ErrorLogStatusSelectProps) {
  const reqStatus = useTypedSelector(errorLogReqStatus);
  const dispatch = useDispatch();

  const { data: users, isFetching: isFetchingUsers, refetch: refetchUsers } = useGetAccountUserSummaryListWithAdmin();

  const onSelectStatus = useCallback(
    (value: LabeledValue) => {
      dispatch(setErrorLogReqStatusReducer(value));
    },
    [dispatch],
  );

  const onClearStatus = useCallback(() => {
    dispatch(setErrorLogReqStatusReducer(null));
  }, [dispatch]);

  return (
    <Select<LabeledValue>
      showSearch
      labelInValue
      value={reqStatus}
      placeholder="Select a account"
      onSelect={onSelectStatus}
      loading={isFetchingUsers}
      optionFilterProp="children"
      filterOption={(input, option) =>
        Boolean((option?.children as unknown as string).toLowerCase().indexOf(input.toLowerCase()) >= 0)
      }
      allowClear
      onClear={onClearStatus}
      css={style}
    >
      <Select.Option
        key={ERROR_LOG_ALL_SETTING.key}
        value={ERROR_LOG_ALL_SETTING.value}
        label={ERROR_LOG_ALL_SETTING.label}
      >
        {ERROR_LOG_ALL_SETTING.label}
      </Select.Option>
      {users?.map((item) => (
        <Select.Option key={item.id} value={item.id} label={item.username}>
          {item.username}
        </Select.Option>
      ))}
    </Select>
  );
}

const style = css`
  width: 10rem;
`;
