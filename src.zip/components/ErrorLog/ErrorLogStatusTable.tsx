import { DownloadOutlined } from '@ant-design/icons';
import CustomIcon from '@components/common/atoms/CustomIcon';
import { getFilteredText } from '@components/common/atoms/FilterModal/FilterModal';
import FilterModalButton from '@components/common/atoms/FilterModal/FilterModalButton';
import { getSearchedText } from '@components/common/atoms/SearchModal/SearchModal';
import SearchModalButton from '@components/common/atoms/SearchModal/SearchModalButton';
import { V_SPACE } from '@components/common/atoms/Space';
import StatusBadge from '@components/common/atoms/StatusBadge/StatusBadge';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import TableScrollTitle from '@components/common/atoms/TableScrollTitle';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { enableHoverActiveStyle, hoverStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { ErrorLogStatusState, PLAN_FTP_TYPE } from '@typesdef/errorLog';
import { JobStatusType } from '@typesdef/Job';
import { Popconfirm, Space, Spin, Table, Tooltip } from 'antd';
import { Fragment, useRef } from 'react';
import { errorLogFilterItems, errorLogStatusSearchItems, getErrorLogRank, getErrorLogUnit } from './ErrorLogCommon';
import ErrorLogStatusSelect from './ErrorLogStatusSelect';
import useErrorLogStatusTable from './hooks/useErrorLogStatusTable';

export type ErrorLogStatusTableProps = {};

export default function ErrorLogStatusTable({}: ErrorLogStatusTableProps) {
  const {
    data,
    onClickDownload,
    isAdmin,
    isRequesting,
    pagination,
    searchParam,
    filterParam,
    hasSearchParam,
    hasFilterParam,
    setSearchParam,
    setFilterParam,
    onChangeTable,
    openSearchModal,
    openFilterModal,
  } = useErrorLogStatusTable();
  const tableRef = useRef<HTMLDivElement>(null);

  const typeRender = (value: PLAN_FTP_TYPE, record: ErrorLogStatusState, index: number) => {
    let valueRender;

    if (value === 'FTP') {
      valueRender = <div>{value}</div>;
    } else {
      valueRender = (
        <div>
          <div>VFTP</div>
          <div>{value.replace('VFTP', '')}</div>
        </div>
      );
    }

    return (
      <Tooltip title={<TypeComponent value={value} record={record} />} placement="right">
        <div css={hoverStyle}>{valueRender}</div>
      </Tooltip>
    );
  };

  const statusRender = (value: JobStatusType, record: ErrorLogStatusState, index: number) => {
    return (
      <Space>
        <StatusBadge value={value} />
        {record.error && value === 'failure' && (
          <Tooltip placement="top" title={record.error} color="red">
            <CustomIcon
              css={css`
                color: red;
              `}
              name="warning"
            />
            {/* it need to diplay tooltip */}
            <div></div>
          </Tooltip>
        )}
      </Space>
    );
  };

  const renderDownload = (value: number, record: ErrorLogStatusState, index: number) => {
    const { status, download_id } = record;

    return (
      <div>
        <Popconfirm
          title="Are you sure to download?"
          onConfirm={() => onClickDownload(download_id)}
          okText="Yes"
          cancelText="No"
          placement="left"
          disabled={Boolean(status !== 'success')}
        >
          {status === 'processing' && <Spin size="small" />}
          {(status === 'failure' || status === 'downloaded') && (
            <div key={value} css={enableHoverActiveStyle(false)}>
              -
            </div>
          )}
          {status === 'success' && <DownloadOutlined key={value} css={enableHoverActiveStyle(true)} />}
        </Popconfirm>
      </div>
    );
  };

  const titleRender = () => (
    <TableHeader
      title={
        <TableHeaderTitle
          total={pagination.total}
          isSearched={hasSearchParam}
          searchedText={getSearchedText(errorLogStatusSearchItems, searchParam)}
          onResetSearch={() => setSearchParam({})}
          isFiltered={hasFilterParam}
          FilteredText={getFilteredText(errorLogFilterItems, filterParam)}
          onResetFilter={() => setFilterParam({})}
          color="green"
        />
      }
    >
      <SearchModalButton hasParam={hasSearchParam} onClick={() => openSearchModal()} />
      <FilterModalButton hasParam={hasFilterParam} onClick={() => openFilterModal()} />
      {isAdmin && <ErrorLogStatusSelect />}
    </TableHeader>
  );

  const rankRender = (value: string, record: ErrorLogStatusState, index: number) => {
    // return <div>{getErrorLogRank(value)}</div>;
    return <div>{value === 'BD' ? 'B/D' : value}</div>;
  };

  const unitRender = (value: string, record: ErrorLogStatusState, index: number) => {
    // return <div>{getErrorLogUnit(value)}</div>;
    return <div>{value}</div>;
  };

  return (
    <div>
      <Table<ErrorLogStatusState>
        rowKey={'id'}
        dataSource={data?.content}
        bordered
        title={titleRender}
        size="small"
        pagination={{
          position: ['bottomCenter'],
          showSizeChanger: true,
          current: pagination.current,
          pageSize: pagination.pageSize,
          total: pagination.total,
        }}
        tableLayout="fixed"
        scroll={{ x: 'max-content' }}
        onChange={onChangeTable}
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
        loading={isRequesting}
        ref={tableRef}
      >
        {isAdmin ? (
          <Fragment>
            <Table.Column<ErrorLogStatusState>
              {...columnProps.userName}
              title={<TableScrollTitle title="Account" ref={tableRef} direction="left" />}
            />
            <Table.Column<ErrorLogStatusState> {...columnProps.error_code} />
          </Fragment>
        ) : (
          <Table.Column<ErrorLogStatusState>
            {...columnProps.error_code}
            title={<TableScrollTitle title="Error Code" ref={tableRef} direction="left" />}
          />
        )}

        <Table.Column<ErrorLogStatusState> {...columnProps.unit} render={unitRender} />
        <Table.Column<ErrorLogStatusState> {...columnProps.rank} render={rankRender} />
        <Table.Column<ErrorLogStatusState> {...columnProps.equipment_name} />
        <Table.Column<ErrorLogStatusState> {...columnProps.occurred_date} />
        <Table.Column<ErrorLogStatusState> {...columnProps.device} />
        <Table.Column<ErrorLogStatusState> {...columnProps.process} />
        <Table.Column<ErrorLogStatusState> {...columnProps.type} render={typeRender} />
        <Table.Column<ErrorLogStatusState> {...columnProps.requestDate} />
        <Table.Column<ErrorLogStatusState> {...columnProps.status} render={statusRender} />
        <Table.Column<ErrorLogStatusState>
          {...columnProps.download}
          render={renderDownload}
          title={<TableScrollTitle title="Download" ref={tableRef} direction="right" />}
        />
      </Table>
    </div>
  );
}

type ColumnName =
  | 'userName'
  | 'error_code'
  | 'unit'
  | 'rank'
  | 'equipment_name'
  | 'occurred_date'
  | 'device'
  | 'process'
  | 'type'
  | 'requestDate'
  | 'status'
  | 'download';

const columnProps: TableColumnPropsType<ErrorLogStatusState, ColumnName> = {
  userName: {
    key: 'userName',
    title: <TableColumnTitle>Account</TableColumnTitle>,
    dataIndex: 'userName',
    align: 'center',
    sorter: true,
    width: 150,
    fixed: 'left',
  },
  error_code: {
    key: 'error_code',
    title: <TableColumnTitle>Error Code</TableColumnTitle>,
    dataIndex: 'error_code',
    align: 'center',
    sorter: true,
    width: 140,
    fixed: 'left',
  },
  unit: {
    title: <TableColumnTitle>Unit</TableColumnTitle>,
    key: 'unit',
    dataIndex: 'unit',
    align: 'center',
    sorter: true,
    // shouldCellUpdate: (cur, prev) => cur.error_code !== prev.error_code,
    width: 100,
  },
  rank: {
    title: <TableColumnTitle>Rank</TableColumnTitle>,
    key: 'rank',
    dataIndex: 'rank',
    align: 'center',
    sorter: true,
    // shouldCellUpdate: (cur, prev) => cur.error_code !== prev.error_code,
    width: 100,
  },
  equipment_name: {
    key: 'equipment_name',
    title: <TableColumnTitle>Equipment Name</TableColumnTitle>,
    dataIndex: 'equipment_name',
    align: 'center',
    sorter: true,
    width: 260,
  },
  occurred_date: {
    key: 'occurred_date',
    title: <TableColumnTitle>Occurred Date</TableColumnTitle>,
    dataIndex: 'occurred_date',
    align: 'center',
    sorter: true,
    width: 190,
  },
  device: {
    key: 'device',
    title: <TableColumnTitle>Device</TableColumnTitle>,
    dataIndex: 'device',
    align: 'center',
    sorter: true,
    width: 120,
  },
  process: {
    key: 'process',
    title: <TableColumnTitle>Process</TableColumnTitle>,
    dataIndex: 'process',
    align: 'center',
    sorter: true,
    width: 120,
  },
  type: {
    key: 'type',
    title: <TableColumnTitle>Type</TableColumnTitle>,
    dataIndex: 'type',
    align: 'center',
    sorter: true,
    width: 130,
  },
  requestDate: {
    key: 'requestDate',
    title: <TableColumnTitle>Request Date</TableColumnTitle>,
    dataIndex: 'requestDate',
    align: 'center',
    sorter: true,
    width: 170,
  },
  status: {
    key: 'status',
    title: <TableColumnTitle>Status</TableColumnTitle>,
    dataIndex: 'status',
    align: 'center',
    sorter: true,
    width: 130,
    fixed: 'right',
  },
  download: {
    key: 'download',
    title: <TableColumnTitle>Download</TableColumnTitle>,
    dataIndex: 'index',
    align: 'center',
    width: 120,
    fixed: 'right',
  },
};

const columnWidth = {
  withAccount: {
    userName: getPixelPercent(1344, 150),
    error_code: getPixelPercent(1344, 110),
    equipment_name: getPixelPercent(1344, 214),
    occurred_date: getPixelPercent(1344, 170),
    device: getPixelPercent(1344, 100),
    process: getPixelPercent(1344, 100),
    type: getPixelPercent(1344, 120),
    requestDate: getPixelPercent(1344, 170),
    status: getPixelPercent(1344, 120),
    download: getPixelPercent(1344, 90),
  },
  withoutAccount: {
    userName: getPixelPercent(1344, 0),
    error_code: getPixelPercent(1344, 140),
    equipment_name: getPixelPercent(1344, 254),
    occurred_date: getPixelPercent(1344, 190),
    device: getPixelPercent(1344, 120),
    process: getPixelPercent(1344, 120),
    type: getPixelPercent(1344, 130),
    requestDate: getPixelPercent(1344, 170),
    status: getPixelPercent(1344, 130),
    download: getPixelPercent(1344, 90),
  },
};

interface TypeComponentsProps {
  value: PLAN_FTP_TYPE;
  record: ErrorLogStatusState;
  index?: number;
}

function TypeComponent({ value, record, index }: TypeComponentsProps) {
  const { command, start, end } = record;
  const title = value === 'FTP' ? '[Log Name]' : '[Command]';
  const content =
    value === 'FTP' ? (
      command.map((item) => <div key={item}>{`• ${item.trim()}`}</div>)
    ) : (
      <div>{`• ${record.command[0]}`}</div>
    );

  return (
    <div
      css={css`
        max-height: 30rem;
        overflow: auto;
      `}
    >
      <div>{title}</div>
      <div
        css={css`
          margin-right: 0.5rem;
        `}
      >
        {content}
      </div>
      <V_SPACE />
      <div>[Collecting Date]</div>
      <div>{`${start} ~`}</div>
      <div>{`${end}`}</div>
    </div>
  );
}
