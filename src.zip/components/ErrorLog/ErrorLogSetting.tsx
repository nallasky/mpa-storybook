import { initErrorLogWithoutSiteReducer } from '@reducers/slices/errorLog';
import { ErrorLogTagType } from '@typesdef/errorLog';
import { Badge, Tabs } from 'antd';
import { useEffect, useMemo, useState } from 'react';
import { useDispatch } from 'react-redux';
import ErrorLogSettingTable from './ErrorLogSettingTable';
import useErrorLogCheckSite from './hooks/useErrorLogCheckSite';
import { errorLogStyle } from './styles/errorLogStyle';

export type ErrorLogTableProps = {};

export default function ErrorLogSetting({}: ErrorLogTableProps): JSX.Element {
  const [activeKey, setActiveKey] = useState<ErrorLogTagType>('default');
  const dispatch = useDispatch();
  const { isExistSite } = useErrorLogCheckSite();

  const settingPanes = useMemo(
    () => [
      {
        title: 'Default',
        key: 'default',
        contents: <ErrorLogSettingTable type={activeKey} />,
      },
      {
        title: 'User',
        key: 'user',
        contents: <ErrorLogSettingTable type={activeKey} />,
      },
    ],
    [activeKey],
  );

  useEffect(() => {
    return () => {
      dispatch(initErrorLogWithoutSiteReducer());
    };
  }, [dispatch]);

  return (
    <div css={errorLogStyle}>
      <div className="content__title">
        <Badge color="blue" />
        <span>Setting</span>
      </div>
      {isExistSite && (
        <div className="content__table">
          <Tabs hideAdd onChange={(key) => setActiveKey(key as ErrorLogTagType)} activeKey={activeKey} type="card">
            {settingPanes.map((pane) => (
              <Tabs.TabPane key={pane.key} tab={pane.title}>
                {pane.contents}
              </Tabs.TabPane>
            ))}
          </Tabs>
        </div>
      )}
    </div>
  );
}
