import { V_SPACE } from '@components/common/atoms/Space';
import { css } from '@emotion/react';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Badge, Button, DatePicker, Modal, Select } from 'antd';
import { LabeledValue } from 'antd/es/select';
import React, { Fragment } from 'react';
import useErrorLogDownloadRequest from '../hooks/useErrorLogDownloadRequest';

export default React.memo(function ErrorLogDownloadRequest({
  visible,
  onClose,
}: GlobalModalDefaultProps<{}>): JSX.Element {
  const {
    siteInfo,
    onOk,
    date,
    onChangeDate,
    curCommand,
    reqDownload,
    isFetchingDownload,
    onChangeSetting,
    onClearSetting,
  } = useErrorLogDownloadRequest({ visible, onClose });

  return (
    <Modal
      title="Error Log Download"
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width={750}
      destroyOnClose
      footer={[
        <Button key="close" type="primary" onClick={onClose} disabled={isFetchingDownload}>
          Close
        </Button>,
        <Button key="download" type="primary" onClick={onOk} loading={isFetchingDownload} disabled={isFetchingDownload}>
          Download
        </Button>,
      ]}
    >
      <div css={style}>
        <div className="setting">
          <div className="name">
            <Badge color="blue" />
            <span>Setting</span>
          </div>
          <div className="value">
            <Select<LabeledValue>
              showSearch
              labelInValue
              value={reqDownload.select ?? undefined}
              placeholder="Select a setting."
              onSelect={onChangeSetting}
              optionFilterProp="children"
              filterOption={(input, option) =>
                Boolean((option?.children as unknown as string).toLowerCase().indexOf(input.toLowerCase()) >= 0)
              }
              onClear={onClearSetting}
            >
              {reqDownload.selectList?.map((item) => (
                <Select.Option key={item.key} value={item.value} label={item.label}>
                  {item.label}
                </Select.Option>
              ))}
            </Select>
          </div>
        </div>
        <V_SPACE />
        <div className="user-fab-name">
          <div className="name">
            <Badge color="blue" />
            <span>User-Fab Name</span>
          </div>
          <div className="value">{siteInfo.siteName}</div>
        </div>
        <V_SPACE />
        <div className="error-code">
          <div className="name">
            <Badge color="blue" />
            <span>Error Code</span>
          </div>
          <div className="value">{reqDownload.error_code}</div>
        </div>
        <V_SPACE />
        <div className="equipment-name">
          <div className="name">
            <Badge color="blue" />
            <span>Equipment Name</span>
          </div>
          <div className="value">{reqDownload.equipment_name}</div>
        </div>
        <V_SPACE />
        <div className="error-date">
          <div className="name">
            <Badge color="blue" />
            <span>Error Date</span>
          </div>
          <div className="value">{reqDownload.occurred_date}</div>
        </div>
        <V_SPACE />
        <div className="device">
          <div className="name">
            <Badge color="blue" />
            <span>Device</span>
          </div>
          <div className="value">{reqDownload.device}</div>
        </div>
        <V_SPACE />
        <div className="process">
          <div className="name">
            <Badge color="blue" />
            <span>Process</span>
          </div>
          <div className="value">{reqDownload.process}</div>
        </div>
        <V_SPACE />
        <div className="collecting-date">
          <div className="name">
            <Badge color="blue" />
            <span>Collecting Date</span>
          </div>
          <DatePicker.RangePicker
            showTime={{ format: 'HH:mm' }}
            format="YYYY-MM-DD HH:mm"
            onChange={onChangeDate}
            // onOk={onOk}
            value={date}
          />
        </div>
        <V_SPACE />
        <div className="type">
          <div className="name">
            <Badge color="blue" />
            <span>Type</span>
          </div>
          <div className="value">{reqDownload.type}</div>
        </div>

        <V_SPACE />
        <div className="command">
          <div className="name">
            <Badge color="blue" />
            <span>{reqDownload.type === 'FTP' ? 'Log Name' : 'Command'}</span>
          </div>
          <div className="value">{curCommand.join(', ')}</div>
        </div>

        {reqDownload.type !== 'FTP' && (
          <Fragment>
            <V_SPACE />
            <div className="log-server-category-name">
              <div className="name">
                <Badge color="blue" />
                <span>Log Server Category Name</span>
              </div>
              <div className="value">{reqDownload.logServerCategoryName ?? ''}</div>
            </div>
          </Fragment>
        )}
      </div>
    </Modal>
  );
});

const style = css`
  display: flex;
  flex-direction: column;

  .setting,
  .user-fab-name,
  .error-code,
  .equipment-name,
  .error-date,
  .device,
  .process,
  .collecting-date,
  .type,
  .command,
  .log-server-category-name {
    display: flex;
    flex-direction: row;
    .name {
      width: 15rem;
    }
    .value {
      width: 25rem;
    }
  }

  .collecting-date {
    align-items: center;
  }

  .setting {
    .ant-select {
      width: 24.125rem;
    }
  }
`;

export const requestSuccessMessage = (
  <div>
    <div>{'Succeed to request error log download.'}</div>
    <div> {'Click the Downloaded File List button to check the downloaded files'}</div>
  </div>
);

export const requestFailureTooMayRequestMessage = (
  <div>
    <div>{'The server is processing a previous download request.'}</div>
    <div> {'Please retry again after a while.'}</div>
  </div>
);
