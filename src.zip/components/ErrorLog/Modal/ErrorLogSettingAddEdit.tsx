import { ErrorCodeInput, errorCodeInputRangeRule } from '@components/common/atoms/SearchModal/SearchModalItems';
import { css } from '@emotion/react';
import { ErrorLogSettingState } from '@typesdef/errorLog';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Checkbox, Form, Input, InputNumber, Modal, Select } from 'antd';
import React from 'react';
import useErrorLogSettingAddEdit from '../hooks/useErrorLogSettingAddEdit';

export interface ErrorLogSettingAddEditProps {
  data?: ErrorLogSettingState;
  siteId: number;
  userId: number | string;
  itemId?: number;
}

export default React.memo(function ErrorLogSettingAddEdit({
  visible,
  onClose,
  data,
  siteId,
  userId,
  itemId,
}: GlobalModalDefaultProps<ErrorLogSettingAddEditProps>): JSX.Element {
  const {
    form,
    modeText,
    formErrorCodeArr,
    formType,
    formBeforeNow,
    formAfterNow,
    categoryOptions,
    isFetchingOptions,
    isLoadingAddEdit,
    onOk,
  } = useErrorLogSettingAddEdit({ visible, onClose, data, siteId, userId, itemId });

  return (
    <Modal
      title={`${modeText} Error Log Setting`}
      open={visible}
      onOk={onOk}
      okButtonProps={{
        loading: isLoadingAddEdit,
        disabled: isLoadingAddEdit,
      }}
      onCancel={onClose}
      cancelButtonProps={{
        disabled: isLoadingAddEdit,
      }}
      width={800}
      destroyOnClose
    >
      <div css={style}>
        <Form form={form} labelCol={{ span: 7 }} wrapperCol={{ span: 17 }} disabled={isLoadingAddEdit}>
          <Form.Item
            name="error_code_arr"
            label="Error Code"
            className="error-code"
            required
            rules={[errorCodeInputRangeRule(false)]}
            // help={formNameValid.help}
            // validateStatus={formNameValid.status}
            // hasFeedback
          >
            {/* Form Item의 하위에 컴포넌트 호출 시, Form Item의 onChange Function이 Props로 전달된다. 
                onChange과 동일한 이름으로 props를 추가 했으 경우에는 Form Item의 Change가 먼저 실행되고 이후에
                추가한 onChange가 실행된다.

                Antd Doc: https://ant.design/components/form/
                After wrapped by Form.Item with name property, value(or other property defined by valuePropName)
                onChange(or other property defined by trigger) props will be added to form controls,
                the flow of form data will be handled by Form which will cause:

                1. You shouldn't use onChange on each form control to collect data(use onValuesChange of Form), but you can still listen to onChange.
                2. You cannot set value for each form control via value or defaultValue prop, you should set default value with initialValues of Form. 
                   Note that initialValues cannot be updated by setState dynamically, you should use setFieldsValue in that situation.
                3. You shouldn't call setState manually, please use form.setFieldsValue to change value programmatically.
            */}
            <ErrorCodeInput value={formErrorCodeArr} allowAsterisk={false} />
          </Form.Item>
          <Form.Item
            name="type"
            label="Type"
            required
            className="type"
            rules={[
              {
                required: true,
                type: 'string',
                message: 'Please select a type!',
              },
            ]}
          >
            <Select
              options={['FTP', 'VFTP(COMPAT)', 'VFTP(SSS)'].map((item) => ({
                key: item,
                value: item,
                label: item,
              }))}
              onSelect={() => {
                form.setFieldsValue({
                  command: [],
                  command_vftp: '',
                });
              }}
            />
          </Form.Item>
          {formType === 'FTP' && (
            <Form.Item
              name="command"
              label="Category"
              className="category"
              required
              rules={[
                {
                  required: true,
                  type: 'array',
                  message: 'Please select categories!',
                },
              ]}
            >
              <Select
                options={categoryOptions}
                mode="multiple"
                allowClear
                loading={isFetchingOptions}
                disabled={isFetchingOptions}
              />
            </Form.Item>
          )}
          {formType === 'VFTP(COMPAT)' && (
            <Form.Item
              name="command_vftp"
              label="Command"
              required
              className="command-vftp"
              rules={[
                {
                  required: true,
                  type: 'string',
                  message: 'Please input a vftp(compat) command!',
                },
                {
                  type: 'string',
                  pattern: new RegExp(/^get YYYYMMDD_HHMMSS-YYYYMMDD_HHMMSS(\.log|-\w+\.log)$/, 'g'),
                  message: 'get YYYYMMDD_HHMMSS-YYYYMMDD_HHMMSS-Command(Option).log',
                },
              ]}
            >
              <Input placeholder="get YYYYMMDD_HHMMSS-YYYYMMDD_HHMMSS-Command(Option).log" />
            </Form.Item>
          )}
          {formType === 'VFTP(SSS)' && (
            <Form.Item
              name="command_vftp"
              label="Command"
              required
              className="command-vftp"
              rules={[
                {
                  required: true,
                  type: 'string',
                  message: 'Please input a vftp(sss) command!',
                },
                {
                  type: 'string',
                  pattern: new RegExp(/^cd \w+-YYYYMMDD_HHMMSS-YYYYMMDD_HHMMSS($|-\w+$)/, 'g'),
                  message: `cd DataType-YYYYMMDD_HHMMSS-YYYYMMDD_HHMMSS-Command(Option)`,
                },
              ]}
            >
              <Input placeholder="cd DataType-YYYYMMDD_HHMMSS-YYYYMMDD_HHMMSS-Command(Option)" />
            </Form.Item>
          )}
          {formType !== 'FTP' && (
            <Form.Item
              name="logServerCategoryName"
              label="Log Server Category Name"
              required
              className="logServerCategoryName"
              rules={[
                {
                  required: true,
                  type: 'string',
                  message: 'Please input a log server category name!',
                },
              ]}
            >
              <Input placeholder="Input a log server category name." />
            </Form.Item>
          )}
          <Form.Item label="Days Before" className="before" required>
            <Form.Item
              name="before"
              required
              rules={[
                {
                  required: true,
                  type: 'string',
                  validator: (_, value) =>
                    new Promise((resolve, reject) => {
                      if (!value && !formBeforeNow) {
                        return reject('Please input a before!');
                      }

                      return resolve(true);
                    }),
                },
              ]}
            >
              <InputNumber stringMode disabled={formBeforeNow} />
            </Form.Item>
            <Form.Item name="before_now" noStyle valuePropName="checked">
              <Checkbox
                onChange={({ target: { checked } }) => {
                  form.setFieldsValue({
                    before: checked ? undefined : '0',
                  });
                }}
              >
                Now
              </Checkbox>
            </Form.Item>
          </Form.Item>
          <Form.Item label="Days After" className="after" required>
            <Form.Item
              name="after"
              required
              rules={[
                {
                  required: true,
                  type: 'string',
                  validator: (_, value) =>
                    new Promise((resolve, reject) => {
                      if (!value && !formAfterNow) {
                        return reject('Please input a after!');
                      }

                      return resolve(true);
                    }),
                },
              ]}
            >
              <InputNumber stringMode disabled={formAfterNow} />
            </Form.Item>
            <Form.Item name="after_now" noStyle valuePropName="checked">
              <Checkbox
                onChange={({ target: { checked } }) => {
                  form.setFieldsValue({
                    after: checked ? undefined : '0',
                  });
                }}
              >
                Now
              </Checkbox>
            </Form.Item>
          </Form.Item>
        </Form>
      </div>
    </Modal>
  );
});

const style = css`
  display: flex;
  flex-direction: column;

  .type {
    .ant-select {
      width: 9rem;
    }
  }

  .before,
  .after {
    .ant-input-number {
      width: 9rem;
    }
    .ant-form-item-control-input-content {
      display: flex;
    }
    .ant-checkbox-wrapper {
      margin-left: 1rem;
      padding-top: 0.25rem;
    }
    margin-bottom: 0;
  }
`;

// const getCommandRegex = (type: 'VFTP(COMPAT)' | 'VFTP(SSS)'): FormItemProps['rules'] =>
//   ({
//     'VFTP(COMPAT)': [
//       {
//         required: true,
//         type: 'string',
//         message: 'Please input a vftp(compat) command!',
//       },
//       {
//         required: true,
//         type: 'string',
//         pattern: new RegExp(/^get\sYYYYMMDD_HHMMSS-YYYYMMDD_HHMMSS(\.log|-.*.log)$/, 'g'),
//         message: 'get YYYYMMDD_HHMMSS-YYYYMMDD_HHMMSS-Command.log',
//       },
//     ],
//     'VFTP(SSS)': [
//       {
//         required: true,
//         type: 'string',
//         message: 'Please input a vftp(sss) command!',
//       },
//       {
//         required: true,
//         type: 'string',
//         pattern: new RegExp(/^cd\s.*-YYYYMMDD_HHMMSS-YYYYMMDD_HHMMSS($|-.*)/, 'g'),
//         message: `cd DataType-YYYYMMDD_HHMMSS-YYYYMMDD_HHMMSS-Command`,
//       },
//     ],
//   }[type]);
