import { InboxOutlined } from '@ant-design/icons';
import CustomIcon from '@components/common/atoms/CustomIcon';
import { css } from '@emotion/react';
import { usePostErrorLogImport } from '@libs/query/errorlog';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { errorLogReqSetting, errorLogSiteInfo } from '@reducers/slices/errorLog';
import useTypedSelector from '@reducers/useTypedSelector';
import { useQueryClient } from '@tanstack/react-query';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Modal, Space } from 'antd';
import Dragger from 'antd/es/upload/Dragger';
import { AxiosError } from 'axios';
import { Fragment, useState } from 'react';

export default function ErrorLogSettingImport({ visible, onClose }: GlobalModalDefaultProps<{}>): JSX.Element {
  const queryClient = useQueryClient();
  const { siteId } = useTypedSelector(errorLogSiteInfo);
  const [importFile, setImportFile] = useState<File | undefined>(undefined);
  const reqSetting = useTypedSelector(errorLogReqSetting);

  const { mutate: mutateImportFile, isLoading: isImporting } = usePostErrorLogImport({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to import error log setting file!`, error);
    },
    onSuccess: () => {
      openNotification('success', 'Success', 'Succeed to import error log setting file');
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.ERROR_LOG_SETTING_LIST], {
        exact: false,
      });
      onClose();
    },
  });

  const handleOk = () => {
    const formData = new FormData();
    formData.append('file', importFile as File);
    mutateImportFile({ siteId: siteId as number, userId: reqSetting?.value as string | number, formData });
  };

  const handleCancel = () => {
    onClose();
  };

  const draggerProps = {
    name: 'file',
    multiple: false,
    maxCount: 1,
    beforeUpload: (file: File) => {
      setImportFile(file);
      return false;
    },
    onRemove: () => {
      setImportFile(undefined);
    },
  };

  return (
    <Modal
      title="Import Error Log Setting File"
      visible={visible}
      okText="Import"
      onOk={handleOk}
      okButtonProps={{ loading: isImporting, disabled: isImporting || !importFile }}
      onCancel={handleCancel}
      cancelButtonProps={{
        disabled: isImporting,
      }}
      closable={!isImporting}
      maskClosable={!isImporting}
      destroyOnClose // TODO: 다른 방법이 있을까???
    >
      <Fragment>
        <div css={warningStyle}>
          <Space>
            <CustomIcon name="warning" />
            <div>All saved data will be deleted and replaced</div>
          </Space>
          <div>with data from the Import file.</div>
        </div>
        <Dragger {...draggerProps}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">Click or drag file to this area to upload</p>
        </Dragger>
      </Fragment>
    </Modal>
  );
}

const warningStyle = css`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  color: red;
  font-size: 1rem;
  margin-bottom: 1rem;
`;
