import { DownloadOutlined, UnorderedListOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import { ellipsisLineStyle } from '@components/common/atoms/Common/Common';
import { getFilteredText } from '@components/common/atoms/FilterModal/FilterModal';
import FilterModalButton from '@components/common/atoms/FilterModal/FilterModalButton';
import RefreshBtn from '@components/common/atoms/RefreshBtn/RefreshBtn';
import { getSearchedText } from '@components/common/atoms/SearchModal/SearchModal';
import SearchModalButton from '@components/common/atoms/SearchModal/SearchModalButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import TableScrollTitle from '@components/common/atoms/TableScrollTitle';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { enableHoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { ErrorLogState } from '@typesdef/errorLog';
import { Table, Tooltip } from 'antd';
import { useRef } from 'react';
import { errorLogFilterItems, errorLogSearchItems, getErrorLogRank, getErrorLogUnit } from './ErrorLogCommon';
import useErrorLogDownloadTable from './hooks/useErrorLogDownloadTable';

export type ErrorLogDownloadTableProps = {};

export default function ErrorLogDownloadTable({}: ErrorLogDownloadTableProps): JSX.Element {
  const {
    list,
    isFetching,
    onClickReqDownload,
    onClickDownloadList,
    onClickRefresh,
    isMatchedBySettingCode,
    pagination,
    searchParam,
    filterParam,
    hasSearchParam,
    hasFilterParam,
    setSearchParam,
    setFilterParam,
    onChangeTable,
    openSearchModal,
    openFilterModal,
  } = useErrorLogDownloadTable();
  const tableRef = useRef<HTMLDivElement>(null);

  const renderDownload = (value: number, record: ErrorLogState, index: number) => {
    const isMatched = isMatchedBySettingCode(record);

    if (isMatched) {
      return (
        <DownloadOutlined key={value} css={enableHoverActiveStyle(true)} onClick={() => onClickReqDownload(record)} />
      );
    } else {
      return (
        <Tooltip title="Not imported error code value" placement="right" color="gray">
          <div key={value} css={enableHoverActiveStyle(false)}>
            -
          </div>
        </Tooltip>
      );
    }
  };

  const titleRender = () => (
    <TableHeader
      title={
        <TableHeaderTitle
          total={pagination.total}
          isSearched={hasSearchParam}
          searchedText={getSearchedText(errorLogSearchItems, searchParam)}
          onResetSearch={() => setSearchParam({})}
          isFiltered={hasFilterParam}
          FilteredText={getFilteredText(errorLogFilterItems, filterParam)}
          onResetFilter={() => setFilterParam({})}
          color="green"
        />
      }
    >
      <SearchModalButton hasParam={hasSearchParam} onClick={() => openSearchModal()} />
      <FilterModalButton hasParam={hasFilterParam} onClick={() => openFilterModal()} />
      <AntdButton icon={<UnorderedListOutlined />} type="primary" onClick={onClickDownloadList}>
        Status
      </AntdButton>
      <RefreshBtn type="primary" onClick={onClickRefresh} loading={isFetching} />
    </TableHeader>
  );

  const renderRank = (value: string, record: ErrorLogState, index: number) => {
    // return <div>{getErrorLogRank(value)}</div>;
    return <div>{value === 'BD' ? 'B/D' : value}</div>;
  };

  const renderUnit = (value: string, record: ErrorLogState, index: number) => {
    // return <div>{getErrorLogUnit(value)}</div>;
    return <div>{value}</div>;
  };

  return (
    <div css={style}>
      <Table<ErrorLogState>
        ref={tableRef}
        rowKey={'id'}
        dataSource={list?.content}
        bordered
        title={titleRender}
        size="small"
        pagination={{
          position: ['bottomCenter'],
          showSizeChanger: true,
          current: pagination.current,
          pageSize: pagination.pageSize,
          total: pagination.total,
        }}
        loading={isFetching}
        scroll={{ x: 'max-content' }}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
        onChange={onChangeTable}
      >
        <Table.Column<ErrorLogState>
          {...errorLogColumnProps.error_code}
          title={<TableScrollTitle title="Error Code" ref={tableRef} direction="left" />}
        />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.unit} render={renderUnit} />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.rank} render={renderRank} />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.equipment_name} />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.error_message} />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.occurrence_count} />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.occurred_date} />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.ppid} />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.device} />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.process} />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.glass_id} />
        <Table.Column<ErrorLogState> {...errorLogColumnProps.lot_id} />
        {/* <Table.Column<ErrorLogState> {...errorLogColumnProps.chuck} /> */}
        <Table.Column<ErrorLogState>
          {...errorLogColumnProps.download}
          title={<TableScrollTitle title="Request Download" ref={tableRef} direction="right" />}
          render={renderDownload}
        />
      </Table>
    </div>
  );
}

const style = css`
  width: 84rem;
`;

type ErrorLogColumnName =
  | 'error_code'
  | 'unit'
  | 'rank'
  | 'equipment_name'
  | 'error_message'
  | 'occurrence_count'
  | 'occurred_date'
  | 'ppid'
  | 'device'
  | 'process'
  | 'glass_id'
  | 'lot_id'
  | 'chuck'
  | 'download';

const errorLogColumnProps: TableColumnPropsType<ErrorLogState, ErrorLogColumnName> = {
  error_code: {
    key: 'error_code',
    dataIndex: 'error_code',
    align: 'center',
    sorter: true,
    // fixed가 설정된 Column에는 shouldCellUpdate를 설정하면 않된다.
    // shouldCellUpdate: (cur, prev) => cur.error_code !== prev.error_code,
    fixed: 'left',
    width: 140,
  },
  unit: {
    title: <TableColumnTitle>Unit</TableColumnTitle>,
    key: 'unit',
    dataIndex: 'unit',
    align: 'center',
    sorter: true,
    // shouldCellUpdate: (cur, prev) => cur.error_code !== prev.error_code,
    width: 100,
  },
  rank: {
    title: <TableColumnTitle>Rank</TableColumnTitle>,
    key: 'rank',
    dataIndex: 'rank',
    align: 'center',
    sorter: true,
    // shouldCellUpdate: (cur, prev) => cur.error_code !== prev.error_code,
    width: 100,
  },
  equipment_name: {
    key: 'equipment_name',
    title: <TableColumnTitle>Equipment Name</TableColumnTitle>,
    dataIndex: 'equipment_name',
    align: 'center',
    sorter: true,
    // shouldCellUpdate: (cur, prev) => cur.error_code !== prev.error_code,
    width: 200,
  },
  error_message: {
    key: 'error_message',
    title: <TableColumnTitle>Error Message</TableColumnTitle>,
    dataIndex: 'error_message',
    align: 'center',
    sorter: true,
    //shouldCellUpdate: (cur, prev) => cur.error_message !== prev.error_message,
    render: function renderErrorMsg(value: string) {
      return (
        <div title={value} css={ellipsisLineStyle({ line: 2 })}>
          {value}
        </div>
      );
    },
    width: 400,
  },
  occurrence_count: {
    key: 'occurrence_count',
    title: <TableColumnTitle>Count</TableColumnTitle>,
    dataIndex: 'occurrence_count',
    align: 'center',
    sorter: true,
    //shouldCellUpdate: (cur, prev) => cur.occurrence_count !== prev.occurrence_count,
    width: 120,
  },
  occurred_date: {
    key: 'occurred_date',
    title: <TableColumnTitle>Date</TableColumnTitle>,
    dataIndex: 'occurred_date',
    align: 'center',
    sorter: true,
    //shouldCellUpdate: (cur, prev) => cur.occurred_date !== prev.occurred_date,
    width: 180,
  },
  ppid: {
    key: 'ppid',
    title: <TableColumnTitle>PPID</TableColumnTitle>,
    dataIndex: 'ppid',
    align: 'center',
    sorter: true,
    //shouldCellUpdate: (cur, prev) => cur.ppid !== prev.ppid,
    width: 100,
  },
  device: {
    key: 'device',
    title: <TableColumnTitle>Device</TableColumnTitle>,
    dataIndex: 'device',
    align: 'center',
    sorter: true,
    //shouldCellUpdate: (cur, prev) => cur.device !== prev.device,
    width: 130,
  },
  process: {
    key: 'process',
    title: <TableColumnTitle>Process</TableColumnTitle>,
    dataIndex: 'process',
    align: 'center',
    sorter: true,
    //shouldCellUpdate: (cur, prev) => cur.process !== prev.process,
    width: 130,
  },
  glass_id: {
    key: 'glass_id',
    title: <TableColumnTitle>Glass Id</TableColumnTitle>,
    dataIndex: 'glass_id',
    align: 'center',
    sorter: true,
    //shouldCellUpdate: (cur, prev) => cur.glass_id !== prev.glass_id,
    width: 200,
  },
  lot_id: {
    key: 'lot_id',
    title: <TableColumnTitle>Lot Id</TableColumnTitle>,
    dataIndex: 'lot_id',
    align: 'center',
    sorter: true,
    //shouldCellUpdate: (cur, prev) => cur.lot_id !== prev.lot_id,
    width: 160,
  },
  chuck: {
    key: 'chuck',
    title: <TableColumnTitle>Chuck</TableColumnTitle>,
    dataIndex: 'chuck',
    align: 'center',
    sorter: true,
    //shouldCellUpdate: (cur, prev) => cur.chuck !== prev.chuck,
    width: 150,
  },
  download: {
    key: 'download',
    dataIndex: 'index',
    align: 'center',
    //shouldCellUpdate: (cur, prev) => cur.id !== prev.id,
    fixed: 'right',
    width: 150,
  },
};
