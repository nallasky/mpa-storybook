import { css } from '@emotion/react';

export const errorLogStyle = css`
  .content__table {
    /* padding-left: 1rem;
    padding-top: 1rem; */
    margin-left: 1rem;
    margin-top: 1rem;
  }
`;

export const errorLogCmdModalStyle = css`
  max-height: 20rem;
  width: 24.875rem;
  overflow-y: auto;

  .body__content {
    margin-top: 0.5rem;
    margin-left: 1rem;
  }
`;
