import { initErrorLogWithoutSiteReducer } from '@reducers/slices/errorLog';
import { Badge } from 'antd';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import ErrorLogStatusTable from './ErrorLogStatusTable';
import useErrorLogCheckSite from './hooks/useErrorLogCheckSite';
import { errorLogStyle } from './styles/errorLogStyle';

export type ErrorLogStatusProps = {};

export default function ErrorLogStatus({}: ErrorLogStatusProps): JSX.Element {
  const dispatch = useDispatch();
  const { isExistSite } = useErrorLogCheckSite();

  useEffect(() => {
    return () => {
      dispatch(initErrorLogWithoutSiteReducer());
    };
  }, [dispatch]);

  return (
    <div css={errorLogStyle}>
      <div className="content__title">
        <Badge color="blue" />
        <span>Error Log</span>
      </div>
      {isExistSite && (
        <div className="content__table">
          <ErrorLogStatusTable />
        </div>
      )}
    </div>
  );
}
