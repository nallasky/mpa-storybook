import { FilterModalItem, SearchModalItem } from '@typesdef/search';

export const errorLogSearchItems: SearchModalItem[] = [
  {
    type: 'code',
    name: 'error_code',
    label: 'Error Code',
  },
  {
    type: 'text',
    name: 'error_message',
    label: 'Error Message',
  },
  {
    type: 'text',
    name: 'equipment_name',
    label: 'Equipment Name',
  },
  {
    type: 'date_range',
    name: 'occurred_date',
    label: 'Occurred Date',
  },
];

export const errorLogStatusSearchItems: SearchModalItem[] = [
  {
    type: 'code',
    name: 'error_code',
    label: 'Error Code',
  },
  {
    type: 'text',
    name: 'equipment_name',
    label: 'Equipment Name',
  },
  {
    type: 'date_range',
    name: 'occurred_date',
    label: 'Occurred Date',
  },
];

export const errorLogSettingSearchItems: SearchModalItem[] = [
  {
    type: 'code',
    name: 'error_code',
    label: 'Error Code',
  },
];

export const errorLogFilterItems: FilterModalItem[] = [
  {
    type: 'group_checkbox',
    name: 'rank',
    label: 'Error Rank',
    options: [
      {
        key: 'A',
        value: 'A',
        label: 'A',
      },
      {
        key: 'BD',
        value: 'BD',
        label: 'B/D',
      },
      {
        key: 'C',
        value: 'C',
        label: 'C',
      },
    ],
  },
  {
    type: 'group_checkbox',
    name: 'unit',
    label: 'Unit',
    options: [
      {
        key: 'CONSOLE',
        value: 'CONSOLE',
        label: 'CONSOLE',
      },
      {
        key: 'MAIN',
        value: 'MAIN',
        label: 'MAIN',
      },
      {
        key: 'SCAN',
        value: 'SCAN',
        label: 'SCAN',
      },
      {
        key: 'PERL',
        value: 'PERL',
        label: 'PERL',
      },
    ],
  },
];

export const getErrorLogRank = (value: string) =>
  ({
    0: 'A',
    1: 'A',
    2: 'B/D',
    3: 'B/D',
    4: 'C',
    5: 'C',
  }[value] ?? '');

export const getErrorLogUnit = (value: string) =>
  ({
    0: 'CONSOLE',
    1: 'MAIN',
    A: 'MAIN',
    2: 'SCAN',
    B: 'SCAN',
    3: 'PERL',
    C: 'PERL',
  }[value] ?? '');
