import { DeleteOutlined, EditOutlined, ExportOutlined, ImportOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import { openAntdModal } from '@components/common/atoms/AntdModal';
import { ellipsisLineStyle } from '@components/common/atoms/Common/Common';
import RefreshBtn from '@components/common/atoms/RefreshBtn';
import { getSearchedText } from '@components/common/atoms/SearchModal/SearchModal';
import SearchModalButton from '@components/common/atoms/SearchModal/SearchModalButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { ADMINISTRATOR, ERROR_LOG_ALL_SETTING } from '@constants/constants';
import { MODAL_NAME, NAV_BAR_HIGHT } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { ErrorLogSettingState, ErrorLogTagType } from '@typesdef/errorLog';
import { SearchModalItem } from '@typesdef/search';
import { Badge, Button, Popconfirm, Space, Table } from 'antd';
import { errorLogSettingSearchItems } from './ErrorLogCommon';
import ErrorLogSettingSelect from './ErrorLogSettingSelect';
import useErrorLogSettingTable from './hooks/useErrorLogSettingTable';
import ErrorLogSettingImport from './Modal/ErrorLogSettingImport';
import { errorLogCmdModalStyle } from './styles/errorLogStyle';

export type ErrorLogSettingTableProps = {
  type: ErrorLogTagType;
};

export default function ErrorLogSettingTable({ type }: ErrorLogSettingTableProps) {
  const {
    data,
    isFetching,
    refetch,
    isAdmin,
    reqSetting,
    onExport,
    loginUser,
    pagination,
    searchParam,
    hasSearchParam,
    setSearchParam,
    onChangeTable,
    onAdd,
    onEdit,
    onDelete,
    isDisableModify,
    openSearchModal,
  } = useErrorLogSettingTable({
    type,
  });
  const { openModal } = useModals();

  const colWidth =
    type === 'default' ? columWidth.withAccount : isAdmin ? columWidth.withAccount : columWidth.withoutAccount;

  const titleRender = () => (
    <TableHeader
      title={
        <TableHeaderTitle
          total={pagination.total}
          isSearched={hasSearchParam}
          searchedText={getSearchedText(errorLogSettingSearchItems, searchParam)}
          onResetSearch={() => setSearchParam({})}
          color="green"
        />
      }
    >
      <SearchModalButton hasParam={hasSearchParam} onClick={() => openSearchModal()} />
      {type === 'user' && isAdmin && <ErrorLogSettingSelect />}
      <AntdButton
        icon={<PlusOutlined />}
        type="primary"
        onClick={() => onAdd()}
        disabled={
          type === 'default' ? loginUser.username !== ADMINISTRATOR : reqSetting?.value === ERROR_LOG_ALL_SETTING.value
        }
      >
        Add
      </AntdButton>
      <AntdButton
        icon={<ImportOutlined />}
        type="primary"
        onClick={() => {
          openModal(MODAL_NAME.ERROR_LOG.IMPORT, ErrorLogSettingImport);
        }}
        disabled={
          type === 'default' ? loginUser.username !== ADMINISTRATOR : reqSetting?.value === ERROR_LOG_ALL_SETTING.value
        }
      >
        Import
      </AntdButton>
      <AntdButton
        icon={<ExportOutlined />}
        type="primary"
        onClick={onExport}
        disabled={reqSetting?.value === ERROR_LOG_ALL_SETTING.value}
      >
        Export
      </AntdButton>
      <RefreshBtn type="primary" onClick={() => refetch()} loading={isFetching} />
    </TableHeader>
  );

  const modalCategory = (value: string[]) => {
    openAntdModal('info', {
      title: 'Categories',
      width: '31.25rem',
      maskClosable: true,
      okText: 'Close',
      content: (
        <div css={errorLogCmdModalStyle}>
          <div className="body__title">
            <Space size={2}>
              <Badge color="blue" />
              {`${value.length} Categories`}
            </Space>
          </div>
          <div className="body__content">
            {value.map((item, idx) => (
              <div key={idx}>
                <Space size={2}>
                  <Badge color="green" />
                  <div>{item.trim()}</div>
                </Space>
              </div>
            ))}
          </div>
        </div>
      ),
    });
  };

  const renderLogSeverCategoryName = (value: string, record: ErrorLogSettingState) => {
    return (
      <div title={value} css={[ellipsisLineStyle({ line: 2 })]}>
        {value}
      </div>
    );
  };

  const renderCommand = (value: string[], record: ErrorLogSettingState) => {
    const isModal = record.type === 'FTP';
    const text = Array.isArray(value) ? value.join(', ') : '';

    return (
      <div
        title={text}
        css={[ellipsisLineStyle({ line: 2 }), isModal && hoverActiveStyle]}
        onClick={() => isModal && modalCategory(value)}
      >
        {text}
      </div>
    );
  };

  const renderEdit = (value: number, record: ErrorLogSettingState, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to edit this error code?"
        onConfirm={() => onEdit(record)}
        okText="Edit"
        cancelText="Cancel"
        disabled={isDisableModify}
      >
        <Button size="small" icon={<EditOutlined />} type="text" disabled={isDisableModify} css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ErrorLogSettingState, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to delete this error code?"
        onConfirm={() => onDelete(record)}
        okText="Delete"
        cancelText="Cancel"
        disabled={isDisableModify}
      >
        <Button size="small" icon={<DeleteOutlined />} type="text" disabled={isDisableModify} css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div>
      <Table<ErrorLogSettingState>
        rowKey={'id'}
        title={titleRender}
        size="small"
        bordered
        dataSource={data?.content}
        loading={isFetching}
        pagination={{
          position: ['bottomCenter'],
          showSizeChanger: true,
          current: pagination.current,
          pageSize: pagination.pageSize,
          total: pagination.total,
        }}
        tableLayout="fixed"
        onChange={onChangeTable}
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        {type === 'user' && isAdmin && (
          <Table.Column<ErrorLogSettingState> {...columnProps.userName} width={colWidth.userName} />
        )}
        <Table.Column<ErrorLogSettingState> {...columnProps.error_code} width={colWidth.error_code} />
        <Table.Column<ErrorLogSettingState> {...columnProps.type} width={colWidth.type} />
        <Table.Column<ErrorLogSettingState> {...columnProps.command} width={colWidth.command} render={renderCommand} />
        <Table.Column<ErrorLogSettingState>
          {...columnProps.logServerCategoryName}
          width={colWidth.logServerCategoryName}
          render={renderLogSeverCategoryName}
        />
        <Table.Column<ErrorLogSettingState> {...columnProps.before} width={colWidth.before} />
        <Table.Column<ErrorLogSettingState> {...columnProps.after} width={colWidth.after} />
        <Table.Column<ErrorLogSettingState> {...columnProps.edit} width={colWidth.edit} render={renderEdit} />
        <Table.Column<ErrorLogSettingState> {...columnProps.delete} width={colWidth.delete} render={renderDelete} />
      </Table>
    </div>
  );
}

const searchItems: SearchModalItem[] = [
  {
    type: 'code',
    name: 'error_code',
    label: 'Error Code',
  },
];

type columnName =
  | 'userName'
  | 'error_code'
  | 'type'
  | 'logServerCategoryName'
  | 'command'
  | 'before'
  | 'after'
  | 'edit'
  | 'delete';

const columnProps: TableColumnPropsType<ErrorLogSettingState, columnName> = {
  userName: {
    key: 'userName',
    title: <TableColumnTitle>Account</TableColumnTitle>,
    dataIndex: 'userName',
    align: 'center',
    sorter: true,
  },
  error_code: {
    key: 'error_code',
    title: <TableColumnTitle>Error Code</TableColumnTitle>,
    dataIndex: 'error_code',
    align: 'center',
    sorter: true,
  },
  type: {
    key: 'type',
    title: <TableColumnTitle>Type</TableColumnTitle>,
    dataIndex: 'type',
    align: 'center',
    sorter: true,
  },
  command: {
    key: 'command',
    title: <TableColumnTitle>Category / Command</TableColumnTitle>,
    dataIndex: 'command',
    align: 'center',
    sorter: true,
  },
  logServerCategoryName: {
    key: 'logServerCategoryName',
    title: (
      <TableColumnTitle>
        <div>Log Sever</div>
        <div>Category Name</div>{' '}
      </TableColumnTitle>
    ),
    dataIndex: 'logServerCategoryName',
    align: 'center',
    sorter: true,
  },
  before: {
    key: 'before',
    title: <TableColumnTitle>Days Before</TableColumnTitle>,
    dataIndex: 'before',
    align: 'center',
    sorter: true,
  },
  after: {
    key: 'after',
    title: <TableColumnTitle>Days After</TableColumnTitle>,
    dataIndex: 'after',
    align: 'center',
    sorter: true,
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    dataIndex: 'id',
    align: 'center',
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    dataIndex: 'id',
    align: 'center',
  },
};

const columWidth = {
  // withAccount: {
  //   userName: getPixelPercent(1344, 200),
  //   error_code: getPixelPercent(1344, 220),
  //   type: getPixelPercent(1344, 150),
  //   command: getPixelPercent(1344, 594),
  //   before: getPixelPercent(1344, 90),
  //   after: getPixelPercent(1344, 90),
  //   edit: getPixelPercent(1344, 0),
  //   delete: getPixelPercent(1344, 0),
  // },
  // withoutAccount: {
  //   userName: getPixelPercent(1344, 0),
  //   error_code: getPixelPercent(1344, 220),
  //   type: getPixelPercent(1344, 150),
  //   command: getPixelPercent(1344, 794),
  //   before: getPixelPercent(1344, 90),
  //   after: getPixelPercent(1344, 90),
  //   edit: getPixelPercent(1344, 0),
  //   delete: getPixelPercent(1344, 0),
  // },
  withAccount: {
    userName: getPixelPercent(1344, 150),
    error_code: getPixelPercent(1344, 180),
    type: getPixelPercent(1344, 140),
    command: getPixelPercent(1344, 400),
    logServerCategoryName: getPixelPercent(1344, 154),
    before: getPixelPercent(1344, 80),
    after: getPixelPercent(1344, 80),
    edit: getPixelPercent(1344, 80),
    delete: getPixelPercent(1344, 80),
  },
  withoutAccount: {
    userName: getPixelPercent(1344, 0),
    error_code: getPixelPercent(1344, 220),
    type: getPixelPercent(1344, 150),
    command: getPixelPercent(1344, 500),
    logServerCategoryName: getPixelPercent(1344, 154),
    before: getPixelPercent(1344, 80),
    after: getPixelPercent(1344, 80),
    edit: getPixelPercent(1344, 80),
    delete: getPixelPercent(1344, 80),
  },
};
