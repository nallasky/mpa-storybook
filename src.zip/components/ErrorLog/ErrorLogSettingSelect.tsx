import { ERROR_LOG_ALL_SETTING } from '@constants/constants';
import { css } from '@emotion/react';
import { useGetAccountUserSummaryList } from '@libs/query/account';
import { errorLogReqSetting, setErrorLogReqSettingReducer } from '@reducers/slices/errorLog';
import useTypedSelector from '@reducers/useTypedSelector';
import { Select } from 'antd';
import { LabeledValue } from 'antd/es/select';
import { useCallback } from 'react';
import { useDispatch } from 'react-redux';

export type ErrorLogSettingSelectProps = {};

export default function ErrorLogSettingSelect({}: ErrorLogSettingSelectProps) {
  const reqSetting = useTypedSelector(errorLogReqSetting);
  const dispatch = useDispatch();

  const { data: users, isFetching: isFetchingUsers, refetch: refetchUsers } = useGetAccountUserSummaryList();

  const onSelectSetting = useCallback(
    (value: LabeledValue) => {
      dispatch(setErrorLogReqSettingReducer(value));
    },
    [dispatch],
  );

  const onClearSetting = useCallback(() => {
    dispatch(setErrorLogReqSettingReducer(null));
  }, [dispatch]);

  return (
    <Select<LabeledValue>
      showSearch
      labelInValue
      value={reqSetting}
      placeholder="Select a setting"
      onSelect={onSelectSetting}
      loading={isFetchingUsers}
      optionFilterProp="children"
      filterOption={(input, option) =>
        Boolean((option?.children as unknown as string).toLowerCase().indexOf(input.toLowerCase()) >= 0)
      }
      onClear={onClearSetting}
      css={style}
    >
      <Select.Option
        key={ERROR_LOG_ALL_SETTING.key}
        value={ERROR_LOG_ALL_SETTING.value}
        label={ERROR_LOG_ALL_SETTING.label}
      >
        {ERROR_LOG_ALL_SETTING.label}
      </Select.Option>
      {users?.map((item) => (
        <Select.Option key={item.id} value={item.id} label={item.username}>
          {item.username}
        </Select.Option>
      ))}
    </Select>
  );
}

const style = css`
  width: 10rem;
`;
