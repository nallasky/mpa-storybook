import { ReloadOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { Badge, Select } from 'antd';
import { LabeledValue } from 'antd/es/select';
import React from 'react';
import RefreshBtn from '../common/atoms/RefreshBtn';
import useErrorLogUserFabName from './hooks/useErrorLogUserFabName';

export type ErrorLogUserFabNameProps = {};

export default React.memo(function ErrorLogUserFabName({}: ErrorLogUserFabNameProps): JSX.Element {
  const { siteList, isFetchingSiteList, refreshSiteList, labeledSiteInfo, onChangeSiteInfo, onClearSiteInfo } =
    useErrorLogUserFabName();

  return (
    <div css={style}>
      <div className="site__title">
        <Badge color="blue" />
        <span>User-Fab Name</span>
      </div>
      <div className="site__content">
        <div className="site__select">
          <Select<LabeledValue>
            showSearch
            labelInValue
            css={selectStyle}
            value={labeledSiteInfo.value ? labeledSiteInfo : undefined}
            placeholder="Select a user-fab"
            onSelect={onChangeSiteInfo}
            loading={isFetchingSiteList}
            optionFilterProp="children"
            //filterOption={(input, option) => option?.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
            filterOption={(input, option) =>
              Boolean((option?.children as unknown as string).toLowerCase().indexOf(input.toLowerCase()) >= 0)
            }
            allowClear
            onClear={onClearSiteInfo}
          >
            {siteList?.map((item) => (
              <Select.Option key={item.siteId} value={item.siteId} label={item.crasCompanyFabName}>
                {item.crasCompanyFabName}
              </Select.Option>
            ))}
          </Select>
          <RefreshBtn
            type="primary"
            icon={<ReloadOutlined />}
            css={btnStyle}
            onClick={refreshSiteList}
            loading={isFetchingSiteList}
            disabled={isFetchingSiteList}
          />
        </div>
      </div>
    </div>
  );
});

const style = css`
  display: flex;
  flex-direction: column;
  width: 100%;
  .site__content {
    display: flex;
    align-items: center;
    margin-top: 1rem;

    justify-content: space-between;
    .site__select {
      padding-left: 1rem;
      display: flex;
      flex-direction: row;
    }
  }
`;

const selectStyle = css`
  width: 30rem;
  text-align: center;
  font-size: inherit;
`;

const btnStyle = css`
  border-radius: 0.625rem;
  margin-left: 0.5rem;
`;
