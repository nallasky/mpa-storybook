import { initErrorLogWithoutSiteReducer } from '@reducers/slices/errorLog';
import { Badge } from 'antd';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import ErrorLogDownloadTable from './ErrorLogDownloadTable';
import useErrorLogCheckSite from './hooks/useErrorLogCheckSite';
import { errorLogStyle } from './styles/errorLogStyle';

export type ErrorLogDownloadProps = {};

export default function ErrorLogDownload({}: ErrorLogDownloadProps): JSX.Element {
  const dispatch = useDispatch();
  const { isExistSite } = useErrorLogCheckSite();

  useEffect(() => {
    return () => {
      dispatch(initErrorLogWithoutSiteReducer());
    };
  }, []);

  return (
    <div css={errorLogStyle}>
      <div className="content__title">
        <Badge color="blue" />
        <span>Error Log Download</span>
      </div>
      {isExistSite && (
        <div className="content__table">
          <ErrorLogDownloadTable />
        </div>
      )}
    </div>
  );
}
