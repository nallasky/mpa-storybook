export { default } from './DefineParam';
