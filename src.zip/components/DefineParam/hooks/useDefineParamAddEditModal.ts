import { queryClient } from '@libs/query/configure';
import { DEFINE_PARAM_REQUEST_MAP, usePostDefineParam, usePutDefineParam } from '@libs/query/defineParam';
import { openNotification } from '@libs/util/notification';
import { MutateDefineParamData } from '@typesdef/defineParam';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { useForm } from 'antd/es/form/Form';
import { useEffect } from 'react';
import { DefineParamAddEditModalProps } from '../Modal/DefineParamAddEditModal';
import { DEFINE_PARAM_VARIABLE } from './useDefineParam';

export default function useDefineParamAddEditModal({
  type,
  id,
  data,
  mode,
  visible,
  onClose,
}: GlobalModalDefaultProps<DefineParamAddEditModalProps>) {
  const [form] = useForm<MutateDefineParamData['data']>();
  const mutate = mode === 'add' ? usePostDefineParam : usePutDefineParam;
  const {
    text: { pascal: title, small: name },
  } = DEFINE_PARAM_VARIABLE[type];
  const { getList } = DEFINE_PARAM_REQUEST_MAP[type];

  const { mutateAsync: mutateAsync, isLoading } = mutate(type, {
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to ${mode} ${name} param.`);
      queryClient.invalidateQueries([getList.key], { exact: true });
      onClose();
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to ${mode} ${name} param!`, error);
    },
  });

  const onFinish = async (data: MutateDefineParamData['data']) => {
    try {
      if (mode === 'edit' && !id) {
        throw new Error('id is not defined for edit mode!');
      }
      if (!data) {
        throw new Error('data is not defined!');
      }
      await mutateAsync({
        id: id ?? 0,
        data: {
          ...data,
          setcode: data.setcode.toUpperCase(),
        },
      });
    } catch (e) {
      console.error(e);
    }
  };

  const onCloseModal = () => {
    queryClient.invalidateQueries([getList.key], { exact: true });
    onClose();
  };

  useEffect(() => {
    form.resetFields();
    if (visible && data && mode === 'edit') {
      form.setFieldsValue(data);
    }
  }, [visible, form, data, mode]);

  return {
    form,
    isLoading,
    onCloseModal,
    onFinish,
    title,
  };
}
