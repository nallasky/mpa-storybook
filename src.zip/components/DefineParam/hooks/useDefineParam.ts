import { openAntdModal } from '@components/common/atoms/AntdModal';
import FileImportModal from '@components/common/atoms/FileImportModal';
import { FileImportModalProps } from '@components/common/atoms/FileImportModal/FileImportModal';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import {
  DEFINE_PARAM_REQUEST_MAP,
  useDeleteDefineParam,
  useGetDefineParamExport,
  useGetDefineParamList,
} from '@libs/query/defineParam';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { DefineParamData } from '@typesdef/defineParam';

import { AxiosError } from 'axios';
import saveAs from 'file-saver';
import { DefineParamProps } from '../DefineParam';
import DefineParamAddEditModal, { DefineParamAddEditModalProps } from '../Modal/DefineParamAddEditModal';

export const DEFINE_PARAM_VARIABLE = {
  cylinder: {
    text: {
      pascal: 'Cylinder',
      small: 'cylinder',
    },
    modalKey: {
      addEdit: MODAL_NAME.DEFINE.CYLINDER.ADD_EDIT,
      import: MODAL_NAME.DEFINE.CYLINDER.IMPORT,
    },
  },
  machine: {
    text: {
      pascal: 'Machine Data',
      small: 'machine data',
    },
    modalKey: {
      addEdit: MODAL_NAME.DEFINE.MACHINE.ADD_EDIT,
      import: MODAL_NAME.DEFINE.MACHINE.IMPORT,
    },
  },
};

export default function useDefineParam({ type }: DefineParamProps) {
  const queryClient = useQueryClient();
  const { getList, importList } = DEFINE_PARAM_REQUEST_MAP[type];
  const {
    text: { pascal: title, small: name },
    modalKey: { addEdit: addEditKey, import: importKey },
  } = DEFINE_PARAM_VARIABLE[type];

  const { openModal } = useModals();

  const { data: defineList, isFetching: isFetchingDefineList } = useGetDefineParamList(type, {
    onError: (error) => {
      openNotification('error', 'Error', `Failed to get ${name} param list!`, error as AxiosError);
    },
  });

  const { mutateAsync: mutateAsyncDelete } = useDeleteDefineParam(type, {
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to delete ${name} param.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete ${name} param!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([getList.key], { exact: true });
    },
  });

  const { mutateAsync: mutateAsyncExport } = useGetDefineParamExport(type, {
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to export ${name} param.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to export ${name} param!`, error);
    },
  });

  const openAddModal = () => {
    openModal<DefineParamAddEditModalProps>(addEditKey, DefineParamAddEditModal, {
      type,
      mode: 'add',
    });
  };

  const openEditModal = (value: DefineParamData) => {
    const { id, ...data } = value;
    openModal<DefineParamAddEditModalProps>(addEditKey, DefineParamAddEditModal, {
      type,
      id,
      data,
      mode: 'edit',
    });
  };

  const onDelete = async ({ id }: DefineParamData) => {
    try {
      await mutateAsyncDelete(id);
    } catch (e) {
      console.error(e);
    }
  };

  const onExport = () => {
    const title = type === 'cylinder' ? 'Cylinder Param Define' : 'Machine Param Define';
    const typeName = type === 'cylinder' ? 'cylinder param define' : 'machine param define';

    openAntdModal('confirm', {
      title: `Export ${title}`,
      content: `Are you sure to export ${typeName}?`,
      okText: 'Export',
      onOk: async () => {
        try {
          const { data, fileName } = await mutateAsyncExport();
          saveAs(data, fileName);
        } catch (e) {
          console.error(e);
        }
      },
    });
  };

  const openImportModal = () => {
    openModal<FileImportModalProps<{ id: number }>>(importKey, FileImportModal, {
      title: `Import ${title} Param File`,
      url: importList.url,
      uploadText: `Please import the excel file for ${name} param.`,
      afterError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to import ${name} param file!`, error);
      },
      afterSuccess: (data) => {
        openNotification('success', 'Success', `Succeed to import ${name} param file.`);
      },
      afterSettled: () => {
        queryClient.invalidateQueries([getList.key], { exact: true });
      },
      mutationKey: [importKey],
    });
  };

  return {
    defineList,
    isFetchingDefineList,
    openAddModal,
    openEditModal,
    onDelete,
    onExport,
    openImportModal,
    name,
  };
}
