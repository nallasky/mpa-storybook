import { DefineParamType, MutateDefineParamData } from '@typesdef/defineParam';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, FormItemProps, Input, Modal } from 'antd';
import useDefineParamAddEditModal from '../hooks/useDefineParamAddEditModal';

export interface DefineParamAddEditModalProps {
  type: DefineParamType;
  id?: number;
  data?: MutateDefineParamData['data'];
  mode: 'add' | 'edit';
}

export default function DefineParamAddEditModal({
  type,
  onClose,
  visible,
  id,
  mode,
  data,
}: GlobalModalDefaultProps<DefineParamAddEditModalProps>): JSX.Element {
  const { form, isLoading, onCloseModal, onFinish, title } = useDefineParamAddEditModal({
    type,
    id,
    mode,
    data,
    visible,
    onClose,
  });
  const modeText = mode === 'add' ? 'Add' : 'Edit';

  return (
    <Modal
      title={`${modeText} ${title} Param`}
      open={visible}
      okText={modeText}
      onOk={form.submit}
      okButtonProps={{ loading: isLoading, disabled: isLoading }}
      onCancel={onCloseModal}
      cancelButtonProps={{
        disabled: isLoading,
      }}
      closable={!isLoading}
      maskClosable={!isLoading}
    >
      <Form<MutateDefineParamData['data']> form={form} onFinish={onFinish} layout="vertical" disabled={isLoading}>
        <Form.Item label="Setcode" name="setcode" required rules={ruleMap.setcode}>
          <Input placeholder="Input a Setcode." maxLength={5} />
        </Form.Item>
        <Form.Item label="Name" name="name" required rules={ruleMap.name}>
          <Input placeholder="Input a Name." />
        </Form.Item>
      </Form>
    </Modal>
  );
}

const ruleMap: Record<keyof MutateDefineParamData['data'], NonNullable<FormItemProps['rules']>> = {
  setcode: [
    {
      required: true,
      type: 'string',
      message: 'Please input a Setcode(5-digit hexadecimal)!',
    },
    {
      message: `Please fill in all 5-digit hexadecimal!`,
      type: 'number',
      validator: (rule, value) => {
        if (!value) return Promise.resolve(true);
        return new Promise((resolve, reject) => {
          if (value && value.length < 5) return reject(false);
          const regex = new RegExp('^[a-fA-F0-9]{0,7}$');
          return regex.test(value) ? resolve(true) : reject(false);
        });
      },
    },
  ],
  name: [
    {
      required: true,
      type: 'string',
      message: 'Please input a Name!',
    },
  ],
};
