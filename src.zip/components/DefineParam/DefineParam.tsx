import { DeleteOutlined, EditOutlined, ExportOutlined, ImportOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import type { TableColumnPropsType } from '@typesdef/common';
import { DefineParamData, DefineParamType } from '@typesdef/defineParam';
import { Popconfirm, Table } from 'antd';
import { Fragment } from 'react';
import useDefineParam from './hooks/useDefineParam';

export interface DefineParamProps {
  type: DefineParamType;
}

export default function DefineParam({ type }: DefineParamProps) {
  const { defineList, isFetchingDefineList, openAddModal, openEditModal, onDelete, onExport, openImportModal, name } =
    useDefineParam({ type });

  const renderTitle = () => (
    <TableHeader title={<TableHeaderTitle total={defineList?.length ?? 0} />}>
      <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddModal}>
        Add
      </AntdButton>
      <AntdButton icon={<ImportOutlined />} type="primary" onClick={() => openImportModal()}>
        Import
      </AntdButton>
      <AntdButton icon={<ExportOutlined />} type="primary" onClick={() => onExport()}>
        Export
      </AntdButton>
    </TableHeader>
  );

  const renderEdit = (value: number, record: DefineParamData, index: number) => {
    return (
      <Popconfirm
        title={
          <Fragment>
            <div>{`Are you sure to edit ${name} param for`}</div>
            <div>{` '${record.name}'?`}</div>
          </Fragment>
        }
        onConfirm={() => openEditModal(record)}
        okText="Edit"
      >
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: DefineParamData, index: number) => {
    return (
      <Popconfirm
        title={
          <Fragment>
            <div>{`Are you sure to delete ${name} param for`}</div>
            <div>{` '${record.name}'?`}</div>
          </Fragment>
        }
        onConfirm={() => onDelete(record)}
        okText="Delete"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <Table<DefineParamData>
      rowKey={'id'}
      dataSource={defineList ?? []}
      bordered
      title={renderTitle}
      size="middle"
      pagination={{
        position: ['bottomCenter'],
      }}
      loading={isFetchingDefineList}
      tableLayout="fixed"
      sticky={{ offsetHeader: NAV_BAR_HIGHT }}
    >
      <Table.Column<DefineParamData> {...columnProps.setcode} />
      <Table.Column<DefineParamData> {...columnProps.name} />
      <Table.Column<DefineParamData> {...columnProps.edit} render={renderEdit} />
      <Table.Column<DefineParamData> {...columnProps.delete} render={renderDelete} />
    </Table>
  );
}

type ColumnName = 'setcode' | 'name' | 'edit' | 'delete';

const columnProps: TableColumnPropsType<DefineParamData, ColumnName> = {
  setcode: {
    key: 'setcode',
    title: <TableColumnTitle>Setcode</TableColumnTitle>,
    dataIndex: 'setcode',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'setcode'),
    },
    width: getPixelPercent(1360, 350),
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'name'),
    },

    width: getPixelPercent(1360, 770),
  },
  edit: {
    key: 'edit',
    dataIndex: 'id',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 120),
  },
  delete: {
    key: 'delete',
    dataIndex: 'id',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 120),
  },
};
