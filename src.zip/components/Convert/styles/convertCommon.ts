import { blue } from '@ant-design/colors';
import { css } from '@emotion/react';
import { hoverStyle } from '@styles/emotion/common';

export const convertInputViewStyle = css`
  border-color: white;
  pointer-events: none;
`;

export const convertSelectViewStyle = (isNotDisp = false) => css`
  pointer-events: none;
  ${isNotDisp &&
  css`
    content-visibility: hidden;
  `}
  .ant-select-selector {
    border-color: white !important;
  }
  .ant-select-arrow {
    display: none;
  }
`;

export const convertTableInputStyle = css`
  width: 10rem;
  font-size: 0.75rem;
`;

export const convertTableSelectStyle = css`
  width: 10rem;
  font-size: 0.75rem;
`;

export const convertTagStyle = (isSelected?: boolean) => css`
  margin-top: 4px;
  margin-bottom: 4px;
  max-width: 10rem;
  vertical-align: middle;

  .text {
    display: inline-block;
    vertical-align: middle;
    max-width: ${isSelected === undefined ? '9rem' : '8rem'};
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    word-break: break-all;
  }

  ${isSelected
    ? css`
        background-color: ${blue[5]};
        color: white;
        svg {
          color: white;
        }
        cursor: default;
        &:hover {
          background-color: ${blue[4]};
        }
      `
    : hoverStyle}
`;

export const convertTableErrorStyle = (isError = false) => css`
  .ant-table {
    .ant-table-container {
      border: ${isError && '1px solid red'};
    }
  }
`;
