import { blue } from '@ant-design/colors';
import { ExclamationCircleOutlined, PlusOutlined } from '@ant-design/icons';
import ErrorDescription from '@components/common/atoms/ErrorDescription';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { openNotification } from '@libs/util/notification';
import { flexCenterStyle } from '@styles/emotion/common';
import { ConvertRuleItem, ConvertSelectTag, CrasError, ReqConvertLogData } from '@typesdef/convertRules';
import { Divider, Empty, Input, InputProps, Select, SelectProps, Space, Spin, Tag } from 'antd';
import { AxiosError } from 'axios';
import { Fragment, JSXElementConstructor, ReactElement, useEffect, useState, useTransition } from 'react';
import {
  convertInputViewStyle,
  convertSelectViewStyle,
  convertTableInputStyle,
  convertTableSelectStyle,
  convertTagStyle,
} from './styles/convertCommon';

export const convertDefTypeCustom = ['text', 'lambda'];
export const convertDefTypePreset = ['null', 'equipment_name', 'equipment_id', 'filename', 'now'];
export const convertDataTypeNumber = ['integer', 'float'];
export const convertUseDefineType = ['info', 'header', 'no_header', 'regex'];
export const noDeleteLog = [
  {
    log_name: 'Running',
    table_name: 'running_rate',
  },
  {
    log_name: 'ErrorLog',
    table_name: 'error_log',
  },
];

export const initialReqConvertLogData: ReqConvertLogData = {
  log_name: '',
  select: [],
  table_name: '',
  input_type: 'csv',
  tag: [],
  ignore: [],
  retention: 90,
};

export const initialConvertRuleItem: ConvertRuleItem = {
  index: null,
  id: null,
  type: null,
  row_index: null,
  col_index: null,
  data: null,
  name: null,
  output_column: null,
  data_type: null,
  def_val: null,
  def_type: null,
  coef: null,
  unit: null,
  regex_prefix: null,
  regex: null,
  re_group: null,
  is_new: null,
  end_state: null,
  start_state: null,
};

interface ConvertTableInputProps {
  isViewMode?: boolean;
  viewWidth?: string;
  isError?: boolean;
}

export function ConvertTableInput({
  disabled = false,
  isViewMode = false,
  isError = false,
  ...rest
}: ConvertTableInputProps & InputProps) {
  const { value, onChange } = rest;
  const [input, setInput] = useState<string | undefined>((value as string) ?? undefined);
  const [_, startTrans] = useTransition();

  useEffect(() => {
    setInput(value as string | undefined);
  }, [value]);

  return (
    <Input
      value={input !== null ? `${input}` : undefined}
      css={isViewMode ? [convertTableInputStyle, convertInputViewStyle] : [convertTableInputStyle]}
      onChange={(e) => {
        setInput(e.target.value);
        startTrans(() => {
          if (onChange) {
            onChange(e);
          }
        });
      }}
      disabled={isViewMode ? false : disabled}
      status={isError ? 'error' : undefined}
      {...rest}
    />
  );
}

interface ConvertTableSelectProps {
  isViewMode?: boolean;
  viewValue?: string;
  viewWidth?: string;
  notViewOptions?: string[];
  isError?: boolean;
}

export function ConvertTableSelect({
  disabled = false,
  isViewMode = false,
  viewValue,
  viewWidth,
  notViewOptions = [],
  isError = false,
  ...rest
}: ConvertTableSelectProps & SelectProps) {
  const { value } = rest;
  if (isViewMode) {
    return (
      <Fragment>
        {!notViewOptions.includes(value as string) && (
          <ConvertViewInput
            css={css`
              width: ${viewWidth};
            `}
          >
            {viewValue ?? value}
          </ConvertViewInput>
        )}
      </Fragment>
    );
  }

  return (
    <Select
      showSearch={isViewMode ? false : true}
      disabled={disabled}
      status={isError ? 'error' : undefined}
      css={isViewMode ? [convertTableSelectStyle, convertSelectViewStyle()] : convertTableSelectStyle}
      {...rest}
    />
  );
}

export const ConvertViewInput = styled.div`
  border: 1px solid white;
  padding: 4px 11px 4px 11px;
  height: 32px;
  line-height: 22.001px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

interface ConvertItemTagProps<T, K> {
  list: T[];
  itemKey: keyof T;
  onDelete?: (value: K, index: number) => void;
  onEdit?: (value: K, index: number) => void;
  onAdd?: () => void;
  selected?: ConvertSelectTag<K>;
}

export function ConvertItemTag<T, K>({ list, itemKey, onDelete, onEdit, onAdd, selected }: ConvertItemTagProps<T, K>) {
  if (!(onDelete && onEdit && onAdd && selected)) {
    return (
      <Fragment>
        {list.map((item, idx) => {
          const curItem = item[itemKey] as unknown as K;
          return (
            <Tag css={[convertTagStyle()]} key={`${curItem}_${idx}`} title={`${idx + 1}: ${curItem}`}>
              <span className="text">{`${idx + 1}: ${curItem}`}</span>
            </Tag>
          );
        })}
      </Fragment>
    );
  }

  return (
    <Fragment>
      {list.map((item, idx) => {
        const curItem = item[itemKey] as unknown as K;
        return (
          <Tag
            css={[convertTagStyle(curItem === selected.value && selected.index === idx)]}
            key={`${curItem}_${idx}`}
            closable
            onClose={() => onDelete(curItem, idx)}
            onClick={() => {
              onEdit(curItem, idx);
            }}
            title={`${idx + 1}: ${curItem}`}
          >
            <span className="text">{`${idx + 1} : ${curItem}`}</span>
          </Tag>
        );
      })}
      <Tag
        css={[
          convertTagStyle(),
          css`
            border-style: dashed;
          `,
        ]}
      >
        <Space onClick={() => onAdd()}>
          <PlusOutlined /> Add
        </Space>
      </Tag>
    </Fragment>
  );
}

type ConvertSelectCustomItemList = 'custom' | 'null';
interface ConvertSelectCustomProps {
  menu: ReactElement<any, string | JSXElementConstructor<any>>;
  index?: number;
  itemList?: ConvertSelectCustomItemList[];
  onClick: ({ index, define }: { index?: number; define: 'custom' | 'null' }) => void;
}

export function ConvertSelectCustom({ menu, index, itemList = [], onClick }: ConvertSelectCustomProps) {
  return (
    <Fragment>
      {menu}
      {itemList.length > 0 && (
        <Fragment>
          <Divider style={{ margin: '8px 0' }} />
          <div css={convertSelectStyle}>
            {itemList.includes('custom') && (
              <div className="custom" onClick={() => onClick({ index, define: 'custom' })}>
                custom
              </div>
            )}
            {itemList.includes('null') && (
              <div className="null" onClick={() => onClick({ index, define: 'null' })}>
                null
              </div>
            )}
          </div>
        </Fragment>
      )}
    </Fragment>
  );
}

const convertSelectStyle = css`
  font-size: 0.875rem;
  margin-left: 0.85rem;
  margin-bottom: 0.5rem;
  .custom,
  .null {
    cursor: pointer;
    color: black;
    &:hover {
      color: ${blue[4]};
    }
    &:active {
      color: ${blue[6]};
    }
  }
`;

export function ConvertSelectNotFound({ isFetching }: { isFetching: boolean }) {
  if (isFetching) {
    return (
      <div css={flexCenterStyle}>
        <Spin />
      </div>
    );
  } else {
    return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  }
}

export const isNoDeleteLog = ({ log_name, table_name }: { log_name: string; table_name: string }) => {
  return noDeleteLog.some((item) => item.log_name === log_name && item.table_name === table_name);
};

export const openCrasErrorNotification = (error: AxiosError<CrasError>, tempErrorMsg: string) => {
  const crasError = error.response?.data?.cras_error;

  if (crasError) {
    openNotification('error', 'Error', <ErrorDescription msg={error.message} error={crasError} />, error);
  } else {
    openNotification('error', 'Error', tempErrorMsg, error);
  }
};

export function ConvertTableErrorTitle({ isError, errorMessage }: { isError: boolean; errorMessage?: string }) {
  const errorMsg = errorMessage ? errorMessage : 'Error Occurred!';

  if (!isError) {
    return <Fragment />;
  }

  return (
    <div
      css={css`
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 0.25rem;
        color: red;

        .text {
          width: 65rem;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      `}
    >
      <ExclamationCircleOutlined />
      <div className="text" title={errorMsg}>
        {errorMsg}
      </div>
    </div>
  );
}
