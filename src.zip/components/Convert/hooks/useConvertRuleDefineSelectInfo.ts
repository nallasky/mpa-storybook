import { useGetColumnDefine } from '@libs/query/columnDefine';
import { convertDuplicateData, convertParsingData } from '@libs/util/convert';
import { validateDBname } from '@libs/util/validation';
import { addConvertRuleInfo, getConvertRuleOption, setConvertRuleSelectInfoCheck } from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ReqSearchParam } from '@typesdef/common';
import { ConvertRuleSelectItem } from '@typesdef/convertRules';
import { DefaultOptionType } from 'antd/es/select';
import produce from 'immer';
import { useEffect, useMemo, useRef, useState } from 'react';
import { batch, useDispatch } from 'react-redux';
import { useDebounce } from 'react-use';
import { initialConvertRuleItem } from '../ConvertCommon';
import { ConvertRuleDefineSelectInfoProps } from '../Modal/ConvertRuleDefineSelectInfo';

interface Props extends ConvertRuleDefineSelectInfoProps {
  onClose: () => void;
}

export interface ConvertRuleSelectItemErrorState {
  key: keyof ConvertRuleSelectItem;
  type: 'duplicated' | 'empty' | 'length' | 'dbNaming';
  list: number[];
}

export default function useConvertRuleDefineSelectInfo({ row, data, onClose }: Props) {
  const dispatch = useDispatch();
  const [info, setInfo] = useState<ConvertRuleSelectItem[]>([]);
  const { data_type, def_type } = useTypedSelector(getConvertRuleOption);
  const [searchParam, setSearchParam] = useState<ReqSearchParam>({});
  const [searchInput, setSearchInput] = useState<{
    index: number | null;
    value: string | null;
  }>({
    index: null,
    value: null,
  });
  const tableRef = useRef<HTMLTableElement>(null);
  const [occurredError, setOccurredError] = useState<ConvertRuleSelectItemErrorState | null>(null);

  useDebounce(
    () => {
      setSearchParam(
        searchInput.index !== null && searchInput.value
          ? {
              name: searchInput.value,
            }
          : {},
      );
    },
    300,
    [searchInput],
  );

  const { data: infoDefines, isFetching: isFetchingDefine } = useGetColumnDefine(
    {
      paths: {
        type: 'info',
      },
      search: searchParam,
    },
    {
      enabled: searchInput.index !== null,
    },
  );

  const defineOptions: DefaultOptionType[] = useMemo(
    () =>
      infoDefines?.content.map((item) => ({
        label: item.name,
        value: item.name,
        key: item.name,
      })) ?? [],
    [infoDefines],
  );

  const dataTypeOptions: DefaultOptionType[] = useMemo(
    () =>
      data_type.map((item) => ({
        label: item,
        value: item,
        key: item,
      })),
    [data_type],
  );

  const defTypeOptions: DefaultOptionType[] = useMemo(
    () =>
      def_type.map((item) => ({
        label: item,
        value: item,
        key: item,
      })),
    [def_type],
  );

  const onSearchDefine = (value: string, index: number) => {
    setSearchInput({
      index,
      value,
    });
  };

  const onFocusDefine = (index: number) => {
    setSearchInput({
      index,
      value: null,
    });
  };

  const onBlurDefine = () => {
    setSearchInput({
      index: null,
      value: null,
    });
  };

  const onClickDefineOther = ({ index, define }: { index?: number; define: 'custom' | 'null' }) => {
    if (index !== undefined) {
      onChangeValue('define', define, index);
      const defineRef = tableRef.current?.querySelector(`.define_${index}`)?.querySelector('.ant-select-selector');
      if (defineRef) {
        const mouseDownEvent = new Event('mousedown', { bubbles: true, cancelable: true });
        // const clickEvent = new Event('click', { bubbles: true, cancelable: true });
        defineRef.dispatchEvent(mouseDownEvent);
        // defineRef.dispatchEvent(clickEvent);
      }
    }
  };

  const onChangeValue = (key: keyof ConvertRuleSelectItem, value: string | number | boolean | null, index: number) => {
    setInfo((prev) =>
      produce(prev, (draft) => {
        // if (key === 'define' && value !== 'custom') {
        //   const foundItem = infoDefines?.content.find((item) => item.name === value);
        //   if (foundItem) {
        //     draft[index] = {
        //       define: value as string,
        //       ...initialConvertRuleItem,
        //       ...foundItem,
        //     };
        //   } else {
        //     draft[index] = {
        //       define: value as string,
        //       ...initialConvertRuleItem,
        //     };
        //   }
        // } else if (key === 'def_type') {
        //   draft[index]['def_type'] = value as string;
        //   draft[index]['def_val'] = ['lambda', 'text'].includes(`${value}`) ? '' : (value as string);
        // } else {
        //   draft[index][key] = value as any;
        // }

        if (key === 'define') {
          if (value === 'custom') {
            draft[index][key] = value as any;
          } else if (value === 'null') {
            draft[index] = {
              define: value as string,
              ...initialConvertRuleItem,
            };
          } else {
            const foundItem = infoDefines?.content.find((item) => item.name === value);
            if (foundItem) {
              draft[index] = {
                define: value as string,
                ...initialConvertRuleItem,
                ...foundItem,
              };
            } else {
              draft[index] = {
                define: value as string,
                ...initialConvertRuleItem,
              };
            }
          }
        } else if (key === 'def_type') {
          draft[index]['def_type'] = value as string;
          draft[index]['def_val'] = ['lambda', 'text'].includes(`${value}`) ? '' : (value as string);
        } else {
          draft[index][key] = value as any;
        }
      }),
    );
  };

  const onDeleteRow = (index: number) => {
    setInfo((prev) =>
      produce(prev, (draft) => {
        draft.splice(index, 1);
      }),
    );
  };

  const validateData = () => {
    const emptyError = validateEmpty(['name', 'output_column', 'data_type']);
    if (emptyError) {
      setOccurredError(emptyError);
      return false;
    }

    const duplicatedError = validateDuplicated(['name', 'output_column']);
    if (duplicatedError) {
      setOccurredError(duplicatedError);
      return false;
    }

    const lengthError = validateLength(['name', 'output_column']);
    if (lengthError) {
      setOccurredError(lengthError);
      return false;
    }

    const dbNamingError = validateDbNaming(['output_column']);
    if (dbNamingError) {
      setOccurredError(dbNamingError);
      return false;
    }

    setOccurredError(null);
    return true;
  };

  const validateEmpty = (keys: (keyof ConvertRuleSelectItem)[]): ConvertRuleSelectItemErrorState | null => {
    for (let i = 0; i < keys.length; i++) {
      const errorArr = info.reduce((acc, item, index) => {
        if (item.define !== 'null' && !item[keys[i]]) {
          acc.push(index);
        }
        return acc;
      }, [] as number[]);
      if (errorArr.length > 0) {
        return {
          key: keys[i],
          type: 'empty',
          list: errorArr,
        };
      }
    }

    return null;
  };

  const validateDuplicated = (keys: (keyof ConvertRuleSelectItem)[]): ConvertRuleSelectItemErrorState | null => {
    for (let i = 0; i < keys.length; i++) {
      const indexValueObj = info.map((item, index) => item[keys[i]]);
      const errorArr = indexValueObj.reduce((acc, item, index, arr) => {
        if (item && arr.indexOf(item) !== arr.lastIndexOf(item)) {
          acc.push(index);
        }
        return acc;
      }, [] as number[]);
      if (errorArr.length > 0) {
        return {
          key: keys[i],
          type: 'duplicated',
          list: errorArr,
        };
      }
    }

    return null;
  };

  const validateLength = (keys: (keyof ConvertRuleSelectItem)[]): ConvertRuleSelectItemErrorState | null => {
    for (let i = 0; i < keys.length; i++) {
      const indexValueObj = info.map((item, index) => item[keys[i]]);
      const errorArr = indexValueObj.reduce((acc, item, index, arr) => {
        if (item && (item as string).length > 50) {
          acc.push(index);
        }
        return acc;
      }, [] as number[]);
      if (errorArr.length > 0) {
        return {
          key: keys[i],
          type: 'length',
          list: errorArr,
        };
      }
    }

    return null;
  };

  const validateDbNaming = (keys: (keyof ConvertRuleSelectItem)[]): ConvertRuleSelectItemErrorState | null => {
    for (let i = 0; i < keys.length; i++) {
      const indexValueObj = info.map((item, index) => item[keys[i]]);
      const errorArr = indexValueObj.reduce((acc, item, index, arr) => {
        if (!item || (item && !validateDBname(item as string))) {
          acc.push(index);
        }

        return acc;
      }, [] as number[]);
      if (errorArr.length > 0) {
        return {
          key: keys[i],
          type: 'dbNaming',
          list: errorArr,
        };
      }
    }

    return null;
  };

  const onOk = () => {
    if (validateData()) {
      batch(() => {
        dispatch(setConvertRuleSelectInfoCheck({ row, checked: true }));
        dispatch(
          addConvertRuleInfo({
            key: row,
            rule: info.map((item) => {
              const { define, ...rest } = item;
              return rest;
            }),
          }),
        );
      });

      onClose();
    }
  };

  useEffect(() => {
    const newInfo: ConvertRuleSelectItem[] = Object.values(data).map((item, idx) => {
      const { name, output_column, data_type, def_val, def_type } = convertParsingData(item);

      return {
        ...initialConvertRuleItem,
        define: name ? 'custom' : 'null',
        index: null,
        id: null,
        type: 'info',
        row_index: null,
        col_index: null,
        data: null,
        name,
        output_column,
        data_type,
        def_val,
        def_type,
        coef: null,
        unit: null,
        regex_prefix: null,
        regex: null,
        re_group: null,
        is_new: false,
      };
    });
    setInfo(convertDuplicateData(newInfo));
  }, [data]);

  return {
    info,
    onChangeValue,
    onDeleteRow,
    onOk,
    dataTypeOptions,
    defTypeOptions,
    defineOptions,
    searchInput,
    onSearchDefine,
    onFocusDefine,
    onBlurDefine,
    onClickDefineOther,
    isFetchingDefine,
    tableRef,
    occurredError,
  };
}
