import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import {
  deleteConvertRuleNoHeader,
  getConvertRuleHeader,
  getConvertRuleNoHeader,
  initConvertRuleNoHeader,
  setConvertRuleNoHeader,
} from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ConvertRuleItemWithKey } from '@typesdef/convertRules';
import { useDispatch } from 'react-redux';
import ConvertRuleDefineNoHeaderCopy from '../Modal/ConvertRuleDefineNoHeaderCopy';
import ConvertRuleDefineTagAddEdit, { ConvertRuleDefineTagAddEditProps } from '../Modal/ConvertRuleDefineTagAddEdit';

export default function useConvertRuleDefineCsvNoHeaderPane() {
  const dispatch = useDispatch();
  const noHeaderData = useTypedSelector(getConvertRuleNoHeader);
  const headerData = useTypedSelector(getConvertRuleHeader);
  const { openModal } = useModals();

  const onAdd = () => {
    openModal<ConvertRuleDefineTagAddEditProps>(MODAL_NAME.RULE_CONVERT.TAG_ADD_EDIT, ConvertRuleDefineTagAddEdit, {
      dataKeys: noHeaderData.map((item) => item.key),
      type: 'no_header',
      mode: 'add',
      itemList: ['column', 'define', 'data', 'name', 'output_column', 'data_type', 'def_val', 'coef', 'unit'],
    });
  };

  const onCopy = () => {
    openModal(MODAL_NAME.RULE_CONVERT.NO_HEADER_COPY, ConvertRuleDefineNoHeaderCopy);
  };

  const onEdit = (data: ConvertRuleItemWithKey, index: number) => {
    openModal<ConvertRuleDefineTagAddEditProps>(MODAL_NAME.RULE_CONVERT.TAG_ADD_EDIT, ConvertRuleDefineTagAddEdit, {
      index: index,
      data,
      dataKeys: noHeaderData.map((item) => item.key),
      type: 'no_header',
      mode: 'edit',
      itemList: ['column', 'define', 'data', 'name', 'output_column', 'data_type', 'def_val', 'coef', 'unit'],
    });
  };

  const onDelete = (index: number) => {
    dispatch(deleteConvertRuleNoHeader(index));
  };

  const onDeleteAll = () => {
    dispatch(initConvertRuleNoHeader());
  };

  return {
    noHeaderData,
    onAdd,
    onEdit,
    onDelete,
    onDeleteAll,
    onCopy,
    isCopy: headerData.length + noHeaderData.length > 0,
  };
}
