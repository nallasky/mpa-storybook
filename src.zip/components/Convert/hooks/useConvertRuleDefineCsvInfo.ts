import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import {
  deleteConvertRuleInfo,
  getConvertRuleInfo,
  initConvertRuleInfo,
  setConvertRuleSelectInfo,
  setConvertRuleSelectInfoCheck,
} from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ConvertRuleItemWithKey } from '@typesdef/convertRules';
import { batch, useDispatch } from 'react-redux';
import ConvertRuleDefineTagAddEdit, { ConvertRuleDefineTagAddEditProps } from '../Modal/ConvertRuleDefineTagAddEdit';

export default function useConvertRuleDefineCsvInfo() {
  const dispatch = useDispatch();
  const infoData = useTypedSelector(getConvertRuleInfo);
  const { openModal } = useModals();

  const onAdd = () => {
    openModal<ConvertRuleDefineTagAddEditProps>(MODAL_NAME.RULE_CONVERT.TAG_ADD_EDIT, ConvertRuleDefineTagAddEdit, {
      dataKeys: infoData.map((item) => +item.key),
      type: 'info',
      mode: 'add',
      itemList: ['row', 'define', 'name', 'output_column', 'data_type', 'def_val'],
    });
  };

  const onEdit = (data: ConvertRuleItemWithKey, index: number) => {
    openModal<ConvertRuleDefineTagAddEditProps>(MODAL_NAME.RULE_CONVERT.TAG_ADD_EDIT, ConvertRuleDefineTagAddEdit, {
      index,
      data,
      dataKeys: infoData.map((item) => +item.key),
      type: 'info',
      mode: 'edit',
      itemList: ['define', 'name', 'output_column', 'data_type', 'def_val'],
    });
  };

  const onDelete = (key: number, index: number) => {
    batch(() => {
      dispatch(deleteConvertRuleInfo(index));
      dispatch(setConvertRuleSelectInfoCheck({ row: key, checked: false }));
    });
  };

  const onDeleteAll = () => {
    batch(() => {
      dispatch(initConvertRuleInfo());
      dispatch(setConvertRuleSelectInfo([]));
    });
  };

  return {
    infoData,
    onAdd,
    onEdit,
    onDelete,
    onDeleteAll,
  };
}
