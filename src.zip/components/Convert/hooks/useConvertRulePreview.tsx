import { batch, useDispatch } from 'react-redux';

import { useFileUploadContext } from '@libs/context/UploadFileProvider';
import {
  usePostConvertPreviewConvert,
  usePostConvertPreviewFilter,
  usePostConvertPreviewSample,
} from '@libs/query/convert';
import {
  getConvertPreviewConvert,
  getConvertPreviewConvertTable,
  getConvertPreviewFilter,
  getConvertPreviewFilterTable,
  getConvertPreviewSample,
  getConvertPreviewSampleTable,
  getConvertReqPreviewConvert,
  getConvertReqPreviewFilter,
  initConvertRuleError,
  setConvertPreview,
  setConvertRuleError,
} from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { TypeConvertRule, TypeConvertRulePreview } from '@typesdef/convertRules';
import { useMemo } from 'react';
import { openCrasErrorNotification } from '../ConvertCommon';
import { useConvertRuleBeforePreview } from './useConvertRuleBeforePreview';

interface UseConvertRulePreviewProps {
  inputType: TypeConvertRule;
  previewType: TypeConvertRulePreview;
}

export default function useConvertRulePreview({ inputType, previewType }: UseConvertRulePreviewProps) {
  const previewSample = useTypedSelector(getConvertPreviewSample);
  const previewConvert = useTypedSelector(getConvertPreviewConvert);
  const previewFilter = useTypedSelector(getConvertPreviewFilter);
  const previewSampleTable = useTypedSelector(getConvertPreviewSampleTable);
  const previewConvertTable = useTypedSelector(getConvertPreviewConvertTable);
  const previewFilterTable = useTypedSelector(getConvertPreviewFilterTable);
  const reqPreviewConvert = useTypedSelector(getConvertReqPreviewConvert);
  const reqPreviewFilter = useTypedSelector(getConvertReqPreviewFilter);
  const { checkBeforeConvertPreview } = useConvertRuleBeforePreview();

  const { files } = useFileUploadContext();
  const disabled = previewType === 'sample' ? files.length === 0 : false;

  const { isLoadingSample, mutateSample } = useConvertRulePreviewSample();
  const { isLoadingConvert, mutateConvert } = useConvertRulePreviewConvert();
  const { isLoadingFilter, mutateFilter } = useConvertRulePreviewFilter();

  const isLoading = useMemo(
    () => isLoadingSample || isLoadingConvert || isLoadingFilter,
    [isLoadingSample, isLoadingConvert, isLoadingFilter],
  );

  const previewData = useMemo(() => {
    switch (previewType) {
      case 'sample':
        return previewSample;
      case 'convert':
        return previewConvert;
      case 'filter':
        return previewFilter;
      default:
        return null;
    }
  }, [previewType, previewSample, previewConvert, previewFilter]);

  const previewTableData = useMemo(() => {
    switch (previewType) {
      case 'sample':
        return previewSampleTable;
      case 'convert':
        return previewConvertTable;
      case 'filter':
        return previewFilterTable;
      default:
        return null;
    }
  }, [previewType, previewSampleTable, previewConvertTable, previewFilterTable]);

  const requestPreview = () => {
    switch (previewType) {
      case 'sample':
        if (files.length > 0) {
          const formData = new FormData();
          formData.append('files', files[0] as File);
          mutateSample({ inputType: inputType, previewType, formData });
        }
        break;
      case 'convert':
        {
          if (checkBeforeConvertPreview()) {
            mutateConvert({
              inputType: inputType,
              previewType,
              ...reqPreviewConvert,
            });
          }
        }
        break;
      case 'filter':
        mutateFilter({
          inputType: inputType,
          previewType,
          ...reqPreviewFilter,
        });
        break;
      default:
        break;
    }
  };

  return {
    previewData,
    previewTableData,
    requestPreview,
    isLoading,
    disabled,
  };
}

export function useConvertRulePreviewSample() {
  const dispatch = useDispatch();
  const {
    isLoading: isLoadingSample,
    mutate: mutateSample,
    mutateAsync: mutateAsyncSample,
  } = usePostConvertPreviewSample({
    onSuccess: ({ data }) => {
      batch(() => {
        dispatch(
          setConvertPreview({
            key: 'sample',
            data: data ?? null,
          }),
        );
        dispatch(initConvertRuleError());
      });
    },
    onError: (error) => {
      dispatch(
        setConvertPreview({
          key: 'sample',
          data: null,
        }),
      );
      openCrasErrorNotification(error, 'Failed to preview sample data!');
    },
  });

  return {
    isLoadingSample,
    mutateSample,
    mutateAsyncSample,
  };
}

export function useConvertRulePreviewConvert() {
  const dispatch = useDispatch();
  const {
    isLoading: isLoadingConvert,
    mutate: mutateConvert,
    mutateAsync: mutateAsyncConvert,
  } = usePostConvertPreviewConvert({
    onSuccess: ({ data }) => {
      batch(() => {
        dispatch(
          setConvertPreview({
            key: 'convert',
            data: data ?? null,
          }),
        );
        dispatch(initConvertRuleError());
      });
    },
    onError: (error) => {
      openCrasErrorNotification(error, 'Failed to preview convert data!');
      batch(() => {
        dispatch(
          setConvertPreview({
            key: 'convert',
            data: null,
          }),
        );
        const errorType = error?.response?.data?.cras_error?.type;
        const errorMessages = error?.response?.data?.cras_error?.error ?? '';
        if (errorType && isConvertType(errorType)) {
          dispatch(
            setConvertRuleError({
              type: errorType ?? null,
              viewScroll: true,
              message: errorMessages,
            }),
          );
        }
      });
    },
  });
  return {
    isLoadingConvert,
    mutateConvert,
    mutateAsyncConvert,
  };
}

export function useConvertRulePreviewFilter() {
  const dispatch = useDispatch();
  const {
    isLoading: isLoadingFilter,
    mutate: mutateFilter,
    mutateAsync: mutateAsyncFilter,
  } = usePostConvertPreviewFilter({
    onSuccess: ({ data }) => {
      batch(() => {
        dispatch(
          setConvertPreview({
            key: 'filter',
            data: data ?? null,
          }),
        );
        dispatch(initConvertRuleError());
      });
    },
    onError: (error) => {
      openCrasErrorNotification(error, 'Failed to preview filter data!');
      batch(() => {
        dispatch(
          setConvertPreview({
            key: 'filter',
            data: null,
          }),
        );

        const errorType = error?.response?.data?.cras_error?.type;
        if (errorType && isFilterType(errorType)) {
          dispatch(
            setConvertRuleError({
              type: errorType,
              viewScroll: true,
            }),
          );
        }
      });
    },
  });
  return {
    isLoadingFilter,
    mutateFilter,
    mutateAsyncFilter,
  };
}

const isConvertType = (type: string) => ['info', 'header', 'no_header', 'custom', 'filter'].includes(type);
const isConvertHeaderType = (type: string) => ['header', 'no_header'].includes(type);
const isFilterType = (type: string) => ['filter'].includes(type);
