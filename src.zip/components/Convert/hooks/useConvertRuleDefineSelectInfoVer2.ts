import { initialConvertRuleItem } from '@components/Convert/ConvertCommon';
import { tableScrollTo } from '@libs/util/common';
import { convertDuplicateData, convertParsingData } from '@libs/util/convert';
import { addConvertRuleInfo, getConvertRuleOption, setConvertRuleSelectInfoCheck } from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ConvertRuleSelectItem } from '@typesdef/convertRules';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, message } from 'antd';
import produce from 'immer';
import { useEffect, useRef, useState } from 'react';
import { batch, useDispatch } from 'react-redux';
import { CheckInfoDuplicationType } from '../Modal/ConvertRuleDefineSelectInfoVer2Items';
import { ConvertRuleDefineSelectInfoProps } from './../Modal/ConvertRuleDefineSelectInfo';

export default function useConvertRuleDefineSelectInfoVer2({
  visible,
  onClose,
  row,
  data,
}: GlobalModalDefaultProps<ConvertRuleDefineSelectInfoProps>) {
  const [info, setInfo] = useState<ConvertRuleSelectItem[]>([]);
  const infoOptions = useTypedSelector(getConvertRuleOption);
  const tableRef = useRef<HTMLDivElement>(null);
  const modalRef = useRef<HTMLDivElement>(null);
  const [form] = Form.useForm<ConvertRuleSelectItem>();
  const [checkForm] = Form.useForm<ConvertRuleSelectItem>();
  const [editingKey, setEditingKey] = useState<number | null>(null);
  const isEditing = (key: React.Key) => key === editingKey;
  const dispatch = useDispatch();

  const onAdd: React.MouseEventHandler<HTMLElement> = async (e) => {
    validateAllData().then((result) => {
      const newIndex = result.length > 0 ? result.length : 0;
      const record = {
        ...initialConvertRuleItem,
        define: 'custom',
      };
      setInfo((prev) =>
        produce(prev, (draft) => {
          draft.push(record);
        }),
      );

      // wait until the new row is rendered
      setTimeout(() => {
        if (tableRef.current) {
          tableScrollTo({
            ref: tableRef.current,
            colIndex: 1,
          });
        }
        onEdit(record, newIndex);
      }, 100);
    });
  };

  const onValidateSaveAsync = (key: React.Key) => {
    let result: ConvertRuleSelectItem[] = [];
    return form
      .validateFields()
      .then(() => {
        const data = form.getFieldsValue();
        result = produce(info, (draft) => {
          const foundIdx = draft.findIndex((item, idx) => idx === +key);
          draft[foundIdx] = data;
        });
        setInfo(result);
        return result;
      })
      .catch((error) => {
        throw new Error(error);
      });
  };

  const onEdit = (record: Partial<ConvertRuleSelectItem>, key: React.Key) => {
    form.setFieldsValue(record);
    setEditingKey(+key);
  };

  const onDelete = (index: number) => {
    setInfo((prev) =>
      produce(prev, (draft) => {
        draft.splice(index, 1);
      }),
    );
    setEditingKey(null);
  };

  const duplicateCheck: CheckInfoDuplicationType = ({ key, value, index, exception }) => {
    return new Promise((resolve, reject) => {
      if (!value) {
        return resolve(true);
      }

      if (exception && exception.includes(value)) {
        return resolve(true);
      }

      return info.filter((item, idx) => idx !== index).some((val) => val[key] === value)
        ? reject(false)
        : resolve(true);
    });
  };

  const onRow = (record: ConvertRuleSelectItem, rowIndex: number | undefined) => ({
    onClick: async (event: React.MouseEvent<HTMLElement, MouseEvent>) => {
      const className = (event.target as Element).className;
      const tagName = (event.target as Element).tagName;

      if (rowIndex === undefined) {
        return;
      }

      if (tagName === 'svg' || tagName === 'path') {
        return;
      }

      if (className.includes('delete') || className.includes('no')) {
        return;
      }

      try {
        if (rowIndex === editingKey) {
          return;
        }

        if (editingKey !== null) {
          await onValidateSaveAsync(editingKey);
          onEdit(record, rowIndex);
        } else {
          onEdit(record, rowIndex);
        }
      } catch (e) {
        console.error(e);
      }
    },
  });

  const getErrorRowKey = (): null | string => {
    const errorItem = tableRef.current?.querySelector('.ant-table-tbody')?.querySelector('.ant-input-status-error');
    if (!errorItem) {
      return null;
    }

    const trEle = errorItem.closest('tr');
    if (!trEle) {
      return null;
    }

    return trEle.getAttribute('data-row-key');
  };

  const validateAllData = async () => {
    let result: ConvertRuleSelectItem[] = info;
    let index = 0;

    try {
      if (editingKey !== null) {
        index = editingKey;
        result = await onValidateSaveAsync(editingKey);
      }

      for (index = 0; index < result.length; index++) {
        checkForm.setFieldsValue(result[index]);
        if (result[index].define !== 'null') {
          await checkForm.validateFields();
        }
      }

      // 중복 체크는 데이터가 들어오기전에 다 수정하고 들어옴.
      // for (index = 0; index < result.length; index++) {
      //   const { define, name, output_column } = result[index];
      //   const isError = result
      //     .filter((_, idx) => idx !== index)
      //     .some((item) => {
      //       let count = 0;
      //       if (define !== 'custom' && define !== 'null' && item.output_column === output_column) {
      //         count++;
      //       }
      //       if (item.name === name) {
      //         count++;
      //       }
      //       if (item.output_column === output_column) {
      //         count++;
      //       }

      //       return count > 0;
      //     });
      //   if (isError) {
      //     break;
      //   }
      // }

      const isErrorRowKey = getErrorRowKey();
      if (isErrorRowKey) {
        index = +isErrorRowKey;
        throw new Error(`There is an error in the row ${isErrorRowKey}`);
      }

      return result;
    } catch (e) {
      if (tableRef.current) {
        tableScrollTo({
          ref: tableRef.current,
          rowIndex: index,
          colIndex: 1,
        });
      }
      onEdit(result[index], index);
      // wait until the selected row is rendered
      setTimeout(() => {
        form.validateFields();
      }, 100);

      message.error({
        content: 'Please clear all errors and try again!',
      });
      console.error(e);
      throw new Error('validateAllData is error!');
    }
  };

  const onOk = async () => {
    validateAllData().then((result) => {
      batch(() => {
        dispatch(setConvertRuleSelectInfoCheck({ row, checked: true }));
        dispatch(
          addConvertRuleInfo({
            key: row,
            rule: result.map((item) => {
              const { define, ...rest } = item;
              return rest;
            }),
          }),
        );
      });
      onClose();
    });
  };

  useEffect(() => {
    const newInfo: ConvertRuleSelectItem[] = Object.values(data).map((item, idx) => {
      const { name, output_column, data_type, def_val, def_type } = convertParsingData(item);

      return {
        ...initialConvertRuleItem,
        define: name ? 'custom' : 'null',
        index: null,
        id: null,
        type: 'info',
        row_index: null,
        col_index: null,
        data: null,
        name,
        output_column,
        data_type,
        def_val,
        def_type,
        coef: null,
        unit: null,
        regex_prefix: null,
        regex: null,
        re_group: null,
        is_new: false,
      };
    });

    setInfo(convertDuplicateData(newInfo));
  }, [data]);

  return {
    info,
    infoOptions,
    tableRef,
    modalRef,
    form,
    isEditing,
    onDelete,
    duplicateCheck,
    onRow,
    onOk,
    onAdd,
    checkForm,
  };
}
