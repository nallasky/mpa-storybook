import { PAGE_URL } from '@constants/constants';
import { useFileUploadContext } from '@libs/context/UploadFileProvider';
import { usePostConvertRule, usePutConvertRule } from '@libs/query/convert';
import { openNotification } from '@libs/util/notification';
import {
  getConvertReqPreviewConvert,
  getConvertReqPreviewFilter,
  getConvertRuleCurStep,
  getConvertRuleSaveConvertData,
  getConvertSearch,
  getConvertSelectedLog,
  initConvertRuleError,
  setConvertRuleCurStep,
} from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { TypeConvertRule } from '@typesdef/convertRules';
import { useMemo } from 'react';
import { useDispatch } from 'react-redux';
import { createSearchParams, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { CONVERT_RULE_STEP } from '../ConvertRule';
import { useConvertRuleBeforePreview } from './useConvertRuleBeforePreview';
import {
  useConvertRulePreviewConvert,
  useConvertRulePreviewFilter,
  useConvertRulePreviewSample,
} from './useConvertRulePreview';

export default function useConvertRuleStep() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const current = useTypedSelector(getConvertRuleCurStep);
  const selectedLog = useTypedSelector(getConvertSelectedLog);
  const { keyword, type } = useTypedSelector(getConvertSearch);
  const [searchParams] = useSearchParams();
  const logName = searchParams.get('name') ?? '';
  const inputType = searchParams.get('inputType') as TypeConvertRule;
  const { mode } = useParams();
  const modeName = mode === 'edit' ? 'Edit' : 'Add';
  const { files, setFiles } = useFileUploadContext();
  const reqPreviewConvert = useTypedSelector(getConvertReqPreviewConvert);
  const reqPreviewFilter = useTypedSelector(getConvertReqPreviewFilter);
  const { isLoadingSample, mutateAsyncSample } = useConvertRulePreviewSample();
  const { isLoadingConvert, mutateAsyncConvert } = useConvertRulePreviewConvert();
  const { isLoadingFilter, mutateAsyncFilter } = useConvertRulePreviewFilter();
  const isLoading = useMemo(
    () => isLoadingSample || isLoadingConvert || isLoadingFilter,
    [isLoadingSample, isLoadingConvert, isLoadingFilter],
  );
  const reqSaveConvertData = useTypedSelector(getConvertRuleSaveConvertData);
  const { checkBeforeConvertPreview } = useConvertRuleBeforePreview();

  const { mutateAsync: mutateAsyncEdit } = usePutConvertRule({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to ${mode} rule about ${logName}`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to ${mode} rule about ${logName}`, error);
    },
  });

  const { mutateAsync: mutateAsyncAdd } = usePostConvertRule({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to ${mode} rule about ${logName}`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to ${mode} rule about ${logName}`, error);
    },
  });

  const nextAction = async () => {
    const [curStep] = current;
    switch (curStep) {
      case CONVERT_RULE_STEP.SAMPLE_LOG:
        if (!(await actionSampleLog())) {
          return false;
        }
        break;
      case CONVERT_RULE_STEP.DEFINE_RULE:
        if (!(await actionRuleDefine())) {
          return false;
        }
        break;
      case CONVERT_RULE_STEP.DEFILE_FILTER:
        if (!(await actionFilterDefine()) || !(await actionSaveDefine())) {
          return false;
        }
        break;
      default:
        break;
    }
    return true;
  };

  const actionSampleLog = async () => {
    try {
      if (files.length > 0) {
        const reqFormData = new FormData();
        reqFormData.append('files', files[0]);
        await mutateAsyncSample({ inputType: inputType, previewType: 'sample', formData: reqFormData });
      }
      dispatch(initConvertRuleError());
      return true;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const actionRuleDefine = async () => {
    try {
      if (!checkBeforeConvertPreview()) {
        return false;
      }

      await mutateAsyncConvert({
        inputType: inputType,
        previewType: 'convert',
        ...reqPreviewConvert,
      });
      dispatch(initConvertRuleError());
      return true;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const actionFilterDefine = async () => {
    try {
      await mutateAsyncFilter({
        inputType: inputType,
        previewType: 'filter',
        ...reqPreviewFilter,
      });
      dispatch(initConvertRuleError());
      return true;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const actionSaveDefine = async () => {
    try {
      const { id } = selectedLog ?? { id: null };
      if (id === null || id === undefined) {
        throw new Error('id is null');
      }
      if (mode === 'add') {
        await mutateAsyncAdd(reqSaveConvertData);
      } else {
        await mutateAsyncEdit(reqSaveConvertData);
      }

      return true;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const onNext = () => {
    dispatch(setConvertRuleCurStep('next'));
  };

  const onPrev = () => {
    dispatch(setConvertRuleCurStep('prev'));
  };

  const onLast = () => {
    navigate(PAGE_URL.RULES_CONVERT);
  };

  const onBack = () => {
    navigate({
      pathname: PAGE_URL.RULES_CONVERT,
      search:
        keyword || type
          ? `?${createSearchParams({
              keyword: (keyword as string) ?? '',
              type,
            })}`
          : undefined,
    });
  };

  return {
    current,
    onNext,
    onPrev,
    onLast,
    selectedLog,
    logName,
    modeName,
    nextAction,
    onBack,
    isLoading,
  };
}
