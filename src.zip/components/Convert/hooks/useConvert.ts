import { openAntdModal } from '@components/common/atoms/AntdModal/index';
import FileImportModal from '@components/common/atoms/FileImportModal';
import { FileImportModalProps } from '@components/common/atoms/FileImportModal/FileImportModal';
import { API_URL, PAGE_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import useTableSortSearch from '@hooks/useTableSortSearch';
import { useGetUserFabNameList } from '@libs/query/common';
import { queryClient } from '@libs/query/configure';
import { useDeleteConvertLog, useGetConvertLogExport, useGetConvertLogList } from '@libs/query/convert';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { getConvertSearch, initConvert, setConvertSearch, setConvertSelectedLog } from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ReqSearchParam } from '@typesdef/common';
import { ConvertLogItem, TypeConvertRule, TypeSearchConvertRule } from '@typesdef/convertRules';
import { AxiosError } from 'axios';
import { saveAs } from 'file-saver';
import { useCallback, useEffect, useLayoutEffect, useState } from 'react';
import { batch, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useDebounce } from 'react-use';
import ConvertAddEditItem, { ConvertAddEditItemProps } from '../Modal/ConvertAddEditItem';
import ConvertErrorLog, { ConvertErrorLogProps } from '../Modal/ConvertErrorLog';

export default function useConvert() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { openModal } = useModals();
  const {
    isRequesting,
    pagination,
    searchParam,
    hasSearchParam,
    setPagination,
    setSearchParam,
    setRequesting,
    onChangeTable,
  } = useTableSortSearch();
  const searchRedux = useTypedSelector(getConvertSearch);
  const [keyword, setKeyword] = useState<string>(searchRedux.keyword);

  const {
    data: crasList,
    isFetching: isFetchingCrasList,
    refetch: refetchCrasList,
  } = useGetUserFabNameList({
    initialData: [],
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to response the list of convert rule(user-fab name)`, error);
    },
  });

  const hasCrasServer = Boolean(crasList?.length ?? 0);

  const {
    data: list,
    isFetching: isFetchingList,
    refetch: refetchList,
  } = useGetConvertLogList(
    {
      pagination: {
        size: pagination.pageSize,
        page: pagination.current - 1,
        sort: pagination.sort,
      },
      search: searchParam,
    },
    {
      enabled: hasCrasServer,
      onSuccess: (data) => {
        setPagination({
          total: data.totalElements,
        });
      },
      onError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to response the list of convert rule`, error);
      },
      onSettled: () => {
        setRequesting(false);
      },
      keepPreviousData: true,
    },
  );

  const { mutateAsync: mutateAsyncDelete, isLoading: isLoadingDelete } = useDeleteConvertLog({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to delete convert log.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete convert log!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_CONVERT_LIST], { exact: false });
    },
  });

  const { mutateAsync: mutateAsyncExport, isLoading: isLoadingImport } = useGetConvertLogExport();

  const getCompanyFabName = useCallback(
    (siteId: number) => {
      const foundSite = crasList?.find((item) => item.siteId === siteId);
      return foundSite ? foundSite.crasCompanyFabName : 'not found';
    },
    [crasList],
  );

  const onClickRule = useCallback(
    (item: ConvertLogItem) => {
      dispatch(setConvertSelectedLog(item));
      navigate(
        PAGE_URL.RULES_CONVERT_RULE({
          type: item.rule ? 'edit' : 'add',
          inputType: item.input_type as TypeConvertRule,
          id: item.id,
          name: item.log_name,
        }),
      );
    },
    [dispatch, navigate],
  );

  const onAdd = () => {
    openModal<ConvertAddEditItemProps>(MODAL_NAME.RULE_CONVERT.LOG_ADD_EDIT, ConvertAddEditItem, {
      mode: 'add',
    });
  };

  const onEdit = useCallback(
    (data: ConvertLogItem, id: number) => {
      openModal<ConvertAddEditItemProps>(MODAL_NAME.RULE_CONVERT.LOG_ADD_EDIT, ConvertAddEditItem, {
        id,
        data,
        mode: 'edit',
      });
    },
    [openModal],
  );

  const onDelete = useCallback(
    async (id: number) => {
      try {
        await mutateAsyncDelete(id);
      } catch (e) {
        console.error(e);
      }
    },
    [mutateAsyncDelete],
  );

  const onExport = () => {
    openAntdModal('confirm', {
      title: 'Export Convert Rules',
      content: 'Are you sure to export convert rules?',
      okText: 'Export',
      onOk: async () => {
        try {
          const { data, fileName } = await mutateAsyncExport();
          saveAs(data, fileName);
          openNotification('success', 'Success', `Succeed to export convert rules '${fileName}'.`);
        } catch (e) {
          console.error(e);
          openNotification('error', 'Error', 'Failed to export convert rules!');
        }
      },
    });
  };

  const onImport = () => {
    openModal<FileImportModalProps>(MODAL_NAME.RULE_CONVERT.FILE_IMPORT, FileImportModal, {
      title: 'Import Convert Rules',
      url: API_URL.POST_CONVERT_LOG_IMPORT,
      afterError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to import convert rules!`, error);
      },
      afterSuccess: () => {
        openNotification('success', 'Success', 'Succeed to import convert rules.');
      },
      afterSettled: () => {
        queryClient.invalidateQueries([QUERY_KEY.RULES_CONVERT_LIST], {
          exact: false,
        });
        queryClient.invalidateQueries([QUERY_KEY.STATUS_SITE_LIST], {
          exact: true,
        });
      },
      mutationKey: [MUTATION_KEY.RULES_CONVERT_IMPORT],
    });
  };

  const onErrorView = useCallback(
    (logId: number) => {
      openModal<ConvertErrorLogProps>(MODAL_NAME.RULE_CONVERT.ERROR_LOG, ConvertErrorLog, {
        logId,
      });
    },
    [openModal],
  );

  useDebounce(
    () => {
      dispatch(setConvertSearch({ keyword }));
    },
    300,
    [keyword],
  );

  const onSelectType = (type: TypeSearchConvertRule) => {
    dispatch(setConvertSearch({ type }));
  };

  useLayoutEffect(() => {
    const { keyword, type } = searchRedux;
    batch(() => {
      dispatch(initConvert());
      if (!keyword && type !== 'all') {
        dispatch(setConvertSearch({ keyword, type }));
      }
    });
  }, []);

  useEffect(() => {
    const param: ReqSearchParam = {};

    if (searchRedux.keyword) {
      param['log_name'] = searchRedux.keyword;
    }

    if (searchRedux.type && searchRedux.type !== 'all') {
      param['input_type'] = searchRedux.type;
    }

    setSearchParam(param);
  }, [searchRedux, setSearchParam]);

  return {
    list,
    isFetchingList,
    hasCrasServer,
    pagination,
    hasSearchParam,
    onChangeTable,
    getCompanyFabName,
    onAdd,
    onEdit,
    onDelete,
    onExport,
    onImport,
    onClickRule,
    onErrorView,
    searchRedux,
    keyword,
    setKeyword,
    onSelectType,
  };
}
