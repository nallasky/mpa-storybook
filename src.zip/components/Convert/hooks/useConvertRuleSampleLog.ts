import { useFileUploadContext } from '@libs/context/UploadFileProvider';
import {
  setConvertPreview,
  setConvertRuleSelectHeader,
  setConvertRuleSelectInfo,
  setConvertRuleServerData,
} from '@reducers/slices/convert';
import { TypeConvertRule } from '@typesdef/convertRules';
import { UploadProps } from 'antd';
import { useEffect } from 'react';
import { batch, useDispatch } from 'react-redux';
import { useSearchParams } from 'react-router-dom';
import { usePrevious } from 'react-use';

export default function useConvertRuleSampleLog() {
  const { files, setFiles } = useFileUploadContext();
  const [searchParams] = useSearchParams();
  const inputType = searchParams.get('inputType') as TypeConvertRule;
  const dispatch = useDispatch();
  const prevFiles = usePrevious(files);

  const uploadProps: UploadProps = {
    name: 'files',
    multiple: false,
    maxCount: 1,
    beforeUpload: (file) => {
      setFiles([file]);
      return false;
    },
    onRemove: () => {
      setFiles([]);
    },
    fileList: files,
  };

  useEffect(() => {
    // when prevFiles is undefined, it means that it is the first time to render this component
    // or nothing has changed in the files;
    // prevFiles is ref value
    if (prevFiles !== undefined) {
      const curFileUid = files.length > 0 ? files[0].uid : null;
      const preFileUid = prevFiles && prevFiles.length > 0 ? prevFiles[0].uid : null;
      if (preFileUid !== curFileUid) {
        batch(() => {
          dispatch(
            setConvertPreview({
              key: 'sample',
              data: null,
            }),
          );
          dispatch(
            setConvertPreview({
              key: 'convert',
              data: null,
            }),
          );
          dispatch(
            setConvertPreview({
              key: 'filter',
              data: null,
            }),
          );
          dispatch(setConvertRuleSelectHeader([]));
          dispatch(setConvertRuleSelectInfo([]));
          dispatch(setConvertRuleServerData());
        });
      }
    }
  }, [files, dispatch]);

  return {
    uploadProps,
    inputType,
  };
}
