import { NAV_BAR_HIGHT } from '@constants/globalValue';
import {
  getConvertRuleError,
  getConvertRuleIsErrorType,
  setConvertRuleErrorViewScroll,
  setConvertRuleHeaderTab,
} from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import type { TypeConvertRule, TypeConvertRuleErrorPosition, TypeConvertRuleItem } from '@typesdef/convertRules';
import { useEffect, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { useSearchParams } from 'react-router-dom';

const positionTop: Record<TypeConvertRuleItem, number> = {
  header: 100,
  no_header: 100,
  info: 35,
  custom: 35,
  filter: 35,
  regex: 35,
};

export default function useConvertRuleScrollError(viewType: TypeConvertRuleErrorPosition) {
  const ruleError = useTypedSelector(getConvertRuleError);
  const dispatch = useDispatch();
  const tableRef = useRef<HTMLDivElement>(null);
  const isError = useTypedSelector(getConvertRuleIsErrorType(viewType));
  const [searchParams] = useSearchParams();
  const inputType = searchParams.get('inputType') as TypeConvertRule;

  useEffect(() => {
    const positionName = getPositionName({ errorType: ruleError.type, viewType, inputType });
    if (positionName) {
      if (['header', 'no_header'].includes(positionName)) {
        dispatch(setConvertRuleHeaderTab(ruleError.type as 'header' | 'no_header'));
      }
      dispatch(setConvertRuleErrorViewScroll(false));
      setTimeout(() => {
        if (tableRef?.current && ruleError.type) {
          const absoluteTop = window.pageYOffset + tableRef.current.getBoundingClientRect().top;
          window.scrollTo({
            top: absoluteTop - NAV_BAR_HIGHT - positionTop[positionName],
            behavior: 'smooth',
          });
        }
      }, 100);
    }
  }, [ruleError.type, ruleError.viewScroll, dispatch, viewType, inputType]);

  return {
    isError,
    errorMessage: ruleError.message,
    tableRef,
  };
}

const getPositionName = ({
  errorType,
  viewType,
  inputType,
}: {
  viewType: TypeConvertRuleErrorPosition;
  errorType: TypeConvertRuleItem | null;
  inputType: TypeConvertRule;
}): TypeConvertRuleItem | null => {
  if (!errorType || viewType !== errorType) {
    return null;
  }

  if (inputType === 'regex' && errorType === 'header') {
    return 'regex';
  }

  return errorType;
};
