import { openAntdModal } from '@components/common/atoms/AntdModal/index';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { usePostConvertParingHeader } from '@libs/query/convert';
import {
  deleteConvertRuleInfoWithKey,
  getConvertPreviewSampleTable,
  getConvertRuleSelectHeader,
  getConvertRuleSelectInfo,
  setConvertRuleHeader,
  setConvertRuleSelectHeaderCheck,
  setConvertRuleSelectInfoCheck,
} from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { CrasError } from '@typesdef/convertRules';
import { AxiosError } from 'axios';
import { batch, useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';
import { openCrasErrorNotification } from '../ConvertCommon';
import { ConvertRuleDefineSelectInfoProps } from '../Modal/ConvertRuleDefineSelectInfo';
import ConvertRuleDefineSelectInfoVer2 from '../Modal/ConvertRuleDefineSelectInfoVer2';

export default function useConvertRuleDefineCsvSelect() {
  const sample = useTypedSelector(getConvertPreviewSampleTable);
  const selectInfo = useTypedSelector(getConvertRuleSelectInfo);
  const selectHeader = useTypedSelector(getConvertRuleSelectHeader);
  const dispatch = useDispatch();
  const { openModal } = useModals();
  const { id } = useParams();

  const { mutateAsync, isLoading } = usePostConvertParingHeader({
    onSuccess: (data) => {
      dispatch(setConvertRuleHeader(data));
    },
  });

  const onCheckInfo = ({
    row,
    index,
    checked,
    data,
  }: {
    row: number;
    index: number;
    checked: boolean;
    data: Record<string, string | null>;
  }) => {
    if (checked) {
      openModal<ConvertRuleDefineSelectInfoProps>(
        MODAL_NAME.RULE_CONVERT.INFO_SELECT,
        ConvertRuleDefineSelectInfoVer2,
        {
          row,
          data,
        },
      );
    } else {
      batch(() => {
        dispatch(setConvertRuleSelectInfoCheck({ row, checked }));
        dispatch(deleteConvertRuleInfoWithKey(row));
      });
    }
  };

  const onCheckHeader = async ({
    row,
    index,
    checked,
    data,
  }: {
    row: number;
    index: number;
    checked: boolean;
    data: Record<string, string | null>;
  }) => {
    if (checked) {
      openAntdModal('confirm', {
        title: 'Are you sure to add this header?',
        onOk: async () => {
          try {
            await mutateAsync({
              id: +(id as string),
              header: Object.values(data) as unknown as string[],
              data: sample.data[index + 1] ? (Object.values(sample.data[index + 1]) as unknown as string[]) : [],
            });

            dispatch(setConvertRuleSelectHeaderCheck({ row, checked }));
          } catch (e) {
            const error = e as AxiosError<CrasError>;
            console.error(error);
            openCrasErrorNotification(error, 'Failed to parsing header data!');
          }
        },
      });
    } else {
      batch(() => {
        dispatch(setConvertRuleSelectHeaderCheck({ row, checked }));
        dispatch(setConvertRuleHeader([]));
      });
    }
  };

  return {
    sample,
    selectInfo,
    selectHeader,
    onCheckInfo,
    onCheckHeader,
  };
}
