import { useGetColumnDefine } from '@libs/query/columnDefine';
import { getFormErrorStatus } from '@libs/util/error';
import {
  addConvertRuleCustom,
  addConvertRuleFilter,
  addConvertRuleHeader,
  editConvertRuleCustom,
  editConvertRuleFilter,
  editConvertRuleHeader,
  getConvertRuleItemForName,
  getConvertRuleOption,
} from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ReqSearchParam } from '@typesdef/common';
import { ConvertRuleItem, ConvertRuleSelectItem, TypeConvertRule } from '@typesdef/convertRules';
import { RuleObject } from 'antd/es/form';
import { useForm, useWatch } from 'antd/es/form/Form';
import { DefaultOptionType } from 'antd/es/select';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useSearchParams } from 'react-router-dom';
import { useDebounce } from 'react-use';
import { convertDefTypeCustom, convertUseDefineType, initialConvertRuleItem } from '../ConvertCommon';
import { ConvertRuleDefineItemAddEditProps } from '../Modal/ConvertRuleDefineItemAddEdit';

interface Props extends ConvertRuleDefineItemAddEditProps {
  onClose: () => void;
}

export default function useConvertRuleDefineItemAddEdit({ onClose, index, data, type, mode, itemList }: Props) {
  const dispatch = useDispatch();
  const ruleList = useTypedSelector(getConvertRuleItemForName(type === 'regex' ? 'header' : type));
  const [form] = useForm<ConvertRuleSelectItem>();
  const ruleOptions = useTypedSelector(getConvertRuleOption);
  const [searchParam, setSearchParam] = useState<ReqSearchParam>({});
  const [searchInput, setSearchInput] = useState<string | null>();
  const divRef = useRef<HTMLDivElement>(null);
  const formDefine = useWatch('define', form);
  const formDefType = useWatch('def_type', form);
  const formDataType = useWatch('data_type', form);
  const [searchParams] = useSearchParams();
  const inputType = searchParams.get('inputType') as TypeConvertRule;

  useDebounce(
    () => {
      setSearchParam(
        searchInput
          ? {
              name: searchInput,
            }
          : {},
      );
    },
    300,
    [searchInput],
  );

  const { data: infoDefines, isFetching: isFetchingDefine } = useGetColumnDefine(
    {
      paths: {
        type,
      },
      search: searchParam,
    },
    {
      enabled: itemList.includes('define') && convertUseDefineType.includes(type),
    },
  );

  const typeOptions: {
    dataType: DefaultOptionType[];
    defType: DefaultOptionType[];
    filterType: DefaultOptionType[];
  } = useMemo(
    () => ({
      dataType: ruleOptions.data_type.map((item) => ({
        label: item,
        value: item,
        key: item,
      })),
      defType: ruleOptions.def_type.map((item) => ({
        label: item,
        value: item,
        key: item,
      })),
      filterType: ruleOptions.filter_type.map((item) => ({
        label: item,
        value: item,
        key: item,
      })),
    }),
    [ruleOptions],
  );

  const defineOptions: DefaultOptionType[] = useMemo(
    () =>
      infoDefines?.content.map((item) => ({
        label: item.name,
        value: item.name,
        key: item.name,
      })) ?? [],
    [infoDefines],
  );

  const onOk = async () => {
    try {
      await form.validateFields();
      switch (type) {
        case 'header':
          headerProcess();
          break;
        case 'custom':
          customProcess();
          break;
        case 'filter':
          filterProcess();
          break;
        case 'regex':
          regexProcess();
          break;
        default:
          break;
      }
      onClose();
    } catch (error) {
      console.error(error);
    }
  };

  const headerProcess = () => {
    const { define, data, name, output_column, data_type, def_type, def_val, coef, unit, start_state, end_state } =
      form.getFieldsValue();
    const rule: ConvertRuleItem = {
      ...initialConvertRuleItem,
      data: data ? data : null,
      name: name ? name : null,
      output_column: output_column ? output_column : null,
      data_type: data_type ? data_type : null,
      def_type: def_type ? def_type : null,
      def_val: def_val ? def_val : null,
      coef: coef ? coef : null, // coef not be 0
      unit: unit ? unit : null,
      type: 'header',
      is_new: true,
    };
    dispatch(
      mode === 'add'
        ? addConvertRuleHeader(rule)
        : editConvertRuleHeader({
            index,
            data: rule,
          }),
    );
  };

  const customProcess = () => {
    const { define, name, output_column, data_type, def_type, def_val } = form.getFieldsValue();
    const rule: ConvertRuleItem = {
      ...initialConvertRuleItem,
      name: name ? name : null,
      output_column: output_column ? output_column : null,
      data_type: data_type ? data_type : null,
      def_type: def_type ? def_type : null,
      def_val: def_val ? def_val : null,
      type: 'custom',
      is_new: true,
    };
    dispatch(
      mode === 'add'
        ? addConvertRuleCustom(rule)
        : editConvertRuleCustom({
            index,
            data: rule,
          }),
    );
  };

  const filterProcess = () => {
    const { define, name, def_type, def_val, start_state, end_state } = form.getFieldsValue();
    const new_def_type = inputType === 'status' ? 'time_sampler' : def_type;
    const rule: ConvertRuleItem = {
      ...initialConvertRuleItem,
      name: name ? name : null,
      def_type: new_def_type ? new_def_type : null,
      def_val: def_val ? def_val : null,
      type: 'filter',
      is_new: true,
      start_state: start_state ? start_state : null,
      end_state: end_state ? end_state : null,
    };
    dispatch(
      mode === 'add'
        ? addConvertRuleFilter(rule)
        : editConvertRuleFilter({
            index,
            data: rule,
          }),
    );
  };

  const regexProcess = () => {
    const { define, name, output_column, data_type, regex_prefix, regex, re_group, def_type, def_val, coef, unit } =
      form.getFieldsValue();
    const rule: ConvertRuleItem = {
      ...initialConvertRuleItem,
      name: name ? name : null,
      output_column: output_column ? output_column : null,
      data_type: data_type ? data_type : null,
      regex_prefix: regex_prefix ? regex_prefix : null,
      regex: regex ? regex : null,
      re_group: re_group ? re_group : null,
      def_type: def_type ? def_type : null,
      def_val: def_val ? def_val : null,
      coef: coef ? coef : null,
      unit: unit ? unit : null,
      type: 'header',
      is_new: true,
    };
    dispatch(
      mode === 'add'
        ? addConvertRuleHeader(rule)
        : editConvertRuleHeader({
            index,
            data: rule,
          }),
    );
  };

  const onChangeDefType = (value: string) => {
    if (!value) {
      form.setFieldsValue({
        def_type: null,
        def_val: null,
      });
    }

    form.setFieldsValue({
      def_type: value,
      def_val: convertDefTypeCustom.includes(value) ? '' : value,
    });
  };

  const onSearchDefine = (value: string | null) => {
    setSearchInput(value);
  };

  const onChangeDefine = (value: string) => {
    const foundItem = infoDefines?.content.find((item) => item.name === value);
    if (foundItem) {
      form.setFieldsValue({
        define: value,
        ...initialConvertRuleItem,
        ...foundItem,
        data: form.getFieldValue('data') ?? null,
      });
    } else {
      form.setFieldsValue({
        define: value,
        ...initialConvertRuleItem,
      });
    }
  };

  const onChangeDefineOther = ({ index, define }: { index?: number; define: 'custom' | 'null' }) => {
    form.setFieldsValue({
      define,
      ...initialConvertRuleItem,
    });

    const defineRef = divRef.current?.querySelector(`.define`)?.querySelector('.ant-select-selector');
    if (defineRef) {
      const mouseDownEvent = new Event('mousedown', { bubbles: true, cancelable: true });
      // const clickEvent = new Event('click', { bubbles: true, cancelable: true });
      defineRef.dispatchEvent(mouseDownEvent);
      // defineRef.current.dispatchEvent(clickEvent);
    }
  };

  const duplicateValidator = (rule: RuleObject, value: any) => {
    const { field } = rule as { field: keyof ConvertRuleItem | undefined };

    if (field === undefined) {
      throw new Error('field is undefined');
    }

    if (!value) {
      return Promise.resolve();
    }

    const dispName = field.replaceAll('_', ' ');
    if (mode === 'add') {
      return ruleList.find((item) => item[field] === value)
        ? Promise.reject(getFormErrorStatus({ rule: 'duplicated' }).help)
        : Promise.resolve();
    }
    if (mode === 'edit') {
      const removeOwn = ruleList.filter((item, idx) => idx !== index);
      return removeOwn.find((item) => item[field] === value)
        ? Promise.reject(getFormErrorStatus({ rule: 'duplicated' }).help)
        : Promise.resolve();
    }
    return Promise.resolve();
  };

  useEffect(() => {
    if (data) {
      form.setFieldsValue({
        ...data,
      });
    } else {
      form.setFieldsValue({
        ...initialConvertRuleItem,
        define: 'custom',
      });
    }
  }, []);

  return {
    form,
    ruleList,
    infoDefines,
    isFetchingDefine,
    onOk,
    onChangeDefType,
    onSearchDefine,
    onChangeDefine,
    onChangeDefineOther,
    searchInput,
    divRef,
    formDefine,
    formDefType,
    formDataType,
    typeOptions,
    defineOptions,
    duplicateValidator,
    inputType,
  };
}
