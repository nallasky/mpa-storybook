import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { deleteConvertRuleCustom, getConvertRuleCustom, setConvertRuleCustom } from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ConvertRuleItem } from '@typesdef/convertRules';
import { useDispatch } from 'react-redux';
import ConvertRuleDefineItemAddEdit, { ConvertRuleDefineItemAddEditProps } from '../Modal/ConvertRuleDefineItemAddEdit';

export default function useConvertRuleDefineCustom() {
  const dispatch = useDispatch();
  const customData = useTypedSelector(getConvertRuleCustom);
  const { openModal } = useModals();

  const onAdd = () => {
    openModal<ConvertRuleDefineItemAddEditProps>(MODAL_NAME.RULE_CONVERT.ITEM_ADD_EDIT, ConvertRuleDefineItemAddEdit, {
      type: 'custom',
      mode: 'add',
      itemList: ['name', 'output_column', 'data_type', 'def_val'],
    });
  };

  const onEdit = (value: ConvertRuleItem, index: number) => {
    openModal<ConvertRuleDefineItemAddEditProps>(MODAL_NAME.RULE_CONVERT.ITEM_ADD_EDIT, ConvertRuleDefineItemAddEdit, {
      index,
      data: value,
      type: 'custom',
      mode: 'edit',
      itemList: ['name', 'output_column', 'data_type', 'def_val'],
    });
  };

  const onDelete = (index: number) => {
    dispatch(deleteConvertRuleCustom(index));
  };

  const onDeleteAll = () => {
    dispatch(setConvertRuleCustom([]));
  };

  return {
    customData,
    onAdd,
    onEdit,
    onDelete,
    onDeleteAll,
  };
}
