import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import {
  deleteConvertRuleHeader,
  getConvertRuleHeader,
  setConvertRuleHeader,
  setConvertRuleSelectHeader,
} from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ConvertRuleItem } from '@typesdef/convertRules';
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import ConvertRuleDefineItemAddEdit, {
  ConvertRuleDefineItemAddEditProps,
} from './../Modal/ConvertRuleDefineItemAddEdit';

export default function useConvertRuleDefineCsvHeaderPane() {
  const dispatch = useDispatch();
  const headerData = useTypedSelector(getConvertRuleHeader);
  const [viewMode, setViewMode] = useState<'simple' | 'detail'>('detail');
  const { openModal } = useModals();

  const onChangeViewMode = (value: string) => {
    setViewMode(value as 'simple' | 'detail');
  };

  const onAdd = () => {
    openModal<ConvertRuleDefineItemAddEditProps>(MODAL_NAME.RULE_CONVERT.ITEM_ADD_EDIT, ConvertRuleDefineItemAddEdit, {
      type: 'header',
      mode: 'add',
      itemList: ['define', 'data', 'name', 'output_column', 'data_type', 'def_val', 'coef', 'unit'],
    });
  };

  const onEdit = (data: ConvertRuleItem, index: number) => {
    openModal<ConvertRuleDefineItemAddEditProps>(MODAL_NAME.RULE_CONVERT.ITEM_ADD_EDIT, ConvertRuleDefineItemAddEdit, {
      index,
      data,
      type: 'header',
      mode: 'edit',
      itemList: ['define', 'data', 'name', 'output_column', 'data_type', 'def_val', 'coef', 'unit'],
    });
  };

  const onDelete = (index: number) => {
    dispatch(deleteConvertRuleHeader(index));
  };

  const onDeleteAll = () => {
    dispatch(setConvertRuleHeader([]));
    dispatch(setConvertRuleSelectHeader([]));
  };

  return {
    headerData,
    viewMode,
    onChangeViewMode,
    onAdd,
    onEdit,
    onDelete,
    onDeleteAll,
  };
}
