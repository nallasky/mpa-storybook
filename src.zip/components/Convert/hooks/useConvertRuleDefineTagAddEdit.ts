import { useGetColumnDefine } from '@libs/query/columnDefine';
import { getFormErrorStatus } from '@libs/util/error';
import {
  addConvertRuleInfo,
  addConvertRuleNoHeader,
  editConvertRuleInfo,
  editConvertRuleNoHeader,
  getConvertRuleOption,
} from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ReqSearchParam } from '@typesdef/common';
import { ConvertRuleItem, ConvertRuleSelectItem, ConvertSelectTag } from '@typesdef/convertRules';
import { RuleObject } from 'antd/es/form';
import { useForm, useWatch } from 'antd/es/form/Form';
import { DefaultOptionType } from 'antd/es/select';
import { produce } from 'immer';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useDebounce } from 'react-use';
import { convertDefTypeCustom, initialConvertRuleItem } from '../ConvertCommon';
import { ConvertRuleDefineTagAddEditProps } from '../Modal/ConvertRuleDefineTagAddEdit';

interface Props extends ConvertRuleDefineTagAddEditProps {
  onClose: () => void;
}

export default function useConvertRuleDefineTagAddEdit({
  onClose,
  index,
  data,
  dataKeys,
  type,
  mode,
  itemList,
}: Props) {
  const dispatch = useDispatch();
  const [form] = useForm<ConvertRuleSelectItem>();
  const [subForm] = useForm<{ row: number; column: number }>();
  const [ruleList, setRuleList] = useState<ConvertRuleItem[]>([]);
  const [selectedTag, setSelectedTag] = useState<ConvertSelectTag<ConvertRuleItem['name']>>({
    mode: 'none',
    value: null,
    index: null,
  });
  const typeOptions = useTypedSelector(getConvertRuleOption);
  const [searchParam, setSearchParam] = useState<ReqSearchParam>({});
  const [searchInput, setSearchInput] = useState<string | null>();
  const divRef = useRef<HTMLDivElement>(null);
  const formDefine = useWatch('define', form);
  const formDefType = useWatch('def_type', form);
  const formDataType = useWatch('data_type', form);

  useDebounce(
    () => {
      setSearchParam(
        searchInput
          ? {
              name: searchInput,
            }
          : {},
      );
    },
    300,
    [searchInput],
  );

  const { data: infoDefines, isFetching: isFetchingDefine } = useGetColumnDefine({
    paths: {
      type: type === 'no_header' ? 'header' : type,
    },
    search: searchParam,
  });

  const defineOptions: DefaultOptionType[] = useMemo(
    () =>
      infoDefines?.content.map((item) => ({
        label: item.name,
        value: item.name,
        key: item.name,
      })) ?? [],
    [infoDefines],
  );

  const dataTypeOptions: DefaultOptionType[] = useMemo(
    () =>
      typeOptions.data_type.map((item) => ({
        label: item,
        value: item,
        key: item,
      })),
    [typeOptions.data_type],
  );

  const defTypeOptions: DefaultOptionType[] = useMemo(
    () =>
      typeOptions.def_type.map((item) => ({
        label: item,
        value: item,
        key: item,
      })),
    [typeOptions.def_type],
  );

  const onDeleteTag = (value: string | null, index: number) => {
    const foundItem = ruleList[index];
    if (foundItem) {
      form.resetFields();
      setRuleList((prev) => prev.filter((item, idx) => idx !== index));
      setSelectedTag({
        mode: 'none',
        index: null,
        value: null,
      });
    }
  };

  const onEditTag = (value: string | null, index: number) => {
    const foundItem = ruleList[index];
    if (foundItem) {
      form.resetFields();
      form.setFieldsValue({
        define: foundItem.name ? undefined : 'null',
        ...ruleList[index],
      });
      setSelectedTag({
        mode: 'edit',
        index,
        value,
      });
    }
  };

  const onAddTag = () => {
    form.resetFields();
    form.setFieldValue('define', 'custom');
    setSelectedTag({
      mode: 'add',
      index: null,
      value: null,
    });
  };

  const onClearTagData = () => {
    setSelectedTag({
      mode: 'none',
      index: null,
      value: null,
    });
    form.resetFields();
  };

  const onSaveAddTagData = (list: ConvertRuleItem[], value: ConvertRuleSelectItem) => {
    const newData = {
      ...initialConvertRuleItem,
      name: value.name,
      output_column: value.output_column,
      data_type: value.data_type,
      def_val: value.def_val,
      def_type: value.def_type,
      coef: value.coef ?? null,
      unit: value.unit ?? null,
    };

    return produce(list, (draft) => {
      draft.push(newData);
    });
  };

  const onSaveEditTagData = (list: ConvertRuleItem[], value: ConvertRuleSelectItem, index: number | null) => {
    const newData = {
      ...initialConvertRuleItem,
      name: value.name,
      output_column: value.output_column,
      data_type: value.data_type,
      def_val: value.def_val,
      def_type: value.def_type,
      coef: value.coef ?? null,
      unit: value.unit ?? null,
    };

    return produce(list, (draft) => {
      if (index !== null && draft[index]) {
        draft[index] = newData;
      }
    });
  };

  const onAddEdit = (value: ConvertRuleSelectItem) => {
    if (selectedTag.mode === 'add') {
      setRuleList((prev) => onSaveAddTagData(prev, value));
    } else {
      setRuleList((prev) => onSaveEditTagData(prev, value, selectedTag.index));
    }
    onClearTagData();
  };

  const onOk = async () => {
    try {
      await subForm.validateFields();
      let updatedRuleList = ruleList;

      if (selectedTag.mode === 'add' || selectedTag.mode === 'edit') {
        await form.validateFields();

        if (selectedTag.mode === 'add') {
          updatedRuleList = onSaveAddTagData(ruleList, form.getFieldsValue());
        } else {
          updatedRuleList = onSaveEditTagData(ruleList, form.getFieldsValue(), selectedTag.index);
        }

        onClearTagData();
      }

      switch (type) {
        case 'info': {
          const key = data?.key || (subForm.getFieldValue('row') as number | undefined);
          if (key) {
            dispatch(
              mode === 'add'
                ? addConvertRuleInfo({ key, rule: updatedRuleList })
                : editConvertRuleInfo({
                    index,
                    data: {
                      key,
                      rule: updatedRuleList,
                    },
                  }),
            );
          }
          break;
        }
        case 'no_header': {
          const key = subForm.getFieldValue('column') as number | undefined;
          if (key) {
            dispatch(
              mode === 'add'
                ? addConvertRuleNoHeader({ key, rule: updatedRuleList })
                : editConvertRuleNoHeader({
                    index,
                    data: {
                      key,
                      rule: updatedRuleList,
                    },
                  }),
            );
          }
          break;
        }
        case 'regex':
          break;
        default:
          break;
      }
      onClose();
    } catch (error) {
      console.error(error);
    }
  };

  const onChangeDefType = (value: string) => {
    form.setFieldsValue({
      def_type: value,
      def_val: convertDefTypeCustom.includes(value) ? '' : value,
    });
  };

  const onSearchDefine = (value: string | null) => {
    setSearchInput(value);
  };

  const onChangeDefine = (value: string) => {
    const foundItem = infoDefines?.content.find((item) => item.name === value);
    if (foundItem) {
      form.setFieldsValue({
        define: value,
        ...initialConvertRuleItem,
        ...foundItem,
      });
    } else {
      form.setFieldsValue({
        define: value,
        ...initialConvertRuleItem,
      });
    }
  };

  const onChangeDefineOther = ({ index, define }: { index?: number; define: 'custom' | 'null' }) => {
    form.setFieldsValue({
      define,
      ...initialConvertRuleItem,
    });

    const defineRef = divRef.current?.querySelector(`.define`)?.querySelector('.ant-select-selector');
    if (defineRef) {
      const mouseDownEvent = new Event('mousedown', { bubbles: true, cancelable: true });
      // const clickEvent = new Event('click', { bubbles: true, cancelable: true });
      defineRef.dispatchEvent(mouseDownEvent);
      // defineRef.current.dispatchEvent(clickEvent);
    }
  };

  const duplicateValidator = (rule: RuleObject, value: any) => {
    const { field } = rule as { field: keyof ConvertRuleItem | undefined };

    if (field === undefined) {
      throw new Error('field is undefined');
    }

    if (!value) {
      return Promise.resolve();
    }

    const dispName = field.replaceAll('_', ' ');
    if (selectedTag.mode === 'add') {
      return ruleList.find((item) => item[field] === value)
        ? Promise.reject(getFormErrorStatus({ rule: 'duplicated' }).help)
        : Promise.resolve();
    }

    if (selectedTag.mode === 'edit') {
      const removeOwn = ruleList.filter((item, idx) => idx !== selectedTag.index);
      return removeOwn.find((item) => item[field] === value)
        ? Promise.reject(getFormErrorStatus({ rule: 'duplicated' }).help)
        : Promise.resolve();
    }

    return Promise.resolve();
  };

  useEffect(() => {
    setRuleList(data?.rule ?? []);
  }, [data]);

  useEffect(() => {
    subForm.setFieldsValue({
      column: ruleList.length,
    });
  }, [ruleList, subForm]);

  return {
    form,
    subForm,
    ruleList,
    infoDefines,
    isFetchingDefine,
    onDeleteTag,
    onEditTag,
    onAddTag,
    selectedTag,
    onOk,
    onAddEdit,
    onChangeDefType,
    onSearchDefine,
    onChangeDefine,
    onChangeDefineOther,
    searchInput,
    divRef,
    formDefine,
    formDefType,
    formDataType,
    defineOptions,
    dataTypeOptions,
    defTypeOptions,
    duplicateValidator,
  };
}
