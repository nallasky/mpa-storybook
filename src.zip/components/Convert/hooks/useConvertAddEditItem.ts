import { API_URL } from '@constants/constants';
import { getRequest } from '@libs/axios/requests';
import { useGetUserFabNameList } from '@libs/query/common';
import { usePostConvertLog, usePutConvertLog } from '@libs/query/convert';
import { QUERY_KEY } from '@libs/query/queryKey';
import { getQueriesParam, isDuplicateItemFormList } from '@libs/util/convert';
import { getFormErrorStatus, initialFormError } from '@libs/util/error';
import { openNotification } from '@libs/util/notification';
import { validateDBname } from '@libs/util/validation';
import { useQueryClient } from '@tanstack/react-query';
import { FormErrorStatus, ResPagination } from '@typesdef/common';
import { ConvertLogItem, ReqConvertLogData } from '@typesdef/convertRules';
import { useForm, useWatch } from 'antd/es/form/Form';
import { SwitchChangeEventHandler } from 'antd/es/switch';
import { useEffect, useMemo, useReducer, useState } from 'react';
import { flushSync } from 'react-dom';
import { useDebounce } from 'react-use';
import { ConvertAddEditItemProps } from '../Modal/ConvertAddEditItem';

interface Props extends ConvertAddEditItemProps {
  onClose: () => void;
}

interface FormValidState {
  log_name: FormErrorStatus;
  table_name: FormErrorStatus;
}

export type FormValidStateAction =
  | { type: 'SET_LOG_NAME'; payload: FormErrorStatus }
  | { type: 'SET_TABLE_NAME'; payload: FormErrorStatus };

const formValidReducer = (state: FormValidState, action: FormValidStateAction): FormValidState => {
  switch (action.type) {
    case 'SET_LOG_NAME':
      return { ...state, log_name: action.payload };
    case 'SET_TABLE_NAME':
      return { ...state, table_name: action.payload };
    default:
      return state;
  }
};

export default function useConvertAddEditItem({ onClose, id, data, mode }: Props) {
  const queryClient = useQueryClient();
  const [form] = useForm<ReqConvertLogData>();
  const [tag, setTagArr] = useState<string[]>([]);
  const [ignore, setIgnoreArr] = useState<string[]>([]);
  const [isRetention, setIsRetention] = useState(true);
  const formLogName = useWatch('log_name', form);
  const formTableName = useWatch('table_name', form);
  const [formValid, setFormValid] = useReducer(formValidReducer, {
    log_name: { ...initialFormError },
    table_name: { ...initialFormError },
  });

  const { data: siteList } = useGetUserFabNameList();

  const siteOptions = useMemo(
    () => siteList?.map((item) => ({ label: item.crasCompanyFabName, value: item.siteId, key: item.siteId })) ?? [],
    [siteList],
  );

  const setTag = (tag: string[]) => {
    setTagArr(tag);
    form.setFieldsValue({
      tag,
    });
  };

  const setIgnore = (ignore: string[]) => {
    setIgnoreArr(ignore);
    form.setFieldsValue({
      ignore,
    });
  };

  const { mutate: mutateAdd, isLoading: isLoadingAdd } = usePostConvertLog({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to ${mode} convert log.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to ${mode} convert log!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_CONVERT_LIST], { exact: false });
    },
  });

  const { mutate: mutateEdit, isLoading: isLoadingEdit } = usePutConvertLog({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to ${mode} convert log.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to ${mode} convert log!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_CONVERT_LIST], { exact: false });
    },
  });

  const isLoading = useMemo(() => isLoadingAdd || isLoadingEdit, [isLoadingAdd, isLoadingEdit]);

  const setRetention: SwitchChangeEventHandler = (checked, event) => {
    setIsRetention(checked);
    form.setFieldsValue({
      retention: checked ? 90 : undefined,
    });
  };

  const onValidateData = async () => {
    let isError = false;
    try {
      await form.validateFields();
    } catch (error) {
      isError = true;
      console.error(error);
    } finally {
      if (!formLogName) {
        setFormValid({ type: 'SET_LOG_NAME', payload: getFormErrorStatus({ rule: 'empty' }) });
        isError = true;
      }

      if (!formTableName) {
        setFormValid({ type: 'SET_TABLE_NAME', payload: getFormErrorStatus({ rule: 'empty' }) });
        isError = true;
      }

      if (Object.values(formValid).some((item) => item.status === 'error')) {
        isError = true;
      }
    }

    return isError;
  };

  const onOk = async () => {
    try {
      if (!(await onValidateData())) {
        const { log_name, table_name, input_type, select, tag, ignore, retention } = form.getFieldsValue();
        const reqData = {
          log_name: log_name ?? '',
          table_name: table_name ?? '',
          input_type: input_type ?? '',
          select: select ?? [],
          tag: tag ?? [],
          ignore: ignore ?? [],
          retention: retention || 0,
        };

        if (mode === 'add') {
          await mutateAdd({
            data: reqData,
          });
        } else if (mode === 'edit') {
          await mutateEdit({
            id,
            data: reqData,
          });
        }
        onClose();
      }
    } catch (error) {
      console.error(error);
    }
  };

  useDebounce(
    async () => {
      if (formLogName) {
        try {
          if (formLogName.length > 50) {
            setFormValid({ type: 'SET_TABLE_NAME', payload: getFormErrorStatus({ rule: 'max', max: 50 }) });
            return;
          }

          flushSync(() => {
            setFormValid({ type: 'SET_LOG_NAME', payload: getFormErrorStatus({ rule: 'initial' }) });
          });

          const { content } = await getRequest<ResPagination<ConvertLogItem[]>>({
            url: API_URL.GET_CONVERT_LOG_LIST(
              getQueriesParam({
                query: {
                  strict: true,
                },
                search: {
                  ['log_name']: formLogName as string,
                },
              }),
            ),
          });

          if (
            isDuplicateItemFormList<ConvertLogItem>({
              key: 'log_name',
              curName: formLogName,
              oriName: data?.log_name ?? '',
              content,
            })
          ) {
            flushSync(() => {
              setFormValid({ type: 'SET_LOG_NAME', payload: getFormErrorStatus({ rule: 'duplicated' }) });
            });
          } else {
            flushSync(() => {
              setFormValid({ type: 'SET_LOG_NAME', payload: getFormErrorStatus({ rule: 'initial' }) });
            });
          }
        } catch (e) {
          console.error(e);
        }
      }
    },

    300,
    [formLogName],
  );

  useDebounce(
    async () => {
      if (formTableName) {
        try {
          if (!validateDBname(formTableName)) {
            setFormValid({ type: 'SET_TABLE_NAME', payload: getFormErrorStatus({ rule: 'dbNaming' }) });
            return;
          }

          if (formLogName.length > 50) {
            setFormValid({ type: 'SET_TABLE_NAME', payload: getFormErrorStatus({ rule: 'max', max: 50 }) });
            return;
          }

          flushSync(() => {
            setFormValid({ type: 'SET_TABLE_NAME', payload: getFormErrorStatus({ rule: 'initial' }) });
          });

          const { content } = await getRequest<ResPagination<ConvertLogItem[]>>({
            url: API_URL.GET_CONVERT_LOG_LIST(
              getQueriesParam({
                query: {
                  strict: true,
                },
                search: {
                  ['table_name']: formTableName as string,
                },
              }),
            ),
          });

          if (
            isDuplicateItemFormList<ConvertLogItem>({
              key: 'table_name',
              curName: formTableName,
              oriName: data?.table_name ?? '',
              content,
            })
          ) {
            flushSync(() => {
              setFormValid({ type: 'SET_TABLE_NAME', payload: getFormErrorStatus({ rule: 'duplicated' }) });
            });
          } else {
            flushSync(() => {
              setFormValid({ type: 'SET_TABLE_NAME', payload: getFormErrorStatus({ rule: 'initial' }) });
            });
          }
        } catch (e) {
          console.error(e);
        }
      }
    },

    300,
    [formTableName],
  );

  useEffect(() => {
    if (formLogName !== undefined && formLogName === '') {
      setFormValid({ type: 'SET_LOG_NAME', payload: getFormErrorStatus({ rule: 'empty' }) });
    } else {
      setFormValid({ type: 'SET_LOG_NAME', payload: getFormErrorStatus({ rule: 'initial' }) });
    }
  }, [formLogName]);

  useEffect(() => {
    if (formTableName !== undefined && formTableName === '') {
      setFormValid({ type: 'SET_TABLE_NAME', payload: getFormErrorStatus({ rule: 'empty' }) });
    } else {
      setFormValid({ type: 'SET_TABLE_NAME', payload: getFormErrorStatus({ rule: 'initial' }) });
    }
  }, [formTableName]);

  useEffect(() => {
    if (data) {
      const { log_name, table_name, input_type, select, tag, ignore, retention } = data;
      form.setFieldsValue({
        log_name,
        table_name,
        input_type,
        select: [], // not display user-fab name
        tag: tag ?? [],
        ignore: ignore ?? [],
        retention: retention || undefined,
      });
      setIsRetention(retention && retention > 0 ? true : false);
      setTag(tag ?? []);
      setIgnore(ignore ?? []);
    } else {
      form.resetFields();
      form.setFieldsValue({
        retention: 90,
        tag: [],
        ignore: [],
      });
    }
  }, []);

  return {
    form,
    onOk,
    formValid,
    isLoading,
    siteOptions,
    tag,
    setTag,
    ignore,
    setIgnore,
    isRetention,
    setRetention,
  };
}
