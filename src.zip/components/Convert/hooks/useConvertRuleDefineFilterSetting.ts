import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { deleteConvertRuleFilter, getConvertRuleFilter, setConvertRuleFilter } from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ConvertRuleItem, TypeConvertRule } from '@typesdef/convertRules';
import { useDispatch } from 'react-redux';
import { useSearchParams } from 'react-router-dom';
import ConvertRuleDefineItemAddEdit, { ConvertRuleDefineItemAddEditProps } from '../Modal/ConvertRuleDefineItemAddEdit';

export default function useConvertRuleDefineFilterSetting() {
  const dispatch = useDispatch();
  const filterData = useTypedSelector(getConvertRuleFilter);
  const { openModal } = useModals();
  const [searchParams] = useSearchParams();
  const inputType = searchParams.get('inputType') as TypeConvertRule;

  const onAdd = () => {
    openModal<ConvertRuleDefineItemAddEditProps>(MODAL_NAME.RULE_CONVERT.ITEM_ADD_EDIT, ConvertRuleDefineItemAddEdit, {
      type: 'filter',
      mode: 'add',
      itemList: inputType === 'status' ? ['name', 'start_state', 'end_state'] : ['name', 'filter_type', 'condition'],
    });
  };

  const onEdit = (data: ConvertRuleItem, index: number) => {
    openModal<ConvertRuleDefineItemAddEditProps>(MODAL_NAME.RULE_CONVERT.ITEM_ADD_EDIT, ConvertRuleDefineItemAddEdit, {
      index,
      data,
      type: 'filter',
      mode: 'edit',
      itemList: inputType === 'status' ? ['name', 'start_state', 'end_state'] : ['name', 'filter_type', 'condition'],
    });
  };

  const onDelete = (index: number) => {
    dispatch(deleteConvertRuleFilter(index));
  };

  const onDeleteAll = () => {
    dispatch(setConvertRuleFilter([]));
  };

  return {
    filterData,
    onAdd,
    onEdit,
    onDelete,
    onDeleteAll,
    inputType,
  };
}
