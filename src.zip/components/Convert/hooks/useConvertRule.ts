import { useGetConvertRule, useGetConvertRuleOption } from '@libs/query/convert';
import { openNotification } from '@libs/util/notification';
import {
  getConvertRuleCurStep,
  initConvertRule,
  setConvertRuleDataFromServer,
  setConvertRuleOptions,
} from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { TypeConvertRule } from '@typesdef/convertRules';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useParams, useSearchParams } from 'react-router-dom';

export default function useConvertRule() {
  const dispatch = useDispatch();
  const [current] = useTypedSelector(getConvertRuleCurStep);
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const inputType = searchParams.get('inputType') as TypeConvertRule;
  const { mode } = useParams();

  const { isFetching: isFetchingRule } = useGetConvertRule(id, {
    enabled: !!id && mode === 'edit',
    onSuccess: (data) => {
      dispatch(setConvertRuleDataFromServer(data));
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to get rule data!`, error);
    },
  });

  const { isFetching: isFetchingOption } = useGetConvertRuleOption({
    onSuccess: (data) => {
      dispatch(setConvertRuleOptions(data));
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to get rule options`, error);
      dispatch(
        setConvertRuleOptions({
          data_type: [],
          def_type: [],
          filter_type: [],
        }),
      );
    },
  });

  useEffect(() => {
    dispatch(initConvertRule);
  }, []);

  return {
    current,
    inputType,
  };
}
