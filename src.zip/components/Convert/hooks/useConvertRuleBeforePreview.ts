import { openNotification } from '@libs/util/notification';
import { getConvertReqPreviewConvert, setConvertRuleError } from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ReqConvertPreviewConvert, TypeConvertRule } from '@typesdef/convertRules';
import { useDispatch } from 'react-redux';
import { useSearchParams } from 'react-router-dom';

export function useConvertRuleBeforePreview() {
  const dispatch = useDispatch();
  const [searchParams] = useSearchParams();
  const inputType = searchParams.get('inputType') as TypeConvertRule;
  const reqPreviewConvert = useTypedSelector(getConvertReqPreviewConvert);

  const checkBeforeConvertPreview = () => {
    const {
      convert: { info, header, no_header, custom },
    } = reqPreviewConvert;

    if (!checkRuleDefineEmpty({ info, header, no_header, custom, inputType })) {
      return false;
    }

    if (!checkRuleDefineNoLogTime({ info, header, no_header, custom, inputType })) {
      return false;
    }
    return true;
  };

  const checkRuleDefineEmpty = ({
    info,
    header,
    no_header,
    custom,
    inputType,
  }: ReqConvertPreviewConvert['convert'] & { inputType: TypeConvertRule }) => {
    if (inputType === 'csv') {
      if (info.length === 0 && header.length === 0 && no_header.length === 0) {
        openNotification('error', 'Error', `Please input at least one rule among Info, Header, and No Header!`);
        return false;
      }
    }
    if (inputType === 'regex') {
      if (header.length === 0) {
        openNotification('error', 'Error', `Please input at least one rule from Regex!`);
        return false;
      }
    }

    return true;
  };

  const checkRuleDefineNoLogTime = ({
    info,
    header,
    no_header,
    custom,
    inputType,
  }: ReqConvertPreviewConvert['convert'] & { inputType: TypeConvertRule }) => {
    const noLogTimeInHeader = header.length > 1 ? !header.some((item) => item.output_column === 'log_time') : false;
    const noLogTimeInNoHeader =
      no_header.length > 1
        ? no_header.reduce((acc, cur) => {
            if (!cur.rule.some((item) => item.output_column === 'log_time')) {
              acc.push(cur.key);
            }
            return acc;
          }, [] as number[])
        : [];

    const noLogTimeInCustom = !custom.some((item) => item.output_column === 'log_time');
    const name = inputType === 'csv' ? 'Header' : 'Regex';

    if (noLogTimeInCustom) {
      if (noLogTimeInHeader && noLogTimeInNoHeader.length > 0) {
        openNotification('error', 'Error', `output column must have log_time column in ${name}!`);
        dispatch(
          setConvertRuleError({
            type: 'custom',
            viewScroll: true,
            message: 'output column must have log_time column!',
          }),
        );

        return false;
      } else if (noLogTimeInHeader) {
        openNotification('error', 'Error', `output column must have log_time column in ${name}!`);
        dispatch(
          setConvertRuleError({
            type: 'header',
            viewScroll: true,
            message: 'output column must have log_time column!',
          }),
        );

        return false;
      } else if (noLogTimeInNoHeader.length > 0) {
        openNotification(
          'error',
          'Error',
          `output column must have log_time column in No Header(${noLogTimeInNoHeader.join(', ')} Columns)!`,
        );
        dispatch(
          setConvertRuleError({
            type: 'no_header',
            viewScroll: true,
            message: `output column must have log_time column in ${noLogTimeInNoHeader.join(', ')} Columns!`,
          }),
        );
        return false;
      }
    }

    return true;
  };

  return {
    checkBeforeConvertPreview,
  };
}
