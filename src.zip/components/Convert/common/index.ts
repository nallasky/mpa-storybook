import { TypeConvertRule } from '@typesdef/convertRules';

const CONVERT_RULE_TYPE: Record<TypeConvertRule, { label: string; value: TypeConvertRule }> = {
  csv: {
    label: 'CSV',
    value: 'csv',
  },
  regex: {
    label: 'Regular Expression',
    value: 'regex',
  },
  status: {
    label: 'Status Monitor',
    value: 'status',
  },
  arcnet: {
    label: 'Arcnet',
    value: 'arcnet',
  },
  cylinder: {
    label: 'Cylinder Drive Count',
    value: 'cylinder',
  },
  laser: {
    label: 'Laser Interferometer Power',
    value: 'laser',
  },
  liftbar: {
    label: 'Liftbar Vacuum',
    value: 'liftbar',
  },
  machine: {
    label: 'Machine Data',
    value: 'machine',
  },
  periodic: {
    label: 'Periodic Log Copy',
    value: 'periodic',
  },
  version: {
    label: 'Version Info',
    value: 'version',
  },
};

export const convertRuleInputTypeOptions = Object.values(CONVERT_RULE_TYPE).map((content) => ({
  label: content.label,
  value: content.value,
  key: content.value,
}));

export const convertRuleInputTypeSearchOptions = [
  {
    label: 'All',
    value: 'all',
    key: 'all',
  },
  ...convertRuleInputTypeOptions,
];

export const convertRuleNoEditInputType: TypeConvertRule[] = [
  CONVERT_RULE_TYPE.cylinder.value,
  CONVERT_RULE_TYPE.arcnet.value,
  CONVERT_RULE_TYPE.machine.value,
];

export const getConvertRuleBaseType = (value: TypeConvertRule) =>
  value === CONVERT_RULE_TYPE['regex'].value ? 'regex' : 'csv';

export const getConvertRuleInputTypeText = (value: TypeConvertRule) => {
  return CONVERT_RULE_TYPE?.[value]?.label ?? '';
};
