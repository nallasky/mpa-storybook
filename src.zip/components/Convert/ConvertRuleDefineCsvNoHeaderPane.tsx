import { BulbOutlined, CopyOutlined, DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { ConvertRuleItem, ConvertRuleItemWithKey } from '@typesdef/convertRules';
import { Popconfirm, Space, Table } from 'antd';
import { ColumnsType } from 'antd/es/table';
import { ConvertItemTag, ConvertTableErrorTitle } from './ConvertCommon';
import useConvertRuleDefineCsvNoHeaderPane from './hooks/useConvertRuleDefineCsvNoHeaderPane';
import useConvertRuleScrollError from './hooks/useConvertRuleScrollError';
import { convertTableErrorStyle } from './styles/convertCommon';

export default function ConvertRuleDefineCsvNoHeaderPane() {
  const { noHeaderData, isCopy, onAdd, onEdit, onDelete, onDeleteAll, onCopy } = useConvertRuleDefineCsvNoHeaderPane();
  const { isError, tableRef, errorMessage } = useConvertRuleScrollError('no_header');

  const renderDefine = (value: ConvertRuleItem[], record: ConvertRuleItemWithKey, index: number) => {
    return (
      <div
        css={css`
          display: flex;
          flex-wrap: wrap;
        `}
      >
        <ConvertItemTag<ConvertRuleItem, ConvertRuleItem['name']> list={value} itemKey="name" />
      </div>
    );
  };

  const renderEdit = (value: number, record: ConvertRuleItemWithKey, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to edit this row?"
        onConfirm={() => onEdit(record, index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ConvertRuleItemWithKey, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to delete this row?"
        onConfirm={() => onDelete(index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const expandedRowRender = (record: ConvertRuleItemWithKey, index: number, indent: number, expanded: boolean) => {
    return <CsvInfoDetail record={record} />;
  };

  const columns: ColumnsType<ConvertRuleItemWithKey> = [
    {
      key: 'key',
      title: <TableColumnTitle>Total Columns</TableColumnTitle>,
      dataIndex: 'key',
      align: 'center',
      width: getPixelPercent(1326, 120),
      render: (value, record, index) => <div>{record.rule.length ?? 0}</div>,
    },

    {
      key: 'rule',
      title: <TableColumnTitle>Header Defines</TableColumnTitle>,
      dataIndex: 'rule',
      align: 'center',
      width: getPixelPercent(1326, 1032),
      render: renderDefine,
      className: 'defines',
    },
    Table.EXPAND_COLUMN,
    {
      key: 'edit',
      title: <TableColumnTitle>Edit</TableColumnTitle>,
      dataIndex: 'row',
      align: 'center',
      width: getPixelPercent(1326, 70),
      render: renderEdit,
    },
    {
      key: 'delete',
      title: <TableColumnTitle>Delete</TableColumnTitle>,
      dataIndex: 'row',
      align: 'center',
      width: getPixelPercent(1326, 70),
      render: renderDelete,
    },
  ];

  const renderTitle = () => (
    <TableHeader
      title={
        isError ? (
          <ConvertTableErrorTitle isError={isError} errorMessage={errorMessage} />
        ) : (
          <Space>
            <BulbOutlined />
            If there is NO HEADER(no #information) in this LOG, please input it.
          </Space>
        )
      }
    >
      <AntdButton icon={<CopyOutlined />} onClick={() => onCopy()} disabled={!isCopy}>
        Copy
      </AntdButton>
      <AntdButton icon={<PlusOutlined />} onClick={() => onAdd()}>
        Add
      </AntdButton>
      <Popconfirm
        title="Are you sure to delete all no header?"
        onConfirm={() => onDeleteAll()}
        okText="Delete"
        cancelText="Cancel"
        disabled={noHeaderData.length === 0}
      >
        <AntdButton icon={<DeleteOutlined />} disabled={noHeaderData.length === 0} />
      </Popconfirm>
    </TableHeader>
  );

  return (
    <Table<ConvertRuleItemWithKey>
      rowKey={(record, index) => record.uuid as string}
      dataSource={noHeaderData}
      columns={columns}
      bordered
      size="small"
      tableLayout="fixed"
      pagination={{
        position: ['bottomCenter'],
      }}
      expandable={{ expandedRowRender }}
      title={renderTitle}
      css={[
        css`
          .ant-table {
            .defines {
              border-right-width: 0px !important;
            }
          }
        `,
        convertTableErrorStyle(isError),
      ]}
      sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      ref={tableRef}
    />
  );
}

interface CsvInfoDetailProps {
  record: ConvertRuleItemWithKey;
}

function CsvInfoDetail({ record }: CsvInfoDetailProps) {
  return (
    <div
      css={css`
        display: flex;
        width: inherit;
      `}
    >
      <Table<ConvertRuleItem>
        rowKey={(record, index) => index as number}
        dataSource={record.rule}
        bordered
        size="small"
        tableLayout="fixed"
        pagination={false}
        css={css`
          margin-left: 4.35rem;
          margin-top: 0.5rem;
          margin-bottom: 0.5rem;
          .ant-table {
            width: 66.75rem;
          }
        `}
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<ConvertRuleItem>
          {...detailColumnProps.no}
          render={(value, record, index) => <div>{index + 1}</div>}
        />
        <Table.Column<ConvertRuleItem> {...detailColumnProps.name} />
        <Table.Column<ConvertRuleItem> {...detailColumnProps.output_column} />
        <Table.Column<ConvertRuleItem> {...detailColumnProps.data_type} />
        <Table.Column<ConvertRuleItem> {...detailColumnProps.def_val} />
        <Table.Column<ConvertRuleItem> {...detailColumnProps.coef} />
        <Table.Column<ConvertRuleItem> {...detailColumnProps.unit} />
      </Table>
    </div>
  );
}

type DetailColumnName = 'no' | 'name' | 'output_column' | 'data_type' | 'def_val' | 'coef' | 'unit';

const detailColumnProps: TableColumnPropsType<ConvertRuleItem, DetailColumnName> = {
  no: {
    key: 'no',
    title: <TableColumnTitle>No</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1068, 80),
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    width: getPixelPercent(1068, 220),
  },
  output_column: {
    key: 'output_column',
    title: <TableColumnTitle>Output Column</TableColumnTitle>,
    dataIndex: 'output_column',
    align: 'center',
    width: getPixelPercent(1068, 220),
  },
  data_type: {
    key: 'data_type',
    title: <TableColumnTitle>Data Type</TableColumnTitle>,
    dataIndex: 'data_type',
    align: 'center',
    width: getPixelPercent(1068, 108),
  },
  def_val: {
    key: 'def_val',
    title: <TableColumnTitle>Default Value</TableColumnTitle>,
    dataIndex: 'def_val',
    align: 'center',
    width: getPixelPercent(1068, 220),
  },
  coef: {
    key: 'coef',
    title: <TableColumnTitle>Coefficient</TableColumnTitle>,
    dataIndex: 'coef',
    align: 'center',
    width: getPixelPercent(1068, 110),
  },
  unit: {
    key: 'unit',
    title: <TableColumnTitle>Unit</TableColumnTitle>,
    dataIndex: 'unit',
    align: 'center',
    width: getPixelPercent(1068, 110),
  },
};
