import { InboxOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { Upload } from 'antd';
import { Fragment } from 'react';
import ConvertRulePreview from './ConvertRulePreview';
import useConvertRuleSampleLog from './hooks/useConvertRuleSampleLog';

export default function ConvertRuleSampleLog() {
  const { uploadProps, inputType } = useConvertRuleSampleLog();

  return (
    <Fragment>
      <div css={style}>
        <div className="wrapper">
          <div className="title">1. Select Sample Log</div>
          <div className="content">
            <Upload.Dragger {...uploadProps}>
              <div>
                <p className="ant-upload-drag-icon">
                  <InboxOutlined />
                </p>
                <p className="ant-upload-text">Click or drag file to this area to upload.</p>
              </div>
            </Upload.Dragger>
          </div>
        </div>
        <ConvertRulePreview inputType={inputType} previewType="sample" />
      </div>
    </Fragment>
  );
}

const style = css`
  padding: 2rem 0.5rem 0.5rem 0.5rem;
  display: flex;
  align-items: center;
  flex-direction: column;

  .wrapper {
    display: flex;
    flex-direction: column;
    margin-bottom: 1rem;
    background-color: #f0f5ff;
    width: 30rem;
    margin-bottom: 3rem;

    padding: 1rem;
    .title {
      color: #1890ff;
      font-size: 1rem;
      margin-bottom: 0.5rem;
    }
    .content {
      padding-left: 2rem;
      .ant-upload {
        .ant-upload-text {
          font-size: 0.875rem;
        }
      }
    }
  }
`;
