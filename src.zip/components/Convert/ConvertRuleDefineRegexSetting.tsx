import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import TableScrollTitle from '@components/common/atoms/TableScrollTitle';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { ConvertRuleItem } from '@typesdef/convertRules';
import { Popconfirm, Select, Table } from 'antd';
import { useRef } from 'react';
import { ConvertTableErrorTitle } from './ConvertCommon';
import useConvertRuleDefineRegexSetting from './hooks/useConvertRuleDefineRegexSetting';
import useConvertRuleScrollError from './hooks/useConvertRuleScrollError';
import { convertTableErrorStyle } from './styles/convertCommon';

export default function ConvertRuleDefineRegexSetting() {
  const { headerData, viewMode, onChangeViewMode, onAdd, onEdit, onDelete, onDeleteAll } =
    useConvertRuleDefineRegexSetting();
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const { isError, tableRef, errorMessage } = useConvertRuleScrollError('header');

  const renderTitle = () => (
    <TableHeader
      title={<ConvertTableErrorTitle isError={isError} errorMessage={errorMessage} />}
      cssStyle={css`
        .ant-select {
          .ant-select-selector {
            width: 5.5rem;
          }
        }
      `}
    >
      <Select onChange={onChangeViewMode} value={viewMode}>
        <Select.Option key="simple" value="simple">
          Simple
        </Select.Option>
        <Select.Option key="detail" value="detail">
          Detail
        </Select.Option>
      </Select>
      <AntdButton icon={<PlusOutlined />} onClick={onAdd}>
        Add
      </AntdButton>
      <Popconfirm
        title="Are you sure to delete all regex?"
        onConfirm={() => onDeleteAll()}
        okText="Delete"
        cancelText="Cancel"
        disabled={headerData.length === 0}
      >
        <AntdButton icon={<DeleteOutlined />} disabled={headerData.length === 0} />
      </Popconfirm>
    </TableHeader>
  );

  const renderEdit = (value: number, record: ConvertRuleItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to edit this column?"
        onConfirm={() => onEdit(record, index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ConvertRuleItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to delete this column?"
        onConfirm={() => onDelete(index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div ref={tableRef}>
      {viewMode === 'simple' ? (
        <Table<ConvertRuleItem>
          rowKey={(record, index) => index as number}
          dataSource={headerData}
          bordered
          size="small"
          tableLayout="fixed"
          pagination={false}
          title={renderTitle}
          sticky={{ offsetHeader: NAV_BAR_HIGHT }}
          css={[convertTableErrorStyle(isError)]}
        >
          <Table.Column<ConvertRuleItem>
            {...simpleColumnProps.no}
            render={(value, record, index) => <div>{index + 1}</div>}
          />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.name} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.output_column} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.data_type} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.regex_prefix} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.regex} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.def_val} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.edit} render={renderEdit} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.delete} render={renderDelete} />
        </Table>
      ) : (
        <Table<ConvertRuleItem>
          ref={tableScrollRef}
          rowKey={(record, index) => index as number}
          dataSource={headerData}
          bordered
          size="small"
          tableLayout="fixed"
          pagination={false}
          title={renderTitle}
          scroll={{ x: 'max-content' }}
          sticky={{ offsetHeader: NAV_BAR_HIGHT }}
          css={[convertTableErrorStyle(isError)]}
        >
          <Table.Column<ConvertRuleItem>
            {...detailColumnProps.no}
            render={(value, record, index) => <div>{index + 1}</div>}
            title={<TableScrollTitle title="No" ref={tableScrollRef} direction="left" />}
          />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.name} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.output_column} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.data_type} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.regex_prefix} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.regex} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.group} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.def_val} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.coef} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.unit} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.edit} render={renderEdit} />
          <Table.Column<ConvertRuleItem>
            {...detailColumnProps.delete}
            render={renderDelete}
            title={<TableScrollTitle title="Delete" ref={tableScrollRef} direction="right" />}
          />
        </Table>
      )}
    </div>
  );
}

const style = css`
  display: flex;
  flex-direction: column;
`;

type SimpleColumnName =
  | 'no'
  | 'name'
  | 'output_column'
  | 'data_type'
  | 'regex_prefix'
  | 'regex'
  | 'def_val'
  | 'edit'
  | 'delete';

const simpleColumnProps: TableColumnPropsType<ConvertRuleItem, SimpleColumnName> = {
  no: {
    key: 'no',
    title: <TableColumnTitle>No</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    width: getPixelPercent(1326, 190),
  },
  output_column: {
    key: 'output_column',
    title: <TableColumnTitle>Output Column</TableColumnTitle>,
    dataIndex: 'output_column',
    align: 'center',
    width: getPixelPercent(1326, 190),
  },
  regex_prefix: {
    key: 'regex_prefix',
    title: <TableColumnTitle>Regex Prefix</TableColumnTitle>,
    dataIndex: 'regex_prefix',
    align: 'center',
    width: getPixelPercent(1326, 190),
  },
  regex: {
    key: 'regex',
    title: <TableColumnTitle>Regex</TableColumnTitle>,
    dataIndex: 'regex',
    align: 'center',
    width: getPixelPercent(1326, 226),
  },
  data_type: {
    key: 'data_type',
    title: <TableColumnTitle>Data Type</TableColumnTitle>,
    dataIndex: 'data_type',
    align: 'center',
    width: getPixelPercent(1326, 100),
  },
  def_val: {
    key: 'def_val',
    title: <TableColumnTitle>Default Value</TableColumnTitle>,
    dataIndex: 'def_val',
    align: 'center',
    width: getPixelPercent(1326, 190),
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
};

type DetailColumnName =
  | 'no'
  | 'name'
  | 'output_column'
  | 'data_type'
  | 'regex_prefix'
  | 'regex'
  | 'group'
  | 'def_val'
  | 'coef'
  | 'unit'
  | 'edit'
  | 'delete';

const detailColumnProps: TableColumnPropsType<ConvertRuleItem, DetailColumnName> = {
  no: {
    key: 'no',
    title: <TableColumnTitle>No</TableColumnTitle>,
    align: 'center',
    width: 100,
    fixed: 'left',
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    width: 190,
    fixed: 'left',
  },
  output_column: {
    key: 'output_column',
    title: <TableColumnTitle>Output Column</TableColumnTitle>,
    dataIndex: 'output_column',
    align: 'center',
    width: 190,
  },
  regex_prefix: {
    key: 'regex_prefix',
    title: <TableColumnTitle>Regex Prefix</TableColumnTitle>,
    dataIndex: 'regex_prefix',
    align: 'center',
    width: 190,
  },
  regex: {
    key: 'regex',
    title: <TableColumnTitle>Regex</TableColumnTitle>,
    dataIndex: 'regex',
    align: 'center',
    width: 226,
  },
  group: {
    key: 'group',
    title: <TableColumnTitle>Group</TableColumnTitle>,
    dataIndex: 'group',
    align: 'center',
    width: 100,
  },
  data_type: {
    key: 'data_type',
    title: <TableColumnTitle>Data Type</TableColumnTitle>,
    dataIndex: 'data_type',
    align: 'center',
    width: 100,
  },
  def_val: {
    key: 'def_val',
    title: <TableColumnTitle>Default Value</TableColumnTitle>,
    dataIndex: 'def_val',
    align: 'center',
    width: 190,
  },
  coef: {
    key: 'coef',
    title: <TableColumnTitle>Coefficient</TableColumnTitle>,
    dataIndex: 'coef',
    align: 'center',
    width: 100,
  },
  unit: {
    key: 'unit',
    title: <TableColumnTitle>Unit</TableColumnTitle>,
    dataIndex: 'unit',
    align: 'center',
    width: 100,
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    width: 80,
    fixed: 'right',
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: 100,
    fixed: 'right',
  },
};
