import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { ConvertRuleItem } from '@typesdef/convertRules';
import { Popconfirm, Table } from 'antd';
import { Fragment } from 'react';
import { ConvertTableErrorTitle } from './ConvertCommon';
import useConvertRuleDefineFilterSetting from './hooks/useConvertRuleDefineFilterSetting';
import useConvertRuleScrollError from './hooks/useConvertRuleScrollError';
import { convertTableErrorStyle } from './styles/convertCommon';

export default function ConvertRuleDefineFilterSetting() {
  const { filterData, onAdd, onEdit, onDelete, onDeleteAll, inputType } = useConvertRuleDefineFilterSetting();
  const { isError, tableRef, errorMessage } = useConvertRuleScrollError('filter');

  const renderTitle = () => (
    <TableHeader
      title={<ConvertTableErrorTitle isError={isError} errorMessage={errorMessage} />}
      cssStyle={css`
        .ant-select {
          .ant-select-selector {
            width: 5.5rem;
          }
        }
      `}
    >
      <AntdButton icon={<PlusOutlined />} onClick={onAdd}>
        Add
      </AntdButton>
      <Popconfirm
        title="Are you sure to delete all filter?"
        onConfirm={() => onDeleteAll()}
        okText="Delete"
        cancelText="Cancel"
        disabled={filterData.length === 0}
      >
        <AntdButton icon={<DeleteOutlined />} disabled={filterData.length === 0} />
      </Popconfirm>
    </TableHeader>
  );

  const renderEdit = (value: number, record: ConvertRuleItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to edit this column?"
        onConfirm={() => onEdit(record, index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ConvertRuleItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to delete this column?"
        onConfirm={() => onDelete(index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div ref={tableRef}>
      <Table<ConvertRuleItem>
        rowKey={(record, index) => index as number}
        dataSource={filterData}
        bordered
        size="small"
        tableLayout="fixed"
        pagination={false}
        title={renderTitle}
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
        css={[convertTableErrorStyle(isError)]}
      >
        {inputType === 'status' ? (
          <Fragment>
            <Table.Column<ConvertRuleItem>
              {...eventColumnProps.no}
              render={(value, record, index) => <div>{index + 1}</div>}
            />
            <Table.Column<ConvertRuleItem> {...eventColumnProps.name} />
            <Table.Column<ConvertRuleItem> {...eventColumnProps.start_state} />
            <Table.Column<ConvertRuleItem> {...eventColumnProps.end_state} />
            <Table.Column<ConvertRuleItem> {...eventColumnProps.edit} render={renderEdit} />
            <Table.Column<ConvertRuleItem> {...eventColumnProps.delete} render={renderDelete} />
          </Fragment>
        ) : (
          <Fragment>
            <Table.Column<ConvertRuleItem>
              {...filterColumnProps.no}
              render={(value, record, index) => <div>{index + 1}</div>}
            />
            <Table.Column<ConvertRuleItem> {...filterColumnProps.name} />
            <Table.Column<ConvertRuleItem> {...filterColumnProps.def_type} />
            <Table.Column<ConvertRuleItem> {...filterColumnProps.def_val} />
            <Table.Column<ConvertRuleItem> {...filterColumnProps.edit} render={renderEdit} />
            <Table.Column<ConvertRuleItem> {...filterColumnProps.delete} render={renderDelete} />
          </Fragment>
        )}
      </Table>
    </div>
  );
}

type FilterColumnName = 'no' | 'name' | 'def_type' | 'def_val' | 'edit' | 'delete';

const filterColumnProps: TableColumnPropsType<ConvertRuleItem, FilterColumnName> = {
  no: {
    key: 'no',
    title: <TableColumnTitle>No</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    width: getPixelPercent(1326, 250),
  },
  def_type: {
    key: 'def_type',
    title: <TableColumnTitle>Type</TableColumnTitle>,
    dataIndex: 'def_type',
    align: 'center',
    width: getPixelPercent(1326, 160),
  },
  def_val: {
    key: 'def_val',
    title: <TableColumnTitle>Condition</TableColumnTitle>,
    dataIndex: 'def_val',
    align: 'center',
    width: getPixelPercent(1326, 676),
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
};

type EventColumnName = 'no' | 'name' | 'start_state' | 'end_state' | 'edit' | 'delete';

const eventColumnProps: TableColumnPropsType<ConvertRuleItem, EventColumnName> = {
  no: {
    key: 'no',
    title: <TableColumnTitle>No</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    width: getPixelPercent(1326, 250),
  },
  start_state: {
    key: 'start_state',
    title: <TableColumnTitle>Start State</TableColumnTitle>,
    dataIndex: 'start_state',
    align: 'center',
    width: getPixelPercent(1326, 418),
  },
  end_state: {
    key: 'end_state',
    title: <TableColumnTitle>End State</TableColumnTitle>,
    dataIndex: 'end_state',
    align: 'center',
    width: getPixelPercent(1326, 418),
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
};
