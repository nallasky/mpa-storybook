import { grey } from '@ant-design/colors';
import { css } from '@emotion/react';
import { TypeConvertRule } from '@typesdef/convertRules';
import { Badge, Space } from 'antd';
import { useSearchParams } from 'react-router-dom';
import ConvertRuleDefineCsvHeader from './ConvertRuleDefineCsvHeader';
import ConvertRuleDefineCsvInfo from './ConvertRuleDefineCsvInfo';
import ConvertRuleDefineCsvSelect from './ConvertRuleDefineCsvSelect';
import ConvertRuleDefineCustom from './ConvertRuleDefineCustom';
import ConvertRulePreview from './ConvertRulePreview';

export default function ConvertRuleDefineCsv() {
  const [searchParams] = useSearchParams();
  const inputType = searchParams.get('inputType') as TypeConvertRule;

  return (
    <div css={csvStyle}>
      <div className="box">
        <div className="title">Select Info and Header</div>
        <div className="content">
          <ConvertRuleDefineCsvSelect />
        </div>
      </div>
      <div className="box">
        <div className="title">Header / Column Define</div>
        <div className="content">
          <div className="sub-content">
            <div className="sub-title">
              <Space size={2}>
                <Badge color="blue" />
                Info
              </Space>
            </div>
            <ConvertRuleDefineCsvInfo />
          </div>
          <div className="sub-content">
            <div className="sub-title">
              <Space size={2}>
                <Badge color="blue" />
                Header
              </Space>
            </div>
            <ConvertRuleDefineCsvHeader />
          </div>
          <div className="sub-content">
            <div className="sub-title">
              <Space size={2}>
                <Badge color="blue" />
                Custom
              </Space>
            </div>
            <ConvertRuleDefineCustom />
          </div>
        </div>
      </div>
      <ConvertRulePreview inputType={inputType} previewType="convert" />
    </div>
  );
}

export const csvStyle = css`
  display: flex;
  justify-content: center;
  flex-direction: column;
  margin-top: 1rem;
  /* padding: 0.5rem 0.5rem 0.5rem 0.5rem; */

  .box:nth-of-type(n + 1) {
    margin-bottom: 2rem;
  }

  .sub-content:nth-of-type(n + 1) {
    margin-bottom: 2rem;
  }

  .box {
    border: 1px solid ${grey[0]};
    border-radius: 3px;
    .title {
      display: flex;
      align-items: center;
      position: absolute;
      margin-top: -12px;
      margin-left: 1rem;
      padding-left: 1rem;
      padding-right: 16px;
      font-weight: 700;
      background-color: white;
    }
    .sub-title {
      font-weight: 700;
      margin-bottom: 0.5rem;
      color: ${grey[5]};
    }
    .content {
      margin-top: 1rem;
      margin-bottom: 1rem;
      margin: 1rem 1rem 1rem 1rem;
      & table {
        font-size: 0.75rem;
        &:first-of-type > thead > tr > th {
          background: #f0f5ff;
          font-weight: 700;
        }
      }
    }
  }
`;
