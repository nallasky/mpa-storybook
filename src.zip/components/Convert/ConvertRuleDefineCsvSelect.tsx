import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { Checkbox, Empty, Table } from 'antd';
import useConvertRuleDefineCsvSelect from './hooks/useConvertRuleDefineCsvSelect';

export default function ConvertRuleDefineCsvSelect() {
  const { sample, selectInfo, selectHeader, onCheckInfo, onCheckHeader } = useConvertRuleDefineCsvSelect();

  if (sample.header.length === 0 && sample.data.length === 0) {
    return (
      <div
        css={css`
          min-height: 10rem;
          display: flex;
          justify-content: center;
          align-items: center;
        `}
      >
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
      </div>
    );
  }

  return (
    <div>
      <Table<Record<string, string | null>>
        rowKey={(record, index) => index as number}
        dataSource={sample.data ?? []}
        bordered
        size="small"
        scroll={{ x: 'max-content' }}
        pagination={false}
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<Record<string, string | null>>
          key="info"
          title="Info"
          align="center"
          render={(data, record, index) => (
            <Checkbox
              checked={selectInfo.includes(index + 1)}
              onChange={({ target: { checked } }) =>
                onCheckInfo({
                  index,
                  row: index + 1,
                  checked,
                  data: record,
                })
              }
            />
          )}
          width={60}
        />
        <Table.Column<Record<string, string | null>>
          key="header"
          title="Header"
          align="center"
          render={(data, record, index) => (
            <Checkbox
              checked={selectHeader.includes(index + 1)}
              onChange={({ target: { checked } }) =>
                onCheckHeader({
                  index,
                  row: index + 1,
                  checked,
                  data: record,
                })
              }
            />
          )}
          width={60}
        />
        {sample.header.map((item) => (
          <Table.Column<Record<string, string | null>>
            key={item}
            dataIndex={item}
            title={item}
            align="center"
            render={(record) => (
              <div
                css={css`
                  min-width: 100px;
                `}
              >
                {record}
              </div>
            )}
          />
        ))}
      </Table>
    </div>
  );
}
