import { grey } from '@ant-design/colors';
import { ReadFilled } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { ConvertPreviewTable, TypeConvertRule, TypeConvertRulePreview } from '@typesdef/convertRules';
import { Empty, Table } from 'antd';
import useConvertRulePreview from './hooks/useConvertRulePreview';

interface ConvertRulePreviewProps {
  inputType: TypeConvertRule;
  previewType: TypeConvertRulePreview;
}

export default function ConvertRulePreview({ inputType, previewType }: ConvertRulePreviewProps) {
  const { previewTableData, requestPreview, isLoading, disabled } = useConvertRulePreview({
    inputType,
    previewType,
  });

  return (
    <div css={style}>
      <div className="title">
        <div className="name">Preview</div>
        <AntdButton
          icon={<ReadFilled />}
          type="primary"
          onClick={requestPreview}
          disabled={isLoading || disabled}
          loading={isLoading}
        >
          Preview
        </AntdButton>
      </div>
      <div className="context">
        {previewType === 'sample' && inputType === 'regex' ? (
          <ConvertRulePreviewText tableData={previewTableData} />
        ) : (
          <ConvertRulePreviewTable isLoading={isLoading} tableData={previewTableData} />
        )}
      </div>
    </div>
  );
}

const style = css`
  width: 100%;
  display: flex;
  flex-direction: column;
  border-radius: 3px;
  border: 1px solid ${grey[0]};
  .title {
    border-bottom: 1px solid ${grey[0]};
    padding-left: 1rem;
    padding-right: 1rem;
    display: flex;
    align-items: center;
    flex-direction: row;
    justify-content: space-between;
    height: 3rem;
    .name {
      font-weight: 700;
    }
  }
  .context {
    margin: 1rem;
  }
`;

interface ConvertRulePreviewDataProps {
  isLoading?: boolean;
  tableData: ConvertPreviewTable | null;
}

const emptyStyle = css`
  min-height: 10rem;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export function ConvertRulePreviewText({ tableData }: ConvertRulePreviewDataProps) {
  if (!tableData || !tableData.text) {
    return (
      <div css={emptyStyle}>
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
      </div>
    );
  }

  return (
    <pre
      css={css`
        margin-left: 1rem;
        margin-right: 1rem;
        max-height: 20rem;
      `}
    >
      {tableData?.text}
    </pre>
  );
}

export function ConvertRulePreviewTable({ isLoading = false, tableData }: ConvertRulePreviewDataProps) {
  if (!tableData || !tableData.header || tableData.header.length === 0) {
    return (
      <div css={emptyStyle}>
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
      </div>
    );
  }

  const isData = tableData.data && tableData.data.length > 0;

  return (
    <Table
      rowKey={(record, index) => index as number}
      dataSource={isData ? tableData.data : [{ '1': '' }]}
      bordered
      size="small"
      scroll={{ x: 'max-content' }}
      pagination={false}
      loading={isLoading}
      css={css`
        & table {
          font-size: 0.75rem;
          &:first-of-type > thead > tr > th {
            background: #f0f5ff;
            font-weight: 700;
          }
          /* .preview-data {
            min-width: 6.25rem;
          } */
        }
      `}
      sticky={{ offsetHeader: NAV_BAR_HIGHT }}
    >
      {tableData.header.map((item) => (
        <Table.Column<Record<string, string | null>>
          key={item}
          dataIndex={item}
          title={item}
          align="center"
          render={(record) => (
            <div
              css={css`
                min-width: 100px;
              `}
            >
              {record}
            </div>
          )}
        />
      ))}
    </Table>
  );
}
