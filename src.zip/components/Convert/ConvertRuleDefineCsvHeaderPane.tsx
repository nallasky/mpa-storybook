import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { ConvertRuleItem } from '@typesdef/convertRules';
import { Popconfirm, Select, Table } from 'antd';
import { ConvertTableErrorTitle } from './ConvertCommon';
import useConvertRuleDefineCsvHeaderPane from './hooks/useConvertRuleDefineCsvHeaderPane';
import useConvertRuleScrollError from './hooks/useConvertRuleScrollError';
import { convertTableErrorStyle } from './styles/convertCommon';

export default function ConvertRuleDefineCsvHeaderPane() {
  const { headerData, viewMode, onChangeViewMode, onAdd, onEdit, onDelete, onDeleteAll } =
    useConvertRuleDefineCsvHeaderPane();
  const { isError, tableRef, errorMessage } = useConvertRuleScrollError('header');

  const renderTitle = () => (
    <TableHeader
      title={<ConvertTableErrorTitle isError={isError} errorMessage={errorMessage} />}
      cssStyle={css`
        .ant-select {
          .ant-select-selector {
            width: 5.5rem;
          }
        }
      `}
    >
      <Select onChange={onChangeViewMode} value={viewMode}>
        <Select.Option key="simple" value="simple">
          Simple
        </Select.Option>
        <Select.Option key="detail" value="detail">
          Detail
        </Select.Option>
      </Select>

      <AntdButton icon={<PlusOutlined />} onClick={onAdd}>
        Add
      </AntdButton>
      <Popconfirm
        title="Are you sure to delete all header?"
        onConfirm={() => onDeleteAll()}
        okText="Delete"
        cancelText="Cancel"
        disabled={headerData.length === 0}
      >
        <AntdButton icon={<DeleteOutlined />} disabled={headerData.length === 0} />
      </Popconfirm>
    </TableHeader>
  );

  const renderEdit = (value: number, record: ConvertRuleItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to edit this column?"
        onConfirm={() => onEdit(record, index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ConvertRuleItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to delete this column?"
        onConfirm={() => onDelete(index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div ref={tableRef}>
      {viewMode === 'simple' ? (
        <Table<ConvertRuleItem>
          rowKey={(record, index) => index as number}
          dataSource={headerData}
          bordered
          size="small"
          tableLayout="fixed"
          pagination={false}
          title={renderTitle}
          sticky={{ offsetHeader: NAV_BAR_HIGHT }}
          css={[convertTableErrorStyle(isError)]}
        >
          <Table.Column<ConvertRuleItem>
            {...simpleColumnProps.no}
            render={(value, record, index) => <div>{index + 1}</div>}
          />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.data} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.name} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.output_column} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.data_type} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.def_val} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.edit} render={renderEdit} />
          <Table.Column<ConvertRuleItem> {...simpleColumnProps.delete} render={renderDelete} />
        </Table>
      ) : (
        <Table<ConvertRuleItem>
          rowKey={(record, index) => index as number}
          dataSource={headerData}
          bordered
          size="small"
          tableLayout="fixed"
          pagination={false}
          title={renderTitle}
          sticky={{ offsetHeader: NAV_BAR_HIGHT }}
          css={[convertTableErrorStyle(isError)]}
        >
          <Table.Column<ConvertRuleItem>
            {...detailColumnProps.no}
            render={(value, record, index) => <div>{index + 1}</div>}
          />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.data} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.name} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.output_column} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.data_type} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.def_val} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.coef} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.unit} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.edit} render={renderEdit} />
          <Table.Column<ConvertRuleItem> {...detailColumnProps.delete} render={renderDelete} />
        </Table>
      )}
    </div>
  );
}

const style = css`
  display: flex;
  flex-direction: column;
`;

type SimpleColumnName = 'no' | 'name' | 'data' | 'output_column' | 'data_type' | 'def_val' | 'edit' | 'delete';

const simpleColumnProps: TableColumnPropsType<ConvertRuleItem, SimpleColumnName> = {
  no: {
    key: 'no',
    title: <TableColumnTitle>No</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    width: getPixelPercent(1326, 235),
  },
  data: {
    key: 'data',
    title: <TableColumnTitle>Data</TableColumnTitle>,
    dataIndex: 'data',
    align: 'center',
    width: getPixelPercent(1326, 235),
  },
  output_column: {
    key: 'output_column',
    title: <TableColumnTitle>Output Column</TableColumnTitle>,
    dataIndex: 'output_column',
    align: 'center',
    width: getPixelPercent(1326, 235),
  },
  data_type: {
    key: 'data_type',
    title: <TableColumnTitle>Data Type</TableColumnTitle>,
    dataIndex: 'data_type',
    align: 'center',
    width: getPixelPercent(1326, 146),
  },
  def_val: {
    key: 'def_val',
    title: <TableColumnTitle>Default Value</TableColumnTitle>,
    dataIndex: 'def_val',
    align: 'center',
    width: getPixelPercent(1326, 235),
  },

  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
};

type DetailColumnName =
  | 'no'
  | 'name'
  | 'data'
  | 'output_column'
  | 'data_type'
  | 'def_val'
  | 'coef'
  | 'unit'
  | 'edit'
  | 'delete';

const detailColumnProps: TableColumnPropsType<ConvertRuleItem, DetailColumnName> = {
  no: {
    key: 'no',
    title: <TableColumnTitle>No</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    width: getPixelPercent(1326, 195),
  },
  data: {
    key: 'data',
    title: <TableColumnTitle>Data</TableColumnTitle>,
    dataIndex: 'data',
    align: 'center',
    width: getPixelPercent(1326, 195),
  },
  output_column: {
    key: 'output_column',
    title: <TableColumnTitle>Output Column</TableColumnTitle>,
    dataIndex: 'output_column',
    align: 'center',
    width: getPixelPercent(1326, 195),
  },
  data_type: {
    key: 'data_type',
    title: <TableColumnTitle>Data Type</TableColumnTitle>,
    dataIndex: 'data_type',
    align: 'center',
    width: getPixelPercent(1326, 106),
  },
  def_val: {
    key: 'def_val',
    title: <TableColumnTitle>Default Value</TableColumnTitle>,
    dataIndex: 'def_val',
    align: 'center',
    width: getPixelPercent(1326, 195),
  },
  coef: {
    key: 'coef',
    title: <TableColumnTitle>Coefficient</TableColumnTitle>,
    dataIndex: 'coef',
    align: 'center',
    width: getPixelPercent(1326, 100),
  },
  unit: {
    key: 'unit',
    title: <TableColumnTitle>Unit</TableColumnTitle>,
    dataIndex: 'unit',
    align: 'center',
    width: getPixelPercent(1326, 100),
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
};
