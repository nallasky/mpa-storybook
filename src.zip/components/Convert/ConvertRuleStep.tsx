import SideSteps from '@components/common/atoms/SideSteps';
import StepButton from '@components/common/atoms/StepButton';
import { css } from '@emotion/react';
import { Divider, PageHeader } from 'antd';
import { convertRuleStep, CONVERT_RULE_STEP } from './ConvertRule';
import useConvertRuleStep from './hooks/useConvertRuleStep';

export default function ConvertRuleStep() {
  const { current, onNext, onPrev, onLast, logName, modeName, nextAction, onBack, isLoading } = useConvertRuleStep();

  return (
    <div>
      <PageHeader
        onBack={onBack}
        title={`${modeName} Convert Rule (${logName})`}
        css={css`
          padding: 0 0 0.5rem 0;
        `}
      />
      <Divider css={dividerStyle('top')} />
      <SideSteps current={current[0]} stepList={convertRuleStep} direction="horizontal" />
      <Divider css={dividerStyle('bottom')} />
      <StepButton
        current={current[0]}
        onNext={onNext}
        onPrev={onPrev}
        lastStep={CONVERT_RULE_STEP.DEFILE_FILTER}
        onLast={onLast}
        nextActionPromise={nextAction}
        type={modeName === 'Edit' ? 'edit' : 'add'}
        title={convertRuleStep[current[0]]}
        disabled={isLoading}
      />
    </div>
  );
}

const dividerStyle = (position: 'top' | 'bottom') => css`
  border: 2px solid #8c8c8c;
  margin-top: ${position === 'top' && 0};
`;
