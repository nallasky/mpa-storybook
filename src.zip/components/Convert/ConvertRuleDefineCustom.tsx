import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { ConvertRuleItem } from '@typesdef/convertRules';
import { Popconfirm, Table } from 'antd';
import { ConvertTableErrorTitle } from './ConvertCommon';
import useConvertRuleDefineCustom from './hooks/useConvertRuleDefineCustom';
import useConvertRuleScrollError from './hooks/useConvertRuleScrollError';
import { convertTableErrorStyle } from './styles/convertCommon';

export default function ConvertRuleDefineCustom() {
  const { customData, onAdd, onEdit, onDelete, onDeleteAll } = useConvertRuleDefineCustom();
  const { isError, tableRef, errorMessage } = useConvertRuleScrollError('custom');

  const renderTitle = () => (
    <TableHeader
      title={<ConvertTableErrorTitle isError={isError} errorMessage={errorMessage} />}
      cssStyle={css`
        .ant-select {
          .ant-select-selector {
            width: 5.5rem;
          }
        }
      `}
    >
      <AntdButton icon={<PlusOutlined />} onClick={onAdd}>
        Add
      </AntdButton>
      <Popconfirm
        title="Are you sure to delete all custom?"
        onConfirm={() => onDeleteAll()}
        okText="Delete"
        cancelText="Cancel"
        disabled={customData.length === 0}
      >
        <AntdButton icon={<DeleteOutlined />} disabled={customData.length === 0} />
      </Popconfirm>
    </TableHeader>
  );

  const renderEdit = (value: number, record: ConvertRuleItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to edit this column?"
        onConfirm={() => onEdit(record, index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ConvertRuleItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to delete this column?"
        onConfirm={() => onDelete(index)}
        okText="Ok"
        cancelText="Cancel"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div ref={tableRef}>
      <Table<ConvertRuleItem>
        rowKey={(record, index) => record.index as number}
        dataSource={customData}
        bordered
        size="small"
        tableLayout="fixed"
        pagination={false}
        title={renderTitle}
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
        css={[convertTableErrorStyle(isError)]}
      >
        <Table.Column<ConvertRuleItem> {...columnProps.no} render={(value, record, index) => <div>{index + 1}</div>} />
        <Table.Column<ConvertRuleItem> {...columnProps.name} />
        <Table.Column<ConvertRuleItem> {...columnProps.output_column} />
        <Table.Column<ConvertRuleItem> {...columnProps.data_type} />
        <Table.Column<ConvertRuleItem> {...columnProps.def_val} />
        <Table.Column<ConvertRuleItem> {...columnProps.edit} render={renderEdit} />
        <Table.Column<ConvertRuleItem> {...columnProps.delete} render={renderDelete} />
      </Table>
    </div>
  );
}

type ColumnName = 'no' | 'name' | 'output_column' | 'data_type' | 'def_val' | 'edit' | 'delete';

const columnProps: TableColumnPropsType<ConvertRuleItem, ColumnName> = {
  no: {
    key: 'no',
    title: <TableColumnTitle>No</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    width: getPixelPercent(1326, 290),
  },

  output_column: {
    key: 'output_column',
    title: <TableColumnTitle>Output Column</TableColumnTitle>,
    dataIndex: 'output_column',
    align: 'center',
    width: getPixelPercent(1326, 290),
  },
  data_type: {
    key: 'data_type',
    title: <TableColumnTitle>Data Type</TableColumnTitle>,
    dataIndex: 'data_type',
    align: 'center',
    width: getPixelPercent(1326, 216),
  },
  def_val: {
    key: 'def_val',
    title: <TableColumnTitle>Default Value</TableColumnTitle>,
    dataIndex: 'def_val',
    align: 'center',
    width: getPixelPercent(1326, 290),
  },

  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1326, 80),
  },
};
