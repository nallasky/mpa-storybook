import {
  DeleteOutlined,
  EditOutlined,
  ExportOutlined,
  ImportOutlined,
  PlusOutlined,
  SearchOutlined,
} from '@ant-design/icons';
import { undraw_create } from '@assets/images';
import AntdButton from '@components/common/atoms/AntdButton';
import CustomIcon from '@components/common/atoms/CustomIcon';
import { V_SPACE } from '@components/common/atoms/Space';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { ContentWrapper } from '@components/common/atoms/Wrapper';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { errorIconHoverActionStyle, hoverActiveStyle, hoverStyle, tableRowErrorStyle } from '@styles/emotion/common';
import { AntdTableRowClassName } from '@typesdef/antd';
import { CustomPagination, TableColumnPropsType } from '@typesdef/common';
import { ConvertLogItem, TypeConvertRule } from '@typesdef/convertRules';
import { Input, Popconfirm, Select, Space, Table, TableProps, Tooltip } from 'antd';
import { memo } from 'react';
import { convertRuleInputTypeSearchOptions, convertRuleNoEditInputType, getConvertRuleInputTypeText } from './common';
import { isNoDeleteLog } from './ConvertCommon';
import useConvert from './hooks/useConvert';

export default function Convert() {
  const {
    list,
    isFetchingList,
    hasCrasServer,
    pagination,
    hasSearchParam,
    onChangeTable,
    getCompanyFabName,
    onAdd,
    onEdit,
    onDelete,
    onExport,
    onImport,
    onClickRule,
    onErrorView,
    searchRedux,
    keyword,
    setKeyword,
    onSelectType,
  } = useConvert();

  return (
    <ContentWrapper>
      <TableHeader
        title={<TableHeaderTitle total={pagination.total} isSearched={hasSearchParam} color="green" />}
        isSeparated
      >
        <Input
          value={keyword}
          onChange={({ target: { value } }) => setKeyword(value)}
          allowClear
          addonAfter={<SearchOutlined />}
          placeholder="Log Name"
          css={searchKeywordStyle}
          disabled={!hasCrasServer}
        />
        <Select
          onSelect={onSelectType}
          value={searchRedux.type}
          css={searchTypeStyle}
          disabled={!hasCrasServer}
          options={convertRuleInputTypeSearchOptions}
        />

        <AntdButton icon={<PlusOutlined />} type="primary" onClick={() => onAdd()} disabled={!hasCrasServer}>
          Add
        </AntdButton>
        <AntdButton icon={<ImportOutlined />} type="primary" onClick={() => onImport()} disabled={!hasCrasServer}>
          Import
        </AntdButton>
        <AntdButton icon={<ExportOutlined />} type="primary" onClick={() => onExport()} disabled={!hasCrasServer}>
          Export
        </AntdButton>
      </TableHeader>
      {hasCrasServer ? (
        <ConvertLogTable
          onErrorView={onErrorView}
          getCompanyFabName={getCompanyFabName}
          onEdit={onEdit}
          onClickRule={onClickRule}
          onDelete={onDelete}
          content={list?.content}
          pagination={pagination}
          onChangeTable={onChangeTable}
          loading={isFetchingList}
        />
      ) : (
        <div className="not-registered" css={emptyStyle}>
          <img alt="register " src={undraw_create} />
          <V_SPACE rem={2} />
          <div className="text">Please register at least one Cras Server in Server Config.</div>
        </div>
      )}
    </ContentWrapper>
  );
}

const searchKeywordStyle = css`
  .ant-input-affix-wrapper {
    border-radius: 0.625rem 0 0 0.625rem !important;
  }
  .ant-input-group-addon {
    border-radius: 0 0.625rem 0.625rem 0 !important;
  }
`;

const searchTypeStyle = css`
  width: 10.5rem;
  .ant-select-selector {
    border-radius: 0.625rem !important;
  }
`;

const emptyStyle = css`
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  margin-top: 4rem;
  img {
    width: 40rem;
  }
  .text {
    font-size: 1.6rem;
  }
`;

interface ConvertLogTableProps {
  onErrorView: (logId: number) => void;
  getCompanyFabName: (siteId: number) => string;
  onEdit: (data: ConvertLogItem, id: number) => void;
  onClickRule: (item: ConvertLogItem) => void;
  onDelete: (id: number) => Promise<void>;
  content?: ConvertLogItem[];
  pagination: CustomPagination;
  onChangeTable: NonNullable<TableProps<any>['onChange']>;
  loading?: boolean;
}

const ConvertLogTable = memo(function ConvertLogTable({
  onErrorView,
  getCompanyFabName,
  onEdit,
  onClickRule,
  onDelete,
  content = [],
  pagination,
  onChangeTable,
  loading = false,
}: ConvertLogTableProps) {
  const renderLogName = (value: string, record: ConvertLogItem, index: number) => {
    const { errors, id } = record;

    return (
      <Space>
        <div>{value}</div>
        {errors > 0 && <CustomIcon css={errorIconHoverActionStyle} name="warning" onClick={() => onErrorView(id)} />}
      </Space>
    );
  };

  const renderInputType = (value: TypeConvertRule, record: ConvertLogItem, index: number) => {
    return <div>{getConvertRuleInputTypeText(value)}</div>;
  };

  const renderSelect = (value: number[], record: ConvertLogItem, index: number) => {
    const length = value.length ?? 0;

    return (
      <div css={hoverStyle}>
        <Tooltip
          title={
            value && value.length > 0 ? (
              value.map((item) => <div key={item}>{getCompanyFabName(item)}</div>)
            ) : (
              <div>All User-Fab</div>
            )
          }
          color="cyan"
          placement="right"
        >
          {length === 0 ? 'All' : length}
        </Tooltip>
      </div>
    );
  };

  const renderEdit = (value: number, record: ConvertLogItem, index: number) => {
    return (
      <Popconfirm title="Are you sure to edit Log?" onConfirm={() => onEdit(record, record.id)} okText="Edit">
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderIsRule = (value: boolean, record: ConvertLogItem, index: number) => {
    const action = value ? 'Edit' : 'Add';

    if (convertRuleNoEditInputType.includes(record.input_type)) {
      return <div>-</div>;
    }

    return (
      <Popconfirm
        title={`Are you sure to ${action.toLowerCase()} rule?`}
        onConfirm={() => onClickRule(record)}
        okText={action}
      >
        <div css={hoverActiveStyle}>{value ? 'Registered' : 'Not Registered'}</div>
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: ConvertLogItem, index: number) => {
    const { log_name, table_name } = record;

    if (isNoDeleteLog({ log_name, table_name })) {
      return <div>-</div>;
    }

    return (
      <Popconfirm title="Are you sure to delete Log?" onConfirm={() => onDelete(record.id)} okText="Delete">
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const rowClassName: Exclude<AntdTableRowClassName<ConvertLogItem>, string> = (record) => {
    return record.errors > 0 ? 'error-mark' : '';
  };

  return (
    <Table<ConvertLogItem>
      rowKey={'id'}
      rowClassName={rowClassName}
      dataSource={content}
      bordered
      size="small"
      pagination={{
        position: ['bottomCenter'],
        showSizeChanger: true,
        current: pagination.current,
        pageSize: pagination.pageSize,
        total: pagination.total,
      }}
      onChange={onChangeTable}
      css={[tableRowErrorStyle]}
      tableLayout="fixed"
      sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      loading={loading}
    >
      <Table.Column<ConvertLogItem> {...columnProps.log_name} render={renderLogName} />
      <Table.Column<ConvertLogItem> {...columnProps.input_type} render={renderInputType} />
      {/* not display user-fab name */}
      {/* <Table.Column<ConvertLogItem> {...columnProps.select} render={renderSelect} /> */}
      <Table.Column<ConvertLogItem> {...columnProps.rule} render={renderIsRule} />
      <Table.Column<ConvertLogItem> {...columnProps.edit} render={renderEdit} />
      <Table.Column<ConvertLogItem> {...columnProps.delete} render={renderDelete} />
    </Table>
  );
});

type ColumnName = 'log_name' | 'input_type' | 'select' | 'rule' | 'edit' | 'delete';

const columnProps: TableColumnPropsType<ConvertLogItem, ColumnName> = {
  log_name: {
    key: 'log_name',
    title: <TableColumnTitle>Log Name</TableColumnTitle>,
    dataIndex: 'log_name',
    align: 'center',
    width: getPixelPercent(1360, 690),
    sorter: true,
  },
  input_type: {
    key: 'input_type',
    title: <TableColumnTitle>Input Type</TableColumnTitle>,
    dataIndex: 'input_type',
    align: 'center',
    width: getPixelPercent(1360, 190),
    sorter: true,
  },
  select: {
    key: 'select',
    title: <TableColumnTitle>Selected User-Fab</TableColumnTitle>,
    dataIndex: 'select',
    align: 'center',
    width: getPixelPercent(1360, 170),
  },
  rule: {
    key: 'rule',
    title: <TableColumnTitle>Rule</TableColumnTitle>,
    dataIndex: 'rule',
    align: 'center',
    width: getPixelPercent(1360, 150),
    sorter: true,
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    dataIndex: 'id',
    align: 'center',
    width: getPixelPercent(1360, 80),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    dataIndex: 'id',
    align: 'center',
    width: getPixelPercent(1360, 80),
  },
};
