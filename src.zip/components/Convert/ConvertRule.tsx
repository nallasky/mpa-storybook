import { css } from '@emotion/react';
import UploadFileProvider from '@libs/context/UploadFileProvider';
import { getConvertRuleBaseType } from './common';
import ConvertRuleDefineCsv from './ConvertRuleDefineCsv';
import ConvertRuleDefineFilter from './ConvertRuleDefineFilter';
import ConvertRuleDefineRegex from './ConvertRuleDefineRegex';
import ConvertRuleSampleLog from './ConvertRuleSampleLog';
import ConvertRuleStep from './ConvertRuleStep';
import useConvertRule from './hooks/useConvertRule';

function ConvertRuleWrapper() {
  return (
    <UploadFileProvider>
      <ConvertRule />
    </UploadFileProvider>
  );
}

function ConvertRule() {
  const { current, inputType } = useConvertRule();
  const baseType = getConvertRuleBaseType(inputType);

  return (
    <div css={style}>
      <ConvertRuleStep />
      {current === CONVERT_RULE_STEP.SAMPLE_LOG && <ConvertRuleSampleLog />}
      {current === CONVERT_RULE_STEP.DEFINE_RULE && baseType === 'csv' && <ConvertRuleDefineCsv />}
      {current === CONVERT_RULE_STEP.DEFINE_RULE && baseType === 'regex' && <ConvertRuleDefineRegex />}
      {current === CONVERT_RULE_STEP.DEFILE_FILTER && <ConvertRuleDefineFilter />}
    </div>
  );
}

export default ConvertRuleWrapper;

const style = css`
  width: 100%;
`;

export enum CONVERT_RULE_STEP {
  SAMPLE_LOG = 0,
  DEFINE_RULE,
  DEFILE_FILTER,
}

export const convertRuleStep = ['Select Sample Log', 'Define Rule', 'Define Filter'];
