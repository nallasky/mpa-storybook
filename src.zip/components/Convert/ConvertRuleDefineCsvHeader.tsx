import { css } from '@emotion/react';
import { getConvertRuleHeaderTab, setConvertRuleHeaderTab } from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { Tabs, TabsProps } from 'antd';
import { useDispatch } from 'react-redux';
import ConvertRuleDefineCsvHeaderPane from './ConvertRuleDefineCsvHeaderPane';
import ConvertRuleDefineCsvNoHeaderPane from './ConvertRuleDefineCsvNoHeaderPane';

export default function ConvertRuleDefineCsvHeader() {
  const dispatch = useDispatch();
  const headerTab = useTypedSelector(getConvertRuleHeaderTab);
  const panes: NonNullable<TabsProps['items']> = [
    {
      key: 'header',
      label: 'Header',
      children: <ConvertRuleDefineCsvHeaderPane />,
    },
    {
      key: 'no_header',
      label: 'No Header',
      children: <ConvertRuleDefineCsvNoHeaderPane />,
    },
  ];

  return (
    <div css={style}>
      <Tabs
        items={panes}
        activeKey={headerTab}
        onChange={(key) => {
          dispatch(setConvertRuleHeaderTab(key as 'header' | 'no_header'));
        }}
      />
    </div>
  );
}

const style = css`
  display: flex;
  flex-direction: column;
`;
