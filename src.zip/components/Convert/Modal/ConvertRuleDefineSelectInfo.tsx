import { DeleteOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { ConvertRuleSelectItem } from '@typesdef/convertRules';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Button, Modal, Popconfirm, Space, Table } from 'antd';
import React from 'react';
import {
  convertDefTypePreset,
  ConvertSelectCustom,
  ConvertSelectNotFound,
  ConvertTableInput,
  ConvertTableSelect,
} from '../ConvertCommon';
import useConvertRuleDefineSelectInfo, {
  ConvertRuleSelectItemErrorState,
} from '../hooks/useConvertRuleDefineSelectInfo';

export interface ConvertRuleDefineSelectInfoProps {
  row: number;
  data: Record<string, string | null>;
}

// TODO: 2022_phase4: 에러 체크하기 위하여 Form으로 변경해야 할듯....
export default React.memo(function ConvertRuleDefineSelectInfo({
  visible,
  onClose,
  row,
  data,
}: GlobalModalDefaultProps<ConvertRuleDefineSelectInfoProps>): JSX.Element {
  const {
    info,
    onChangeValue,
    onDeleteRow,
    onOk,
    dataTypeOptions,
    defTypeOptions,
    defineOptions,
    searchInput,
    onSearchDefine,
    onFocusDefine,
    onBlurDefine,
    onClickDefineOther,
    isFetchingDefine,
    tableRef,
    occurredError,
  } = useConvertRuleDefineSelectInfo({
    row,
    data,
    onClose,
  });

  const renderNo = (value: undefined, record: ConvertRuleSelectItem, index: number) => {
    return <div>{index + 1}</div>;
  };

  const renderDefine = (value: string, record: ConvertRuleSelectItem, index: number) => {
    const searchValue = searchInput.index && searchInput.index === index ? searchInput.value ?? undefined : undefined;

    return (
      <ConvertTableSelect
        className={`define_${index}`}
        value={record.define}
        onChange={(value) => {
          onChangeValue('define', value, index);
        }}
        options={defineOptions}
        searchValue={searchValue}
        onSearch={(value) => onSearchDefine(value, index)}
        dropdownRender={(menu) => (
          <ConvertSelectCustom menu={menu} itemList={['custom', 'null']} index={index} onClick={onClickDefineOther} />
        )}
        onFocus={() => onFocusDefine(index)}
        onBlur={() => onBlurDefine()}
        notFoundContent={<ConvertSelectNotFound isFetching={isFetchingDefine} />}
      />
    );
  };

  const renderName = (value: string, record: ConvertRuleSelectItem, index: number) => {
    return (
      <ConvertTableInput
        value={record.name ?? undefined}
        onChange={(e) => onChangeValue('name', e.target.value, index)}
        isViewMode={record.define !== 'custom'}
        isError={isErrorItem(occurredError, index, 'name')}
        maxLength={50}
      />
    );
  };

  const renderOutputColumn = (value: string, record: ConvertRuleSelectItem, index: number) => {
    return (
      <ConvertTableInput
        value={record.output_column ?? undefined}
        onChange={(e) => onChangeValue('output_column', e.target.value, index)}
        isViewMode={record.define !== 'custom'}
        isError={isErrorItem(occurredError, index, 'output_column')}
        maxLength={50}
      />
    );
  };

  const renderDataType = (value: string, record: ConvertRuleSelectItem, index: number) => {
    return (
      <ConvertTableSelect
        value={record.data_type}
        onChange={(value) => {
          onChangeValue('data_type', value, index);
        }}
        options={dataTypeOptions}
        filterOption={(input, option) =>
          option?.value ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
        }
        isViewMode={record.define !== 'custom'}
        isError={isErrorItem(occurredError, index, 'data_type')}
      />
    );
  };

  const renderDefaultValue = (value: string, record: ConvertRuleSelectItem, index: number) => {
    return (
      <Space>
        <ConvertTableInput
          value={record.def_val ?? undefined}
          onChange={(e) => onChangeValue('def_val', e.target.value, index)}
          isViewMode={record.define !== 'custom'}
        />
        <ConvertTableSelect
          value={record.def_type}
          onChange={(value) => {
            onChangeValue('def_type', value, index);
          }}
          options={defTypeOptions}
          allowClear
          filterOption={(input, option) =>
            option?.value ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
          }
          viewValue={record.def_type ? `(${record.def_type})` : ''}
          viewWidth="160px"
          notViewOptions={convertDefTypePreset}
          isViewMode={record.define !== 'custom'}
        />
      </Space>
    );
  };

  const renderDelete = (value: undefined, record: ConvertRuleSelectItem, index: number) => {
    return (
      <Popconfirm
        title="Are you sure to delete this row?"
        onConfirm={() => onDeleteRow(index)}
        okText="Delete"
        cancelText="Cancel"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <Modal
      title={`Select Info (Row : ${row})`}
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width={1276}
      destroyOnClose
      okButtonProps={{
        disabled: info.length === 0,
      }}
      footer={[
        <span
          key="error"
          css={css`
            color: red;
            margin-right: 1rem;
          `}
        >
          {occurredError ? getErrorMsg(occurredError) : undefined}
        </span>,
        <Button key="close" onClick={onClose}>
          Close
        </Button>,
        <Button key="save" type="primary" onClick={onOk} disabled={info.length === 0}>
          Save
        </Button>,
      ]}
    >
      <Table<ConvertRuleSelectItem>
        rowKey={(record, index) => index as number}
        dataSource={info}
        bordered
        size="small"
        tableLayout="fixed"
        pagination={false}
        scroll={{ y: 490, x: true }}
        css={style}
        ref={tableRef}
      >
        <Table.Column<ConvertRuleSelectItem> {...columnProps.no} render={renderNo} width={80} />
        <Table.Column<ConvertRuleSelectItem> {...columnProps.define} render={renderDefine} width={185} />
        <Table.Column<ConvertRuleSelectItem> {...columnProps.name} render={renderName} width={185} />
        <Table.Column<ConvertRuleSelectItem> {...columnProps.output_column} render={renderOutputColumn} width={185} />
        <Table.Column<ConvertRuleSelectItem> {...columnProps.data_type} render={renderDataType} width={185} />
        <Table.Column<ConvertRuleSelectItem> {...columnProps.def_val} render={renderDefaultValue} width={348} />
        <Table.Column<ConvertRuleSelectItem> {...columnProps.delete} render={renderDelete} width={60} />
      </Table>
    </Modal>
  );
});

const isErrorItem = (
  error: ConvertRuleSelectItemErrorState | null,
  index: number,
  name: keyof ConvertRuleSelectItem,
) => {
  return error !== null && error !== undefined && error.key === name && error.list.includes(index);
};

const getErrorMsg = (error: ConvertRuleSelectItemErrorState) =>
  ({
    empty: `${error.key.replaceAll('_', ' ')} is empty!`,
    duplicated: `Duplicate ${error.key.replaceAll('_', ' ')}!`,
    dbNaming: 'Begin without digits, lowercase letters, digits and underscores only!',
    length: `${error.key.replaceAll('_', ' ')} length must be less than 50!`,
  }[error.type as string] ?? '');

type ColumnName = 'no' | 'define' | 'name' | 'output_column' | 'data_type' | 'def_val' | 'delete';

const columnProps: TableColumnPropsType<ConvertRuleSelectItem, ColumnName> = {
  no: {
    key: 'no',
    title: <TableColumnTitle>Column</TableColumnTitle>,
    align: 'center',
    // width: getPixelPercent(1360, 690),
  },
  define: {
    key: 'define',
    title: <TableColumnTitle>Column Define</TableColumnTitle>,
    dataIndex: 'define',
    align: 'center',
    // shouldCellUpdate: (cur, prev) => cur.define !== prev.define,
    // width: getPixelPercent(1360, 690),
  },
  name: {
    key: 'name',
    title: <TableColumnTitle>Name</TableColumnTitle>,
    dataIndex: 'name',
    align: 'center',
    // shouldCellUpdate: (cur, prev) => cur.name !== prev.name || cur.define !== prev.define,
    //width: getPixelPercent(1360, 190),
  },
  output_column: {
    key: 'output_column',
    title: <TableColumnTitle>Output Column</TableColumnTitle>,
    dataIndex: 'output_column',
    align: 'center',
    // shouldCellUpdate: (cur, prev) => cur.output_column !== prev.output_column || cur.define !== prev.define,
    //width: getPixelPercent(1360, 190),
  },
  data_type: {
    key: 'data_type',
    title: <TableColumnTitle>Data Type</TableColumnTitle>,
    dataIndex: 'data_type',
    align: 'center',
    // shouldCellUpdate: (cur, prev) => cur.data_type !== prev.data_type || cur.define !== prev.define,
    //width: getPixelPercent(1360, 170),
  },
  def_val: {
    key: 'def_val',
    title: <TableColumnTitle>Default Value</TableColumnTitle>,
    dataIndex: 'def_val',
    align: 'center',
    // shouldCellUpdate: (cur, prev) =>
    //   cur.def_type !== prev.def_type || cur.def_val !== prev.def_val || cur.define !== prev.define,
    //width: getPixelPercent(1360, 150),
  },

  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    //width: getPixelPercent(1360, 80),
  },
};

const style = css`
  & table {
    font-size: 0.75rem;
    &:first-of-type > thead > tr > th {
      background: #f0f5ff;

      font-weight: 700;
    }
  }
`;
