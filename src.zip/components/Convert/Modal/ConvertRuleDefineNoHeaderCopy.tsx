import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { getConvertRuleItem } from '@libs/util/error';
import { getConvertRuleHeader, getConvertRuleNoHeader } from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { ConvertRuleItemWithKey } from '@typesdef/convertRules';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Modal, Select } from 'antd';
import { useForm } from 'antd/es/form/Form';
import { DefaultOptionType } from 'antd/es/select';
import React, { useMemo } from 'react';
import ConvertRuleDefineTagAddEdit, { ConvertRuleDefineTagAddEditProps } from './ConvertRuleDefineTagAddEdit';

export default React.memo(function ConvertRuleDefineNoHeaderCopy({
  visible,
  onClose,
}: GlobalModalDefaultProps): JSX.Element {
  const [form] = useForm<{
    targetRule: number;
  }>();
  const noHeaderData = useTypedSelector(getConvertRuleNoHeader);
  const headerData = useTypedSelector(getConvertRuleHeader);

  const { openModal } = useModals();

  const options: DefaultOptionType[] = useMemo(() => {
    const optionArr: DefaultOptionType[] = [];

    if (headerData.length > 0) {
      optionArr.push({
        label: `Header / ${headerData.length} Columns`,
        value: 'header',
        key: 'header',
      });
    }

    noHeaderData.forEach((item) => {
      optionArr.push({
        label: `No Header / ${item.key} Columns`,
        value: item.key.toString(),
        key: item.key.toString(),
      });
    });

    return optionArr;
  }, [noHeaderData, headerData]);

  const onOk = async () => {
    try {
      await form.validateFields();
      const target = form.getFieldValue('targetRule');
      if (!target) {
        throw new Error('targetRule is undefined!');
      }

      let data: ConvertRuleItemWithKey | undefined;
      if (target === 'header') {
        data = {
          key: headerData.length,
          rule: headerData,
        };
      } else {
        data = noHeaderData.find((item) => +item.key === +target);
      }

      if (!data) {
        throw new Error(`There no data form noHeaderData[${target}]!`);
      }

      onClose();
      openModal<ConvertRuleDefineTagAddEditProps>(MODAL_NAME.RULE_CONVERT.TAG_ADD_EDIT, ConvertRuleDefineTagAddEdit, {
        dataKeys: noHeaderData.map((item) => item.key),
        data: data,
        type: 'no_header',
        mode: 'add',
        itemList: ['column', 'define', 'data', 'name', 'output_column', 'data_type', 'def_val', 'coef', 'unit'],
        isOpenDelay: true,
      });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Modal
      title={'Copy  Header / No Header Rule'}
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width="500px"
      destroyOnClose
      okText="Copy"
    >
      <Form form={form} labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>
        <Form.Item
          label="Target Rule"
          name="targetRule"
          required
          rules={[getConvertRuleItem({ rule: 'emptySelect', type: 'string' })]}
        >
          <Select
            showSearch
            filterOption={(input, option) =>
              option ? (option.label as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
            }
            options={options}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
});
