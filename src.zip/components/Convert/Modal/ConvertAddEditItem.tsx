import FormTag from '@components/common/atoms/CustomForm/FormTag';
import { css } from '@emotion/react';
import { getConvertRuleItem } from '@libs/util/error';
import { ConvertLogItem } from '@typesdef/convertRules';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Input, InputNumber, Modal, Select, Space, Switch } from 'antd';
import React from 'react';
import { convertRuleInputTypeOptions } from '../common';
import useConvertAddEditItem from '../hooks/useConvertAddEditItem';

export interface ConvertAddEditItemProps {
  id?: number;
  data?: ConvertLogItem;
  mode: 'edit' | 'add';
}

export default React.memo(function ConvertAddEditItem({
  visible,
  onClose,
  id,
  data,
  mode,
}: GlobalModalDefaultProps<ConvertAddEditItemProps>): JSX.Element {
  const { form, onOk, formValid, isLoading, siteOptions, tag, setTag, ignore, setIgnore, isRetention, setRetention } =
    useConvertAddEditItem({
      id,
      data,
      mode,
      onClose,
    });

  return (
    <Modal
      title={mode === 'add' ? 'Add Log' : 'Edit Log'}
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width="600px"
      destroyOnClose
      cancelButtonProps={{
        disabled: isLoading,
      }}
      okButtonProps={{
        loading: isLoading,
        disabled: isLoading,
      }}
      maskClosable={!isLoading}
    >
      <div
        css={css`
          height: 630px;
          overflow-y: auto;
        `}
      >
        <Form form={form} onFinish={onOk} layout="vertical" disabled={isLoading}>
          <Form.Item
            name="log_name"
            label="Log Name"
            className="log_name"
            required
            help={formValid.log_name.help}
            validateStatus={formValid.log_name.status}
            // hasFeedback
          >
            <Input disabled={mode === 'edit'} maxLength={50} />
          </Form.Item>
          <Form.Item
            name="table_name"
            label="Table Name"
            className="table_name"
            required
            help={formValid.table_name.help}
            validateStatus={formValid.table_name.status}
            // hasFeedback
          >
            <Input disabled={mode === 'edit'} maxLength={50} />
          </Form.Item>
          <Form.Item
            label="Input Type"
            name="input_type"
            className="input_type"
            required
            rules={[getConvertRuleItem({ rule: 'emptySelect', type: 'string' })]}
          >
            <Select
              showSearch
              filterOption={(input, option) =>
                option ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
              }
              options={convertRuleInputTypeOptions}
              disabled={mode === 'edit'}
            />
          </Form.Item>
          {/* not display user-fab name */}
          {/* <Form.Item
            label="User-Fab Name"
            name="select"
            className="user-fab-name"
            tooltip="If you select nothing, it will run on all user-fabs."
          >
            <Select
              showSearch
              filterOption={(input, option) =>
                option ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
              }
              placeholder="All (If you select nothing, it will run on all user-fabs.)"
              mode="multiple"
              allowClear
              options={siteOptions}
            />
          </Form.Item> */}
          <FormTag
            label="Tags"
            name="tag"
            tag={tag}
            setTag={setTag}
            rules={[
              getConvertRuleItem({
                rule: 'min',
                type: 'array',
                min: 1,
              }),
            ]}
          />
          <FormTag label="Ignore Pattern" name="ignore" tag={ignore} setTag={setIgnore} />
          <Form.Item
            label={
              <Space>
                <div>Retention Period (Days)</div>
                <Switch checked={isRetention} onChange={setRetention} />
              </Space>
            }
            name="retention"
            rules={
              isRetention
                ? [
                    getConvertRuleItem({ rule: 'empty', type: 'number' }),
                    getConvertRuleItem({
                      rule: 'custom',
                      type: 'number',
                      message: 'Must be greater than 1!`',
                      validator: (rule, value) =>
                        new Promise((resolve, reject) => {
                          if (!value) return resolve(true);
                          return +value >= 1 ? resolve(true) : reject(false);
                        }),
                    }),
                  ]
                : []
            }
          >
            <InputNumber min={1} max={9999} maxLength={4} precision={0} disabled={!isRetention} />
          </Form.Item>
        </Form>
      </div>
    </Modal>
  );
});
