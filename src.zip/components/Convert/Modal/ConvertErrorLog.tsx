import { LinkOutlined } from '@ant-design/icons';
import { ellipsisLineStyle } from '@components/common/atoms/Common/Common';
import RefreshBtn from '@components/common/atoms/RefreshBtn/RefreshBtn';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { API_URL } from '@constants/constants';
import { css } from '@emotion/react';
import useMoveToHistoryLog from '@hooks/useMoveToHistoryLog';
import { useGetConvertError } from '@libs/query/convert';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { downloadFileUrl } from '@libs/util/download';
import { openNotification } from '@libs/util/notification';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { ConvertRuleItemErrorMsg } from '@typesdef/convertRules';
import { BuildHistoryState } from '@typesdef/Job';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Modal, Popconfirm, Table } from 'antd';
import { AxiosError } from 'axios';
import { memo } from 'react';

export interface ConvertErrorLogProps {
  logId: number;
}

export default memo(function ConvertErrorLog({
  visible,
  onClose,
  logId,
}: GlobalModalDefaultProps<ConvertErrorLogProps>): JSX.Element {
  const { moveToHistoryLog } = useMoveToHistoryLog();

  const { data, isFetching, refetch } = useGetConvertError(logId, {
    enabled: Boolean(logId),
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to response the list of convert log error`, error);
    },
  });

  const renderTitle = () => {
    return (
      <TableHeader title={<TableHeaderTitle total={data?.length ?? 0} />}>
        <RefreshBtn onClick={() => refetch()} loading={isFetching} />
      </TableHeader>
    );
  };

  const renderLog = (value: BuildHistoryState, record: ConvertRuleItemErrorMsg, index: number) => {
    const { jobType, stepType, jobId, jobName, stepId, stepName, historyId } = value;

    if (!historyId) {
      return <div>-</div>;
    }

    return (
      <Popconfirm
        placement="top"
        title="Are you sure to move to history log?"
        onConfirm={() => {
          moveToHistoryLog({
            jobType,
            stepType,
            jobId,
            jobName,
            stepId,
            stepName,
            historyId,
          });
          onClose();
        }}
      >
        <LinkOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderFile = (value: string, record: ConvertRuleItemErrorMsg) => {
    const { log_id, id, file_exist } = record;

    if (!log_id || !id || !file_exist) {
      return <div>{value}</div>;
    }

    return (
      <Popconfirm
        placement="top"
        title="Are you sure to download file?"
        onConfirm={() => {
          downloadFileUrl(API_URL.GET_DOWNLOAD_CONVERT_ERROR_LOG(log_id as number, id as number));
        }}
      >
        <div css={hoverActiveStyle}>{value}</div>
      </Popconfirm>
    );
  };

  return (
    <div>
      <Modal
        title={'Error Messages'}
        open={visible}
        onOk={onClose}
        okText="Close"
        cancelButtonProps={{
          hidden: true,
        }}
        closable
        onCancel={onClose}
        maskClosable
        destroyOnClose
        width={'1358px'}
      >
        <Table<ConvertRuleItemErrorMsg>
          rowKey={'index'}
          dataSource={data ?? []}
          bordered
          title={renderTitle}
          size="small"
          pagination={{
            position: ['bottomCenter'],
            showSizeChanger: false,
            pageSize: 5,
            hideOnSinglePage: true,
          }}
          tableLayout="fixed"
          loading={isFetching}
          css={css`
            table {
              font-size: 0.8rem;
            }
          `}
        >
          <Table.Column<ConvertRuleItemErrorMsg> {...columnProps.index} />
          <Table.Column<ConvertRuleItemErrorMsg> {...columnProps.equipment} />
          <Table.Column<ConvertRuleItemErrorMsg> {...columnProps.path} />
          <Table.Column<ConvertRuleItemErrorMsg> {...columnProps.file} render={renderFile} />
          <Table.Column<ConvertRuleItemErrorMsg> {...columnProps.row} />
          <Table.Column<ConvertRuleItemErrorMsg> {...columnProps.content} />
          <Table.Column<ConvertRuleItemErrorMsg> {...columnProps.msg} />
          <Table.Column<ConvertRuleItemErrorMsg> {...columnProps.created} />
          <Table.Column<ConvertRuleItemErrorMsg> {...columnProps.history} render={renderLog} />
        </Table>
      </Modal>
    </div>
  );
});

type ConvertErrorColumnName =
  | 'index'
  | 'equipment'
  | 'path'
  | 'file'
  | 'row'
  | 'content'
  | 'msg'
  | 'created'
  | 'history';

const columnProps: TableColumnPropsType<ConvertRuleItemErrorMsg, ConvertErrorColumnName> = {
  index: {
    key: 'index',
    title: <TableColumnTitle>No</TableColumnTitle>,
    dataIndex: 'index',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'index'),
    },
    width: getPixelPercent(1310, 70),
    render: function renderIndex(value: number, record: ConvertRuleItemErrorMsg, index: number) {
      return <div>{value + 1}</div>;
    },
  },
  equipment: {
    key: 'equipment',
    title: <TableColumnTitle>Equipment Name</TableColumnTitle>,
    dataIndex: 'equipment',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'equipment'),
    },
    width: getPixelPercent(1310, 150),
  },
  path: {
    key: 'path',
    title: <TableColumnTitle>Path</TableColumnTitle>,
    dataIndex: 'path',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'path'),
    },
    width: getPixelPercent(1310, 150),
    render: function renderPath(value: string, record: ConvertRuleItemErrorMsg, index: number) {
      return (
        <div title={value} css={ellipsisLineStyle({ line: 2 })}>
          {value}
        </div>
      );
    },
  },
  file: {
    key: 'file',
    title: <TableColumnTitle>File Name</TableColumnTitle>,
    dataIndex: 'file',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'file'),
    },
    width: getPixelPercent(1310, 150),
  },
  row: {
    key: 'row',
    title: <TableColumnTitle>Log Line</TableColumnTitle>,
    dataIndex: 'row',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'row'),
    },
    width: getPixelPercent(1310, 70),
  },

  content: {
    key: 'content',
    title: <TableColumnTitle>Log Content</TableColumnTitle>,
    dataIndex: 'content',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'content'),
    },
    width: getPixelPercent(1310, 270),
    render: function renderContent(value: string, record: ConvertRuleItemErrorMsg, index: number) {
      return (
        <div title={value} css={ellipsisLineStyle({ line: 2 })}>
          {value}
        </div>
      );
    },
  },
  msg: {
    key: 'msg',
    title: <TableColumnTitle>Error Message</TableColumnTitle>,
    dataIndex: 'msg',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'msg'),
    },
    width: getPixelPercent(1310, 270),
  },
  created: {
    key: 'created',
    title: <TableColumnTitle>Date</TableColumnTitle>,
    dataIndex: 'created',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'created'),
    },
    width: getPixelPercent(1310, 120),
  },
  history: {
    key: 'history',
    title: <TableColumnTitle>Log</TableColumnTitle>,
    dataIndex: 'history',
    align: 'center',
    width: getPixelPercent(1310, 60),
  },
};
