import { css } from '@emotion/react';
import { useGetColumnDefine } from '@libs/query/columnDefine';
import { dbNameValidator, getConvertRuleItem } from '@libs/util/error';
import { ReqSearchParam } from '@typesdef/common';
import { ConvertRuleSelectItem } from '@typesdef/convertRules';
import { Form, FormInstance, Input, Select } from 'antd';
import { Rule } from 'antd/es/form';
import { useWatch } from 'antd/es/form/Form';
import { DefaultOptionType } from 'antd/es/select';
import { useMemo, useRef, useState } from 'react';
import { useDebounce } from 'react-use';
import {
  convertDefTypeCustom,
  ConvertSelectCustom,
  ConvertSelectNotFound,
  initialConvertRuleItem,
} from '../ConvertCommon';

type ColumnName = 'no' | 'define' | 'name' | 'output_column' | 'data_type' | 'def_type' | 'delete';
type OptionType = Record<'data_type' | 'def_type', string[]>;

export type CheckInfoDuplicationType = ({
  key,
  value,
  index,
  exception,
}: {
  key: keyof ConvertRuleSelectItem;
  value: string;
  index: number;
  exception?: string[];
}) => Promise<boolean>;

interface EditableCellProps {
  index: number;
  editing: boolean;
  dataIndex: keyof ConvertRuleSelectItem;
  dataKey: ColumnName;
  record: ConvertRuleSelectItem;
  form: FormInstance<ConvertRuleSelectItem>;
  options: OptionType;
  duplicateCheck: CheckInfoDuplicationType;
  children: React.ReactNode;
  rest?: any;
}

export function InfoSelectEditableCell({
  index,
  editing,
  dataIndex,
  dataKey,
  record,
  form,
  options,
  duplicateCheck,
  children,
  ...rest
}: EditableCellProps) {
  let childNode = children;

  if (dataIndex !== undefined) {
    childNode = editing ? (
      <EditableCellItem
        index={index}
        dataIndex={dataIndex}
        dataKey={dataKey}
        record={record}
        form={form}
        options={options}
        duplicateCheck={duplicateCheck}
      />
    ) : (
      <NotEditableCellItem dataKey={dataKey} dataIndex={dataIndex} record={record} index={index}>
        {children}
      </NotEditableCellItem>
    );
  }

  return (
    <td
      {...rest}
      css={css`
        word-break: break-all;
      `}
    >
      {childNode}
    </td>
  );
}

interface EditableCellItemProps {
  index: number;
  dataIndex: keyof ConvertRuleSelectItem;
  dataKey: ColumnName;
  record: ConvertRuleSelectItem;
  form: FormInstance<ConvertRuleSelectItem>;
  options?: OptionType;
  duplicateCheck?: CheckInfoDuplicationType;
  rules?: Rule[];
}

function EditableCellItem({ ...rest }: EditableCellItemProps) {
  const { index, dataKey, dataIndex, form, duplicateCheck } = rest;
  const formRecord = form.getFieldsValue();
  const isViewMode = dataIndex !== 'define' && formRecord.define && formRecord.define !== 'custom' ? true : false;

  if (isViewMode) {
    return (
      <Form.Item name={dataIndex} noStyle>
        <NotEditableCellItem {...rest} record={formRecord} />
        {dataIndex === 'def_type' && <Form.Item name="def_val" noStyle />}
      </Form.Item>
    );
  }

  const rules = getEditableCellItemRules({ index, dataKey, dataIndex, duplicateCheck });

  switch (dataKey) {
    case 'define':
      return <EditableCellItemDefine {...rest} rules={rules} />;

    case 'name':
      return <EditableCellItemText {...rest} rules={rules} />;

    case 'output_column':
      return <EditableCellItemText {...rest} rules={rules} />;

    case 'data_type':
      return <EditableCellItemSelect {...rest} rules={rules} />;

    case 'def_type':
      return <EditableCellItemDefType {...rest} rules={rules} />;

    default:
      return <EditableCellItemText {...rest} rules={rules} />;
  }
}

interface NotEditableCellItemProps {
  index: number;
  dataIndex: keyof ConvertRuleSelectItem;
  dataKey: ColumnName;
  record: ConvertRuleSelectItem;
  children?: React.ReactNode;
}

const NotEditableCellItem = ({ index, dataIndex, dataKey, record, children }: NotEditableCellItemProps) => {
  switch (dataKey) {
    case 'no':
      return <div css={warpNoEditableCellStyle}>{(index ?? 0) + 1}</div>;

    case 'delete':
      return <div>{children}</div>;

    case 'def_type':
      return (
        <div css={warpDefValEditableCellStyle}>
          <div className="editable-cell-value-wrap" title={`${record.def_val ?? ''}`}>
            {record.def_val}
          </div>
          <div className="editable-cell-value-wrap">
            {convertDefTypeCustom.includes(record.def_type ?? '') && `(${record.def_type})`}
          </div>
        </div>
      );

    default:
      return (
        <div css={warpEditableCellStyle}>
          <div className="editable-cell-value-wrap" title={`${record[dataIndex]}`}>
            {record[dataIndex]}
          </div>
        </div>
      );
  }
};

function EditableCellItemDefine({ index, dataIndex, form, rules = [] }: EditableCellItemProps) {
  const [searchParam, setSearchParam] = useState<ReqSearchParam>({});
  const [searchInput, setSearchInput] = useState<string>('');
  const selectRef = useRef<HTMLDivElement>(null);

  useDebounce(
    () => {
      setSearchParam(
        searchInput
          ? {
              name: searchInput,
            }
          : {},
      );
    },
    300,
    [searchInput],
  );

  const { data: infoDefines, isFetching: isFetchingDefine } = useGetColumnDefine({
    paths: {
      type: 'info',
    },
    search: searchParam,
  });

  const defineOptions: DefaultOptionType[] = useMemo(
    () =>
      infoDefines?.content.map((item) => ({
        label: item.name,
        value: item.name,
        key: item.name,
      })) ?? [],
    [infoDefines],
  );

  const onSearchDefine = (value: string) => {
    setSearchInput(value);
  };

  const onFocusDefine = () => {
    setSearchInput('');
  };
  const onBlurDefine = () => {
    setSearchInput('');
  };

  const onChangeValue = (value: string) => {
    if (value === 'custom' || value === 'null') {
      const defineRef = selectRef.current?.querySelector('.ant-select-selector');
      if (defineRef) {
        const mouseDownEvent = new Event('mousedown', { bubbles: true, cancelable: true });
        // const clickEvent = new Event('click', { bubbles: true, cancelable: true });

        defineRef.dispatchEvent(mouseDownEvent);
        // defineRef.dispatchEvent(clickEvent);
      }
      form.setFieldsValue({ ...initialConvertRuleItem, define: value });
    } else {
      const foundItem = infoDefines?.content.find((item) => item.name === value);
      if (foundItem) {
        form.setFieldsValue({ ...initialConvertRuleItem, ...foundItem, define: value });
      } else {
        form.setFieldsValue({ ...initialConvertRuleItem, define: value });
      }
    }
  };

  return (
    <div ref={selectRef}>
      <Form.Item css={formItemStyle} name={dataIndex} rules={rules}>
        <Select
          size="small"
          options={defineOptions}
          showSearch
          onChange={onChangeValue}
          searchValue={searchInput}
          onSearch={onSearchDefine}
          onFocus={() => onFocusDefine()}
          onBlur={() => onBlurDefine()}
          dropdownRender={(menu) => (
            <ConvertSelectCustom
              menu={menu}
              itemList={['custom', 'null']}
              index={index}
              onClick={({ index, define }) => onChangeValue(define)}
            />
          )}
          notFoundContent={<ConvertSelectNotFound isFetching={isFetchingDefine} />}
          css={css`
            width: 10rem !important;
            .ant-select-selector {
              font-size: 0.8rem;
            }
          `}
        />
      </Form.Item>
    </div>
  );
}

function EditableCellItemSelect({ dataIndex, options, rules = [] }: EditableCellItemProps) {
  return (
    <Form.Item style={{ margin: 0 }} name={dataIndex} rules={rules}>
      <Select
        size="small"
        showSearch
        options={
          options?.data_type.map((item) => ({
            key: item,
            value: item,
            label: item,
          })) ?? []
        }
        css={formSelectStyle}
      />
    </Form.Item>
  );
}

function EditableCellItemDefType({ options, form }: EditableCellItemProps) {
  const formDefType = useWatch('def_type', form);

  return (
    <div
      css={css`
        display: flex;
        height: 32px;
        padding-top: 4px;
        padding-bottom: 4px;
        .ant-form-item + .ant-form-item {
          margin-left: 8px;
        }
      `}
    >
      <Form.Item css={formItemStyle} name="def_val">
        <Input size="small" css={formInputStyle} disabled={!convertDefTypeCustom.includes(formDefType ?? '')} />
      </Form.Item>

      <Form.Item css={formItemStyle} name="def_type">
        <Select
          size="small"
          onChange={(value) => {
            form.setFieldsValue({
              def_type: value as string,
              def_val: ['lambda', 'text'].includes(`${value}`) ? '' : (value as string),
            });
          }}
          showSearch
          allowClear
          options={
            options?.def_type.map((item) => ({
              key: item,
              value: item,
              label: item,
            })) ?? []
          }
          filterOption={(input, option) =>
            option?.value ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
          }
          css={formSelectStyle}
        />
      </Form.Item>
    </div>
  );
}

function EditableCellItemText({ dataIndex, rules = [] }: EditableCellItemProps) {
  return (
    <Form.Item css={formItemStyle} name={dataIndex} rules={rules}>
      <Input size="small" css={formInputStyle} />
    </Form.Item>
  );
}

const getEditableCellItemRules = ({
  index,
  dataKey,
  dataIndex,
  duplicateCheck,
}: {
  index: number;
  dataKey: ColumnName;
  dataIndex: keyof ConvertRuleSelectItem;
  duplicateCheck?: CheckInfoDuplicationType;
}): Rule[] => {
  const empty = getConvertRuleItem({ rule: 'empty', type: 'string' });
  const emptySelect = getConvertRuleItem({ rule: 'emptySelect', type: 'string' });
  const max = getConvertRuleItem({ rule: 'max', type: 'string', max: 50 });
  const duplicated = (exception?: string[]) =>
    getConvertRuleItem({
      rule: 'duplicated',
      type: 'string',
      validator: (rule, value) =>
        duplicateCheck
          ? duplicateCheck({
              index,
              key: dataIndex,
              value,
              exception,
            })
          : new Promise((resolve) => resolve(true)),
    });
  const dbNaming = getConvertRuleItem({
    rule: 'dbNaming',
    type: 'string',
  });

  switch (dataKey) {
    case 'define':
      return [empty, duplicated(['null', 'custom'])];
    case 'name':
      return [empty, max, duplicated()];
    case 'output_column':
      return [empty, max, duplicated(), dbNaming];
    case 'data_type':
      return [emptySelect];
    default:
      return [];
  }
};

export const getEditableCellItemRulesForOk = (name: ColumnName): Rule[] => {
  const empty = getConvertRuleItem({ rule: 'empty', type: 'string' });
  const emptySelect = getConvertRuleItem({ rule: 'emptySelect', type: 'string' });
  const max = getConvertRuleItem({ rule: 'max', type: 'string', max: 50 });
  const dbNaming = getConvertRuleItem({
    rule: 'dbNaming',
    type: 'string',
  });

  switch (name) {
    case 'define':
      return [empty];
    case 'name':
      return [empty, max];
    case 'output_column':
      return [empty, max, dbNaming];
    case 'data_type':
      return [emptySelect];
    default:
      return [];
  }
};

const formItemStyle = css`
  margin: 0;
  .ant-form-item-explain {
    font-size: 0.8rem;
    display: flex;
  }
  .ant-form-item-control-input {
    min-height: 24px;
  }
`;

const formSelectStyle = css`
  width: 10rem !important;
  .ant-select-selector {
    font-size: 0.8rem;
  }
`;

const formInputStyle = css`
  font-size: 0.8rem;
  margin-top: 0;
  width: 10rem;
  height: 24px;
  line-height: 24px;
`;

const editableCellStyle = css`
  padding-left: 7px;
  padding-right: 7px;
  border: 1px solid transparent;
  height: 24px;
  line-height: 22px;
  width: 10rem;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  word-break: break-all;
`;

const warpEditableCellStyle = css`
  height: 32px;
  padding-top: 4px;
  padding-bottom: 4px;
  width: 10rem;

  .editable-cell-value-wrap {
    ${editableCellStyle}
  }
`;

const warpNoEditableCellStyle = css`
  display: flex;
  justify-content: center;
`;

const warpDefValEditableCellStyle = css`
  display: flex;
  height: 32px;
  padding-top: 4px;
  padding-bottom: 4px;
  .editable-cell-value-wrap + .editable-cell-value-wrap {
    margin-left: 8px;
  }

  .editable-cell-value-wrap {
    ${editableCellStyle}
  }
`;
