import { DeleteOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { hoverActiveStyle } from '@styles/emotion/common';
import { ConvertRuleSelectItem } from '@typesdef/convertRules';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Modal, Popconfirm, Table } from 'antd';
import { ColumnGroupType, ColumnsType, ColumnType } from 'antd/es/table';
import React from 'react';
import useConvertRuleDefineSelectInfoVer2 from '../hooks/useConvertRuleDefineSelectInfoVer2';
import { getEditableCellItemRulesForOk, InfoSelectEditableCell } from './ConvertRuleDefineSelectInfoVer2Items';

export interface ConvertRuleDefineSelectInfoProps {
  row: number;
  data: Record<string, string | null>;
}

type EditableColumnsType<RecordType> = (ColumnGroupType<RecordType> | ColumnType<RecordType>) & {
  editable?: boolean;
  dataIndex?: ColumnType<RecordType>['dataIndex'];
};

export default React.memo(function ConvertRuleDefineSelectInfoVer2({
  visible,
  onClose,
  row,
  data,
}: GlobalModalDefaultProps<ConvertRuleDefineSelectInfoProps>): JSX.Element {
  const {
    info,
    infoOptions,
    modalRef,
    tableRef,
    form,
    isEditing,
    onDelete,
    duplicateCheck,
    onRow,
    onOk,
    onAdd,
    checkForm,
  } = useConvertRuleDefineSelectInfoVer2({
    visible,
    onClose,
    row,
    data,
  });

  const columns: EditableColumnsType<ConvertRuleSelectItem>[] = [
    {
      key: 'no',
      title: <TableColumnTitle>Column</TableColumnTitle>,
      align: 'center',
      width: 80,
      render: (value, record, index) => <div className="no">{index + 1}</div>,
      editable: false,
      className: 'no',
    },
    {
      key: 'define',
      title: <TableColumnTitle>Column Define</TableColumnTitle>,
      dataIndex: 'define',
      width: 175,
      editable: true,
    },
    {
      key: 'name',
      title: <TableColumnTitle>Name</TableColumnTitle>,
      dataIndex: 'name',
      width: 175,
      editable: true,
    },
    {
      key: 'output_column',
      title: <TableColumnTitle>Output Column</TableColumnTitle>,
      dataIndex: 'output_column',
      width: 175,
      editable: true,
    },
    {
      key: 'data_type',
      title: <TableColumnTitle>Data Type</TableColumnTitle>,
      dataIndex: 'data_type',
      width: 175,
      editable: true,
    },
    {
      key: 'def_type',
      title: <TableColumnTitle>Default Value</TableColumnTitle>,
      dataIndex: 'def_type',
      width: 335,
      editable: true,
    },
    {
      key: 'delete',
      title: <TableColumnTitle>Delete</TableColumnTitle>,
      dataIndex: 'delete',
      align: 'center',
      width: 60,
      editable: false,
      className: 'delete',
      render: (value, record, index) => (
        <Popconfirm
          className="delete"
          title="Are you sure to delete this row?"
          onConfirm={(e) => {
            // to prevent event bubbling about row selection
            e?.stopPropagation();
            onDelete(index);
          }}
          okText="Delete"
          cancelText="Cancel"
        >
          <div css={[hoverActiveStyle]}>
            <DeleteOutlined />
          </div>
        </Popconfirm>
      ),
    },
  ];

  const mergedColumns = columns.map((col) => {
    if (!col.editable) {
      return col;
    }

    return {
      ...col,
      onCell: (record: ConvertRuleSelectItem, index: number) => ({
        index,
        editing: isEditing(index),
        dataIndex: col.dataIndex,
        dataKey: col.key,
        record,
        options: infoOptions,
        duplicateCheck,
        form,
      }),
    };
  });

  const renderTitle = () => (
    <TableHeader>
      <AntdButton icon={<PlusOutlined />} onClick={onAdd}>
        Add
      </AntdButton>
    </TableHeader>
  );

  return (
    <Modal
      title={`Select Info (Row : ${row})`}
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width={1276}
      destroyOnClose
      okButtonProps={{
        disabled: info.length === 0,
      }}
    >
      <div ref={modalRef}>
        <Form form={form} component={false}>
          <Table<ConvertRuleSelectItem>
            title={renderTitle}
            ref={tableRef}
            rowKey={(record, index) => index as number}
            rowClassName={() => 'editable-row'}
            dataSource={info}
            bordered
            size="small"
            tableLayout="fixed"
            pagination={false}
            scroll={{ y: 490 }}
            css={style}
            columns={mergedColumns as ColumnsType<ConvertRuleSelectItem>}
            components={{
              body: {
                cell: InfoSelectEditableCell,
              },
            }}
            onRow={onRow}
          />
        </Form>
        <Form form={checkForm} component={false}>
          <Form.Item name="define" hidden rules={getEditableCellItemRulesForOk('define')} />
          <Form.Item name="name" hidden rules={getEditableCellItemRulesForOk('name')} />
          <Form.Item name="output_column" hidden rules={getEditableCellItemRulesForOk('output_column')} />
          <Form.Item name="data_type" hidden rules={getEditableCellItemRulesForOk('data_type')} />
          <Form.Item name="def_val" hidden />
          <Form.Item name="def_type" hidden />
        </Form>
      </div>
    </Modal>
  );
});

const style = css`
  width: 1228px;

  & table {
    font-size: 0.8rem;
    &:first-of-type > thead > tr > th {
      background: #f0f5ff;

      font-weight: 700;
    }
  }

  .ant-table-header {
    .ant-table-thead {
      th {
        text-align: center;
      }
    }
  }

  .editable-cell-value-wrap {
    cursor: pointer;
  }

  .editable-row:hover .editable-cell-value-wrap {
    /* border: 1px solid #d9d9d9;
    border-radius: 2px; */
  }
`;
