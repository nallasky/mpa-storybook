import { css } from '@emotion/react';
import { getPascalCaseName } from '@libs/util/convert';
import { getConvertRuleItem } from '@libs/util/error';
import { ConvertRuleItem, ConvertRuleSelectItemKey } from '@typesdef/convertRules';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Input, InputNumber, Modal, Select } from 'antd';
import React from 'react';
import {
  convertDataTypeNumber,
  convertDefTypeCustom,
  ConvertSelectCustom,
  ConvertSelectNotFound,
  ConvertViewInput,
} from '../ConvertCommon';
import useConvertRuleDefineItemAddEdit from '../hooks/useConvertRuleDefineItemAddEdit';

export interface ConvertRuleDefineItemAddEditProps {
  index?: number;
  data?: ConvertRuleItem;
  type: 'header' | 'regex' | 'custom' | 'custom' | 'filter';
  mode: 'edit' | 'add';
  itemList: (ConvertRuleSelectItemKey | 'condition' | 'filter_type')[];
}

export default React.memo(function ConvertRuleDefineItemAddEdit({
  visible,
  onClose,
  index,
  data,
  type,
  mode,
  itemList,
}: GlobalModalDefaultProps<ConvertRuleDefineItemAddEditProps>): JSX.Element {
  const {
    form,
    ruleList,
    isFetchingDefine,
    onOk,
    onChangeDefType,
    onSearchDefine,
    onChangeDefine,
    onChangeDefineOther,
    searchInput,
    divRef,
    formDefine,
    formDefType,
    formDataType,
    defineOptions,
    typeOptions,
    duplicateValidator,
    inputType,
  } = useConvertRuleDefineItemAddEdit({
    index,
    data,
    type,
    mode,
    itemList,
    onClose,
  });

  const title = getPascalCaseName(inputType === 'status' ? [mode, 'event'] : [mode, ...type.split('_')]);
  const viewData = form.getFieldValue('data');
  const viewName = form.getFieldValue('name');
  const viewDataType = form.getFieldValue('data_type');
  const viewDefType = form.getFieldValue('def_type');
  const viewDefVal = form.getFieldValue('def_val');
  const viewOutCol = form.getFieldValue('output_column');
  const viewCoef = form.getFieldValue('coef');
  const viewUnit = form.getFieldValue('unit');
  const viewRegexPrefix = form.getFieldValue('regex_prefix');
  const viewRegex = form.getFieldValue('regex');
  const viewReGroup = form.getFieldValue('re_group');
  const isViewInput = !formDefine || formDefine === 'custom';

  return (
    <Modal title={title} open={visible} onOk={onOk} onCancel={onClose} width="600px" destroyOnClose>
      <div ref={divRef}>
        <Form form={form} labelCol={{ span: 8 }} wrapperCol={{ span: 16 }} css={formStyle} onFinish={onOk}>
          {itemList.includes('define') && (
            <Form.Item name="define" label="Column Define" className="define">
              <Select
                className="define__select"
                showSearch
                filterOption={(input, option) =>
                  option?.value
                    ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase())
                    : false
                }
                options={defineOptions}
                onChange={onChangeDefine}
                searchValue={searchInput ?? undefined}
                onSearch={onSearchDefine}
                dropdownRender={(menu) => (
                  <ConvertSelectCustom menu={menu} itemList={['custom']} onClick={onChangeDefineOther} />
                )}
                onFocus={() => onSearchDefine(null)}
                onBlur={() => onSearchDefine(null)}
                notFoundContent={<ConvertSelectNotFound isFetching={isFetchingDefine} />}
              />
            </Form.Item>
          )}
          {itemList.includes('data') && (
            <Form.Item name="data" label="Data" className="data">
              <ConvertViewInput title={viewData}>{viewData}</ConvertViewInput>
            </Form.Item>
          )}
          {itemList.includes('name') && (
            <Form.Item
              name="name"
              label="Name"
              className="name"
              required
              rules={[
                getConvertRuleItem({ rule: 'empty', type: 'string' }),
                getConvertRuleItem({ rule: 'max', type: 'string', max: 50 }),
                getConvertRuleItem({ rule: 'duplicated', type: 'string', validator: duplicateValidator }),
              ]}
            >
              {isViewInput ? (
                <Input maxLength={50} />
              ) : (
                <ConvertViewInput title={viewName}>{viewName}</ConvertViewInput>
              )}
            </Form.Item>
          )}
          {itemList.includes('output_column') && (
            <Form.Item
              label="Output Column"
              name="output_column"
              className="output_column"
              required
              rules={[
                getConvertRuleItem({ rule: 'empty', type: 'string' }),
                getConvertRuleItem({ rule: 'max', type: 'string', max: 50 }),
                getConvertRuleItem({ rule: 'duplicated', type: 'string', validator: duplicateValidator }),
                getConvertRuleItem({
                  rule: 'dbNaming',
                  type: 'string',
                }),
              ]}
            >
              {isViewInput ? <Input /> : <ConvertViewInput title={viewOutCol}>{viewOutCol}</ConvertViewInput>}
            </Form.Item>
          )}
          {itemList.includes('regex_prefix') && (
            <Form.Item
              name="regex_prefix"
              label="Regex Prefix"
              className="regex_prefix"
              required
              rules={[getConvertRuleItem({ rule: 'empty', type: 'string' })]}
            >
              {isViewInput ? <Input /> : <ConvertViewInput title={viewRegexPrefix}>{viewRegexPrefix}</ConvertViewInput>}
            </Form.Item>
          )}
          {itemList.includes('regex') && (
            <Form.Item
              name="regex"
              label="Regex"
              className="regex"
              required
              rules={[getConvertRuleItem({ rule: 'empty', type: 'string' })]}
            >
              {isViewInput ? <Input /> : <ConvertViewInput title={viewRegex}>{viewRegex}</ConvertViewInput>}
            </Form.Item>
          )}
          {itemList.includes('re_group') && (
            <Form.Item name="re_group" label="Group" className="re_group">
              {isViewInput ? (
                <InputNumber
                  css={css`
                    width: 100%;
                  `}
                  min={0}
                  max={999}
                  maxLength={999}
                  precision={0}
                />
              ) : (
                <ConvertViewInput title={viewReGroup}>{viewReGroup}</ConvertViewInput>
              )}
            </Form.Item>
          )}
          {itemList.includes('data_type') && (
            <Form.Item
              label="Data Type"
              name="data_type"
              className="data_type"
              required
              rules={[getConvertRuleItem({ rule: 'emptySelect', type: 'string' })]}
            >
              {isViewInput ? (
                <Select
                  showSearch
                  filterOption={(input, option) =>
                    option?.value
                      ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase())
                      : false
                  }
                  options={typeOptions.dataType}
                />
              ) : (
                <ConvertViewInput title={viewDataType}>{viewDataType}</ConvertViewInput>
              )}
            </Form.Item>
          )}
          {itemList.includes('def_val') && (
            <Form.Item label="Default Value" className="default_wrapper">
              <Form.Item
                name="def_val"
                className="def_val"
                // rules={[{ required: true, message: 'Please input a default value!' }]}
              >
                {isViewInput ? (
                  <Input disabled={!convertDefTypeCustom.includes(formDefType ?? '')} />
                ) : (
                  <ConvertViewInput title={viewDefVal}>{viewDefVal}</ConvertViewInput>
                )}
              </Form.Item>
              <Form.Item name="def_type" className="def_type">
                {isViewInput ? (
                  <Select
                    showSearch
                    filterOption={(input, option) =>
                      option?.value
                        ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase())
                        : false
                    }
                    onChange={onChangeDefType}
                    options={typeOptions.defType}
                    allowClear
                  />
                ) : (
                  <ConvertViewInput title={viewDefType ? `(${viewDefType})` : ''}>
                    {viewDefType ? `(${viewDefType})` : ''}
                  </ConvertViewInput>
                )}
              </Form.Item>
            </Form.Item>
          )}
          {itemList.includes('coef') && (
            <Form.Item name="coef" label="Coefficient" className="coef">
              {isViewInput ? (
                <InputNumber
                  css={css`
                    width: 100%;
                  `}
                  disabled={!convertDataTypeNumber.includes(formDataType ?? '')}
                  min={-99999999}
                  max={99999999}
                  maxLength={8}
                />
              ) : (
                <ConvertViewInput title={viewCoef}>{viewCoef}</ConvertViewInput>
              )}
            </Form.Item>
          )}
          {itemList.includes('unit') && (
            <Form.Item name="unit" label="Unit" className="unit">
              {isViewInput ? <Input /> : <ConvertViewInput title={viewUnit}>{viewUnit}</ConvertViewInput>}
            </Form.Item>
          )}
          {itemList.includes('filter_type') && (
            <Form.Item
              label="Type"
              name="def_type"
              className="filter_type"
              required
              rules={[getConvertRuleItem({ rule: 'emptySelect', type: 'string' })]}
            >
              <Select
                showSearch
                filterOption={(input, option) =>
                  option?.value
                    ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase())
                    : false
                }
                options={typeOptions.filterType}
              />
            </Form.Item>
          )}
          {itemList.includes('condition') && (
            <Form.Item
              name="def_val"
              label="Condition"
              className="condition"
              required
              rules={[getConvertRuleItem({ rule: 'empty', type: 'string' })]}
            >
              <Input />
            </Form.Item>
          )}
          {itemList.includes('start_state') && (
            <Form.Item
              name="start_state"
              label="Start State"
              className="start_state"
              required
              rules={[getConvertRuleItem({ rule: 'empty', type: 'string' })]}
            >
              <Input />
            </Form.Item>
          )}
          {itemList.includes('end_state') && (
            <Form.Item
              name="end_state"
              label="End State"
              className="end_state"
              required
              rules={[getConvertRuleItem({ rule: 'empty', type: 'string' })]}
            >
              <Input />
            </Form.Item>
          )}
        </Form>
      </div>
    </Modal>
  );
});

const formStyle = css`
  .def_val,
  .def_type {
    display: inline-block;
    width: 11.05rem;
  }
  .def_type {
    margin-left: 0.9rem;
  }
  .default_wrapper {
    margin-bottom: 0;
  }

  .def_val {
    .ant-form-item-explain-error {
      width: 368px;
    }
  }
`;
