import { css } from '@emotion/react';
import { getPascalCaseName } from '@libs/util/convert';
import { dbNameValidator, getConvertRuleItem } from '@libs/util/error';
import { ConvertRuleItem, ConvertRuleItemWithKey, ConvertRuleSelectItemKey } from '@typesdef/convertRules';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Button, Divider, Form, Input, InputNumber, Modal, Select } from 'antd';
import React, { Fragment } from 'react';
import {
  convertDataTypeNumber,
  convertDefTypeCustom,
  ConvertItemTag,
  ConvertSelectCustom,
  ConvertSelectNotFound,
  ConvertViewInput,
} from '../ConvertCommon';
import useConvertRuleDefineTagAddEdit from '../hooks/useConvertRuleDefineTagAddEdit';

export interface ConvertRuleDefineTagAddEditProps {
  index?: number;
  data?: ConvertRuleItemWithKey;
  dataKeys?: number[];
  type: 'info' | 'header' | 'no_header' | 'regex';
  mode: 'edit' | 'add';
  itemList: (ConvertRuleSelectItemKey | 'row' | 'column')[];
}

export default React.memo(function ConvertRuleDefineTagAddEdit({
  visible,
  onClose,
  index,
  data,
  dataKeys,
  type,
  mode,
  itemList,
}: GlobalModalDefaultProps<ConvertRuleDefineTagAddEditProps>): JSX.Element {
  const {
    form,
    subForm,
    ruleList,
    isFetchingDefine,
    onDeleteTag,
    onEditTag,
    onAddTag,
    selectedTag,
    onOk,
    onAddEdit,
    onChangeDefType,
    onSearchDefine,
    onChangeDefine,
    onChangeDefineOther,
    searchInput,
    divRef,
    formDefine,
    formDefType,
    formDataType,
    defineOptions,
    dataTypeOptions,
    defTypeOptions,
    duplicateValidator,
  } = useConvertRuleDefineTagAddEdit({
    onClose,
    index,
    data,
    dataKeys,
    type,
    mode,
    itemList,
  });

  const title = getPascalCaseName([mode, ...type.split('_')]);
  const viewName = form.getFieldValue('name');
  const viewDataType = form.getFieldValue('data_type');
  const viewDefType = form.getFieldValue('def_type');
  const viewDefVal = form.getFieldValue('def_val');
  const viewOutCol = form.getFieldValue('output_column');
  const viewCoef = form.getFieldValue('coef');
  const viewUnit = form.getFieldValue('unit');
  const isViewInput = !formDefine || formDefine === 'custom';
  const isNotNullDefine = formDefine !== 'null';

  return (
    <Modal
      title={title}
      open={visible}
      onOk={onOk}
      okButtonProps={{ disabled: ruleList.length === 0 }}
      onCancel={onClose}
      width="600px"
      destroyOnClose
    >
      <div ref={divRef}>
        {itemList.includes('row') && (
          <Fragment>
            <Form form={subForm} labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              <Form.Item
                label="Row"
                name="row"
                required
                rules={[
                  getConvertRuleItem({ rule: 'empty', type: 'number' }),
                  getConvertRuleItem({
                    rule: 'duplicated',
                    type: 'number',
                    name: 'row exists',
                    validator: (rule, value) => {
                      return (dataKeys ?? []).find((item) => item === value) ? Promise.reject() : Promise.resolve();
                    },
                  }),
                ]}
              >
                <InputNumber
                  min={1}
                  max={999}
                  maxLength={3}
                  precision={0}
                  css={css`
                    width: 100%;
                  `}
                />
              </Form.Item>
            </Form>
            <Divider
              css={css`
                margin: 0.5rem 0 0.5rem 0;
              `}
            />
          </Fragment>
        )}
        {itemList.includes('column') && (
          <Fragment>
            <Form form={subForm} labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
              <Form.Item
                label="Total Columns"
                name="column"
                rules={[
                  getConvertRuleItem({
                    rule: 'duplicated',
                    type: 'number',
                    name: 'number of columns exists',
                    validator: (rule, value) => {
                      if (mode === 'add') {
                        return (dataKeys ?? []).find((item) => item === value) ? Promise.reject() : Promise.resolve();
                      } else {
                        return (dataKeys ?? [])
                          .filter((item, idx) => idx === data?.key ?? -1)
                          .find((item) => item === value)
                          ? Promise.reject()
                          : Promise.resolve();
                      }
                    },
                  }),
                ]}
              >
                <InputNumber
                  disabled
                  css={css`
                    width: 100%;
                  `}
                />
              </Form.Item>
            </Form>
            <Divider
              css={css`
                margin: 0.5rem 0 0.5rem 0;
              `}
            />
          </Fragment>
        )}
        <Form
          form={form}
          labelCol={{ span: 8 }}
          wrapperCol={{ span: 16 }}
          css={formStyle}
          disabled={selectedTag.mode === 'none'}
          onFinish={onAddEdit}
        >
          {itemList.includes('define') && (
            <Form.Item name="define" label="Column Define" className="define">
              <Select
                className="define__select"
                showSearch
                filterOption={(input, option) =>
                  option?.value
                    ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase())
                    : false
                }
                options={defineOptions}
                onChange={onChangeDefine}
                searchValue={searchInput ?? undefined}
                onSearch={onSearchDefine}
                dropdownRender={(menu) => (
                  <ConvertSelectCustom menu={menu} itemList={['custom', 'null']} onClick={onChangeDefineOther} />
                )}
                onFocus={() => onSearchDefine(null)}
                onBlur={() => onSearchDefine(null)}
                notFoundContent={<ConvertSelectNotFound isFetching={isFetchingDefine} />}
              />
            </Form.Item>
          )}
          {itemList.includes('name') && (
            <Form.Item
              name="name"
              label="Name"
              className="name"
              required
              rules={
                isNotNullDefine
                  ? [
                      getConvertRuleItem({ rule: 'empty', type: 'string' }),
                      getConvertRuleItem({ rule: 'max', type: 'string', max: 50 }),
                      getConvertRuleItem({
                        rule: 'duplicated',
                        type: 'string',
                        validator: duplicateValidator,
                      }),
                    ]
                  : undefined
              }
            >
              {isViewInput ? (
                <Input maxLength={50} />
              ) : (
                <ConvertViewInput title={viewName}>{viewName}</ConvertViewInput>
              )}
            </Form.Item>
          )}
          {itemList.includes('output_column') && (
            <Form.Item
              label="Output Column"
              name="output_column"
              className="output_column"
              required
              rules={
                isNotNullDefine
                  ? [
                      getConvertRuleItem({ rule: 'empty', type: 'string' }),
                      getConvertRuleItem({ rule: 'max', type: 'string', max: 50 }),
                      getConvertRuleItem({
                        rule: 'duplicated',
                        type: 'string',
                        validator: duplicateValidator,
                      }),
                      getConvertRuleItem({
                        rule: 'dbNaming',
                        type: 'string',
                      }),
                    ]
                  : undefined
              }
            >
              {isViewInput ? (
                <Input maxLength={50} />
              ) : (
                <ConvertViewInput title={viewOutCol}>{viewOutCol}</ConvertViewInput>
              )}
            </Form.Item>
          )}
          {itemList.includes('data_type') && (
            <Form.Item
              label="Data Type"
              name="data_type"
              className="data_type"
              required
              rules={isNotNullDefine ? [getConvertRuleItem({ rule: 'emptySelect', type: 'string' })] : undefined}
            >
              {isViewInput ? (
                <Select
                  showSearch
                  filterOption={(input, option) =>
                    option?.value
                      ? (option.value as unknown as string).toLowerCase().includes(input.toLowerCase())
                      : false
                  }
                  options={dataTypeOptions}
                />
              ) : (
                <ConvertViewInput title={viewDataType}>{viewDataType}</ConvertViewInput>
              )}
            </Form.Item>
          )}
          {itemList.includes('def_val') && (
            <Form.Item label="Default Value" className="default_wrapper">
              <Form.Item
                name="def_val"
                className="def_val"
                // rules={isNotNullDefine ? [{ required: true, message: 'Please input a default value!' }] : undefined}
              >
                {isViewInput ? (
                  <Input disabled={!convertDefTypeCustom.includes(formDefType ?? '')} />
                ) : (
                  <ConvertViewInput title={viewDefVal}>{viewDefVal}</ConvertViewInput>
                )}
              </Form.Item>
              <Form.Item name="def_type" className="def_type">
                {isViewInput ? (
                  <Select
                    showSearch
                    allowClear
                    filterOption={(input, option) =>
                      option?.value
                        ? (option.children as unknown as string).toLowerCase().includes(input.toLowerCase())
                        : false
                    }
                    onChange={onChangeDefType}
                    options={defTypeOptions}
                  />
                ) : (
                  <ConvertViewInput title={viewDefType ? `(${viewDefType})` : ''}>
                    {viewDefType ? `(${viewDefType})` : ''}
                  </ConvertViewInput>
                )}
              </Form.Item>
            </Form.Item>
          )}
          {itemList.includes('coef') && (
            <Form.Item name="coef" label="Coefficient" className="coef">
              {isViewInput ? (
                <InputNumber
                  css={css`
                    width: 100%;
                  `}
                  min={-99999999}
                  max={99999999}
                  maxLength={8}
                  disabled={!convertDataTypeNumber.includes(formDataType ?? '')}
                />
              ) : (
                <ConvertViewInput title={viewCoef}>{viewCoef}</ConvertViewInput>
              )}
            </Form.Item>
          )}
          {itemList.includes('unit') && (
            <Form.Item name="unit" label="Unit" className="unit">
              {isViewInput ? <Input /> : <ConvertViewInput title={viewUnit}>{viewUnit}</ConvertViewInput>}
            </Form.Item>
          )}
          <Form.Item
            css={css`
              display: flex;
              justify-content: flex-end;
            `}
          >
            {selectedTag.mode !== 'none' && (
              <Button type="primary" htmlType="submit">
                {selectedTag.mode === 'add' ? 'Add' : 'Edit'}
              </Button>
            )}
          </Form.Item>
        </Form>
        <Divider
          css={css`
            margin: 0.5rem 0 0.5rem 0;
          `}
        />
        <div>
          <ConvertItemTag<ConvertRuleItem, ConvertRuleItem['name']>
            list={ruleList}
            itemKey={'name'}
            onDelete={onDeleteTag}
            onEdit={onEditTag}
            onAdd={onAddTag}
            selected={selectedTag}
          />
        </div>
      </div>
    </Modal>
  );
});

const formStyle = css`
  .def_val,
  .def_type {
    display: inline-block;
    width: 11.05rem;
  }
  .def_type {
    margin-left: 0.9rem;
  }
  .default_wrapper {
    margin-bottom: 0;
  }

  .def_val {
    .ant-form-item-explain-error {
      width: 368px;
    }
  }
`;
