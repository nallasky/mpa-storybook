import { grey } from '@ant-design/colors';
import { css } from '@emotion/react';
import { getConvertPreviewSampleTable } from '@reducers/slices/convert';
import useTypedSelector from '@reducers/useTypedSelector';
import { TypeConvertRule } from '@typesdef/convertRules';
import { Badge, Space } from 'antd';
import { useSearchParams } from 'react-router-dom';
import ConvertRuleDefineCustom from './ConvertRuleDefineCustom';
import ConvertRuleDefineRegexSetting from './ConvertRuleDefineRegexSetting';
import ConvertRulePreview, { ConvertRulePreviewText } from './ConvertRulePreview';

export default function ConvertRuleDefineRegex() {
  const [searchParams] = useSearchParams();
  const inputType = searchParams.get('inputType') as TypeConvertRule;
  const previewTableData = useTypedSelector(getConvertPreviewSampleTable);

  return (
    <div css={csvStyle}>
      <div className="box">
        <div className="title">Sample Log</div>
        <div className="content">
          <ConvertRulePreviewText tableData={previewTableData} />
        </div>
      </div>
      <div className="box">
        <div className="title">Regex Define</div>
        <div className="content">
          <div className="sub-content">
            <div className="sub-title">
              <Space size={2}>
                <Badge color="blue" />
                Regex
              </Space>
            </div>
            <ConvertRuleDefineRegexSetting />
          </div>
          <div className="sub-content">
            <div className="sub-title">
              <Space size={2}>
                <Badge color="blue" />
                Custom
              </Space>
            </div>
            <ConvertRuleDefineCustom />
          </div>
        </div>
      </div>
      <ConvertRulePreview inputType={inputType} previewType="convert" />
    </div>
  );
}

export const csvStyle = css`
  display: flex;
  justify-content: center;
  flex-direction: column;
  margin-top: 1rem;
  /* padding: 0.5rem 0.5rem 0.5rem 0.5rem; */

  .box:nth-of-type(n + 1) {
    margin-bottom: 2rem;
  }

  .sub-content:nth-of-type(n + 1) {
    margin-bottom: 2rem;
  }

  .box {
    border: 1px solid ${grey[0]};
    border-radius: 3px;
    .title {
      display: flex;
      align-items: center;
      position: absolute;
      margin-top: -12px;
      margin-left: 1rem;
      padding-left: 1rem;
      padding-right: 16px;
      font-weight: 700;
      background-color: white;
    }
    .sub-title {
      font-weight: 700;
      margin-bottom: 0.5rem;
      color: ${grey[5]};
    }
    .content {
      margin-top: 1rem;
      margin-bottom: 1rem;
      margin: 1rem 1rem 1rem 1rem;
      & table {
        font-size: 0.75rem;
        &:first-of-type > thead > tr > th {
          background: #f0f5ff;
          font-weight: 700;
        }
      }
    }
  }
`;
