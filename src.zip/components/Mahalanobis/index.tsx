export { default } from './Mahalanobis';
