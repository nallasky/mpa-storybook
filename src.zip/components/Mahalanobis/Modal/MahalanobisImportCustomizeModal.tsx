import { css } from '@emotion/react';
import MahalanobisImportProvider from '@libs/context/MahalanobisImportProvider';
import type { ResUploadMahalanobisData } from '@typesdef/mahalanobis';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Modal } from 'antd';
import React from 'react';
import useRemoteJobStatusImportCustomize from '../hooks/useMahalanobisImportCustomizeModal';
import { MahalanobisImportCustomizeModalContent } from './MahalanobisImportCustomizeModalContent';

export interface MahalanobisImportCustomizeModalProps {
  data: ResUploadMahalanobisData[];
  mode?: 'import' | 'copy';
  pathId: number;
}

export default React.memo(function MahalanobisImportCustomizeModal({
  visible,
  onClose,
  data,
  mode = 'import',
  pathId,
}: GlobalModalDefaultProps<MahalanobisImportCustomizeModalProps>): JSX.Element {
  return (
    <MahalanobisImportProvider data={data} pathId={pathId}>
      <ModalWrapper visible={visible} onClose={onClose} mode={mode}>
        <MahalanobisImportCustomizeModalContent mode={mode} />
      </ModalWrapper>
    </MahalanobisImportProvider>
  );
});

type ModalWrapperProps = GlobalModalDefaultProps<{
  mode: 'import' | 'copy';
  children: React.ReactNode;
}>;

function ModalWrapper({ visible, onClose, mode, children }: ModalWrapperProps): JSX.Element {
  const { onOk, isLoadingImport, isError, modeText, itemData } = useRemoteJobStatusImportCustomize({
    visible,
    onClose,
    mode,
  });

  if (itemData.length === 0) {
    return (
      <Modal
        title={'Clear Mahalanobis'}
        open={visible}
        onOk={onOk}
        onCancel={onClose}
        width="500px"
        destroyOnClose
        cancelButtonProps={{
          disabled: isLoadingImport,
        }}
        okText="Clear"
        okButtonProps={{
          loading: isLoadingImport,
          disabled: isLoadingImport,
        }}
        maskClosable={!isLoadingImport}
      >
        <div
          css={css`
            display: flex;
            flex-direction: column;
            align-items: center;
            color: red;
          `}
        >
          <div>There are not mahalanobis items in imported excel file.</div>
          <div>if you import this file, all mahalanobis items are cleared.</div>
        </div>
      </Modal>
    );
  }

  return (
    <Modal
      title={`Customize ${modeText} Mahalanobis`}
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width="1000px"
      destroyOnClose
      cancelButtonProps={{
        disabled: isLoadingImport,
      }}
      okText={modeText}
      okButtonProps={{
        loading: isLoadingImport,
        disabled: isLoadingImport || isError,
      }}
      maskClosable={!isLoadingImport}
    >
      {children}
    </Modal>
  );
}
