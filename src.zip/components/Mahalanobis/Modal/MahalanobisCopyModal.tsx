import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Modal, Select, Space, Spin } from 'antd';
import React from 'react';
import useMahalanobisCopyModal from '../hooks/useMahalanobisCopyModal';

export default React.memo(function MahalanobisCopyModal({ visible, onClose }: GlobalModalDefaultProps): JSX.Element {
  const { form, onOk, registeredIdOptions, isFetching, isMutating } = useMahalanobisCopyModal({
    visible,
    onClose,
  });
  return (
    <Modal
      title={
        <Space>
          <div>Copy Mahalanobis</div> {isFetching && <Spin size="small" />}
        </Space>
      }
      open={visible}
      onOk={onOk}
      onCancel={onClose}
      width="550px"
      destroyOnClose
      cancelButtonProps={{
        disabled: isMutating,
      }}
      okText="Copy"
      okButtonProps={{
        loading: isMutating,
        disabled: isFetching,
      }}
      maskClosable={!isMutating}
    >
      <Form form={form} labelCol={{ span: 8 }} wrapperCol={{ span: 16 }} disabled={isFetching || isMutating}>
        <Form.Item
          label="Select Source"
          name="source"
          required
          rules={[{ required: true, message: 'Please select a source!' }]}
        >
          <Select
            placeholder="Select a Source"
            showSearch
            filterOption={(input, option) =>
              option ? (option.label as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
            }
            options={registeredIdOptions}
            loading={isFetching}
          />
        </Form.Item>
        <Form.Item
          label="Select Target"
          name="target"
          required
          rules={[{ required: true, message: 'Please select a target!' }]}
        >
          <Select
            placeholder="Select a Target"
            showSearch
            filterOption={(input, option) =>
              option ? (option.label as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
            }
            options={registeredIdOptions}
            loading={isFetching}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
});
