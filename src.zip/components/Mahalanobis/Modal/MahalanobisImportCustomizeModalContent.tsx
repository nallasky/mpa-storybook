import { ExclamationCircleOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { useMahalanobisImportContext } from '@libs/context/MahalanobisImportProvider';
import { useGetMahalanobisItemOptions } from '@libs/query/mahalanobis';
import { openNotification } from '@libs/util/notification';
import type { ResUploadMahalanobisData } from '@typesdef/mahalanobis';
import { Badge, Menu, MenuProps, Select, Space } from 'antd';
import { LabeledValue } from 'antd/es/select';
import React, { Fragment, useEffect } from 'react';

export function MahalanobisImportCustomizeModalContent({ mode }: { mode: 'import' | 'copy' }) {
  const { originData, itemData, itemIndex, curItem, errorIndexList, setItemIndex, setEquipment } =
    useMahalanobisImportContext();

  const menuItems: MenuProps['items'] = itemData.map(({ item }, index) => {
    const isError = errorIndexList.includes(index);

    return getItem(
      <div css={menuStyle(isError)}>
        <div className="name" title={item}>
          {item}
        </div>
        {isError && (
          <div className="error">
            <ExclamationCircleOutlined css={[styleRed]} />
            <div className="error-msg">No Equipment Name</div>
          </div>
        )}
      </div>,
      index,
    );
  });

  useEffect(() => {
    if (itemData.length > 0) {
      setItemIndex(0);
    }
  }, []);

  return (
    <div css={style}>
      <Menu
        selectedKeys={itemIndex !== null ? [itemIndex.toString()] : []}
        onClick={(value) => {
          setItemIndex(+value.key);
        }}
        mode="inline"
        items={menuItems}
        css={css`
          .ant-menu-item {
            height: 3rem;
          }
        `}
      />
      <MahalanobisImportCustomizeContentInfo />
    </div>
  );
}

const style = css`
  display: flex;
  .ant-menu {
    width: 350px;
    height: 40.125rem;
    overflow-x: hidden;
    overflow-y: auto;
  }
  width: 100%;
`;

const styleRed = css`
  color: red;
`;

type MenuItem = Required<MenuProps>['items'][number];

function getItem(
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[],
  type?: 'group',
): MenuItem {
  return {
    key,
    icon,
    children,
    label,
    type,
  } as MenuItem;
}

const menuStyle = (isError: boolean) => css`
  display: flex;
  flex-direction: column;
  justify-content: center;

  .name {
    width: 210px;
    align-items: center;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    ${isError
      ? css`
          line-height: 1.5rem;
          height: 1.5rem;
        `
      : css`
          line-height: 3rem;
          height: 3rem;
        `}
  }

  .error {
    color: red;
    font-size: 0.75rem;
    display: flex;
    align-items: center;
    height: 1rem;
    .error-msg {
      margin-left: 0.25rem;
      height: 1rem;
      line-height: 1rem;
    }
  }
`;

export function MahalanobisImportCustomizeContentInfo() {
  const { originData, itemData, itemIndex, curItem, errorIndexList, setItemIndex, setEquipment, pathId } =
    useMahalanobisImportContext();
  const textObj = getItemText(curItem);

  const { data: options, isFetching: isFetchingOptions } = useGetMahalanobisItemOptions(pathId, {
    enabled: Boolean(pathId && curItem),
    onError: (error) => {
      openNotification('error', 'Error', `Failed to get mahalanobis table options!`, error);
    },
  });

  const isErrorEquipment = errorIndexList.includes(itemIndex ?? -1);

  return (
    <div css={infoStyle}>
      {itemIndex !== null && (
        <Fragment>
          <ItemWrapper title="Original Equipment Name">
            <div className="text" title={textObj.original_equipment_name}>
              {textObj.original_equipment_name}
            </div>
          </ItemWrapper>
          <ItemWrapper title="Equipment Name" errorMsg={isErrorEquipment ? 'Please Select a Equipment Name!' : ''}>
            <Select
              style={{ width: '100%' }}
              options={options?.equipment ?? []}
              value={curItem?.equipment_id}
              onSelect={(value: string, option: LabeledValue) => {
                setEquipment({
                  itemIndex,
                  equipmentId: option.value as string,
                  equipmentName: option.label as string,
                });
              }}
              status={isErrorEquipment ? 'error' : ''}
              loading={isFetchingOptions}
              disabled={isFetchingOptions}
            />
          </ItemWrapper>
          <ItemWrapper title="Target Table">
            <div className="text" title={textObj.table_name}>
              {textObj.table_name}
            </div>
          </ItemWrapper>
          <ItemWrapper title="Column Name 1">
            <div className="text" title={textObj.colname1}>
              {textObj.colname1}
            </div>
          </ItemWrapper>
          <ItemWrapper title="Column Name 2">
            <div className="text" title={textObj.colname2}>
              {textObj.colname2}
            </div>
          </ItemWrapper>
          <ItemWrapper title="Covariance">
            <div className="text" title={textObj.covariance}>
              {textObj.covariance}
            </div>
          </ItemWrapper>
          <ItemWrapper title="Mean 1">
            <div className="text" title={textObj.mean1}>
              {textObj.mean1}
            </div>
          </ItemWrapper>
          <ItemWrapper title="Mean 2">
            <div className="text" title={textObj.mean2}>
              {textObj.mean2}
            </div>
          </ItemWrapper>
          <ItemWrapper title="Variance 1">
            <div className="text" title={textObj.variance1}>
              {textObj.variance1}
            </div>
          </ItemWrapper>
          <ItemWrapper title="Variance 2">
            <div className="text" title={textObj.variance2}>
              {textObj.variance2}
            </div>
          </ItemWrapper>
          <ItemWrapper title="Item">
            <div className="text" title={textObj.item}>
              {textObj.item}
            </div>
          </ItemWrapper>
          <ItemWrapper title="Memo">
            <div className="text" title={textObj.memo}>
              {textObj.memo}
            </div>
          </ItemWrapper>
        </Fragment>
      )}
    </div>
  );
}

const getItemText = (value: ResUploadMahalanobisData | null) => {
  if (!value) {
    return {
      original_equipment_name: '',
      equipment_name: '',
      table_name: '',
      item: '',
      colname1: '',
      colname2: '',
      covariance: '',
      mean1: '',
      mean2: '',
      variance1: '',
      variance2: '',
      memo: '',
    };
  }

  const {
    original_equipment_name,
    equipment_name,
    table_name,
    item,
    colname1,
    colname2,
    covariance,
    mean1,
    mean2,
    variance1,
    variance2,
    memo,
  } = value;

  return {
    original_equipment_name: `${original_equipment_name}`,
    equipment_name: `${equipment_name}`,
    table_name: `${table_name}`,
    item: `${item}`,
    colname1: `${colname1}`,
    colname2: `${colname2}`,
    covariance: `${covariance}`,
    mean1: `${mean1}`,
    mean2: `${mean2}`,
    variance1: `${variance1}`,
    variance2: `${variance2}`,
    memo: `${memo}`,
  };
};

const infoStyle = css`
  display: flex;
  flex-direction: column;
  margin-left: 1rem;
  width: 100%;

  .item:not(:nth-last-of-type(1)) {
    margin-bottom: 1rem;
  }
`;

function ItemWrapper({
  title,
  children,
  direction = 'horizontal',
  errorMsg,
}: {
  title: string;
  children: React.ReactNode;
  direction?: 'vertical' | 'horizontal';
  errorMsg?: string;
}) {
  return (
    <div css={itemWrapperStyle(direction)} className="item">
      {direction === 'horizontal' ? (
        <Fragment>
          <div className="set-item">
            <div className="title">
              <Space size={2}>
                <Badge color="blue" />
                {title}
              </Space>
            </div>
            <div className="value">{children}</div>
          </div>
          <div className="error">{errorMsg}</div>
        </Fragment>
      ) : (
        <Fragment>
          <div className="set-item">
            <div className="title">
              <Space size={2}>
                <Badge color="blue" />
                {title}
              </Space>
            </div>
            <div className="error">{errorMsg}</div>
          </div>
          <div className="value">{children}</div>
        </Fragment>
      )}
    </div>
  );
}

const itemWrapperStyle = (direction: 'vertical' | 'horizontal') => css`
  ${direction === 'horizontal' &&
  css`
    display: flex;
    flex-direction: column;
    .set-item {
      display: flex;
      .title {
        width: 15rem;
      }
      .value {
        width: 25rem;
        .text {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
        }
      }
    }
    .error {
      height: 1rem;
      margin-left: 15rem;
      color: red;
    }
  `}
  ${direction === 'vertical' &&
  css`
    display: flex;
    flex-direction: column;
    .set-item {
      display: flex;
      flex-direction: row;
      .title {
        width: 10rem;
      }
      .error {
        width: 25rem;
        color: red;
      }
    }
    .value {
      width: 45rem;
    }
  `}
`;
