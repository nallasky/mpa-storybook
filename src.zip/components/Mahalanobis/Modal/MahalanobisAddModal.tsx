import type { ReqAddMahalanobisData } from '@typesdef/mahalanobis';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Modal, Select } from 'antd';
import useMahalanobisAddModal from '../hooks/useMahalanobisAddModal';

export default function MahalanobisAddModal({ onClose, visible }: GlobalModalDefaultProps): JSX.Element {
  const { form, onFinish, isFetchingSiteIdList, isLoadingAdd, unregisteredSiteIdOptions } = useMahalanobisAddModal({
    onClose,
    visible,
  });

  return (
    <Modal
      title="Add Mahalanobis"
      open={visible}
      okText="Add"
      onOk={form.submit}
      okButtonProps={{ loading: isLoadingAdd, disabled: isFetchingSiteIdList }}
      onCancel={onClose}
      cancelButtonProps={{
        disabled: isLoadingAdd,
      }}
      closable={!isLoadingAdd}
      maskClosable={!isLoadingAdd}
    >
      <Form<ReqAddMahalanobisData>
        form={form}
        onFinish={onFinish}
        layout="vertical"
        disabled={isFetchingSiteIdList || isLoadingAdd}
      >
        <Form.Item label="User-Fab Name" name="siteId">
          <Select
            options={unregisteredSiteIdOptions}
            showSearch
            filterOption={(input, option) =>
              option ? (option.label as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
            }
          />
        </Form.Item>
      </Form>
    </Modal>
  );
}
