import FileImportModal, { FileImportModalProps } from '@components/common/atoms/FileImportModal/FileImportModal';
import { API_URL, PAGE_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { useDeleteMahalanobis, useGetMahalanobisExport, useGetMahalanobisList } from '@libs/query/mahalanobis';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { initializeUploadedMahalanobisData } from '@libs/util/mahalanobis';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { MahalanobisData, ResUploadMahalanobisData } from '@typesdef/mahalanobis';
import { AxiosError } from 'axios';
import saveAs from 'file-saver';
import { useNavigate } from 'react-router-dom';
import MahalanobisAddModal from '../Modal/MahalanobisAddModal';
import MahalanobisCopyModal from '../Modal/MahalanobisCopyModal';
import MahalanobisImportCustomizeModal, {
  MahalanobisImportCustomizeModalProps,
} from '../Modal/MahalanobisImportCustomizeModal';

export default function useMahalanobis() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { openModal } = useModals();
  const { data: mahaList, isFetching: isFetchingMahaList } = useGetMahalanobisList({
    onError: (error) => {
      openNotification('error', 'Error', 'Failed to get mahalanobis list!', error as AxiosError);
    },
  });

  const { mutateAsync: mutateAsyncDelete } = useDeleteMahalanobis({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to delete mahalanobis.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete mahalanobis!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_MAHALANOBIS_LIST], { exact: true });
    },
  });

  const { mutateAsync: mutateAsyncExport } = useGetMahalanobisExport({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to export mahalanobis.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to export mahalanobis!`, error);
    },
  });

  const onDelete = async ({ id }: MahalanobisData) => {
    try {
      await mutateAsyncDelete(id);
    } catch (e) {
      console.error(e);
    }
  };

  const onExport = async ({ id }: MahalanobisData) => {
    try {
      const { data, fileName } = await mutateAsyncExport(id);
      saveAs(data, fileName);
    } catch (e) {
      console.error(e);
    }
  };

  const openImportModal = ({ id, companyFabName }: MahalanobisData) => {
    openModal<FileImportModalProps<ResUploadMahalanobisData[]>>(MODAL_NAME.MAHALANOBIS.IMPORT_UPLOAD, FileImportModal, {
      title: `Upload Mahalanobis File For '${companyFabName}'`,
      url: API_URL.POST_MAHALANOBIS_UPLOAD_EXPORT_FILE(id),
      afterError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to upload mahalanobis file!`, error);
      },
      afterSuccess: (data) => {
        openModal<MahalanobisImportCustomizeModalProps>(
          MODAL_NAME.MAHALANOBIS.IMPORT_CUSTOMIZE,
          MahalanobisImportCustomizeModal,
          {
            data: initializeUploadedMahalanobisData(data),
            mode: 'import',
            pathId: id,
          },
        );
      },
      mutationKey: [MUTATION_KEY.JOB_REMOTE_IMPORT_UPLOAD],
    });
  };

  const openAddModal = () => {
    openModal(MODAL_NAME.MAHALANOBIS.ADD, MahalanobisAddModal);
  };

  const openCopyModal = () => {
    openModal(MODAL_NAME.MAHALANOBIS.COPY, MahalanobisCopyModal);
  };

  const moveEditPage = ({ id, companyFabName }: MahalanobisData) => {
    navigate(PAGE_URL.RULES_ANALYSIS_MAHALANOBIS_EDIT(id, companyFabName));
  };

  return {
    mahaList,
    isFetchingMahaList,
    openAddModal,
    onDelete,
    onExport,
    openImportModal,
    moveEditPage,
    openCopyModal,
  };
}
