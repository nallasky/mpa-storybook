import {
  useGetMahalanobisItemById,
  useGetMahalanobisItemOptions,
  usePostMahalanobisItemAdd,
  usePutMahalanobisItemEdit,
} from '@libs/query/mahalanobis';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { MahalanobisItemData, ReqMahalanobisItemData } from '@typesdef/mahalanobis';
import type { Rule, RuleObject } from 'antd/es/form';
import { useForm, useWatch } from 'antd/es/form/Form';
import { useEffect, useMemo, useState } from 'react';
import type { MahalanobisAddEditDrawerProps } from '../Drawer/MahalanobisAddEditDrawer';

export interface MahalanobisAddEditFormData extends Omit<MahalanobisItemData, 'id'> {}

export default function useMahalanobisAddEditDrawer({
  params: { editId, open, parentId },
  onClose,
}: MahalanobisAddEditDrawerProps) {
  const [form] = useForm<MahalanobisAddEditFormData>();
  const selectedTarget = useWatch<string | undefined>('table_name', form);
  const mode = editId ? 'edit' : 'add';
  const [isOpenSelect, setIsOpenSelect] = useState({ colname1: false, colname2: false });
  const queryClient = useQueryClient();

  const { data: item, isFetching: isFetchingItem } = useGetMahalanobisItemById(parentId, editId ?? -1, {
    enabled: Boolean(parentId && editId && open),
    onSuccess: (data) => {
      form.setFieldsValue({ ...data });
    },
  });

  const { data: options, isFetching: isFetchingOptions } = useGetMahalanobisItemOptions(parentId, {
    enabled: Boolean(parentId && open),
    onError: (error) => {
      openNotification('error', 'Error', `Failed to get mahalanobis table options `, error);
    },
  });

  const mutation = editId ? usePutMahalanobisItemEdit : usePostMahalanobisItemAdd;
  const { mutate: mutateAddEdit, isLoading: isLoadingAddEdit } = mutation({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to ${mode} mahalanobis item.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to ${mode} mahalanobis item!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_MAHALANOBIS_ITEM_LIST, parentId]);
      onClose();
    },
  });

  const equipmentOptions = useMemo(() => options?.equipment ?? [], [options]);
  const targetOptions = useMemo(() => options?.target ?? [], [options]);
  const colNameOptions = useMemo(() => {
    if (!selectedTarget || !options?.colname) {
      return [];
    }

    if (!options.colname[selectedTarget]) {
      return [];
    }

    return options.colname[selectedTarget];
  }, [options, selectedTarget]);

  const setOpenColName = (name: 'colname1' | 'colname2') => (open: boolean) => {
    setIsOpenSelect((prev) => ({ ...prev, [name]: open }));
  };

  const onSaveColName = (name: 'colname1' | 'colname2') => (value: string) => {
    form.setFieldValue(name, value);
  };

  const onSelectTarget = (value: string) => {
    form.setFieldsValue({
      table_name: value,
      colname1: undefined,
      colname2: undefined,
    });
  };

  const validateReqData = async (): Promise<ReqMahalanobisItemData> => {
    try {
      const reqData = await form.validateFields();
      const equipmentName =
        equipmentOptions.find((item) => item.label === reqData.equipment_name)?.label?.toString() ?? '';

      return {
        parentId,
        ...reqData,
        id: editId,
        equipment_name: equipmentName,
      };
    } catch (error) {
      console.error(error);
      throw new Error('validation failed!');
    }
  };

  const onSave = async () => {
    try {
      const reqData = await validateReqData();
      mutateAddEdit(reqData);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (open) {
      form.resetFields();
    }
  }, [open, form]);

  return {
    form,
    equipmentOptions,
    targetOptions,
    colNameOptions,
    isFetching: isFetchingItem || isFetchingOptions,
    isMutating: isLoadingAddEdit,
    onSelectTarget,
    selectedTarget,
    onSave,
    isOpenSelect,
    setOpenColName,
    onSaveColName,
  };
}

const inputNumberRules = (name: string): Rule[] => [
  {
    type: 'number',
    required: true,
    message: `Please input a ${name}!`,
  },
];

const inputRules = (name: string): Rule[] => [
  {
    type: 'string',
    required: true,
    message: `Please input a ${name}!`,
  },
];

const selectRules = (name: string, type: NonNullable<RuleObject['type']>): Rule[] => [
  {
    type,
    required: true,
    message: `Please select a ${name}!`,
  },
];

type RuleKeyType = keyof Pick<
  MahalanobisAddEditFormData,
  | 'equipment_name'
  | 'table_name'
  | 'colname1'
  | 'colname2'
  | 'covariance'
  | 'mean1'
  | 'mean2'
  | 'variance1'
  | 'variance2'
  | 'item'
>;

type PlaceHolderKeyType = keyof Pick<
  MahalanobisAddEditFormData,
  | 'equipment_name'
  | 'table_name'
  | 'colname1'
  | 'colname2'
  | 'covariance'
  | 'mean1'
  | 'mean2'
  | 'variance1'
  | 'variance2'
  | 'item'
  | 'memo'
>;

export const mahalanobisRule: Record<RuleKeyType, Rule[]> = {
  equipment_name: selectRules('equipment name', 'string'),
  table_name: selectRules('target table', 'string'),
  colname1: inputRules('column name 1'),
  colname2: inputRules('column name 2'),
  covariance: inputNumberRules('covariance'),
  mean1: inputNumberRules('mean 1'),
  mean2: inputNumberRules('mean 2'),
  variance1: inputNumberRules('variance 1'),
  variance2: inputNumberRules('variance 2'),
  item: inputRules('item'),
};

export const mahalanobisPlaceHolder: Record<PlaceHolderKeyType, string> = {
  equipment_name: 'Select a equipment name.',
  table_name: 'Select a target table.',
  colname1: 'Input a column name 1.',
  colname2: 'Input a column name 2.',
  covariance: 'Input a covariance.',
  mean1: 'Input a mean 1.',
  mean2: 'Input a mean 2.',
  variance1: 'Input a variance 1.',
  variance2: 'Input a variance 2.',
  item: 'Input a item.',
  memo: 'Input a memo.',
};
