import { useGetMahalanobisRegisterStatusList, usePostMahalanobisAdd } from '@libs/query/mahalanobis';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { ReqAddMahalanobisData } from '@typesdef/mahalanobis';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { useForm } from 'antd/es/form/Form';
import { LabeledValue } from 'antd/es/select';
import { AxiosError } from 'axios';

export default function useMahalanobisAddModal({ onClose, visible }: GlobalModalDefaultProps) {
  const [form] = useForm<ReqAddMahalanobisData>();
  const queryClient = useQueryClient();

  const { data: siteIdList, isFetching: isFetchingSiteIdList } = useGetMahalanobisRegisterStatusList('siteId', {
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to get user-fab name list!`, error);
    },
  });

  const unregisteredSiteIdOptions: LabeledValue[] = siteIdList?.unregistered ?? [];

  const { mutate: mutateAdd, isLoading: isLoadingAdd } = usePostMahalanobisAdd({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to add mahalanobis!`, error);
    },
    onSuccess: () => {
      openNotification('success', 'Success', `Success to add mahalanobis.`);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_MAHALANOBIS_LIST], { exact: true });
      onClose();
    },
  });

  const onFinish = (values: ReqAddMahalanobisData) => {
    mutateAdd(values);
  };

  return {
    form,
    onFinish,
    isFetchingSiteIdList,
    isLoadingAdd,
    unregisteredSiteIdOptions,
  };
}
