import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { useGetMahalanobisRegisterStatusList, usePostMahalanobisJobCopy } from '@libs/query/mahalanobis';
import { QUERY_KEY } from '@libs/query/queryKey';
import { initializeUploadedMahalanobisData } from '@libs/util/mahalanobis';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { useForm } from 'antd/es/form/Form';
import type { AxiosError } from 'axios';
import MahalanobisImportCustomizeModal, {
  MahalanobisImportCustomizeModalProps,
} from '../Modal/MahalanobisImportCustomizeModal';

export default function useMahalanobisCopyModal({ visible, onClose }: GlobalModalDefaultProps) {
  const [form] = useForm<{
    source: number;
    target: number;
  }>();
  const queryClient = useQueryClient();
  const { openModal } = useModals();

  const { data: idOptions, isFetching } = useGetMahalanobisRegisterStatusList('id', {
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', `Failed to get user-fab name list!`, error);
    },
  });

  const { mutate: mutateCopy, isLoading: isMutating } = usePostMahalanobisJobCopy({
    onSuccess: (data) => {
      const { target } = form.getFieldsValue();
      onClose();
      openModal<MahalanobisImportCustomizeModalProps>(
        MODAL_NAME.MAHALANOBIS.IMPORT_CUSTOMIZE,
        MahalanobisImportCustomizeModal,
        {
          data: initializeUploadedMahalanobisData(data),
          mode: 'copy',
          pathId: target,
        },
      );
    },
    onError: (error) => {
      openNotification('error', 'Error', 'Failed to get mahalanobis from target!', error);
      queryClient.invalidateQueries([QUERY_KEY.RULES_MAHALANOBIS_LIST]);
      onClose();
    },
  });

  const onOk = async () => {
    if (!(await form.validateFields())) {
      return;
    }
    const { source } = form.getFieldsValue();
    mutateCopy(source);
  };

  return { form, onOk, registeredIdOptions: idOptions?.registered ?? [], isFetching, isMutating };
}
