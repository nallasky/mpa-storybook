import { PAGE_URL } from '@constants/constants';
import { useDeleteMahalanobisItem, useGetMahalanobisItemList } from '@libs/query/mahalanobis';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { MahalanobisItemData } from '@typesdef/mahalanobis';
import { AxiosError } from 'axios';
import { useEffect, useReducer } from 'react';
import { useParams, useSearchParams, Navigate, useNavigate } from 'react-router-dom';

export interface MahalanobisAddEditDrawerState {
  parentId: number;
  open: boolean;
  editId: number;
}

function addEditDrawerStateReducer(
  state: MahalanobisAddEditDrawerState,
  payload: Partial<MahalanobisAddEditDrawerState>,
): MahalanobisAddEditDrawerState {
  return {
    ...state,
    ...payload,
  };
}

const initialAddEditDrawerState: MahalanobisAddEditDrawerState = {
  editId: 0,
  open: false,
  parentId: 0,
};

export default function useMahalanobisEdit() {
  const { id } = useParams();
  const parentId = id ? +id : 0;
  const [searchParams] = useSearchParams();
  const name = searchParams.get('name');
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const [addEditDrawerParams, setAddEditDrawerParams] = useReducer(
    addEditDrawerStateReducer,
    initialAddEditDrawerState,
  );

  const { data: mahaItemList, isFetching: isFetchingMahaItemList } = useGetMahalanobisItemList(parentId, {
    enabled: !!id,
    onError: (error) => {
      const newError = error instanceof AxiosError ? error : undefined;
      openNotification('error', 'Error', `Failed to get mahalanobis item list!`, newError);
    },
  });

  const { mutateAsync: mutateDeleteAsync } = useDeleteMahalanobisItem({
    onSuccess: (data) => {
      openNotification('success', 'Success', `Succeed to delete mahalanobis item.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete mahalanobis item!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_MAHALANOBIS_ITEM_LIST, parentId]);
    },
  });

  const openAddDrawer = () => {
    setAddEditDrawerParams({ open: true, editId: 0 });
  };

  const openEditDrawer = ({ id }: MahalanobisItemData) => {
    setAddEditDrawerParams({ open: true, editId: id });
  };

  const onCloseEditDrawer = () => {
    setAddEditDrawerParams({ open: false, editId: 0 });
  };

  const onDelete = ({ id }: MahalanobisItemData) => mutateDeleteAsync({ parentId, id });

  const backToParentPage = () => {
    navigate(PAGE_URL.RULES_ANALYSIS_MAHALANOBIS);
  };

  useEffect(() => {
    setAddEditDrawerParams({ parentId });
  }, [parentId]);

  return {
    name,
    mahaItemList,
    isFetchingMahaItemList,
    addEditDrawerParams,
    openAddDrawer,
    openEditDrawer,
    onCloseEditDrawer,
    onDelete,
    backToParentPage,
  };
}
