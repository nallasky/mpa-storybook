import { useMahalanobisImportContext } from '@libs/context/MahalanobisImportProvider';
import { usePostMahalanobisImportCustomize } from '@libs/query/mahalanobis';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { GlobalModalDefaultProps } from '@typesdef/modal';

type useHookProps = GlobalModalDefaultProps<{
  mode: 'import' | 'copy';
}>;

export default function useMahalanobisImportCustomizeModal({ visible, onClose, mode }: useHookProps) {
  const { curItem, errorIndexList, itemData, itemIndex, originData, pathId } = useMahalanobisImportContext();
  const queryClient = useQueryClient();
  const isError = errorIndexList.length > 0;
  const modeText = mode === 'import' ? 'Import' : 'Copy';

  const { mutate: mutateImport, isLoading: isLoadingImport } = usePostMahalanobisImportCustomize({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to ${mode} mahalanobis.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to ${mode} mahalanobis!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.RULES_MAHALANOBIS_LIST]);
      onClose();
    },
  });

  const onOk = () => {
    mutateImport({
      pathId,
      reqData: itemData,
    });
  };

  return { onOk, isLoadingImport, isError, modeText, itemData };
}
