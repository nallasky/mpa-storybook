import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import TableScrollTitle from '@components/common/atoms/TableScrollTitle';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { MahalanobisItemData } from '@typesdef/mahalanobis';
import { PageHeader, Popconfirm, Table } from 'antd';
import { useRef } from 'react';
import MahalanobisAddEditDrawer from './Drawer/MahalanobisAddEditDrawer';
import useMahalanobisEdit from './hooks/useMahalanobisEdit';

export default function MahalanobisEdit() {
  const tableRef = useRef<HTMLDivElement>(null);
  const {
    name,
    mahaItemList,
    isFetchingMahaItemList,
    addEditDrawerParams,
    openAddDrawer,
    openEditDrawer,
    onCloseEditDrawer,
    onDelete,
    backToParentPage,
  } = useMahalanobisEdit();

  const renderTitle = () => (
    <TableHeader title={<TableHeaderTitle total={mahaItemList?.length ?? 0} />}>
      <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddDrawer}>
        Add
      </AntdButton>
    </TableHeader>
  );

  const renderEdit = (value: number, record: MahalanobisItemData, index: number) => {
    return (
      <Popconfirm title="Are you sure to edit mahalanobis item?" onConfirm={() => openEditDrawer(record)} okText="Edit">
        <EditOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderDelete = (value: number, record: MahalanobisItemData, index: number) => {
    return (
      <Popconfirm title="Are you sure to delete mahalanobis item?" onConfirm={() => onDelete(record)} okText="Delete">
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div
      css={css`
        width: 100%;
        display: flex;
        flex-direction: column;
      `}
    >
      <PageHeader
        onBack={backToParentPage}
        title={`Mahalanobis Items (${name})`}
        css={css`
          padding: 0 0 0.5rem 0;
        `}
      />
      <Table<MahalanobisItemData>
        ref={tableRef}
        rowKey={'id'}
        dataSource={mahaItemList ?? []}
        bordered
        title={renderTitle}
        size="middle"
        pagination={{
          position: ['bottomCenter'],
        }}
        loading={isFetchingMahaItemList}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
        scroll={{ x: 'max-content' }}
      >
        <Table.Column<MahalanobisItemData>
          {...columnProps.equipment_name}
          title={<TableScrollTitle title="Equipment Name" ref={tableRef} direction="left" />}
        />
        <Table.Column<MahalanobisItemData> {...columnProps.table_name} />
        <Table.Column<MahalanobisItemData> {...columnProps.covariance} />
        <Table.Column<MahalanobisItemData> {...columnProps.colname1} />
        <Table.Column<MahalanobisItemData> {...columnProps.colname2} />
        <Table.Column<MahalanobisItemData> {...columnProps.mean1} />
        <Table.Column<MahalanobisItemData> {...columnProps.mean2} />
        <Table.Column<MahalanobisItemData> {...columnProps.variance1} />
        <Table.Column<MahalanobisItemData> {...columnProps.variance2} />
        <Table.Column<MahalanobisItemData> {...columnProps.item} />
        <Table.Column<MahalanobisItemData> {...columnProps.memo} />
        <Table.Column<MahalanobisItemData> {...columnProps.edit} render={renderEdit} />
        <Table.Column<MahalanobisItemData>
          {...columnProps.delete}
          render={renderDelete}
          title={<TableScrollTitle title="Delete" ref={tableRef} direction="right" />}
        />
      </Table>
      <MahalanobisAddEditDrawer params={addEditDrawerParams} onClose={onCloseEditDrawer} />
    </div>
  );
}

const TdContent = styled.div<{ width: number }>`
  width: ${({ width }) => width}px;
  text-overflow: ellipsis;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
`;

type ColumnName =
  | 'equipment_name'
  | 'table_name'
  | 'covariance'
  | 'colname1'
  | 'colname2'
  | 'mean1'
  | 'mean2'
  | 'variance1'
  | 'variance2'
  | 'item'
  | 'memo'
  | 'edit'
  | 'delete';

const columnProps: TableColumnPropsType<MahalanobisItemData, ColumnName> = {
  equipment_name: {
    key: 'equipment_name',
    title: <TableColumnTitle>Equipment Name</TableColumnTitle>,
    dataIndex: 'equipment_name',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'equipment_name'),
    },
    render: (value: string) => (
      <TdContent title={`${value}`} width={200}>
        {value}
      </TdContent>
    ),
    fixed: 'left',
    width: 200,
  },
  table_name: {
    key: 'table_name',
    title: <TableColumnTitle>Target Table</TableColumnTitle>,
    dataIndex: 'table_name',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'table_name'),
    },
    render: (value: string) => (
      <TdContent title={`${value}`} width={200}>
        {value}
      </TdContent>
    ),
    width: 200,
  },
  covariance: {
    key: 'covariance',
    title: <TableColumnTitle>Covariance</TableColumnTitle>,
    dataIndex: 'covariance',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'covariance'),
    },
    render: (value: number) => (
      <TdContent title={`${value}`} width={100}>
        {value}
      </TdContent>
    ),
    width: 100,
  },
  colname1: {
    key: 'colname1',
    dataIndex: 'colname1',
    title: <TableColumnTitle>Column Name 1</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'colname1'),
    },
    render: (value: number) => (
      <TdContent title={`${value}`} width={250}>
        {value}
      </TdContent>
    ),
    width: 250,
  },
  colname2: {
    key: 'colname2',
    dataIndex: 'colname2',
    title: <TableColumnTitle>Column Name 2</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'colname2'),
    },
    render: (value: number) => (
      <TdContent title={`${value}`} width={250}>
        {value}
      </TdContent>
    ),
    width: 250,
  },
  mean1: {
    key: 'mean1',
    dataIndex: 'mean1',
    title: <TableColumnTitle>Mean 1</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'mean1'),
    },
    render: (value: number) => (
      <TdContent title={`${value}`} width={100}>
        {value}
      </TdContent>
    ),
    width: 100,
  },
  mean2: {
    key: 'mean2',
    dataIndex: 'mean2',
    title: <TableColumnTitle>Mean 2</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'mean2'),
    },
    render: (value: number) => (
      <TdContent title={`${value}`} width={100}>
        {value}
      </TdContent>
    ),
    width: 100,
  },
  variance1: {
    key: 'variance1',
    dataIndex: 'variance1',
    title: <TableColumnTitle>Variance 1</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'variance1'),
    },
    render: (value: number) => (
      <TdContent title={`${value}`} width={100}>
        {value}
      </TdContent>
    ),
    width: 100,
  },
  variance2: {
    key: 'variance2',
    dataIndex: 'variance2',
    title: <TableColumnTitle>Variance 2</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'variance2'),
    },
    render: (value: number) => (
      <TdContent title={`${value}`} width={100}>
        {value}
      </TdContent>
    ),
    width: 100,
  },
  item: {
    key: 'item',
    dataIndex: 'item',
    title: <TableColumnTitle>item</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'item'),
    },
    render: (value: number) => (
      <TdContent title={`${value}`} width={200}>
        {value}
      </TdContent>
    ),
    width: 200,
  },
  memo: {
    key: 'memo',
    dataIndex: 'memo',
    title: <TableColumnTitle>Memo</TableColumnTitle>,
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'memo'),
    },
    render: (value: number) => (
      <TdContent title={`${value}`} width={200}>
        {value}
      </TdContent>
    ),
    width: 200,
  },

  edit: {
    key: 'edit',
    dataIndex: 'id',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    align: 'center',
    fixed: 'right',
    width: 80,
  },

  delete: {
    key: 'delete',
    dataIndex: 'id',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    fixed: 'right',
    width: 100,
  },
};
