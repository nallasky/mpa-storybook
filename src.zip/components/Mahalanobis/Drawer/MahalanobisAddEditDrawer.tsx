import AntdButton from '@components/common/atoms/AntdButton';
import SearchPopover from '@components/common/atoms/SelectPopover';
import { css } from '@emotion/react';
import { Drawer, Form, Input, InputNumber, Select, Space, Spin } from 'antd';
import useMahalanobisAddEditDrawer, {
  mahalanobisPlaceHolder,
  mahalanobisRule,
} from '../hooks/useMahalanobisAddEditDrawer';

import { MahalanobisAddEditDrawerState } from '../hooks/useMahalanobisEdit';

export interface MahalanobisAddEditDrawerProps {
  params: MahalanobisAddEditDrawerState;
  onClose: () => void;
}

export default function MahalanobisAddEditDrawer({ params, onClose }: MahalanobisAddEditDrawerProps): JSX.Element {
  const {
    form,
    equipmentOptions,
    targetOptions,
    colNameOptions,
    isFetching,
    isMutating,
    onSelectTarget,
    selectedTarget,
    onSave,
    isOpenSelect,
    setOpenColName,
    onSaveColName,
  } = useMahalanobisAddEditDrawer({
    params,
    onClose,
  });

  const modeText = params.editId ? 'Edit' : 'Add';
  const isRequesting = isFetching || isMutating;

  return (
    <Drawer
      title={
        <Space>
          <div>{`${modeText} Mahalanobis Item`}</div>
          {isFetching && <Spin size="small" />}
        </Space>
      }
      open={params.open}
      onClose={onClose}
      width={600}
      maskClosable={!isMutating}
      destroyOnClose
      extra={
        <Space>
          <AntdButton onClick={onClose} disabled={isMutating} type="default">
            Cancel
          </AntdButton>
          <AntdButton type="primary" onClick={onSave} disabled={isRequesting}>
            {modeText}
          </AntdButton>
        </Space>
      }
    >
      <div css={style}>
        <Form form={form} labelCol={{ span: 7 }} wrapperCol={{ span: 24 }} disabled={isRequesting}>
          <Form.Item label="Equipment Name" name="equipment_id" required rules={mahalanobisRule.equipment_name}>
            <Select options={equipmentOptions} placeholder={mahalanobisPlaceHolder.equipment_name} />
          </Form.Item>
          <Form.Item label="Target Table" name="table_name" required rules={mahalanobisRule.table_name}>
            <Select<string>
              options={targetOptions}
              onSelect={onSelectTarget}
              placeholder={mahalanobisPlaceHolder.table_name}
            />
          </Form.Item>
          <Form.Item label="Column Name 1" name="colname1" required rules={mahalanobisRule.colname1}>
            <Input
              addonAfter={
                <SearchPopover<string>
                  title="Column Name 1"
                  open={isOpenSelect.colname1}
                  onOpen={setOpenColName('colname1')}
                  onSave={onSaveColName('colname1')}
                  width="15rem"
                  options={colNameOptions}
                  disabled={Boolean(!selectedTarget) || isRequesting}
                />
              }
              placeholder={mahalanobisPlaceHolder.colname1}
              disabled={Boolean(!selectedTarget)}
            />
          </Form.Item>
          <Form.Item label="Column Name 2" name="colname2" required rules={mahalanobisRule.colname2}>
            <Input
              addonAfter={
                <SearchPopover
                  title="Column Name 2"
                  open={isOpenSelect.colname2}
                  onOpen={setOpenColName('colname2')}
                  onSave={onSaveColName('colname2')}
                  width="15rem"
                  options={colNameOptions}
                  disabled={Boolean(!selectedTarget)}
                />
              }
              placeholder={mahalanobisPlaceHolder.colname2}
              disabled={Boolean(!selectedTarget)}
            />
          </Form.Item>
          <Form.Item label="Covariance" name="covariance" required rules={mahalanobisRule.covariance}>
            <InputNumber style={{ width: '100%' }} placeholder={mahalanobisPlaceHolder.covariance} />
          </Form.Item>
          <Form.Item label="Mean 1" name="mean1" required rules={mahalanobisRule.mean1}>
            <InputNumber style={{ width: '100%' }} placeholder={mahalanobisPlaceHolder.mean1} />
          </Form.Item>
          <Form.Item label="Mean 2" name="mean2" required rules={mahalanobisRule.mean2}>
            <InputNumber style={{ width: '100%' }} placeholder={mahalanobisPlaceHolder.mean2} />
          </Form.Item>
          <Form.Item label="Variance 1" name="variance1" required rules={mahalanobisRule.variance1}>
            <InputNumber style={{ width: '100%' }} placeholder={mahalanobisPlaceHolder.variance1} />
          </Form.Item>
          <Form.Item label="Variance 2" name="variance2" required rules={mahalanobisRule.variance2}>
            <InputNumber style={{ width: '100%' }} placeholder={mahalanobisPlaceHolder.variance2} />
          </Form.Item>
          <Form.Item label="Item" name="item" required rules={mahalanobisRule.item}>
            <Input style={{ width: '100%' }} placeholder={mahalanobisPlaceHolder.item} />
          </Form.Item>
          <Form.Item label="Memo" name="memo">
            <Input placeholder={mahalanobisPlaceHolder.memo} />
          </Form.Item>
        </Form>
      </div>
    </Drawer>
  );
}

const style = css``;
