import {
  CopyOutlined,
  DeleteOutlined,
  EditOutlined,
  ExportOutlined,
  ImportOutlined,
  PlusOutlined,
} from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import type { TableColumnPropsType } from '@typesdef/common';
import type { MahalanobisData } from '@typesdef/mahalanobis';
import { Popconfirm, Space, Table } from 'antd';
import { Fragment } from 'react';
import useMahalanobis from './hooks/useMahalanobis';

export default function Mahalanobis() {
  const {
    mahaList,
    isFetchingMahaList,
    openAddModal,
    onDelete,
    onExport,
    openImportModal,
    moveEditPage,
    openCopyModal,
  } = useMahalanobis();

  const renderTitle = () => (
    <TableHeader title={<TableHeaderTitle total={mahaList?.length ?? 0} />}>
      <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddModal}>
        Add
      </AntdButton>
      <AntdButton icon={<CopyOutlined />} type="primary" onClick={openCopyModal}>
        Copy
      </AntdButton>
    </TableHeader>
  );

  const renderImport = (value: number, record: MahalanobisData, index: number) => (
    <ImportOutlined css={hoverActiveStyle} onClick={() => openImportModal(record)} />
  );

  const renderExport = (value: number, record: MahalanobisData, index: number) => {
    return (
      <Popconfirm
        title={
          <Fragment>
            <div>Are you sure to export mahalanobis for</div>
            <div>{`'${record.companyFabName}'?`}</div>
          </Fragment>
        }
        onConfirm={() => onExport(record)}
        okText="Export"
      >
        <ExportOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  const renderItemEdit = (value: number, record: MahalanobisData, index: number) => (
    <Space>
      <div>{value} Items</div>
      <EditOutlined css={hoverActiveStyle} onClick={() => moveEditPage(record)} />
    </Space>
  );

  const renderDelete = (value: number, record: MahalanobisData, index: number) => {
    return (
      <Popconfirm
        title={
          <Fragment>
            <div>Are you sure to delete mahalanobis for</div>
            <div>{`'${record.companyFabName}'?`}</div>
          </Fragment>
        }
        onConfirm={() => onDelete(record)}
        okText="Delete"
      >
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div>
      <Table<MahalanobisData>
        rowKey={'id'}
        dataSource={mahaList ?? []}
        bordered
        title={renderTitle}
        size="middle"
        pagination={{
          position: ['bottomCenter'],
        }}
        loading={isFetchingMahaList}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<MahalanobisData> {...columnProps.companyFabName} />
        <Table.Column<MahalanobisData> {...columnProps.itemCnt} render={renderItemEdit} />
        <Table.Column<MahalanobisData> {...columnProps.date} />
        <Table.Column<MahalanobisData> {...columnProps.import} render={renderImport} />
        <Table.Column<MahalanobisData> {...columnProps.export} render={renderExport} />
        <Table.Column<MahalanobisData> {...columnProps.delete} render={renderDelete} />
      </Table>
    </div>
  );
}

type ColumnName = 'companyFabName' | 'itemCnt' | 'date' | 'import' | 'export' | 'delete';

const columnProps: TableColumnPropsType<MahalanobisData, ColumnName> = {
  companyFabName: {
    key: 'companyFabName',
    title: <TableColumnTitle>User-Fab Name</TableColumnTitle>,
    dataIndex: 'companyFabName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'companyFabName'),
    },
    width: getPixelPercent(1360, 440),
  },
  itemCnt: {
    key: 'itemCnt',
    title: <TableColumnTitle>Mahalanobis Item</TableColumnTitle>,
    dataIndex: 'itemCnt',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'itemCnt'),
    },

    width: getPixelPercent(1360, 300),
  },
  date: {
    key: 'date',
    title: <TableColumnTitle>Last Updated</TableColumnTitle>,
    dataIndex: 'date',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'date'),
    },

    width: getPixelPercent(1360, 260),
  },
  import: {
    key: 'id',
    dataIndex: 'id',
    title: <TableColumnTitle>Import</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 120),
  },
  export: {
    key: 'export',
    dataIndex: 'id',
    title: <TableColumnTitle>Export</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 120),
  },
  delete: {
    key: 'delete',
    dataIndex: 'id',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    align: 'center',
    width: getPixelPercent(1360, 120),
  },
};
