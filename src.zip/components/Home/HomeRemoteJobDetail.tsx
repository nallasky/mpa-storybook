import { css } from '@emotion/react';
import { HomeRemoteJobDetailItem, HomeRemoteJobItem } from '@typesdef/home';
import { Badge, Space, Table, Empty } from 'antd';
import { memo, useCallback } from 'react';
import useHomeRemoteJobDetail from './hooks/useHomeRemoteJobDetail';
import { AntdTableRowClassName } from '@typesdef/antd';
import { TableColumnPropsType } from '@typesdef/common';
import CustomIcon from '@components/common/atoms/CustomIcon';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle, tableRowErrorStyle } from '@styles/emotion/common';
import { statusIconStyleWithJob } from '@components/RemoteJobStatus/RemoteJobStatus';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { ErrorResult } from './Home';

export interface HomeRemoteJobDetailProps {
  data: HomeRemoteJobItem;
}

export default memo(function HomeRemoteJobDetail({ data }: HomeRemoteJobDetailProps): JSX.Element {
  const {
    jobList,
    isLoadingJobList,
    onChangeTable,
    pagination,
    loggedInUserRole,
    openStartStopModal,
    moveToRemoteJobStep,
    isError,
    isFirstLoading,
  } = useHomeRemoteJobDetail({
    data,
  });

  const rowClassName: Exclude<AntdTableRowClassName<HomeRemoteJobDetailItem>, string> = useCallback((record) => {
    return record.failure > 0 ? 'error-mark' : '';
  }, []);

  const renderJobName = useCallback(
    (value: string, record: HomeRemoteJobDetailItem, index: number) => {
      return (
        <div css={hoverActiveStyle} onClick={() => moveToRemoteJobStep(record)}>
          {value}
        </div>
      );
    },
    [moveToRemoteJobStep],
  );

  const renderSteps = useCallback((value: number, record: HomeRemoteJobDetailItem, index: number) => {
    const { processing, success, failure, notbuild } = record;

    return (
      <div
        css={css`
          display: flex;
          justify-content: center;
          gap: 0 1rem;
        `}
      >
        <Space size={2}>
          <Badge status="processing" />
          <div>{`Processing (${processing})`}</div>
        </Space>
        <Space size={2}>
          <Badge status="success" />
          <div>{`Success (${success})`}</div>
        </Space>
        <Space size={2}>
          <Badge status="error" />
          <div>{`Failure (${failure})`}</div>
        </Space>
        <Space size={2}>
          <Badge status="default" />
          <div>{`Not Build (${notbuild})`}</div>
        </Space>
      </div>
    );
  }, []);

  const renderStatus = useCallback(
    (value: boolean, record: HomeRemoteJobDetailItem, index: number) => {
      const { jobId, jobName, stop: prevStop } = record;
      if (value)
        return (
          <div css={statusIconStyleWithJob(loggedInUserRole.ROLE_JOB)}>
            <CustomIcon className="stopped" name="stop" />
            <span className="text" onClick={() => openStartStopModal({ action: 'start', jobId, jobName, prevStop })}>
              Stopped
            </span>
          </div>
        );
      else
        return (
          <div
            css={statusIconStyleWithJob(loggedInUserRole.ROLE_JOB)}
            onClick={() => openStartStopModal({ action: 'stop', jobId, jobName, prevStop })}
          >
            <CustomIcon className="running" name="play" />
            <span className="text">Running</span>
          </div>
        );
    },
    [loggedInUserRole, openStartStopModal],
  );

  return (
    <div css={tableWrapper}>
      <Table<HomeRemoteJobDetailItem>
        rowKey={'jobId'}
        dataSource={jobList?.content ?? []}
        bordered
        size="small"
        pagination={{
          position: ['bottomCenter'],
          showSizeChanger: true,
          current: pagination.current,
          pageSize: pagination.pageSize,
          total: pagination.total,
        }}
        css={[tableRowErrorStyle]}
        tableLayout="fixed"
        rowClassName={rowClassName}
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
        onChange={onChangeTable}
        loading={isLoadingJobList || isFirstLoading}
        locale={{
          emptyText: isError ? (
            <ErrorResult title="Failed to get status of job detail!" />
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          ),
        }}
      >
        <Table.Column<HomeRemoteJobDetailItem> {...columnProps.jobName} render={renderJobName} />
        <Table.Column<HomeRemoteJobDetailItem> {...columnProps.steps} render={renderSteps} />
        <Table.Column<HomeRemoteJobDetailItem> {...columnProps.status} render={renderStatus} />
      </Table>
    </div>
  );
});

type ColumnName = 'jobName' | 'steps' | 'status';

const columnProps: TableColumnPropsType<HomeRemoteJobDetailItem, ColumnName> = {
  jobName: {
    key: 'jobName',
    title: <TableColumnTitle>Job Name</TableColumnTitle>,
    dataIndex: 'jobName',
    align: 'center',

    width: getPixelPercent(1052, 300),
  },
  steps: {
    key: 'steps',
    title: <TableColumnTitle>Steps</TableColumnTitle>,
    dataIndex: 'jobId',
    align: 'center',
    width: getPixelPercent(1052, 602),
  },
  status: {
    key: 'stop',
    title: <TableColumnTitle>Status</TableColumnTitle>,
    dataIndex: 'stop',
    align: 'center',
    width: getPixelPercent(1052, 150),
  },
};

const tableWrapper = css`
  width: 100%;
  min-height: 40vh;
  margin-top: 20px;
  display: flex;
`;
