import { css } from '@emotion/react';
import { Badge, Result, Space } from 'antd';
import HomeRemoteJob from './HomeRemoteJob';
import HomeRemoteJobDetail from './HomeRemoteJobDetail';
import useHome from './hooks/useHome';

export default function Home() {
  const { selectedJob, setSelectedJob } = useHome();

  return (
    <div css={style}>
      <div className="item">
        <ItemTitle title="Job Status" />
        <HomeRemoteJob selectedJob={selectedJob} setSelectedJob={setSelectedJob} />
      </div>
      {selectedJob.siteId ? (
        <div key={selectedJob.siteId}>
          <ItemTitle title={`Job Status Detail [${selectedJob.crasCompanyName}-${selectedJob.crasFabName}]`} />
          <HomeRemoteJobDetail data={selectedJob} />
        </div>
      ) : null}
    </div>
  );
}

function ItemTitle({ title }: { title: string }) {
  return (
    <Space>
      <Badge color="blue" />
      <div>{title}</div>
    </Space>
  );
}

export function ErrorResult({ title }: { title: string }) {
  return (
    <Result
      status="error"
      title={title}
      css={css`
        padding: 10px;
        .ant-result-icon {
          margin-bottom: 0;
          svg {
            width: 50px;
          }
        }
      `}
    />
  );
}

const style = css`
  flex: 1;
  .item {
    display: flex;
    flex-direction: column;
    gap: 15px;
    margin-bottom: 2rem;
    height: 13rem;
  }
  gap: 1rem;
`;
