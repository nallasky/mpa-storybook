import { HomeRemoteJobItem } from '@typesdef/home';
import { useState } from 'react';

export default function useHome() {
  const [selectedJob, setSelectedJob] = useState<HomeRemoteJobItem>({
    siteId: 0,
    crasCompanyName: '',
    crasFabName: '',
    registeredJob: 0,
    status: 'notbuild',
  });

  return { selectedJob, setSelectedJob };
}
