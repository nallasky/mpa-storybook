import { openAntdModal } from '@components/common/atoms/AntdModal';
import { PAGE_URL } from '@constants/constants';
import useTableSortSearch from '@hooks/useTableSortSearch';
import { getStatusRemoteJobStop, startRemoteJob, stopRemoteJob } from '@libs/axios/requests';
import { useGetHomeRemoteJobDetail } from '@libs/query/home';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { loginUserRoleBooleanSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { useQueryClient } from '@tanstack/react-query';
import type { HomeRemoteJobDetailItem, HomeRemoteJobItem } from '@typesdef/home';
import { AxiosError } from 'axios';
import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export interface HomeRemoteJobDetailHookProps {
  data: HomeRemoteJobItem;
}

export default function useHomeRemoteJobDetail({ data }: HomeRemoteJobDetailHookProps) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { pagination, setPagination, onChangeTable } = useTableSortSearch();
  const [isError, setError] = useState<boolean>(false);
  const loggedInUserRole = useTypedSelector(loginUserRoleBooleanSelector);

  const {
    data: jobList,
    isFetching: isFetchingJobList,
    isLoading: isLoadingJobList,
    refetch: refetchJobList,
  } = useGetHomeRemoteJobDetail(
    {
      paths: {
        siteId: data.siteId,
      },
      pagination: {
        size: pagination.pageSize,
        page: pagination.current - 1,
        sort: pagination.sort,
      },
    },
    {
      enabled: Boolean(data.siteId),
      onSuccess: (data) => {
        setPagination({
          total: data.totalElements,
        });
        setError(false);
      },
      onError: (error) => {
        if (!isError) {
          setError(true);
          openNotification('error', 'Error', `Failed to get status of job detail!`, error);
        }
      },
      keepPreviousData: true,
      refetchInterval: 3000,
    },
  );

  const openStartStopModal = ({
    action,
    jobId,
    jobName,
    prevStop,
  }: {
    action: 'start' | 'stop';
    jobId: number;
    jobName: string;
    prevStop: boolean;
  }) => {
    const actionText = action === 'start' ? 'Start' : 'End';
    openAntdModal('confirm', {
      title: `${actionText} Job`,
      content: `Are you sure to ${action} job '${jobName}'?`,
      okText: action === 'start' ? 'Start' : 'Stop',
      onOk: async () => {
        try {
          const { stop } = await getStatusRemoteJobStop(jobId);
          if (prevStop !== stop) {
            openNotification(
              'error',
              'Error',
              `The information of job '${jobName}' on the server has been changed. So, run the update. please try again!`,
            );
          } else {
            if (action === 'start') await startRemoteJob(jobId);
            else await stopRemoteJob(jobId);
            openNotification('success', 'Success', `Succeed to ${action} job '${jobName}'.`);
          }
        } catch (e) {
          openNotification('error', 'Error', `Failed to ${action} job '${jobName}'!`, e as AxiosError);
        } finally {
          refetchJobList();
        }
      },
    });
  };

  const moveToRemoteJobStep = useCallback(
    (record: HomeRemoteJobDetailItem) => {
      const { jobId, jobName } = record;
      navigate(
        `${PAGE_URL.STATUS_REMOTE_STEP({
          jobId,
          jobName,
        })}`,
      );
    },
    [navigate],
  );

  useEffect(() => {
    setPagination({
      current: 1,
      pageSize: 10,
      total: 0,
      sort: {},
    });
  }, [data]);

  useEffect(() => {
    return () => {
      queryClient.resetQueries([QUERY_KEY.HOME_REMOTE_JOB_DETAIL_LIST], {
        exact: false,
      });
    };
  }, []);

  return {
    jobList,
    isLoadingJobList,
    pagination,
    setPagination,
    onChangeTable,
    loggedInUserRole,
    openStartStopModal,
    moveToRemoteJobStep,
    isError,
    isFirstLoading: isFetchingJobList && isLoadingJobList,
  };
}
