import { useGetHomeRemoteJob } from '@libs/query/home';
import { openNotification } from '@libs/util/notification';
import { HomeRemoteJobItem } from '@typesdef/home';
import { useEffect, useState } from 'react';

export default function useHomeRemoteJob(
  selectedJob: HomeRemoteJobItem,
  setSelectedJob: (data: HomeRemoteJobItem) => void,
) {
  const [isError, setError] = useState(false);

  const { data, isLoading } = useGetHomeRemoteJob({
    refetchInterval: 3000,
    onError: (error) => {
      if (!isError) {
        setError(true);
        openNotification('error', 'Error', `Failed to get status of jobs!`, error);
      }
    },
    onSuccess: () => {
      setError(false);
    },
  });

  const onViewDetail = (data: HomeRemoteJobItem) => {
    setSelectedJob(data);
  };

  useEffect(() => {
    if (Array.isArray(data) && data.length > 0) {
      if (!data.find((e) => e.siteId === selectedJob.siteId)) {
        setSelectedJob(data[0]);
      }
    } else {
      setSelectedJob({
        siteId: 0,
        crasCompanyName: '',
        crasFabName: '',
        registeredJob: 0,
        status: 'notbuild',
      });
    }
  }, [data]);

  return {
    data,
    isLoading,
    onViewDetail,
    isError,
    setError,
  };
}
