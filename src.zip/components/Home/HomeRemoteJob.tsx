import { blue, green, red } from '@ant-design/colors';
import { css } from '@emotion/react';
import { HomeRemoteJobItem } from '@typesdef/home';
import { Badge, Col, Empty, Row, Space, Spin } from 'antd';
import { PresetStatusColorType } from 'antd/es/_util/colors';
import { ReactNode } from 'react';
import { ErrorResult } from './Home';
import useHomeRemoteJob from './hooks/useHomeRemoteJob';

export interface HomeRemoteJobDetailProps {
  data: HomeRemoteJobItem;
}

interface SelectedJobProps {
  selectedJob: HomeRemoteJobItem;
  setSelectedJob: (data: HomeRemoteJobItem) => void;
}

interface ItemProps {
  item: HomeRemoteJobItem;
  selectedJob: HomeRemoteJobItem;
  onClick: (data: HomeRemoteJobItem) => void;
}

export default function HomeRemoteJob({ selectedJob, setSelectedJob }: SelectedJobProps) {
  const { data, isLoading, onViewDetail, isError } = useHomeRemoteJob(selectedJob, setSelectedJob);
  let render: ReactNode = null;

  if (isError) {
    render = <ErrorResult title="Failed to get status of jobs!" />;
  } else {
    if (isLoading) {
      render = <Spin size="large" />;
    } else {
      if (Array.isArray(data) && data.length > 0) {
        render = (
          <Row gutter={[24, 20]} css={rowStyle}>
            {data?.map((item) => (
              <HomeRemoteJobBox key={item.siteId} item={item} selectedJob={selectedJob} onClick={onViewDetail} />
            ))}
          </Row>
        );
      } else {
        render = <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
      }
    }
  }

  return <div css={jobStatusStyle}>{render}</div>;
}

function HomeRemoteJobBox({ item, selectedJob, onClick }: ItemProps) {
  return (
    <Col span={4} onClick={() => onClick(item)}>
      <div css={remoteJobItemStyle(item.status, item.siteId === selectedJob.siteId)}>
        <div className="status">
          <Badge status={getStatus(item.status)} />
          <div className="user-fab-name">{`${item.crasCompanyName}-${item.crasFabName}`}</div>
        </div>
        <div className="job">
          <Space size={2}>
            <Badge color="black" />
            <div>{`Registered ${item.registeredJob ?? 0} Jobs`}</div>
          </Space>
        </div>
      </div>
    </Col>
  );
}

const getStatus = (input: HomeRemoteJobItem['status']): PresetStatusColorType =>
  (({
    success: 'success',
    failure: 'error',
    processing: 'processing',
    notbuild: 'default',
  }[input] as PresetStatusColorType) ?? 'default');

const getStatusColor = (input: HomeRemoteJobItem['status']): string =>
  ({
    success: green[0],
    failure: red[0],
    processing: blue[0],
    notbuild: '#F8F9FA',
  }[input] ?? '#F8F9FA');

const remoteJobItemStyle = (status: HomeRemoteJobItem['status'], isSelected: boolean) => css`
  height: 6rem;
  border: ${isSelected ? '2px solid #1890ff' : '0'};
  box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
  border-radius: 10px;
  padding: 0.5rem 1rem 0.5rem 1rem;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  cursor: pointer;
  background-color: ${getStatusColor(status)};

  ${isSelected === false &&
  `&:hover {
    transform: translateY(-8px);
    transition-duration: 0.5s;
    box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
  }
  `}

  &:not(:hover) {
    transform: translateY(0px);
    transition-duration: 0.5s;
  }

  .status {
    display: flex;
    .ant-badge-status-dot {
      width: 0.7rem;
      height: 0.7rem;
    }

    .user-fab-name {
      font-weight: 700;
      overflow: hidden;
      word-wrap: break-word;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
  }

  .job {
    font-size: 0.85rem;
    margin-left: 0.2rem;
  }
`;

const rowStyle = css`
  width: 85rem;
  display: flex;
  flex-wrap: nowrap;
  overflow-x: auto;
  padding: 10px 0 30px 0;

  &:hover {
    transition-delay: 1s;
    &::-webkit-scrollbar {
      height: 5px;
      background-color: #ffffff;
      border-radius: 10px;
    }
    &::-webkit-scrollbar-thumb {
      background: #d3d3d3;
      border-radius: 120px;
      background-clip: padding-box;
    }

    &::-webkit-scrollbar-track {
      background-color: #ededed;
    }

    ::-webkit-scrollbar-thumb:hover {
      background: #acacac;
    }

    ::-webkit-scrollbar-thumb:active {
      background: #838383;
    }
  }

  &::-webkit-scrollbar {
    height: 5px;
    background-color: #ffffff;
    border-radius: 10px;
  }
  &::-webkit-scrollbar-thumb {
    background: #ffffff;
    border-radius: 120px;
    background-clip: padding-box;
  }

  &::-webkit-scrollbar-track {
    background-color: #ffffff;
  }
`;

const jobStatusStyle = css`
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
`;
