import type { AccountUserRoleType } from '@typesdef/account';
import { Space, Tag } from 'antd';

interface AccountPermissionProps {
  roles: AccountUserRoleType[];
}

export default function AccountPermission({ roles }: AccountPermissionProps) {
  return (
    <Space size={0.5}>
      <Tag color={activeColor}>STATUS</Tag>
      <Tag color={getPermissionColor('ROLE_JOB', roles)}>JOB</Tag>
      <Tag color={getPermissionColor('ROLE_ERRORLOG', roles)}>ERROR LOG</Tag>
      <Tag color={getPermissionColor('ROLE_RULES', roles)}>RULES</Tag>
      <Tag color={getPermissionColor('ROLE_ADDRESS', roles)}>ADDRESS BOOK</Tag>
      <Tag color={getPermissionColor('ROLE_ACCOUNT', roles)}>ACCOUNT</Tag>
      <Tag color={getPermissionColor('ROLE_CONFIGURE', roles)}>SERVER CONFIG</Tag>
    </Space>
  );
}

const activeColor = '#108ee9';
const inactiveColor = '#8c8c8c';

function getPermissionColor(role: AccountUserRoleType, userRoles: AccountUserRoleType[]) {
  return userRoles.includes(role) ? activeColor : inactiveColor;
}
