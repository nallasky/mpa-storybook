import { openAntdModal } from '@components/common/atoms/AntdModal';
import type { FileImportModalProps } from '@components/common/atoms/FileImportModal/FileImportModal';
import FileImportModal from '@components/common/atoms/FileImportModal/FileImportModal';
import { API_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { useGetAccountExport } from '@libs/query/account';
import { MUTATION_KEY } from '@libs/query/mutationKey';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import { AxiosError } from 'axios';
import saveAs from 'file-saver';
import { useState } from 'react';

export type AccountPaneKey = 'group' | 'user';

export default function useAccount() {
  const [activeKey, setActiveKey] = useState<AccountPaneKey>('group');
  const queryClient = useQueryClient();
  const { openModal } = useModals();

  const { mutateAsync: mutateAsyncExport } = useGetAccountExport();

  const onExport = () => {
    openAntdModal('confirm', {
      title: 'Export Account',
      content: 'Are you sure to export account?',
      okText: 'Export',
      onOk: async () => {
        try {
          const { data, fileName } = await mutateAsyncExport();
          saveAs(data, fileName);
          openNotification('success', 'Success', `Succeed to export account '${fileName}'.`);
        } catch (e) {
          console.error(e);
          openNotification('error', 'Error', 'Failed to export account!');
        }
      },
    });
  };

  const onImport = () => {
    openModal<FileImportModalProps>(MODAL_NAME.RULE_CONVERT.FILE_IMPORT, FileImportModal, {
      title: 'Import Account',
      url: API_URL.POST_ACCOUNT_IMPORT,
      afterError: (error: AxiosError) => {
        openNotification('error', 'Error', `Failed to import account!`, error);
      },
      afterSuccess: () => {
        openNotification('success', 'Success', 'Succeed to import account.');
      },
      afterSettled: () => {
        if (activeKey === 'group') {
          queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_GROUP_SUMMARY_LIST]);
        } else {
          queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_USER_SUMMARY_LIST]);
        }
      },
      mutationKey: [MUTATION_KEY.ACCOUNT_IMPORT],
    });
  };

  return { activeKey, setActiveKey, onExport, onImport };
}
