import {
  useGetAccountGroupById,
  useGetAccountGroupSummaryListInModal,
  useGetAccountUserSummaryListInModal,
  usePostAccountGroup,
  usePutAccountGroup,
} from '@libs/query/account';
import { QUERY_KEY } from '@libs/query/queryKey';
import { getGroupRegex, getRoleArrFromRoleObj } from '@libs/util/account';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type {
  AccountUserRoleBoolean,
  AccountUserRoleType,
  AccountUserSummaryData,
  ReqAccountGroupData,
} from '@typesdef/account';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import type { RuleObject } from 'antd/es/form';
import { useForm } from 'antd/es/form/Form';
import { AxiosError } from 'axios';
import { useReducer, useState } from 'react';
import type { AccountGroupChangeModalProps } from '../Modal/AccountGroupChangeModal';

export default function useAccountGroupChangeModal({
  id,
  mode,
  onClose,
  visible,
}: GlobalModalDefaultProps<AccountGroupChangeModalProps>) {
  const queryClient = useQueryClient();
  const [form] = useForm<Pick<ReqAccountGroupData, 'groupName'>>();
  const [groupState, dispatchGroupState] = useReducer(reducer, initialState);
  const [isDisabledGroupName, setDisabledGroupName] = useState(false);

  const { data: group, isFetching: isFetchingGroup } = useGetAccountGroupById(id as number, {
    enabled: id !== undefined && mode === 'edit',
    onSuccess: (data) => {
      const { roles, users } = data;
      dispatchGroupState({
        type: 'permission/set',
        payload: getPermissionBoolean(roles),
      });

      dispatchGroupState({
        type: 'targetUserKeys/set',
        payload: users?.map((user) => user.id.toString()) ?? [],
      });
      form.setFieldValue('groupName', data.groupName);
      const compareValue = data?.groupName?.trim()?.toLowerCase() ?? '';
      setDisabledGroupName(['default', 'administrator'].includes(compareValue));
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response group data!`, error);
    },
  });

  const { data: groups, isFetching: isFetchingGroups } = useGetAccountGroupSummaryListInModal({
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response group list!`, error);
    },
  });

  const { data: users, isFetching: isFetchingUsers } = useGetAccountUserSummaryListInModal({
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response user list!`, error);
    },
  });

  const onMutateError = (error: AxiosError<unknown, any>) => {
    openNotification('error', 'Error', `Failed to ${mode} group!`, error);
  };

  const onMutateSuccess = (data: unknown) => {
    openNotification('success', 'Success', `Success to ${mode} group!`);
    queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_GROUP_SUMMARY_LIST], { exact: true });
    onClose();
  };

  const { mutate: mutateAdd, isLoading: isLoadingAdd } = usePostAccountGroup({
    onSuccess: onMutateSuccess,
    onError: onMutateError,
  });

  const { mutate: mutateEdit, isLoading: isLoadingEdit } = usePutAccountGroup({
    onSuccess: onMutateSuccess,
    onError: onMutateError,
  });

  const isFetching = isFetchingGroup || isFetchingUsers || isFetchingGroups;
  const isSubmitting = isLoadingAdd || isLoadingEdit;

  const validateGroupName = async (rule: RuleObject, value: string) => {
    const trimmedValue = value?.trim() ?? '';
    const compareValue = trimmedValue.toLowerCase() ?? '';

    if (!trimmedValue) {
      return;
    }

    if (['default', 'administrator'].includes(compareValue)) {
      if (mode === 'add') {
        throw new Error(`The name 'Default' or 'Administrator' cannot be used!`);
      }
    }

    if (!getGroupRegex().test(trimmedValue)) {
      throw new Error('Group name is invalid!');
    }

    const foundGroup = groups?.find((group) => group.groupName === trimmedValue);
    if (foundGroup) {
      if (mode === 'add') {
        throw new Error('Duplicated group name!');
      } else {
        if (foundGroup && foundGroup.id !== id) {
          throw new Error('Duplicated group name!');
        }
      }
    }
  };

  const onSubmit = async () => {
    try {
      const { groupName } = await form.validateFields();

      const reqData: ReqAccountGroupData = {
        id: id ?? -1,
        groupName,
        roles: getRoleArrFromRoleObj(groupState.permission),
        userIds: groupState.targetUserKeys.map((id) => Number(id)),
      };

      if (mode === 'add') {
        mutateAdd(reqData);
      } else {
        mutateEdit(reqData);
      }
    } catch (error) {
      console.error(error);
    }
  };

  return {
    form,
    groups,
    users,
    isFetching,
    groupState,
    dispatchGroupState,
    validateGroupName,
    onSubmit,
    isSubmitting,
    isDisabledGroupName,
  };
}

function getPermissionBoolean(roles: AccountUserRoleType[] = []): Partial<AccountUserRoleBoolean> {
  const initPermission: Partial<AccountUserRoleBoolean> = {};

  return (
    roles.reduce((acc, cur) => {
      acc[cur] = true;
      return acc;
    }, initPermission) ?? initPermission
  );
}

export interface AccountGroupMemberSettingProps {
  users: AccountUserSummaryData[] | undefined;
  isRequesting: boolean;
  targetUserKeys: State['targetUserKeys'];
  dispatchGroupState: React.Dispatch<ReducerAction>;
}

export interface AccountGroupPermissionSettingProps {
  isRequesting: boolean;
  permission: State['permission'];
  dispatchGroupState: React.Dispatch<ReducerAction>;
}

interface State {
  permission: AccountUserRoleBoolean;
  targetUserKeys: string[];
}
const initialState: State = {
  permission: {
    ROLE_STATUS: false,
    ROLE_JOB: false,
    ROLE_CONFIGURE: false,
    ROLE_RULES: false,
    ROLE_ADDRESS: false,
    ROLE_ACCOUNT: false,
    ROLE_ERRORLOG: false,
  },
  targetUserKeys: [],
};

type ReducerAction =
  | { type: 'permission/set'; payload: Partial<State['permission']> }
  | { type: 'targetUserKeys/set'; payload: State['targetUserKeys'] };

const reducer = (state: State, action: ReducerAction) => {
  switch (action.type) {
    case 'permission/set':
      return {
        ...state,
        permission: {
          ...state.permission,
          ...action.payload,
        },
      };
    case 'targetUserKeys/set':
      return {
        ...state,
        targetUserKeys: action.payload,
      };

    default:
      return state;
  }
};
