import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { useDeleteAccountGroup, useGetAccountGroupSummaryList } from '@libs/query/account';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { AccountGroupSummaryData } from '@typesdef/account';
import { useEffect, useMemo, useState } from 'react';
import AccountGroupChangeModal, { AccountGroupChangeModalProps } from '../Modal/AccountGroupChangeModal';
import { AccountPaneKey } from './useAccount';

export default function useAccountGroup({ activeKey }: { activeKey: AccountPaneKey }) {
  const queryClient = useQueryClient();
  const { openModal } = useModals();
  const [searchKeyword, setSearchKeyword] = useState<string | undefined>();

  const { data, isFetching: isFetchingGroups } = useGetAccountGroupSummaryList({
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response group list!`, error);
    },
  });

  const { mutateAsync: mutateAsyncDelete } = useDeleteAccountGroup({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to delete group.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete group!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_GROUP_SUMMARY_LIST]);
    },
  });

  const onSearch = (value: string | undefined) => {
    setSearchKeyword(value);
  };

  const groups = useMemo(() => {
    if (!searchKeyword) {
      return data ?? [];
    }

    return data?.filter((item) => item.groupName.toLowerCase().includes(searchKeyword.toLowerCase())) ?? [];
  }, [searchKeyword, data]);

  const openAddModal = () => {
    openModal<AccountGroupChangeModalProps>(MODAL_NAME.ACCOUNT.GROUP.ADD_EDIT, AccountGroupChangeModal, {
      mode: 'add',
    });
  };

  const openEditModal = (record: AccountGroupSummaryData) => {
    openModal<AccountGroupChangeModalProps>(MODAL_NAME.ACCOUNT.GROUP.ADD_EDIT, AccountGroupChangeModal, {
      id: record.id,
      mode: 'edit',
    });
  };

  const onDelete = async (id: number) => {
    try {
      await mutateAsyncDelete(id);
    } catch (error) {
      console.error(error);
    } finally {
      queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_GROUP_SUMMARY_LIST]);
    }
  };

  useEffect(() => {
    if (activeKey === 'group') {
      queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_GROUP_SUMMARY_LIST]);
    }
  }, [activeKey, queryClient]);

  return {
    groups,
    isFetchingGroups,
    searchKeyword,
    onSearch,
    openAddModal,
    openEditModal,
    onDelete,
  };
}
