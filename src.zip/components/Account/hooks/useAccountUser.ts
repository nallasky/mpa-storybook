import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import { useDeleteAccountUser, useGetAccountGroupSummaryList, useGetAccountUserSummaryList } from '@libs/query/account';
import { QUERY_KEY } from '@libs/query/queryKey';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { AccountUserSummaryData } from '@typesdef/account';
import { LabeledValue } from 'antd/es/select';
import { useEffect, useMemo, useState } from 'react';
import { AccountGroupChangeModalProps } from '../Modal/AccountGroupChangeModal';
import AccountUserChangeModal, { AccountUserChangeModalProps } from '../Modal/AccountUserChangeModal';
import { AccountPaneKey } from './useAccount';

const ALL_LABEL = {
  key: '-1',
  label: 'All',
  value: -1,
};

export default function useAccountUser({ activeKey }: { activeKey: AccountPaneKey }) {
  const { openModal } = useModals();
  const queryClient = useQueryClient();
  const { data, isFetching: isFetchingUsers } = useGetAccountUserSummaryList({
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response user list!`, error);
    },
  });

  const { data: groups, isFetching: isFetchingGroups } = useGetAccountGroupSummaryList({
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response group list!`, error);
    },
  });

  const { mutateAsync: mutateAsyncDelete } = useDeleteAccountUser({
    onSuccess: () => {
      openNotification('success', 'Success', `Succeed to delete user.`);
    },
    onError: (error) => {
      openNotification('error', 'Error', `Failed to delete user!`, error);
    },
    onSettled: () => {
      queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_USER_SUMMARY_LIST]);
      queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_GROUP_SUMMARY_LIST]);
    },
  });

  const [searchKeyword, setSearchKeyword] = useState<string | undefined>();
  const [selectGroup, setSelectGroup] = useState<number>(ALL_LABEL.value);

  const onSearch = (value: string | undefined) => {
    setSearchKeyword(value);
  };

  const onChangeSelectGroup = (value: number) => {
    setSelectGroup(value);
  };

  const users = useMemo(() => {
    let newUsers = data ?? [];

    if (selectGroup !== ALL_LABEL.value) {
      newUsers = newUsers.filter((item) => item.groupId === selectGroup);
    }

    if (searchKeyword) {
      newUsers = newUsers.filter((item) => item.username.toLowerCase().includes(searchKeyword.toLowerCase()));
    }

    return newUsers;
  }, [searchKeyword, data, selectGroup]);

  const groupOptions = useMemo((): LabeledValue[] => {
    const options: LabeledValue[] = [ALL_LABEL];

    if (groups) {
      groups.forEach((group) => {
        options.push({
          key: group.id.toString(),
          label: group.groupName,
          value: group.id,
        });
      });
    }

    return options;
  }, [groups]);

  const openAddModal = () => {
    openModal<AccountUserChangeModalProps>(MODAL_NAME.ACCOUNT.USER.ADD_EDIT, AccountUserChangeModal, {
      mode: 'add',
    });
  };

  const openEditModal = (record: AccountUserSummaryData) => {
    openModal<AccountGroupChangeModalProps>(MODAL_NAME.ACCOUNT.USER.ADD_EDIT, AccountUserChangeModal, {
      id: record.id,
      mode: 'edit',
    });
  };

  const onDelete = async (id: number) => {
    try {
      await mutateAsyncDelete(id);
    } catch (error) {
      console.error(error);
    } finally {
      queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_USER_SUMMARY_LIST]);
      queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_GROUP_SUMMARY_LIST]);
    }
  };

  useEffect(() => {
    if (activeKey === 'user') {
      queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_USER_SUMMARY_LIST]);
      queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_GROUP_SUMMARY_LIST]);
    }
  }, [activeKey, queryClient]);

  return {
    users,
    isFetching: isFetchingUsers || isFetchingGroups,
    searchKeyword,
    onSearch,
    openAddModal,
    openEditModal,
    groupOptions,
    selectGroup,
    onChangeSelectGroup,
    onDelete,
  };
}
