import {
  useGetAccountGroupSummaryListInModal,
  useGetAccountUserById,
  useGetAccountUserSummaryListInModal,
  usePostAccountUser,
  usePutAccountUser,
} from '@libs/query/account';
import { QUERY_KEY } from '@libs/query/queryKey';
import { getPasswordRegex, getUsernameRegex } from '@libs/util/account';
import { openNotification } from '@libs/util/notification';
import { useQueryClient } from '@tanstack/react-query';
import type { AccountUserRoleType, ReqAccountUserData } from '@typesdef/account';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { RuleObject } from 'antd/es/form';
import { useForm, useWatch } from 'antd/es/form/Form';
import { LabeledValue } from 'antd/es/select';
import { AxiosError } from 'axios';
import md5 from 'md5';
import { useEffect, useMemo } from 'react';
import type { AccountUserChangeModalProps } from '../Modal/AccountUserChangeModal';

interface UserChangeFormData
  extends Pick<ReqAccountUserData, 'username' | 'password' | 'groupId' | 'isChangePassword'> {
  confirmPassword: string;
}

export default function useAccountUserChangeModal({
  id,
  mode,
  onClose,
  visible,
}: GlobalModalDefaultProps<AccountUserChangeModalProps>) {
  const [form] = useForm<UserChangeFormData>();
  const queryClient = useQueryClient();
  const selectedGroupId = useWatch('groupId', form);
  const isChangePassword = useWatch('isChangePassword', form);

  const { data: user, isFetching: isFetchingUser } = useGetAccountUserById(id as number, {
    enabled: id !== undefined && mode === 'edit',
    onSuccess: (data) => {
      const { username, password, groupId } = data;
      form.setFieldsValue({
        username,
        groupId,
        isChangePassword: false,
      });
    },
    onError: (error) => {
      form.setFieldsValue({
        isChangePassword: false,
      });
      openNotification('error', 'Error', `Failed to response user data!`, error);
    },
  });

  const { data: users, isFetching: isFetchingUsers } = useGetAccountUserSummaryListInModal({
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response user list!`, error);
    },
  });

  const { data: groups, isFetching: isFetchingGroups } = useGetAccountGroupSummaryListInModal({
    onError: (error) => {
      openNotification('error', 'Error', `Failed to response group list!`, error);
    },
  });

  const groupOptions = useMemo(
    (): LabeledValue[] =>
      groups?.map((group) => ({
        key: group.id.toString(),
        label: group.groupName,
        value: group.id,
      })) ?? [],
    [groups],
  );

  const groupPermission = useMemo((): AccountUserRoleType[] => {
    if (selectedGroupId !== undefined && groups !== undefined) {
      const selectedGroup = groups.find((group) => group.id === selectedGroupId);
      if (selectedGroup !== undefined) {
        return selectedGroup.roles;
      }
    }

    return [];
  }, [selectedGroupId, groups]);

  const onMutateError = (error: AxiosError<unknown, any>) => {
    openNotification('error', 'Error', `Failed to ${mode} user!`, error);
  };

  const onMutateSuccess = (data: unknown) => {
    openNotification('success', 'Success', `Success to ${mode} user!`);
    queryClient.invalidateQueries([QUERY_KEY.ACCOUNT_USER_SUMMARY_LIST], { exact: true });
    onClose();
  };

  const { mutate: mutateAdd, isLoading: isLoadingAdd } = usePostAccountUser({
    onSuccess: onMutateSuccess,
    onError: onMutateError,
  });

  const { mutate: mutateEdit, isLoading: isLoadingEdit } = usePutAccountUser({
    onSuccess: onMutateSuccess,
    onError: onMutateError,
  });

  const isFetching = isFetchingUser || isFetchingUsers || isFetchingGroups;
  const isSubmitting = isLoadingAdd || isLoadingEdit;

  const validateUserName = async (rule: RuleObject, value: string) => {
    const trimmedValue = value.trim();

    if (!trimmedValue) {
      return;
    }

    if (trimmedValue.toLowerCase() === 'administrator') {
      throw new Error(`The username 'Administrator' cannot be used!`);
    }

    if (!getUsernameRegex().test(trimmedValue)) {
      throw new Error(`Username is invalid!`);
    }

    const foundUser = users?.find((user) => user.username === trimmedValue);
    if (foundUser) {
      if (mode === 'add') {
        throw new Error('Duplicated username!');
      } else {
        if (foundUser && foundUser.id !== id) {
          throw new Error('Duplicated username!');
        }
      }
    }
  };

  const validatePassword = async (rule: RuleObject, value: string) => {
    const trimmedValue = value.trim();

    if (!trimmedValue) {
      return;
    }

    if (!getPasswordRegex().test(trimmedValue)) {
      throw new Error(`Password is invalid!`);
    }
  };

  const onSubmit = async () => {
    try {
      const { groupId, password, username, isChangePassword, confirmPassword } = await form.validateFields();

      const reqData: ReqAccountUserData = {
        id: id ?? -1,
        username,
        groupId,
        isChangePassword,
        password: isChangePassword ? md5(password) : '',
      };

      if (mode === 'add') {
        mutateAdd(reqData);
      } else {
        mutateEdit(reqData);
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    form.setFieldsValue({
      password: '',
      confirmPassword: '',
    });
  }, [isChangePassword, form]);

  useEffect(() => {
    if (visible && mode === 'add') {
      form.setFieldsValue({
        isChangePassword: true,
      });
    }
  }, [form, mode, visible]);

  return {
    form,
    groupOptions,
    isFetching,
    isSubmitting,
    validateUserName,
    validatePassword,
    onSubmit,
    groupPermission,
    isChangePassword,
  };
}
