import { PAGE_URL } from '@constants/constants';
import useLogout from '@hooks/useLogout';
import { usePutAccountChangePassword } from '@libs/query/account';
import { getPasswordRegex } from '@libs/util/account';
import { openNotification } from '@libs/util/notification';
import { loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { RuleObject } from 'antd/es/form';
import { useForm } from 'antd/es/form/Form';
import { AxiosError } from 'axios';
import md5 from 'md5';
import { useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AccountChangePasswordModalProps } from '../Modal/AccountChangePasswordModal';

interface FormChangePassword {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export default function useAccountChangePasswordModal({
  onClose,
  visible,
  shouldChangePassword,
}: GlobalModalDefaultProps<AccountChangePasswordModalProps>) {
  const loggedInUser = useTypedSelector(loginUserSelector);
  const [form] = useForm<FormChangePassword>();
  const navigate = useNavigate();
  const { onLogout } = useLogout();

  const { mutate: mutateChangePw, isLoading: isFetching } = usePutAccountChangePassword({
    onError: (error) => {
      const newError = error as AxiosError<{ message: string }>;
      openNotification('error', 'Error', 'Failed to change password!', newError);
    },
    onSuccess: () => {
      openNotification('success', 'Success', 'Succeed to change password.');
      onClose();
      if (shouldChangePassword) {
        navigate(PAGE_URL.HOME);
      }
    },
  });

  const handleOk = useCallback(
    (data: FormChangePassword) => {
      mutateChangePw({
        id: loggedInUser.id,
        currentPassword: md5(data.currentPassword),
        newPassword: md5(data.newPassword),
      });
    },
    [mutateChangePw, loggedInUser.id],
  );

  const handleCancel = () => {
    if (shouldChangePassword) {
      onLogout();
    } else {
      onClose();
    }
  };

  const validatePassword = async (rule: RuleObject, value: string) => {
    const trimmedValue = value.trim();

    if (!trimmedValue) {
      return;
    }

    if (!getPasswordRegex().test(trimmedValue)) {
      throw new Error(`Password is invalid!`);
    }
  };

  useEffect(() => {
    if (visible) {
      form.resetFields();
    }
  }, [visible, form]);

  return {
    loggedInUser,
    form,
    handleOk,
    handleCancel,
    isFetching,
    validatePassword,
  };
}
