import { ExclamationOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Input, Modal, Spin, Tabs } from 'antd';
import { useMemo, useState } from 'react';
import useAccountGroupChangeModal from '../hooks/useAccountGroupChangeModal';
import AccountGroupChangeModalMember from './AccountGroupChangeModalMember';
import AccountGroupChangeModalPermission from './AccountGroupChangeModalPermission';

type GroupChangePaneKey = 'MEMBER' | 'PERMISSION';

const GROUP_PANE_PROPERTY: Record<GroupChangePaneKey, { TITLE: string; KEY: GroupChangePaneKey }> = {
  MEMBER: {
    TITLE: 'Member',
    KEY: 'MEMBER',
  },
  PERMISSION: {
    TITLE: 'Permission',
    KEY: 'PERMISSION',
  },
};

export interface AccountGroupChangeModalProps {
  id?: number;
  mode: 'add' | 'edit';
}

export default function AccountGroupChangeModal({
  id,
  mode,
  onClose,
  visible,
}: GlobalModalDefaultProps<AccountGroupChangeModalProps>) {
  const {
    form,
    groups,
    users,
    isFetching,
    groupState,
    dispatchGroupState,
    validateGroupName,
    onSubmit,
    isSubmitting,
    isDisabledGroupName,
  } = useAccountGroupChangeModal({
    id,
    mode,
    onClose,
    visible,
  });

  const modeText = mode === 'add' ? 'Add' : 'Edit';
  const [activeKey, setActiveKey] = useState<GroupChangePaneKey>('MEMBER');

  const groupPanes = useMemo(
    () => [
      {
        title: GROUP_PANE_PROPERTY.MEMBER.TITLE,
        key: GROUP_PANE_PROPERTY.MEMBER.KEY,
        contents: (
          <AccountGroupChangeModalMember
            users={users}
            targetUserKeys={groupState.targetUserKeys}
            isRequesting={isFetching || isSubmitting}
            dispatchGroupState={dispatchGroupState}
          />
        ),
      },
      {
        title: GROUP_PANE_PROPERTY.PERMISSION.TITLE,
        key: GROUP_PANE_PROPERTY.PERMISSION.KEY,
        contents: (
          <AccountGroupChangeModalPermission
            permission={groupState.permission}
            isRequesting={isFetching || isSubmitting}
            dispatchGroupState={dispatchGroupState}
          />
        ),
      },
    ],
    [isFetching, groupState, dispatchGroupState, users, isSubmitting],
  );

  return (
    <Modal
      title={
        <div
          css={css`
            display: flex;
            gap: 0.5rem;
            align-items: center;
            height: 1.375rem;
          `}
        >
          <div>{`${modeText} Group`}</div>
          {isFetching && <Spin size="small" />}
        </div>
      }
      open={visible}
      width="900px"
      onOk={onSubmit}
      okButtonProps={{
        disabled: isFetching || isSubmitting,
        loading: isSubmitting,
      }}
      onCancel={onClose}
      cancelButtonProps={{
        disabled: isSubmitting,
      }}
      destroyOnClose
    >
      <div css={style}>
        <Form form={form} disabled={isFetching}>
          <Form.Item
            label="Group Name"
            name="groupName"
            required
            rules={[
              {
                required: true,
                message: 'Please input a group name!',
              },
              {
                validator: validateGroupName,
              },
            ]}
            tooltip={<GroupNameToolTip />}
          >
            <Input disabled={isDisabledGroupName} />
          </Form.Item>
        </Form>
        <Tabs hideAdd onChange={(key) => setActiveKey(key as GroupChangePaneKey)} activeKey={activeKey} type="card">
          {groupPanes.map((pane) => (
            <Tabs.TabPane key={pane.key} tab={pane.title} disabled={isFetching}>
              {pane.contents}
            </Tabs.TabPane>
          ))}
        </Tabs>
      </div>
    </Modal>
  );
}

const style = css`
  height: 36rem;
`;

export const GroupNameToolTip = () => {
  return (
    <div>
      <p>
        <ExclamationOutlined /> Characters that can be entered: alphabet, number, dot(.), low line(_), hyphen(-).
      </p>
      <p>
        <ExclamationOutlined /> Start and end must be entered in alphabet or number.
      </p>
      <p>
        <ExclamationOutlined /> Allowed to be at least 3 characters long and up to 20 characters long.
      </p>
      <p>
        <ExclamationOutlined /> {'The group name "Default" or "Administrator" cannot be used. (Case insensitive)'}
      </p>
    </div>
  );
};
