import { CheckOutlined, CloseOutlined } from '@ant-design/icons';
import { ACCOUNT_ROLE } from '@constants/account';
import { css } from '@emotion/react';
import { loginUserRoleBooleanSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { Switch } from 'antd';
import { AccountGroupPermissionSettingProps } from '../hooks/useAccountGroupChangeModal';

export default function AccountGroupChangeModalPermission({
  permission,
  isRequesting,
  dispatchGroupState,
}: AccountGroupPermissionSettingProps) {
  const loggedInUserRole = useTypedSelector(loginUserRoleBooleanSelector);

  return (
    <div css={style}>
      <div className="box">
        <div>{`• ${ACCOUNT_ROLE.ROLE_STATUS.TITLE}`}</div>
        <Switch
          checkedChildren={<CheckOutlined />}
          unCheckedChildren={<CloseOutlined />}
          disabled={true}
          checked={true}
        />
      </div>
      <div className="box">
        <div>{`• ${ACCOUNT_ROLE.ROLE_JOB.TITLE}`}</div>
        <Switch
          checkedChildren={<CheckOutlined />}
          unCheckedChildren={<CloseOutlined />}
          disabled={!loggedInUserRole.ROLE_JOB || isRequesting}
          checked={permission.ROLE_JOB}
          onClick={(checked) => dispatchGroupState({ type: 'permission/set', payload: { ROLE_JOB: checked } })}
        />
      </div>
      <div className="box">
        <div>{`• ${ACCOUNT_ROLE.ROLE_ERRORLOG.TITLE}`}</div>
        <Switch
          checkedChildren={<CheckOutlined />}
          unCheckedChildren={<CloseOutlined />}
          disabled={!loggedInUserRole.ROLE_ERRORLOG || isRequesting}
          checked={permission.ROLE_ERRORLOG}
          onClick={(checked) => dispatchGroupState({ type: 'permission/set', payload: { ROLE_ERRORLOG: checked } })}
        />
      </div>
      <div className="box">
        <div>{`• ${ACCOUNT_ROLE.ROLE_RULES.TITLE}`}</div>
        <Switch
          checkedChildren={<CheckOutlined />}
          unCheckedChildren={<CloseOutlined />}
          disabled={!loggedInUserRole.ROLE_RULES || isRequesting}
          checked={permission.ROLE_RULES}
          onClick={(checked) => dispatchGroupState({ type: 'permission/set', payload: { ROLE_RULES: checked } })}
        />
      </div>
      <div className="box">
        <div>{`• ${ACCOUNT_ROLE.ROLE_ADDRESS.TITLE}`}</div>
        <Switch
          checkedChildren={<CheckOutlined />}
          unCheckedChildren={<CloseOutlined />}
          disabled={!loggedInUserRole.ROLE_ADDRESS || isRequesting}
          checked={permission.ROLE_ADDRESS}
          onClick={(checked) => dispatchGroupState({ type: 'permission/set', payload: { ROLE_ADDRESS: checked } })}
        />
      </div>
      <div className="box">
        <div>{`• ${ACCOUNT_ROLE.ROLE_ACCOUNT.TITLE}`}</div>
        <Switch
          checkedChildren={<CheckOutlined />}
          unCheckedChildren={<CloseOutlined />}
          disabled={!loggedInUserRole.ROLE_ACCOUNT || isRequesting}
          checked={permission.ROLE_ACCOUNT}
          onClick={(checked) => dispatchGroupState({ type: 'permission/set', payload: { ROLE_ACCOUNT: checked } })}
        />
      </div>
      <div className="box">
        <div>{`• ${ACCOUNT_ROLE.ROLE_CONFIGURE.TITLE}`}</div>
        <Switch
          checkedChildren={<CheckOutlined />}
          unCheckedChildren={<CloseOutlined />}
          disabled={!loggedInUserRole.ROLE_CONFIGURE || isRequesting}
          checked={permission.ROLE_CONFIGURE}
          onClick={(checked) => dispatchGroupState({ type: 'permission/set', payload: { ROLE_CONFIGURE: checked } })}
        />
      </div>
    </div>
  );
}

const style = css`
  display: grid;
  grid-template-columns: 1fr 1fr;
  margin-left: 3rem;
  margin-right: 3rem;
  gap: 1rem;
  .box {
    display: flex;
    gap: 1rem;
    align-items: center;
    justify-content: end;
  }
`;
