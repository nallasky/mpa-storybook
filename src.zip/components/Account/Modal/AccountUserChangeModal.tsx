import { ExclamationOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Form, Input, Modal, Select, Space, Spin, Switch } from 'antd';
import { Fragment } from 'react';
import AccountPermission from '../AccountPermission';
import useAccountUserChangeModal from '../hooks/useAccountUserChangeModal';

export interface AccountUserChangeModalProps {
  id?: number;
  mode: 'add' | 'edit';
}

export default function AccountUserChangeModal({
  id,
  mode,
  onClose,
  visible,
}: GlobalModalDefaultProps<AccountUserChangeModalProps>) {
  const {
    form,
    groupOptions,
    isFetching,
    isSubmitting,
    validateUserName,
    validatePassword,
    onSubmit,
    groupPermission,
    isChangePassword,
  } = useAccountUserChangeModal({ id, mode, onClose, visible });

  const modeText = mode === 'add' ? 'Add' : 'Edit';

  return (
    <Modal
      title={
        <div
          css={css`
            display: flex;
            gap: 0.5rem;
            align-items: center;
            height: 1.375rem;
          `}
        >
          <div>{`${modeText} User`}</div>
          {isFetching && <Spin size="small" />}
        </div>
      }
      open={visible}
      width="650px"
      onOk={onSubmit}
      okButtonProps={{
        disabled: isFetching || isSubmitting,
        loading: isSubmitting,
      }}
      onCancel={onClose}
      cancelButtonProps={{
        disabled: isSubmitting,
      }}
      destroyOnClose
    >
      <div css={style}>
        <Form form={form} disabled={isFetching} layout="vertical">
          <Form.Item
            tooltip={<UserNameToolTip />}
            label="Username"
            name="username"
            required
            rules={[
              {
                required: true,
                message: 'Please input a username!',
              },
              {
                validator: validateUserName,
              },
            ]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="Group"
            name="groupId"
            required
            rules={[
              {
                required: true,
                message: 'Please select a group!',
              },
            ]}
          >
            <Select allowClear options={groupOptions} />
          </Form.Item>
          <Form.Item label="Permission">
            <AccountPermission roles={groupPermission} />
          </Form.Item>
          <Form.Item
            className="change-password"
            label={
              <Space>
                <div>Change Password</div>
                <Form.Item noStyle valuePropName="checked" name="isChangePassword">
                  <Switch disabled={mode === 'add'} />
                </Form.Item>
              </Space>
            }
          />
          {isChangePassword && (
            <Fragment>
              <Form.Item
                label="Password"
                name="password"
                className="password"
                rules={[
                  {
                    required: true,
                    message: 'Please input a password!',
                  },
                  {
                    validator: validatePassword,
                  },
                ]}
                tooltip={<PasswordToolTip />}
              >
                <Input.Password />
              </Form.Item>
              <Form.Item
                label="Confirm Password"
                name="confirmPassword"
                className="confirmPassword"
                dependencies={['password']}
                rules={[
                  {
                    required: true,
                    message: 'Please confirm your password!',
                  },
                  ({ getFieldValue }) => ({
                    validator(_, value) {
                      if (!value || getFieldValue('password') === value) {
                        return Promise.resolve();
                      }
                      return Promise.reject(new Error('The two passwords that you entered do not match!'));
                    },
                  }),
                ]}
              >
                <Input.Password />
              </Form.Item>
            </Fragment>
          )}
        </Form>
      </div>
    </Modal>
  );
}

const style = css`
  .ant-form {
    .change-password {
      .ant-form-item-control-input {
        display: none;
      }
    }

    .password,
    .confirmPassword {
      margin-left: 1.5rem;
    }
  }
`;

export const UserNameToolTip = () => {
  return (
    <div>
      <p>
        <ExclamationOutlined /> Characters that can be entered: alphabet, number, dot(.), low line(_), hyphen(-).
      </p>
      <p>
        <ExclamationOutlined /> Start and end must be entered in alphabet or number.
      </p>
      <p>
        <ExclamationOutlined /> Allowed to be at least 3 characters long and up to 30 characters long.
      </p>
    </div>
  );
};

export const PasswordToolTip = () => {
  return (
    <div>
      <p>
        <ExclamationOutlined /> Characters that can be entered: alphabet, number.
      </p>
      <p>
        <ExclamationOutlined /> Allowed to be at least 6 characters long and up to 30 characters long.
      </p>
    </div>
  );
};
