import { PAGE_URL } from '@constants/constants';
import { loginUserHasLicenseRoleSelector, loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import type { LicenseStatusType } from '@typesdef/auth';
import { GlobalModalDefaultProps } from '@typesdef/modal';
import { Modal, ModalProps } from 'antd';
import { Fragment, ReactNode, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';

interface LicenseModalProps
  extends Pick<
    ModalProps,
    'title' | 'okText' | 'onOk' | 'okButtonProps' | 'cancelText' | 'onCancel' | 'cancelButtonProps'
  > {
  content?: ReactNode;
}

export default function AccountInvalidLicenseModal({ onClose, visible }: GlobalModalDefaultProps): JSX.Element {
  const { licenseStatus } = useTypedSelector(loginUserSelector);
  const hasLicenseRole = useTypedSelector(loginUserHasLicenseRoleSelector);
  const navigate = useNavigate();
  const goToSystemConfig = useCallback(() => {
    navigate(PAGE_URL.SYSTEM_CONFIG);
    onClose();
  }, [navigate, onClose]);

  const modalProps = useMemo(() => {
    const props: LicenseModalProps = {};

    if (licenseStatus === 'expired') {
      props.title = 'License registration expired';
      if (hasLicenseRole) {
        props.okText = 'Move';
        props.onOk = () => goToSystemConfig();
        props.cancelText = 'Close';
        props.onCancel = () => onClose();
        props.content = (
          <Fragment>
            <div>Your license has expired.</div>
            <div>Would you like to go to the license registration page?</div>
          </Fragment>
        );
      } else {
        props.okButtonProps = {
          hidden: true,
        };
        props.cancelText = 'Close';
        props.onCancel = () => onClose();
        props.cancelButtonProps = {
          type: 'primary',
        };
        props.content = (
          <Fragment>
            <div>Your license has expired.</div>
            <div>Please update your license.</div>
          </Fragment>
        );
      }
    } else if (licenseStatus === 'notRegistered') {
      props.title = 'License registration required';
      if (hasLicenseRole) {
        props.okText = 'Move';
        props.onOk = () => goToSystemConfig();
        props.cancelText = 'Close';
        props.onCancel = () => onClose();
        props.content = (
          <Fragment>
            <div>License not registered.</div>
            <div>Would you like to go to the license registration page?</div>
          </Fragment>
        );
      } else {
        props.okButtonProps = {
          hidden: true,
        };
        props.cancelText = 'Close';
        props.onCancel = () => onClose();
        props.cancelButtonProps = {
          type: 'primary',
        };
        props.content = (
          <Fragment>
            <div>License not registered.</div>
            <div>Please register your license.</div>
          </Fragment>
        );
      }
    }
    return props;
  }, [licenseStatus, hasLicenseRole, goToSystemConfig, onClose]);

  return (
    <Modal
      title={getTitle(licenseStatus)}
      open={visible}
      okText={modalProps.okText}
      onOk={modalProps.onOk}
      okButtonProps={modalProps.okButtonProps}
      cancelText={modalProps.cancelText}
      onCancel={modalProps.onCancel}
      cancelButtonProps={modalProps.cancelButtonProps}
      closable
      maskClosable
    >
      <div>{modalProps.content}</div>
    </Modal>
  );
}

const getTitle = (licenseStatus: LicenseStatusType) =>
  ({
    expired: 'License registration expired',
    notRegistered: 'License registration required',
  }[licenseStatus as string] ?? '');
