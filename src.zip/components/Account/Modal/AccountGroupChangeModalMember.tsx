import { css } from '@emotion/react';
import type { AccountUserSummaryData } from '@typesdef/account';
import { Empty, Table, Transfer, TransferProps } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import type { TableRowSelection } from 'antd/es/table/interface';
import { AccountGroupMemberSettingProps } from '../hooks/useAccountGroupChangeModal';

export default function AccountGroupChangeModalMember({
  users,
  targetUserKeys,
  isRequesting,
  dispatchGroupState,
}: AccountGroupMemberSettingProps) {
  const filterOption = (inputValue: string, option: AccountUserSummaryData) => option.username.indexOf(inputValue) > -1;

  const onChange = (nextTargetKeys: string[]) => {
    dispatchGroupState({ type: 'targetUserKeys/set', payload: nextTargetKeys });
  };

  return (
    <div>
      <TableTransfer
        rowKey={(record) => record.id.toString()}
        dataSource={users ?? []}
        targetKeys={targetUserKeys}
        disabled={isRequesting}
        showSearch
        onChange={onChange}
        filterOption={filterOption}
        leftColumns={leftTableColumns}
        rightColumns={rightTableColumns}
        titles={['All Users', 'Group Members']}
        css={css`
          height: 29rem;
        `}
        locale={{
          itemsUnit: 'Users',
          itemUnit: 'Users',
          searchPlaceholder: 'Search Username',
        }}
      />
    </div>
  );
}

interface TableTransferProps extends TransferProps<AccountUserSummaryData> {
  dataSource: AccountUserSummaryData[];
  leftColumns: TableColumnsType;
  rightColumns: TableColumnsType;
}

const TableTransfer = ({ leftColumns, rightColumns, ...restProps }: TableTransferProps) => (
  <Transfer {...restProps}>
    {({ direction, filteredItems, onItemSelectAll, onItemSelect, selectedKeys: listSelectedKeys }) => {
      const columns = direction === 'left' ? leftColumns : rightColumns;

      const rowSelection: TableRowSelection<AccountUserSummaryData> = {
        getCheckboxProps: (item) => ({
          disabled: restProps.disabled,
        }),
        onSelectAll(selected, selectedRows) {
          const treeSelectedKeys = selectedRows.map(({ id }) => id.toString());

          const diffKeys = selected
            ? differenceTwoArray(treeSelectedKeys, listSelectedKeys)
            : differenceTwoArray(listSelectedKeys, treeSelectedKeys);
          onItemSelectAll(diffKeys as string[], selected);
        },
        onSelect({ id }, selected) {
          onItemSelect(id.toString(), selected);
        },
        selectedRowKeys: listSelectedKeys,
      };

      return (
        <Table<AccountUserSummaryData>
          css={tableStyle}
          rowKey={(record) => record.id.toString()}
          rowSelection={rowSelection}
          columns={columns}
          dataSource={filteredItems}
          size="small"
          onRow={({ id }) => ({
            onClick: () => {
              if (restProps.disabled) return;
              onItemSelect(id.toString(), !listSelectedKeys.includes(id.toString()));
            },
          })}
          pagination={{
            pageSize: 7,
            position: ['bottomCenter'],
          }}
          locale={{
            emptyText: <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="No Users" />,
          }}
        />
      );
    }}
  </Transfer>
);

const tableStyle = css`
  .ant-table-content {
    table {
      tbody {
        .ant-table-placeholder {
          td {
            border: 0;
          }
        }
      }
    }
  }
`;

const differenceTwoArray = (source: string[], target: string[]) => {
  const targetObj: Record<string, string> = {};
  target.forEach((key) => {
    targetObj[key] = key;
  });

  const result: string[] = [];
  source.forEach((key) => {
    if (!Object.prototype.hasOwnProperty.call(targetObj, key)) {
      result.push(key);
    }
  });

  return result;
};

type TableColumnsType = ColumnsType<AccountUserSummaryData>;

const leftTableColumns: TableColumnsType = [
  {
    dataIndex: 'groupName',
    title: 'Group Name',
  },
  {
    dataIndex: 'username',
    title: 'Username',
  },
];

const rightTableColumns: TableColumnsType = [
  {
    dataIndex: 'username',
    title: 'Username',
  },
];
