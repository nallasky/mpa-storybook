import FormConfirmPassword from '@components/common/atoms/CustomForm/FormConfirmPassword';
import FormPassword from '@components/common/atoms/CustomForm/FormPassword';
import { css } from '@emotion/react';
import type { GlobalModalDefaultProps } from '@typesdef/modal';
import { Alert, Form, Modal } from 'antd';
import useAccountChangePasswordModal from '../hooks/useAccountChangePasswordModal';
import { PasswordToolTip } from './AccountUserChangeModal';

export type AccountChangePasswordModalProps = {
  shouldChangePassword?: boolean;
};

export default function AccountChangePasswordModal({
  onClose,
  visible,
  shouldChangePassword = false,
}: GlobalModalDefaultProps<AccountChangePasswordModalProps>): JSX.Element {
  const { form, handleOk, handleCancel, isFetching, validatePassword } = useAccountChangePasswordModal({
    onClose,
    visible,
    shouldChangePassword,
  });

  return (
    <Modal
      title="Change Password"
      open={visible}
      okText="Change"
      onOk={form.submit}
      okButtonProps={{ loading: isFetching, disabled: isFetching }}
      cancelText={shouldChangePassword ? 'Logout' : 'Cancel'}
      onCancel={handleCancel}
      cancelButtonProps={{
        disabled: isFetching,
      }}
      closable={shouldChangePassword ? false : !isFetching}
      maskClosable={shouldChangePassword ? false : !isFetching}
      keyboard={!shouldChangePassword}
    >
      <div
        css={css`
          display: flex;
          flex-direction: column;
          gap: 1rem;
        `}
      >
        {shouldChangePassword && <Alert message="You must change your initial password." type="warning" banner />}
        <Form form={form} onFinish={handleOk} layout="vertical">
          <FormPassword label="Current Password" name="currentPassword" />
          <FormPassword
            label="New Password"
            name="newPassword"
            tooltip={<PasswordToolTip />}
            rules={[
              {
                validator: validatePassword,
              },
            ]}
          />
          <FormConfirmPassword label="Confirm Password" name="confirmPassword" compareFieldName="newPassword" />
        </Form>
      </div>
    </Modal>
  );
}
