import AntdButton from '@components/common/atoms/AntdButton';
import { css } from '@emotion/react';
import { Tabs } from 'antd';
import { useMemo } from 'react';
import AccountGroup from './AccountGroup';
import AccountUser from './AccountUser';
import useAccount, { AccountPaneKey } from './hooks/useAccount';

export default function Account() {
  const { activeKey, setActiveKey, onExport, onImport } = useAccount();

  const accountPanes = useMemo(
    () => [
      {
        title: 'Group',
        key: 'group',
        contents: <AccountGroup activeKey={activeKey} />,
      },
      {
        title: 'User',
        key: 'user',
        contents: <AccountUser activeKey={activeKey} />,
      },
    ],
    [activeKey],
  );

  return (
    <div css={style}>
      <div className="button-group">
        <AntdButton onClick={onExport}>Export</AntdButton>
        <AntdButton onClick={onImport}>Import</AntdButton>
      </div>
      <Tabs hideAdd onChange={(key) => setActiveKey(key as AccountPaneKey)} activeKey={activeKey} type="card">
        {accountPanes.map((pane) => (
          <Tabs.TabPane key={pane.key} tab={pane.title}>
            {pane.contents}
          </Tabs.TabPane>
        ))}
      </Tabs>
    </div>
  );
}

const style = css`
  display: flex;
  flex-direction: column;
  width: 100%;
  position: relative;

  .button-group {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 0.5rem;
    position: absolute;
    height: 2.5rem;
    right: 1rem;
    z-index: 1;
  }
`;
