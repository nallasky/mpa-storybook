import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import SearchText from '@components/common/atoms/SearchText';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import type { AccountUserRoleType, AccountUserSummaryData } from '@typesdef/account';
import type { TableColumnPropsType } from '@typesdef/common';
import { Popconfirm, Select, Table } from 'antd';
import AccountPermission from './AccountPermission';
import { AccountPaneKey } from './hooks/useAccount';
import useAccountUser from './hooks/useAccountUser';

export default function AccountUser({ activeKey }: { activeKey: AccountPaneKey }) {
  const {
    users,
    isFetching,
    searchKeyword,
    onSearch,
    openAddModal,
    openEditModal,
    groupOptions,
    selectGroup,
    onChangeSelectGroup,
    onDelete,
  } = useAccountUser({ activeKey });

  const renderTitle = () => (
    <TableHeader title={<TableHeaderTitle total={users.length} isSearched={searchKeyword ? true : false} />}>
      <SearchText value={searchKeyword} onSearch={onSearch} placeholder="Username" />
      <Select
        options={groupOptions}
        showSearch
        filterOption={(input, option) =>
          option ? (option.label as unknown as string).toLowerCase().includes(input.toLowerCase()) : false
        }
        css={css`
          width: 10rem;
          .ant-select-selector {
            border-radius: 0.625rem !important;
          }
        `}
        value={selectGroup}
        onChange={onChangeSelectGroup}
      />
      <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddModal}>
        Add
      </AntdButton>
    </TableHeader>
  );

  const renderRoles = (value: AccountUserRoleType[], record: AccountUserSummaryData, index: number) => {
    return <AccountPermission roles={value} />;
  };

  const renderEdit = (value: number, record: AccountUserSummaryData, index: number) => {
    return <EditOutlined css={hoverActiveStyle} onClick={() => openEditModal(record)} />;
  };

  const renderDelete = (value: number, record: AccountUserSummaryData, index: number) => {
    return (
      <Popconfirm title="Are you sure to delete this user?" onConfirm={() => onDelete(record.id)} okText="Delete">
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div css={style}>
      <Table<AccountUserSummaryData>
        rowKey={'id'}
        dataSource={users}
        bordered
        title={renderTitle}
        size="middle"
        pagination={{
          position: ['bottomCenter'],
        }}
        loading={isFetching}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<AccountUserSummaryData> {...columnProps.username} />
        <Table.Column<AccountUserSummaryData> {...columnProps.groupName} />
        <Table.Column<AccountUserSummaryData> {...columnProps.roles} render={renderRoles} />
        <Table.Column<AccountUserSummaryData> {...columnProps.accessAt} />
        <Table.Column<AccountUserSummaryData> {...columnProps.updateAt} />
        <Table.Column<AccountUserSummaryData> {...columnProps.edit} render={renderEdit} />
        <Table.Column<AccountUserSummaryData> {...columnProps.delete} render={renderDelete} />
      </Table>
    </div>
  );
}

const style = css`
  margin: 1rem;
`;

type ColumnName = 'username' | 'groupName' | 'roles' | 'accessAt' | 'updateAt' | 'edit' | 'delete';

const columnProps: TableColumnPropsType<AccountUserSummaryData, ColumnName> = {
  username: {
    key: 'username',
    title: <TableColumnTitle>Username</TableColumnTitle>,
    dataIndex: 'username',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'username'),
    },
    width: getPixelPercent(1328, 150),
  },
  groupName: {
    key: 'groupName',
    title: <TableColumnTitle>Group Name</TableColumnTitle>,
    dataIndex: 'groupName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'groupName'),
    },
    width: getPixelPercent(1328, 150),
  },
  roles: {
    key: 'roles',
    title: <TableColumnTitle>Permission</TableColumnTitle>,
    dataIndex: 'roles',
    align: 'center',
    width: getPixelPercent(1328, 608),
  },
  accessAt: {
    key: 'accessAt',
    title: <TableColumnTitle>Last Accessed</TableColumnTitle>,
    dataIndex: 'accessAt',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'accessAt'),
    },
    width: getPixelPercent(1328, 140),
  },
  updateAt: {
    key: 'updateAt',
    title: <TableColumnTitle>Last Updated</TableColumnTitle>,
    dataIndex: 'updateAt',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'updateAt'),
    },
    width: getPixelPercent(1328, 140),
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    dataIndex: 'id',
    align: 'center',
    width: getPixelPercent(1328, 70),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    dataIndex: 'id',
    align: 'center',
    width: getPixelPercent(1328, 70),
  },
};
