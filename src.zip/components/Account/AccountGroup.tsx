import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import AntdButton from '@components/common/atoms/AntdButton';
import SearchText from '@components/common/atoms/SearchText';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { hoverActiveStyle } from '@styles/emotion/common';
import type { AccountGroupSummaryData, AccountUserRoleType } from '@typesdef/account';
import type { TableColumnPropsType } from '@typesdef/common';
import { Popconfirm, Table } from 'antd';
import AccountPermission from './AccountPermission';
import { AccountPaneKey } from './hooks/useAccount';
import useAccountGroup from './hooks/useAccountGroup';

export default function AccountGroup({ activeKey }: { activeKey: AccountPaneKey }) {
  const { groups, isFetchingGroups, searchKeyword, onSearch, openAddModal, openEditModal, onDelete } = useAccountGroup({
    activeKey,
  });

  const renderTitle = () => (
    <TableHeader title={<TableHeaderTitle total={groups.length} isSearched={searchKeyword ? true : false} />}>
      <SearchText value={searchKeyword} onSearch={onSearch} placeholder="Group Name" />
      <AntdButton icon={<PlusOutlined />} type="primary" onClick={openAddModal}>
        Add
      </AntdButton>
    </TableHeader>
  );

  const renderRoles = (value: AccountUserRoleType[], record: AccountGroupSummaryData, index: number) => {
    return <AccountPermission roles={value} />;
  };

  const renderEdit = (value: number, record: AccountGroupSummaryData, index: number) => {
    return <EditOutlined css={hoverActiveStyle} onClick={() => openEditModal(record)} />;
  };

  const renderDelete = (value: number, record: AccountGroupSummaryData, index: number) => {
    const { groupName } = record;

    if (groupName && groupName.trim().toLowerCase() === 'default') {
      return <div>-</div>;
    }

    return (
      <Popconfirm title="Are you sure to delete this group?" onConfirm={() => onDelete(record.id)} okText="Delete">
        <DeleteOutlined css={hoverActiveStyle} />
      </Popconfirm>
    );
  };

  return (
    <div css={style}>
      <Table<AccountGroupSummaryData>
        rowKey={'id'}
        dataSource={groups}
        bordered
        title={renderTitle}
        size="middle"
        pagination={{
          position: ['bottomCenter'],
        }}
        loading={isFetchingGroups}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<AccountGroupSummaryData> {...columnProps.groupName} />
        <Table.Column<AccountGroupSummaryData> {...columnProps.roles} render={renderRoles} />
        <Table.Column<AccountGroupSummaryData> {...columnProps.userCnt} />
        <Table.Column<AccountGroupSummaryData> {...columnProps.edit} render={renderEdit} />
        <Table.Column<AccountGroupSummaryData> {...columnProps.delete} render={renderDelete} />
      </Table>
    </div>
  );
}

const style = css`
  margin: 1rem;
`;

type ColumnName = 'groupName' | 'roles' | 'userCnt' | 'edit' | 'delete';

const columnProps: TableColumnPropsType<AccountGroupSummaryData, ColumnName> = {
  groupName: {
    key: 'groupName',
    title: <TableColumnTitle>Group Name</TableColumnTitle>,
    dataIndex: 'groupName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'groupName'),
    },
    width: getPixelPercent(1328, 250),
  },
  roles: {
    key: 'roles',
    title: <TableColumnTitle>Permission</TableColumnTitle>,
    dataIndex: 'roles',
    align: 'center',
    width: getPixelPercent(1328, 818),
  },
  userCnt: {
    key: 'userCnt',
    title: <TableColumnTitle>Members</TableColumnTitle>,
    dataIndex: 'userCnt',
    align: 'center',
    width: getPixelPercent(1328, 100),
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    dataIndex: 'id',
    align: 'center',
    width: getPixelPercent(1328, 80),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    dataIndex: 'id',
    align: 'center',
    width: getPixelPercent(1328, 80),
  },
};
