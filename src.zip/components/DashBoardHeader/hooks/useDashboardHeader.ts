import AccountChangePasswordModal, {
  AccountChangePasswordModalProps,
} from '@components/Account/Modal/AccountChangePasswordModal';
import { API_URL, DEFAULT_URL, PAGE_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useLogout from '@hooks/useLogout';
import useModals from '@hooks/useModal';
import { getRequest } from '@libs/axios/requests';
import { QUERY_KEY } from '@libs/query/queryKey';
import { hasValidLicense } from '@libs/util/auth';
import { setConvertSearch } from '@reducers/slices/convert';
import { getDebugLogIsFixedCras, setDebugModeFixedCras } from '@reducers/slices/debugMode';
import { loginUserRoleBooleanSelector, loginUserSelector } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import { useQuery } from '@tanstack/react-query';
import { useCallback, useLayoutEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';

export enum NavType {
  HOME = 'home',
  JOB = 'job',
  LOCAL_IMPORT = 'local_import',
  ERROR_LOG = 'errorlog',
  ERROR_LOG_DOWNLOAD = 'errorlog:download',
  ERROR_LOG_STATUS = 'errorlog:status',
  ERROR_LOG_SETTING = 'errorlog:setting',
  CONFIGURE = 'configure',
  RULES = 'rules',
  RULES_CONVERT = 'rules:convert',
  RULES_CRAS = 'rules:cras',
  RULES_DEFINE = 'rules:define',
  RULES_DEFINE_COLUMN = 'rules:define:column',
  RULES_DEFINE_CYLINDER = 'rules:define:cylinder',
  RULES_DEFINE_MACHINE = 'rules:define:machine',
  ADDRESS_BOOK = 'address',
  ACCOUNT = 'account',
  SYSTEM_CONFIG = 'system',
  RULE_ANALYSIS_MAHALANOBIS = 'rule:analysis:mahalanobis',
  RULE_ANALYSIS_ARCNET = 'rule:analysis:arcnet',
  RULE_ANALYSIS_ARCNET_ITEM = 'rule:analysis:arcnet:item',
  RULE_ANALYSIS_ARCNET_UNIT = 'rule:analysis:arcnet:unit',
  NOT_LICENSED = 'notlicensed',
  test = 'test',
}

export enum UserItemType {
  CHANGE_PASSWORD = 'changepw',
  LOGOUT = 'logout',
}

export default function useDashboardHeader() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [currentKey, setCurrentKey] = useState(NavType.JOB);
  const loggedInUser = useTypedSelector(loginUserSelector);
  const loggedInUserRole = useTypedSelector(loginUserRoleBooleanSelector);
  const isLicensed = hasValidLicense(loggedInUser.licenseStatus);
  const { pathname } = useLocation();
  const { onLogout } = useLogout();
  const { openModal } = useModals();
  const isFixedCras = useTypedSelector(getDebugLogIsFixedCras);

  useQuery(
    [QUERY_KEY.DEBUG_SELECT_CRAS_SERVER],
    () =>
      getRequest<{ siteId: number | null }>({
        url: API_URL.GET_DEBUG_SELECT_CRAS_SERVER,
      }),
    {
      onSuccess: (data) => {
        dispatch(setDebugModeFixedCras(data?.siteId ? +data.siteId : null));
      },
      onError(error) {
        dispatch(setDebugModeFixedCras(null));
      },
    },
  );

  const beforeNavigate = useCallback(
    (type: NavType) => {
      switch (type) {
        case NavType.RULES_CONVERT:
          dispatch(
            setConvertSearch({
              keyword: '',
              type: 'all',
            }),
          );
          break;

        default:
          break;
      }
    },
    [dispatch],
  );

  const onClickNavItem = useCallback(
    ({ key }: { key: React.Key }) => {
      const url = getNavUrl(key as NavType);

      console.log(key, url);

      if (url) {
        setCurrentKey(key as NavType);
        beforeNavigate(key as NavType);
        navigate(url);
      }
    },
    [navigate, setCurrentKey, beforeNavigate],
  );

  const onClickUserItem = useCallback(
    ({ key }: { key: React.Key }) => {
      switch (key) {
        case UserItemType.CHANGE_PASSWORD:
          openModal<AccountChangePasswordModalProps>(MODAL_NAME.AUTH.CHANGE_PASSWORD, AccountChangePasswordModal);
          break;
        case UserItemType.LOGOUT:
          onLogout();
          break;
        default:
          break;
      }
    },

    [onLogout, openModal],
  );

  const goToDebugMode = () => {
    navigate(DEFAULT_URL + '/dashboard/debug');
  };

  useLayoutEffect(() => {
    const navPathKey = getCurrentUrlKey(pathname);
    if (navPathKey !== currentKey) {
      setCurrentKey(navPathKey);
    }
  }, [pathname, currentKey]);

  return {
    currentKey,
    onClickNavItem,
    onClickUserItem,
    loggedInUser,
    loggedInUserRole,
    isLicensed,
    isFixedCras,
    goToDebugMode,
  };
}

const getCurrentUrlKey = (url: string): NavType => {
  let key = NavType.HOME;
  const trimmedUrl = url.trim();

  if (trimmedUrl === PAGE_URL.HOME) {
    key = NavType.HOME;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/status/remote')) {
    key = NavType.JOB;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/status/local')) {
    key = NavType.LOCAL_IMPORT;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/errorlog/download')) {
    key = NavType.ERROR_LOG_DOWNLOAD;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/errorlog/status')) {
    key = NavType.ERROR_LOG_STATUS;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/errorlog/setting')) {
    key = NavType.ERROR_LOG_SETTING;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/configure')) {
    key = NavType.CONFIGURE;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/rules/convert')) {
    key = NavType.RULES_CONVERT;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/rules/cras-data')) {
    key = NavType.RULES_CRAS;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/rules/define/column')) {
    key = NavType.RULES_DEFINE_COLUMN;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/rules/define/cylinder')) {
    key = NavType.RULES_DEFINE_CYLINDER;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/rules/define/machine')) {
    key = NavType.RULES_DEFINE_MACHINE;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/address')) {
    key = NavType.ADDRESS_BOOK;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/account')) {
    key = NavType.ACCOUNT;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/system')) {
    key = NavType.SYSTEM_CONFIG;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/rules/analysis/mahalanobis')) {
    key = NavType.RULE_ANALYSIS_MAHALANOBIS;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/rules/analysis/arcnet/item')) {
    key = NavType.RULE_ANALYSIS_ARCNET_ITEM;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/rules/analysis/arcnet/unit')) {
    key = NavType.RULE_ANALYSIS_ARCNET_UNIT;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/notlicensed')) {
    key = NavType.NOT_LICENSED;
  } else if (trimmedUrl.startsWith(DEFAULT_URL + '/dashboard/test')) {
    key = NavType.test;
  }

  return key;
};

export const getNavUrl = (navType: NavType) =>
  ({
    [NavType.HOME]: PAGE_URL.HOME,
    [NavType.JOB]: PAGE_URL.STATUS_REMOTE,
    [NavType.LOCAL_IMPORT]: PAGE_URL.STATUS_LOCAL,
    [NavType.ERROR_LOG_DOWNLOAD]: PAGE_URL.ERROR_LOG_DOWNLOAD,
    [NavType.ERROR_LOG_STATUS]: PAGE_URL.ERROR_LOG_STATUS,
    [NavType.ERROR_LOG_SETTING]: PAGE_URL.ERROR_LOG_SETTING,
    [NavType.CONFIGURE]: PAGE_URL.CONFIGURE,
    [NavType.RULES_CONVERT]: PAGE_URL.RULES_CONVERT,
    [NavType.RULES_CRAS]: PAGE_URL.RULES_CRAS_DATA,
    [NavType.RULES_DEFINE_COLUMN]: PAGE_URL.RULES_DEFINE_COLUMN,
    [NavType.RULES_DEFINE_CYLINDER]: PAGE_URL.RULES_DEFINE_CYLINDER,
    [NavType.RULES_DEFINE_MACHINE]: PAGE_URL.RULES_DEFINE_MACHINE,
    [NavType.ADDRESS_BOOK]: PAGE_URL.ADDRESS_BOOK,
    [NavType.ACCOUNT]: PAGE_URL.ACCOUNT,
    [NavType.SYSTEM_CONFIG]: PAGE_URL.SYSTEM_CONFIG,
    [NavType.RULE_ANALYSIS_MAHALANOBIS]: PAGE_URL.RULES_ANALYSIS_MAHALANOBIS,
    [NavType.RULE_ANALYSIS_ARCNET_ITEM]: PAGE_URL.RULES_ANALYSIS_ARCNET_ITEM,
    [NavType.RULE_ANALYSIS_ARCNET_UNIT]: PAGE_URL.RULES_ANALYSIS_ARCNET_UNIT,
    [NavType.NOT_LICENSED]: PAGE_URL.NOT_LICENSED,
    [NavType.test]: PAGE_URL.test,
  }[navType as string] ?? null);
