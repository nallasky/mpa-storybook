import { blue } from '@ant-design/colors';
import {
  AlertOutlined,
  ApartmentOutlined,
  BookOutlined,
  FileProtectOutlined,
  FileZipOutlined,
  LaptopOutlined,
  PartitionOutlined,
  SettingOutlined,
  DatabaseOutlined,
} from '@ant-design/icons';
import { css } from '@emotion/react';
import styled from '@emotion/styled';
import { hoverActiveStyleDefColor } from '@styles/emotion/common';
import type { AccountUserRoleBoolean } from '@typesdef/account';
import { Col, Dropdown, Menu, Row, Space } from 'antd';
import { ItemType } from 'antd/es/menu/hooks/useItems';
import { useMemo } from 'react';
import CustomIcon from '../common/atoms/CustomIcon';
import useDashboardHeader, { NavType, UserItemType } from './hooks/useDashboardHeader';

const Container = styled(Row)`
  display: flex;
  flex-wrap: nowrap;
  justify-content: center;
`;

const InnerContainer = styled(Row)`
  display: flex;
  flex-wrap: nowrap;
  justify-content: space-between;
  width: 90rem;
`;

const NavSection = styled(Row)`
  flex-wrap: nowrap;
`;

const Title = styled(Col)`
  align-items: center;
  min-width: 14rem;
  font-size: 1.714rem;
  font-weight: 700;
  color: white;
  cursor: pointer;
  &:hover {
    color: ${blue[4]};
  }
  &:active {
    color: ${blue[6]};
  }
`;

const LoginUserSection = styled(Row)`
  display: flex;
  align-items: center;
  justify-content: center;
`;

type DashBoardNavBarProps = {};

function DashBoardNavBar({}: DashBoardNavBarProps): JSX.Element {
  const {
    currentKey,
    onClickNavItem,
    onClickUserItem,
    loggedInUser,
    loggedInUserRole,
    isLicensed,
    isFixedCras,
    goToDebugMode,
  } = useDashboardHeader();

  const navItems: ItemType[] = useMemo(() => getNavItems(loggedInUserRole, isLicensed), [loggedInUserRole, isLicensed]);
  const systemItems: ItemType[] = useMemo(
    () => getSystemItems(loggedInUserRole, isLicensed),
    [loggedInUserRole, isLicensed],
  );
  const userItems: ItemType[] = useMemo(
    () => getUserItems(loggedInUser.username === 'Administrator', isLicensed),
    [loggedInUser.username, isLicensed],
  );

  return (
    <Container>
      <InnerContainer>
        <NavSection>
          <Title onClick={() => onClickNavItem({ key: isLicensed ? NavType.HOME : NavType.NOT_LICENSED })}>
            Log Monitor
          </Title>
          <Menu
            theme="dark"
            mode="horizontal"
            css={menuStyle}
            selectedKeys={[currentKey]}
            items={navItems}
            onClick={onClickNavItem}
          />
        </NavSection>

        <LoginUserSection>
          <Space size={'middle'}>
            {isFixedCras && (
              <div
                css={[
                  css`
                    color: white;
                  `,
                  hoverActiveStyleDefColor,
                ]}
                onClick={goToDebugMode}
              >
                Warning: Cras Server is fixed!
              </div>
            )}
            {(loggedInUserRole.ROLE_ADDRESS || loggedInUserRole.ROLE_ACCOUNT || loggedInUserRole.ROLE_CONFIGURE) && (
              <Dropdown
                arrow
                placement="bottom"
                overlay={
                  <Menu
                    css={systemMenuStyle}
                    items={systemItems}
                    onClick={onClickNavItem}
                    selectedKeys={[currentKey]}
                  />
                }
                trigger={['click']}
              >
                <div css={systemSettingStyle}>
                  <Space>
                    <SettingOutlined />
                  </Space>
                </div>
              </Dropdown>
            )}
            <Dropdown
              arrow
              placement="bottom"
              overlay={<Menu css={loginUserMenuStyle} items={userItems} onClick={onClickUserItem} />}
              trigger={['click']}
            >
              <div css={loginUserStyle}>
                {loggedInUser.username && (
                  <Space>
                    <CustomIcon name="user" />
                    <div>{loggedInUser.username}</div>
                  </Space>
                )}
              </div>
            </Dropdown>
          </Space>
        </LoginUserSection>
      </InnerContainer>
    </Container>
  );
}

function getNavItems(roles: AccountUserRoleBoolean, isLicensed: boolean): ItemType[] {
  const { ROLE_RULES, ROLE_ERRORLOG } = roles;
  const items: ItemType[] = [];

  if (isLicensed) {
    items.push(
      ...[
        {
          label: 'Job',
          key: NavType.JOB,
          icon: <PartitionOutlined />,
        },
        {
          label: 'Local Import',
          key: NavType.LOCAL_IMPORT,
          icon: <FileZipOutlined />,
        },
      ],
    );
  }

  if (isLicensed && ROLE_ERRORLOG) {
    items.push({
      label: 'Error Log',
      key: NavType.ERROR_LOG,
      icon: <AlertOutlined />,
      children: [
        {
          label: 'Download',
          key: NavType.ERROR_LOG_DOWNLOAD,
        },
        {
          label: 'Status',
          key: NavType.ERROR_LOG_STATUS,
        },
        {
          label: 'Setting',
          key: NavType.ERROR_LOG_SETTING,
        },
      ],
    });
  }

  if (isLicensed && ROLE_RULES) {
    items.push({
      label: 'Rules',
      key: NavType.RULES,
      icon: <FileProtectOutlined />,
      children: [
        {
          label: 'Convert Rules',
          key: NavType.RULES_CONVERT,
        },
        {
          label: 'Define',
          key: NavType.RULES_DEFINE,
          children: [
            {
              label: 'Column Define',
              key: NavType.RULES_DEFINE_COLUMN,
            },
            {
              label: 'Cylinder Param Define',
              key: NavType.RULES_DEFINE_CYLINDER,
            },
            {
              label: 'Machine Data Param',
              key: NavType.RULES_DEFINE_MACHINE,
            },
          ],
        },
        {
          label: 'Analysis',
          key: ' analysis:submenu',
          onClick: () => {},
          children: [
            {
              label: 'Cras Data',
              key: NavType.RULES_CRAS,
            },
            {
              label: 'Mahalanobis',
              key: NavType.RULE_ANALYSIS_MAHALANOBIS,
            },
            {
              label: 'Arcnet',
              key: NavType.RULE_ANALYSIS_ARCNET,
              children: [
                {
                  label: 'Item Setting',
                  key: NavType.RULE_ANALYSIS_ARCNET_ITEM,
                },
                {
                  label: 'Unit Setting',
                  key: NavType.RULE_ANALYSIS_ARCNET_UNIT,
                },
              ],
            },
          ],
        },
      ],
    });
  }

  items.push({
    label: 'Viewer',
    key: NavType.test,
    icon: <DatabaseOutlined />,
  });

  return items;
}

function getSystemItems(roles: AccountUserRoleBoolean, isLicensed: boolean): ItemType[] {
  const { ROLE_CONFIGURE, ROLE_ADDRESS, ROLE_ACCOUNT } = roles;
  const items: ItemType[] = [];

  if (ROLE_ADDRESS && isLicensed) {
    items.push({
      label: 'Address Book',
      key: NavType.ADDRESS_BOOK,
      icon: <BookOutlined />,
    });
  }

  if (ROLE_ACCOUNT && isLicensed) {
    items.push({
      label: 'Account',
      key: NavType.ACCOUNT,
      icon: <CustomIcon name="idcard" />,
    });
  }

  if (ROLE_CONFIGURE) {
    if (isLicensed) {
      items.push({
        label: 'Server Config',
        key: NavType.CONFIGURE,
        icon: <ApartmentOutlined />,
      });
    }

    items.push({
      label: 'System Config',
      key: NavType.SYSTEM_CONFIG,
      icon: <LaptopOutlined />,
    });
  }

  return items;
}

function getUserItems(isAdmin: boolean, isLicensed: boolean): ItemType[] {
  const items: ItemType[] = [];

  if (isLicensed) {
    items.push({
      label: 'Change Password',
      key: UserItemType.CHANGE_PASSWORD,
    });
  }

  items.push({
    label: 'Logout',
    key: UserItemType.LOGOUT,
  });

  return items;
}

const menuStyle = css`
  /* width: 50rem; */
  min-width: 31.25rem;
  font-size: 1rem;
`;

const loginUserStyle = css`
  color: white;
  cursor: pointer;
  &:hover {
    color: ${blue[2]};
  }
  display: flex;
  align-items: center;
  justify-content: center;
  height: 1.5rem;

  .ant-space {
    display: flex; // Space에 flex를 설정하지 않으면 Navar의 높이가 튀어나온다...
    .ant-space-item {
      display: flex; //Space의 align 속성이 적용되지 않기 대문에 내부 item에 flex 적용
    }
  }

  .anticon {
    font-size: 1.5rem;
  }
`;

const systemSettingStyle = css`
  color: white;
  cursor: pointer;
  &:hover {
    color: ${blue[2]};
  }
  display: flex;
  align-items: center;
  justify-content: center;
  height: 1.5rem;

  .ant-space {
    display: flex; // Space에 flex를 설정하지 않으면 Navar의 높이가 튀어나온다...
    .ant-space-item {
      display: flex; //Space의 align 속성이 적용되지 않기 대문에 내부 item에 flex 적용
    }
  }

  .anticon {
    font-size: 1.5rem;
  }
`;

const systemMenuStyle = css`
  .ant-dropdown-menu-item:hover {
    background-color: #e6f7ff;
    /* font-weight: 700; */
  }
`;

const loginUserMenuStyle = css`
  text-align: center;
  .ant-dropdown-menu-item:hover {
    background-color: #e6f7ff;
    /* font-weight: 700; */
  }
`;

export default DashBoardNavBar;
