import AccountChangePasswordModal, {
  AccountChangePasswordModalProps,
} from '@components/Account/Modal/AccountChangePasswordModal';
import AccountInvalidLicenseModal from '@components/Account/Modal/AccountInvalidLicenseModal';
import { PAGE_URL } from '@constants/constants';
import { MODAL_NAME } from '@constants/globalValue';
import useModals from '@hooks/useModal';
import useValidateLogin from '@hooks/useValidateLogin';
import { useGetAuthLogin } from '@libs/query/auth';
import { hasValidLicense } from '@libs/util/auth';
import { openNotification } from '@libs/util/notification';
import { loginUserSelector, setLoginUser } from '@reducers/slices/loginUser';
import useTypedSelector from '@reducers/useTypedSelector';
import type { ReqAuthLoginData } from '@typesdef/auth';
import { useForm } from 'antd/lib/form/Form';
import { AxiosError } from 'axios';
import md5 from 'md5';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';

export default function useLogin() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { openModal } = useModals();
  const [form] = useForm<ReqAuthLoginData>();
  const { validateToken } = useValidateLogin();
  const { isLoggedIn } = useTypedSelector(loginUserSelector);

  const { mutate: mutateLogin, isLoading: isMutateLogin } = useGetAuthLogin({
    onError: (error: AxiosError) => {
      openNotification('error', 'Error', 'Failed to login!', error);
    },

    onSuccess: (loginUserInfo) => {
      if (loginUserInfo.id && loginUserInfo.roles && loginUserInfo.username) {
        dispatch(setLoginUser({ ...loginUserInfo, isLoggedIn: true }));

        if (!hasValidLicense(loginUserInfo.licenseStatus)) {
          openModal(MODAL_NAME.AUTH.INVALID_LICENSE, AccountInvalidLicenseModal);
          navigate(PAGE_URL.NOT_LICENSED);
          return;
        }

        if (loginUserInfo.isInitialPassword) {
          openModal<AccountChangePasswordModalProps>(MODAL_NAME.AUTH.CHANGE_PASSWORD, AccountChangePasswordModal, {
            shouldChangePassword: true,
          });
          navigate(PAGE_URL.CHANGE_PASSWORD);
          return;
        }

        navigate(PAGE_URL.HOME);
      } else {
        openNotification('error', 'Error', 'Failed to login!');
      }
    },
  });

  const requestLogin = (loginData: ReqAuthLoginData) => {
    mutateLogin({
      ...loginData,
      password: md5(loginData.password),
    });
  };

  useEffect(() => {
    if (!isLoggedIn) {
      validateToken().then((result) => {
        if (result !== null) {
          const { licenseStatus, isInitialPassword } = result;
          if (!hasValidLicense(licenseStatus)) {
            openModal(MODAL_NAME.AUTH.INVALID_LICENSE, AccountInvalidLicenseModal);
            navigate(PAGE_URL.NOT_LICENSED);
            return;
          }

          if (isInitialPassword) {
            openModal<AccountChangePasswordModalProps>(MODAL_NAME.AUTH.CHANGE_PASSWORD, AccountChangePasswordModal, {
              shouldChangePassword: true,
            });
            navigate(PAGE_URL.CHANGE_PASSWORD);
            return;
          }

          navigate(PAGE_URL.HOME);
        }
      });
    } else {
      navigate(PAGE_URL.HOME);
    }
  }, []);

  return {
    requestLogin,
    isMutateLogin,
    form,
  };
}
