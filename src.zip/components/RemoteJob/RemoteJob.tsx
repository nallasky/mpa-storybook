import { AppstoreAddOutlined, FileSyncOutlined } from '@ant-design/icons';
import CustomIcon from '@components/common/atoms/CustomIcon';
import SideSteps from '@components/common/atoms/SideSteps';
import StepButton from '@components/common/atoms/StepButton';
import { css } from '@emotion/react';
import { stepTransition, variantsAxisForX } from '@libs/util/framerMotion';
import { RemoteJobType, REMOTE_JOB_STEP } from '@typesdef/Job';
import { PageHeader, Space } from 'antd';
import { AnimatePresence, motion } from 'framer-motion';
import React, { Fragment } from 'react';
import { useRemoteJob } from './hooks/useRemoteJob';
import RemoteJobCheck from './RemoteJobCheck';
import RemoteJobOther from './RemoteJobOther';
import RemoteJobSetting from './RemoteJobSetting';
import RemoteJobSteps from './RemoteJobSteps';

export interface RemoteJobProps {
  type: RemoteJobType;
}

export default function RemoteJob({ type }: RemoteJobProps): JSX.Element {
  const { current, direction, onNext, onPrev, onBack, onNextAction, disabledNext } = useRemoteJob({ type });

  return (
    <div css={style}>
      <PageHeader
        onBack={onBack}
        title={`${type === 'add' ? 'Add' : 'Edit'} Job Setting`}
        css={css`
          padding: 0 0 0 0;
          margin-bottom: 1rem;
        `}
      />
      <div className="setting__wrapper">
        <SideSteps current={current} stepList={remoteJobStepList} />
        <div className="setting__context">
          <div className="setting__context__title">
            <RemoteTitle current={current} />
            <StepButton
              current={current}
              onNext={onNext}
              onPrev={onPrev}
              lastStep={REMOTE_JOB_STEP.CHECK}
              nextActionPromise={onNextAction}
              type={type}
              disabled={disabledNext}
            />
          </div>
          <AnimatePresence mode="popLayout" initial={false} custom={direction}>
            <motion.div
              key={current}
              custom={direction}
              variants={variantsAxisForX(20)}
              initial="enter"
              animate="center"
              exit="exit"
              transition={stepTransition}
              className="setting__context__main"
            >
              {current === REMOTE_JOB_STEP.JOB && <RemoteJobSetting type={type} />}
              {current === REMOTE_JOB_STEP.STEPS && <RemoteJobSteps />}
              {current === REMOTE_JOB_STEP.OTHER && <RemoteJobOther />}
              {current === REMOTE_JOB_STEP.CHECK && <RemoteJobCheck />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

const remoteJobStepList = ['Job', 'Steps', 'Other', 'Check'];

const RemoteTitle = React.memo(function RemoteTitleMemo({ current }: { current: number }) {
  return (
    {
      [REMOTE_JOB_STEP.JOB]: (
        <Space>
          <CustomIcon name="plans_setting" />
          <span>Job</span>
        </Space>
      ),
      [REMOTE_JOB_STEP.STEPS]: (
        <Space>
          <FileSyncOutlined />
          <span>Steps</span>
        </Space>
      ),
      [REMOTE_JOB_STEP.OTHER]: (
        <Space>
          <AppstoreAddOutlined />
          <span>Others</span>
        </Space>
      ),
      [REMOTE_JOB_STEP.CHECK]: (
        <Space>
          <CustomIcon name="check_setting" />
          <span>Check</span>
        </Space>
      ),
    }[current] ?? <Fragment />
  );
});

const style = css`
  display: flex;
  flex-direction: column;
  width: 100%;
  .setting__wrapper {
    display: flex;
    width: 100%;
    padding-left: 1rem;
    .setting__context {
      display: flex;
      flex-direction: column;
      width: 100%;
      padding-left: 1rem;
      .setting__context__title {
        display: flex;
        justify-content: space-between;
        width: 100%;
        font-size: 1.125rem;
      }
      .setting__context__main {
        display: flex;
        flex-direction: column;
        width: 100%;
        padding-top: 2rem;
        padding-left: 2rem;
      }
    }
  }
`;
