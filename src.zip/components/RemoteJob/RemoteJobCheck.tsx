import PopupTip from '@components/common/atoms/PopupTip';
import { css } from '@emotion/react';
import {
  getRemoteJobErrorNotice,
  selectRemoteJobInfo,
  selectRemoteJobStepRules,
  selectRemoteJobStepsWithoutErrorNotice,
} from '@reducers/slices/remoteJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { RemoteJobStepDetailState, TransferRemoteJobJudgeRule } from '@typesdef/Job';
import { Badge, Tooltip } from 'antd';
import { Fragment, useMemo } from 'react';
import { convertStepType } from './Drawer/RemoteJobStepsDrawerCommon';

export type RemoteJobCheckProps = {};

export default function RemoteJobCheck({}: RemoteJobCheckProps): JSX.Element {
  const jobInfo = useTypedSelector(selectRemoteJobInfo);
  const steps = useTypedSelector(selectRemoteJobStepsWithoutErrorNotice);
  const rules = useTypedSelector(selectRemoteJobStepRules);
  const errorNotice = useTypedSelector(getRemoteJobErrorNotice);
  const errorNoticeRecipients = useMemo(() => {
    if (!errorNotice || errorNotice.isEmail === false) {
      return <div>Disable</div>;
    }

    const recipients = [
      ...errorNotice.groupBook.map((item) => `@${item.name}`),
      ...errorNotice.emailBook.map((item) => item.email),
      ...errorNotice.customEmails,
    ];

    if (recipients.length === 0) {
      return <div>Default Recipients</div>;
    } else {
      return (
        <Tooltip title={recipients.map((item) => item)} placement="right" color="blue">
          {`${recipients.length} Recipients (with Default)`}
        </Tooltip>
      );
    }
  }, [errorNotice]);

  return (
    <div css={style}>
      <div className="job-name">
        <div className="name">
          <Badge color="blue" />
          <span>Job Name</span>
        </div>
        <div className="value">{jobInfo.jobName}</div>
      </div>
      <div className="user-fab-name">
        <div className="name">
          <Badge color="blue" />
          <span>User-Fab Name</span>
        </div>
        <div className="value">{jobInfo.siteName}</div>
      </div>
      <div className="steps">
        <div className="name">
          <Badge color="blue" />
          <span>Steps</span>
        </div>
        <div className="value">
          {steps.map((item) => (
            <div
              css={css`
                margin-bottom: 1rem;
              `}
              key={item.uuid}
            >
              <StepsCheck step={item} steps={steps} rules={rules} />
            </div>
          ))}
        </div>
      </div>
      <div className="error-notice">
        <div className="name">
          <Badge color="blue" />
          <span>Error Notice</span>
        </div>
        <div>{errorNoticeRecipients}</div>
      </div>
    </div>
  );
}

type StepsCheckProps = {
  step: RemoteJobStepDetailState;
  steps: RemoteJobStepDetailState[];
  rules: TransferRemoteJobJudgeRule[];
};
function StepsCheck({ step, steps, rules }: StepsCheckProps) {
  if (step.stepType === 'collect') {
    return (
      <div className="sub-item">
        <div className="sub-item-name" title={step.stepName as string}>
          {step.stepName}
        </div>
        <div className="sub-item-value">
          <div>{convertStepType(step.stepType)}</div>
          <div>{`${step.planIds.length} Plans`}</div>
          <StepsCheckExecuteMode step={step} steps={steps} />
          <div>{`Retention Period / ${step.retentionPeriod} Day`}</div>
          {step.isFtp && <div>{`${step.ftps.length} FTP/SFTP`}</div>}
        </div>
      </div>
    );
  }

  if (step.stepType === 'convert') {
    return (
      <div className="sub-item">
        <div className="sub-item-name" title={step.stepName as string}>
          {step.stepName}
        </div>
        <div className="sub-item-value">
          <div>{convertStepType(step.stepType)}</div>
          <StepsCheckExecuteMode step={step} steps={steps} />
        </div>
      </div>
    );
  }

  if (step.stepType === 'summary') {
    return (
      <div className="sub-item">
        <div className="sub-item-name" title={step.stepName as string}>
          {step.stepName}
        </div>
        <div className="sub-item-value">
          <div>{convertStepType(step.stepType)}</div>
          <StepsCheckExecuteMode step={step} steps={steps} />
          <StepsCheckRecipients step={step} />
          <div>{`Before / ${step.before ?? 0} Day`}</div>
          <div>{`Retention Period / ${step.retentionPeriod} Day`}</div>
        </div>
      </div>
    );
  }

  if (step.stepType === 'cras') {
    return (
      <div className="sub-item">
        <div className="sub-item-name" title={step.stepName as string}>
          {step.stepName}
        </div>
        <div className="sub-item-value">
          <div>{convertStepType(step.stepType)}</div>
          <StepsCheckExecuteMode step={step} steps={steps} />
          <StepsCheckRecipients step={step} />
          <div>{`Before ${step.before ?? 0} Days`}</div>
          <div>{`${step.selectJudgeRules?.length ?? 0} / ${rules?.length ?? 0} Judge Rules`}</div>
          <div>{`Retention Period / ${step.retentionPeriod} Day`}</div>
        </div>
      </div>
    );
  }

  if (step.stepType === 'version') {
    return (
      <div className="sub-item">
        <div className="sub-item-name" title={step.stepName as string}>
          {step.stepName}
        </div>
        <div className="sub-item-value">
          <div>{convertStepType(step.stepType)}</div>
          <StepsCheckExecuteMode step={step} steps={steps} />
          <StepsCheckRecipients step={step} />
          <div>{`Before / ${step.before ?? 0} Day`}</div>
          <div>{`Retention Period / ${step.retentionPeriod} Day`}</div>
        </div>
      </div>
    );
  }

  if (step.stepType === 'purge') {
    return (
      <div className="sub-item">
        <div className="sub-item-name" title={step.stepName as string}>
          {step.stepName}
        </div>
        <div className="sub-item-value">
          <div>{convertStepType(step.stepType)}</div>
          <StepsCheckExecuteMode step={step} steps={steps} />
        </div>
      </div>
    );
  }

  if (step.stepType === 'notice') {
    return (
      <div className="sub-item">
        <div className="sub-item-name" title={step.stepName as string}>
          {step.stepName}
        </div>
        <div className="sub-item-value">
          <div>{convertStepType(step.stepType)}</div>
          <StepsCheckRecipients step={step} />
        </div>
      </div>
    );
  }

  if (step.stepType === 'mahalanobis') {
    return (
      <div className="sub-item">
        <div className="sub-item-name" title={step.stepName as string}>
          {step.stepName}
        </div>
        <div className="sub-item-value">
          <div>{convertStepType(step.stepType)}</div>
          <StepsCheckExecuteMode step={step} steps={steps} />
        </div>
      </div>
    );
  }

  if (step.stepType === 'custom') {
    return (
      <div className="sub-item">
        <div className="sub-item-name" title={step.stepName as string}>
          {step.stepName}
        </div>
        <div className="sub-item-value">
          <div>{convertStepType(step.stepType)}</div>
          <StepsCheckExecuteMode step={step} steps={steps} />
          {step.isEmail && <StepsCheckRecipients step={step} />}
        </div>
      </div>
    );
  }

  return <Fragment />;
}

function StepsCheckExecuteMode({ step, steps }: { step: RemoteJobStepDetailState; steps: RemoteJobStepDetailState[] }) {
  if (step.mode === 'time') {
    return <div>{`Specified Time / ${step.time.join(', ')}`}</div>;
  }

  if (step.mode === 'cycle') {
    const stepText = step.cycle !== null ? step.cycle.charAt(0).toUpperCase() + step.cycle.slice(1) : '';
    return (
      <Fragment>
        {step.time[0] && <div>{`Start Time / ${step.time[0]}`}</div>}
        <div>{`Cycle / ${step.period} ${stepText}`}</div>
      </Fragment>
    );
  }

  if (step.mode === 'pre') {
    return <div>{`Previous / ${steps.find((item) => item.uuid === step.preStep)?.stepName ?? ''}`}</div>;
  }

  if (step.mode === 'next') {
    return <div>{`Next / ${steps.find((item) => item.uuid === step.nextStep)?.stepName ?? ''}`}</div>;
  }

  return <Fragment />;
}

function StepsCheckRecipients({ step }: { step: RemoteJobStepDetailState }) {
  if (!step.isEmail) {
    return <Fragment />;
  }

  if (step.emailBook.length > 0 || step.groupBook.length > 0 || step.customEmails.length > 0) {
    const recipients = [
      ...step.groupBook.map((item) => `@${item.name}`),
      ...step.emailBook.map((item) => item.email),

      ...step.customEmails,
    ];

    return (
      <div>
        <PopupTip
          value={`${recipients.length} Recipients`}
          list={recipients.map((item) => item)}
          placement="right"
          color="blue"
        />
      </div>
    );
  } else {
    return <div>Default Recipients</div>;
  }
}

const style = css`
  font-size: 1rem;
  flex-wrap: nowrap;
  display: flex;
  flex-direction: column;
  margin-bottom: 2rem;

  .job-name,
  .user-fab-name,
  .error-notice,
  .steps {
    display: flex;
    .name {
      width: 14rem;
    }
    .value {
      display: flex;
      flex-direction: column;
      width: 49.125rem;
      .sub-item {
        display: flex;
        width: 49.125rem;
        .sub-item-name {
          width: 16rem;
          margin-right: 2rem;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
        }
        .sub-item-value {
          /* width: 34.125rem; */
          flex: 1;
        }
      }
    }
    margin-bottom: 1rem;
  }
`;
