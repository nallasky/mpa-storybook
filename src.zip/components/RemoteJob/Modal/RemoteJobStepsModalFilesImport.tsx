import { DeleteOutlined, ExclamationCircleOutlined, UploadOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import { Button, FormInstance, Modal, Popconfirm, Radio, Upload } from 'antd';
import { RcFile, UploadFile } from 'antd/es/upload/interface';
import React, { memo, useCallback, useEffect, useRef } from 'react';
import { FormRemoteJobStepsDrawer } from '../hooks/useRemoteJobStepsDrawer';
import useRemoteJobStepsModalFilesImport from '../hooks/useRemoteJobStepsModalFilesImport';

interface RemoteJobStepsModalFilesImportProps {
  form: FormInstance<FormRemoteJobStepsDrawer>;
}

export default React.memo(function RemoteJobStepsModalFilesImport({
  form,
}: RemoteJobStepsModalFilesImportProps): JSX.Element {
  const {
    visible,
    setVisible,
    onChangeMode,
    propsBefore,
    deleteAllFile,
    handleUpload,
    mode,
    buttonRef,
    error,
    isLoadingUpload,
    onClickUpload,
    stopPropagation,
  } = useRemoteJobStepsModalFilesImport({ form });

  const itemRender = useCallback(
    (originNode: React.ReactElement, file: UploadFile, fileList: Array<UploadFile>) => {
      if (mode === 'directory') {
        return <CustomItemRender originNode={originNode} file={file} fileList={fileList} />;
      } else {
        return originNode;
      }
    },
    [mode],
  );

  return (
    <Modal
      visible={visible}
      closable={!isLoadingUpload}
      onCancel={() => setVisible(false)}
      title="Import Files"
      width={500}
      okButtonProps={{ loading: isLoadingUpload }}
      cancelButtonProps={{
        disabled: isLoadingUpload,
      }}
      onOk={handleUpload}
      maskClosable={!isLoadingUpload}
    >
      <div css={style}>
        <div className="select-section">
          <Radio.Group value={mode} onChange={onChangeMode} disabled={isLoadingUpload}>
            <Radio value="directory">Directory</Radio>
            <Radio value="files">Files</Radio>
          </Radio.Group>
        </div>
        <div className="upload-section">
          <Popconfirm title="Delete All Files" onConfirm={deleteAllFile} onCancel={stopPropagation}>
            <Button className="delete-btn" icon={<DeleteOutlined />} type="dashed" onClick={stopPropagation} />
          </Popconfirm>
          <Upload {...propsBefore} multiple={mode === 'files'} directory={mode === 'directory'} itemRender={itemRender}>
            {mode === 'directory' ? (
              <Button className="select-btn" icon={<UploadOutlined />} onClick={onClickUpload} ref={buttonRef}>
                Select Directory
              </Button>
            ) : (
              <Button className="select-btn" icon={<UploadOutlined />}>
                Select Files
              </Button>
            )}
          </Upload>
        </div>
        {error && (
          <div className="error-section">
            <ExclamationCircleOutlined />
            <div>{error}</div>
          </div>
        )}
      </div>
    </Modal>
  );
});

const style = css`
  .select-section {
    margin-bottom: 2rem;
    color: red;
  }
  .upload-section {
    .ant-upload-list.ant-upload-list-text {
      overflow: auto;
      max-height: 30rem;
    }

    .ant-upload.ant-upload-select.ant-upload-select-text {
      .select-btn {
        width: 10rem;
      }
    }

    .select-files {
      display: flex;
      justify-content: center;
    }
    .delete-btn {
      position: absolute;
      left: 12rem;
    }
  }

  .error-section {
    display: flex;
    align-items: center;
    color: red;
    margin-top: 1rem;
    .anticon {
      margin-right: 0.5rem;
    }
  }
`;

const CustomItemRender = memo(function CustomItemRenderMemo({
  originNode,
  file,
  fileList,
}: {
  originNode: React.ReactElement;
  file: UploadFile;
  fileList: Array<UploadFile>;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const divElement: HTMLDivElement | undefined | null = ref.current?.querySelector('.ant-upload-list-item-name');

    if (divElement) {
      const { webkitRelativePath, name } = file as RcFile;
      const filePath = webkitRelativePath.split('/');
      // remove upper directory name
      filePath.shift();
      divElement.title = filePath.join('/') ?? name;
      divElement.innerHTML = filePath.join('/') ?? name;
    }
  }, []);

  return <div ref={ref}>{originNode}</div>;
});
