import { FormInstance, Modal } from 'antd';
import { FormRemoteJobStepsDrawer } from '../hooks/useRemoteJobStepsDrawer';
import useRemoteJobStepsModalPlans from '../hooks/useRemoteJobStepsModalPlans';
import RemoteJobPlanTable from '../RemoteJobPlanTable';

export type RemoteJobStepsModalPlansProps = {
  form: FormInstance<FormRemoteJobStepsDrawer>;
};

export default function RemoteJobStepsModalPlans({ form }: RemoteJobStepsModalPlansProps): JSX.Element {
  const {
    visible,
    selectSiteInfo,
    plans,
    isFetchingPlans,
    refreshPlans,
    selectPlanIds,
    setSelectPlanIds,
    handleOk,
    handleCancel,
  } = useRemoteJobStepsModalPlans({ form });

  return (
    <Modal
      title={'Edit Plans'}
      visible={visible}
      okText={'Edit'}
      onOk={handleOk}
      onCancel={handleCancel}
      // cancelButtonProps={{
      //   disabled: isFetchingAddEdit,
      // }}
      // closable={!isFetchingAddEdit}
      // maskClosable={!isFetchingAddEdit}
      maskClosable
      width={'1200px'}
    >
      <RemoteJobPlanTable
        plans={plans}
        selectPlanIds={selectPlanIds}
        setSelectPlanIds={setSelectPlanIds}
        isFetchingPlans={isFetchingPlans}
        refreshPlans={refreshPlans}
        selectSiteInfo={selectSiteInfo}
      />
    </Modal>
  );
}
