import { DeleteOutlined, EditOutlined, HistoryOutlined, PlusOutlined } from '@ant-design/icons';
import { ellipsisLineStyle } from '@components/common/atoms/Common/Common';
import CustomIcon from '@components/common/atoms/CustomIcon';
import StepMilestoneModal from '@components/common/atoms/StepMilestoneModal';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { NAV_BAR_HIGHT } from '@constants/globalValue';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { errorIconStyle, hoverActiveStyle } from '@styles/emotion/common';
import { TableColumnPropsType } from '@typesdef/common';
import { AVAILABLE_MANUAL_EXECUTE_STEPS, JobModeType, JobStepType, RemoteJobStepDetailState } from '@typesdef/Job';
import { Button, Checkbox, Popconfirm, Space, Table, Tooltip } from 'antd';
import { TableRowSelection } from 'antd/es/table/interface';
import React, { Fragment, useCallback } from 'react';
import RemoteJobStepsDrawer from './Drawer/RemoteJobStepsDrawer';
import { convertStepType } from './Drawer/RemoteJobStepsDrawerCommon';
import useRemoteJobSteps from './hooks/useRemoteJobSteps';
import RemoteJobStepsModalAdd from './Modal/RemoteJobStepsModalAdd';

export type RemoteJobStepsProps = {};

export default function RemoteJobSteps({}: RemoteJobStepsProps): JSX.Element {
  const {
    stepList,
    enableList,
    setEnableList,
    onChangeEnable,
    onToggleAllEnable,
    openAddStepDrawer,
    openEditStepDrawer,
    onDeleteStep,
    form,
    stepMilestone,
    isMilestone,
    setMilestone,
  } = useRemoteJobSteps();

  const AllCheckEnable = () => (
    <Checkbox
      checked={enableList && enableList.length ? true : false}
      indeterminate={stepList && enableList && enableList.length > 0 && enableList.length < stepList.length}
      onChange={onToggleAllEnable}
    />
  );

  const rowSelection: TableRowSelection<RemoteJobStepDetailState> = {
    type: 'checkbox',
    selectedRowKeys: enableList as string[],
    onChange: onChangeEnable,
    columnTitle: <AllCheckEnable />,
  };

  const onCell = (record: RemoteJobStepDetailState, rowIndex: number | undefined) => ({
    // onClick: (event: React.MouseEvent<HTMLElement, MouseEvent>) => {
    //   if (enableList.find((item) => item === record.uuid) !== undefined) {
    //     setEnableList(enableList.filter((item) => item !== record.uuid) as string[]);
    //   } else {
    //     setEnableList(enableList.concat(record.uuid) as string[]);
    //   }
    // },
  });

  const renderTitle = useCallback(
    () => (
      <TableHeader title={<TableHeaderTitle total={stepList?.length ?? 0} />}>
        <Button icon={<HistoryOutlined />} type="primary" onClick={() => setMilestone(true)}>
          Milestone
        </Button>
        <Button icon={<PlusOutlined />} type="primary" onClick={openAddStepDrawer}>
          Add
        </Button>
      </TableHeader>
    ),
    [stepList, openAddStepDrawer, setMilestone],
  );

  const stepTypeRender = useCallback(
    (value: JobStepType, record: RemoteJobStepDetailState, index: number) => <div>{convertStepType(value)}</div>,
    [],
  );

  const executeModeRender = useCallback(
    (value: JobModeType, record: RemoteJobStepDetailState, index: number) => {
      let title: React.ReactNode = null;

      switch (value) {
        case 'time':
          title = record.time ? (
            <Fragment>
              {record.time.map((item) => (
                <div key={item}>{item}</div>
              ))}
            </Fragment>
          ) : null;
          break;
        case 'cycle':
          title = `${record.period} ${record.cycle}` ?? null;
          break;
        case 'pre':
          title = stepList.find((item) => item.uuid === record.preStep)?.stepName ?? null;
          break;
        case 'next':
          title = stepList.find((item) => item.uuid === record.nextStep)?.stepName ?? null;
          break;
        case 'none':
          title = '';
          break;
        default:
          break;
      }

      return (
        <Tooltip placement="right" title={title}>
          <Space>
            <div>{convertExecuteMode(value)}</div>
            {title === null && AVAILABLE_MANUAL_EXECUTE_STEPS.includes(record.stepType) && (
              <Tooltip placement="right" title={'No Value'} color="red">
                <CustomIcon css={errorIconStyle} name="warning" />
                {/* it need to diplay tooltip */}
                <div></div>
              </Tooltip>
            )}
          </Space>
        </Tooltip>
      );
    },
    [stepList],
  );

  const editRender = useCallback(
    (value: string, record: RemoteJobStepDetailState, index: number) => {
      return (
        <Popconfirm
          title="Are you sure to edit this step?"
          onConfirm={() => openEditStepDrawer(record)}
          okText="Ok"
          cancelText="Cancel"
        >
          <EditOutlined css={hoverActiveStyle} />
        </Popconfirm>
      );
    },
    [openEditStepDrawer],
  );

  const deleteRender = useCallback(
    (value: string, record: RemoteJobStepDetailState, index: number) => {
      return (
        <Popconfirm
          title="Are you sure to delete this step?"
          onConfirm={() => onDeleteStep(value)}
          okText="Ok"
          cancelText="Cancel"
        >
          <DeleteOutlined css={hoverActiveStyle} />
        </Popconfirm>
      );
    },
    [onDeleteStep],
  );

  return (
    <div css={style}>
      <Table<RemoteJobStepDetailState>
        rowKey={'uuid'}
        rowSelection={rowSelection}
        dataSource={stepList ?? []}
        bordered
        title={renderTitle}
        size="small"
        pagination={{
          position: ['bottomCenter'],
        }}
        // onRow={onRow}
        tableLayout="fixed"
        sticky={{ offsetHeader: NAV_BAR_HIGHT }}
      >
        <Table.Column<RemoteJobStepDetailState> {...columnProps.stepName} onCell={onCell} />
        <Table.Column<RemoteJobStepDetailState> {...columnProps.stepType} onCell={onCell} render={stepTypeRender} />
        <Table.Column<RemoteJobStepDetailState>
          {...columnProps.executeMode}
          onCell={onCell}
          render={executeModeRender}
        />
        <Table.Column<RemoteJobStepDetailState> {...columnProps.description} onCell={onCell} />
        <Table.Column<RemoteJobStepDetailState> {...columnProps.edit} render={editRender} />
        <Table.Column<RemoteJobStepDetailState> {...columnProps.delete} render={deleteRender} />
      </Table>
      <RemoteJobStepsModalAdd form={form} />
      <RemoteJobStepsDrawer form={form} />
      <StepMilestoneModal steps={stepMilestone} visible={isMilestone} setVisible={setMilestone} />
    </div>
  );
}

const style = css`
  .ant-table-tbody {
    cursor: default;
  }
`;

type ColumnName = 'stepName' | 'stepType' | 'executeMode' | 'description' | 'edit' | 'delete';

const columnProps: TableColumnPropsType<RemoteJobStepDetailState, ColumnName> = {
  //enable width: 58
  stepName: {
    key: 'stepName',
    title: <TableColumnTitle>Step Name</TableColumnTitle>,
    dataIndex: 'stepName',
    className: 'stepName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'stepName'),
    },
    width: getPixelPercent(1056, 238),
  },
  stepType: {
    key: 'stepType',
    title: <TableColumnTitle>Step Type</TableColumnTitle>,
    dataIndex: 'stepType',
    className: 'stepType',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'stepType'),
    },
    width: getPixelPercent(1056, 150),
  },
  executeMode: {
    key: 'mode',
    title: <TableColumnTitle>Execute Mode</TableColumnTitle>,
    dataIndex: 'mode',
    className: 'mode',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'mode'),
    },
    width: getPixelPercent(1056, 150),
  },
  description: {
    key: 'description',
    title: <TableColumnTitle>Description</TableColumnTitle>,
    dataIndex: 'description',
    className: 'description',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'description'),
    },
    render: function renderDescription(value: string, record: RemoteJobStepDetailState, index: number) {
      return (
        <div title={value} css={ellipsisLineStyle({ line: 2 })}>
          {value}
        </div>
      );
    },
    width: getPixelPercent(1056, 300),
  },
  edit: {
    key: 'edit',
    title: <TableColumnTitle>Edit</TableColumnTitle>,
    dataIndex: 'uuid',
    className: 'edit',
    align: 'center',
    width: getPixelPercent(1056, 80),
  },
  delete: {
    key: 'delete',
    title: <TableColumnTitle>Delete</TableColumnTitle>,
    dataIndex: 'uuid',
    className: 'delete',
    align: 'center',
    width: getPixelPercent(1056, 80),
  },
};

export const convertExecuteMode = (value: JobModeType): string =>
  ({
    time: 'Time',
    cycle: 'Cycle',
    pre: 'Previous',
    next: 'Next',
    none: 'None',
  }[value] ?? '-');
