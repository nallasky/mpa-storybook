import { DesktopOutlined, PushpinOutlined, ReloadOutlined } from '@ant-design/icons';
import RefreshBtn from '@components/common/atoms/RefreshBtn';
import { NAME_MAX_LENGTH } from '@constants/constants';
import { css } from '@emotion/react';
import { RemoteJobType } from '@typesdef/Job';
import { Input, Select, Space } from 'antd';
import { LabeledValue } from 'antd/es/select';
import { useRemoteJobSetting } from './hooks/useRemoteJobSetting';

export type RemoteJobSettingProps = {
  type: RemoteJobType;
};

export default function RemoteJobSetting({ type }: RemoteJobSettingProps): JSX.Element {
  const {
    selectJob,
    selectSiteInfo,
    setSelectSiteInfo,
    setJobName,
    siteList,
    isFetchingSiteList,
    refreshSiteList,
    isCollectStep,
  } = useRemoteJobSetting();

  return (
    <div css={style}>
      <div className="job-name">
        <Space css={spaceStyle}>
          <PushpinOutlined />
          <span>Job Name</span>
        </Space>
        <Input
          placeholder="Input a job name"
          maxLength={NAME_MAX_LENGTH}
          value={selectJob.jobName ?? undefined}
          onChange={setJobName}
        />
      </div>
      <div className="user-fabName">
        <Space css={spaceStyle}>
          <DesktopOutlined />
          <span>User-Fab Name</span>
        </Space>
        <Select<LabeledValue>
          showSearch
          labelInValue
          css={selectStyle}
          value={selectSiteInfo.value ? selectSiteInfo : undefined}
          placeholder="Select a user-fab"
          onSelect={setSelectSiteInfo}
          loading={isFetchingSiteList}
          disabled={isFetchingSiteList || isCollectStep}
          optionFilterProp="children"
          //filterOption={(input, option) => option?.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
          filterOption={(input, option) =>
            Boolean((option?.children as unknown as string).toLowerCase().indexOf(input.toLowerCase()) >= 0)
          }
        >
          {siteList?.map((item) => (
            <Select.Option key={item.siteId} value={item.siteId} label={item.crasCompanyFabName}>
              {item.crasCompanyFabName}
            </Select.Option>
          ))}
        </Select>

        {type === 'add' && (
          <RefreshBtn
            type="primary"
            icon={<ReloadOutlined />}
            css={btnStyle}
            onClick={refreshSiteList}
            loading={isFetchingSiteList}
            disabled={isFetchingSiteList}
          />
        )}
      </div>
      {isCollectStep && (
        <div className="user-fabName-warning">To change User-Fab Name, you must delete all Collect Steps.</div>
      )}
    </div>
  );
}

const style = css`
  font-size: 1rem;
  flex-wrap: nowrap;
  display: flex;
  flex-direction: column;

  .job-name {
    display: inherit;
    .ant-input {
      width: 33.75rem;
      font-size: 1rem;
    }
  }

  .user-fabName {
    display: inherit;
    font-size: 1rem;
    margin-top: 2rem;
    flex-wrap: nowrap;
  }
  .user-fabName-warning {
    margin-left: 13.25rem;
    font-size: 0.875rem;
    color: #faad14;
  }
`;

const spaceStyle = css`
  width: 13.25rem;
  margin-bottom: 0.5rem;
`;

const selectStyle = css`
  width: 33.75rem;
  text-align: center;
  font-size: inherit;
`;

const btnStyle = css`
  border-radius: 0.625rem;
  margin-left: 0.5rem;
`;
