import AddressSelect from '@components/common/atoms/AddressSelect';
import { css } from '@emotion/react';
import { getRemoteJobErrorNoticeEmail, setRemoteJobStepErrorNotice } from '@reducers/slices/remoteJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { AddressOption } from '@typesdef/address';
import { Badge } from 'antd';
import React, { useCallback, useMemo } from 'react';
import { useDispatch } from 'react-redux';
import { convertRecipientState } from './hooks/useRemoteJobSteps';

export default React.memo(function RemoteJobOtherErrorNotice(): JSX.Element {
  const dispatch = useDispatch();
  const { emailBook, groupBook, customEmails } = useTypedSelector(getRemoteJobErrorNoticeEmail);
  const recipients = useMemo(
    () =>
      convertRecipientState({
        groupBook,
        emailBook,
        customEmails,
      }),
    [emailBook, groupBook, customEmails],
  );

  const setEachRecipients = useCallback(
    ({
      emailBook,
      groupBook,
      customEmails,
    }: {
      emailBook: AddressOption[];
      groupBook: AddressOption[];
      customEmails: string[];
    }) => {
      dispatch(
        setRemoteJobStepErrorNotice({
          emailBook,
          groupBook,
          customEmails,
        }),
      );
    },
    [dispatch],
  );

  return (
    <div css={style}>
      <div className="subject">
        <div className="subject-title">
          <Badge color="blue" />
          <span>Recipients</span>
        </div>
        <div className="subject-value">
          <AddressSelect recipients={recipients} setEachRecipients={setEachRecipients} />
        </div>
      </div>
    </div>
  );
});

const style = css`
  display: flex;
  flex-direction: column;
  gap: 1rem;

  .subject {
    display: flex;
    .subject-title {
      display: flex;
      width: 10rem;
    }
    .subject-value {
      display: flex;
    }
  }
`;
