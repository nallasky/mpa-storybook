import PopupTip from '@components/common/atoms/PopupTip';
import RefreshBtn from '@components/common/atoms/RefreshBtn/RefreshBtn';
import TableHeader from '@components/common/atoms/TableHeader';
import { TableHeaderTitle } from '@components/common/atoms/TableHeader/TableHeader';
import { css } from '@emotion/react';
import { TableColumnTitle } from '@libs/util/commonStyle';
import { compareTableItem } from '@libs/util/compareTableItem';
import { getPixelPercent } from '@libs/util/convert';
import { TableColumnPropsType } from '@typesdef/common';
import { PlanStatusType, RemoteJobPlanDetailState } from '@typesdef/Job';
import { Badge, Checkbox, Table, Tooltip } from 'antd';
import { LabeledValue } from 'antd/es/select';
import { TableRowSelection } from 'antd/es/table/interface';
import React, { Fragment, useCallback } from 'react';

export type RemoteJobPlanTableProps = {
  plans: RemoteJobPlanDetailState[] | undefined;
  selectPlanIds: number[];
  setSelectPlanIds: (value: React.Key[]) => void;
  isFetchingPlans: boolean;
  refreshPlans: () => void;
  selectSiteInfo: LabeledValue;
};

export default React.memo(function RemoteJobPlanTable({
  plans,
  selectPlanIds,
  setSelectPlanIds,
  isFetchingPlans,
  refreshPlans,
  selectSiteInfo,
}: RemoteJobPlanTableProps): JSX.Element {
  const renderPlanType = useCallback(
    (value: string, record: RemoteJobPlanDetailState, index: number, type?: ColumnName) => {
      return <div>{getPlanType(value)}</div>;
    },
    [],
  );

  const renderStatus = useCallback(
    (value: string, record: RemoteJobPlanDetailState, index: number, type?: ColumnName) => {
      return (
        <Badge status={value === 'stop' ? 'error' : 'processing'} text={value === 'stop' ? 'Stopped' : 'Running'} />
      );
    },
    [],
  );

  const renderDetail = useCallback(
    (value: PlanStatusType, record: RemoteJobPlanDetailState, index: number, type?: ColumnName) => {
      const text = value?.charAt(0).toUpperCase() + value?.slice(1) ?? 'Unknown';
      return (
        <Fragment>
          {record.error ? (
            <Tooltip color="red" title={<ErrorDetailPopup error={record.error} measure={record.measure} />}>
              <Badge color={getErrorDetailColor(value)} text={text} />
            </Tooltip>
          ) : (
            <Badge color={getErrorDetailColor(value)} text={text} />
          )}
        </Fragment>
      );
    },
    [],
  );

  const renderMachine = useCallback(
    (value: number, record: RemoteJobPlanDetailState, index: number, type?: ColumnName) => (
      <PopupTip value={value} list={record.machineNames} />
    ),
    [],
  );

  const renderTarget = useCallback(
    (value: number, record: RemoteJobPlanDetailState, index: number, type?: ColumnName) => (
      <PopupTip value={value} list={record.targetNames} />
    ),
    [],
  );

  const renderTitle = useCallback(
    () => (
      <TableHeader title={<TableHeaderTitle total={plans?.length ?? 0} />}>
        <RefreshBtn onClick={refreshPlans} loading={isFetchingPlans} disabled={!selectSiteInfo?.value} />
      </TableHeader>
    ),
    [plans, isFetchingPlans, selectSiteInfo, refreshPlans],
  );

  const onSelectChange = (selectedRowKeys: React.Key[], selectedRows: RemoteJobPlanDetailState[]) => {
    setSelectPlanIds(selectedRowKeys);
  };

  const toggleSelectAll = useCallback(() => {
    if (plans && plans.length > 0)
      setSelectPlanIds(
        selectPlanIds.length === plans.length ? [] : plans.map((r: RemoteJobPlanDetailState) => r.planId),
      );
  }, [plans, selectPlanIds, setSelectPlanIds]);

  const AllCheckbox = () => (
    <Checkbox
      checked={selectPlanIds && selectPlanIds.length ? true : false}
      indeterminate={plans && selectPlanIds && selectPlanIds.length > 0 && selectPlanIds.length < plans.length}
      onChange={toggleSelectAll}
    />
  );

  const rowSelection: TableRowSelection<RemoteJobPlanDetailState> = {
    type: 'checkbox',
    selectedRowKeys: selectPlanIds,
    onChange: onSelectChange,
    columnTitle: <AllCheckbox />,
  };

  const onRow = (record: RemoteJobPlanDetailState, rowIndex: number | undefined) => ({
    onClick: (event: React.MouseEvent<HTMLElement, MouseEvent>) => {
      if (record.planId !== undefined) {
        if (selectPlanIds.find((item) => item === record.planId) !== undefined) {
          setSelectPlanIds(selectPlanIds.filter((item) => item !== record.planId));
        } else {
          setSelectPlanIds(selectPlanIds.concat(record.planId));
        }
      }
    },
  });

  return (
    <Table<RemoteJobPlanDetailState>
      rowKey={'planId'}
      rowSelection={rowSelection}
      dataSource={plans}
      bordered
      title={renderTitle}
      size="middle"
      pagination={{
        position: ['bottomCenter'],
      }}
      loading={isFetchingPlans}
      onRow={onRow}
      tableLayout="fixed"
      css={tableStyle}
    >
      <Table.Column<RemoteJobPlanDetailState> {...columnProps.planName} />
      <Table.Column<RemoteJobPlanDetailState> {...columnProps.description} />
      <Table.Column<RemoteJobPlanDetailState> {...columnProps.planType} render={renderPlanType} />
      <Table.Column<RemoteJobPlanDetailState> {...columnProps.machineCount} render={renderMachine} />
      <Table.Column<RemoteJobPlanDetailState> {...columnProps.targetCount} render={renderTarget} />
      <Table.Column<RemoteJobPlanDetailState> {...columnProps.status} render={renderStatus} />
      <Table.Column<RemoteJobPlanDetailState> {...columnProps.detail} render={renderDetail} />
    </Table>
  );
});

type ColumnName = 'planName' | 'description' | 'planType' | 'machineCount' | 'targetCount' | 'status' | 'detail';

const columnProps: TableColumnPropsType<RemoteJobPlanDetailState, ColumnName> = {
  planName: {
    key: 'planName',
    title: <TableColumnTitle>Plan Name</TableColumnTitle>,
    dataIndex: 'planName',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'planName'),
    },
    width: getPixelPercent(1000, 210),
  },
  description: {
    key: 'description',
    title: <TableColumnTitle>Description</TableColumnTitle>,
    dataIndex: 'description',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'description'),
    },
    width: getPixelPercent(1000, 234),
  },
  planType: {
    key: 'plan_type',
    title: <TableColumnTitle>Type</TableColumnTitle>,
    dataIndex: 'planType',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'planType'),
    },
    width: getPixelPercent(1000, 146),
  },
  machineCount: {
    key: 'machines',
    title: <TableColumnTitle>Machines</TableColumnTitle>,
    dataIndex: 'machineCount',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'machineCount'),
    },
    width: getPixelPercent(1000, 100),
  },
  targetCount: {
    key: 'targets',
    title: <TableColumnTitle>Targets</TableColumnTitle>,
    dataIndex: 'targetCount',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'targetCount'),
    },
    width: getPixelPercent(1000, 100),
  },
  status: {
    key: 'status',
    title: <TableColumnTitle>Status</TableColumnTitle>,
    dataIndex: 'status',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'status'),
    },
    width: getPixelPercent(1000, 110),
  },
  detail: {
    key: 'detail',
    title: <TableColumnTitle>Detail</TableColumnTitle>,
    dataIndex: 'detail',
    align: 'center',
    sorter: {
      compare: (a, b) => compareTableItem(a, b, 'detail'),
    },
    width: getPixelPercent(1000, 110),
  },
};

const ErrorDetailPopup = React.memo(function ErrorDetailPopupMemo({
  error,
  measure,
}: {
  error: string;
  measure: string;
}) {
  return (
    <div>
      <div>• Error</div>
      <p
        css={css`
          white-space: pre-line;
        `}
      >
        {error}
      </p>
      <p />
      <div>• Detail</div>
      <p
        css={css`
          white-space: pre-line;
        `}
      >
        {measure}
      </p>
    </div>
  );
});

const getErrorDetailColor = (value: PlanStatusType): string =>
  ({
    registered: '#d9d9d9',
    collecting: 'blue',
    collected: 'green',
    suspended: 'red',
    halted: 'red',
    completed: '#d9d9d9',
  }[value] ?? '#d9d9d9');

const getPlanType = (value: string): string =>
  ({
    ftp: 'FTP',
    vftp_compat: 'VFTP(COMPAT)',
    vftp_sss: 'VFTP(SSS)',
  }[value] ?? '-');

const tableStyle = css`
  .ant-table-tbody {
    tr {
      cursor: pointer;
    }
  }
`;
