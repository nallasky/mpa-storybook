import AddressSelect from '@components/common/atoms/AddressSelect';
import { EMAIL_SUBJECT_MAX } from '@constants/constants';
import { css } from '@emotion/react';
import { Form, FormInstance, Input, Switch } from 'antd';
import { Fragment } from 'react';
import { FormRemoteJobStepsDrawer } from '../hooks/useRemoteJobStepsDrawer';
import useRemoteJobStepsDrawerEmail from '../hooks/useRemoteJobStepsDrawerEmail';
import RemoteJobStepsModalAddrBook from '../Modal/RemoteJobStepsModalAddrBook';
import { StepCommonLabel } from './RemoteJobStepsDrawerCommon';

export default function RemoteJobStepsDrawerEmail({ form }: { form: FormInstance<FormRemoteJobStepsDrawer> }) {
  const { recipients, setRecipients, isEnableEmail, setEnableEmail, itemVisible } = useRemoteJobStepsDrawerEmail({
    form,
  });

  return (
    <div css={style}>
      <Form.Item label={<StepCommonLabel label="Email" />} className="isEmail" name="isEmail">
        <Switch checkedChildren="On" unCheckedChildren="Off" onChange={setEnableEmail} checked={isEnableEmail} />
      </Form.Item>
      {isEnableEmail && (
        <Fragment>
          <Form.Item
            label={<StepCommonLabel label="Recipients" depth={1} />}
            name="recipient"
            // rules={[
            //   {
            //     required: true,
            //     message: 'Please input recipients!',
            //     validator: (rule, value) =>
            //       new Promise((resolve, reject) => {
            //         if (value.length === 0) {
            //           reject(false);
            //         }
            //         resolve(true);
            //       }),
            //   },
            // ]}
            colon={false}
          >
            <AddressSelect recipients={recipients} setRecipients={setRecipients} />
          </Form.Item>
          {itemVisible.isSubject && (
            <Form.Item
              label={<StepCommonLabel label="Subject" depth={1} />}
              name="subject"
              // rules={[{ required: true, message: 'Please input a subject!' }]}
              colon={false}
            >
              <Input placeholder="Input a subject to replace the default." allowClear maxLength={EMAIL_SUBJECT_MAX} />
            </Form.Item>
          )}
          {itemVisible.isBody && (
            <Form.Item
              label={<StepCommonLabel label="Body" depth={1} />}
              name="body"
              // rules={[{ required: true, message: 'Please input a body!' }]}
              colon={false}
            >
              <Input.TextArea
                autoSize={{ minRows: 3, maxRows: 5 }}
                placeholder="Input a body to replace the default."
                allowClear
              />
            </Form.Item>
          )}
          <RemoteJobStepsModalAddrBook form={form} />
        </Fragment>
      )}
    </div>
  );
}

const style = css`
  .isEmail {
    label::after {
      color: transparent;
    }
  }
`;
