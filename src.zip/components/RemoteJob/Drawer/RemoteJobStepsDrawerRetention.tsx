import { css } from '@emotion/react';
import { Form, FormInstance, InputNumber, Space } from 'antd';
import { FormRemoteJobStepsDrawer } from '../hooks/useRemoteJobStepsDrawer';
import { StepCommonLabel } from './RemoteJobStepsDrawerCommon';

export type RemoteJobStepsDrawerRetentionProps = {
  form: FormInstance<FormRemoteJobStepsDrawer>;
};

export default function RemoteJobStepsDrawerRetention({ form }: RemoteJobStepsDrawerRetentionProps): JSX.Element {
  return (
    <div css={styleBefore}>
      <Space>
        <Form.Item
          label={<StepCommonLabel label="Retention Period" />}
          className="retentionPeriod"
          name="retentionPeriod"
          rules={[
            {
              required: true,
              message: `Please input a number between 1 to 9999!`,
            },
          ]}
          colon={false}
        >
          <InputNumber
            min={1}
            max={9999}
            maxLength={4}
            precision={0}
            addonAfter="Days"
            css={css`
              width: 8.375rem;
            `}
          />
        </Form.Item>
      </Space>
    </div>
  );
}

const styleBefore = css``;
