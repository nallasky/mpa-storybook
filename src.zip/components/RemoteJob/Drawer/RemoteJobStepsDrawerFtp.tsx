import { css } from '@emotion/react';
import { useGetSystemConfigFtpList } from '@libs/query/systemConfig';
import { convertFromFtpToFtpLabel } from '@libs/util/job';
import type { RemoteJobFTPWithLabel } from '@typesdef/Job';
import type { FormInstance } from 'antd';
import { Form, Select, Switch } from 'antd';
import { useWatch } from 'antd/es/form/Form';
import type { FormRemoteJobStepsDrawer } from '../hooks/useRemoteJobStepsDrawer';
import { StepCommonLabel } from './RemoteJobStepsDrawerCommon';

export type RemoteJobStepsDrawerFtpProps = {
  form: FormInstance<FormRemoteJobStepsDrawer>;
};

export default function RemoteJobStepsFtpRetention({ form }: RemoteJobStepsDrawerFtpProps): JSX.Element {
  const { data: ftpList, isFetching: isFetchingFtpList } = useGetSystemConfigFtpList();
  const isFtpWatch = useWatch('isFtp', form);

  return (
    <div css={style}>
      <Form.Item label={<StepCommonLabel label="FTP/SFTP" />} className="isFtp" name="isFtp" valuePropName="checked">
        <Switch checkedChildren="On" unCheckedChildren="Off" />
      </Form.Item>
      {isFtpWatch && (
        <Form.Item
          label={<StepCommonLabel depth={1} label="FTP/SFTP Server" />}
          className="ftps"
          name="ftps"
          colon={false}
          rules={[{ required: true, type: 'array', message: 'Please add FTP/SFTP server!' }]}
        >
          <Select<number, RemoteJobFTPWithLabel>
            loading={isFetchingFtpList}
            allowClear
            mode="multiple"
            onChange={(value, option) => {
              form.setFieldsValue({
                ftps: Array.isArray(option) ? option : [option],
              });
            }}
            options={Array.isArray(ftpList) ? ftpList.map(convertFromFtpToFtpLabel) : []}
          />
        </Form.Item>
      )}
    </div>
  );
}

const style = css``;
