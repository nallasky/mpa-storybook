import { EditOutlined } from '@ant-design/icons';
import { H_SPACE } from '@components/common/atoms/Space';
import { css } from '@emotion/react';
import { Button, Form, FormInstance } from 'antd';
import { FormRemoteJobStepsDrawer } from '../hooks/useRemoteJobStepsDrawer';
import useRemoteJobStepsDrawerPlans from '../hooks/useRemoteJobStepsDrawerPlans';
import RemoteJobStepsModalPlans from '../Modal/RemoteJobStepsModalPlans';
import { StepCommonLabel } from './RemoteJobStepsDrawerCommon';

export type RemoteJobStepsDrawerPlansProps = {
  form: FormInstance<FormRemoteJobStepsDrawer>;
};

export default function RemoteJobStepsDrawerPlans({ form }: RemoteJobStepsDrawerPlansProps): JSX.Element {
  const { selectedPlans, onOpenEditModal } = useRemoteJobStepsDrawerPlans({ form });
  return (
    <div css={style}>
      <Form.Item label={<StepCommonLabel label="Plans" />} className="plans" colon={false}>
        <div className="select-plans">
          <div>{`${selectedPlans.length} Plans`}</div>
          <H_SPACE rem={2} />
          <Button
            type="dashed"
            icon={<EditOutlined />}
            onClick={onOpenEditModal}
            css={css`
              border-radius: 0.625rem;
            `}
          >
            Edit
          </Button>
        </div>
        {/* just for setting form value */}
        <Form.Item
          noStyle
          name="planIds"
          rules={[
            {
              required: true,
              type: 'array',
              message: 'Please select at least one plan!',
            },
          ]}
        />
      </Form.Item>

      <RemoteJobStepsModalPlans form={form} />
    </div>
  );
}

const style = css`
  .select-plans {
    display: flex;
    align-items: center;
  }
`;
