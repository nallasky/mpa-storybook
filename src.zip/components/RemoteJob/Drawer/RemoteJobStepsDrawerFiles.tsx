import { css } from '@emotion/react';
import { hoverStyle } from '@styles/emotion/common';
import { Button, Form, FormInstance, Popconfirm, Popover, Space } from 'antd';
import { FormRemoteJobStepsDrawer } from '../hooks/useRemoteJobStepsDrawer';
import useRemoteJobStepsDrawerFiles from '../hooks/useRemoteJobStepsDrawerFiles';
import RemoteJobStepsModalFilesImport from '../Modal/RemoteJobStepsModalFilesImport';
import { StepCommonLabel } from './RemoteJobStepsDrawerCommon';

export type RemoteJobStepsDrawerFilesProps = {
  form: FormInstance<FormRemoteJobStepsDrawer>;
};

export default function RemoteJobStepsDrawerFiles({ form }: RemoteJobStepsDrawerFilesProps): JSX.Element {
  const { directory, openFilesModal, isExport, setExport, onExport, isLoadingExport } = useRemoteJobStepsDrawerFiles({
    form,
  });

  return (
    <div css={style}>
      <Form.Item label={<StepCommonLabel label="Files" />} colon={false}>
        <Form.Item className="files-btns">
          <Space>
            <Popover
              placement="right"
              trigger="hover"
              content={
                <div
                  css={css`
                    max-width: 30rem;
                    max-height: 30rem;
                    overflow-y: auto;

                    .file-item {
                      white-space: nowrap;
                      overflow-x: hidden;
                      text-overflow: ellipsis;
                    }
                  `}
                >
                  {directory.map((item, idx) => (
                    <div className="file-item" title={item} key={idx}>
                      {item}
                    </div>
                  ))}
                </div>
              }
              title="File List"
            >
              <div css={hoverStyle}>{`${directory.length} files`}</div>
            </Popover>
            <Button onClick={openFilesModal}>Import</Button>
            <Popconfirm
              title="Export Files?"
              visible={isExport}
              onConfirm={onExport}
              okButtonProps={{ loading: isLoadingExport }}
              onCancel={() => setExport(false)}
              cancelButtonProps={{ disabled: isLoadingExport }}
            >
              <Button onClick={() => setExport(true)} disabled={directory.length === 0}>
                Export
              </Button>
            </Popconfirm>
          </Space>
        </Form.Item>
        {/* just for setting form value */}
        <Form.Item
          noStyle
          name="directory"
          rules={[
            {
              required: true,
              type: 'array',
              message: 'Please select files!',
            },
          ]}
        />
      </Form.Item>
      <RemoteJobStepsModalFilesImport form={form} />
    </div>
  );
}

const style = css`
  .files-type,
  .files-btns {
    margin-bottom: 0.5rem;
  }
`;
