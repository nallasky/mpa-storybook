import MarkUpTags from '@components/common/atoms/MarkupTags';
import { css } from '@emotion/react';
import { Badge, DatePicker, Form, FormInstance, InputNumber, Radio, Select, Space, TimePicker } from 'antd';
import { FormRemoteJobStepsDrawer } from '../hooks/useRemoteJobStepsDrawer';
import useRemoteJobStepsDrawerExecute from '../hooks/useRemoteJobStepsDrawerExecute';
import { StepCommonLabel, StepEmptyLabel } from './RemoteJobStepsDrawerCommon';

export type RemoteJobStepsDrawerExecuteProps = {
  form: FormInstance<FormRemoteJobStepsDrawer>;
};

const ENABLE_EXECUTE_MODE_NEXT = false;
export default function RemoteJobStepsDrawerExecute({ form }: RemoteJobStepsDrawerExecuteProps): JSX.Element {
  const {
    executeMode,
    setExecuteMode,
    timeMoment,
    onChangeTimeMoment,
    time,
    onChangeTime,
    stepUuidOptions,
    uuid,
    startTime,
    onChangeStartTime,
    formCycle,
  } = useRemoteJobStepsDrawerExecute({ form });

  return (
    <div css={style}>
      <Form.Item label={<StepCommonLabel label="Execute Mode" />} name="mode" colon={false}>
        <Radio.Group onChange={setExecuteMode}>
          <Radio value="time">Specified Time</Radio>
          <Radio value="cycle">Cycle</Radio>
          <Radio value="pre">Previous</Radio>
          {ENABLE_EXECUTE_MODE_NEXT && <Radio value="next">Next</Radio>}
          <Radio value="none">None</Radio>
        </Radio.Group>
      </Form.Item>

      {executeMode === 'cycle' && (
        <Form.Item label={<StepEmptyLabel />} colon={false}>
          <Form.Item label={<CycleTitle title="Start Time" />} colon={false}>
            <DatePicker
              format="YYYY-MM-DD HH:mm"
              showTime
              onChange={onChangeStartTime}
              value={startTime}
              placeholder="Select a start time"
            />
            <Form.Item
              name="time"
              noStyle
              rules={[
                {
                  required: true,
                  type: 'array',
                  message: 'Please select a start time!',
                },
              ]}
            ></Form.Item>
          </Form.Item>
          <Form.Item
            label={<CycleTitle title="Cycle" />}
            name="period"
            className="period"
            rules={[
              { required: true, message: 'Please input a cycle!' },
              {
                message: 'Minute must be more than 5!',
                validator: (rule, value) =>
                  formCycle === 'minute' && value < 5 ? Promise.reject() : Promise.resolve(),
              },
            ]}
            colon={false}
          >
            <InputNumber
              min={formCycle === 'minute' ? 5 : 1}
              max={999}
              css={css`
                width: 6.375rem !important;
              `}
              addonAfter={
                <Form.Item name="cycle" noStyle>
                  <Select
                    className="select-value"
                    css={css`
                      width: 6rem !important;
                    `}
                  >
                    <Select.Option value="minute">Miniute</Select.Option>
                    <Select.Option value="hour">Hour</Select.Option>
                    <Select.Option value="day">Day</Select.Option>
                  </Select>
                </Form.Item>
              }
            />
          </Form.Item>
        </Form.Item>
      )}
      {executeMode === 'time' && (
        <Form.Item
          label={<StepEmptyLabel />}
          name="time"
          colon={false}
          rules={[{ required: true, message: 'Please input times!' }]}
        >
          <Space direction="vertical">
            <TimePicker value={timeMoment} format="HH:mm" onChange={onChangeTimeMoment} />
            <MarkUpTags tags={time} setTags={onChangeTime} />
          </Space>
        </Form.Item>
      )}
      {executeMode === 'pre' && (
        <Form.Item label={<StepEmptyLabel />} colon={false}>
          <Form.Item
            name="preStep"
            className="preStep"
            rules={[{ required: true, message: 'Please select a previous step!' }]}
          >
            <Select className="select-value" allowClear placeholder="Select a previous step">
              {stepUuidOptions.map((item) => (
                <Select.Option key={item.uuid as string} value={item.uuid as string}>
                  {item.stepName}
                </Select.Option>
              ))}
            </Select>
          </Form.Item>
        </Form.Item>
      )}
      {ENABLE_EXECUTE_MODE_NEXT && executeMode === 'next' && (
        <Form.Item label={<StepEmptyLabel />} colon={false}>
          <Space>
            <Form.Item
              name="nextStep"
              className="nextStep"
              rules={[{ required: true, message: 'Please select a next step!' }]}
            >
              <Select className="select-value" allowClear placeholder="Select a next step">
                {stepUuidOptions.map((item) => (
                  <Select.Option key={item.uuid as string} value={item.uuid as string}>
                    {item.stepName}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>
          </Space>
        </Form.Item>
      )}
    </div>
  );
}

const CycleTitle = ({ title }: { title: string }) => (
  <div
    css={css`
      display: flex;
      width: 6rem;
    `}
  >
    <Space size={2}>
      <Badge color="green" />
      <div>{title}</div>
    </Space>
  </div>
);

const style = css`
  .period {
    .ant-input-number-input-wrap {
      width: 5rem;
    }
  }

  .preStep,
  .nextStep {
    .select-value {
      width: 15.625rem;
    }
  }

  .ant-form-item-explain {
    width: 53rem;
  }
`;
