import { useGetUserFabNameList } from '@libs/query/common';
import { openNotification } from '@libs/util/notification';
import { selectRemoteJobInfo, selectRemoteJobIsCollectStep, setRemoteJob } from '@reducers/slices/remoteJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { LabeledValue } from 'antd/es/select';
import { useCallback, useMemo } from 'react';
import { useDispatch } from 'react-redux';

export function useRemoteJobSetting() {
  const dispatch = useDispatch();
  const {
    data: siteList,
    isFetching: isFetchingSiteList,
    refetch: refetchSiteList,
  } = useGetUserFabNameList({
    onError: () => {
      openNotification('error', 'Error', `Failed to get user-fab name list.`);
    },
  });
  const selectJob = useTypedSelector(selectRemoteJobInfo);
  const isCollectStep = useTypedSelector(selectRemoteJobIsCollectStep);

  const setJobName: React.ChangeEventHandler<HTMLInputElement> = useCallback(
    (e) => {
      dispatch(setRemoteJob({ jobName: e.target.value }));
    },
    [dispatch],
  );

  const selectSiteInfo = useMemo(
    (): LabeledValue => ({
      key: `${selectJob.siteId}`,
      value: selectJob.siteId as number,
      label: selectJob.siteName,
    }),
    [selectJob.siteId, selectJob.siteName],
  );

  const setSelectSiteInfo = useCallback(
    ({ value, label }: LabeledValue) => {
      dispatch(
        setRemoteJob({
          siteId: (value as number) ?? null,
          siteName: (label as string) ?? null,
        }),
      );
    },
    [dispatch],
  );

  const refreshSiteList = useCallback(() => {
    refetchSiteList();
  }, [refetchSiteList]);

  return {
    selectJob,
    selectSiteInfo,
    setSelectSiteInfo,
    setJobName,
    siteList,
    isFetchingSiteList,
    refreshSiteList,
    isCollectStep,
  };
}
