import { useGetRemoteJobStepFiles } from '@libs/query/remoteJob';
import { openNotification } from '@libs/util/notification';
import { selectRemoteJobInfo, selectRemoteJobVisible, setRemoteJobVisible } from '@reducers/slices/remoteJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { FormInstance } from 'antd';
import { saveAs } from 'file-saver';
import { useCallback, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { FormRemoteJobStepsDrawer } from './useRemoteJobStepsDrawer';

export default function useRemoteJobStepsDrawerFiles({ form }: { form: FormInstance<FormRemoteJobStepsDrawer> }) {
  const dispatch = useDispatch();
  const [directory, setDirectory] = useState<string[]>([]);
  const isFilesModal = useTypedSelector(selectRemoteJobVisible('isFiles'));
  const [uuid, setUuid] = useState('');
  const { jobId } = useTypedSelector(selectRemoteJobInfo);
  const [isExport, setExport] = useState(false);

  const { isLoading: isLoadingExport, refetch: refetchExport } = useGetRemoteJobStepFiles(
    (jobId as number) ?? 0,
    uuid as string,
    {
      enabled: false,
      onSuccess: (resData) => {
        const { data, fileName } = resData;
        saveAs(data, fileName);
        openNotification('success', 'Success', `Succeed to export custom step files.`);
      },
      onError: (e) => {
        openNotification('error', 'Error', 'Failed to export custom step files!', e);
      },
      onSettled: () => {
        setExport(false);
      },
    },
  );

  const openFilesModal = useCallback(() => {
    dispatch(
      setRemoteJobVisible({
        isFiles: true,
      }),
    );
  }, [dispatch]);

  const onExport = useCallback(() => {
    refetchExport();
  }, [refetchExport]);

  useEffect(() => {
    if (!isFilesModal) {
      setDirectory(form.getFieldValue('directory') ?? []);
      setUuid(form.getFieldValue('uuid') ?? '');
    }
  }, [isFilesModal]);

  return {
    directory,
    openFilesModal,
    isExport,
    setExport,
    onExport,
    isLoadingExport,
  };
}
