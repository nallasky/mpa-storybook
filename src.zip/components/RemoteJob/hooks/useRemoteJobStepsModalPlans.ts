import { QUERY_KEY } from '@libs/query/queryKey';
import { useGetRemoteJobPlans } from '@libs/query/remoteJob';
import { openNotification } from '@libs/util/notification';
import { selectRemoteJobInfo, selectRemoteJobVisible, setRemoteJobVisible } from '@reducers/slices/remoteJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { useQueryClient } from '@tanstack/react-query';
import { FormInstance } from 'antd';
import { LabeledValue } from 'antd/es/select';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useDispatch } from 'react-redux';
import { FormRemoteJobStepsDrawer } from './useRemoteJobStepsDrawer';

export default function useRemoteJobStepsModalPlans({ form }: { form: FormInstance<FormRemoteJobStepsDrawer> }) {
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const { siteId, siteName } = useTypedSelector(selectRemoteJobInfo);
  const visible = useTypedSelector(selectRemoteJobVisible('isPlans'));
  const [selectPlanIds, setStateSelectPlanIds] = useState<number[]>([]);

  const {
    data: plans,
    isFetching: isFetchingPlans,
    refetch: refreshPlans,
  } = useGetRemoteJobPlans(siteId as number, {
    enabled: Boolean(siteId) && visible,
    onError: () => {
      queryClient.setQueryData([QUERY_KEY.JOB_REMOTE_PLANS, siteId], []);
      openNotification('error', 'Error', `Failed to get auto plan list of "${siteName}".`);
    },
  });

  const selectSiteInfo = useMemo(
    (): LabeledValue => ({
      key: `${siteId}`,
      value: siteId as number,
      label: siteName,
    }),
    [siteId, siteName],
  );

  const setSelectPlanIds = useCallback((value: React.Key[]) => {
    setStateSelectPlanIds(value.map((item) => +item));
  }, []);

  const setVisible = useCallback(
    (visible: boolean) => {
      dispatch(setRemoteJobVisible({ isPlans: visible }));
    },
    [dispatch],
  );

  const handleOk = useCallback(() => {
    form.setFieldsValue({
      planIds: selectPlanIds,
    });
    setVisible(false);
  }, [setVisible, selectPlanIds, form]);

  const handleCancel = useCallback(() => {
    setVisible(false);
  }, [setVisible]);

  useEffect(() => {
    if (visible) {
      setStateSelectPlanIds(form.getFieldValue('planIds') ?? []);
    } else {
      setStateSelectPlanIds([]);
    }
  }, [visible]);

  return {
    visible,
    selectSiteInfo,
    plans,
    isFetchingPlans,
    refreshPlans,
    selectPlanIds,
    setSelectPlanIds,
    handleOk,
    handleCancel,
  };
}
