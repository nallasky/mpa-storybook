import { convertFromFtpLabelToFtp } from '@libs/util/job';
import { addEditRemoteJobStep, selectRemoteJobVisible, setRemoteJobVisible } from '@reducers/slices/remoteJob';
import useTypedSelector from '@reducers/useTypedSelector';
import type { AddressOption } from '@typesdef/address';
import type {
  JobCycleType,
  JobModeType,
  JobScriptType,
  JobStepType,
  RemoteJobFTPWithLabel,
  RemoteJobStepDetailState,
  RemoteJobStepItemVisible,
  RemoteJobType,
  TransferRemoteJobJudgeRule,
} from '@typesdef/Job';
import { FormInstance, useWatch } from 'antd/es/form/Form';
import { useCallback, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';

export interface FormRemoteJobStepsDrawer {
  type: RemoteJobType;
  uuid: string | null;
  stepId: number | null;
  stepName: string | null;
  stepType: JobStepType;
  enable: boolean;
  mode: JobModeType | null;
  time: string[];
  cycle: JobCycleType | null;
  period: number | null;
  preStep: string | null;
  nextStep: string | null;
  isEmail: boolean;
  recipient: AddressOption[];
  subject: string | null;
  body: string | null;
  selectJudgeRules: TransferRemoteJobJudgeRule[];
  before: number | null;
  description: string | null;
  scriptType: JobScriptType | null;
  script: string | null;
  fileIndices: number[];
  planIds: number[];
  directory: string[];
  retentionPeriod: number | null;
  isFtp: boolean;
  ftps: RemoteJobFTPWithLabel[];
}

export default function useRemoteJobStepsDrawer({ form }: { form: FormInstance<FormRemoteJobStepsDrawer> }) {
  const dispatch = useDispatch();
  const visible = useTypedSelector(selectRemoteJobVisible('isStep'));
  const [itemVisible, setItemVisible] = useState<RemoteJobStepItemVisible>({
    isEmail: false,
    isExecuteMode: false,
    isScript: false,
    isBefore: false,
    isJudgeRules: false,
    isPlans: false,
    isRetentionPeriod: false,
    isFtp: false,
  });
  const type = useWatch('type', form);

  const onCloseDrawer = useCallback(() => {
    dispatch(
      setRemoteJobVisible({
        isStep: false,
      }),
    );
  }, [dispatch]);

  const onSubmit = useCallback(async () => {
    try {
      const data = await form.validateFields();
      dispatch(addEditRemoteJobStep(stepFormToReduxState(data)));
      dispatch(
        setRemoteJobVisible({
          isStep: false,
        }),
      );
    } catch (e) {
      console.error('Validate Failed: ', e);
    }
  }, [form, dispatch]);

  useEffect(() => {
    if (visible) {
      const stepType = form.getFieldValue('stepType') as JobStepType;
      setItemVisible({
        isEmail: itemVisibleOption.email.includes(stepType),
        isExecuteMode: itemVisibleOption.execute.includes(stepType),
        isScript: itemVisibleOption.script.includes(stepType),
        isBefore: itemVisibleOption.before.includes(stepType),
        isJudgeRules: itemVisibleOption.judgeRule.includes(stepType),
        isPlans: itemVisibleOption.plans.includes(stepType),
        isRetentionPeriod: itemVisibleOption.retention.includes(stepType),
        isFtp: itemVisibleOption.ftp.includes(stepType),
      });
    } else {
      form.resetFields();
    }
  }, [visible]);

  return { form, visible, onCloseDrawer, itemVisible, onSubmit, type };
}

function stepFormToReduxState(formData: FormRemoteJobStepsDrawer): RemoteJobStepDetailState {
  const {
    type,
    uuid,
    stepId,
    stepName,
    stepType,
    enable,
    mode,
    time,
    cycle,
    period,
    preStep,
    nextStep,
    isEmail,
    recipient,
    subject,
    body,
    selectJudgeRules,
    before,
    description,
    scriptType,
    script,
    fileIndices,
    planIds,
    directory,
    retentionPeriod,
    isFtp,
    ftps,
  } = formData;

  return {
    uuid: uuid ?? null,
    stepId: stepId ?? null,
    stepName,
    stepType,
    enable,
    mode: mode ?? null,
    time: time ?? [],
    cycle: cycle ?? null,
    period: period ?? null,
    preStep: preStep ?? null,
    nextStep: nextStep ?? null,
    isEmail,
    customEmails: recipient?.filter((item) => item.id <= 0).map((filtered) => filtered.email) ?? [],
    emailBook: recipient?.filter((item) => !item.group && item.id > 0) ?? [],
    groupBook: recipient?.filter((item) => item.group) ?? [],
    subject: subject ?? null,
    body: body ?? null,
    before: before ?? null,
    selectJudgeRules:
      selectJudgeRules?.map((item) => ({ enable: item.enable, itemId: item.itemId, itemName: item.itemName })) ?? [],
    description: description ?? null,
    scriptType: scriptType ?? null,
    script: script ?? null,
    fileIndices: fileIndices ?? [],
    planIds: planIds ?? [],
    directory: directory ?? [],
    retentionPeriod: retentionPeriod ?? null,
    isFtp,
    ftps: Array.isArray(ftps) ? ftps.map(convertFromFtpLabelToFtp) : [],
  };
}

export const itemVisibleOption: Record<
  'email' | 'execute' | 'script' | 'before' | 'judgeRule' | 'plans' | 'retention' | 'ftp',
  JobStepType[]
> = {
  email: ['summary', 'cras', 'version', 'notice'],
  execute: ['collect', 'convert', 'summary', 'cras', 'version', 'purge', 'mahalanobis', 'custom'],
  script: ['custom'],
  before: ['summary', 'cras', 'version'],
  judgeRule: ['cras'],
  plans: ['collect'],
  retention: ['collect', 'summary', 'cras', 'version'],
  ftp: ['collect'],
};
