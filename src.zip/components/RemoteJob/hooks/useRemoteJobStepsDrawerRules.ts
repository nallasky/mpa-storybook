import { QUERY_KEY } from '@libs/query/queryKey';
import { selectRemoteJobInfo, selectRemoteJobVisible, setRemoteJobVisible } from '@reducers/slices/remoteJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { useQueryClient } from '@tanstack/react-query';
import { RemoteJobJudgeRule, TransferRemoteJobJudgeRule } from '@typesdef/Job';
import { FormInstance } from 'antd';
import { useCallback, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { FormRemoteJobStepsDrawer } from './useRemoteJobStepsDrawer';

export default function useRemoteJobStepsDrawerRules({ form }: { form: FormInstance<FormRemoteJobStepsDrawer> }) {
  const queryClient = useQueryClient();
  // const totalRules = useTypedSelector(selectRemoteJobStepRules);
  const { siteId } = useTypedSelector(selectRemoteJobInfo);
  const totalRules = queryClient.getQueryData<TransferRemoteJobJudgeRule[]>([
    QUERY_KEY.JOB_REMOTE_JUDGE_RULE_LIST,
    siteId,
  ]);

  const [curRules, setCurRulesState] = useState<RemoteJobJudgeRule[]>([]);
  const dispatch = useDispatch();
  const isEditModal = useTypedSelector(selectRemoteJobVisible('isJudgeRules'));

  const onOpenEditModal = useCallback(() => {
    dispatch(setRemoteJobVisible({ isJudgeRules: true }));
  }, [dispatch]);

  useEffect(() => {
    if (!isEditModal) {
      setCurRulesState(form.getFieldValue('selectJudgeRules') ?? []);
    }
  }, [isEditModal]);

  return {
    totalRules,
    curRules,
    setCurRulesState,
    onOpenEditModal,
  };
}
