import { openAntdModal } from '@components/common/atoms/AntdModal';
import { CUSTOM_STEP_PYTHON_NAME, CUSTOM_STEP_SCRIPT_NAME } from '@constants/constants';
import { usePostRemoteJobStepFiles } from '@libs/query/remoteJob';
import { selectRemoteJobVisible, setRemoteJobVisible } from '@reducers/slices/remoteJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { FormInstance, message, RadioChangeEvent } from 'antd';
import { RcFile, UploadFile } from 'antd/es/upload/interface';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { FormRemoteJobStepsDrawer } from './useRemoteJobStepsDrawer';

interface UseRemoteJobStepsModalFilesImportProps {
  form: FormInstance<FormRemoteJobStepsDrawer>;
}
export default function useRemoteJobStepsModalFilesImport({ form }: UseRemoteJobStepsModalFilesImportProps) {
  const dispatch = useDispatch();
  const visible = useTypedSelector(selectRemoteJobVisible('isFiles'));
  const [fileList, setFileList] = useState<RcFile[]>([]);
  const [mode, setMode] = useState<'directory' | 'files'>('directory');
  const buttonRef = useRef<HTMLBRElement>(null);
  const [error, setError] = useState('');

  const { mutateAsync: mutateAsyncUpload, isLoading: isLoadingUpload } = usePostRemoteJobStepFiles();

  const setVisible = useCallback(
    (visible: boolean) => {
      dispatch(
        setRemoteJobVisible({
          isFiles: visible,
        }),
      );
    },
    [dispatch],
  );

  const onChangeMode = useCallback((e: RadioChangeEvent) => {
    setMode(e.target.value);
    setFileList([]);
  }, []);

  const propsBefore = {
    onRemove: (file: UploadFile<any>) => {
      const fileInfo = file as RcFile;
      setFileList((prev) => {
        const index = prev.indexOf(fileInfo);
        const newFileList = prev.slice();
        newFileList.splice(index, 1);
        return newFileList;
      });
    },
    beforeUpload: (file: RcFile) => {
      setFileList((prev) => [...prev, file]);
      return false;
    },
    fileList,
  };

  const deleteAllFile = useCallback((e?: React.MouseEvent<HTMLElement>) => {
    console.log('e', e);
    if (e) e.stopPropagation();
    setFileList([]);
  }, []);

  const handleDirConfirm = useCallback(() => {
    setFileList([]);
    if (buttonRef?.current?.previousSibling) {
      (buttonRef.current.previousSibling as HTMLElement).click();
    }
  }, []);

  const handleUpload = async () => {
    let pythonStart = false;
    let shellStart = false;
    const formData = new FormData();
    const savedFiles: string[] = [];

    if (fileList.length === 0) {
      return setError('Please select at least one file.');
    }

    fileList.forEach((file) => {
      formData.append('files', file);
      let fileName = '';
      if (mode === 'directory') {
        // const filePath = file.webkitRelativePath.split('/');
        // const fileName = filePath.pop() as string;
        // const dirPath = filePath.length === 0 ? '' : filePath.join('/');
        // console.log('file.webkitRelativePath', file.webkitRelativePath);
        // console.log('dirPath, fileName', dirPath, fileName);
        const fileDirInfo = file.webkitRelativePath.split('/');
        fileDirInfo.shift();
        fileName = fileDirInfo.join('/');
      } else {
        fileName = file.name;
      }

      savedFiles.push(fileName);

      if (fileName === CUSTOM_STEP_PYTHON_NAME) pythonStart = true;
      if (fileName === CUSTOM_STEP_SCRIPT_NAME) shellStart = true;
    });

    formData.append('uuid', form.getFieldValue('uuid'));
    formData.append('directory', mode === 'directory' ? 'true' : 'false');

    if ((pythonStart && shellStart) || (!pythonStart && !shellStart)) {
      return setError(`You only need to import one of '${CUSTOM_STEP_PYTHON_NAME}' and '${CUSTOM_STEP_SCRIPT_NAME}'.`);
    }

    try {
      await mutateAsyncUpload(formData);
      message.success('upload successfully.');
      setFileList([]);
      form.setFieldsValue({
        directory: savedFiles,
      });
    } catch (e) {
      message.error('upload failed.');
    } finally {
      setVisible(false);
    }
  };

  const onClickUpload: React.MouseEventHandler<HTMLElement> = useCallback(
    (e) => {
      e.stopPropagation();
      openAntdModal('confirm', {
        title: 'Select Directory',
        content: `Uploaded files are deleted. Would you like to continue?`,
        okText: 'Select',
        onOk: handleDirConfirm,
      });
    },
    [handleDirConfirm],
  );

  const stopPropagation = useCallback((e?: React.MouseEvent) => {
    e && e.stopPropagation();
  }, []);

  useEffect(() => {
    if (!visible) {
      setFileList([]);
      setMode('directory');
      setError('');
    }
  }, [visible]);

  return {
    visible,
    setVisible,
    onChangeMode,
    propsBefore,
    deleteAllFile,
    handleUpload,
    fileList,
    mode,
    buttonRef,
    error,
    isLoadingUpload,
    onClickUpload,
    stopPropagation,
  };
}
