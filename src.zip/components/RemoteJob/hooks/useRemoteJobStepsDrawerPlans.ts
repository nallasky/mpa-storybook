import { selectRemoteJobVisible, setRemoteJobVisible } from '@reducers/slices/remoteJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { FormInstance } from 'antd';
import { useCallback, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { FormRemoteJobStepsDrawer } from './useRemoteJobStepsDrawer';

export default function useRemoteJobStepsDrawerPlans({ form }: { form: FormInstance<FormRemoteJobStepsDrawer> }) {
  const dispatch = useDispatch();
  const [selectedPlans, setSelectedPlans] = useState<number[]>([]);
  const isEditModal = useTypedSelector(selectRemoteJobVisible('isPlans'));

  const onOpenEditModal = useCallback(() => {
    dispatch(setRemoteJobVisible({ isPlans: true }));
  }, [dispatch]);

  useEffect(() => {
    if (!isEditModal) {
      setSelectedPlans(form.getFieldValue('planIds') ?? []);
    }
  }, [isEditModal]);

  return {
    selectedPlans,
    onOpenEditModal,
  };
}
