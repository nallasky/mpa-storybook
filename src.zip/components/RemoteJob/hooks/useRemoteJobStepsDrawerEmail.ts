import { AddressOption } from '@typesdef/address';
import { JobStepType } from '@typesdef/Job';
import { FormInstance } from 'antd';
import { useWatch } from 'antd/es/form/Form';
import { SwitchChangeEventHandler } from 'antd/es/switch';
import { ChangeEvent, useCallback, useEffect, useState } from 'react';
import { FormRemoteJobStepsDrawer } from './useRemoteJobStepsDrawer';

export default function useRemoteJobStepsDrawerEmail({ form }: { form: FormInstance<FormRemoteJobStepsDrawer> }) {
  const [isEnableEmail, setIsEnableEmailState] = useState(false);
  const [itemVisible, setItemVisible] = useState<{ isSubject: boolean; isBody: boolean }>({
    isSubject: false,
    isBody: false,
  });
  const recipients = useWatch('recipient', form);

  const setRecipients = useCallback(
    (recipients: AddressOption[]) => {
      form.setFieldValue('recipient', recipients);
    },
    [form],
  );

  const onChangeSubject = useCallback(
    (e: ChangeEvent<HTMLInputElement>) => {
      form.setFieldsValue({
        subject: e.target.value,
      });
    },
    [form],
  );

  const onChangeBody = useCallback(
    (e: ChangeEvent<HTMLTextAreaElement>) => {
      form.setFieldsValue({
        body: e.target.value,
      });
    },
    [form],
  );

  const setEnableEmail = useCallback<SwitchChangeEventHandler>(
    (checked, event) => {
      form.setFieldsValue({
        isEmail: checked,
      });
      setIsEnableEmailState(checked);
    },
    [form],
  );

  useEffect(() => {
    const type = form.getFieldValue('stepType') as JobStepType;
    const displaySubject = ['summary', 'cras', 'version', 'custom'];

    setItemVisible({
      isSubject: displaySubject.includes(type) ? true : false,
      isBody: type === 'custom' ? true : false,
    });
    setIsEnableEmailState(form.getFieldValue('isEmail') ?? true);
  }, []);

  return {
    recipients,
    setRecipients,
    onChangeSubject,
    onChangeBody,
    isEnableEmail,
    setEnableEmail,
    itemVisible,
  };
}
