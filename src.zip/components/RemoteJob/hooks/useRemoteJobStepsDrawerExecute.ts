import { selectRemoteJobStepKeys } from '@reducers/slices/remoteJob';
import useTypedSelector from '@reducers/useTypedSelector';
import { JobModeType } from '@typesdef/Job';
import { FormInstance, RadioChangeEvent } from 'antd';
import { useWatch } from 'antd/es/form/Form';
import moment, { Moment } from 'moment';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { FormRemoteJobStepsDrawer } from './useRemoteJobStepsDrawer';

export default function useRemoteJobStepsDrawerExecute({ form }: { form: FormInstance<FormRemoteJobStepsDrawer> }) {
  const [timeMoment, setTimeMoment] = useState<moment.Moment | null>(null);
  const [time, setTime] = useState<string[]>([]);
  const [mode, setMode] = useState<JobModeType>('time');
  const stepUuids = useTypedSelector(selectRemoteJobStepKeys);
  const [uuid, setUuid] = useState<string | null>(null);
  const [startTime, setStartTime] = useState<Moment | null>(null);
  const curUuid = useWatch('uuid', form);
  const formCycle = useWatch('cycle', form);

  const stepUuidOptions = useMemo(
    () => stepUuids.filter((item) => item.uuid && item.uuid !== curUuid && item.stepType !== 'notice'),
    [stepUuids, curUuid],
  );

  const onChangeTime = useCallback(
    (time: string[]) => {
      setTime(time);
      form.setFieldsValue({
        time,
      });
    },
    [form],
  );

  const onChangeTimeMoment = useCallback(
    (value: moment.Moment | null, dateString: string) => {
      if (time.findIndex((item) => item === dateString) === -1) {
        onChangeTime([...time, dateString]);
      }
      setTimeMoment(null);
    },
    [time, onChangeTime],
  );

  const setExecuteMode = useCallback(
    ({ target: { value } }: RadioChangeEvent) => {
      let time: string[] = [];
      let startTime: moment.Moment | null = null;

      if (value === 'cycle') {
        const now = moment();
        time = [now.format('YYYY-MM-DD HH:mm')];
        startTime = now;
      }

      setTimeMoment(null);
      setTime(time);
      setUuid(null);
      setMode(value);
      setStartTime(startTime);

      form.setFieldsValue({
        time,
        cycle: value === 'cycle' ? 'day' : null,
        period: null,
        preStep: null,
        nextStep: null,
      });
    },
    [form],
  );

  const onChangeStartTime = (value: Moment | null, dateString: string) => {
    setStartTime(value);
    if (dateString) {
      form.setFieldsValue({
        time: [dateString],
      });
    } else {
      form.setFieldsValue({
        time: [],
      });
    }
  };

  useEffect(() => {
    const { mode, time, uuid } = form.getFieldsValue();

    if (mode) {
      setMode(mode);
    } else {
      setMode('time');
      form.setFieldValue('mode', 'time');
    }

    setUuid(uuid ?? null);
    if (mode === 'cycle') {
      setStartTime(time && time.length > 0 ? moment(time[0], 'YYYY-MM-DD HH:mm') : null);
      setTime([]);
    } else if (mode === 'time') {
      setStartTime(null);
      setTime(time ?? []);
    } else {
      setStartTime(null);
      setTime([]);
    }
  }, []);

  return {
    executeMode: mode,
    setExecuteMode,
    timeMoment,
    onChangeTimeMoment,
    time,
    onChangeTime,
    stepUuidOptions,
    uuid,
    startTime,
    onChangeStartTime,
    formCycle,
  };
}
