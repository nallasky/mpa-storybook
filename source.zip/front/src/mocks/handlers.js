import { rest } from 'msw';
import { URL_FOCUS_SETTING, URL_FOCUS_LOT_ID_INFO, URL_FOCUS_ANALYSIS } from "@constants/URL";

export const handlers = [
  rest.get(`${URL_FOCUS_SETTING}/:fab`, (req, res, ctx) => {
    const { fab } = req.params;

    if (fab === 'error') {
      return res(ctx.status(400), ctx.json({ message: 'error' }))
    }

    return res(
      ctx.status(200),
      ctx.json({
      "tolerance": {
      "PS Pitch": {
        "AFC_Drive_Offset_Pitch": {
          "lower_limit": -20.0,
            "upper_limit": 20.0
        },
        "Each_Shot_Pitch_Offset_i": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        },
        "Mask_Plate_PreScan_Pitch_i": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        },
        "AFC_Drive_Diff_Pitch": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        },
        "Other": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        }
      },
      "PS Roll": {
        "AFC_Drive_Offset_Roll": {
          "lower_limit": -20.0,
            "upper_limit": 20.0
        },
        "Each_Shot_Roll_Offset_i": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        },
        "Mask_Plate_PreScan_Roll_i": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        },
        "AFC_Drive_Diff_Roll": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        },
        "Other": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        }
      },
      "PS Z": {
        "AFC_Drive_Offset_Other_Z_i": {
          "lower_limit": -30.0,
            "upper_limit": 30.0
        },
        "AFC_Drive_Offset_Z": {
          "lower_limit": -30.0,
            "upper_limit": 30.0
        },
        "Chuck_Lock_AFC_Z": {
          "lower_limit": -15.0,
            "upper_limit": 15.0
        },
        "Each_Shot_AFC_i": {
          "lower_limit": -30.0,
            "upper_limit": 30.0
        },
        "Each_Shot_P/R_Offset_Other_Z_i": {
          "lower_limit": -30.0,
            "upper_limit": 30.0
        },
        "AFC_Base_PSZ": {
          "lower_limit": -20.0,
            "upper_limit": 300.0
        },
        "LiPS_PSZ": {
          "lower_limit": -50.0,
            "upper_limit": 50.0
        },
        "Mask_Plate_PreScan_Other_Z_i": {
          "lower_limit": -5.0,
            "upper_limit": 5.0
        },
        "Mask_Plate_PreScan_Z_i": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        },
        "Mag_Other_Z": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        },
        "AFC_Drive_Diff_Z": {
          "lower_limit": -10.0,
            "upper_limit": 10.0
        },
        "Other": {
          "lower_limit": -50.0,
            "upper_limit": 50.0
        },
        "Plate_Thickness_Z_i": {
          "lower_limit": -20.0,
            "upper_limit": 20.0
        },
        "Position_Offset_Z_i": {
          "lower_limit": -20.0,
            "upper_limit": 20.0
        }
      }
    }
    }))
  }),
  rest.get(`${URL_FOCUS_LOT_ID_INFO}/:id*`, (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({
      "job": [
        "2X2_TACT/oas_cit3",
        "2X2_TACT/oas_cit4",
        "eval7101/1st_cits"
      ],
      "lot_id": {
        "2X2_TACT/oas_cit4": {
          "normal_lot_id": [],
          "pseudo_lot_id": [
            "DLID20211208113904_",
            "DLID20211208115332_"
          ]
        },
        "2X2_TACT/oas_cit3": {
          "normal_lot_id": [],
          "pseudo_lot_id": [
            "DLID20211208141548_LOTID_2021-12-08_0"
          ]
        },
        "eval7101/1st_cits": {
          "normal_lot_id": [],
          "pseudo_lot_id": [
            "DLID20211208142838_LOTID_2021-12-08_0"
          ]
        }
      }
    }));
  }),
  rest.post(`${URL_FOCUS_ANALYSIS}`, (req, res, ctx) => {
    const { fab_nm } = req.body;

    if  (fab_nm === 'error_object') {
      return res(ctx.status(400), ctx.json({ message: 'request error' }));
    }

    return res(
      ctx.status(200),
      ctx.json(fab_nm === 'empty' ? {
        "PS Pitch": [],
        "PS Roll": [],
        "PS Z": [],
      } : {
        "PS Pitch": [
          {
            "plate": 1,
            "shot": 4,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.152,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.152,
            "Other": 0.0
          },
          {
            "plate": 1,
            "shot": 3,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.152,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.152,
            "Other": 0.0
          },
          {
            "plate": 1,
            "shot": 2,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.152,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.152,
            "Other": 0.0
          },
          {
            "plate": 1,
            "shot": 1,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.152,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.152,
            "Other": 0.0
          },
          {
            "plate": 2,
            "shot": 4,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 2,
            "shot": 3,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 2,
            "shot": 2,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 2,
            "shot": 1,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 3,
            "shot": 4,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 3,
            "shot": 3,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 3,
            "shot": 2,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 3,
            "shot": 1,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 4,
            "shot": 4,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 4,
            "shot": 3,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 4,
            "shot": 2,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 4,
            "shot": 1,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 5,
            "shot": 4,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 5,
            "shot": 3,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 5,
            "shot": 2,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          },
          {
            "plate": 5,
            "shot": 1,
            "glass_id": null,
            "AFC_Drive_Offset_Pitch": 13.753,
            "Each_Shot_Pitch_Offset_i": 0.0,
            "Mask_Plate_PreScan_Pitch_i": 0.0,
            "AFC_Drive_Diff_Pitch": 0.0,
            "Expoready_Pitch": 13.753,
            "Other": 0.0
          }
        ],
        "PS Roll": [
          {
            "plate": 1,
            "shot": 4,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.092,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.092,
            "Other": 0.0
          },
          {
            "plate": 1,
            "shot": 3,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.092,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.092,
            "Other": 0.0
          },
          {
            "plate": 1,
            "shot": 2,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.092,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.092,
            "Other": 0.0
          },
          {
            "plate": 1,
            "shot": 1,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.092,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.092,
            "Other": 0.0
          },
          {
            "plate": 2,
            "shot": 4,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 2,
            "shot": 3,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 2,
            "shot": 2,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 2,
            "shot": 1,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 3,
            "shot": 4,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 3,
            "shot": 3,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 3,
            "shot": 2,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 3,
            "shot": 1,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 4,
            "shot": 4,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 4,
            "shot": 3,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 4,
            "shot": 2,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 4,
            "shot": 1,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 5,
            "shot": 4,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 5,
            "shot": 3,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 5,
            "shot": 2,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          },
          {
            "plate": 5,
            "shot": 1,
            "glass_id": null,
            "AFC_Drive_Offset_Roll": -1.103,
            "Each_Shot_Roll_Offset_i": 0.0,
            "Mask_Plate_PreScan_Roll_i": 0.0,
            "AFC_Drive_Diff_Roll": 0.0,
            "Expoready_Roll": -1.103,
            "Other": 0.0
          }
        ],
        "PS Z": [
          {
            "plate": 1,
            "shot": 4,
            "glass_id": null,
            "AFC_Base_PSZ": -5.713,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 26.867,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -6.357,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.069,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": -25.77,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.104,
            "Expoready_Z": -16.184
          },
          {
            "plate": 1,
            "shot": 3,
            "glass_id": null,
            "AFC_Base_PSZ": -5.713,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 26.867,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -16.888,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.645,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": 82.535,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.106,
            "Expoready_Z": 102.074
          },
          {
            "plate": 1,
            "shot": 2,
            "glass_id": null,
            "AFC_Base_PSZ": -5.713,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 26.867,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -3.117,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.281,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": -91.476,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.104,
            "Expoready_Z": -85.342
          },
          {
            "plate": 1,
            "shot": 1,
            "glass_id": null,
            "AFC_Base_PSZ": -5.713,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 26.867,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": 0.0,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": 0.077,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": -4.106,
            "AFC_Drive_Offset_Other_Z_i": 24.887,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.105,
            "Expoready_Z": 33.367
          },
          {
            "plate": 2,
            "shot": 4,
            "glass_id": null,
            "AFC_Base_PSZ": -2.471,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -6.357,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.297,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": -25.771,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.003,
            "Expoready_Z": -13.07
          },
          {
            "plate": 2,
            "shot": 3,
            "glass_id": null,
            "AFC_Base_PSZ": -2.471,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -16.888,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.814,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": 82.534,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.005,
            "Expoready_Z": 105.247
          },
          {
            "plate": 2,
            "shot": 2,
            "glass_id": null,
            "AFC_Base_PSZ": -2.471,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -3.117,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.457,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": -91.477,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.002,
            "Expoready_Z": -82.175
          },
          {
            "plate": 2,
            "shot": 1,
            "glass_id": null,
            "AFC_Base_PSZ": -2.471,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": 0.0,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -0.15,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": -0.686,
            "AFC_Drive_Offset_Other_Z_i": 24.886,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.005,
            "Expoready_Z": 33.061
          },
          {
            "plate": 3,
            "shot": 4,
            "glass_id": null,
            "AFC_Base_PSZ": -2.965,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.236,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -6.357,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.176,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": -25.771,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.002,
            "Expoready_Z": -13.442
          },
          {
            "plate": 3,
            "shot": 3,
            "glass_id": null,
            "AFC_Base_PSZ": -2.965,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.236,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -16.888,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.746,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": 82.533,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.004,
            "Expoready_Z": 104.821
          },
          {
            "plate": 3,
            "shot": 2,
            "glass_id": null,
            "AFC_Base_PSZ": -2.965,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.236,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -3.117,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.364,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": -91.477,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.001,
            "Expoready_Z": -82.57499999999999
          },
          {
            "plate": 3,
            "shot": 1,
            "glass_id": null,
            "AFC_Base_PSZ": -2.965,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.236,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": 0.0,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -0.043,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": -1.274,
            "AFC_Drive_Offset_Other_Z_i": 24.886,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.003,
            "Expoready_Z": 33.264
          },
          {
            "plate": 4,
            "shot": 4,
            "glass_id": null,
            "AFC_Base_PSZ": -2.78,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -6.357,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.22,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": -25.771,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.003,
            "Expoready_Z": -13.302
          },
          {
            "plate": 4,
            "shot": 3,
            "glass_id": null,
            "AFC_Base_PSZ": -2.78,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -16.888,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.706,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": 82.533,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.005,
            "Expoready_Z": 105.045
          },
          {
            "plate": 4,
            "shot": 2,
            "glass_id": null,
            "AFC_Base_PSZ": -2.78,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -3.117,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.401,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": -91.477,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.002,
            "Expoready_Z": -82.428
          },
          {
            "plate": 4,
            "shot": 1,
            "glass_id": null,
            "AFC_Base_PSZ": -2.78,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": 0.0,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -0.064,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": -1.09,
            "AFC_Drive_Offset_Other_Z_i": 24.886,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.004,
            "Expoready_Z": 33.243
          },
          {
            "plate": 5,
            "shot": 4,
            "glass_id": null,
            "AFC_Base_PSZ": -2.622,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -6.357,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.247,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": -25.77,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.003,
            "Expoready_Z": -13.17
          },
          {
            "plate": 5,
            "shot": 3,
            "glass_id": null,
            "AFC_Base_PSZ": -2.622,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -16.888,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.783,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": 82.534,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.005,
            "Expoready_Z": 105.127
          },
          {
            "plate": 5,
            "shot": 2,
            "glass_id": null,
            "AFC_Base_PSZ": -2.622,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": -3.117,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -1.414,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.0,
            "AFC_Drive_Offset_Other_Z_i": -91.476,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.002,
            "Expoready_Z": -82.282
          },
          {
            "plate": 5,
            "shot": 1,
            "glass_id": null,
            "AFC_Base_PSZ": -2.622,
            "AFC_Drive_Offset_Z": 6.466,
            "LiPS_Pitch_Other_Z_i": 28.238,
            "LiPS_PSZ": -16.581,
            "Each_Shot_AFC_i": 0.0,
            "Each_Shot_P/R_Offset_Other_Z_i": 0.0,
            "Plate_Thickness_Z_i": 0.0,
            "Mask_Plate_PreScan_Z_i": 0.0,
            "Mag_Other_Z": -0.104,
            "Position_Offset_Z_i": 0.0,
            "Chuck_Lock_AFC_Z": 0.31,
            "AFC_Drive_Offset_Other_Z_i": 24.887,
            "Mask_Plate_PreScan_Other_Z_i": 0.0,
            "AFC_Drive_Diff_Z": 0.0,
            "Other": 0.005,
            "Expoready_Z": 31.961000000000002
          }
        ]
      })
    );
  })
];