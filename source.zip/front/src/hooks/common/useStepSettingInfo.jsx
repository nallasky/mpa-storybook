import useRuleSettingInfo from './useRuleSettingInfo';
import { getType, regExpStr, sortArrayOfObjects } from '@libs/util/util';
import { createGraphItems } from '@libs/util/common/functionGroup';

const useStepSettingInfo = () => {
  const {
    ruleStepConfig,
    setRuleStepConfig,
    updateConvertInfo,
    updateAnalysisInfo,
    updateVisualInfo,
    updateFilterInfo,
    analysisStepInfo,
    convertStepInfo,
  } = useRuleSettingInfo();

  const addNextStepConfig = ({ next, info, setCurrent }) => {
    addStepPreviewAndNext({
      next: next,
      info: info,
      preview: undefined,
    });

    /* const isNextStepExist =
      ruleStepConfig.findIndex((obj) => obj.step === next) !== -1;
    if (isNextStepExist) {
      setRuleStepConfig(
        ruleStepConfig.map((target) =>
          target.step === next ? { ...target, config: info.config } : target,
        ),
      );
    } else {
      setRuleStepConfig(
        ruleStepConfig.concat({ step: next, config: info.config }),addStepPreviewAndNext
      );
    }*/
    setCurrent(next);
  };
  const addCurrentStepPreview = ({ current, info }) => {
    addStepPreviewAndNext({
      next: undefined,
      info: undefined,
      preview: { current: current, info: info },
    });
    /*    const isStepExist =
      ruleStepConfig.findIndex((obj) => obj.step === current) !== -1;
    if (isStepExist) {
      setRuleStepConfig(
        ruleStepConfig.map((obj2) =>
          obj2.step === current ? { ...obj2, data: info } : obj2,
        ),
      );
    } else {
      setRuleStepConfig(ruleStepConfig.concat({ step: current, data: info }));
    }*/
  };

  const addStepPreviewAndNext = ({ next, info, preview }) => {
    let ruleStep = [...ruleStepConfig];
    let cloneObj = {};

    if (preview?.current ?? false) {
      const { current: previewStep, info: previewInfo } = preview;
      const isPreviewStep =
        ruleStep.findIndex((obj) => obj.step === previewStep) !== -1;
      cloneObj = isPreviewStep
        ? ruleStep.map((obj2) =>
            obj2.step === previewStep ? { ...obj2, data: previewInfo } : obj2,
          )
        : ruleStep.concat({ step: previewStep, data: previewInfo });
      ruleStep = JSON.parse(JSON.stringify(cloneObj));
    }
    if (info ?? false) {
      const isNextStep = ruleStep.findIndex((obj) => obj.step === next) !== -1;
      cloneObj = isNextStep
        ? ruleStep.map((target) =>
            target.step === next ? { ...target, config: info.config } : target,
          )
        : ruleStep.concat({ step: next, config: info.config });
    }
    setRuleStepConfig(cloneObj);
  };

  const updateStepSetting = ({ info }) => {
    console.log('updateStepSetting ', info);
    if (info?.convert?.log_define ?? false) {
      console.log('update convert ');
      updateConvertInfo({
        ...convertStepInfo,
        log_define: {
          ...convertStepInfo.log_define,
          ...info?.convert?.log_define,
        },
        info:
          sortArrayOfObjects(info?.convert?.info ?? [], 'col_index').map(
            (obj, index) => {
              return {
                ...obj,
                key: index + 1,
                rec_type: 'DB',
                output_column_val: obj?.output_column ?? '',
              };
            },
          ) ?? [],
        header:
          sortArrayOfObjects(info?.convert?.header ?? [], 'col_index').map(
            (obj, index) => {
              return {
                ...obj,
                key: index + 1,
                rec_type: 'DB',
                output_column_val: obj?.output_column ?? '',
              };
            },
          ) ?? [],
        custom:
          info?.convert?.custom?.map((obj, index) => {
            return {
              ...obj,
              key: index + 1,
              rec_type: 'DB',
              output_column_val: obj?.output_column ?? '',
            };
          }) ?? [],
      });
    }
    console.log('update convert completed');

    if (info?.analysis?.setting?.aggregation_default ?? false) {
      console.log('update analysis ');
      updateAnalysisInfo({
        ...analysisStepInfo,
        setting: {
          aggregation_default: info?.analysis?.setting?.aggregation_default,
          items: info?.analysis?.setting?.items.map((obj, index) => {
            return { ...obj, key: index + 1 };
          }),
        },
      });
    }
    console.log('update analysis completed');

    if (info?.filter?.items ?? false) {
      console.log('update filter ');
      updateFilterInfo(
        info?.filter?.items.map((obj, index) => {
          return {
            ...obj,
            key: index + 1,
          };
        }) ?? [],
      );
    }
    console.log('update filter completed');

    if (info?.visualization ?? false) {
      console.log('update visualization ');
      updateVisualInfo({
        function_graph_type:
          info.visualization.function_graph_type.map((v) => {
            v.script = v.script
              .replaceAll(/""/g, '"')
              .replaceAll(/(^")|("$)/g, '');
            return v;
          }) ?? [],
        graph_list: info.visualization.graph_list ?? [],
        items: createGraphItems(info.visualization),
      });
      console.log('update visualization completed');
    }
  };
  const getColumnData = (obj, name, origin, defineList) => {
    console.log('=====', name);
    console.log('origin', origin + '');
    const origin_type = getType(origin);
    const dList = Object.keys(defineList ?? {});
    const custom_type = dList.includes(name?.trim());
    console.log('custom_type', custom_type, 'origin_type', origin_type);
    if (custom_type) {
      const value = name.trim() ?? 'null';
      return {
        ...obj,
        name: name.trim() ?? '',
        output_column: defineList[value].output_column,
        output_column_val: defineList[value].output_column,
        data_type: defineList[value].data_type,
        def_val: defineList[value].def_val,
        def_type: defineList[value].def_type,
        coef: defineList[value]?.coef ?? 1,
        unit: defineList[value]?.unit ?? '',
      };
    } else {
      const cName = regExpStr(name + '').trim();
      const columnName = isNaN(+name)
        ? name?.trim() ?? ''
        : Math.abs(name).toString();

      const data = !isNaN(+cName.charAt(0)) ? `_${cName}` : cName;
      if (origin_type === 'number') {
        return {
          ...obj,
          name: columnName,
          output_column: data,
          output_column_val: data,
          data_type: 'integer',
          def_val: 'null',
          def_type: 'null',
          coef: 1,
          unit: '',
        };
      }
      if (origin_type === 'float') {
        return {
          ...obj,
          name: columnName,
          output_column: data,
          output_column_val: data,
          data_type: 'float',
          def_val: 'null',
          def_type: 'null',
          coef: 1,
          unit: '',
        };
      } else if (origin_type === 'string') {
        console.log('=====2', name.trim().length, name.trim());
        return {
          ...obj,
          name: columnName,
          output_column: data,
          output_column_val: data,
          data_type: 'text',
          def_val: 'null',
          def_type: 'null',
        };
      } else if (origin_type === 'date') {
        return {
          ...obj,
          name: 'log_time',
          output_column: 'log_time',
          output_column_val: 'log_time',
          data_type: 'timestamp',
          def_val: 'now',
          def_type: 'now',
        };
      }
      return obj;
    }
  };
  return {
    addNextStepConfig,
    addCurrentStepPreview,
    updateStepSetting,
    addStepPreviewAndNext,
    getColumnData,
  };
};
export default useStepSettingInfo;
