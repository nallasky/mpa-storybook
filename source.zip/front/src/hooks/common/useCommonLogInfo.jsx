import {
  getCategories,
  getLogLists,
  UpdateCategoriesReducer,
  UpdateLogListReducer,
  UpdateAllCommonLogSettingReducer,
} from '@reducers/slices/CommonLogInfo';
import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';

const useCommonLogInfo = () => {
  const dispatch = useDispatch();
  const gCategories = useSelector(getCategories);
  const gLogLists = useSelector(getLogLists);

  const setCategories = useCallback(
    (value) => {
      dispatch(UpdateCategoriesReducer(value));
    },
    [dispatch],
  );
  const setLogList = useCallback(
    (value) => {
      dispatch(UpdateLogListReducer(value));
    },
    [dispatch],
  );
  const setAllCommonSetting = useCallback(
    ({ category, log }) => {
      dispatch(UpdateAllCommonLogSettingReducer({ category, log }));
    },
    [dispatch],
  );
  return {
    setCategories,
    gCategories,
    setLogList,
    gLogLists,
    setAllCommonSetting,
  };
};
export default useCommonLogInfo;
