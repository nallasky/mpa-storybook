import { useDispatch, useSelector } from 'react-redux';
import {
  getAdcMeasurementSetting,
  getCorrectionSetting,
  getOasBaseLineSetting,
  getCorrectionUploadedFiles,
  getCorrectionUnknownFilesDelete,
  initialOverlayReducer,
  UpdateAdcMeasurementInfoReducer,
  UpdateCorrectionInfoReducer,
  UpdateCorrectionUploadedFilesReducer,
  UpdateCorrectionUnknownFilesDeleteReducer,
  UpdateOasBaseLineInfoReducer,
  mapInitial,
} from '@reducers/slices/OverlayInfo';
import { useCallback } from 'react';
import {
  OVERLAY_ADC_CATEGORY,
  OVERLAY_CORRECTION_CATEGORY,
  OVERLAY_OAS_BASELINE_CATEGORY,
} from '@constants/etc';
import useOverlayResultInfo from './useOverlayResultInfo';
import { CPVS_MODE } from '@constants/OverlayDefault';
import { createPostData } from '@libs/util/common/functionGroup';

const useOverlayInfo = () => {
  const dispatch = useDispatch();
  const correctionSet = useSelector(getCorrectionSetting);
  const adcMeasurementSet = useSelector(getAdcMeasurementSetting);
  const oasBaseLineSet = useSelector(getOasBaseLineSetting);
  const correctionFiles = useSelector(getCorrectionUploadedFiles);
  const correctionUnknownFilesDelete = useSelector(
    getCorrectionUnknownFilesDelete,
  );
  const {
    updateMapSetting,
    updateCorrectionMapSetting,
    updateOasBaseLineMapGraphSetting,
    updateAdcCommonInfo,
    updateCorrectionCommonInfo,
    updateOasBaseLinePlotGraphSetting,
    updateOasBaseLineCommonInfo,
  } = useOverlayResultInfo();
  const initialOverlayInfo = useCallback(() => {
    dispatch(initialOverlayReducer());
  }, [dispatch]);

  const updateCorrectionFiles = useCallback(
    (files) => {
      dispatch(UpdateCorrectionUploadedFilesReducer(files));
    },
    [dispatch],
  );

  const updateCorrectionUnknownFilesDelete = useCallback(
    (value) => {
      dispatch(UpdateCorrectionUnknownFilesDeleteReducer(value));
    },
    [dispatch],
  );

  const updateAdcMeasurementSetting = useCallback(
    (value) => {
      dispatch(UpdateAdcMeasurementInfoReducer(value));
    },
    [dispatch],
  );
  const updateCorrectionSetting = useCallback(
    (value) => {
      dispatch(UpdateCorrectionInfoReducer(value));
    },
    [dispatch],
  );
  const updateOasBaseLineSetting = useCallback(
    (value) => {
      dispatch(UpdateOasBaseLineInfoReducer(value));
    },
    [dispatch],
  );

  const getCorrectionCpVsDefault = (defaultV, shot) => {
    return getCorrectionCpVsSetting(defaultV, undefined, shot);
  };

  const getCorrectionCpVsSetting = (defaultV, Value, shot) => {
    const data = Value?.[shot[0]] ?? defaultV;
    const key_list = Object.keys(data).filter(
      (o) => !o.includes('chk') && !o.includes('mode'),
    );
    return {
      cp: shot?.map((shotN) =>
        key_list
          .filter((o) => o.includes('cp'))
          .reduce(
            (acc, o) => ({
              ...acc,
              [o]: {
                value: (defaultV ?? Value?.[shotN])?.[o],
                checked: !!(defaultV ?? Value?.[shotN])?.[`${o}_chk`],
              },
            }),
            {
              shot: {
                id: shotN,
                mode: (Value?.[shotN] ?? defaultV)?.['cpmode'] ?? 'auto',
              },
            },
          ),
      ),
      vs: shot?.map((shotN) =>
        key_list
          .filter((o) => o.includes('vs'))
          .reduce(
            (acc, o) => ({
              ...acc,
              [o]: {
                value: (defaultV ?? Value?.[shotN])?.[o],
                checked: !!(defaultV ?? Value?.[shotN])?.[`${o}_chk`],
              },
            }),
            {
              shot: {
                id: shotN,
                mode: (Value?.[shotN] ?? defaultV)?.['vsmode'] ?? 'auto',
              },
            },
          ),
      ),
    };
  };
  const makePlotGraphStoreData = (info, orgin) => {
    const {
      graph,
      targetInfo: { selected: period },
    } = orgin;
    const shotList = Object.keys(info.baseline).map(Number);
    const glassIdList = Object.keys(info.baseline).reduce(
      (acc, shot) =>
        Object.assign(acc, { [shot]: Object.keys(info.baseline[shot]) }),
      {},
    );
    const { plot } = graph;
    const obj = {
      ...plot,
      shot: {
        list: shotList,
        selected: shotList[0],
      },
      scale: {
        ...plot.scale,
        period: {
          type: 'auto',
          upper_limit: period[1],
          lower_limit: period[0],
        },
      },
      highlight_glass: {
        list: glassIdList,
        selected: '',
      },
    };
    return obj;
  };
  const makeMapGraphStoreData = (data, origin) => {
    let adc_measurement_cpvs = undefined;
    let correction_cpvs = undefined;
    let baseline_cpvs = undefined;
    const origin_map = origin.graph?.map ?? origin.graph;
    let mapObj = { ...origin_map };
    if (data?.cp_vs) {
      const { cp_vs } = data;
      if (cp_vs.adc_measurement) {
        const { adc_measurement } = cp_vs;
        adc_measurement_cpvs = {
          mode: adc_measurement.included ? CPVS_MODE.FROM_LOG : CPVS_MODE.EACH,
          shots: adc_measurement?.shot.reduce(
            (acc, o) =>
              Object.assign(acc, {
                [o]: adc_measurement?.default,
              }),
            {},
          ),
          preset: adc_measurement?.preset,
        };
      } else {
        console.log('not exist cpvs(adc_measuremnt) data');
      }
      if (cp_vs?.correction) {
        const { correction } = cp_vs;
        correction_cpvs = {
          mode: CPVS_MODE.EACH,
          preset: correction?.preset ?? {},
          shots: getCorrectionCpVsDefault(
            correction?.default,
            correction?.shot,
          ),
        };
      } else {
        console.log('not exist cpvs(correction) data');
      }
      if (!adc_measurement_cpvs && !correction_cpvs) {
        baseline_cpvs = {
          mode: cp_vs.included ? CPVS_MODE.FROM_LOG : CPVS_MODE.EACH,
          preset: cp_vs.preset ?? {},
          shots: cp_vs?.shot.reduce(
            (acc, o) =>
              Object.assign(acc, {
                [o]: cp_vs?.default,
              }),
            {},
          ),
        };
      }
      Object.assign(mapObj, {
        ...data.etc,
        offset: {
          mode: 'auto',
          info: data?.offset ?? {},
          default: data?.offset,
        },
        cp_vs: {
          adc_measurement: adc_measurement_cpvs ?? {},
          correction: correction_cpvs ?? {},
          baseline: baseline_cpvs ?? {},
        },
      });
    } else {
      console.log('not exist cp_vs data');
      Object.assign(mapObj, {
        offset:
          origin_map.offset.mode !== 'auto'
            ? {
                ...origin_map.offset,
                info: data.offset,
                default: data?.offset,
              }
            : {
                ...origin_map.offset,
                default: data?.offset,
              },
      });
    }
    return mapObj;
  };
  const makeCommonStoreData = (data, origin) => {
    const map_data = data?.data?.map ?? data?.data ?? data?.map;
    let commonObj = {};
    if (map_data) {
      const lot_data = Object.values(map_data)[0];
      const plate = Object.keys(lot_data.plate);
      const plate_data = Object.values(lot_data.plate)[0];
      const shot = Object.keys(plate_data.shot).map(Number);
      if (data?.cp_vs) {
        commonObj = {
          shot: shot,
          plate: plate,
          origin: data,
        };
      } else {
        console.log('not exist cp_vs data');
        commonObj = {
          shot: shot,
          plate: plate,
          origin: { ...origin.info.origin, ...data },
        };
      }
    } else {
      commonObj = {
        shot: [],
        plate: [],
        origin: data,
      };
    }
    return commonObj;
  };
  const updateOriginDataSetting = (data, mode, origin) => {
    console.log('[updateOriginDataSetting]data', data);
    console.log('[updateOriginDataSetting]mode', mode);
    console.log('[updateOriginDataSetting]origin', origin);
    if (mode === OVERLAY_ADC_CATEGORY) {
      updateMapSetting(makeMapGraphStoreData(data, origin));
      updateAdcCommonInfo(makeCommonStoreData(data, origin));
    } else if (mode === OVERLAY_CORRECTION_CATEGORY) {
      updateCorrectionMapSetting(makeMapGraphStoreData(data, origin));
      updateCorrectionCommonInfo(makeCommonStoreData(data, origin));
    } else if (mode === OVERLAY_OAS_BASELINE_CATEGORY) {
      console.log('[updateOriginDataSetting]start =====');
      updateOasBaseLinePlotGraphSetting(makePlotGraphStoreData(data, origin));
      console.log('[updateOriginDataSetting]plot graph completed =====');
      if (data.map) {
        console.log('[updateOriginDataSetting]map graph start =====');
        updateOasBaseLineMapGraphSetting(makeMapGraphStoreData(data, origin));
        console.log('[updateOriginDataSetting]map graph completed =====');
      } else {
        updateOasBaseLineMapGraphSetting(mapInitial);
      }
      console.log('[updateOriginDataSetting]origin data start =====');
      updateOasBaseLineCommonInfo(makeCommonStoreData(data, origin));
      console.log('[updateOriginDataSetting]origin data completed =====');
    } else {
      console.log('not matching category : ', mode);
    }
  };

  const getReAnalysisParameter = (mode, data) => {
    let postData = createPostData(data, mode);
    const { cp_vs } = data.graph?.map ?? data.graph;
    const adc_cp_vs_list = (cp_vs) => {
      const shots = Object.keys(cp_vs.shots);
      const shots_value = Object.values(cp_vs.shots);
      return Object.keys(shots_value[0]).reduce(
        (acc, cp) => ({
          ...acc,
          [cp]:
            cp_vs.mode === CPVS_MODE.SAME
              ? shots_value.reduce(
                  (acc2, _, i) => ({
                    ...acc2,
                    [shots[i]]: shots_value[0][cp],
                  }),
                  {},
                )
              : shots_value.reduce(
                  (acc2, o2, i) => ({ ...acc2, [shots[i]]: o2[cp] }),
                  {},
                ),
        }),
        {},
      );
    };
    const correction_cp_vs_list = (cp_vs, mode) => {
      console.log('cp_vs', cp_vs);
      const cpVS = Object.keys(cp_vs);
      const getCpVsValue = (cp_vs, key) => {
        return mode === CPVS_MODE.SAME
          ? {
              [key]: cp_vs.reduce(
                (acc, o) => ({ ...acc, [o.shot.id]: cp_vs[0][key].value }),
                {},
              ),
            }
          : {
              [key]: cp_vs.reduce(
                (acc, o) => ({ ...acc, [o.shot.id]: o[key].value }),
                {},
              ),
            };
      };
      return cpVS.reduce((acc, cp) => {
        const key_list = Object.keys(cp_vs?.[cp]?.[0]).filter(
          (o) => o !== 'shot',
        ); //cp1, cp12d.....
        return Object.assign(
          acc,
          key_list.reduce(
            (acc2, key2) => ({
              ...acc2,
              ...getCpVsValue(cp_vs[cp], key2),
            }),
            {},
          ),
        );
      }, {});
    };
    console.log('!!cp_vs?.correction', !!data?.graph?.cp_vs?.correction?.mode);

    if (Object.keys(cp_vs).length === 0) return postData;

    const cpvs_list = ['adc_measurement', 'correction', 'baseline'];
    console.log('cpvs_list', cpvs_list);
    return {
      ...postData,
      cp_vs:
        mode === OVERLAY_CORRECTION_CATEGORY &&
        !!data?.graph?.cp_vs?.correction?.mode
          ? {
              use_from_log: cp_vs?.adc_measurement.mode === CPVS_MODE.FROM_LOG,
              adc_measurement: adc_cp_vs_list(cp_vs?.adc_measurement),
              correction: correction_cp_vs_list(
                cp_vs?.correction.shots,
                cp_vs?.correction.mode,
              ),
            }
          : mode === OVERLAY_OAS_BASELINE_CATEGORY
          ? {
              use_from_log: cp_vs?.baseline.mode === CPVS_MODE.FROM_LOG,
              oasbaseline: adc_cp_vs_list(cp_vs.baseline),
            }
          : {
              use_from_log: cp_vs?.adc_measurement.mode === CPVS_MODE.FROM_LOG,
              adc_measurement: adc_cp_vs_list(cp_vs.adc_measurement),
            },
    };
  };
  return {
    adcMeasurementSet,
    correctionSet,
    oasBaseLineSet,
    initialOverlayInfo,
    updateAdcMeasurementSetting,
    updateCorrectionSetting,
    updateOasBaseLineSetting,
    adcCommonInfo: adcMeasurementSet.info,
    correctionCommonInfo: correctionSet.info,
    oasBaseLineCommonInfo: oasBaseLineSet.info,
    updateOriginDataSetting,
    getCorrectionCpVsDefault,
    getCorrectionCpVsSetting,
    getReAnalysisParameter,
    updateCorrectionFiles,
    updateCorrectionUnknownFilesDelete,
    correctionFiles,
    correctionUnknownFilesDelete,
  };
};
export default useOverlayInfo;
