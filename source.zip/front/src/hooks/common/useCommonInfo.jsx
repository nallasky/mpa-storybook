import { useCallback, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  getSupportUrl,
  initialCommonAction,
  UpdateVersionInfoReducer,
} from '@reducers/slices/BasicInfo';
const useCommonInfo = () => {
  const dispatch = useDispatch();
  const [isEdit, setEdit] = useState(false);
  const currentPath = [];
  const supportUrl = useSelector(getSupportUrl);
  const MenuInfo = {};
  const setCurrentPath = () => {};

  const setVersionInfo = useCallback(
    (value) => {
      dispatch(UpdateVersionInfoReducer(value));
    },
    [dispatch],
  );
  const initCommonSetting = useCallback(() => {
    dispatch(initialCommonAction());
  }, [dispatch]);

  const setEditPage = useCallback(
    (edit) => {
      console.log('setEditPage:', edit);
      setEdit(edit);
    },
    [setEdit],
  );

  const getUrl = ({ body }) => {
    let menuList = [];
    body.map((obj) => {
      obj.func.map((obj2) => {
        menuList.push({
          func: obj2.func_id,
          category: obj.title,
          category_id: obj.category_id,
          func_name: obj2.title,
          path: `${obj.title}/${obj2.title}`,
          source: obj2?.info?.Source,
          system_func: obj2?.system_func,
        });
      });
    });

    return menuList;
  };

  return {
    MenuInfo,
    setVersionInfo,
    currentPath,
    setCurrentPath,
    initCommonSetting,
    supportUrl,
    isEdit,
    setEditPage,
    getUrl,
  };
};

export default useCommonInfo;
