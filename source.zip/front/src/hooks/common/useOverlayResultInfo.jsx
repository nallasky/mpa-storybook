import { useCallback, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  getAdcMeasurementSetting,
  UpdateAdcMeasurementCommonInfoReducer,
  UpdateAnovaGraphSettingReducer,
  UpdateCorrectionCommonInfoReducer,
  UpdateReproducibilityGraphSettingReducer,
  UpdateVariationGraphSettingReducer,
  UpdateMapGraphSettingReducer,
  getCorrectionSetting,
  UpdateCorrectionMapGraphSettingReducer,
  UpdateOasBaseLinePlotGraphSettingReducer,
  getOasBaseLineSetting,
  UpdateOasBaseLineCommonInfoReducer,
  UpdateOasBaseLineMapGraphSettingReducer,
} from '@reducers/slices/OverlayInfo';
import { getTableForm } from '@libs/util/util';

const useOverlayResult = () => {
  const dispatch = useDispatch();
  //------AdcMeasurement------------------------------------------------------
  const gMap = useSelector(getAdcMeasurementSetting).graph.map; //

  //------Correction--- ---------------------------------------------------
  const gCorrectionTargetInfo = useSelector(getCorrectionSetting).targetInfo;
  const gCorrectionInfo = useSelector(getCorrectionSetting).info;
  const gCorrectionData = useSelector(getCorrectionSetting).info.origin;
  const gCorrectionMap = useSelector(getCorrectionSetting).graph;

  //------OasBaseLine--- ---------------------------------------------------
  const gOasBaseLineMap = useSelector(getOasBaseLineSetting).graph.map;

  //-----------REDUX---FUNC UPDATE-------------------------------------------------------

  const updateReproducibilitySetting = useCallback(
    (value) => {
      dispatch(UpdateReproducibilityGraphSettingReducer(value));
    },
    [dispatch],
  );
  const updateMapSetting = useCallback(
    (value) => {
      dispatch(UpdateMapGraphSettingReducer(value));
    },
    [dispatch],
  );
  const updateVariationSetting = useCallback(
    (value) => {
      dispatch(UpdateVariationGraphSettingReducer(value));
    },
    [dispatch],
  );

  const updateAnovaSetting = useCallback(
    (value) => {
      dispatch(UpdateAnovaGraphSettingReducer(value));
    },
    [dispatch],
  );

  const updateAdcCommonInfo = useCallback(
    (data) => {
      dispatch(UpdateAdcMeasurementCommonInfoReducer(data));
    },
    [dispatch],
  );

  const updateCorrectionMapSetting = useCallback(
    (value) => {
      dispatch(UpdateCorrectionMapGraphSettingReducer(value));
    },
    [dispatch],
  );

  const updateCorrectionCommonInfo = useCallback(
    (data) => {
      dispatch(UpdateCorrectionCommonInfoReducer(data));
    },
    [dispatch],
  );

  const updateOasBaseLinePlotGraphSetting = useCallback(
    (value) => {
      dispatch(UpdateOasBaseLinePlotGraphSettingReducer(value));
    },
    [dispatch],
  );
  const updateOasBaseLineMapGraphSetting = useCallback(
    (value) => {
      dispatch(UpdateOasBaseLineMapGraphSettingReducer(value));
    },
    [dispatch],
  );
  const updateOasBaseLineCommonInfo = useCallback(
    (data) => {
      dispatch(UpdateOasBaseLineCommonInfoReducer(data));
    },
    [dispatch],
  );

  //--------------------------------
  const stage_correction_tooltip = useMemo(() => {
    //['[DR]', 'bdc x', '', '[MY]', 'bdc y']
    const setting = gCorrectionTargetInfo.stage_correction_list;
    return Object.keys(setting).reduce((acc, key) => {
      const arr = [];
      Object.keys(setting[key]).forEach((key2) => {
        if (setting[key][key2] === true) arr.push(key2);
      });
      return [...acc, `[${key}]`, ...arr, ''];
    }, []);
  }, [gCorrectionData]);

  const adc_correction_tooltip = useMemo(() => {
    //['[ADC Measurement + Offset]' ]
    const setting = gCorrectionTargetInfo.adc_correction_list;
    const selectedKey = Object.keys(setting).find((o) => setting[o].selected);
    return selectedKey !== undefined
      ? [
          `[${selectedKey}]`,
          ...Object.keys(setting[selectedKey]).filter((o) => {
            return o !== 'selected' && setting[selectedKey][o] ? o : false;
          }),
        ]
      : [];
  }, [gCorrectionData]);

  //--------------------------------

  const getAnovaTableFuc = useCallback((data) => {
    const data_value = Object.values(data);
    const disp_order = Object.keys(data_value?.[0] ?? {});
    const row = Object.keys(data).map((key, i) => ({
      ...data_value[i],
      ADC: key,
    }));
    return getTableForm({
      info: { disp_order: ['ADC'].concat(disp_order), row: row } ?? {},
    });
  }, []);

  return {
    gMap,
    updateMapSetting,
    updateReproducibilitySetting,
    updateVariationSetting,
    updateAnovaSetting,
    updateCorrectionCommonInfo,
    updateAdcCommonInfo,
    updateCorrectionMapSetting,
    updateOasBaseLinePlotGraphSetting,
    updateOasBaseLineCommonInfo,
    updateOasBaseLineMapGraphSetting,

    gCorrectionInfo,
    gOasBaseLineMap,

    gCorrectionData,
    gCorrectionMap,
    getAnovaTableFuc,

    adc_correction_tooltip,
    stage_correction_tooltip,
  };
};
export default useOverlayResult;
