import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import * as slice from '../../reducers/slices/ResultInfo';

const useResultInfo = () => {
  const dispatch = useDispatch();

  const setAnalysisInfo = useCallback(
    (v) => {
      dispatch(slice.UpdateAnalysisReducer(v));
    },
    [dispatch],
  );

  const setOriginalInfo = useCallback(
    (v) => {
      dispatch(slice.UpdateOriginalReducer(v));
    },
    [dispatch],
  );

  const setOriginalFilteredRows = useCallback(
    (v) => {
      dispatch(slice.UpdateOriginalFilteredRowsReducer(v));
    },
    [dispatch],
  );

  const setAnalysisGraphInfo = useCallback(
    (v) => {
      dispatch(slice.UpdateAnalysisGraphInfoReducer(v));
    },
    [dispatch],
  );

  const setOriginalGraphInfo = useCallback(
    (v) => {
      dispatch(slice.UpdateOriginalGraphInfoReducer(v));
    },
    [dispatch],
  );

  const setSavedAggregation = useCallback(
    (v) => {
      dispatch(slice.UpdateSavedAggregationReducer(v));
    },
    [dispatch],
  );

  const setVisualization = useCallback(
    (v) => {
      dispatch(slice.UpdateVisualizationReducer(v));
    },
    [dispatch],
  );

  const initializing = useCallback(() => {
    dispatch(slice.initialAction());
  }, [dispatch]);

  const setSelectedDatabase = useCallback(
    (v) => {
      dispatch(slice.UpdateSelectedDatabaseReducer(v));
    },
    [dispatch],
  );

  const setSelectedEquipment = useCallback(
    (v) => {
      dispatch(slice.UpdateSelectedEquipmentReducer(v));
    },
    [dispatch],
  );

  const setRemoteApplyInfo = useCallback(
    (v) => {
      dispatch(slice.UpdateRemoteApplyInfoReducer(v));
    },
    [dispatch],
  );

  return {
    selectedDatabase: useSelector((state) => state.ResultInfo.selectedDatabase),
    selectedEquipment: useSelector(
      (state) => state.ResultInfo.selectedEquipment,
    ),
    analysisData: useSelector((state) => state.ResultInfo.analysis),
    originalData: useSelector((state) => state.ResultInfo.original),
    originalFilteredRows: useSelector(
      (state) => state.ResultInfo.originalFilteredRows,
    ),
    analysisGraphInfo: useSelector(
      (state) => state.ResultInfo.analysisGraphInfo,
    ),
    originalGraphInfo: useSelector(
      (state) => state.ResultInfo.originalGraphInfo,
    ),
    savedAggregation: useSelector((state) => state.ResultInfo.savedAggregation),
    visualization: useSelector((state) => state.ResultInfo.visualization),
    remoteApplyInfo: useSelector((state) => state.ResultInfo.remoteApplyInfo),
    setAnalysisInfo,
    setOriginalInfo,
    setOriginalFilteredRows,
    setAnalysisGraphInfo,
    setOriginalGraphInfo,
    setSavedAggregation,
    setVisualization,
    setSelectedDatabase,
    setSelectedEquipment,
    setRemoteApplyInfo,
    initializing,
  };
};

export default useResultInfo;
