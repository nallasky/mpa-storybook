import { useDispatch, useSelector } from 'react-redux';
import {
  getAdcMeasurementSetting,
  getCorrectionSetting,
  initialOverlay,
  UpdateAdcMeasurementInfoReducer,
  UpdateCorrectionInfoReducer,
} from '../reducers/slices/OverlayInfo';
import { useCallback } from 'react';

const useOverlayInfo = () => {
  const dispatch = useDispatch();
  const correctionSet = useSelector(getCorrectionSetting);
  const adcMeasurementSet = useSelector(getAdcMeasurementSetting);

  const initialOverlayInfo = useCallback(() => {
    dispatch(initialOverlay());
  }, [dispatch]);

  const updateAdcMeasurementSetting = useCallback(
    (value) => {
      dispatch(UpdateAdcMeasurementInfoReducer(value));
    },
    [dispatch],
  );
  const updateCorrectionSetting = useCallback(
    (value) => {
      dispatch(UpdateCorrectionInfoReducer(value));
    },
    [dispatch],
  );

  return {
    adcMeasurementSet,
    correctionSet,
    initialOverlayInfo,
    updateAdcMeasurementSetting,
    updateCorrectionSetting,
    adcCommonInfo: adcMeasurementSet.info,
    correctionCommonInfo: correctionSet.info,
  };
};
export default useOverlayInfo;
