import { useDispatch, useSelector } from 'react-redux';
import {
  getAdcMeasurementSetting,
  getCorrectionSetting,
  initialOverlay,
  UpdateAdcMeasurementInfoReducer,
  UpdateCorrectionInfoReducer,
} from '../reducers/slices/OverlayInfo';
import { useCallback } from 'react';
import {
  OVERLAY_ADC_CATEGORY,
  OVERLAY_CORRECTION_CATEGORY,
} from '../lib/api/Define/etc';
import useOverlayResultInfo from './useOverlayResultInfo';
import { CPVS_MODE } from '../lib/api/Define/OverlayDefault';

const useOverlayInfo = () => {
  const dispatch = useDispatch();
  const correctionSet = useSelector(getCorrectionSetting);
  const adcMeasurementSet = useSelector(getAdcMeasurementSetting);
  const {
    updateMapSetting,
    updateCorrectionMapSetting,
    updateAdcCommonInfo,
    updateCorrectionCommonInfo,
  } = useOverlayResultInfo();
  const initialOverlayInfo = useCallback(() => {
    dispatch(initialOverlay());
  }, [dispatch]);

  const updateAdcMeasurementSetting = useCallback(
    (value) => {
      dispatch(UpdateAdcMeasurementInfoReducer(value));
    },
    [dispatch],
  );
  const updateCorrectionSetting = useCallback(
    (value) => {
      dispatch(UpdateCorrectionInfoReducer(value));
    },
    [dispatch],
  );
  const getCorrectionCpVsDefault = (defaultV, shot) => {
    return getCorrectionCpVsSetting(defaultV, undefined, shot);
  };

  const getCorrectionCpVsSetting = (defaultV, Value, shot) => {
    const data = Value?.[shot[0]] ?? defaultV;
    const key_list = Object.keys(data).filter(
      (o) => !o.includes('chk') && !o.includes('mode'),
    );
    return {
      cp: shot?.map((shotN) =>
        key_list
          .filter((o) => o.includes('cp'))
          .reduce(
            (acc, o) => ({
              ...acc,
              [o]: {
                value: (defaultV ?? Value?.[shotN])?.[o],
                checked: (defaultV ?? Value?.[shotN])?.[`${o}_chk`] ?? false,
              },
            }),
            {
              shot: {
                id: shotN,
                mode: (Value?.[shotN] ?? defaultV)?.['cpmode'] ?? 'auto',
              },
            },
          ),
      ),
      vs: shot?.map((shotN) =>
        key_list
          .filter((o) => o.includes('vs'))
          .reduce(
            (acc, o) => ({
              ...acc,
              [o]: {
                value: (defaultV ?? Value?.[shotN])?.[o],
                checked: (defaultV ?? Value?.[shotN])?.[`${o}_chk`] ?? false,
              },
            }),
            {
              shot: {
                id: shotN,
                mode: (Value?.[shotN] ?? defaultV)?.['vsmode'] ?? 'auto',
              },
            },
          ),
      ),
    };
  };
  const updateOriginDataSetting = useCallback(
    (data, mode) => {
      const lot_data = Object.values(
        mode === OVERLAY_ADC_CATEGORY ? data.data : data.data.map,
      )[0];
      const plate = Object.keys(lot_data.plate);
      const shot = data?.cp_vs?.correction?.shot ?? data?.cp_vs?.adc_measurement?.shot;
      const adc_measurement_shot = shot.reduce(
        (acc, o) =>
          Object.assign(acc, {
            [o]: data?.cp_vs?.adc_measurement?.default,
          }),
        {},
      );
      if ([OVERLAY_ADC_CATEGORY, OVERLAY_CORRECTION_CATEGORY].includes(mode)) {
        //origin data  & update
        if (mode === OVERLAY_ADC_CATEGORY) {
          //shot & plate information
          updateMapSetting(
            data?.cp_vs ?? false
              ? {
                  ...adcMeasurementSet.graph.map,
                  ...data.etc, //div, plate_size, column_num, display_map
                  offset: {
                    mode: 'auto',
                    info: data?.offset ?? {},
                    default: data?.offset,
                  },
                  cp_vs: {
                    mode:
                      data?.cp_vs?.adc_measurement?.included === true
                        ? CPVS_MODE.FROM_LOG
                        : CPVS_MODE.EACH,
                    shots: adc_measurement_shot,
                    preset: data?.cp_vs?.adc_measurement?.preset,
                  },
                }
              : {
                  ...adcMeasurementSet.graph.map,
                  offset: {
                    ...adcMeasurementSet.graph.map.offset,
                    default: data?.offset,
                  },
                },
          );
          updateAdcCommonInfo({
            shot: shot,
            plate: plate,
            origin:
              data?.cp_vs ?? false
                ? data
                : { ...adcMeasurementSet.info.origin, ...data },
          });
        } else if (mode === OVERLAY_CORRECTION_CATEGORY) {
          const correction_data = data?.cp_vs?.correction;
          const correction_cpvs = getCorrectionCpVsDefault(
            correction_data.default,
            shot,
          );
          updateCorrectionMapSetting(
            data?.cp_vs ?? false
              ? {
                  ...correctionSet.graph.image,
                  ...data.etc, //div, plate_size, column_num, display_map
                  offset: {
                    mode: 'auto',
                    info: data?.offset ?? {},
                    default: data?.offset,
                  },
                  cp_vs: {
                    adc_measurement: {
                      mode:
                        data?.cp_vs?.adc_measurement?.included === true
                          ? CPVS_MODE.FROM_LOG
                          : CPVS_MODE.EACH,
                      shots: adc_measurement_shot,
                      preset: data?.cp_vs?.adc_measurement?.preset,
                    },
                    correction: {
                      mode: CPVS_MODE.EACH,
                      preset: correction_data?.preset ?? {},
                      shots: correction_cpvs,
                    },
                  },
                }
              : {
                  ...correctionSet.graph,
                  offset: {
                    ...correctionSet.graph.offset,
                    default: data?.offset,
                  },
                },
          );
          updateCorrectionCommonInfo({
            shot: shot,
            plate: plate,
            origin:
              data?.cp_vs ?? false
                ? data
                : { ...correctionSet.info.origin, ...data },
          });
        }
      }
    },
    [
      adcMeasurementSet.graph.map,
      correctionSet.graph,
      adcMeasurementSet.info,
      correctionSet.info,
    ],
  );
  return {
    adcMeasurementSet,
    correctionSet,
    initialOverlayInfo,
    updateAdcMeasurementSetting,
    updateCorrectionSetting,
    adcCommonInfo: adcMeasurementSet.info,
    correctionCommonInfo: correctionSet.info,
    updateOriginDataSetting,
    getCorrectionCpVsDefault,
    getCorrectionCpVsSetting,
  };
};
export default useOverlayInfo;
