import { useDispatch, useSelector } from 'react-redux';
import {
  getAdcMeasurementSetting,
  getCorrectionSetting,
  initialOverlay,
  UpdateAdcMeasurementInfoReducer,
  UpdateCorrectionInfoReducer,
} from '../reducers/slices/OverlayInfo';
import { useCallback } from 'react';
import {
  OVERLAY_ADC_CATEGORY,
  OVERLAY_CORRECTION_CATEGORY,
} from '../lib/api/Define/etc';
import useOverlayResultInfo from './useOverlayResultInfo';
import { CPVS_MODE } from '../lib/api/Define/OverlayDefault';

const useOverlayInfo = () => {
  const dispatch = useDispatch();
  const correctionSet = useSelector(getCorrectionSetting);
  const adcMeasurementSet = useSelector(getAdcMeasurementSetting);
  const {
    updateMapSetting,
    updateAdcCommonInfo,
    updateCorrectionCommonInfo,
  } = useOverlayResultInfo();
  const initialOverlayInfo = useCallback(() => {
    dispatch(initialOverlay());
  }, [dispatch]);

  const updateAdcMeasurementSetting = useCallback(
    (value) => {
      dispatch(UpdateAdcMeasurementInfoReducer(value));
    },
    [dispatch],
  );
  const updateCorrectionSetting = useCallback(
    (value) => {
      dispatch(UpdateCorrectionInfoReducer(value));
    },
    [dispatch],
  );
  const updateOriginDataSetting = useCallback((data, mode) => {
    if ([OVERLAY_ADC_CATEGORY, OVERLAY_CORRECTION_CATEGORY].includes(mode)) {
      //origin data  & update
      if (mode === OVERLAY_ADC_CATEGORY) {
        //shot & plate information
        const lot_data = Object.values(data.data)[0];
        const plate = Object.keys(lot_data.plate);
        const plate_data = Object.values(lot_data.plate)[0];
        const shot = Object.keys(plate_data.shot);
        updateMapSetting({
          ...adcMeasurementSet.graph.map,
          ...data.etc, //div, plate_size, column_num, display_map
          offset: { mode: 'auto', info: data?.offset ?? {} },
          cp_vs: {
            mode:
              data?.cp_vs?.adc_measurement?.included === true
                ? CPVS_MODE.FROM_LOG
                : CPVS_MODE.EACH,
            shots: shot.reduce(
              (acc, o) =>
                Object.assign(acc, {
                  [o]: data?.cp_vs?.adc_measurement?.default,
                }),
              {},
            ),
            preset: data?.cp_vs?.adc_measurement?.preset,
          },
        });
        updateAdcCommonInfo({ shot: shot, plate: plate, origin: data });
      } else if (mode === OVERLAY_CORRECTION_CATEGORY) {
        const lot_data = Object.values(data.data.map)[0];
        const plate = Object.keys(lot_data.plate);
        const plate_data = Object.values(lot_data.plate)[0];
        const shot = Object.keys(plate_data.shot);

        updateCorrectionCommonInfo({ shot: shot, plate: plate, origin: data });
      }
    }
  }, []);
  return {
    adcMeasurementSet,
    correctionSet,
    initialOverlayInfo,
    updateAdcMeasurementSetting,
    updateCorrectionSetting,
    adcCommonInfo: adcMeasurementSet.info,
    correctionCommonInfo: correctionSet.info,
    updateOriginDataSetting,
  };
};
export default useOverlayInfo;
