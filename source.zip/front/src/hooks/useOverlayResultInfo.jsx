import { useCallback, useState } from 'react';
import {
  OVERLAY_ADC_CATEGORY,
  OVERLAY_CORRECTION_CATEGORY,
} from '../lib/api/Define/etc';
import {
  OVERLAY_ADC_TYPE_LIST,
  OVERLAY_CORRECTION_TYPE_LIST,
} from '../lib/api/Define/OverlayDefault';
import { useDispatch, useSelector } from 'react-redux';
import {
  getAdcMeasurementSetting,
  UpdateAdcMeasurementCommonInfoReducer,
  UpdateCorrectionCommonInfoReducer,
  UpdateReproducibilityGraphSettingReducer,
  UpdateVariationGraphSettingReducer,
} from '../reducers/slices/OverlayInfo';
import { MSG_X } from '../lib/api/Define/Message';
import { global_adc_mea_data } from '../lib/api/axios/tempResponse';
const useOverlayResult = () => {
  const [type, setType] = useState({ selected: undefined, list: [] });
  const [mode, setMode] = useState(undefined);
  const [AnovaTab, setAnovaTab] = useState(MSG_X);
  const dispatch = useDispatch();
  //const correctionSet = useSelector(getCorrectionSetting);
  const gReproducibility = useSelector(getAdcMeasurementSetting).graph
    .reproducibility;
  const gVariation = useSelector(getAdcMeasurementSetting).graph.variation;
  const gMap = useSelector(getAdcMeasurementSetting).graph.map;

  //-----------REDUX----------------------------------------------------------
  const updateReproducibilitySetting = useCallback(
    (value) => {
      dispatch(UpdateReproducibilityGraphSettingReducer(value));
    },
    [dispatch],
  );
  const updateVariationSetting = useCallback(
    (value) => {
      dispatch(UpdateVariationGraphSettingReducer(value));
    },
    [dispatch],
  );

  const updateAdcCommonInfo = useCallback(
    (data) => {
      dispatch(UpdateAdcMeasurementCommonInfoReducer(data));
    },
    [dispatch],
  );

  const updateCorrectionCommonInfo = useCallback(
    (data) => {
      dispatch(UpdateCorrectionCommonInfoReducer(data));
    },
    [dispatch],
  );
  //-----------------HOOK------------------------------------------------
  const updateResultType = useCallback(
    (e) => {
      setType((prevState) => ({
        ...prevState,
        selected:
          (e ?? mode) === OVERLAY_ADC_CATEGORY
            ? OVERLAY_ADC_TYPE_LIST[0]
            : OVERLAY_CORRECTION_TYPE_LIST[0],
        list:
          (e ?? mode) === OVERLAY_ADC_CATEGORY
            ? OVERLAY_ADC_TYPE_LIST
            : OVERLAY_CORRECTION_TYPE_LIST,
      }));
    },
    [mode],
  );

  const changeMode = (e) => {
    setMode(e);
    updateResultType(e);
    if ([OVERLAY_ADC_CATEGORY, OVERLAY_CORRECTION_CATEGORY].includes(e)) {
      const lot_data = Object.values(global_adc_mea_data.data)[0];
      const plate = Object.keys(lot_data.plate);
      const plate_data = Object.values(lot_data.plate)[0];
      const shot = Object.keys(plate_data.shot);
      updateAdcCommonInfo({ shot: shot, plate: plate });
    }
  };

  const changeGraphType = (e) => {
    const findType = type.list.find((o) => o.id === e);
    if (findType !== undefined) {
      setType((prevState) => ({ ...prevState, selected: findType }));
    } else {
      console.log('not support graph type : ', e);
    }
  };

  return {
    OverlayResultType: type.selected,
    setOverlayResultType: changeGraphType,
    OverlayResultMode: mode,
    setOverlayResultMode: changeMode,
    getOverlayResultTypeList: type.list,
    gVariation,
    gMap,
    gReproducibility,
    updateReproducibilitySetting,
    updateVariationSetting,
    AnovaTab,
    setAnovaTab,
    updateCorrectionCommonInfo,
    updateAdcCommonInfo,
  };
};
export default useOverlayResult;
