import { useCallback, useState } from 'react';
import { OVERLAY_ADC_CATEGORY } from '../lib/api/Define/etc';
import {
  OVERLAY_ADC_TYPE_LIST,
  OVERLAY_CORRECTION_TYPE_LIST,
} from '../lib/api/Define/OverlayDefault';
import { useDispatch, useSelector } from 'react-redux';
import {
  getAdcMeasurementSetting,
  UpdateAdcMeasurementCommonInfoReducer,
  UpdateAnovaGraphSettingReducer,
  UpdateCorrectionCommonInfoReducer,
  UpdateReproducibilityGraphSettingReducer,
  UpdateVariationGraphSettingReducer,
  UpdateMapGraphSettingReducer,
  getCorrectionSetting,
} from '../reducers/slices/OverlayInfo';

const useOverlayResult = () => {
  const [type, setType] = useState({ selected: undefined, list: [] });
  const [mode, setMode] = useState(undefined);
  const [isEtcUpdating, updateEtcSetting] = useState(false);
  const dispatch = useDispatch();
  //------AdcMeasurement------------------------------------------------------
  const gAdcMeasurementFabName = useSelector(getAdcMeasurementSetting)
    .targetInfo.fab_name;
  const gReproducibility = useSelector(getAdcMeasurementSetting).graph
    .reproducibility;
  const gVariation = useSelector(getAdcMeasurementSetting).graph.variation;
  const gMap = useSelector(getAdcMeasurementSetting).graph.map; //
  const gAdcMeasurementData = useSelector(getAdcMeasurementSetting).info.origin;
  const gAnova = useSelector(getAdcMeasurementSetting).graph.anova;
  const gAdcMeasurementCPVS = gAdcMeasurementData?.cp_vs?.adc_measurement ?? {};

  //------Correction--- ---------------------------------------------------
  const gCorrectionData = useSelector(getCorrectionSetting).info.origin;
  const gCorrectionImage = useSelector(getCorrectionSetting).graph.image;
  const gCorrectionComponent = useSelector(getCorrectionSetting).graph.component;

  //-----------REDUX---FUNC UPDATE-------------------------------------------------------

  const updateReproducibilitySetting = useCallback(
    (value) => {
      dispatch(UpdateReproducibilityGraphSettingReducer(value));
    },
    [dispatch],
  );
  const updateMapSetting = useCallback(
    (value) => {
      dispatch(UpdateMapGraphSettingReducer(value));
    },
    [dispatch],
  );

  const updateVariationSetting = useCallback(
    (value) => {
      dispatch(UpdateVariationGraphSettingReducer(value));
    },
    [dispatch],
  );

  const updateAnovaSetting = useCallback(
    (value) => {
      dispatch(UpdateAnovaGraphSettingReducer(value));
    },
    [dispatch],
  );

  const updateAdcCommonInfo = useCallback(
    (data) => {
      dispatch(UpdateAdcMeasurementCommonInfoReducer(data));
    },
    [dispatch],
  );

  const updateCorrectionCommonInfo = useCallback(
    (data) => {
      dispatch(UpdateCorrectionCommonInfoReducer(data));
    },
    [dispatch],
  );
  //-----------------HOOK------------------------------------------------
  const updateResultType = useCallback(
    (e) => {
      setType({
        list:
          (e ?? mode) === OVERLAY_ADC_CATEGORY
            ? OVERLAY_ADC_TYPE_LIST
            : OVERLAY_CORRECTION_TYPE_LIST,
        selected:
          (e ?? mode) === OVERLAY_ADC_CATEGORY
            ? OVERLAY_ADC_TYPE_LIST[0]
            : OVERLAY_CORRECTION_TYPE_LIST[0],
      });
    },
    [mode],
  );

  const changeMode = (e) => {
    setMode(e);
    updateResultType(e);
  };

  const changeGraphType = (e) => {
    const findType = type.list.find((o) => o.id === e);
    if (findType !== undefined) {
      setType((prevState) => ({ ...prevState, selected: findType }));
    } else {
      console.log('not support graph type : ', e);
    }
  };

  return {
    OverlayResultType: type.selected,
    setOverlayResultType: changeGraphType,
    OverlayResultMode: mode,
    setOverlayResultMode: changeMode,
    getOverlayResultTypeList: type.list,
    gVariation,
    gMap,
    gAnova,
    gReproducibility,
    updateMapSetting,
    updateReproducibilitySetting,
    updateVariationSetting,
    updateAnovaSetting,
    updateCorrectionCommonInfo,
    updateAdcCommonInfo,
    gAdcMeasurementData,
    gAdcMeasurementFabName,
    gAdcMeasurementCPVS,
    isEtcUpdating,
    updateEtcSetting,
    gCorrectionData,
    gCorrectionComponent,
    gCorrectionImage
  };
};
export default useOverlayResult;
