import { useQuery, useMutation } from 'react-query';
import { QUERY_KEY } from '@constants/QueryKey';
import {
  getColumnDefineList,
  getLogPatternInfo,
  getRemoteDatabaseInfo,
  postDatabaseSave,
  postDatabaseStatus,
  putLogPatternInfo,
  putColumnDefineInfo,
  deleteColumnDefineInfo,
  getLogDefineList,
  deleteLogDefineLogInfo,
  deleteLogDefineRuleInfo,
  getLocalDatabaseInfo,
  putLocalDatabaseInfo,
  postImportLogDefine,
} from '@libs/axios/configRequest';
import { RequestOnError } from '@libs/util/common/common';

export const useGetRemoteDatabaseInfo = ({
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery([QUERY_KEY.MGMT_REMOTE_DB], getRemoteDatabaseInfo, {
    enabled: enabled,
    onError: onError ?? RequestOnError,
    onSuccess,
    onSettled,
  });

export const useGetLocalDatabaseInfo = ({
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery([QUERY_KEY.MGMT_LOCAL_DB], getLocalDatabaseInfo, {
    enabled: enabled,
    onError: onError ?? RequestOnError,
    onSuccess,
    onSettled,
  });
export const usePutLocalDatabaseInfo = () =>
  useMutation([QUERY_KEY.MGMT_DB_UPDATE], putLocalDatabaseInfo);

export const usePostDatabaseStatus = () =>
  useMutation([QUERY_KEY.MGMT_REMOTE_DB_STATUS], postDatabaseStatus);

export const usePostDatabaseSave = () =>
  useMutation([QUERY_KEY.MGMT_DB_ADD], postDatabaseSave);

export const useGetLogPatternInfo = ({
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery([QUERY_KEY.GET_LOG_PATTERN_LIST], getLogPatternInfo, {
    enabled: enabled,
    onError: onError ?? RequestOnError,
    onSuccess,
    onSettled,
  });
export const usePutLogPatternInfo = () =>
  useMutation([QUERY_KEY.PUT_LOG_PATTERN_INFO], putLogPatternInfo);

export const useGetColumnDefineInfo = ({
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery([QUERY_KEY.GET_COLUMN_DEFINE_LIST], getColumnDefineList, {
    enabled: enabled,
    onError: onError ?? RequestOnError,
    onSuccess,
    onSettled,
  });

export const usePutColumnDefineInfo = () =>
  useMutation([QUERY_KEY.PUT_COLUMN_DEFINE_INFO], putColumnDefineInfo);

export const useDeleteColumnDefineInfo = () =>
  useMutation([QUERY_KEY.DELETE_COLUMN_DEFINE_INFO], deleteColumnDefineInfo);

export const useGetLogDefineInfo = ({
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery([QUERY_KEY.GET_LOG_DEFINE_LIST], getLogDefineList, {
    enabled: enabled,
    onError: onError ?? RequestOnError,
    onSuccess,
    onSettled,
  });
export const usePostLogDefineImport = () =>
  useMutation([QUERY_KEY.POST_LOG_DEFINE_INFO_IMPORT], postImportLogDefine);

export const useDeleteLogDefineLog = () =>
  useMutation([QUERY_KEY.DELETE_LOG_DEFINE_INFO], deleteLogDefineLogInfo);

export const useDeleteLogDefineRule = () =>
  useMutation([QUERY_KEY.DELETE_LOG_DEFINE_INFO], deleteLogDefineRuleInfo);
