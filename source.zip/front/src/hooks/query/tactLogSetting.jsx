import { QUERY_KEY } from '@constants/QueryKey';
import { RequestOnError } from '@libs/util/common/common';
import {
  deleteTactLogScriptFile,
  getTactLogSettingInfo,
  postTactLogScriptFile,
} from '@libs/axios/tactLogRequest';
import { useMutation, useQuery } from 'react-query';

export const useGetTactLogInfo = ({ enabled, onError, onSuccess, onSettled }) =>
  useQuery([QUERY_KEY.TACT_LOG_SETTING_GET], getTactLogSettingInfo, {
    enabled: enabled,
    onError: onError ?? RequestOnError,
    onSuccess,
    onSettled,
  });

export const usePostTactLogScriptFile = () =>
  useMutation(
    [QUERY_KEY.TACT_LOG_SETTING_UPDATE_SCRIPT],
    postTactLogScriptFile,
  );
export const useDeleteTactLogScriptFile = () =>
  useMutation(
    [QUERY_KEY.TACT_LOG_SETTING_DELETE_SCRIPT],
    deleteTactLogScriptFile,
  );
