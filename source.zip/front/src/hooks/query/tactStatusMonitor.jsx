import { useMutation, useQuery } from 'react-query';
import { QUERY_KEY } from '../../constants/QueryKey';
import {
  getTactStatusFilesInfo,
  getTactStatusJobList,
  postTactStatusJobTact,
  postTactStatusPlateDetailTact,
  postTactStatusPlateTact,
  uploadTactStatusFiles,
  uploadTactStatusFilesStatus,
} from '../../libs/axios/tactStatusRequest';

export const usePostTactStatusUploadLogFiles = () => {
  const controller = new AbortController();
  const signal = controller.signal;
  const mutation = useMutation(
    [QUERY_KEY.TACT_STATUS_MONITOR_POST_UPLOAD],
    (arg) => uploadTactStatusFiles(arg, signal),
  );
  const cancel = () => controller.abort();
  return { ...mutation, cancel };
};
export const useGetTactStatusConvertedStatus = ({ rid, options }) =>
  useQuery(
    [QUERY_KEY.TACT_STATUS_MONITOR_GET_CONVERTED_STATUS, rid],
    () => uploadTactStatusFilesStatus({ rid }),
    options ?? {},
  );
export const useGetTactStatusConvertedFilesInfo = ({ rid, options }) =>
  useQuery(
    [QUERY_KEY.TACT_STATUS_MONITOR_GET_CONVERTED_STATUS, rid],
    () => getTactStatusFilesInfo({ rid }),
    options ?? {},
  );

export const useGetTactStatusJobList = ({ rid, period, options }) =>
  useQuery(
    [QUERY_KEY.TACT_STATUS_MONITOR_GET_JOB_LIST, rid, period],
    () => getTactStatusJobList({ rid, period }),
    options ?? {},
  );

export const usePostTactStatusJobTact = () => {
  const controller = new AbortController();
  const signal = controller.signal;
  const mutation = useMutation(
    [QUERY_KEY.TACT_STATUS_MONITOR_POST_JOB_TACT],
    (arg) => postTactStatusJobTact({ ...arg, signal }),
  );
  const cancel = () => controller.abort();
  return { ...mutation, cancel };
};

export const usePostTactStatusPlateTact = () =>
  useMutation(
    [QUERY_KEY.TACT_STATUS_MONITOR_POST_PLATE_TACT],
    postTactStatusPlateTact,
  );
export const usePostTactStatusPlateDetailTact = () =>
  useMutation(
    [QUERY_KEY.TACT_STATUS_MONITOR_POST_PLATE_TACT],
    postTactStatusPlateDetailTact,
  );
