import { useQuery } from 'react-query';
import { QUERY_KEY } from '@constants/QueryKey';
import { getMainVersionInfo } from '@libs/axios/mainRequest';
import { RequestOnError } from '@libs/util/common/common';

export const useGetVersionInfo = ({ onError, onSuccess }) =>
  useQuery([QUERY_KEY.VERSION_INIT], getMainVersionInfo, {
    onError: onError ?? RequestOnError,
    onSuccess,
  });
