import { QUERY_KEY } from '@constants/QueryKey';
import { RequestOnError } from '@libs/util/common/common';
import { useMutation, useQuery } from 'react-query';
import {
  getEditStep1Resource,
  getStep1Resource,
} from '@libs/axios/anlysisFunctionStepRequest';
import {
  URL_RESOURCE_EDIT_INIT,
  URL_RESOURCE_NEW_INIT,
  URL_SETTING_LOG_DEFINE_NEW_STEP1,
} from '@constants/URL';
import { postLogStepSampleLog } from '@libs/axios/LogStepRequest';

export const useGetJobStepResource = ({
  isEdit,
  func_id,
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery(
    [QUERY_KEY.STEP1_INIT, func_id],
    () =>
      isEdit
        ? getEditStep1Resource({ url: `${URL_RESOURCE_EDIT_INIT}/${func_id}` })
        : getStep1Resource({ url: URL_RESOURCE_NEW_INIT }),
    {
      enabled: enabled,
      onError: onError ?? RequestOnError,
      onSuccess,
      onSettled,
    },
  );

export const useGetRuleStepResource = ({
  isEdit,
  log_name,
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery(
    [QUERY_KEY.STEP1_INIT, log_name],
    () =>
      isEdit
        ? getEditStep1Resource({
            url: `${URL_SETTING_LOG_DEFINE_NEW_STEP1}/${log_name}`,
          })
        : getStep1Resource({
            url: log_name
              ? `${URL_SETTING_LOG_DEFINE_NEW_STEP1}/${log_name}`
              : URL_SETTING_LOG_DEFINE_NEW_STEP1,
          }),
    {
      enabled: enabled,
      onError: onError ?? RequestOnError,
      onSuccess,
      onSettled,
    },
  );

export const usePostLogStepSampleLog = () =>
  useMutation([QUERY_KEY.LOG_STEP_SAMPLE_LOG], postLogStepSampleLog);
