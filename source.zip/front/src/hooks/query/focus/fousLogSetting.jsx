import { QUERY_KEY } from '@constants/QueryKey';
import { RequestOnError } from '@libs/util/common/common';
import { useMutation, useQuery } from 'react-query';
import {
  deleteFocusLogScriptFile,
  getFocusLogSettingInfo,
  postFocusLogScriptFile,
} from '@libs/axios/focusRequest';

export const useGetFocusLogInfo = ({
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery([QUERY_KEY.FOCUS_LOG_SETTING_GET], getFocusLogSettingInfo, {
    enabled: enabled,
    onError: onError ?? RequestOnError,
    onSuccess,
    onSettled,
  });

export const usePostFocusLogScriptFile = () =>
  useMutation(
    [QUERY_KEY.FOCUS_LOG_SETTING_UPDATE_SCRIPT],
    postFocusLogScriptFile,
  );
export const useDeleteFocusLogScriptFile = () =>
  useMutation(
    [QUERY_KEY.FOCUS_LOG_SETTING_DELETE_SCRIPT],
    deleteFocusLogScriptFile,
  );
