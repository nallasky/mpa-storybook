import { useMutation, useQuery } from 'react-query';
import { QUERY_KEY } from '@constants/QueryKey';
import {
  getTactMemoryFilesAnalysisResult,
  postTactMemoryFilesAnalysisResult,
  uploadTactMemoryFiles,
  uploadTactMemoryFilesStatus,
} from '@libs/axios/tactMemoryRequest';

export const usePostTactMemoryUploadLogFiles = () => {
  const controller = new AbortController();
  const signal = controller.signal;
  const mutation = useMutation(
    [QUERY_KEY.TACT_MEMORY_DUMP_POST_UPLOAD],
    (arg) => uploadTactMemoryFiles(arg, signal),
  );
  const cancel = () => controller.abort();
  return { ...mutation, cancel };
};
export const useGetTactMemoryConvertedStatus = ({ rid, options }) =>
  useQuery(
    [QUERY_KEY.TACT_MEMORY_DUMP_GET_CONVERTED_STATUS, rid],
    () => uploadTactMemoryFilesStatus({ rid }),
    options ?? {},
  );

export const useGetTactMemoryAnalysisResult = ({ rid, auto_adjust, options }) =>
  useQuery(
    [QUERY_KEY.TACT_MEMORY_DUMP_GET_ANALYSIS_RESULT, rid],
    () => getTactMemoryFilesAnalysisResult({ rid, auto_adjust }),
    options ?? {},
  );

export const usePostTactMemoryAnalysisResult = () =>
  useMutation(
    [QUERY_KEY.TACT_MEMORY_DUMP_POST_ANALYSIS_RESULT],
    postTactMemoryFilesAnalysisResult,
  );
