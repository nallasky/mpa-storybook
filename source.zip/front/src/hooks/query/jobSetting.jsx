import { useQuery } from 'react-query';
import { QUERY_KEY } from '../../constants/QueryKey';
import { RequestOnError } from '@libs/util/common/common';
import { getResource_JobSetting } from '@libs/axios/jobSettingRequest';

export const useGetJobResource = ({
  func_id,
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery(
    [QUERY_KEY.JOBSETTING_INIT, func_id],
    () => getResource_JobSetting({ func_id }),
    {
      enabled: enabled,
      onError: onError ?? RequestOnError,
      onSuccess,
      onSettled,
    },
  );
