import { useQuery } from 'react-query';
import { QUERY_KEY } from '../../constants/QueryKey';
import { getTactSettingInfo } from '../../libs/axios/tactSettingRequest';

export const useGetTactSettingInfo = (tab, onSuccess, onError) => {
  return useQuery(
    [QUERY_KEY.TACT_SETTING_GET, tab],
    () => getTactSettingInfo({ tab }),
    {
      onSuccess,
      onError,
    },
  );
};
export const usePutTactSettingInfo = (tab, onSuccess, onError) => {
  return useQuery(
    [QUERY_KEY.TACT_SETTING_GET, tab],
    () => getTactSettingInfo({ tab }),
    {
      onSuccess,
      onError,
    },
  );
};
