import { useMutation, useQuery } from 'react-query';
import { QUERY_KEY } from '../../constants/QueryKey';
import {
  addTactSettingPuName,
  deleteTactSettingPuName,
  downloadTactSettingInfo,
  getTactSettingInfo,
  importTactSettingInfo,
  putTactSettingInfo,
} from '../../libs/axios/tactSettingRequest';

export const useGetTactSettingInfo = ({ tab, options }) =>
  useQuery(
    [QUERY_KEY.TACT_SETTING_GET, tab],
    () => getTactSettingInfo({ tab }),
    options ?? {},
  );
export const useGetTactSettingDownload = ({ options, key }) =>
  useQuery(
    [QUERY_KEY.TACT_SETTING_DOWNLOAD, key],
    downloadTactSettingInfo,
    options ?? {},
  );

export const usePutTactSettingInfo = () =>
  useMutation([QUERY_KEY.TACT_SETTING_UPDATE], putTactSettingInfo);

export const usePostImportSetting = () =>
  useMutation([QUERY_KEY.TACT_SETTING_POST_IMPORT], importTactSettingInfo);

export const useDeletePrimaryPuName = () =>
  useMutation([QUERY_KEY.TACT_SETTING_DELETE_PU_NAME], deleteTactSettingPuName);

export const usePutPrimaryPuName = () =>
  useMutation([QUERY_KEY.TACT_SETTING_PUT_PU_NAME], addTactSettingPuName);
