import { QUERY_KEY } from '@constants/QueryKey';
import { RequestOnError } from '@libs/util/common/common';
import {
  add_Overlay_preset_info,
  delete_Overlay_preset_info,
  get_Overlay_Correction_Setting_Info,
  get_Overlay_Info,
  get_Overlay_preset_Info,
  get_Overlay_Remote_Equipment_Info,
  get_Overlay_Remote_Info,
  post_Overlay_Analysis,
  post_Overlay_job_FilesUpload,
  post_Overlay_upload_machine,
  put_Overlay_graph_setting,
  update_Overlay_preset_info,
} from '@libs/axios/overlayRequest';
import { useQuery, useMutation } from 'react-query';

export const useGetOverlayInfo = ({
  category,
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery(
    [QUERY_KEY.OVERLAY_INITIAL_INFO],
    () => get_Overlay_Info({ category }),
    {
      enabled: enabled,
      onError: onError ?? RequestOnError,
      onSuccess,
      onSettled,
    },
  );
export const useGetOverlayRemoteInfo = ({
  obj,
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery(
    [QUERY_KEY.OVERLAY_REMOTE_INFO],
    () => get_Overlay_Remote_Info(obj),
    {
      enabled: enabled,
      onError: onError ?? RequestOnError,
      onSuccess,
      onSettled,
    },
  );
export const useGetOverlayRemoteEquipmentInfo = ({
  obj,
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery(
    [QUERY_KEY.OVERLAY_REMOTE_USER_FAB_EQUIPMENT],
    () => get_Overlay_Remote_Equipment_Info(obj),
    {
      enabled: enabled,
      onError: onError ?? RequestOnError,
      onSuccess,
      onSettled,
    },
  );
export const useGetOverlayCorrectionSettingInfo = ({
  fab_name,
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery(
    [QUERY_KEY.OVERLAY_CORRECTION_SETTING_INFO],
    () => get_Overlay_Correction_Setting_Info(fab_name),
    {
      enabled: enabled,
      onError: onError ?? RequestOnError,
      onSuccess,
      onSettled,
    },
  );
export const useGetOverlayCpvs = ({
  id,
  category,
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery(
    [QUERY_KEY.OVERLAY_PRESET_GET],
    () => get_Overlay_preset_Info({ id, category }),
    {
      enabled: enabled,
      onError: onError ?? RequestOnError,
      onSuccess,
      onSettled,
    },
  );
export const usePostOverlayAnalysisUpload = () =>
  useMutation([QUERY_KEY.OVERLAY_ANALYSIS_UPLOAD], post_Overlay_upload_machine);

export const usePostOverlayAnalysis = (controller) => {
  const cancel = () => controller.current?.abort();
  const mutation = useMutation([QUERY_KEY.OVERLAY_ANALYSIS_START], (arg) => {
    controller.current = new AbortController();
    return post_Overlay_Analysis({
      ...arg,
      signal: controller.current.signal,
    });
  });
  return { ...mutation, cancel };
};

/* ==================== Overlay CPVS Setting ==================*/

export const usePostOverlayCpVsUploadLogFiles = (controller) => {
  const mutation = useMutation(
    [QUERY_KEY.OVERLAY_CPVS_JOB_FILE_UPLOAD],
    ({ category, form }) => {
      if (controller) {
        controller.current = new AbortController();
        return post_Overlay_job_FilesUpload(
          category,
          form,
          controller?.current?.signal,
        );
      } else {
        return post_Overlay_job_FilesUpload(category, form, undefined);
      }
    },
  );
  const cancel = () => controller?.current?.abort();
  return { ...mutation, cancel };
};

export const usePostOverlayCpvsDelete = () =>
  useMutation([QUERY_KEY.OVERLAY_PRESET_DELETE], delete_Overlay_preset_info);

export const usePostOverlayCpvsUpdate = () => {
  const mutation = useMutation(
    [QUERY_KEY.OVERLAY_PRESET_UPDATE],
    update_Overlay_preset_info,
  );
  return mutation;
};
export const usePostOverlayCpvsAdd = () => {
  const mutation = useMutation(
    [QUERY_KEY.OVERLAY_PRESET_ADD],
    add_Overlay_preset_info,
  );
  return mutation;
};

export const usePutOverlayGraphInfo = () =>
  useMutation([QUERY_KEY.OVERLAY_GRAPH_INFO_PUT], put_Overlay_graph_setting);
