import { QUERY_KEY } from '@constants/QueryKey';
import { RequestOnError } from '@libs/util/common/common';
import {
  deleteOverlayLogScriptFile,
  getOverlayLogSettingInfo,
  postOverlayLogScriptFile,
} from '@libs/axios/overlayLogRequest';
import { useMutation, useQuery } from 'react-query';

export const useGetOverlayLogInfo = ({
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery([QUERY_KEY.OVERLAY_LOG_SETTING_GET], getOverlayLogSettingInfo, {
    enabled: enabled,
    onError: onError ?? RequestOnError,
    onSuccess,
    onSettled,
  });

export const usePostOverlayLogScriptFile = () =>
  useMutation(
    [QUERY_KEY.OVERLAY_LOG_SETTING_UPDATE_SCRIPT],
    postOverlayLogScriptFile,
  );
export const useDeleteOverlayLogScriptFile = () =>
  useMutation(
    [QUERY_KEY.OVERLAY_LOG_SETTING_DELETE_SCRIPT],
    deleteOverlayLogScriptFile,
  );
