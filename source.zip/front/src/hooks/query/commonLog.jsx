import { QUERY_KEY } from '@constants/QueryKey';
import {
  deleteCommonLogItem,
  exportCommonLogItem,
  getCategoryInfo,
  importCommonLogItem,
  postUpdateCategory,
} from '@libs/axios/commonLogRequest';
import { RequestOnError } from '@libs/util/common/common';
import { useMutation, useQuery } from 'react-query';

export const useGetCommonLogInfo = ({
  enabled,
  onError,
  onSuccess,
  onSettled,
}) =>
  useQuery([QUERY_KEY.GET_COMMON_LOG_LIST], getCategoryInfo, {
    enabled: enabled,
    onError: onError ?? RequestOnError,
    onSuccess,
    onSettled,
  });

export const usePostUpdateCategory = () =>
  useMutation([QUERY_KEY.UPDATE_CATEGORY], postUpdateCategory);

export const useDeleteCommonLogItem = () =>
  useMutation([QUERY_KEY.DELETE_COMMON_LOG_ITEM], deleteCommonLogItem);

export const usePostCommonLogExport = () =>
  useMutation([QUERY_KEY.EXPORT_COMMON_LOG_ITEM], exportCommonLogItem);

export const usePostCommonLogImport = () =>
  useMutation([QUERY_KEY.IMPORT_COMMON_LOG_ITEM], importCommonLogItem);
