import { createSlice } from '@reduxjs/toolkit';

const initialJobSettingState = {
  resource: {},
  info: {
    log_name: '',
    source: '',
    target_path: [],
    equipment_type: '',
  },
};
const initialState = {
  categories: [],
  logList: [],
  jobSetting: initialJobSettingState,
};

const CommonLogInfo = createSlice({
  name: 'CommonLogInfo',
  initialState,
  reducers: {
    initialCommonLogReducer: () => initialState,
    initialJobSettingReducer: (state) => {
      state.jobSetting = initialJobSettingState;
    },
    UpdateJobSettingReducer: (state, action) => {
      const { info, resource } = action.payload;
      if (info ?? false) {
        state.jobSetting.info = info;
      }
      if (resource ?? false) {
        state.jobSetting.resource = resource;
      }
    },
    UpdateAllCommonLogSettingReducer: (state, action) => {
      const { category, log } = action.payload;
      return {
        ...state,
        categories: Array.isArray(category)
          ? category
          : state.categories.map((obj) =>
              obj.category_id === category.category_id ? category : obj,
            ),
        logList: Array.isArray(log)
          ? log
          : state.logList.map((obj) => (obj.id === log.log.id ? log : obj)),
      };
    },
    UpdateCategoriesReducer: (state, action) => {
      const object = action.payload;
      return {
        ...state,
        categories: Array.isArray(object)
          ? object
          : state.categories.map((obj) =>
              obj.category_id === object.category_id ? object : obj,
            ),
      };
    },
    UpdateLogListReducer: (state, action) => {
      const object = action.payload;
      return {
        ...state,
        logList: Array.isArray(object)
          ? object
          : state.logList.map((obj) => (obj.id === object.id ? object : obj)),
      };
    },
  },
});

//reducer's action
export const {
  initialCommonLogReducer: initialCommonLogReducer,
  UpdateCategoriesReducer,
  UpdateLogListReducer,
  UpdateAllCommonLogSettingReducer,
  UpdateJobSettingReducer,
  initialJobSettingReducer,
} = CommonLogInfo.actions;

export const getLogLists = (state) => state.CommonLogInfo.logList;
export const getCategories = (state) => state.CommonLogInfo.categories;
export const getJobSettingInfo = (state) => state.CommonLogInfo.jobSetting;

export default CommonLogInfo.reducer;
