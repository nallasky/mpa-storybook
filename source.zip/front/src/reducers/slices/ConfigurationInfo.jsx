import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  dbList: [],
  dbPath: '',
  logPattern: [],
  logColumn: {
    data: [],
    data_type: [],
    def_type: [],
  },
  logDefine: [],
};
const makeObject = (objList, origin, key) =>
  objList.findIndex((obj) => obj[key] === origin[key]) !== -1
    ? objList.map((obj) => (obj[key] === origin[key] ? origin : obj))
    : [...objList, origin];
const ConfigurationInfo = createSlice({
  name: 'configuration',
  initialState,
  reducers: {
    initialConfigurationReducer: () => initialState,
    UpdateLocalDatabaseReducer: (state, action) => {
      state.dbPath = action.payload;
    },
    UpdateDatabaseReducer: (state, action) => {
      const object = action.payload;
      return {
        ...state,
        dbList: Array.isArray(object)
          ? object.length > 0
            ? object
            : []
          : makeObject(state.dbList, object, 'id'),
      };
    },
    UpdateLogPatternReducer: (state, action) => {
      const object = action.payload;
      return {
        ...state,
        logPattern: Array.isArray(object)
          ? object
          : makeObject(state.logPattern, object, 'idx'),
      };
    },
    UpdateLogColumnReducer: (state, action) => {
      const object = action.payload;
      return {
        ...state,
        logColumn: object.data_type
          ? object
          : {
              ...state.logColumn,
              data: Array.isArray(object)
                ? object
                : makeObject(state.logColumn, object, 'idx'),
            },
      };
    },
    UpdateLogDefineReducer: (state, action) => {
      const object = action.payload;
      return {
        ...state,
        logDefine: Array.isArray(object)
          ? object
          : makeObject(state.logDefine, object, 'idx'),
      };
    },
  },
});

//reducer's action
export const {
  initialConfigurationReducer: initialConfigurationAction,
  UpdateDatabaseReducer,
  UpdateLogPatternReducer,
  UpdateLogColumnReducer,
  UpdateLogDefineReducer,
  UpdateLocalDatabaseReducer,
} = ConfigurationInfo.actions;

export const getDBList = (state) => state.ConfigurationInfo.dbList;
export const getLocalDBPath = (state) => state.ConfigurationInfo.dbPath;
export const getLogPatternList = (state) => state.ConfigurationInfo.logPattern;
export const getLogColumnList = (state) =>
  state.ConfigurationInfo.logColumn.data;
export const getLogColumnDefType = (state) =>
  state.ConfigurationInfo.logColumn.def_type;
export const getLogColumnDataType = (state) =>
  state.ConfigurationInfo.logColumn.data_type;
export const getLogDefineList = (state) => state.ConfigurationInfo.logDefine;

export default ConfigurationInfo.reducer;
