import { createSlice, createSelector } from '@reduxjs/toolkit';

const commonUpdateInfoAll = (_, action) => ({ ...action.payload });

const commonUpdateInfoSingle = (state, action) => {
  if (Array.isArray(action.payload)) {
    const tmpState = {};
    action.payload.forEach((v) => {
      const { key, value } = v;
      tmpState[key] = value;
    });
    return { ...state, ...tmpState };
  } else {
    const { key, value } = action.payload;
    state[key] = value;
  }
};

const commonSelectorOption = {
  memoizeOptions: {
    equalityCheck: (a, b) => JSON.stringify(a) === JSON.stringify(b),
  },
};

export const initialFileList = {
  FOCUSLOGDETAIL: [],
  ILLUMINANCEMULTITABLE: [],
  PLATEAUTOFOCUSCOMPENSATION: [],
  PLATEFOCUSINTERLOCKMONITOR: [],
  PRESCANCOMPENSATIONMONITOR: [],
  STAGEPOSITIONMONITOR: [],
  StatusMonitor: [],
  machine: [],
  unknown: [],
  prescan: [],
  chuck: [],
  rtaf: [],
};

export const initialFileInfoState = {
  fileList: initialFileList,
  deviceList: {},
  deleteList: [],
};

const FocusFileInfo = createSlice({
  name: 'FocusFileInfo',
  initialState: initialFileInfoState,
  reducers: {
    resetFileInfo: () => initialFileInfoState,
    UpdateFileInfoAll: commonUpdateInfoAll,
    UpdateFileInfoSingle: commonUpdateInfoSingle,
  },
});

const fileInfoFileListSelector = (state) => state.FocusFileInfo.fileList;
const fileInfoDeviceListSelector = (state) => state.FocusFileInfo.deviceList;
const fileInfoDeleteListSelector = (state) => state.FocusFileInfo.deleteList;
export const fileInfoSelector = createSelector(
  [fileInfoFileListSelector, fileInfoDeviceListSelector],
  (fileList, deviceList) => ({
    fileList,
    deviceList,
  }),
  commonSelectorOption,
);
export const fileDeleteListSelector = createSelector(
  fileInfoDeleteListSelector,
  (deleteList) => deleteList,
  commonSelectorOption,
);

export const initialGraphSetting = {
  'PS Pitch': {},
  'PS Roll': {},
  'PS Z': {},
  prescan: {},
  rtaf: {},
  chuck: {},
  type: '',
};

export const initialGraphScale = {
  line_graph_left_scale: {},
  stacked_graph_left_scale: {},
  stacked_graph_right_scale: {},
  graph_left_scale: {},
  graph_right_scale: {},
};

export const initialGraphData = {
  'PS Pitch': [],
  'PS Roll': [],
  'PS Z': [],
  prescan: [],
  rtaf: [],
  chuck: {},
};

export const initialSavedGraphInfoState = {
  graph_setting: initialGraphSetting,
  graph_scale: initialGraphScale,
  graph_data: initialGraphData,
  shot_setting: {
    list: [],
    selected: {
      'PS Pitch': '',
      'PS Roll': '',
      'PS Z': '',
    },
    isAll: false,
  },
};

const FocusSavedGraphInfo = createSlice({
  name: 'FocusSavedGraphInfo',
  initialState: initialSavedGraphInfoState,
  reducers: {
    resetSavedGraphInfo: () => initialSavedGraphInfoState,
    UpdateSavedGraphInfoAll: commonUpdateInfoAll,
    UpdateSavedGraphInfoSingle: commonUpdateInfoSingle,
    UpdateSavedGraphInfoShotSelected: (state, action) => {
      const { key, value } = action.payload;
      state.shot_setting.selected[key] = value;
    },
    UpdateSavedGraphInfoShotSelectedAll: (state, action) => {
      const { isAll, value } = action.payload;
      if (isAll) {
        state.shot_setting.selected = {
          'PS Pitch': value,
          'PS Roll': value,
          'PS Z': value,
        };
      }
      state.shot_setting.isAll = isAll;
    },
    UpdateSavedGraphInfoTolerance: (state, action) => {
      const { graph_setting } = state;
      const { type, list } = action.payload;
      const result = {};
      for (const [key, value] of Object.entries(graph_setting)) {
        if (!['PS Pitch', 'PS Roll', 'PS Z'].includes(key)) continue;
        if (type === 'all' || type === key) {
          const tmpObj = {};
          for (const [subKey, subValue] of Object.entries(value)) {
            tmpObj[subKey] =
              type === 'all'
                ? {
                    ...subValue,
                    ...list[key][subKey],
                  }
                : {
                    ...subValue,
                    ...list[subKey],
                  };
          }
          result[key] = tmpObj;
        } else {
          result[key] = value;
        }
      }
      state.graph_setting = {
        ...graph_setting,
        ...result,
      };
    },
    UpdateSavedGraphInfoColor: (state, action) => {
      const { key, value } = action.payload;
      const { graph_setting } = state;
      const result = {};
      for (const [k, v] of Object.entries(graph_setting[key])) {
        result[k] = Object.hasOwn(value, k)
          ? {
              ...v,
              ...value[k],
            }
          : v;
      }
      state.graph_setting = {
        ...graph_setting,
        [key]: result,
      };
    },
    UpdateSavedGraphSetting: (state, action) => {
      const { key, value } = action.payload;
      state.graph_setting[key] = {
        ...state.graph_setting[key],
        ...value,
      };
    },
    UpdateSavedGraphScale: (state, action) => {
      const { key, value } = action.payload;
      state.graph_scale[key] = value;
    },
  },
});
const savedGraphInfoGraphSettingSelector = (state) =>
  state.FocusSavedGraphInfo.graph_setting;
const savedGraphInfoGraphScaleSelector = (state) =>
  state.FocusSavedGraphInfo.graph_scale;
const savedGraphInfoGraphDataSelector = (state) =>
  state.FocusSavedGraphInfo.graph_data;
const savedGraphInfoShotSettingSelector = (state) =>
  state.FocusSavedGraphInfo.shot_setting;
const savedGraphInfoRenderItemSelector = (state) => {
  const {
    graph_setting,
    graph_scale,
    graph_data,
    shot_setting: { selected },
  } = state.FocusSavedGraphInfo;
  return {
    graph_setting,
    graph_scale,
    graph_data,
    selected_shot: selected,
  };
};
const savedGraphInfoTypeSelector = (state) =>
  state.FocusSavedGraphInfo.graph_setting.type;

export const graphSettingSelector = createSelector(
  savedGraphInfoGraphSettingSelector,
  (graph_setting) => graph_setting,
  commonSelectorOption,
);
export const graphScaleSelector = createSelector(
  savedGraphInfoGraphScaleSelector,
  (graph_scale) => graph_scale,
  commonSelectorOption,
);
export const graphDataSelector = createSelector(
  savedGraphInfoGraphDataSelector,
  (graph_data) => graph_data,
  commonSelectorOption,
);
export const graphShotSettingSelector = createSelector(
  savedGraphInfoShotSettingSelector,
  (shot_setting) => shot_setting,
  commonSelectorOption,
);
export const graphRenderInfoSelector = createSelector(
  savedGraphInfoRenderItemSelector,
  (graph_info) => graph_info,
  commonSelectorOption,
);
export const graphTypeSelector = createSelector(
  savedGraphInfoTypeSelector,
  (type) => type,
  commonSelectorOption,
);

export const initialTargetInfoState = {
  rid: '',
  fab_name: '',
  fab_list: [],
  period: [],
  selectedPeriod: [],
  job: '',
  job_list: [],
  lot_id: '',
  lot_id_list: {},
  mean_dev_diff: [],
  mean_dev_diff_list: [],
  currentTab: 'status',
};

const FocusTargetInfo = createSlice({
  name: 'FocusTargetInfo',
  initialState: initialTargetInfoState,
  reducers: {
    resetTargetInfo: () => initialTargetInfoState,
    UpdateTargetInfoAll: commonUpdateInfoAll,
    UpdateTargetInfoSingle: commonUpdateInfoSingle,
    UpdateTargetInfoCurrentTab: (state, action) => {
      state.currentTab = action.payload;
    },
  },
});

const focusTargetInfoSelector = (state) => state.FocusTargetInfo;
const focusTargetInfoRidSelector = (state) => state.FocusTargetInfo.rid;
const focusTargetInfoFabSelector = (state) => state.FocusTargetInfo.fab_name;
const focusTargetInfoPeriodSelector = (state) =>
  state.FocusTargetInfo.selectedPeriod;
const focusTargetInfoJobSelector = (state) => state.FocusTargetInfo.job;
const focusTargetInfoLotIdSelector = (state) => state.FocusTargetInfo.lot_id;
const focusTargetCurrentTabSelector = (state) =>
  state.FocusTargetInfo.currentTab;
export const targetInfoAllSelector = createSelector(
  focusTargetInfoSelector,
  (target_info) => target_info,
  commonSelectorOption,
);
export const targetInfoRidSelector = createSelector(
  focusTargetInfoRidSelector,
  (rid) => rid,
  commonSelectorOption,
);
export const targetInfoFabSelector = createSelector(
  focusTargetInfoFabSelector,
  (name) => name,
  commonSelectorOption,
);
export const targetInfoCurrentTabSelector = createSelector(
  focusTargetCurrentTabSelector,
  (currentTab) => currentTab,
  commonSelectorOption,
);
export const targetInfoExportSelector = createSelector(
  [
    focusTargetInfoFabSelector,
    focusTargetInfoPeriodSelector,
    focusTargetInfoJobSelector,
    focusTargetInfoLotIdSelector,
  ],
  (fab, period, job, lot_id) => ({
    fab,
    period,
    job,
    lot_id,
  }),
  commonSelectorOption,
);

export const focusFileInfoActions = FocusFileInfo.actions;
export const focusSavedGraphInfoActions = FocusSavedGraphInfo.actions;
export const focusTargetInfoActions = FocusTargetInfo.actions;

//---------- About Focus Log Setting -----------------------------------------------------

const updateLogSettingInfoAll = (_, action) => [...action.payload];
const initialLogSettingState = [];

const FocusLogSettingInfo = createSlice({
  name: 'FocusLogSettingInfo',
  initialState: initialLogSettingState,
  reducers: {
    resetLogSettingInfo: () => initialLogSettingState,
    UpdateLogList: updateLogSettingInfoAll,
  },
});
export const focusLogSettingSelector = (state) => state.FocusLogSettingInfo;
export const focusLogSettingActions = FocusLogSettingInfo.actions;

export default {
  FocusFileInfo: FocusFileInfo.reducer,
  FocusSavedGraphInfo: FocusSavedGraphInfo.reducer,
  FocusTargetInfo: FocusTargetInfo.reducer,
  FocusLogSettingInfo: FocusLogSettingInfo.reducer,
};
