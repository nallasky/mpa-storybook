import { createSlice } from '@reduxjs/toolkit';
import { MAIN } from '@constants/URL';
const initialState = {
  path: [MAIN],
  supportUrl: [],
  menuInfo: '',
  version: '',
};
const BasicInfo = createSlice({
  name: 'BasicInfo',
  initialState,
  reducers: {
    initialBasicReducer: () => initialState,
    UpdateVersionInfoReducer: (state, action) => {
      state.version = action.payload;
    },
    UpdateMenuInfoReducer: (state, action) => {
      state.menuInfo = action.payload;
    },
  },
});

//reducer's action
export const {
  initialBasicReducer: initialCommonAction,
  UpdateVersionInfoReducer,
} = BasicInfo.actions;

export const getSupportUrl = (state) => state.BasicInfo.supportUrl;
export const getVersionInfo = (state) => state.BasicInfo.version;

export default BasicInfo.reducer;
