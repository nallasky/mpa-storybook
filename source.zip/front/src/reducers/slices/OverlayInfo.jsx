import { createSlice } from '@reduxjs/toolkit';
import { MSG_LOCAL, MESSAGE } from '../../constants/Message';
import { V_OFF } from '../../constants/etc';
import { getParseData } from '../../libs/util/util';

export const initialOverlayValue = {
  source: MSG_LOCAL,
  source_info: {
    files_rid: '',
    db: { id: '', name: '' },
  },
  targetInfo: {
    fab_name: '',
    fab_list: [],
    equipment_name: '',
    equipment_name_list: {},
    period: ['', ''],
    selected: ['', ''],
    job: '',
    job_list: [],
    lot_id: [],
    lot_id_list: {},
    mean_dev_diff: [],
    mean_dev_diff_list: [],
    ae_correction: V_OFF,
    stage_correction: [],
    stage_correction_list: {},
    adc_correction: [],
    adc_correction_list: {},
  },
  info: { plate: [], shot: [], origin: undefined },
};
export const mapInitial = {
  column_num: undefined,
  show_extra_info: true,
  div: {
    div_upper: undefined,
    div_lower: undefined,
    scale: undefined,
  },
  display_map: {
    min: 1,
    max: 30,
  },
  plate_size: {
    size_x: undefined,
    size_y: undefined,
  },
  offset: {},
  cp_vs: {},
};
const plotInitial = {
  shot: { list: [], selected: '' },
  graph_type: '',
  highlight_glass: { list: [], selected: '' },
  scale: { type: '', upper_limit: '0', lower_limit: '0' },
  color: {},
};
const AdcGraphInitial = {
  map: mapInitial,
  variation: {
    x_range_min: 0,
    x_range_max: 0,
    y_range_min: 0,
    y_range_max: 0,
    select_shot: 'all',
  },
  reproducibility: {
    three_sigma_x: 0,
    three_sigma_y: 0,
  },
  anova: {
    selected: MESSAGE.X.toUpperCase(),
  },
};
/*const CorrectionGraphInitial = {
  image: mapInitial,
  component: mapInitial,
};*/

const correctionFileInitValue = () => {
  return Array.from(Array(5), (_, i) => {
    return i !== 4
      ? {
          status: undefined,
          type: undefined,
          fileObj: undefined,
        }
      : [];
  });
};

export const initialCorrectionUploadedFiles = {
  ADCMEASUREMENT: correctionFileInitValue(),
  OffsetTable: correctionFileInitValue(),
  CASPHeader: correctionFileInitValue(),
  CASPTable: correctionFileInitValue(),
  DRTable: correctionFileInitValue(),
  MYTable: correctionFileInitValue(),
  YawTable: correctionFileInitValue(),
  machine: correctionFileInitValue(),
  unknown: [],
};

export const initialOverlayState = {
  correction: { ...initialOverlayValue, graph: mapInitial },
  adcMeasurement: { ...initialOverlayValue, graph: AdcGraphInitial },
  oasBaseLine: {
    ...initialOverlayValue,
    graph: { plot: plotInitial, map: mapInitial },
  },
  log: [],
  correctionUploadedFiles: initialCorrectionUploadedFiles,
  correctionUnknownFilesDelete: false,
};
const OverlayInfo = createSlice({
  name: 'OverlayInfo',
  initialState: initialOverlayState,
  reducers: {
    initialOverlayReducer: () => initialOverlayState,
    UpdateAdcMeasurementCommonInfoReducer: (state, action) => {
      state.adcMeasurement.info = action.payload;
    },
    UpdateCorrectionCommonInfoReducer: (state, action) => {
      state.correction.info = action.payload;
    },
    UpdateOasBaseLineCommonInfoReducer: (state, action) => {
      state.oasBaseLine.info = action.payload;
    },
    UpdateAdcMeasurementInfoReducer: (state, action) => {
      state.adcMeasurement = action.payload;
    },
    UpdateCorrectionInfoReducer: (state, action) => {
      state.correction = action.payload;
    },
    UpdateOasBaseLineInfoReducer: (state, action) => {
      state.oasBaseLine = action.payload;
    },
    UpdateMapGraphSettingReducer: (state, action) => {
      console.log('UpdateMapGraphSettingReducer', action.payload);
      state.adcMeasurement.graph.map = action.payload;
    },
    UpdateAnovaGraphSettingReducer: (state, action) => {
      state.adcMeasurement.graph.anova = action.payload;
    },
    UpdateReproducibilityGraphSettingReducer: (state, action) => {
      state.adcMeasurement.graph.reproducibility = action.payload;
    },
    UpdateVariationGraphSettingReducer: (state, action) => {
      const uValue = getParseData(action.payload);
      const cloneVariation = { ...state.adcMeasurement.graph.variation };
      return {
        ...state,
        adcMeasurement: {
          ...state.adcMeasurement,
          graph: {
            ...state.adcMeasurement.graph,
            variation: { ...cloneVariation, [uValue.id]: uValue.value },
          },
        },
      };
    },
    UpdateCorrectionMapGraphSettingReducer: (state, action) => {
      state.correction.graph = action.payload;
    },
    UpdateOasBaseLinePlotGraphSettingReducer: (state, action) => {
      state.oasBaseLine.graph.plot = action.payload;
    },
    UpdateOasBaseLineMapGraphSettingReducer: (state, action) => {
      console.log('UpdateOasBaseLineMapGraphSettingReducer', action.payload);
      state.oasBaseLine.graph.map = action.payload;
    },

    UpdateLogSettingInfoReducer: (state, action) => {
      state.log = action.payload;
    },
    UpdateCorrectionUploadedFilesReducer: (state, action) => {
      state.correctionUploadedFiles = action.payload;
    },
    UpdateCorrectionUnknownFilesDeleteReducer: (state, action) => {
      state.correctionUnknownFilesDelete = action.payload;
    },
  },
});

//reducer's action
export const {
  initialOverlayReducer,
  UpdateAdcMeasurementInfoReducer,
  UpdateAdcMeasurementCommonInfoReducer,
  UpdateReproducibilityGraphSettingReducer,
  UpdateVariationGraphSettingReducer,
  UpdateCorrectionInfoReducer,
  UpdateCorrectionCommonInfoReducer,
  UpdateAnovaGraphSettingReducer,
  UpdateMapGraphSettingReducer,
  UpdateCorrectionMapGraphSettingReducer,
  UpdateLogSettingInfoReducer,
  UpdateOasBaseLineCommonInfoReducer,
  UpdateOasBaseLineInfoReducer,
  UpdateOasBaseLinePlotGraphSettingReducer,
  UpdateCorrectionUploadedFilesReducer,
  UpdateCorrectionUnknownFilesDeleteReducer,
  UpdateOasBaseLineMapGraphSettingReducer,
} = OverlayInfo.actions;

export const getCorrectionSetting = (state) => state.OverlayInfo.correction;
export const getAdcMeasurementSetting = (state) =>
  state.OverlayInfo.adcMeasurement;
export const getOasBaseLineSetting = (state) => state.OverlayInfo.oasBaseLine;

export const getOverlayLogSetting = (state) => state.OverlayInfo.log;
export const getCorrectionUploadedFiles = (state) =>
  state.OverlayInfo.correctionUploadedFiles;
export const getCorrectionUnknownFilesDelete = (state) =>
  state.OverlayInfo.correctionUnknownFilesDelete;

export default OverlayInfo.reducer;
