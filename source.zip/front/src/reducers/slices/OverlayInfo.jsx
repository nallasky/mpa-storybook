import { createSlice } from '@reduxjs/toolkit';
import { MSG_LOCAL } from '../../lib/api/Define/Message';
import { V_OFF } from '../../lib/api/Define/etc';
import { getParseData } from '../../lib/util/Util';

const initialValue = {
  source: MSG_LOCAL,
  source_info: {
    files_rid: '',
    db: { id: '', name: '' },
  },
  targetInfo: {
    fab_name: '',
    fab_list: [],
    equipment_name: '',
    period: ['', ''],
    selected: ['', ''],
    job: '',
    job_list: [],
    lot_id: [],
    lot_id_list: {},
    mean_dev_diff: [],
    mean_dev_diff_list: [],
    ae_correction: V_OFF,
    stage_correction: [],
    stage_correction_list: {},
    adc_correction: [],
    adc_correction_list: {},
  },
  info: { plate: [], shot: [] },
};
const AdcGraphInitial = {
  adc_map: {},
  variation: {
    x_range_min: 0,
    x_range_max: 0,
    y_range_min: 0,
    y_range_max: 0,
    select_shot: 'all',
  },
  reproducibility: {
    three_sigma_x: 0,
    three_sigma_y: 0,
  },
};
const CorrectionGraphInitial = {
  image: {},
  component: {},
};
const initialState = {
  correction: { ...initialValue, graph: CorrectionGraphInitial },
  adcMeasurement: { ...initialValue, graph: AdcGraphInitial },
};
const OverlayInfo = createSlice({
  name: 'OverlayInfo',
  initialState,
  reducers: {
    initialReducer: () => initialState,
    UpdateAdcMeasurementCommonInfoReducer: (state, action) => {
      state.adcMeasurement.info = action.payload;
    },
    UpdateCorrectionCommonInfoReducer: (state, action) => {
      state.correction.info = action.payload;
    },
    UpdateAdcMeasurementInfoReducer: (state, action) => {
      state.adcMeasurement = action.payload;
    },
    UpdateCorrectionInfoReducer: (state, action) => {
      state.correction = action.payload;
    },
    UpdateReproducibilityGraphSettingReducer: (state, action) => {
      state.adcMeasurement.graph.reproducibility = action.payload;
    },
    UpdateVariationGraphSettingReducer: (state, action) => {
      const uValue = getParseData(action.payload);
      const cloneVariation = { ...state.adcMeasurement.graph.variation };
      return {
        ...state,
        adcMeasurement: {
          ...state.adcMeasurement,
          graph: {
            ...state.adcMeasurement.graph,
            variation: { ...cloneVariation, [uValue.id]: uValue.value },
          },
        },
      };
    },
  },
});

//reducer's action
export const {
  initialReducer: initialOverlay,
  UpdateAdcMeasurementInfoReducer,
  UpdateAdcMeasurementCommonInfoReducer,
  UpdateReproducibilityGraphSettingReducer,
  UpdateVariationGraphSettingReducer,
  UpdateCorrectionInfoReducer,
  UpdateCorrectionCommonInfoReducer,
} = OverlayInfo.actions;

export const getCorrectionSetting = (state) => state.OverlayInfo.correction;
export const getAdcMeasurementSetting = (state) =>
  state.OverlayInfo.adcMeasurement;

export default OverlayInfo.reducer;
