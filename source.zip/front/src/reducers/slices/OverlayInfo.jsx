import { createSlice } from '@reduxjs/toolkit';
import { MSG_LOCAL, MSG_X, MSG_Y } from '../../lib/api/Define/Message';
import { V_OFF } from '../../lib/api/Define/etc';
import { getParseData } from '../../lib/util/Util';
import { CPVS_MODE } from '../../lib/api/Define/OverlayDefault';

const initialValue = {
  source: MSG_LOCAL,
  source_info: {
    files_rid: '',
    db: { id: '', name: '' },
  },
  targetInfo: {
    fab_name: '',
    fab_list: [],
    equipment_name: '',
    equipment_name_list: {},
    period: ['', ''],
    selected: ['', ''],
    job: '',
    job_list: [],
    lot_id: [],
    lot_id_list: {},
    mean_dev_diff: [],
    mean_dev_diff_list: [],
    ae_correction: V_OFF,
    stage_correction: [],
    stage_correction_list: {},
    adc_correction: [],
    adc_correction_list: {},
  },
  info: { plate: [], shot: [], origin: undefined },
};
const AdcGraphInitial = {
  map: {
    column_num: undefined,
    show_extra_info: true,
    div: {
      upper: undefined,
      lower: undefined,
      scale: undefined,
    },
    display_map: {
      min: 1,
      max: 30,
    },
    plate_size: {
      size_x: undefined,
      size_y: undefined,
    },
    offset: {},
    cp_vs: {
      mode: CPVS_MODE.FROM_LOG, //from_log, each, same
      shots: {
        1: {
          cp1: 0,
          cp2: 0,
          cp3: 0,
          vs1: 0,
          vs2: 0,
          v3: 0,
          display: undefined,
        },
      },
      preset: {},
    },
  },
  variation: {
    x_range_min: 0,
    x_range_max: 0,
    y_range_min: 0,
    y_range_max: 0,
    select_shot: 'all',
  },
  reproducibility: {
    three_sigma_x: 0,
    three_sigma_y: 0,
  },
  anova: { list: [MSG_X.toUpperCase(), MSG_Y.toUpperCase()], selected: MSG_X.toUpperCase() },
};
const CorrectionGraphInitial = {
  image: {},
  component: {},
};
const initialState = {
  correction: { ...initialValue, graph: CorrectionGraphInitial },
  adcMeasurement: { ...initialValue, graph: AdcGraphInitial },
};
const OverlayInfo = createSlice({
  name: 'OverlayInfo',
  initialState,
  reducers: {
    initialReducer: () => initialState,
    UpdateAdcMeasurementCommonInfoReducer: (state, action) => {
      state.adcMeasurement.info = action.payload;
    },
    UpdateCorrectionCommonInfoReducer: (state, action) => {
      state.correction.info = action.payload;
    },
    UpdateAdcMeasurementInfoReducer: (state, action) => {
      state.adcMeasurement = action.payload;
    },
    UpdateCorrectionInfoReducer: (state, action) => {
      state.correction = action.payload;
    },
    UpdateMapGraphSettingReducer: (state, action) => {
      console.log('UpdateMapGraphSettingReducer', action.payload);
      state.adcMeasurement.graph.map = action.payload;
    },
    UpdateAnovaGraphSettingReducer: (state, action) => {
      state.adcMeasurement.graph.anova = action.payload;
    },
    UpdateReproducibilityGraphSettingReducer: (state, action) => {
      state.adcMeasurement.graph.reproducibility = action.payload;
    },
    UpdateVariationGraphSettingReducer: (state, action) => {
      const uValue = getParseData(action.payload);
      const cloneVariation = { ...state.adcMeasurement.graph.variation };
      return {
        ...state,
        adcMeasurement: {
          ...state.adcMeasurement,
          graph: {
            ...state.adcMeasurement.graph,
            variation: { ...cloneVariation, [uValue.id]: uValue.value },
          },
        },
      };
    },
  },
});

//reducer's action
export const {
  initialReducer: initialOverlay,
  UpdateAdcMeasurementInfoReducer,
  UpdateAdcMeasurementCommonInfoReducer,
  UpdateReproducibilityGraphSettingReducer,
  UpdateVariationGraphSettingReducer,
  UpdateCorrectionInfoReducer,
  UpdateCorrectionCommonInfoReducer,
  UpdateAnovaGraphSettingReducer,
  UpdateMapGraphSettingReducer,
} = OverlayInfo.actions;

export const getCorrectionSetting = (state) => state.OverlayInfo.correction;
export const getAdcMeasurementSetting = (state) =>
  state.OverlayInfo.adcMeasurement;

export default OverlayInfo.reducer;
