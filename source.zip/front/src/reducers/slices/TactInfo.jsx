import { createSlice } from '@reduxjs/toolkit';
import { getParseData, getParseJsonData } from '../../libs/util/util';
const initialState = {
  settings: {
    plate_tact: [],
    plate_detail_tact: [],
    plate_tact_event: [],
    name_dat: [],
    primary_pu: {},
    reference_pu: [],
  },
};
const TactInfo = createSlice({
  name: 'TactInfo',
  initialState,
  reducers: {
    initialSettingReducer: () => initialState,
    UpdateTactALLSettingReducer: (state, action) => {
      const pData = getParseJsonData(action.payload);
      state.settings = pData.reduce((acc, obj) => {
        if (Array.isArray(obj.value)) {
          Object.assign(acc, {
            [obj.id]: obj.value.map((obj2, idx) => ({
              ...obj2,
              index: idx,
            })),
          });
        } else {
          const obj2 = getParseJsonData(obj.value);
          Object.assign(acc, {
            [obj.id]: obj2.reduce(
              (acc, obj3) =>
                Object.assign(acc, {
                  [obj3.id]: obj3.value.map((obj4, idx) => ({
                    ...obj4,
                    index: idx,
                  })),
                }),
              {},
            ),
          });
        }
        return acc;
      }, {});
    },
    UpdateTactSettingReducer: (state, action) => {
      const data = getParseData(action.payload);
      state.settings[data.id] = data.value.map((obj, idx) => ({
        ...obj,
        index: idx,
      }));
    },
  },
});

//reducer's action
export const {
  initialSettingReducer: initialSettingAction,
  UpdateTactSettingReducer,
  UpdateTactALLSettingReducer,
} = TactInfo.actions;
export const getTactSetting = (state) => state.TactInfo.settings;
export default TactInfo.reducer;
