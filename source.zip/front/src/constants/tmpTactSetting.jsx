export const PlateTact = [
  {
    id: 1,
    display_order: 1,
    classification: 'step',
  },
  {
    id: 2,
    display_order: 2,
    classification: 'Measurement',
  },
  {
    id: 3,
    display_order: 3,
    classification: 'Cailbration',
  },
  {
    id: 4,
    display_order: 4,
    classification: 'Exposure',
  },
];
export const PlateTactEvent = [
  {
    id: 1,
    event: '1st Shot Expo End',
  },
  {
    id: 2,
    event: 'AAR Fine Tuning End',
  },
  {
    id: 3,
    event: 'AAR Fine Tuning Start',
  },
  {
    id: 4,
    event: 'AAR Pre Tuning End',
  },
  {
    id: 5,
    event: 'AAR Pre Tuning Start',
  },
];
export const PlateDetailTact = [
  {
    id: 1,
    event: '1st Shot Expo',
    start: '1st Shot Expo start',
    End: '1st Shot Expo End',
    classification: 'Exposure',
    display: true,
  },
  {
    id: 2,
    event: 'AAR Fine Tuning',
    start: 'AAR Fine Tunning Start',
    End: 'AAR Fin Tuning End',
    classification: 'Cailbration',
    display: true,
  },
  {
    id: 3,
    event: 'AFC',
    start: 'AFC Start',
    End: 'AFC End',
    classification: 'Measurement',
    display: false,
  },
  {
    id: 4,
    event: 'AAR Pre Tuning',
    start: 'AAR Pre Tuning Start',
    End: 'AAR Pre Tuning End',
    classification: 'Cailbration ',
    display: true,
  },
];
export const Name_data = [
  {
    id: 1,
    PUID: '10000',
    Name: 'MAINユニット・ウォーミング・アップ',
  },
  {
    id: 2,
    PUID: '10001',
    Name: 'MAINユニット・アラーム・チェック',
  },
  {
    id: 3,
    PUID: '10002',
    Name: 'MAINユニット・ワーニング・チェック',
  },
];
export const primary_pu = {
  primary_pu_1: [
    {
      id: 1,
      PUID: '1211C',
      Name: 'マスク処理',
      Level: 0,
    },
    {
      id: 2,
      PUID: '2006F',
      Name: 'ＡＦＣ計測位置移動',
      Level: 1,
    },
  ],
  primary_pu_2: [],
};
export const ref_pu = [
  {
    id: 1,
    PUID: '1211C',
    primary_pu: 'primary_pu_1',
  },
];
export const tact_setting = {
  plate_tact: PlateTact,
  plate_event: PlateTactEvent,
  plate_detail: PlateDetailTact,
  name_data: Name_data,
  primary_pu: primary_pu,
  ref_pu: ref_pu,
};

export const tact_status_target = {
  period: ['2020-11-16 00:00:13', '2020-11-26 23:59:58'],
  job: [
    '425B03A1/1LAA2EE',
    '315A07A1/1LAA1EE',
    '546B0DLS/1LDB2EE',
    '547B0DLS/7LDB2AE',
    '548B0DLS/5LDB2XE',
    '549B0DLS/4LDB2QE',
  ],
};

export const tact_status_job = {
  '315A07A1/1LAA1EE': {
    lot: {
      lot_id: [], // 해당job의 lot_id 리스트
      lot_id_block: [], //해당job의 lot_id_block리스트
      calc: [1, 2, 3, 4, 5, 15], //lot별 tact계산값
    },
    plate: {
      lot_id_block1: {
        //lot_id_block명칭
        lot_id: '0000000', //없으면 null
        plate_no: [], //
        adc_fdc: [true, false], //adc 데이터의 경우 true, fdc데이터의 경우 false
        calc: [1, 2], //plate별 tact계산값
      },
      lot_id_block2: {
        adc_fdc: [true, true, true, false],
        calc: [3, 4, 5, 6],
      },
    },
  },
  '425B03A1/1LAA2EE': {
    lot: {
      lot_id: [],
      lot_id_block: [],
      calc: [5, 6, 7, 8, 9],
    },
    plate: {
      lot_id_block1: {
        adc_fdc: [false, true, true],
        calc: [10, 11, 12],
      },
    },
  },
};
