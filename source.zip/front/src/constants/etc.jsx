export const V_ON = 'on';
export const V_OFF = 'off';
export const R_OK = 200;
export const RESPONSE_OK = '200';
export const RESPONSE_NG = '400';
export const DATE_FORMAT = 'YYYY-MM-DD HH:mm:ss';
export const E_STEP_1 = 0;
export const E_STEP_2 = 1;
export const E_STEP_2_1 = 2;
export const E_STEP_MULTI_2 = 3;
export const E_STEP_3 = 4;
export const E_STEP_MULTI_3 = 5;
export const E_STEP_4 = 6;
export const E_STEP_MULTI_4 = 7;
export const E_STEP_5 = 8;
export const E_STEP_6 = 9;
export const E_STEP_7 = 10;
export const E_JOB_STEP_END = 999;
export const E_LOG_STEP_END = 1000;
export const E_STEP_TITLE_SETTING = E_STEP_1;
export const E_STEP_FUNC_SELECT_SETTING = E_STEP_MULTI_2;
export const E_STEP_LOG_DEFINE_SETTING = E_STEP_2_1;
export const E_STEP_LOG_SELECT_SETTING = E_STEP_2;
export const E_STEP_LOG_CONVERT_SETTING = E_STEP_3;
export const E_STEP_FILTER_SETTING = E_STEP_4;
export const E_STEP_ANALYSIS_SETTING = E_STEP_5;
export const E_STEP_MULTI_ANALYSIS_SETTING = E_STEP_MULTI_3;
export const E_STEP_VISUAL_SETTING = E_STEP_6;
export const E_STEP_MULTI_VISUAL_SETTING = E_STEP_MULTI_4;
export const E_STEP_PATTERN_SETTING = E_STEP_7;
export const E_STEP_2_PREVIEW_LINE = 30;

export const LOCAL_INFO = 'local';
export const REMOTE_INFO = 'remote';
export const SQL_INFO = 'sql';
export const HISTORY_INFO = 'history';
export const TABLE_INFO = 'table';
export const E_SINGLE_TYPE = 'single';
export const E_MULTI_TYPE = 'multi';

export const OVERLAY_ADC_CATEGORY = 'ADCMEASUREMENT';
export const OVERLAY_CORRECTION_CATEGORY = 'correction';
export const OVERLAY_OAS_BASELINE_CATEGORY = 'OASBASELINEMEASUREMENTMONITOR';
export const E_OVERLAY_GRAPH_ALL = 'all';
export const E_OVERLAY_MAP = 'map';
export const E_OVERLAY_PLOT = 'plot';
export const E_OVERLAY_VARIATION = 'variation';
export const E_OVERLAY_REPRODUCIBILITY = 'reproducibility';
export const E_OVERLAY_ANOVA = 'anova';
export const E_OVERLAY_IMAGE = 'image';
export const E_OVERLAY_COMPONENT = 'component';
export const E_CPVS_ADC_MEASUREMENT = 'adc_measurement';
export const E_CPVS_CORRECTION = 'correction';
export const E_CPVS_BASELINE = 'baseline';

export const OVERLAY_ADC_MEASUREMENT_LOG = 'ADCMEASUREMENT';
export const OVERLAY_MACHINE_LOG = 'machine';
export const OVERLAY_OASBASELINE_LOG = 'OASBASELINEMEASUREMENTMONITOR';

export const E_New = 'New';
export const E_Default = 'Default';

export const E_TACT_SETTING_ALL = 'all';
export const E_TACT_SETTING_PLATE = 'plate_tact';
export const E_TACT_SETTING_PLATE_DETAIL = 'plate_detail';
export const E_TACT_SETTING_PLATE_EVENT = 'plate_event';
export const E_TACT_SETTING_NAME_DAT = 'name_data';
export const E_TACT_SETTING_PRIMARY_PU = 'primary_PU_Setting';
export const E_TACT_SETTING_PRIMARY_PU_SETTING = 'primary_pu';
export const E_TACT_SETTING_REFERENCE_PU = 'ref_pu';
export const E_TACT_SETTING_PAGE_INFO = 'page_info';

export const E_TACT_STATUS_JOB_TACT = 'job_tact';
export const E_TACT_STATUS_PLATE_TACT = 'plate_tact';
export const E_TACT_STATUS_PLATE_TACT_DIFF = 'plate_tact_diff';
export const E_TACT_STATUS_PREDICT_TACT = 'predict';
export const E_TACT_STATUS_PLATE_DETAIL_TACT = 'plate_detail_tact';
export const E_TACT_STATUS_PLATE_DETAIL_TACT_DIFF = 'plate_detail_tact_diff';

export const E_TACT_MEMORY_DOWNLOADED = 'import';
export const E_TACT_MEMORY_LOG_SERVER = 'logserver';
export const E_TACT_MEMORY_COPY_FILES = 'copy';

export const E_TACT_GRAPH_UNIT_LOT = 'lot';
export const E_TACT_GRAPH_UNIT_PLATE = 'plate';

export const E_TACT_GRAPH_ADC_FDC_ALL = 'ALL';
export const E_TACT_GRAPH_ADC = 'ADC';
export const E_TACT_GRAPH_FDC = 'FDC';

export const E_TACT_GRAPH_TYPE_THROUGHPUT = 'Throughput';
export const E_TACT_GRAPH_TYPE_WORKING = 'Working';
export const E_TACT_GRAPH_TYPE_WAITING = 'Waiting';

export const E_TACT_GRAPH_JOB_SCRIPT = 'job_tact';
export const E_TACT_GRAPH_PLATE_SCRIPT = 'plate_tact';
export const E_TACT_GRAPH_PLATE_DIFF_SCRIPT = 'plate_tact_diff';
export const E_TACT_GRAPH_PLATE_DETAIL_SCRIPT = 'plate_detail_tact';
export const E_TACT_GRAPH_PLATE_DETAIL_DIFF_SCRIPT = 'plate_detail_tact_diff';
export const E_TACT_GRAPH_MEMORY_DUMP_SCRIPT = 'memory_dump';

export const E_TACT_GRAPH_COLOR_JOB = 'job_tact';
export const E_TACT_GRAPH_COLOR_PLATE = 'plate_tact';
export const E_TACT_GRAPH_COLOR_PREDICT = 'predict';
export const E_TACT_GRAPH_COLOR_DIFFERENCE = 'difference';
export const E_TACT_GRAPH_COLOR_PLATE_DETAIL = 'plate_detail_color';
