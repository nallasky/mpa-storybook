export const SLICE = '/';
export const HOME = SLICE;
export const MAIN = 'main';
export const CONFIGURATION = 'configuration';
export const ANALYSIS = 'job';
export const TACT = 'tact';
export const PROCESS = SLICE + 'process';
export const SETTINGS = 'settings';
export const OVERLAY = 'overlay';
export const STATUS_MONITOR = 'status';
export const CORRECTION = 'correction';
export const NEW = 'new';
export const NEW_LOG = 'new-log';
export const NEW_RULE = 'new-rule';
export const EDIT_RULE = 'edit-rule';
export const EDIT = 'edit';
export const FOCUS = 'focus';
export const OAS_BASELINE = 'oas-baseline';
export const LOG = 'log-setting';
export const LOG_DEFINE = 'log';
export const PRESCAN_COE = 'prescan_coe';

export const ADC_MEASUREMENT = 'adc';
export const MEMORY_DUMP = 'memory';
export const QUICK = 'quick';
export const COMMON_LOG = 'common';
export const INFO = 'info';

export const URL_MAIN = SLICE + MAIN;
export const URL_JOB_ANALYSIS = MAIN + SLICE + ANALYSIS;
export const URL_NEW = MAIN + SLICE + NEW;
export const URL_EDIT = MAIN + SLICE + EDIT;
export const URL_CONFIG_SETTING = MAIN + SLICE + CONFIGURATION;
export const URL_ANALYSIS_FUNCTION = MAIN + SLICE + COMMON_LOG;

export const URL_COMMON_LOG = SLICE + COMMON_LOG;
export const URL_COMMON_LOG_NEW = URL_COMMON_LOG + SLICE + NEW;
export const URL_COMMON_LOG_EDIT = URL_COMMON_LOG + SLICE + EDIT;

export const URL_OVERLAY = SLICE + OVERLAY;
export const OVERLAY_ADC_MEASUREMENT = OVERLAY + SLICE + ADC_MEASUREMENT;
export const OVERLAY_CORRECTION = OVERLAY + SLICE + CORRECTION;
export const OVERLAY_OAS_BASELINE = OVERLAY + SLICE + OAS_BASELINE;
export const OVERLAY_LOG_SETTING = OVERLAY + SLICE + LOG;

export const URL_TACT = SLICE + TACT;
export const TACT_SETTING = TACT + SLICE + SETTINGS;
export const TACT_STATUS_MONITOR = TACT + SLICE + STATUS_MONITOR;
export const TACT_MEMORY_DUMP = TACT + SLICE + MEMORY_DUMP;
export const TACT_LOG_SETTING = TACT + SLICE + LOG;
export const TACT_ANALYSIS_SETTING = TACT + SLICE + SETTINGS;

export const FOCUS_ANALYSIS = FOCUS + SLICE + ANALYSIS;
export const FOCUS_LOG_SETTING = FOCUS + SLICE + LOG;
export const FOCUS_PRESCAN_COE = FOCUS + SLICE + PRESCAN_COE;

export const URL_RESOURCE = '/api/resources';
export const URL_RESOURCE_MAIN = URL_RESOURCE + '/main';
export const URL_RESOURCE_ABOUT = URL_RESOURCE + '/about';
export const URL_RESOURCE_FUNC = URL_RESOURCE + '/func';
export const URL_RESOURCE_COMMON = URL_RESOURCE + '/common';
export const URL_RESOURCE_SETTING = URL_RESOURCE + SLICE + SETTINGS;
export const URL_RESOURCE_HISTORY_SETTING = URL_RESOURCE_SETTING + '/history';
export const URL_RESOURCE_RULE = URL_RESOURCE + '/rule';
export const URL_RESOURCE_SCRIPT = URL_RESOURCE + '/scripts';
export const URL_RESOURCE_LOG_SETTING = URL_RESOURCE + '/log-setting';

export const URL_RESOURCE_SETTING_DATE = URL_RESOURCE_SETTING + '/date';

export const URL_RESOURCE_COMMON_CATEGORY = URL_RESOURCE_COMMON + '/category';

export const URL_RESOURCE_REMOTE = URL_RESOURCE + '/remote';
export const URL_RESOURCE_REMOTE_TABLE = URL_RESOURCE_REMOTE + '/tables';
export const URL_RESOURCE_REMOTE_EQUIPMENTS =
  URL_RESOURCE_REMOTE + '/equipments';
export const URL_RESOURCE_REMOTE_VALID_DATE = URL_RESOURCE_REMOTE + '/date';

//NEXT BUTTON CLICK
export const URL_RESOURCE_NEW = URL_RESOURCE + '/new';
export const URL_RESOURCE_NEW_INIT = URL_RESOURCE_NEW + '/step1';
export const URL_RESOURCE_NEW_STEP1 = URL_RESOURCE_NEW + '/step2';
export const URL_RESOURCE_NEW_STEP2 = URL_RESOURCE_NEW + '/step3';
export const URL_RESOURCE_NEW_STEP3 = URL_RESOURCE_NEW + '/step4';
export const URL_RESOURCE_NEW_STEP4 = URL_RESOURCE_NEW + '/step5';
export const URL_RESOURCE_NEW_STEP5 = URL_RESOURCE_NEW + '/step6';

export const URL_RESOURCE_STEP2_MULTI_SETTING =
  URL_RESOURCE_NEW + '/step2' + SLICE + SETTINGS;

export const URL_RESOURCE_EDIT = URL_RESOURCE + '/edit';
export const URL_RESOURCE_EDIT_INIT = URL_RESOURCE_EDIT + '/step1';
export const URL_RESOURCE_EDIT_STEP1 = URL_RESOURCE_EDIT + '/step2';
export const URL_RESOURCE_EDIT_STEP2 = URL_RESOURCE_EDIT + '/step3';
export const URL_RESOURCE_EDIT_STEP3 = URL_RESOURCE_EDIT + '/step4';
export const URL_RESOURCE_EDIT_STEP4 = URL_RESOURCE_EDIT + '/step5';
export const URL_RESOURCE_EDIT_STEP5 = URL_RESOURCE_EDIT + '/step6';
export const URL_RESOURCE_EDIT_STEP6 = URL_RESOURCE_EDIT + '/step7';

//PREVIEW BUTTON CLICK
export const URL_API_PREVIEW = '/api/preview';
export const URL_PREVIEW_SAMPLELOG = URL_API_PREVIEW + '/samplelog';
export const URL_PREVIEW_SAMPLELOG_MULTI = URL_PREVIEW_SAMPLELOG + '/multi';
export const URL_PREVIEW_CONVERT = URL_API_PREVIEW + '/convert';
export const URL_PREVIEW_FILTER = URL_API_PREVIEW + '/filter';
export const URL_PREVIEW_ANALYSIS = URL_API_PREVIEW + '/analysis';
export const URL_PREVIEW_ANALYSIS_MULTI = URL_PREVIEW_ANALYSIS + '/multi';
export const URL_PREVIEW_CONVERTED = URL_API_PREVIEW + '/converted';
export const URL_PREVIEW_SQL = URL_API_PREVIEW + '/sql';

export const URL_API_CONVERTER = '/api/converter';
export const URL_CONVERTER_JOB = URL_API_CONVERTER + '/job';
export const URL_CONVERTER_FILE = URL_API_CONVERTER + '/file';

export const URL_API_ANALYSIS = '/api/analysis';
export const URL_ANALYSIS_LOCAL = URL_API_ANALYSIS + '/local';
export const URL_ANALYSIS_REMOTE = URL_API_ANALYSIS + '/remote';
export const URL_ANALYSIS_SQL = URL_API_ANALYSIS + '/sql';
export const URL_ANALYSIS_HISTORY = URL_API_ANALYSIS + '/history';

export const URL_ANALYSIS_DEFAULT = URL_API_ANALYSIS + '/default';
export const URL_ANALYSIS_DEFAULT_MULTI = URL_ANALYSIS_DEFAULT + '/multi';

export const URL_SETTING_MGMT = '/api/setting';
export const URL_SETTING_GET_LOCAL = URL_SETTING_MGMT + '/local';
export const URL_SETTING_GET_REMOTE = URL_SETTING_MGMT + '/remote';
export const URL_SETTING_GET_TABLES = URL_SETTING_MGMT + '/tables';
export const URL_SETTING_CHECK_DB_CONNECTION =
  URL_SETTING_MGMT + '/connection-check';

export const URL_SETTING = '/api/setting';
export const URL_SETTING_REMOTE = URL_SETTING + '/remote';
export const URL_SETTING_LOCAL = URL_SETTING + '/local';
export const URL_SETTING_LOG_PATTERN = URL_SETTING + '/log-pattern';
export const URL_SETTING_COLUMN_DEFINE = URL_SETTING + '/column-define';
export const URL_SETTING_LOG_DEFINE = URL_SETTING + '/log-define';

export const URL_SETTING_LOG_DEFINE_NEW = URL_SETTING_LOG_DEFINE + '/new';
export const URL_SETTING_LOG_DEFINE_NEW_STEP1 =
  URL_SETTING_LOG_DEFINE_NEW + '/step1';
export const URL_SETTING_LOG_DEFINE_NEW_STEP2 =
  URL_SETTING_LOG_DEFINE_NEW + '/step2';

export const URL_SETTING_LOG_DEFINE_EDIT = URL_SETTING_LOG_DEFINE + '/edit';
export const URL_SETTING_LOG_DEFINE_EDIT_STEP1 =
  URL_SETTING_LOG_DEFINE_EDIT + '/step1';
export const URL_SETTING_LOG_DEFINE_EDIT_STEP2 =
  URL_SETTING_LOG_DEFINE_EDIT + '/step2';

export const URL_SETTING_LOG_DEFINE_RULE = URL_SETTING_LOG_DEFINE + '/rule';
export const URL_SETTING_LOG_DEFINE_LOG = URL_SETTING_LOG_DEFINE;

export const URL_IMPORT = '/api/import';
export const URL_IMPORT_LOG_DEFINE = URL_IMPORT + '/rules';
export const URL_IMPORT_FUNCTIONS = URL_IMPORT + '/function';

export const URL_EXPORT = '/api/export';
export const URL_EXPORT_LOG_DEFINE = URL_EXPORT + '/rules';
export const URL_EXPORT_FUNCTIONS = URL_EXPORT + '/function';
export const URL_EXPORT_OVERLAY = URL_EXPORT + '/overlay';
export const URL_EXPORT_TACT = URL_EXPORT + '/tact';
export const URL_EXPORT_TACT_STATUS = URL_EXPORT_TACT + '/statusmonitor';

export const URL_API_OVERLAY = '/api/overlay';
export const URL_OVERLAY_CONVERT = URL_API_OVERLAY + '/convert';
export const URL_OVERLAY_CONVERT_STATUS = URL_API_OVERLAY + '/status';
export const URL_OVERLAY_REMOTE = URL_API_OVERLAY + '/remote';
export const URL_OVERLAY_REMOTE_EQUIPMENT = URL_OVERLAY_REMOTE + '/equipments';
export const URL_OVERLAY_EQUIPMENT_INFO = `${URL_OVERLAY_REMOTE}/info`;
export const URL_OVERLAY_SETTING_INFO = `${URL_API_OVERLAY}/setting`;
export const URL_OVERLAY_ANALYSIS_INFO = `${URL_API_OVERLAY}/info`;
export const URL_OVERLAY_GRAPH_INFO = `${URL_OVERLAY_ANALYSIS_INFO}/graph`;
export const URL_OVERLAY_PLATE_INFO = `${URL_OVERLAY_ANALYSIS_INFO}/plate`;
export const URL_OVERLAY_ANALYSIS = `${URL_API_OVERLAY}/analysis`;
export const URL_OVERLAY_ETC = URL_API_OVERLAY + '/etc';
export const URL_OVERLAY_CPVS = URL_API_OVERLAY + '/cpvs';
export const URL_OVERLAY_CPVS_LOAD = URL_OVERLAY_CPVS + '/load';

export const URL_API_TACT = '/api/tact';
export const URL_TACT_SETTING = URL_API_TACT + '/settings';
export const URL_TACT_SETTING_DOWNLOAD = URL_TACT_SETTING + '/download';
export const URL_TACT_SETTING_IMPORT = URL_TACT_SETTING + '/import';
export const URL_TACT_SETTING_PREVIEW = URL_TACT_SETTING + '/preview';

export const URL_TACT_STATUS_MONITOR = URL_API_TACT + '/statusmonitor';
export const URL_TACT_STATUS_MONITOR_LOG_CONVERT =
  URL_TACT_STATUS_MONITOR + '/convert';
export const URL_TACT_STATUS_MONITOR_LOG_CONVERT_STATUS =
  URL_TACT_STATUS_MONITOR + '/status';
export const URL_TACT_STATUS_MONITOR_INFO = URL_TACT_STATUS_MONITOR + '/info';
export const URL_TACT_STATUS_MONITOR_INFO_JOB =
  URL_TACT_STATUS_MONITOR_INFO + '/job';

export const URL_TACT_STATUS_MONITOR_JOB = URL_TACT_STATUS_MONITOR + '/job';
export const URL_TACT_STATUS_MONITOR_JOB_INFO =
  URL_TACT_STATUS_MONITOR_JOB + '/info';

export const URL_TACT_STATUS_MONITOR_ANALYSIS =
  URL_TACT_STATUS_MONITOR + '/analysis';
export const URL_TACT_STATUS_MONITOR_ANALYSIS_JOB =
  URL_TACT_STATUS_MONITOR_ANALYSIS + '/job-tact';
export const URL_TACT_STATUS_MONITOR_ANALYSIS_PLATE =
  URL_TACT_STATUS_MONITOR_ANALYSIS + '/plate-tact';
export const URL_TACT_STATUS_MONITOR_ANALYSIS_PLATE_DETAIL =
  URL_TACT_STATUS_MONITOR_ANALYSIS + '/plate-detail-tact';

export const URL_TACT_MEMORY_DUMP = URL_API_TACT + '/tsmemory';
export const URL_TACT_MEMORY_DUMP_CONVERT = URL_TACT_MEMORY_DUMP + '/convert';
export const URL_TACT_MEMORY_DUMP_CONVERT_STATUS =
  URL_TACT_MEMORY_DUMP + '/status';
export const URL_TACT_MEMORY_DUMP_ANALYSIS = URL_TACT_MEMORY_DUMP + '/analysis';
export const URL_TACT_MEMORY_DUMP_DOWNLOAD = URL_TACT_MEMORY_DUMP + '/download';

export const URL_API_FOCUS = '/api/focus';
export const URL_FOCUS_INFO = URL_API_FOCUS + '/info';
export const URL_FOCUS_LOT_ID_INFO = URL_FOCUS_INFO + '/lot-id';
export const URL_FOCUS_FILE_CONVERT = URL_API_FOCUS + '/convert';
export const URL_FOCUS_FILE_CONVERT_STATUS = URL_API_FOCUS + '/status';
export const URL_FOCUS_SETTING = URL_API_FOCUS + '/setting';
export const URL_FOCUS_ANALYSIS = URL_API_FOCUS + '/analysis';
export const URL_FOCUS_FILE_EXPORT = '/api/export/focus';
export const URL_FOCUS_SAVE_SCALE = URL_FOCUS_SETTING + '/graph-scale';
export const URL_FOCUS_SAVE_COLOR = URL_FOCUS_SETTING + '/color';
