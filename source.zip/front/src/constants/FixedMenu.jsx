import {
  OVERLAY_ADC_MEASUREMENT,
  OVERLAY_CORRECTION,
  TACT_MEMORY_DUMP,
  TACT_SETTING,
  TACT_STATUS_MONITOR,
} from './URL';
import PushpinOutlined from '@ant-design/icons/lib/icons/PushpinOutlined';
import React from 'react';
import { MSG_TACT, MSG_TACT_SETTING } from './Message';

export const fixedTopMenu = [
  {
    category_id: 0,
    title: 'Quick Mode',
    func: [
      {
        func_id: undefined,
        info: undefined,
        title: 'Quick Viewer',
      },
    ],
  },
  {
    category_id: 1,
    title: 'OVERLAY',
    func: [
      {
        func_id: OVERLAY_ADC_MEASUREMENT,
        info: undefined,
        title: 'Overlay \n ADC Meas.',
      },
      {
        func_id: OVERLAY_CORRECTION,
        info: undefined,
        title: 'Overlay \n Correction Comp.',
      },
    ],
  },
  {
    category_id: 2,
    title: MSG_TACT,
    func: [
      {
        func_id: TACT_STATUS_MONITOR,
        info: undefined,
        title: 'TACT \n Status Monitor',
      },
      {
        func_id: TACT_MEMORY_DUMP,
        info: undefined,
        title: 'TACT \n TS Memory Dump',
      },
      {
        func_id: TACT_SETTING,
        info: undefined,
        title: MSG_TACT_SETTING,
      },
    ],
  },
];

export const FixedIcon = (
  <PushpinOutlined
    style={{
      fontSize: '30px',
      display: 'flex',
      alignItems: 'center',
    }}
  />
);
