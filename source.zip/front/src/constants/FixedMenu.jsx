import {
  OVERLAY,
  COMMON_LOG,
  OVERLAY_CORRECTION,
  OVERLAY_ADC_MEASUREMENT,
  OVERLAY_OAS_BASELINE,
  TACT_MEMORY_DUMP,
  TACT_STATUS_MONITOR,
  TACT,
  TACT_ANALYSIS_SETTING,
  OVERLAY_LOG_SETTING,
  TACT_LOG_SETTING,
  FOCUS,
  FOCUS_ANALYSIS,
  FOCUS_LOG_SETTING,
  FOCUS_PRESCAN_COE,
} from './URL';
import {
  DotChartOutlined,
  BarChartOutlined,
  SettingOutlined,
} from '@ant-design/icons/lib/icons';
import React from 'react';
import { Main as message } from '@assets/locale/en';
import QuickView from '@components/QuickView/QuickView';

export const fixedTopMenu = {
  quick: {
    title: message.service.quick.title,
    func_id: undefined,
    children: undefined,
    component: QuickView,
  },
  log: {
    title: message.service.log.title,
    func_id: COMMON_LOG,
    children: undefined,
    component: undefined,
  },
  tact: {
    title: message.service.tact.title,
    func_id: TACT,
    children: [
      {
        func_id: TACT_STATUS_MONITOR,
        icon: <DotChartOutlined className="icon" />,
        title: message.service.tact.children.status,
      },
      {
        func_id: TACT_MEMORY_DUMP,
        icon: <BarChartOutlined className="icon" />,
        title: message.service.tact.children.memory,
      },
      {
        func_id: TACT_ANALYSIS_SETTING,
        icon: <SettingOutlined className="icon" />,
        title: message.service.tact.children.tact_analysis_settings,
      },
      {
        func_id: TACT_LOG_SETTING,
        icon: <SettingOutlined className="icon" />,
        title: message.service.tact.children.log,
      },
    ],
    component: undefined,
  },
  overlay: {
    title: message.service.overlay.title,
    func_id: OVERLAY,
    children: [
      {
        func_id: OVERLAY_ADC_MEASUREMENT,
        icon: <DotChartOutlined className="icon" />,
        title: message.service.overlay.children.adc,
      },
      {
        func_id: OVERLAY_CORRECTION,
        icon: <BarChartOutlined className="icon" />,
        title: message.service.overlay.children.correction,
      },
      {
        func_id: OVERLAY_OAS_BASELINE,
        icon: <BarChartOutlined className="icon" />,
        title: message.service.overlay.children.oas_baseline,
      },
      {
        func_id: OVERLAY_LOG_SETTING,
        icon: <SettingOutlined className="icon" />,
        title: message.service.overlay.children.log,
      },
    ],
    component: undefined,
  },
  Focus: {
    title: message.service.focus.title,
    func_id: FOCUS,
    children: [
      {
        func_id: FOCUS_ANALYSIS,
        icon: <BarChartOutlined className="icon" />,
        title: message.service.focus.children.analysis,
      },
      {
        func_id: FOCUS_LOG_SETTING,
        icon: <SettingOutlined className="icon" />,
        title: message.service.focus.children.log,
      },
      {
        func_id: FOCUS_PRESCAN_COE,
        icon: <BarChartOutlined className="icon" />,
        title: message.service.focus.children.prescan_coe,
      },
    ],
    component: undefined,
  },
};
