const db_name_item = {
  target: 'name',
  type: 'input',
  title: 'Name',
  content: '',
};
const defaultDBSetting = [
  { target: 'host', type: 'input', title: 'Host', content: '' },
  { target: 'port', type: 'input', title: 'Port', content: '' },
  {
    target: 'username',
    type: 'input',
    title: 'UserName',
    content: '',
  },
  {
    target: 'dbname',
    type: 'input',
    title: 'DBName',
    content: '',
  },
  {
    target: 'password',
    type: 'password',
    title: 'Password',
    content: '',
  },
];
export const remote_setting = {
  items: [db_name_item, ...defaultDBSetting],
};
export const local_setting = {
  items: defaultDBSetting,
};
