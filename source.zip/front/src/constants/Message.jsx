//--------COMMON-------------------------------------------------
export const MSG_HOME = 'Home';
export const MSG_LOCAL = 'local';
export const MSG_REMOTE = 'remote';
export const MSG_SQL = 'sql';
export const MSG_MULTI = 'multi';
export const MSG_SAVE_SETTING = 'Save Setting';
export const MSG_CANCEL = 'Cancel';
export const MSG_DOWNLOAD = 'Download';
export const MSG_DEFAULT = 'Default';
export const MSG_APPLY = 'Apply';
export const MSG_RESET = 'Reset';
export const MSG_SAVE = 'Save';
export const MSG_EDIT = 'Edit';
export const MSG_RE_START = 'Re-Start';
export const MSG_ALL = 'All';
export const MSG_PRESET = 'Preset';
export const MSG_SAVE_PRESET = 'Save Preset';
export const MSG_NEW_PRESET = 'New Preset';
export const MSG_UPDATE_PRESET = 'Update Preset';
export const MSG_MAX = 'Max';
export const MSG_MIN = 'Min';

//--------MANAGEMENT-------------------------------------------------

export const MSG_CONFIRM_CANCEL = 'Sure to cancel?';
export const MSG_CONFIRM_DELETE = 'Sure to delete?';

//--------ANALYSIS-------------------------------------------------
export const MSG_ANALYSIS = 'Analysis';

//--------JOBSTEP-------------------------------------------------

export const MSG_PREVIEW = 'Preview';
export const MSG_NEXT = 'Next';
export const MSG_PREVIOUS = 'Previous';

export const MSG_PREVIOUS_TABLE = 'Previous Preview TABLE';
export const MSG_UPLOAD_SCRIPT = 'upload script';
export const MSG_PROGRESS = 'In Progress';
export const MSG_WAITING = 'Waiting';
export const MSG_FINISHED = 'Finished';
export const MSG_CUSTOM_STEP1 = 'Title Setting';
export const MSG_CUSTOM_STEP2 = 'Select Log Data';
export const MSG_CUSTOM_STEP3 = 'Define Headers & Columns';
export const MSG_CUSTOM_STEP4 = 'Define Data Filter';
export const MSG_CUSTOM_STEP5 = 'Analysis Setting';
export const MSG_CUSTOM_STEP6 = 'Visualization Setting';

export const MSG_STEP1_CATEGORY = 'Category';
export const MSG_STEP1_MAIN_TITLE = 'Main Title';
export const MSG_STEP1_SUB_TITLE = 'Sub Title';

export const MSG_STEP3_LOG_DEFINE = 'Log Define';
export const MSG_STEP3_SELECT = 'Select Headers and Columns';
export const MSG_STEP3_DEFINE = 'Headers/Columns Define';
export const MSG_STEP3_INFO = 'Info';
export const MSG_STEP3_HEADERS = 'Headers';
export const MSG_STEP3_CUSTOM = 'Custom Columns';
export const MSG_STEP3_CONVERT_SCRIPT = 'Select Convert Script';
export const MSG_REQUIRED_TOOLTIP = 'This is a required field';

export const MSG_STEP4_FILTER = 'Filter Setting';
export const MSG_STEP4_SHOW_ORIGINAL = 'Show Original Log Data';

export const MSG_STEP5_ANALYSIS = 'Analysis Setting';
export const MSG_STEP5_AGGREGATION = 'Aggregation By ';

export const MSG_ADD_DATABASE = 'Add Database';
export const MSG_ADD_NEW = 'Add New..';
export const MSG_DISABLE = 'disabled';

export const MSG_TABLE_TITLE_INDEX = 'Index';
export const MSG_TABLE_TITLE_ROW = 'Row';
export const MSG_TABLE_TITLE_SOURCE_COLUMN = 'Source Column';
export const MSG_TABLE_TITLE_DATA = 'Data';
export const MSG_TABLE_TITLE_NAME = 'Name';
export const MSG_TABLE_TITLE_OUTPUT = 'Output Column';
export const MSG_TABLE_TITLE_TYPE = 'Type';
export const MSG_TABLE_TITLE_DEFAULT = 'Default Value';
export const MSG_TABLE_TITLE_COEFFICIENT = 'Coefficient';
export const MSG_TABLE_TITLE_UNIT = 'Unit';
export const MSG_TABLE_TITLE_DISP_ORDER = 'Disp.Order';
export const MSG_TABLE_TITLE_TILE = 'Title';
export const MSG_TABLE_TITLE_GROUP = 'Group Analysis';
export const MSG_TABLE_TITLE_TOTAL = 'Total Analysis';

export const MSG_TABLE_TITLE_FILTER_NAME = 'Filter Name';
export const MSG_TABLE_TITLE_FILTER_TYPE = 'Filter Type';
export const MSG_TABLE_TITLE_FILTER_CONDITION = 'Condition';

export const MSG_TABLE_TITLE_DELETE = 'Delete';
export const MSG_TABLE_TITLE_SKIP = 'Skip';

//--------OVERLAY-------------------------------------------------

// Reproducibility

//--------TACT-------------------------------------------------
export const MESSAGE = {
  /*
  #=========================================#
  | COMMON                                  |
  #=========================================#
  */
  HOME: 'Home',
  LOCAL: 'local',
  REMOTE: 'remote',
  SQL: 'sql',
  MULTI: 'multi',
  SAVE_SETTING: 'Save Setting',
  CANCEL: 'Cancel',
  DOWNLOAD: 'Download',
  DEFAULT: 'Default',
  APPLY: 'Apply',
  RESET: 'Reset',
  SAVE: 'Save',
  EDIT: 'Edit',
  RE_START: 'Re-Start',
  ALL: 'All',
  PRESET: 'Preset',
  SAVE_PRESET: 'Save Preset',
  NEW_PRESET: 'New Preset',
  UPDATE_PRESET: 'Update Preset',
  MAX: 'Max',
  MIN: 'Min',
  BUTTON_ANALYSIS: 'Analysis Now',
  SETTING: 'Setting',
  FUNCTION: 'function',
  HISTORY: 'history',
  PERIOD: 'Period',
  JOB: 'Job',
  SELECT_TARGET: 'Select Target',
  /*
  #=========================================#
  | MANAGEMENT                              |
  #=========================================#
  */
  CONFIGURATION: 'Configuration',
  CONFIG_DATABASE_TITLE: 'Database',

  MGMT_MAIN_TITLE: 'Management Setting',
  MGMT_LOCAL_TITLE: 'LOCAL DATABASE INFO',
  MGMT_REMOTE_TITLE: 'REMOTE DATABASE INFO',
  MGMT_TABLE_TITLE: 'SETTINGS TABLE LIST',
  CONFIRM_CANCEL: 'Sure to cancel?',
  CONFIRM_DELETE: 'Sure to delete?',
  DBCONNECTION_TEST: 'TEST Connection',
  /*
  #=========================================#
  | IMPORT/EXPORT                           |
  #=========================================#
  */
  IMPORT_EXPORT: 'IMPORT/EXPORT',
  EXPORT: 'Export',
  IMPORT: 'Import',
  UPLOAD_EXCEL_ONLY: 'Upload excel file only',
  /*
  #=========================================#
  | ANALYSIS                                |
  #=========================================#
  */
  ANALYSIS: 'Analysis',
  /*
  #=========================================#
  | JOB STEP                                |
  #=========================================#
  */
  PREVIEW: 'Preview',
  NEXT: 'Next',
  PREVIOUS: 'Previous',
  PREVIOUS_TABLE: 'Previous Preview TABLE',
  UPLOAD_SCRIPT: 'upload script',
  PROGRESS: 'In Progress',
  WAITING: 'Waiting',
  FINISHED: 'Finished',
  CUSTOM_STEP1: 'Title Setting',
  CUSTOM_STEP2: 'Select Log Data',
  CUSTOM_STEP3: 'Define Headers & Columns',
  CUSTOM_STEP4: 'Define Data Filter',
  CUSTOM_STEP5: 'Analysis Setting',
  CUSTOM_STEP6: 'Visualization Setting',
  STEP1_CATEGORY: 'Category',
  STEP1_MAIN_TITLE: 'Main Title',
  STEP1_SUB_TITLE: 'Sub Title',
  STEP3_LOG_DEFINE: 'Log Define',
  STEP3_SELECT: 'Select Headers and Columns',
  STEP3_DEFINE: 'Headers/Columns Define',
  STEP3_INFO: 'Info',
  STEP3_HEADERS: 'Headers',
  STEP3_CUSTOM: 'Custom Columns',
  STEP3_CONVERT_SCRIPT: 'Select Convert Script',
  REQUIRED_TOOLTIP: 'This is a required field',
  STEP4_FILTER: 'Filter Setting',
  STEP4_SHOW_ORIGINAL: 'Show Original Log Data',
  STEP5_ANALYSIS: 'Analysis Setting',
  STEP5_FILTER_KEY: 'Select Filter Key',
  STEP5_AGGREGATION: 'Aggregation By',
  ADD_DATABASE: 'Add Database',
  ADD_NEW: 'Add New..',
  DISABLE: 'disabled',
  TABLE_TITLE_INDEX: 'Index',
  TABLE_TITLE_ROW: 'Row',
  TABLE_TITLE_SOURCE_COLUMN: 'Source Column',
  TABLE_TITLE_DATA: 'Data',
  TABLE_TITLE_NAME: 'Name',
  TABLE_TITLE_OUTPUT: 'Output Column',
  TABLE_TITLE_TYPE: 'Type',
  TABLE_TITLE_DEFAULT: 'Default Value',
  TABLE_TITLE_COEFFICIENT: 'Coefficient',
  TABLE_TITLE_UNIT: 'Unit',
  TABLE_TITLE_DISP_ORDER: 'Disp.Order',
  TABLE_TITLE_TILE: 'Title',
  TABLE_TITLE_GROUP: 'Group Analysis',
  TABLE_TITLE_TOTAL: 'Total Analysis',
  TABLE_TITLE_FILTER_NAME: 'Filter Name',
  TABLE_TITLE_FILTER_TYPE: 'Filter Type',
  TABLE_TITLE_FILTER_CONDITION: 'Condition',
  TABLE_TITLE_DELETE: 'Delete',
  TABLE_TITLE_SKIP: 'Skip',
  /*
  #=========================================#
  | OVERLAY                                 |
  #=========================================#
  */
  OVERLAY: 'Overlay',
  /*
  #=========================================#
  | OVERLAY (MAP)                           |
  #=========================================#
  */
  DISPLAY_MAP: 'Display Map',
  NUMBER_OF_COLUMNS: 'Number of Columns to Display',
  SHOW_EXTRA_INFO: 'Show Extra Info',
  DIV: 'Div',
  LOWER_ROW: 'Lower Row',
  UPPER_ROW: 'Upper Row',
  PLATE_SIZE: 'Plate Size',
  SIZE_X: 'Size X:',
  SIZE_Y: 'Size Y:',
  STILDE: '~',
  OFFSET_XY: 'Offset X/Y',
  OFFSET_X: 'Offset X',
  OFFSET_Y: 'Offset Y',
  CP_VS: 'CP / VS',
  CP_VS_FROM_LOG: 'From Log Data',
  CP_VS_EACH_SHOT: 'Set CP/VS for each shot',
  CP_VS_SHOT1_SAME: 'Reflect the CP/VS of shot1 on all shots',
  JOB_FILE_UPLOAD: 'Job data file',
  /*
  #=========================================#
  | OVERLAY (Variation)                     |
  #=========================================#
  */
  RANGE_SHOT_CHANGE: 'Range / Shot Option',
  RANGE_CHANGE: 'Range Change',
  SHOT_CHANGE: 'Shot Select',
  SIGMA_RANGE: '3s Range Change',
  Y_UPPER_LIMIT: 'Y: Upper Limit',
  X_UPPER_LIMIT: 'X: Upper Limit',
  Y_LOWER_LIMIT: 'Y: Lower Limit',
  X_LOWER_LIMIT: 'X: Lower Limit',
  SIGMA_X: '3s_X',
  SIGMA_Y: '3s_Y',
  X: 'x',
  Y: 'y',
  /*
  #=========================================#
  | OVERLAY (Reproducibility)               |
  #=========================================#
  */
  OVERLAY_: 'Overlay',
  OVERLAY_ADC: 'Adcmeasurement',
  OVERLAY_CORRECTION: 'Correction Component',
  OVERLAY_OASBASELINE: 'Oas Baseline',
  OVERLAY_LOG: 'Overlay Log Setting',
  /*
  #=========================================#
  | TACT                                    |
  #=========================================#
  */
  TACT: 'Tact',
  TACT_SETTING: 'Tact Setting',
  STATUS_MONITOR: 'Status Monitor',
  MEMORY_DUMP: 'TS Memory Dump',
  TACT_GRAPH_UNIT: 'Unit',
  TACT_GRAPH_TYPE: 'Type',
  TACT_GRAPH_ADC_FDC: 'ADC/FDC',
  TACT_GRAPH_DISPLAY_OUTLIER: 'Display Outlier',
  TACT_GRAPH_JOB_SCALE: 'Job Tact Scale',
  TACT_GRAPH_PLATE_SCALE: 'Plate Tact Scale',
  TACT_GRAPH_SHOW_PREDICTIVE_VALUE: 'Show Predictive Value',
  TACT_GRAPH_SHOW_DATA_TABLE: 'Show Data Table',
  TACT_GRAPH_SCALE_UNIT: 'Scale Unit',
  TACT_GRAPH_UNIT_MSEC: 'Msec',
  TACT_GRAPH_COLOR_CHANGE_JOB: 'Job Tact Color Change',
  TACT_GRAPH_COLOR_CHANGE_PLATE: 'Plate Tact Color Change',
  TACT_GRAPH_COLOR_CHANGE_PLATE_DETAIL: 'Plate Detail Tact Color Change',
  TACT_GRAPH_COLOR_CHANGE_PREDICTIVE: 'Predictive Color Change',
  TACT_GRAPH_COLOR_CHANGE_DIFF: 'Difference Graph Color Change',
  /*
  #=========================================#
  | FOCUS                                    |
  #=========================================#
  */
  FOCUS: 'Focus',
  FOCUS_PRESCAN_COE: 'PreScan Correction Of Exposure',
  /*
  #=========================================#
  | REGEXP                                  |
  #=========================================#
  */
  COMMON_REGEXP:
    'Only English, numeric, and underbar(_:special character) are allowed.And the first and last characters can only be English characters. (up to 30 characters) ',
  RULE_NAME_REGEXP:
    'Only English, numeric, and underbar(_:special character) are allowed.(up to 30 characters) ',
  TABLE_NAME_REGEXP:
    'Only English(lower case), numeric, and underbar(_:special character) are allowed.(up to 30 characters) ',
  ALL_STRING_REGEXP: 'Enter up to 30 characters',
  REFER_TO_TOOLTIP: 'Please refer to the tooltip for input specifications.',
  REFER_TO_TOOLTIP2: 'Please check the tooltip.',
  SELECT_COMBOBOX: 'Select one of the items',
  ONLY_NUMBER_REGEXP: 'Only numbers can be entered.',
  DEFAULT_TYPE_REGEXP:
    'Select one of the items. If you select [text],[lambda], please write more than 1 character.',
  ANY_CHARACTER_REGEXP: 'please write more than 1 character.',
  COEFFICIENT_REGEXP: 'Power of 10.(for example, 1/10/100...)',
  UNIT_REGEXP: 'Units such as um (micrometer) and mm (millimeter)',
  ANALYSIS_REGEXP:
    'Select one of the items. If you select [script],[sequential], please write more than 1 character.',
  CONFIGURATION_ADD_PATTERN:
    'Checks if a specific string exists in a file name.',
  CONFIGURATION_ADD_IGNORE_PATTERN:
    'Checks that there is no specific string in a file name',
};
