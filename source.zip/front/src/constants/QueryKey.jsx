export const QUERY_KEY = {
  MAIN_INIT: 'main_init',
  VERSION_INIT: 'version_init',
  //---------------------------------------------------------
  GET_LOG_PATTERN_LIST: 'config/log_pattern/get',
  POST_LOG_PATTERN_INFO: 'config/log_pattern/post',
  PUT_LOG_PATTERN_INFO: 'config/log_pattern/put',
  DELETE_LOG_PATTERN_INFO: 'config/log_pattern/delete',
  GET_COLUMN_DEFINE_LIST: 'config/column-define/get',
  POST_COLUMN_DEFINE_INFO: 'config/column-define/post',
  PUT_COLUMN_DEFINE_INFO: 'config/column-define/put',
  DELETE_COLUMN_DEFINE_INFO: 'config/column-define/delete',
  GET_LOG_DEFINE_LIST: 'config/log-define/get',
  POST_LOG_DEFINE_INFO_IMPORT: 'config/log-define/post/import',
  POST_LOG_DEFINE_INFO_EXPORT: 'config/log-define/post/export',
  PUT_LOG_DEFINE_INFO: 'config/log-define/put',
  DELETE_LOG_DEFINE_INFO: 'config/log-define/delete',
  //---------------------------------------------------------
  GET_COMMON_LOG_LIST: 'log/common/get',
  UPDATE_CATEGORY: 'log/category/update',

  UPDATE_COMMON_LOG_ITEM: 'log/common/update',
  DELETE_COMMON_LOG_ITEM: 'log/common/delete',
  EXPORT_COMMON_LOG_ITEM: 'log/common/export',
  IMPORT_COMMON_LOG_ITEM: 'log/common/import',

  //---------------------------------------------------------
  JOBSETTING_INIT: 'jobSetting/loading',
  JOBSETTING_FILE_UPLOAD: 'jobSetting/file-upload',
  JOBSETTING_LOCAL_JOB: 'jobSetting/local/convert-job',
  JOBSETTING_SQL_JOB: 'jobSetting/sql',
  JOBSETTING_REMOTE_JOB: 'jobSetting/remote',
  JOBSETTING_HISTORY_JOB: 'jobSetting/history',
  JOBSETTING_USER_FAB_EQUIPMENT_LIST: 'jobSetting/remote/equipment_list',
  JOBSETTING_CONVERT_NG: 'jobSetting/convert-job/delete',
  JOBSETTING_CONVERT_JOB_STATUS: 'jobSetting/convert-job/status',
  JOBSETTING_EQUIPMENT_VALID_DATE: 'jobSetting/remote/table/equipment/date',
  JOBSETTING_DELETE_HISTORY: 'jobSetting/history/delete',
  JOBSETTING_MULTIJOB_UPDATE: 'jobSetting/multi/info_update', //mutation

  //---------------------------------------------------------
  MGMT_INIT: 'mgmt_init',
  MGMT_LOCAL_DB: 'mgmt/local',
  MGMT_REMOTE_DB: 'mgmt/remote',
  MGMT_REMOTE_DB_LIST: 'mgmt/remote/list',
  MGMT_REMOTE_DB_DETAIL: 'mgmt/remote/db_id',
  MGMT_REMOTE_DB_STATUS: 'mgmt/remote/db_id/status',
  MGMT_TABLE_DB: 'mgmt/table',
  DB_CONNECTION_CHECK: 'mgmt/connection-check', //mutation
  MGMT_DB_UPDATE: 'mgmt/db_update', //mutation
  MGMT_DB_DELETE: 'mgmt/db_delete', //mutation
  MGMT_DB_ADD: 'mgmt/db_add', //mutation
  MGMT_RULES_IMPORT: 'mgmt/rules/import',

  //---------------------------------------------------------
  STEP1_INIT: 'jobStep/step1/init',
  STEP1_EDIT_INIT: 'jobStep/step1/edit_init',
  STEP1_NEXT: 'jobStep/step1/next',
  STEP2_MULTI_RESOURCE: 'jobStep/step2/resource/multi',
  STEP2_MULTI_PREVIEW: 'jobStep/step2/preview/multi',
  STEP2_MULTI_LOCAL_JOB_STATUS: 'jobStep/step2/preview/local/convertor',
  STEP2_MULTI_PREVIEW2: 'jobStep/step2/preview/multi/request',
  STEP2_RESOURCE_UPDATE: 'jobStep/step2/resource/update',
  STEP2_DB_TABLE_LIST: 'jobStep/step2/db_id/table_list',
  STEP2_USER_FAB_EQUIPMENT_LIST: 'jobStep/step2/db_id/table/equipment_list',
  STEP2_EQUIPMENT_VALID_COLUMN:
    'jobStep/step2/db_id/table/equipment/time_column',
  STEP2_EQUIPMENT_VALID_DATE: 'jobStep/step2/db_id/table/equipment/date',
  STEP5_PREVIEW: 'jobStep/step5/preview',
  STEP5_DATASOURCE_LIST: 'jobStep/step5/db_list',
  STEP5_SQL_QUERY: 'jobStep/step5/sql_query',

  LOG_STEP_INIT: 'LogStep/step1/init',
  LOG_STEP_SAMPLE_LOG: 'LogStep/step1/sample-log',
  //---------------------------------------------------------
  OVERLAY_INITIAL_INFO: 'overlay/init/info',
  OVERLAY_REMOTE_DB_LIST: 'overlay/remote/list',
  OVERLAY_REMOTE_INFO: 'overlay/remote/info',
  OVERLAY_REMOTE_USER_FAB_EQUIPMENT: 'overlay/remote/equipment',
  OVERLAY_LOCAL_FILE_UPLOAD: 'overlay/local/file-upload',
  OVERLAY_ETC_SETTING_UPDATE: 'overlay/map/etc',
  OVERLAY_PRESET_ADD: 'overlay/map/preset/add', //mutation
  OVERLAY_PRESET_UPDATE: 'overlay/map/preset/update', //mutation
  OVERLAY_PRESET_DELETE: 'overlay/map/preset/delete', //mutation
  OVERLAY_PRESET_GET: 'overlay/map/preset/get',
  OVERLAY_CPVS_JOB_FILE_UPLOAD: 'overlay/map/cpvs/job/file-upload',
  OVERLAY_GRAPH_INFO_PUT: 'overlay/graph/info/put',
  OVERLAY_CORRECTION_SETTING_INFO: 'overlay/correction/setting/info',
  OVERLAY_ANALYSIS_START: 'overlay/analysis/start/post',
  OVERLAY_ANALYSIS_UPLOAD: 'overlay/analysis/upload/post',

  OVERLAY_LOG_SETTING_GET: 'overlay/log-setting/get',
  OVERLAY_LOG_SETTING_UPDATE_SCRIPT: 'overlay/log-setting/post/script',
  OVERLAY_LOG_SETTING_DELETE_SCRIPT: 'overlay/log-setting/delete/script',

  //---------------------------------------------------------

  FOCUS_LOG_SETTING_GET: 'focus/log-setting/get',
  FOCUS_LOG_SETTING_UPDATE_SCRIPT: 'focus/log-setting/post/script',
  FOCUS_LOG_SETTING_DELETE_SCRIPT: 'focus/log-setting/delete/script',

  //---------------------------------------------------------

  TACT_SETTING_GET: 'tact/setting/get',
  TACT_SETTING_DOWNLOAD: 'tact/setting/download',
  TACT_SETTING_UPDATE: 'tact/setting/update',
  TACT_SETTING_POST_IMPORT: 'tact/setting/post/import', //mutation
  TACT_SETTING_DELETE_PU_NAME: 'tact/setting/delete/pu_name', //mutation
  TACT_SETTING_PUT_PU_NAME: 'tact/setting/put/pu_name', //mutation

  TACT_STATUS_MONITOR_POST_UPLOAD: 'tact/status_monitor/post/upload', //mutation
  TACT_STATUS_MONITOR_GET_CONVERTED_STATUS:
    'tact/status_monitor/get/converted_status', //get
  TACT_STATUS_MONITOR_GET_JOB_INFO: 'tact/status_monitor/get/job_info',
  TACT_STATUS_MONITOR_GET_JOB_LIST: 'tact/status_monitor/get/job_list',
  TACT_STATUS_MONITOR_POST_JOB_TACT: 'tact/status_monitor/post/job_tact', //mutation
  TACT_STATUS_MONITOR_POST_PLATE_TACT: 'tact/status_monitor/post/plate_tact', //mutation

  TACT_MEMORY_DUMP_POST_UPLOAD: 'tact/memory/post/upload', //mutation
  TACT_MEMORY_DUMP_POST_ANALYSIS_RESULT: 'tact/memory/post/analysis', //mutation
  TACT_MEMORY_DUMP_GET_CONVERTED_STATUS: 'tact/memory/get/converted_status', //get
  TACT_MEMORY_DUMP_GET_ANALYSIS_RESULT: 'tact/memory/get/analysis', //get

  TACT_LOG_SETTING_GET: 'tact/log-setting/get',
  TACT_LOG_SETTING_UPDATE_SCRIPT: 'tact/log-setting/post/script',
  TACT_LOG_SETTING_DELETE_SCRIPT: 'tact/log-setting/delete/script',
};
