import DatabaseSetting from '@components/Configuration/DatabaseSetting';
import LogPattern from '@components/Configuration/LogPattern';
import LogColumn from '@components/Configuration/LogColumn';
import { LogDefine } from '@components/Configuration/LogDefine';
import { Config } from '@assets/locale/en';

export const DEFINE_ENABLE_PATTERN_ADD = false;
export const DEFINE_ENABLE_PATTERN_LOG_EDIT = false;
export const ConfigList = [
  { title: Config.dataBase.title, component: <DatabaseSetting /> },
  { title: Config.logDefine.title, component: <LogDefine /> },
  { title: Config.logPattern.title, component: <LogPattern /> },
  { title: Config.logColumn.title, component: <LogColumn /> },
];
export const LogPattenDefaultItem = {
  idx: undefined,
  log_name: undefined,
  pattern: [],
  ignore_pattern: [],
};
export const LogColumnDefaultItem = {
  idx: undefined,
  type: 'info', //0: info, 1: header
  data: undefined,
  output_column: undefined,
  data_type: 'text',
  def_type: 'null',
  def_val: 'null',
  custom_value: '',
  coef: 1,
  unit: '',
};
export const LogColumnInfoList = [
  'id',
  'type',
  'output_column',
  'data_type',
  'def_val',
  'def_type',
];
export const LogColumnHeaderList = [
  'id',
  'type',
  'data',
  'output_column',
  'data_type',
  'def_val',
  'def_type',
  'coef',
  'unit',
];

export const DatabaseListTable = [
  {
    title: Config.dataBase.remote.table.columns.no,
    dataIndex: 'no',
  },
  {
    title: Config.dataBase.remote.table.columns.name,
    dataIndex: 'name',
  },
  {
    title: Config.dataBase.remote.table.columns.address,
    dataIndex: 'address',
  },
  {
    title: Config.dataBase.remote.table.columns.status,
    dataIndex: 'sts',
  },
  {
    title: Config.dataBase.remote.table.columns.delete,
    dataIndex: 'edit',
  },
];
export const LogPatternTable = [
  {
    title: Config.logPattern.table.columns.no,
    dataIndex: 'no',
  },
  {
    title: Config.logPattern.table.columns.logName,
    dataIndex: 'log_name',
  },
  {
    title: Config.logPattern.table.columns.pattern,
    dataIndex: 'pattern',
  },
  {
    title: Config.logPattern.table.columns.ignore_pattern,
    dataIndex: 'ignore_pattern',
  },
  {
    title: Config.logPattern.table.columns.edit,
    dataIndex: 'edit',
  },
];
export const LogColumnTable = [
  {
    title: Config.logColumn.table.columns.no,
    dataIndex: 'no',
  },
  {
    title: Config.logColumn.table.columns.type,
    dataIndex: 'type',
  },
  {
    title: Config.logColumn.table.columns.data,
    dataIndex: 'data',
  },
  {
    title: Config.logColumn.table.columns.database_name,
    dataIndex: 'output_column',
  },
  {
    title: Config.logColumn.table.columns.database_type,
    dataIndex: 'data_type',
  },
  {
    title: Config.logColumn.table.columns.def_type,
    dataIndex: 'def_val',
  },
  {
    title: Config.logColumn.table.columns.coef,
    dataIndex: 'coef',
  },
  {
    title: Config.logColumn.table.columns.unit,
    dataIndex: 'unit',
  },
  {
    title: Config.logColumn.table.columns.edit,
    dataIndex: 'edit',
  },
];

export const LogColumnTypeList = [
  {
    title: Config.logColumn.modal.type.options.info,
    value: 'info',
  },
  {
    title: Config.logColumn.modal.type.options.header,
    value: 'header',
  },
];

export const LogColumnDatabaseTypeList = [
  {
    title: Config.logColumn.modal.database_type.options.integer,
    value: 'integer',
  },
  {
    title: Config.logColumn.modal.database_type.options.float,
    value: 'float',
  },
  {
    title: Config.logColumn.modal.database_type.options['varchar(10)'],
    value: 'varchar(10)',
  },
  {
    title: Config.logColumn.modal.database_type.options['varchar(30)'],
    value: 'varchar(30)',
  },
  {
    title: Config.logColumn.modal.database_type.options['varchar(50)'],
    value: 'varchar(50)',
  },
  {
    title: Config.logColumn.modal.database_type.options.timestamp,
    value: 'timestamp',
  },
  {
    title: Config.logColumn.modal.database_type.options.time,
    value: 'time',
  },
  {
    title: Config.logColumn.modal.database_type.options.boolean,
    value: 'boolean',
  },
];

export const LogColumnDefaultTypeList = [
  {
    title: Config.logColumn.modal.def_type.options.null,
    value: 'null',
  },
  {
    title: Config.logColumn.modal.def_type.options.text,
    value: 'text',
  },
  {
    title: Config.logColumn.modal.def_type.options.now,
    value: 'now',
  },
  {
    title: Config.logColumn.modal.def_type.options.lambda,
    value: 'lambda',
  },
];

export const excelFileType =
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
export const csvFileType = ' text/csv;charset=utf-8';

export const ExcelForm = [
  {
    title: Config.dataBase.remote.excel.no,
    key: 'no',
  },
  {
    title: Config.dataBase.remote.excel.name,
    key: 'name',
  },
  {
    title: Config.dataBase.remote.excel.host,
    key: 'host',
  },
  {
    title: Config.dataBase.remote.excel.port,
    key: 'port',
  },
  {
    title: Config.dataBase.remote.excel.user,
    key: 'username',
  },
  {
    title: Config.dataBase.remote.excel.db_name,
    key: 'dbname',
  },
  {
    title: Config.dataBase.remote.excel.pw,
    key: 'password',
  },
  {
    title: Config.dataBase.remote.excel.encrypted,
    key: 'encrypted',
  },
];
