import {
  E_TACT_SETTING_NAME_DAT,
  E_TACT_SETTING_PLATE,
  E_TACT_SETTING_PLATE_DETAIL,
  E_TACT_SETTING_PLATE_EVENT, E_TACT_SETTING_PRIMARY_PU,
  E_TACT_SETTING_PRIMARY_PU_SETTING, E_TACT_SETTING_REFERENCE_PU,
} from './etc';

export const PLATE_TACT = {
  id: E_TACT_SETTING_PLATE,
  title: 'Plate TACT',
};

export const PLATE_DETAIL_TACT = {
  id: E_TACT_SETTING_PLATE_DETAIL,
  title: 'Plate Detail TACT ',
};

export const PLATE_DETAIL_TACT_EVENT = {
  id: E_TACT_SETTING_PLATE_EVENT,
  title: 'Plate TACT Event',
};

export const NAME_DAT = {
  id: E_TACT_SETTING_NAME_DAT,
  title: 'Name.dat ',
};

export const PRIMARY_PU = {
  id: E_TACT_SETTING_PRIMARY_PU,
  title: 'Primary PU ',
};

export const PRIMARY_PU_SETTING = {
  id: E_TACT_SETTING_PRIMARY_PU_SETTING,
  title: 'Primary PU Setting',
};

export const REFERENCE_PU = {
  id: E_TACT_SETTING_REFERENCE_PU,
  title: 'reference PU',
};

export const TACT_SETTING_LIST = [
  PLATE_TACT,
  PLATE_DETAIL_TACT,
  PLATE_DETAIL_TACT_EVENT,
  NAME_DAT,
  PRIMARY_PU,
];

export const TACT_PRIMARY_PU_LIST = [PRIMARY_PU_SETTING, REFERENCE_PU];

export const TACT_SET_PLATE_COLUMNS = [
  {
    title: 'Display order',
    dataIndex: 'display_order',
    render: (text, record, index) => index + 1,
  },
  {
    title: 'Classification',
    dataIndex: 'classification',
  },
];

export const TACT_SET_PLATE_DETAIL_COLUMNS = [
  {
    title: 'Event',
    dataIndex: 'event',
    editable: true,
  },
  {
    title: 'Start',
    dataIndex: 'start',
    editable: true,
  },
  {
    title: 'End',
    dataIndex: 'End',
    editable: true,
  },
  {
    title: 'Classification',
    dataIndex: 'classification',
    editable: true,
  },
  {
    title: 'Display',
    dataIndex: 'display',
    render: (display) => (display ? 'Show' : 'Hide'),
  },
];

export const TACT_SET_PLATE_EVENT_COLUMNS = [
  {
    title: 'No',
    dataIndex: 'index',
    render: (text, record, index) => index + 1,
  },
  {
    title: 'Event',
    dataIndex: 'event',
    editable: true,
  },
];

export const TACT_SET_NAME_DAT_COLUMNS = [
  {
    title: 'PUID',
    dataIndex: 'PUID',
    editable: true,
  },
  {
    title: 'Name',
    dataIndex: 'Name',
    editable: true,
  },
];

export const TACT_SET_PRIMARY_PU_COLUMNS = [
  {
    title: 'PUID',
    dataIndex: 'PUID',
    editable: true,
  },
  {
    title: 'Name',
    dataIndex: 'Name',
    editable: true,
  },
  {
    title: 'level ',
    dataIndex: 'Level',
    editable: true,
  },
];
export const TACT_SET_REFERENCE_PU_COLUMNS = [
  {
    title: 'PUID',
    dataIndex: 'PUID',
    editable: true,
  },
  {
    title: 'Primary PU Name',
    dataIndex: 'primary_pu',
  },
];
