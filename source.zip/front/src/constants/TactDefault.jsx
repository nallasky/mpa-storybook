import {
  E_TACT_GRAPH_ADC,
  E_TACT_GRAPH_ADC_FDC_ALL,
  E_TACT_GRAPH_COLOR_DIFFERENCE,
  E_TACT_GRAPH_COLOR_JOB,
  E_TACT_GRAPH_COLOR_PLATE,
  E_TACT_GRAPH_COLOR_PLATE_DETAIL,
  E_TACT_GRAPH_COLOR_PREDICT,
  E_TACT_GRAPH_FDC,
  E_TACT_GRAPH_TYPE_THROUGHPUT,
  E_TACT_GRAPH_TYPE_WAITING,
  E_TACT_GRAPH_TYPE_WORKING,
  E_TACT_GRAPH_UNIT_LOT,
  E_TACT_GRAPH_UNIT_PLATE,
  E_TACT_MEMORY_COPY_FILES,
  E_TACT_MEMORY_DOWNLOADED,
  E_TACT_MEMORY_LOG_SERVER,
  E_TACT_SETTING_NAME_DAT,
  E_TACT_SETTING_PLATE,
  E_TACT_SETTING_PLATE_DETAIL,
  E_TACT_SETTING_PLATE_EVENT,
  E_TACT_SETTING_PRIMARY_PU,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
  E_TACT_SETTING_REFERENCE_PU,
  E_TACT_STATUS_JOB_TACT,
  E_TACT_STATUS_PLATE_DETAIL_TACT,
  E_TACT_STATUS_PLATE_TACT,
  E_TACT_GRAPH_PLATE_DIFF_SCRIPT,
  E_TACT_GRAPH_PLATE_SCRIPT,
  E_TACT_GRAPH_JOB_SCRIPT,
  E_TACT_GRAPH_PLATE_DETAIL_SCRIPT,
  E_TACT_GRAPH_PLATE_DETAIL_DIFF_SCRIPT,
  E_TACT_GRAPH_MEMORY_DUMP_SCRIPT,
} from './etc';
import { MESSAGE } from './Message';
import {
  JobTactScript,
  PlateTactScript,
  PlateTactDiffScript,
  PlateDetailTactScript,
  PlateDetailTactDiffScript,
  TSMemoryDumpScript,
} from '../libs/graph';

//----------tact Status ------------------------------------------------------------------------

export const TACT_STATUS_JOB = {
  id: E_TACT_STATUS_JOB_TACT,
  title: 'Job TACT',
};
export const TACT_STATUS_PLATE = {
  id: E_TACT_STATUS_PLATE_TACT,
  title: 'Plate TACT',
};
export const TACT_STATUS_PLATE_DETAIL = {
  id: E_TACT_STATUS_PLATE_DETAIL_TACT,
  title: 'Plate Detail TACT',
};

export const TACT_GRAPH_UNIT_LOT = {
  id: E_TACT_GRAPH_UNIT_LOT,
  title: 'Lot',
};
export const TACT_GRAPH_UNIT_PLATE = {
  id: E_TACT_GRAPH_UNIT_PLATE,
  title: 'Plate',
};

export const TACT_GRAPH_UNIT_LIST = [
  TACT_GRAPH_UNIT_LOT,
  TACT_GRAPH_UNIT_PLATE,
];

export const TACT_GRAPH_TYPE_THROUGHPUT = {
  id: E_TACT_GRAPH_TYPE_THROUGHPUT,
  title: 'Throughput',
};
export const TACT_GRAPH_TYPE_WORKING = {
  id: E_TACT_GRAPH_TYPE_WORKING,
  title: 'Working',
};
export const TACT_GRAPH_TYPE_WAITING = {
  id: E_TACT_GRAPH_TYPE_WAITING,
  title: 'Waiting',
};

export const TACT_GRAPH_TYPE_LIST = [
  TACT_GRAPH_TYPE_THROUGHPUT,
  TACT_GRAPH_TYPE_WORKING,
  TACT_GRAPH_TYPE_WAITING,
];

export const TACT_GRAPH_ADC_FDC_ALL = {
  id: E_TACT_GRAPH_ADC_FDC_ALL,
  title: 'All',
};
export const TACT_GRAPH_ADC = {
  id: E_TACT_GRAPH_ADC,
  title: 'ADC',
};
export const TACT_GRAPH_FDC = {
  id: E_TACT_GRAPH_FDC,
  title: 'FDC',
};

export const TACT_GRAPH_ADC_FDC_LIST = [
  TACT_GRAPH_ADC_FDC_ALL,
  TACT_GRAPH_ADC,
  TACT_GRAPH_FDC,
];
export const TACT_GRAPH_COLOR_JOB = {
  id: E_TACT_GRAPH_COLOR_JOB,
  title: MESSAGE.TACT_GRAPH_COLOR_CHANGE_JOB,
};
export const TACT_GRAPH_COLOR_PLATE = {
  id: E_TACT_GRAPH_COLOR_PLATE,
  title: MESSAGE.TACT_GRAPH_COLOR_CHANGE_PLATE,
};
export const TACT_GRAPH_COLOR_PREDICTIVE = {
  id: E_TACT_GRAPH_COLOR_PREDICT,
  title: MESSAGE.TACT_GRAPH_COLOR_CHANGE_PREDICTIVE,
};
export const TACT_GRAPH_COLOR_DIFFERENCE = {
  id: E_TACT_GRAPH_COLOR_DIFFERENCE,
  title: MESSAGE.TACT_GRAPH_COLOR_CHANGE_DIFF,
};
export const TACT_GRAPH_COLOR_PLATE_DETAIL = {
  id: E_TACT_GRAPH_COLOR_PLATE_DETAIL,
  title: MESSAGE.TACT_GRAPH_COLOR_CHANGE_PLATE_DETAIL,
};

export const TACT_GRAPH_COLOR_LIST = {
  [E_TACT_STATUS_JOB_TACT]: [TACT_GRAPH_COLOR_JOB],
  [E_TACT_STATUS_PLATE_TACT]: [
    TACT_GRAPH_COLOR_PLATE,
    TACT_GRAPH_COLOR_PREDICTIVE,
    TACT_GRAPH_COLOR_DIFFERENCE,
  ],
  [E_TACT_STATUS_PLATE_DETAIL_TACT]: [TACT_GRAPH_COLOR_PLATE_DETAIL],
};

//----------tact Memory ------------------------------------------------------------------------

export const TACT_MEMORY_COPY = {
  id: E_TACT_MEMORY_COPY_FILES,
  title: 'Copy File',
};
export const TACT_MEMORY_LOG_SERVER = {
  id: E_TACT_MEMORY_LOG_SERVER,
  title: 'logServer Log',
};

export const TACT_MEMORY_IMPORT_LOG = {
  id: E_TACT_MEMORY_DOWNLOADED,
  title: 'Downloaded ',
};

export const TACT_MEMORY_LIST = [
  TACT_MEMORY_COPY,
  TACT_MEMORY_LOG_SERVER,
  TACT_MEMORY_IMPORT_LOG,
];

//----------tact Setting ------------------------------------------------------------------------

export const PLATE_TACT = {
  id: E_TACT_SETTING_PLATE,
  title: 'Plate TACT',
};

export const PLATE_DETAIL_TACT = {
  id: E_TACT_SETTING_PLATE_DETAIL,
  title: 'Plate Detail TACT ',
};

export const PLATE_DETAIL_TACT_EVENT = {
  id: E_TACT_SETTING_PLATE_EVENT,
  title: 'Plate TACT Event',
};

export const NAME_DAT = {
  id: E_TACT_SETTING_NAME_DAT,
  title: 'Name.dat ',
};

export const PRIMARY_PU = {
  id: E_TACT_SETTING_PRIMARY_PU,
  title: 'Primary PU ',
};

export const PRIMARY_PU_SETTING = {
  id: E_TACT_SETTING_PRIMARY_PU_SETTING,
  title: 'Primary PU Setting',
};

export const REFERENCE_PU = {
  id: E_TACT_SETTING_REFERENCE_PU,
  title: 'reference PU',
};

export const TACT_SETTING_LIST = [
  PLATE_TACT,
  PLATE_DETAIL_TACT,
  PLATE_DETAIL_TACT_EVENT,
  NAME_DAT,
  PRIMARY_PU,
];

export const TACT_PRIMARY_PU_LIST = [PRIMARY_PU_SETTING, REFERENCE_PU];

export const TACT_SET_DATA = {
  TACT_SET_INDEX: 'index',
  TACT_SET_ID: 'id',
  TACT_SET_DISPLAY_ORDER: 'display_order',
  TACT_SET_CATEGORY: 'category',
  TACT_SET_EVENT: 'event',
  TACT_SET_EVENT_START: 'event_start',
  TACT_SET_EVENT_END: 'event_end',
  TACT_SET_EVENT_CATEGORY: 'category',
  TACT_SET_EVENT_DISPLAY: 'display',
  TACT_SET_EVENT_KIND: 'event_kind',
  TACT_SET_NAME_DAT_PU_ID: 'puid',
  TACT_SET_NAME_DAT_NAME: 'name',
  TACT_SET_PRIMARY_PU_PU_ID: 'puid',
  TACT_SET_PRIMARY_PU_NAME: 'name',
  TACT_SET_PRIMARY_PU_LEVEL: 'level',
  TACT_SET_REFERENCE_PU_PU_ID: 'puid',
  TACT_SET_REFERENCE_PU_PRIMARY_PU: 'primary_pu_name',
};
export const TACT_SET_DUPLICATED_CHECK_LIST = {
  [E_TACT_SETTING_PLATE]: [
    TACT_SET_DATA.TACT_SET_DISPLAY_ORDER, //plate_tact
    TACT_SET_DATA.TACT_SET_CATEGORY, //plate_tact
  ],
  [E_TACT_SETTING_PLATE_DETAIL]: [
    TACT_SET_DATA.TACT_SET_EVENT, //plate_detail_tact
  ],
  [E_TACT_SETTING_PLATE_EVENT]: [
    TACT_SET_DATA.TACT_SET_EVENT_KIND, //plate_tact_event
  ],
  [E_TACT_SETTING_NAME_DAT]: [
    TACT_SET_DATA.TACT_SET_NAME_DAT_PU_ID, //name_data
  ],
  [E_TACT_SETTING_PRIMARY_PU_SETTING]: [
    TACT_SET_DATA.TACT_SET_PRIMARY_PU_PU_ID, //primary_pu
  ],
  [E_TACT_SETTING_REFERENCE_PU]: [
    TACT_SET_DATA.TACT_SET_REFERENCE_PU_PU_ID, //ref_pu
  ],
};
export const TACT_SET_ORDER_BY = {
  [E_TACT_SETTING_PLATE]: TACT_SET_DATA.TACT_SET_DISPLAY_ORDER, //plate_tact
  [E_TACT_SETTING_PLATE_DETAIL]: TACT_SET_DATA.TACT_SET_ID, //plate_detail_tact
  [E_TACT_SETTING_PLATE_EVENT]: TACT_SET_DATA.TACT_SET_ID, //plate_tact_event
  [E_TACT_SETTING_NAME_DAT]: TACT_SET_DATA.TACT_SET_ID, //name_dat
  [E_TACT_SETTING_PRIMARY_PU_SETTING]: TACT_SET_DATA.TACT_SET_ID, //primary_pu
  [E_TACT_SETTING_REFERENCE_PU]: TACT_SET_DATA.TACT_SET_ID, //primary_pu
};

export const TACT_SET_PLATE_COLUMNS = [
  {
    title: 'Display order',
    dataIndex: TACT_SET_DATA.TACT_SET_DISPLAY_ORDER,
    editable: false,
    render: (text, record, index) => record?.display_order ?? index + 1,
  },
  {
    title: 'Classification',
    dataIndex: TACT_SET_DATA.TACT_SET_CATEGORY,
    editable: true,
    editType: 'input',
  },
];
export const TACT_SET_PLATE_DETAIL_COLUMNS = [
  {
    title: 'Event',
    dataIndex: TACT_SET_DATA.TACT_SET_EVENT,
    editable: true,
    editType: 'input',
  },
  {
    title: 'Start',
    dataIndex: TACT_SET_DATA.TACT_SET_EVENT_START,
    editable: true,
    editType: 'select',
  },
  {
    title: 'End',
    dataIndex: TACT_SET_DATA.TACT_SET_EVENT_END,
    editable: true,
    editType: 'select',
  },
  {
    title: 'Classification',
    dataIndex: TACT_SET_DATA.TACT_SET_EVENT_CATEGORY,
    editable: true,
    editType: 'select',
  },
  {
    title: 'Display',
    dataIndex: TACT_SET_DATA.TACT_SET_EVENT_DISPLAY,
    editable: true,
    editType: 'select',
    render: (display) =>
      display === undefined ? '' : display === 1 ? 'Show' : 'Hide',
  },
];
export const TACT_SET_PLATE_EVENT_COLUMNS = [
  {
    title: 'No',
    dataIndex: TACT_SET_DATA.TACT_SET_INDEX,
    render: (text) => text + 1,
  },
  {
    title: 'Event',
    dataIndex: TACT_SET_DATA.TACT_SET_EVENT_KIND,
    editable: true,
    editType: 'input',
  },
];
export const TACT_SET_NAME_DAT_COLUMNS = [
  {
    title: 'PU ID',
    dataIndex: TACT_SET_DATA.TACT_SET_NAME_DAT_PU_ID,
    editable: true,
    editType: 'input',
  },
  {
    title: 'Name',
    dataIndex: TACT_SET_DATA.TACT_SET_NAME_DAT_NAME,
    editable: true,
    editType: 'input',
  },
];
export const TACT_SET_PRIMARY_PU_COLUMNS = [
  {
    title: 'PU ID',
    dataIndex: TACT_SET_DATA.TACT_SET_PRIMARY_PU_PU_ID,
    editable: true,
    editType: 'input',
  },
  {
    title: 'Name',
    dataIndex: TACT_SET_DATA.TACT_SET_PRIMARY_PU_NAME,
    editable: true,
    editType: 'input',
  },
  {
    title: 'Level ',
    dataIndex: TACT_SET_DATA.TACT_SET_PRIMARY_PU_LEVEL,
    editable: true,
    editType: 'select',
  },
];
export const TACT_SET_REFERENCE_PU_COLUMNS = [
  {
    title: 'PU ID',
    dataIndex: TACT_SET_DATA.TACT_SET_REFERENCE_PU_PU_ID,
    editable: true,
    editType: 'input',
  },
  {
    title: 'Primary PU Name',
    dataIndex: TACT_SET_DATA.TACT_SET_REFERENCE_PU_PRIMARY_PU,
    editable: true,
    editType: 'select',
  },
];

export const tactScriptMap = {
  [E_TACT_STATUS_JOB_TACT]: {
    script: { [E_TACT_GRAPH_JOB_SCRIPT]: JobTactScript },
    color: TACT_GRAPH_COLOR_LIST[E_TACT_STATUS_JOB_TACT],
  },
  [E_TACT_STATUS_PLATE_TACT]: {
    script: {
      [E_TACT_GRAPH_PLATE_SCRIPT]: PlateTactScript,
      [E_TACT_GRAPH_PLATE_DIFF_SCRIPT]: PlateTactDiffScript,
    },
    color: TACT_GRAPH_COLOR_LIST[E_TACT_STATUS_PLATE_TACT],
  },
  [E_TACT_STATUS_PLATE_DETAIL_TACT]: {
    script: {
      [E_TACT_GRAPH_PLATE_DETAIL_SCRIPT]: PlateDetailTactScript,
      [E_TACT_GRAPH_PLATE_DETAIL_DIFF_SCRIPT]: PlateDetailTactDiffScript,
    },
    color: TACT_GRAPH_COLOR_LIST[E_TACT_STATUS_PLATE_DETAIL_TACT],
  },
};

export const tactMemoryScriptMap = {
  [E_TACT_GRAPH_MEMORY_DUMP_SCRIPT]: TSMemoryDumpScript,
};

export const tactExportForm = {
  [E_TACT_STATUS_JOB_TACT]: {
    file_name: 'JobTact',
    setting: {
      period_from: 'sPeriod',
      period_to: 'sPeriod',
      job: 'sJobList',
      unit: 'unit',
      adc_fdc: 'adc_fdc',
      outlier: 'display_outlier',
    },
  },
  [E_TACT_STATUS_PLATE_TACT]: {
    file_name: 'PlateTact',
    setting: {
      type: 'type',
      adc_fdc: 'adc_fdc',
      comparison: {
        period_from: 'comparePeriod',
        period_to: 'comparePeriod',
        job: 'compareJob',
      },
      org: {
        period_from: 'sPeriod',
        period_to: 'sPeriod',
        job: 'job',
      },
    },
  },
  [E_TACT_STATUS_PLATE_DETAIL_TACT]: {
    file_name: 'PlateDetailTact',
    setting: {
      type: 'type',
      adc_fdc: 'adc_fdc',
      rid: 'rid',
      comparison: {
        period_from: 'comparePeriod',
        period_to: 'comparePeriod',
        lot_id_block: 'lot_id_block',
        plate: 'plate',
        job: 'compareJob',
      },
      org: {
        period_from: 'comparePeriod',
        period_to: 'comparePeriod',
        lot_id_block: 'lot_id_block',
        plate: 'plate',
        job: 'compareJob',
      },
    },
  },
};
