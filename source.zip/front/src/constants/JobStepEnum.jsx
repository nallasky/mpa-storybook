export const E_JOB_STEP = {
  STEP1_CATEGORY_ID: 'category_id',
  STEP1_TITLE: 'title',
  STEP2_RULE_NAME: 'rule_name',
  STEP2_LOG_NAME: 'log_name',
};
