import { JobStep } from '@assets/locale/en';
import {
  URL_PREVIEW_ANALYSIS,
  URL_PREVIEW_CONVERT,
  URL_PREVIEW_FILTER,
  URL_PREVIEW_SAMPLELOG,
  URL_RESOURCE_EDIT,
  URL_RESOURCE_EDIT_STEP1,
  URL_RESOURCE_EDIT_STEP2,
  URL_RESOURCE_EDIT_STEP3,
  URL_RESOURCE_EDIT_STEP4,
  URL_RESOURCE_EDIT_STEP5,
  URL_RESOURCE_NEW,
  URL_RESOURCE_NEW_STEP1,
  URL_RESOURCE_NEW_STEP2,
  URL_PREVIEW_ANALYSIS_MULTI,
  URL_SETTING_LOG_DEFINE_NEW,
  URL_SETTING_LOG_DEFINE_EDIT,
  URL_SETTING_LOG_DEFINE_NEW_STEP2,
  URL_SETTING_LOG_DEFINE_EDIT_STEP2,
} from '@constants/URL';
import {
  E_STEP_ANALYSIS_SETTING,
  E_JOB_STEP_END,
  E_STEP_FILTER_SETTING,
  E_STEP_FUNC_SELECT_SETTING,
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_LOG_SELECT_SETTING,
  E_STEP_MULTI_ANALYSIS_SETTING,
  E_STEP_MULTI_VISUAL_SETTING,
  E_STEP_PATTERN_SETTING,
  E_STEP_TITLE_SETTING,
  E_STEP_VISUAL_SETTING,
  E_LOG_STEP_END,
  E_STEP_LOG_DEFINE_SETTING,
} from '@constants/etc';
import {
  AllMax30Regex,
  AllowMiddleLetterRegex,
  AnyRegex,
  coefRegex,
  FirstLetterRegex,
  NumberRegex,
  TitleRegex,
} from '@libs/util/regExp';

export const FunctionStep = [
  E_STEP_TITLE_SETTING,
  E_STEP_LOG_SELECT_SETTING,
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_ANALYSIS_SETTING,
  E_STEP_VISUAL_SETTING,
];

export const MultifunctionStep = [
  E_STEP_TITLE_SETTING,
  E_STEP_FUNC_SELECT_SETTING,
  E_STEP_MULTI_ANALYSIS_SETTING,
  E_STEP_MULTI_VISUAL_SETTING,
];

export const RuleStep = [
  E_STEP_LOG_DEFINE_SETTING,
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_FILTER_SETTING,
];

export const StepConfigure = {
  [E_STEP_TITLE_SETTING]: {
    description: JobStep.setting.title,
    preview: undefined,
    new: URL_RESOURCE_NEW_STEP1, //next
    edit: URL_RESOURCE_EDIT_STEP1, //next
  },
  [E_STEP_LOG_SELECT_SETTING]: {
    description: JobStep.setting.log,
    preview: URL_PREVIEW_SAMPLELOG,
    new: URL_RESOURCE_NEW_STEP2, //next
    edit: URL_RESOURCE_EDIT_STEP2, //next
  },
  [E_STEP_LOG_DEFINE_SETTING]: {
    description: JobStep.setting.log_define,
    preview: URL_PREVIEW_SAMPLELOG,
    new: URL_SETTING_LOG_DEFINE_NEW_STEP2, //next
    edit: URL_SETTING_LOG_DEFINE_EDIT_STEP2, //next
  },
  [E_STEP_FUNC_SELECT_SETTING]: {
    description: JobStep.setting.log,
    preview: URL_PREVIEW_SAMPLELOG,
    new: URL_RESOURCE_NEW_STEP2, //next
    edit: URL_RESOURCE_EDIT_STEP2, //next
  },
  [E_STEP_LOG_CONVERT_SETTING]: {
    description: JobStep.setting.define,
    preview: URL_PREVIEW_CONVERT,
    edit: URL_RESOURCE_EDIT_STEP3, //next
  },
  [E_STEP_FILTER_SETTING]: {
    description: JobStep.setting.filter,
    preview: URL_PREVIEW_FILTER,
    edit: URL_RESOURCE_EDIT_STEP4, //next
  },
  [E_STEP_ANALYSIS_SETTING]: {
    description: JobStep.setting.analysis,
    preview: URL_PREVIEW_ANALYSIS,
    edit: URL_RESOURCE_EDIT_STEP5, //next
  },
  [E_STEP_MULTI_ANALYSIS_SETTING]: {
    description: JobStep.setting.analysis,
    preview: URL_PREVIEW_ANALYSIS_MULTI,
    edit: URL_RESOURCE_EDIT_STEP5, //next
  },
  [E_STEP_VISUAL_SETTING]: {
    description: JobStep.setting.visualization,
    preview: undefined,
  },
  [E_STEP_MULTI_VISUAL_SETTING]: {
    description: JobStep.setting.visualization,
    preview: undefined,
  },
  [E_STEP_PATTERN_SETTING]: {
    description: JobStep.setting.pattern,
    preview: undefined,
  },
  [E_JOB_STEP_END]: {
    new: URL_RESOURCE_NEW,
    edit: URL_RESOURCE_EDIT,
  },
  [E_LOG_STEP_END]: {
    new: URL_SETTING_LOG_DEFINE_NEW,
    edit: URL_SETTING_LOG_DEFINE_EDIT,
  },
};

export const E_JOB_STEP = {
  STEP1_CATEGORY_ID: 'category_id',
  STEP1_TITLE: 'title',
  STEP2_RULE_NAME: 'rule_name',
  STEP2_LOG_NAME: 'log_name',
};

export const ConvertInfoListTable = [
  {
    title: JobStep.convert.info.table.columns.sort,
    dataIndex: 'sort',
  },
  {
    title: JobStep.convert.info.table.columns.idx,
    dataIndex: 'idx',
  },
  {
    title: JobStep.convert.info.table.columns.row,
    dataIndex: 'row_index',
  },
  {
    title: JobStep.convert.info.table.columns.data,
    dataIndex: 'data',
  },
  {
    title: JobStep.convert.info.table.columns.name,
    dataIndex: 'name',
  },
  {
    title: JobStep.convert.info.table.columns.output_column,
    dataIndex: 'output_column_val',
  },
  {
    title: JobStep.convert.info.table.columns.data_type,
    dataIndex: 'data_type',
  },
  {
    title: JobStep.convert.info.table.columns.def_val,
    dataIndex: 'def_type',
  },
  {
    title: JobStep.convert.info.table.columns.delete,
    dataIndex: 'delete',
  },
  {
    title: JobStep.convert.info.table.columns.skip,
    dataIndex: 'skip',
  },
];
export const DEFINE_INFO_TYPE = 'info';
export const DEFINE_HEADER_TYPE = 'header';
export const DEFINE_CUSTOM_TYPE = 'custom';

export const ColumnInfoList = [
  'name',
  'output_column',
  'output_column_val',
  'data_type',
  'def_val',
  'def_type',
  'row_index',
];
export const ColumnHeaderList = [
  'name',
  'output_column',
  'output_column_val',
  'data_type',
  'def_val',
  'def_type',
  'coef',
  'unit',
];
export const ColumnCustomList = [
  'name',
  'output_column',
  'output_column_val',
  'data_type',
  'def_val',
  'def_type',
];

export const ConvertColumn = {
  [DEFINE_INFO_TYPE]: ColumnInfoList,
  [DEFINE_HEADER_TYPE]: ColumnHeaderList,
  [DEFINE_CUSTOM_TYPE]: ColumnCustomList,
};

export const inputCommonValidator = (name) => {
  let info = { status: '', errMsg: undefined };
  if (!(name?.trim()?.length ?? 0)) {
    info.status = 'error';
  } else if (!FirstLetterRegex.test(name.trim())) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.first_letter;
  } else if (!AllowMiddleLetterRegex.test(name.trim())) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.arrow_letter;
  } else if (!AllMax30Regex.test(name.trim())) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.limit_letter;
  }
  return info;
};
export const analysisTitleValidator = (name) => {
  let info = { status: '', errMsg: undefined };
  if (!(name?.trim()?.length ?? 0)) {
    info.status = 'error';
  } else if (!FirstLetterRegex.test(name.trim())) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.first_letter;
  } else if (!TitleRegex.test(name.trim())) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.analysis_input_letter;
  } else if (!AllMax30Regex.test(name.trim())) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.limit_letter;
  }
  return info;
};

export const analysisSequentialValidator = (name) => {
  let info = { status: '', errMsg: undefined };
  if (!(name?.trim()?.length ?? 0)) {
    info.status = 'error';
  } else {
    const availableChar = [
      'delta',
      'inv',
      'abs',
      'max',
      'ave',
      '3sigma',
      'range',
      'count',
      'min',
      'nunique',
      'sum',
    ];
    name.split('.').forEach((str) => {
      if (!availableChar.includes(str)) {
        info.status = 'error';
        info.errMsg = JobStep.err.tooltip.analysis_sequential_letters;
      }
    });
  }
  return info;
};

export const allAllowValidator = (name) => {
  let info = { status: '', errMsg: undefined };
  if (!(name?.trim()?.length ?? 0)) {
    info.status = 'error';
  } else if (!AnyRegex.test(name?.trim() ?? '')) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.first_letter;
  }
  return info;
};
export const AllMax30Validator = (name) => {
  let info = { status: '', errMsg: undefined };
  if (!(name?.trim()?.length ?? 0)) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.required_letter;
  } else if (!AllMax30Regex.test(name.trim())) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.limit_letter;
  }
  return info;
};

export const CoefficientValidator = (number) => {
  let info = { status: '', errMsg: undefined };
  if (!(number + '').length) {
    info.status = 'error';
  } else if (!coefRegex.test(number)) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.coef;
  }
  return info;
};

export const NumberValidator = (number) => {
  let info = { status: '', errMsg: undefined };
  if (!(number + '').length) {
    info.status = 'error';
  } else if (!NumberRegex.test(number)) {
    info.status = 'error';
    info.errMsg = JobStep.err.tooltip.number;
  }
  return info;
};
