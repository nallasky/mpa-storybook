import { MSG_LOCAL, MSG_REMOTE } from './Message';
import {
  AlignLeftOutlined,
  BarChartOutlined,
  DotChartOutlined,
  TableOutlined,
  StockOutlined,
} from '@ant-design/icons';
import React from 'react';
import {
  E_CPVS_ADC_MEASUREMENT,
  E_CPVS_CORRECTION,
  E_OVERLAY_ANOVA,
  E_OVERLAY_COMPONENT,
  E_OVERLAY_IMAGE,
  E_OVERLAY_MAP,
  E_OVERLAY_PLOT,
  E_OVERLAY_REPRODUCIBILITY,
  E_OVERLAY_VARIATION,
  OVERLAY_ADC_CATEGORY,
  OVERLAY_OAS_BASELINE_CATEGORY,
} from './etc';

export const overlay_source = [MSG_LOCAL, MSG_REMOTE];

export const OVERLAY_MAP = {
  id: E_OVERLAY_MAP,
  title: 'Map',
  icon: <TableOutlined />,
  enable: (origin) => {
    if (origin?.data || origin?.map) {
      console.log('E_OVERLAY_MAP - origin', origin);
      return true;
    }
    return false;
  },
};

export const OVERLAY_PLOT = {
  id: E_OVERLAY_PLOT,
  title: 'Plot',
  icon: <StockOutlined />,
  enable: (origin) => {
    if (origin?.baseline && Object.keys(origin?.baseline ?? {}).length) {
      console.log('E_OVERLAY_PLOT - origin?.baseline', origin?.baseline);
      return true;
    }
    return false;
  },
};

export const OVERLAY_VARIATION = {
  id: E_OVERLAY_VARIATION,
  title: 'Variation',
  icon: <DotChartOutlined />,
  enable: (origin) => {
    if (origin?.variation || origin?.data) {
      console.log(
        'E_OVERLAY_VARIATION - origin.variation || origin.data',
        origin?.variation,
        origin?.data,
      );
      return true;
    }
    return false;
  },
};
export const OVERLAY_REPRODUCIBILITY = {
  id: E_OVERLAY_REPRODUCIBILITY,
  title: 'Reproducibility',
  icon: <BarChartOutlined />,
  enable: (origin) => {
    if (origin?.reproducibility) {
      console.log(
        'OVERLAY_REPRODUCIBILITY - origin.reproducibility',
        origin?.reproducibility,
      );
      return true;
    }
    return false;
  },
};
export const OVERLAY_ANOVA = {
  id: E_OVERLAY_ANOVA,
  title: 'Anova',
  icon: <AlignLeftOutlined />,
  enable: (origin) => {
    if (origin?.anova) {
      console.log('OVERLAY_ANOVA - origin.anova', origin?.anova);
      return true;
    }
    return false;
  },
};
export const OVERLAY_IMAGE_MAP = {
  id: E_OVERLAY_IMAGE,
  title: 'Correction Image Map',
  icon: <TableOutlined />,
  enable: (origin) => {
    if (origin?.data?.map || origin?.data?.correction_image) {
      const { data } = origin;

      console.log(
        'E_OVERLAY_IMAGE - data.map, data.correction_image',
        data.map,
        data.correction_image,
      );
      return true;
    }
    return false;
  },
};
export const OVERLAY_COMPONENT_MAP = {
  id: E_OVERLAY_COMPONENT,
  title: 'Correction Component Map',
  icon: <TableOutlined />,
  enable: (origin) => {
    const { data } = origin;
    if (data?.adc_correction || data?.stage_correction) {
      console.log(
        'E_OVERLAY_IMAGE - data.map, data.correction_image',
        data.adc_correction,
        data.stage_correction,
      );
      return true;
    }
    return false;
  },
};

export const OVERLAY_CPVS_ADC_MEASUREMENT = {
  id: E_CPVS_ADC_MEASUREMENT,
  title: 'ADC Measurement',
  icon: undefined,
  enable: (origin) => {
    if (origin) {
      console.log('OVERLAY_REPRODUCIBILITY - origin.reproducibility', origin);
      return true;
    }
    return false;
  },
};

export const OVERLAY_CPVS_CORRECTION = {
  id: E_CPVS_CORRECTION,
  title: 'Correction component of exposure',
  icon: undefined,
  enable: (origin) => {
    if (origin) {
      console.log('OVERLAY_REPRODUCIBILITY - origin.reproducibility', origin);
      return true;
    }
    return false;
  },
};

export const OVERLAY_ADC_TYPE_LIST = [
  OVERLAY_MAP,
  OVERLAY_VARIATION,
  OVERLAY_REPRODUCIBILITY,
  OVERLAY_ANOVA,
];
export const OVERLAY_CORRECTION_TYPE_LIST = [
  OVERLAY_IMAGE_MAP,
  OVERLAY_COMPONENT_MAP,
];

export const OVERLAY_OAS_BASELINE_TYPE_LIST = [OVERLAY_PLOT, OVERLAY_MAP];

export const OVERLAY_CORRECTION_CPVS_LIST = [
  OVERLAY_CPVS_ADC_MEASUREMENT,
  OVERLAY_CPVS_CORRECTION,
];
export const CPVS_MODE = {
  FROM_LOG: 'from_log',
  EACH: 'each_shot',
  SAME: 'reflect_all',
};
export const CPVS_DISP = {
  P1_P2_P3: 'P1&P2&P3',
  P1_P2: 'P1&P2',
  P2_P3: 'P2&P3',
  P2_ONLY: 'P2 Only',
  NONE: 'None',
};
export const CPVS_BASELINE_DISP = {
  FRONT_BACK: 'Back&Front',
  BACK: 'Back',
  FRONT: 'Front',
  NONE: 'None',
};
export const CP_VS_DISPLAY_LIST = [
  CPVS_DISP.P1_P2_P3,
  CPVS_DISP.P1_P2,
  CPVS_DISP.P2_P3,
  CPVS_DISP.P2_ONLY,
  CPVS_DISP.NONE,
];
export const CP_VS_BASELINE_DISPLAY_LIST = [
  CPVS_BASELINE_DISP.FRONT_BACK,
  CPVS_BASELINE_DISP.BACK,
  CPVS_BASELINE_DISP.FRONT,
  CPVS_BASELINE_DISP.NONE,
];

export const CP_VS_DISPLAY_OPTION = {
  [CPVS_DISP.P1_P2_P3]: 0,
  [CPVS_DISP.P1_P2]: 1,
  [CPVS_DISP.P2_P3]: 2,
  [CPVS_DISP.P2_ONLY]: 3,
  [CPVS_DISP.NONE]: 4,
  [CPVS_BASELINE_DISP.FRONT_BACK]: 0,
  [CPVS_BASELINE_DISP.BACK]: 1,
  [CPVS_BASELINE_DISP.FRONT]: 2,
  [CPVS_BASELINE_DISP.NONE]: 4,
};

export const OVERLAY_OFFSET_RESET = {
  x: 0,
  y: 0,
};
const PLUS_880 = `880.000000`;
const PLUS_735 = `735.000000`;
const PLUS_440 = `440.000000`;
const PLUS_200 = `200`;
const MINUS_735 = `-735.000000`;
const MINUS_440 = `-440.000000`;
export const OVERLAY_CPVS_MIN_MAX = {
  cp1: {
    min: MINUS_735,
    max: PLUS_735,
  },
  cp1d: {
    min: MINUS_735,
    max: PLUS_735,
  },
  cp12d: {
    min: MINUS_735,
    max: PLUS_735,
  },
  cp21d: {
    min: MINUS_735,
    max: PLUS_735,
  },
  cp2: {
    min: MINUS_735,
    max: PLUS_735,
  },
  cp23d: {
    min: MINUS_735,
    max: PLUS_735,
  },
  cp32d: {
    min: MINUS_735,
    max: PLUS_735,
  },
  cp3: {
    min: MINUS_735,
    max: PLUS_735,
  },
  inside_vs: {
    min: 0,
    max: PLUS_200,
  },
  vs1: {
    min: 0,
    max: PLUS_880,
  },
  vs1l: {
    min: MINUS_440,
    max: PLUS_440,
  },
  vs1r: {
    min: MINUS_440,
    max: PLUS_440,
  },
  vs2: {
    min: 0,
    max: PLUS_880,
  },
  vs2l: {
    min: MINUS_440,
    max: PLUS_440,
  },
  vs2r: {
    min: MINUS_440,
    max: PLUS_440,
  },
  vs3: {
    min: 0,
    max: PLUS_880,
  },
  vs3l: {
    min: MINUS_440,
    max: PLUS_440,
  },
  vs3r: {
    min: MINUS_440,
    max: PLUS_440,
  },
  vs4l: {
    min: MINUS_440,
    max: PLUS_440,
  },
  vs4r: {
    min: MINUS_440,
    max: PLUS_440,
  },
  vsc: {
    min: MINUS_440,
    max: PLUS_440,
  },
  front: {
    min: MINUS_735,
    max: PLUS_735,
  },
  back: {
    min: MINUS_735,
    max: PLUS_735,
  },
  vs_front: {
    min: 0,
    max: PLUS_880,
  },
  vs_back: {
    min: 0,
    max: PLUS_880,
  },
};

export const OVERLAY_SOURCE = [
  { label: MSG_LOCAL, value: MSG_LOCAL },
  { label: MSG_REMOTE, value: MSG_REMOTE },
];

export const OVERLAY_OAS_SOURCE_FILE_LIST = [
  OVERLAY_ADC_CATEGORY,
  OVERLAY_OAS_BASELINE_CATEGORY,
  'unknown',
];

export const OVERLAY_TARGET_AE_CORRECTION = [
  { label: 'Off', value: 'off' },
  { label: 'Shift/RotCorrection', value: 'mode0' },
  { label: 'Shift/RotCorrection/MagCorrection', value: 'mode1' },
];
export const ANOVA_LIST = ['X', 'Y'];
