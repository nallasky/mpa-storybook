import { useEffect } from 'react';
import { Pages } from './pages';
import useCommonInfo from '@hooks/common/useCommonInfo';

const App = () => {
  const { initCommonSetting } = useCommonInfo();

  useEffect(() => {
    initCommonSetting();
  }, []);

  return <Pages />;
};

export default App;
