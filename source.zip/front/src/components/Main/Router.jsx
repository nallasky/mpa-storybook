import React, { useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBinoculars } from '@fortawesome/free-solid-svg-icons';
import AppLayout from '../common/templates/mainLayout';
import NaviBar from '../common/molecules/Navibar/NaviBar';
import { css } from '@emotion/react';
import VersionInfo from '../common/atoms/Version';
import Button from '../common/atoms/Button/Button';
import MgmtPage from '../Mgmt';
import { Spin } from 'antd';
import { Switch, Route } from 'react-router-dom';
import Error from '../Error';
import useCommonJob from '../../hooks/common/useBasicInfo';
import { ANALYSIS, EDIT, MAIN, NEW, OVERLAY, TACT } from '../../constants/URL';
import JobStep from '../JobStep/JobStep';
import ResultMain from '../JobAnalysis/ResultMain';
import MainPage from './Main';
import { useQuery } from 'react-query';
import { QUERY_KEY } from '../../constants/QueryKey';
import Job from '../JobSetting/job';
import {
  getMainResourceInfo,
  getMainVersionInfo,
} from '../../libs/axios/mainRequest';
import NotificationBox from '../common/molecules/NotificationBox/Notification';
import { Overlay } from '../../pages/overlay';
import { Tact } from '../../pages/tact';
import ModalProvider from '../../libs/util/modalControl/ModalProvider';
import { default as QuickViewModal } from '../../libs/util/modalControl/Modal';

const titleStyle = css`
  color: black;
  z-index: 300;
  font-weight: 400;
  font-size: 44px;
  text-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  margin-bottom: 22px;
  margin-top: 22px;
`;

const buttonWrapper = css`
  position: fixed;
  bottom: 110px;
  right: 50px;
  z-index: 300;
`;

const loadingWrapper = css`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`;

const Router = () => {
  const {
    setBasicInfo,
    versionInfo,
    MenuInfo,
    showMgmt,
    openMgmtPage,
    closeMgmtPage,
    initCommonSetting,
    setSupportUrl,
    setCategories,
    categoryList,
    getUrl,
  } = useCommonJob();

  const {
    error: MainError,
    isLoading: isMainLoading,
    isFetching: isMainReLoading,
  } = useQuery([QUERY_KEY.MAIN_INIT], getMainResourceInfo, {
    onSuccess: (info) => {
      setSupportUrl(getUrl({ body: info.body }));
      setBasicInfo(null, info);
      setCategories(categoryList(info?.body));
    },
    onError: (error) => {
      NotificationBox('ERROR', error.message, 4.5);
    },
  });
  const { error: VersionError, isLoading: isVersionLoading } = useQuery(
    [QUERY_KEY.VERSION_INIT],
    getMainVersionInfo,
    {
      onSuccess: (info) => {
        setBasicInfo(info, null);
      },
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
    },
  );

  useEffect(() => {
    initCommonSetting();
  }, []);

  if (isVersionLoading || isMainLoading || isMainReLoading)
    return (
      <div css={loadingWrapper}>
        <Spin tip="Loading..." size="large" />
      </div>
    );

  if (MainError || VersionError)
    return (
      <div>
        <p>error occurred</p>
        <p>{VersionError?.message ?? MainError?.message ?? 'ERROR'}</p>
      </div>
    );

  if (versionInfo === '' || MenuInfo === '') return <div>no data</div>;

  const { title, footer } = MenuInfo;

  return (
    <ModalProvider>
      <AppLayout>
        <AppLayout.Header>
          <p css={titleStyle}>{title}</p>
          <NaviBar />
        </AppLayout.Header>
        <AppLayout.Content>
          <Switch>
            <Route exact path={MAIN} component={MainPage} />
            <Route path={ANALYSIS} component={ResultMain} />
            <Route
              path={[`${NEW}/:type/:category_id`, `${EDIT}/:type/:func_id`]}
              component={JobStep}
            />
            <Route path={OVERLAY} component={Overlay} />
            <Route path={TACT} component={Tact} />
            <Route path={MAIN} component={Error.notfound} />
          </Switch>
        </AppLayout.Content>
        <AppLayout.Footer>
          <VersionInfo footer={footer} info={versionInfo} />
        </AppLayout.Footer>
        <div css={buttonWrapper}>
          <Button iconOnly size="md" onClick={openMgmtPage}>
            <FontAwesomeIcon icon={faBinoculars} />
          </Button>
        </div>
        <MgmtPage show={showMgmt} closeFunc={closeMgmtPage} />
        <Job />
      </AppLayout>
      <QuickViewModal />
    </ModalProvider>
  );
};

export default Router;
