export { default as MainPage } from './Main';
