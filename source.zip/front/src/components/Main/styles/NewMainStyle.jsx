import { css } from '@emotion/react';
import SubItem from '@assets/SubItem.svg';

export const MainBody = css`
  & > .grid {
    display: grid;
    width: 100%;
    grid-template-columns: 1fr 1fr;
    height: 200px;
    padding: 0rem 3rem;
    & > div {
      margin: auto 0;
      & > .title-text {
        font-family: 'Poppins';
        font-style: normal;
        font-weight: 600;
        font-size: 60px;
        line-height: 90px;
        text-transform: capitalize;
        color: var(--ckr-purple-10);
      }
      & > .title-text-sub {
        font-family: 'Poppins';
        font-style: normal;
        font-weight: 700;
        font-size: 60px;
        line-height: 90px;
        text-transform: capitalize;
        color: var(--ckr-orange-3);
      }
      & > .text {
        font-family: 'Saira';
        font-style: normal;
        font-weight: 400;
        font-size: 16px;
        line-height: 30px;
        text-transform: capitalize;
        color: var(--ckr-gray-7);
        white-space: pre-wrap;
      }
    }
  }
  & .ant-btn-primary {
    color: var(--ckr-gray-1);
    border-color: var(--ckr-orange-6);
    background: var(--ckr-orange-6);
    width: 215px;
    border-radius: 4px;
    &:hover {
      background: var(--ckr-orange-5);
      border-color: var(--ckr-orange-5);
    }
  }
`;
export const ItemBody = css`
  position: relative;
  padding: 0rem 3rem;
  & > div > .item-button {
    position: absolute;
    top: 66px;
    height: 213px;
    font-size: 30px;
    border: none;
    cursor: pointer;
    z-index: 2;
    transition: all 0.3s;
    background-color: transparent;
    & > span {
      transition: all 0.3s;
    }
    &:hover:not(:disabled) {
      & > span {
        color: var(--ckr-gray-7);
      }
    }
    &.left {
      left: 47px;
      width: 62px;
    }
    &.right {
      right: 47px;
      width: 62px;
    }
    &:disabled {
      color: transparent;
      cursor: default;
    }
  }
  & .carousel-box {
    padding: 0 3rem;
    & > .carousel-wrapper {
      position: relative;
      width: 100%;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      & > .quick-move-wrapper {
        display: none;
        width: 100%;
        justify-content: center;
        align-items: center;
        column-gap: 0.4rem;
        &.show {
          display: flex;
        }
        & > button {
          border: none;
          border-radius: 50%;
          padding: 0.3rem;
          background-color: var(--ckr-gray-6);
          cursor: pointer;
          transition: all 0.3s;
          &.selected {
            background-color: var(--ckr-purple-10);
          }
        }
      }
    }
  }
  & button.item {
    transition: all 0.2s;
    &:active {
      &:nth-of-type(1) {
        transform: translateY(10px);
        border: 2px solid var(--ckr-blue-3);
      }
      &:nth-of-type(2) {
        transform: translateY(10px);
        border: 2px solid var(--ckr-geekblue-3);
      }
    }
    &.selected {
      &:nth-of-type(3) {
        transform: translateY(10px);
        border-color: var(--ckr-volcano-3);
        box-shadow: none;
      }
      &:nth-of-type(4) {
        transform: translateY(10px);
        border-color: var(--ckr-green-3);
        box-shadow: none;
      }
      &:nth-of-type(5) {
        transform: translateY(10px);
        border-color: var(--ckr-cyan-3);
        box-shadow: none;
      }
    }
  }
  & button.sub-item {
    &:hover {
      border: 1px solid var(--ckr-blue-6);
    }
  }
  & .title {
    font-family: 'Poppins';
    font-weight: 600;
    font-size: 32px;
    text-transform: capitalize;
  }
  & .itemBox {
    display: flex;
    padding: 1rem 0 1.5rem 0;
    z-index: 1;
    position: relative;
    transition: all 0.3s ease-in-out;
    & .item {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 37px 14px;
      gap: 12px;
      width: 219px;
      box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
      border-radius: 10px;
      border: 2px solid transparent;
      cursor: pointer;
      position: relative;
      flex-shrink: 0;
      margin: 0px 15.3px;
      &:hover {
        &:nth-of-type(1) {
          background: #f0faff;
          border: 2px solid var(--ckr-blue-3);
        }
        &:nth-of-type(2) {
          background: #f5f8ff;
          border: 2px solid var(--ckr-geekblue-3);
        }
        &:nth-of-type(3) {
          background: #fff8f2;
          border: 2px solid var(--ckr-volcano-3);
          &::after {
            background: #fff8f2;
          }
        }
        &:nth-of-type(4) {
          background: #fbfff7;
          border: 2px solid var(--ckr-green-3);
          &::after {
            background: #fbfff7;
          }
        }
        &:nth-of-type(5) {
          background: #f0fffd;
          border: 2px solid var(--ckr-cyan-3);
          &::after {
            background: #f0fffd;
          }
        }
      }
      &.selected {
        &::after {
          display: block;
          box-shadow: none;
        }
      }
      &:after {
        position: absolute;
        display: none;
        left: 96px;
        top: 198px;
        width: 20px;
        height: 20px;
        transform: rotate(45deg);
        box-shadow: 3px 3px 3px -1px rgba(0, 0, 0, 0.25);
        content: '';
        transition: all 0.2s;
      }
      &:nth-of-type(3) {
        &::after {
          background-color: var(--ckr-volcano-1);
          border: 2px solid var(--ckr-volcano-1);
        }
        &.selected {
          &::after {
            border-color: transparent var(--ckr-volcano-3) var(--ckr-volcano-3)
              transparent;
          }
        }
      }
      &:nth-of-type(4) {
        &::after {
          background-color: var(--ckr-green-1);
          border: 2px solid var(--ckr-green-1);
        }
        &.selected {
          &::after {
            border-color: transparent var(--ckr-green-3) var(--ckr-green-3)
              transparent;
          }
        }
      }
      &:nth-of-type(5) {
        &::after {
          background-color: var(--ckr-cyan-1);
          border: 2px solid var(--ckr-cyan-1);
        }
        &.selected {
          &::after {
            border-color: transparent var(--ckr-cyan-3) var(--ckr-cyan-3)
              transparent;
          }
        }
      }
      &:nth-of-type(1) {
        background: var(--ckr-blue-1);
      }
      &:nth-of-type(2) {
        background: var(--ckr-geekblue-1);
      }
      &:nth-of-type(3) {
        background: var(--ckr-volcano-1);
        &::after {
          border-color: var(--ckr-volcano-1);
        }
      }
      &:nth-of-type(4) {
        background: var(--ckr-green-1);
        &::after {
          border-color: var(--ckr-green-1);
        }
      }
      &:nth-of-type(5) {
        background: var(--ckr-cyan-1);
        &::after {
          border-color: var(--ckr-cyan-1);
        }
      }
    }
  }
  & .item-name {
    font-family: 'Poppins';
    font-style: normal;
    font-weight: 600;
    font-size: 25px;
    line-height: 180%;
    text-align: center;
  }
  & .item-number {
    font-family: 'Poppins';
    font-weight: 500;
    position: absolute;
    bottom: 14px;
    color: var(--ckr-gray-7);
  }
  & .list-item {
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: flex-start;
    padding: 1rem 3rem;
    background: var(--ckr-volcano-1);
    border: 1px solid var(--ckr-volcano-3);
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
    border-radius: 20px;
    & .list-title {
      font-family: 'Poppins';
      font-size: 25px;
      font-weight: bold;
    }
    & > .carousel-sub-wrapper {
      margin-top: 25px;
      position: relative;
      width: 100%;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      row-gap: 0.5rem;
      align-items: center;
      & > .quick-move-wrapper {
        width: 500px;
        display: flex;
        justify-content: center;
        align-items: center;
        column-gap: 0.4rem;
        & > button {
          border: none;
          border-radius: 50%;
          padding: 0.3rem;
          background-color: var(--ckr-gray-6);
          cursor: pointer;
          transition: all 0.3s;
          &.selected {
            background-color: var(--ckr-purple-10);
          }
        }
      }
    }
    & > .carousel-button {
      position: absolute;
      top: 81px;
      height: 150px;
      font-size: 30px;
      border: none;
      background-color: var(--ckr-cyan-1);
      color: var(--ckr-purple-10);
      cursor: pointer;
      z-index: 1;
      transition: all 0.3s;
      & > span {
        transition: all 0.3s;
      }
      &:hover:not(:disabled) {
        & > span {
          color: var(--ckr-gray-7);
        }
      }
      &.right {
        right: 30px;
      }
      &.left {
        left: 30px;
      }
      &:disabled {
        color: transparent;
        cursor: default;
      }
    }
  }
  & .overlay-color {
    opacity: 1;
    background: var(--ckr-green-1);
    border: 1px solid var(--ckr-green-3);
  }
  & .Focus-color {
    opacity: 1;
    background: var(--ckr-cyan-1);
    border: 1px solid var(--ckr-cyan-3);
  }
  & .sub-item-box {
    position: relative;
    display: flex;
    width: 100%;
    transition: all 0.3s;
  }
  & .sub-item {
    width: 150px;
    height: 150px;
    background-image: url(${SubItem});
    background-repeat: no-repeat;
    background-position: 50% 6px;
    background-size: 100px;
    box-shadow: 0px 8px 15px rgba(140, 152, 164, 0.1);
    border-radius: 4px;
    position: relative;
    cursor: pointer;
    justify-self: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    margin: 0 29px;
    flex-shrink: 0;
    & > span {
      display: flex;
      align-items: center;
      height: 50%;
      &:first-of-type {
        font-size: 40px;
      }
      &:last-of-type {
        font-family: 'Poppins';
        font-weight: 600;
        white-space: break-spaces;
      }
    }
  }
  & .ant-btn > .anticon + span {
    margin-left: 0px;
  }
`;
