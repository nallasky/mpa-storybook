import { css } from '@emotion/react';

export const itemIconStyle = css`
  position: absolute;
  top: 15px;
  left: 25px;
  & > span {
    color: var(--ckr-gray-13);
  }
  & > img {
    height: 32px;
  }
`;

export const MenuBarWrapper = css`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
`;
export const MenuButton = css`
  font-weight: 400;
  margin-left: 8px;
`;

export const itemWrapper = css`
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  grid-template-rows: auto;
  gap: 2rem;
  justify-items: center;
  margin: 2rem 0;
`;
export const deleteModalWrapper = css`
  height: 50px;
  display: flex;
  justify-content: center;
  padding: 15px;
`;
