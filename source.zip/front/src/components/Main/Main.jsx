import React, { useState, useRef } from 'react';
import * as SS from './styles/NewMainStyle';
import { Button } from 'antd';
import PropTypes from 'prop-types';
import {
  SettingOutlined,
  LeftCircleFilled,
  RightCircleFilled,
} from '@ant-design/icons';
import ItemIcon from '@assets/ItemIcon.svg';
import { CONFIGURATION } from '@constants/URL';
import { useNavigate } from 'react-router-dom';
import { Main as message, Common as commonMsg } from '@assets/locale/en';
import { fixedTopMenu } from '@constants/FixedMenu';
import useModal from '@libs/util/modalControl/useModal';

const moveItem = (v) => `
  transform: translateX(calc(-100% * ${v}));
`;

const MainTitle = ({ navigate }) => {
  return (
    <div className="grid">
      <div>
        <span className="title-text">{message.main.title.text}</span>
        <br />
        <span className="title-text-sub">{message.main.title.text_sub}</span>
      </div>
      <div>
        {message.main.sub_title.map((msg, i) => (
          <>
            <span className="text" key={i}>
              {msg}
            </span>
            <br />
          </>
        ))}
        <div style={{ marginTop: '10px' }}>
          <Button
            type="primary"
            icon={<SettingOutlined />}
            onClick={() => navigate(CONFIGURATION)}
          >
            {message.main.configuration.title}
          </Button>
        </div>
      </div>
    </div>
  );
};
MainTitle.propTypes = {
  navigate: PropTypes.func,
};

const Main = () => {
  const [mode, setMode] = useState('');
  const [moveValue, setMoveValue] = useState(0);
  const [moveSubValue, setMoveSubValue] = useState(0);
  const navigate = useNavigate();
  const outSection = useRef();
  const { openModal } = useModal();

  const onClickEvent = (sMode) => {
    const selectObj = fixedTopMenu[sMode];
    setMode(mode !== sMode ? sMode : '');
    if (selectObj?.component ?? false) {
      openModal(selectObj?.component, {});
    } else if (
      selectObj.children === undefined &&
      (selectObj?.func_id ?? false)
    ) {
      navigate(selectObj?.func_id);
    }
  };
  console.log('test ===>>' + [mode]);
  return (
    <div css={SS.MainBody}>
      <MainTitle navigate={navigate} />
      <div css={SS.ItemBody}>
        <div>
          {Object.keys(fixedTopMenu).length > 5 && (
            <>
              <button
                className="item-button left"
                onClick={() => setMoveValue(moveValue - 1)}
                disabled={moveValue === 0}
              >
                <LeftCircleFilled />
              </button>
              <button
                className="item-button right"
                onClick={() => setMoveValue(moveValue + 1)}
                disabled={
                  Math.round(Object.keys(fixedTopMenu).length / 5) === moveValue
                }
              >
                <RightCircleFilled />
              </button>
            </>
          )}
          <div className="title">{message.service.title}</div>
          <div className="carousel-box">
            <div className="carousel-wrapper">
              <div css={() => moveItem(moveValue)} className="itemBox">
                {Object.keys(fixedTopMenu).map((sMode, idx) => {
                  const menu = fixedTopMenu[sMode];
                  const pushButton =
                    mode === 'tact' || mode === 'overlay' || mode === 'Focus';
                  return (
                    <button
                      className={
                        'item' +
                        (pushButton && mode === sMode ? ' selected' : '')
                      }
                      onClick={() => {
                        setMoveValue(0);
                        onClickEvent(sMode);
                      }}
                      key={idx}
                      tabIndex="-1"
                    >
                      <img src={ItemIcon} />
                      <span className="item-name">{menu.title}</span>
                      {(menu?.children ?? false) && (
                        <span className="item-number">
                          {menu?.children ?? false
                            ? menu.children.length
                            : 'XX'}{' '}
                          {commonMsg.items}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
              {Object.keys(fixedTopMenu).length > 5 && (
                <div
                  className={
                    'quick-move-wrapper' + (mode === '' ? ' show' : '')
                  }
                >
                  {Object.keys(fixedTopMenu)
                    .reduce(
                      (acc, _, idx) => (idx % 5 === 0 ? [...acc, idx] : acc),
                      [],
                    )
                    .map((_, index) => (
                      <button
                        key={index}
                        tabIndex="-1"
                        className={moveValue === index ? 'selected' : ''}
                        onClick={() => setMoveValue(index)}
                      />
                    ))}
                </div>
              )}
            </div>
          </div>
        </div>
        {(fixedTopMenu[mode]?.children ?? false) && (
          <div
            className={`list-item ${mode}-color`}
            ref={outSection}
            onClick={(e) => {
              if (outSection.current === e.target) {
                setMode('');
              }
            }}
          >
            {fixedTopMenu[mode].children.length > 6 && (
              <>
                <button
                  className="carousel-button left"
                  onClick={() => setMoveSubValue(moveSubValue - 1)}
                  disabled={moveSubValue === 0}
                >
                  <LeftCircleFilled />
                </button>
                <button
                  className="carousel-button right"
                  onClick={() => setMoveSubValue(moveSubValue + 1)}
                  disabled={
                    Math.round(fixedTopMenu[mode].children.length / 6) ===
                    moveSubValue
                  }
                >
                  <RightCircleFilled />
                </button>
              </>
            )}
            <div>
              <span className="list-title">{fixedTopMenu[mode].title}</span>
            </div>
            <div className="carousel-sub-wrapper">
              <div css={() => moveItem(moveSubValue)} className="sub-item-box">
                {fixedTopMenu[mode].children.map((child, idx) => (
                  <Button
                    className="sub-item"
                    onClick={() => navigate(child.func_id)}
                    key={idx}
                    tabIndex="-1"
                  >
                    {child.icon}
                    <span>{child.title}</span>
                  </Button>
                ))}
              </div>
              {fixedTopMenu[mode].children.length > 6 && (
                <div className="quick-move-wrapper">
                  {fixedTopMenu[mode].children
                    .reduce(
                      (acc, _, idx) => (idx % 6 === 0 ? [...acc, idx] : acc),
                      [],
                    )
                    .map((_, index) => (
                      <button
                        key={index}
                        tabIndex="-1"
                        className={moveSubValue === index ? 'selected' : ''}
                        onClick={() => setMoveSubValue(index)}
                      />
                    ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
export default Main;
