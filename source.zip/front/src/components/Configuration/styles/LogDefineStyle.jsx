import { css } from '@emotion/react';

export const LogDefineStyle = css`
  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
  & ::-webkit-scrollbar {
    width: 10px;
  }
  & ::-webkit-scrollbar-thumb {
    background-color: var(--ckr-blue-6);
    border-radius: 10px;
    background-clip: padding-box;
    border: 2px solid transparent;
  }
  & ::-webkit-scrollbar-track {
    background-color: var(--ckr-blue-3);
    border-radius: 10px;
    box-shadow: inset 0px 0px 5px white;
  }
  & > .box-group {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-template-rows: auto;
    gap: 1rem;
    padding: 1rem;
    & > .box-group-box {
      width: 459px;
      background-color: var(--ckr-gray-1);
      padding: 1rem;
      border-radius: 10px;
      & > div + div {
        margin-top: 10px;
      }
      & > .title-wrapper {
        & > .box-title {
          font-family: 'Poppins';
          font-size: 18px;
          font-weight: bold;
          color: var(--ckr-blue-6);
        }
        & > .box-sub {
          display: flex;
          justify-content: space-between;
          margin-bottom: 10px;
          align-items: center;
          & > div:first-of-type {
            display: flex;
            column-gap: 5px;
          }
          & .number-label {
            &::after {
              display: inline-block;
              content: ':';
            }
          }
          & .number-value-label {
            color: var(--ckr-blue-6);
          }
        }
      }
      & > .box-simply-ContentGroup {
        display: flex;
        border-top: 2px solid var(--ckr-gray-4);
        padding: 1rem;
        flex-wrap: wrap;
        max-height: 160px;
        overflow: auto;
        animation: fade-in 1s linear;
        & > div:first-of-type {
          margin-left: 0px;
        }
        & > div:nth-of-type(5n + 1) {
          margin-left: 0px;
        }
        & > .simply-content {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          width: calc(100% / 5 + 8px);
          height: 60px;
          background-color: var(--ckr-blue-6);
          color: var(--ckr-gray-1);
          border: 2px solid var(--ckr-gray-1);
          border-radius: 45%;
          margin-left: -10px;
          & > span {
            font-size: 16px;
          }
        }
        & > .simply-content-plus {
          width: calc(100% / 5 + 8px);
          height: 60px;
          background-color: var(--ckr-gray-6);
          color: var(--ckr-gray-1);
          border: 2px solid var(--ckr-gray-1);
          border-radius: 45%;
          margin-left: -10px;
          & > span {
            font-size: 25px;
            color: var(--ckr-gray-10);
          }
          &:hover {
            background-color: var(--ckr-gray-5);
            & > span {
              color: var(--ckr-gray-1);
            }
          }
        }
      }
      & > .box-detail-Content-group {
        border-top: 2px solid var(--ckr-gray-4);
        padding: 1rem;
        max-height: 330px;
        overflow: auto;
        animation: fade-in 1s linear;
        & > .detail-content {
          display: grid;
          grid-template-columns: 8fr 2fr;
          & + .detail-content {
            margin-top: 0.7rem;
          }
          & > div {
            display: flex;
            gap: 10px;
            align-items: center;
          }
          & .box-label {
            align-self: center;
            width: 230px;
            text-overflow: ellipsis;
            overflow: hidden;
          }
          & .detail-icon {
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            width: 70px;
            height: 50px;
            background-color: var(--ckr-blue-6);
            color: var(--ckr-gray-1);
            border-radius: 25px;
            box-shadow: 4px 6px 0px 0px var(--ckr-green-2);
          }
          & .detail-edit-box {
            justify-content: space-between;
            align-items: center;
            & > button {
              border-radius: 8px;
            }
          }
        }
      }
      & .detail-content-button {
        & > button {
          width: 100%;
          height: 50px;
          display: flex;
          justify-content: center;
        }
      }
    }
  }
`;

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 10px;
  box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  & > span {
    vertical-align: middle;
    margin-right: 5px;
    display: inline;
  }
  &.blue {
    color: var(--ckr-gray-1);
    background-color: var(--ckr-blue-6);
    border: 1px solid var(--ckr-blue-6);
    height: 32px;
    display: flex;
    align-items: center;
    &:hover {
      background-color: var(--ckr-blue-5);
      border: 1px solid var(--ckr-blue-5);
    }
  }
  &.gold {
    font-size: 16px;
    background-color: var(--ckr-gold-2);
    border: 1px solid var(--ckr-gold-2);
    color: var(--ckr-gold-6);
    background-image: linear-gradient(
      90deg,
      transparent 0%,
      transparent 50%,
      var(--ckr-gold-1) 50%
    );
    background-size: 230%;
    transition: all 0.5s;
    &:hover {
      background-position: 100%;
    }
    & > span {
      margin-right: 0;
      color: inherit;
      &.anticon {
        color: var(--ckr-gold-8);
      }
      & + span {
        margin-left: 5px;
      }
    }
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;
