import { css } from '@emotion/react';

export const LogDefineStyle = css`
  padding: 20px 60px;
  & > div + div {
    margin-top: 10px;
  }
  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
  & ::-webkit-scrollbar {
    width: 10px;
  }
  & ::-webkit-scrollbar-thumb {
    background-color: var(--ckr-blue-6);
    border-radius: 10px;
    background-clip: padding-box;
    border: 2px solid transparent;
  }
  & ::-webkit-scrollbar-track {
    background-color: var(--ckr-blue-3);
    border-radius: 10px;
    box-shadow: inset 0px 0px 5px white;
  }
  & .log-button-box {
    padding: 0 75px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    & .log-add-button-box {
      display: flex;
      gap: 4px;
    }
    & .log-import-button-box {
      display: flex;
      gap: 10px;
    }
  }

  & .menu-title {
    font-style: normal;
    font-weight: 600;
    font-size: 20px;
    line-height: 24px;
    margin-left: 10px;
  }
  & .label {
    font-style: normal;
    font-weight: 500;
    font-size: 16px;
    line-height: 22px;
    display: flex;
    align-items: center;
    color: var(--ckr-blue-6);
  }
  & .number-label-box {
    display: flex;
    align-items: center;
    gap: 4px;
    color: var(--ckr-blue-6);
    & .number-label {
      font-weight: 500;
    }
    & .number-value-label {
      font-weight: 500;
    }
  }

  & div > span > svg {
    color: var(--ckr-purple-6);
    width: 24px;
    height: 19px;
  }
  & .log-define-setting {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0px 75px;
    & svg {
      width: 16px;
      height: 16px;
    }
  }
  & > .box-group {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-template-rows: auto;
    gap: 1rem;
    padding: 0 75px;
    & > .box-group-box {
      background-color: var(--ckr-gray-1);
      padding: 1rem;
      border-radius: 10px;
      & > div + div {
        margin-top: 10px;
      }
      & > .title-wrapper {
        & > .box-main {
          display: flex;
          justify-content: space-between;
          margin-bottom: 10px;
          align-items: center;
          & > .box-title {
            font-size: 18px;
            font-weight: 500;
            color: var(--ckr-blue-6);
            width: 249px;
            text-overflow: ellipsis;
            overflow: hidden;
          }
        }
        & > .box-sub {
          display: flex;
          justify-content: space-between;
          margin-bottom: 10px;
          align-items: center;
          & > div {
            position: relative;
            & .number-label {
              position: absolute;
              white-space: pre;
              bottom: 7px;
              font-weight: 500;
              font-size: 13px;
              color: var(--ckr-gray-7);
            }
          }
        }
      }
      & > .box-simply-ContentGroup {
        display: flex;
        border-top: 2px solid var(--ckr-gray-5);
        padding: 1rem;
        flex-wrap: wrap;
        max-height: 175px;
        overflow: auto;
        animation: fade-in 1s linear;
        & > button:first-of-type {
          margin-left: 0px;
        }
        & > div:nth-of-type(7n + 1) {
          margin-left: 0px;
          & > .simply-content-plus {
            margin-left: 0px;
          }
        }
        & > .simply-content {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          width: 53.6px;
          height: 53.6px;
          background-color: var(--ckr-blue-3);
          color: var(--ckr-gray-10);
          border: 2px solid var(--ckr-gray-1);
          border-radius: 50%;
          margin-left: -10px;
          & > span {
            font-size: 20px;
            font-weight: 500;
          }
        }
        & > .button-wrapper {
          width: 53.6px;
          & > .simply-content-plus {
            width: 100%;
            height: 53.6px;
            background-color: var(--ckr-gray-6);
            color: var(--ckr-gray-1);
            border: 2px solid var(--ckr-gray-1);
            border-radius: 50%;
            margin-left: -10px;
            & > span {
              font-size: 25px;
              color: var(--ckr-gray-10);
            }
            &:hover {
              background-color: var(--ckr-gray-5);
              & > span {
                color: var(--ckr-gray-1);
              }
            }
          }
        }
      }
      & > .box-detail-Content-group {
        border-top: 2px solid var(--ckr-gray-4);
        padding: 1rem;
        max-height: 330px;
        overflow: auto;
        animation: fade-in 1s linear;
        & > .detail-content {
          display: grid;
          grid-template-columns: 8fr 2fr;
          & + .detail-content {
            margin-top: 0.7rem;
          }
          & > div {
            display: flex;
            gap: 10px;
            align-items: center;
          }
          & .box-label {
            align-self: center;
            width: 150px;
            text-overflow: ellipsis;
            overflow: hidden;
          }
          & .detail-icon {
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            width: 70px;
            height: 50px;
            background-color: var(--ckr-blue-3);
            color: var(--ckr-gray-10);
            border-radius: 25px;
            box-shadow: 4px 6px 0px 0px var(--ckr-green-2);
            font-size: 16px;
            font-weight: 500;
          }
          & .detail-edit-box {
            justify-content: space-between;
            align-items: center;
            & > button {
              border-radius: 8px;
            }
          }
        }
      }
      & .detail-content-button {
        margin-top: 10px;
        & > button {
          width: 100%;
          height: 50px;
          display: flex;
          justify-content: center;
        }
      }
    }
  }
`;

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 10px;
  box-shadow: 0px 2px 4px 1px rgb(0 0 0 / 20%);
  cursor: pointer;
  white-space: pre;
  & > span {
    vertical-align: middle;
    margin-right: 5px;
    display: inline;
  }
  &.white {
    background-color: var(--ckr-gray-1);
    border: 1px solid var(--ckr-gray-5);
    height: 32px;
    display: flex;
    align-items: center;
    &:disabled {
      background-color: var(--ckr-gray-5);
      color: transparent;
    }
    &:hover {
      background-color: var(--ckr-gray-3);
    }
  }
  &.dashed {
    border: 1px dashed var(--ckr-gray-5);
    box-shadow: unset;
  }
  &.blue {
    color: var(--ckr-gray-1);
    background-color: var(--ckr-blue-6);
    border: 1px solid var(--ckr-blue-6);
    height: 32px;
    display: flex;
    align-items: center;
    &:hover {
      background-color: var(--ckr-blue-5);
      border: 1px solid var(--ckr-blue-5);
    }
  }
  &.gold {
    width: 98px;
    font-size: 14px;
    padding: 2px;
    box-shadow: unset;
    background-color: var(--ckr-gold-2);
    border: 1px solid var(--ckr-gold-2);
    color: var(--ckr-gold-6);
    background-image: linear-gradient(
      90deg,
      transparent 0%,
      transparent 50%,
      var(--ckr-gold-1) 50%
    );
    background-size: 230%;
    transition: all 0.5s;
    &:hover {
      background-position: 100%;
    }
    & > span {
      margin-right: 0;
      color: inherit;
      &.anticon {
        color: var(--ckr-gold-8);
      }
      & + span {
        margin-left: 5px;
      }
    }
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;
