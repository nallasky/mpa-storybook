import { css } from '@emotion/react';

export const LogColumnBody = css`
  padding: 20px 60px;
  & .menu-title {
    font-style: normal;
    font-weight: 600;
    font-size: 20px;
    line-height: 24px;
    margin-left: 10px;
  }
  & .label {
    font-style: normal;
    font-weight: 500;
    font-size: 16px;
    line-height: 22px;
    display: flex;
    align-items: center;
    color: var(--ckr-blue-6);
    &::after {
      display: inline-block;
      content: ':';
    }
  }
  & .number-label {
    font-weight: 500;
    &::after {
      display: inline-block;
      content: ':';
    }
  }
  & .number-value-label {
    font-weight: 500;
  }

  & .log-column {
    & > div {
      margin-bottom: 10px;
    }
    & div > span > svg {
      color: var(--ckr-purple-6);
      width: 24px;
      height: 19px;
    }
    & .log-column-setting {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0px 75px;
      & svg {
        width: 16px;
        height: 16px;
      }
    }
    & .button {
      display: flex;
      gap: 10px;
      & svg {
        width: 16px;
        height: 16px;
      }
    }
    & .table {
      padding: 0px 75px;
      & .ant-tag {
        border-radius: 10px;
        & svg {
          width: 10px;
          height: 12px;
        }
      }
      & .ant-table.ant-table-middle {
        border-radius: 10px;
      }
      & table > thead > tr > th {
        font-weight: 700;
      }
    }
    & .logColumnTable {
      & table > tbody > tr > td {
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: pre;
        &:last-of-type {
          & > div {
            display: flex;
            justify-content: space-evenly;
          }
        }
      }
    }
  }
`;

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 10px;
  box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  & > span {
    vertical-align: middle;
    margin-right: 5px;
    display: inline;
  }
  &.white {
    background-color: var(--ckr-gray-1);
    border: 1px solid var(--ckr-gray-5);
    height: 32px;
    display: flex;
    align-items: center;
    &:disabled {
      background-color: var(--ckr-gray-5);
      color: transparent;
    }
    &:hover {
      background-color: var(--ckr-gray-3);
    }
  }
  &.blue {
    color: var(--ckr-gray-1);
    background-color: var(--ckr-blue-6);
    border: 1px solid var(--ckr-blue-6);
    height: 32px;
    display: flex;
    align-items: center;
    &:hover {
      background-color: var(--ckr-blue-5);
      border: 1px solid var(--ckr-blue-5);
    }
  }
  &:disabled {
    cursor: not-allowed;
    pointer-events: none;
    background-color: var(--ckr-gray-5);
    border: transparent;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;
export const ModalStyle = css`
  & > .ant-modal {
    top: 33%;
  }
`;

export const LogColumnModal = css`
  & .modal-body-style {
    display: flex;
    flex-direction: column;
    padding: 0px;
    gap: 10px;
    & .modal-pattern {
      display: grid;
      grid-template-columns: 0.3fr 1fr;
      font-size: 14px;
      font-weight: 700;
      color: var(--ckr-gray-10);
    }
    & .ant-form-item-label {
      text-align: unset;
    }
    & .ant-form-item-control {
      display: none;
    }
    & .ant-form-item {
      margin-bottom: unset;
    }
    & .ant-form-item-label > label {
      font-weight: 700;
    }
    & button {
      display: flex;
      align-items: center;
      justify-content: center;
      & .button-svg {
        color: var(--ckr-gray-7);
      }
    }
    & .column-style {
      display: grid;
      grid-template-columns: 0.8fr 1fr;
      & label {
        color: var(--ckr-gray-10);
      }
      & .nostar {
        padding-left: 12px;
      }
    }
  }
  & .upload-label > span {
    &::after {
      display: none;
    }
  }
  & .label {
    color: var(--ckr-gray-10);
    align-self: center;
    &:not(.nostar) {
      &::before {
        display: inline-block;
        color: var(--ckr-red-6);
        font-size: 14px;
        content: '*';
        margin-right: 0.3rem;
      }
    }
    &::after {
      display: inline-block;
      content: ':';
    }
  }
  & .ant-modal-footer {
    display: flex;
  }
`;
export const ModalFooterStyle = css`
  display: inline-flex;
  gap: 10px;
  padding: 0px 8px;
`;
