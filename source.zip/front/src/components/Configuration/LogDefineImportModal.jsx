import { useState } from 'react';
import PropTypes from 'prop-types';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import { Common, Config } from '@assets/locale/en';
import { Upload } from '@components/common/atoms/Upload';
import { ModalFooterButton } from '@components/CommonLog/styles/CommonLogStyles';
import { useLogDefine } from '@components/Configuration/hooks';
import {
  LogColumnModal,
  ModalFooterStyle,
} from '@components/Configuration/styles/LogColumnStyle';
import { Spin } from 'antd';
const {
  logDefine: { import: message },
} = Config;

const LogDefineImportModal = ({ onClose, onSave }) => {
  const [isVisible, setIsVisible] = useState(true);
  const { importLogDefineList, importFilesProps, isImporting, isEnableImport } =
    useLogDefine();
  const closeFunc = () => {
    setIsVisible(false);
    onClose();
  };
  const onImportFunc = () => {
    importLogDefineList({
      onSuccessFunc: () => {
        onSave();
        onClose();
      },
    });
  };
  return (
    <DraggableModal
      visible={isVisible}
      footer={
        <div css={ModalFooterStyle}>
          <ModalFooterButton
            className="white"
            onClick={closeFunc}
            key={'footer_left'}
          >
            {Common.Btn_Cancel}
          </ModalFooterButton>
          <ModalFooterButton
            onClick={onImportFunc}
            key={'footer_right'}
            disabled={isImporting || !isEnableImport}
          >
            {Common.Btn_Apply}
          </ModalFooterButton>
        </div>
      }
      title={message.title}
      cancelHandler={closeFunc}
      maskClosable
      centered
    >
      <div css={LogColumnModal}>
        <Spin tip={message.loading} spinning={isImporting}>
          <div className="modal-body-style">
            <Upload
              label={message.alert}
              required={true}
              uploadProps={importFilesProps}
              type={'Drag'}
            />
          </div>
        </Spin>
      </div>
    </DraggableModal>
  );
};
LogDefineImportModal.propTypes = {
  onClose: PropTypes.func,
  onSave: PropTypes.func,
};

export default LogDefineImportModal;
