import React, { useState } from 'react';
import * as SS from '@components/Configuration/styles/ConfigurationStyle';
import { Input, Skeleton, Button, Tooltip } from 'antd';
import {
  DatabaseOutlined,
  FolderOpenFilled,
  RollbackOutlined,
} from '@ant-design/icons';
import { Config, Common } from '@assets/locale/en';
import RemoteDatabaseSetting from '@components/Configuration/RemoteDatabaseSetting';
import {
  useConfiguration,
  useLocalDatabase,
} from '@components/Configuration/hooks';
const message = Config.dataBase;

const DatabaseSetting = () => {
  const [localDBReload, setLocalDBReload] = useState(true);
  const {
    gLocalDbPath,
    localDbPath,
    errMsg,
    updateLocalDatabasePath,
    resetLocalDatabasePath,
    changeLocalDatabasePath,
    isLoading: updateIsLoading,
  } = useLocalDatabase();
  const { getLocalDatabaseResource } = useConfiguration();

  const { isLoading, error, isFetching } = getLocalDatabaseResource({
    enabled: localDBReload,
    onSettled: () => setLocalDBReload(false),
  });

  return (
    <div css={SS.DataBaseBody}>
      {error ?? false ? (
        <div className="Local-location">
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <div className="Local-location">
          <Skeleton
            loading={isLoading || isFetching}
            active
            paragraph={{ rows: 5 }}
          >
            <div>
              <DatabaseOutlined />
              <span className="menu-title">{message.local.title}</span> <br />
            </div>
            <div className="location-setting">
              <span className="label">{message.local.location}</span>
              <Input.Group compact>
                <div className="local-input-style">
                  <Tooltip
                    title={errMsg}
                    visible={!!errMsg}
                    trigger="hover"
                    overlayClassName="local-input-tooltip"
                  >
                    <Input
                      prefix={<FolderOpenFilled />}
                      style={{ width: '550px' }}
                      onChange={changeLocalDatabasePath}
                      value={localDbPath ?? gLocalDbPath}
                    />
                  </Tooltip>
                  <Button
                    type="primary"
                    onClick={resetLocalDatabasePath}
                    icon={<RollbackOutlined />}
                  >
                    {Common.Btn_Reset}
                  </Button>
                </div>
              </Input.Group>
              <button
                css={SS.antdButtonStyle}
                className="blue"
                disabled={localDbPath === undefined || updateIsLoading}
                onClick={() =>
                  updateLocalDatabasePath({
                    onSuccess: () => setLocalDBReload(true),
                  })
                }
              >
                {Common.Btn_Apply}
              </button>
            </div>
          </Skeleton>
        </div>
      )}
      <div className="remote-database">
        <RemoteDatabaseSetting />
      </div>
    </div>
  );
};
export default DatabaseSetting;
