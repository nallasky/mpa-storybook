import React from 'react';
import * as SS from '@components/Configuration/styles/ConfigurationStyle';
import { Input, Space } from 'antd';
import { DatabaseOutlined, FolderOutlined } from '@ant-design/icons';
import { Config, Common } from '@assets/locale/en';
import RemoteDatabaseSetting from '@components/Configuration/RemoteDatabaseSetting';
const message = Config.dataBase;

const DatabaseSetting = () => {
  const { Search } = Input;
  const onSearch = (value) => console.log(value);
  return (
    <div css={SS.DataBaseBody}>
      <div className="Local-location">
        <div>
          <DatabaseOutlined />
          <span className="menu-title">{message.local.title}</span> <br />
        </div>
        <div className="location-setting">
          <span className="label">{message.local.location}</span>
          <Space direction="vertical" style={{ width: '450px' }}>
            <Search
              onSearch={onSearch}
              enterButton={<FolderOutlined />}
              value="C:\MPA Analysis Tool"
            />
          </Space>
          <button css={SS.antdButtonStyle} className="blue">
            {Common.Btn_Apply}
          </button>
        </div>
      </div>
      <div className="remote-database">
        <RemoteDatabaseSetting />
      </div>
    </div>
  );
};
export default DatabaseSetting;
