import { useState, Fragment } from 'react';
import * as SS from '@components/Configuration/styles/LogPatternStyle';
import { LogPatternModal } from '@components/Configuration/LogPatternModal';
import useModal from '@libs/util/modalControl/useModal';
import {
  PlusOutlined,
  NotificationOutlined,
  EditOutlined,
} from '@ant-design/icons';
import { Table, Button, Tag, Skeleton } from 'antd';
import {
  DEFINE_ENABLE_PATTERN_ADD,
  LogPattenDefaultItem,
  LogPatternTable,
} from '@constants/ConfigurationDefault';
import { useConfiguration } from '@components/Configuration/hooks';
import { Config, Common } from '@assets/locale/en';

const message = Config.logPattern;
const PATTERN_DISPLAY_ITEM = 3;
const LogPattern = () => {
  const [reLoad, setReLoad] = useState(true);
  const { openModal } = useModal();
  const { gLogPatternList, getLogPatternResource } = useConfiguration();
  const { isLoading, error, isFetching } = getLogPatternResource({
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });
  const RenderFunc = (type, record) => {
    return type === 'no' ? (
      record.idx
    ) : type === 'edit' ? (
      <Button
        type="dashed"
        icon={<EditOutlined />}
        onClick={() =>
          openModal(LogPatternModal, {
            type: 'edit',
            onSave: () => setReLoad(true),
            info: gLogPatternList.find((obj) => obj.id === record.id),
          })
        }
      />
    ) : type === 'pattern' || type === 'ignore_pattern' ? (
      record[type].map((obj, idx) =>
        idx < PATTERN_DISPLAY_ITEM ? (
          <Tag className="table-patten" key={idx}>
            {obj.length > 20 ? obj.slice(0, 20) + '...' : obj}
          </Tag>
        ) : (
          record[type].length - 1 === idx && (
            <Tag className="table-patten" key={idx} color={'blue'}>
              <PlusOutlined /> {record[type].length - PATTERN_DISPLAY_ITEM}
            </Tag>
          )
        ),
      )
    ) : (
      record[type]
    );
  };
  return (
    <div css={SS.LogPatternBody}>
      {error ?? false ? (
        <div>
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <Skeleton
          loading={isLoading || isFetching}
          active
          paragraph={{ rows: 5 }}
        >
          <div className="log-pattern-style">
            <div>
              <NotificationOutlined />
              <span className="menu-title">{message.title}</span>
            </div>
            <div className="log-pattern-setting">
              <div style={{ display: 'flex', gap: '4px' }}>
                {DEFINE_ENABLE_PATTERN_ADD ? (
                  <button
                    css={SS.antdButtonStyle}
                    className="white"
                    style={{ marginRight: '10px' }}
                    onClick={() =>
                      openModal(LogPatternModal, {
                        type: 'new',
                        onSave: () => setReLoad(true),
                        info: {
                          ...LogPattenDefaultItem,
                          id: null,
                          idx:
                            gLogPatternList.length === 0
                              ? 1
                              : Math.max(
                                  ...(gLogPatternList ?? []).map(
                                    (obj) => obj.idx,
                                  ),
                                ) + 1,
                        },
                      })
                    }
                  >
                    <PlusOutlined />
                    {message.add.title}
                  </button>
                ) : (
                  <Fragment></Fragment>
                )}
                <span className="number-label">{Common.NumOfItems}</span>
                <span className="number-value-label">
                  {gLogPatternList.length}
                </span>
              </div>
            </div>
            <div className="table logPatternTable">
              <Table
                dataSource={gLogPatternList}
                bordered
                size="middle"
                tableLayout="auto"
              >
                {LogPatternTable.map((column) => {
                  return (
                    <Table.Column
                      key={column.dataIndex}
                      title={column.title}
                      dataIndex={column.dataIndex}
                      render={(_, record) =>
                        RenderFunc(column.dataIndex, record)
                      }
                    />
                  );
                })}
              </Table>
            </div>
          </div>
        </Skeleton>
      )}
    </div>
  );
};
export default LogPattern;
