import React, { useState, Fragment, useMemo } from 'react';
import * as SS from './styles/LogColumnStyle';
import { Select } from 'antd';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import PropTypes from 'prop-types';
import { Config, Common } from '@assets/locale/en';
import {
  LogColumnDatabaseTypeList,
  LogColumnTypeList,
  LogColumnDefaultTypeList,
  LogColumnInfoList,
  LogColumnHeaderList,
} from '@constants/ConfigurationDefault';
import { RequestOnError } from '@libs/util/common/common';
import { useConfiguration } from '@components/Configuration/hooks';
import { coefRegex } from '@libs/util/regExp';
import InputForm from '@components/common/atoms/Input/InputForm';
import { getParseData } from '@libs/util/util';

const { Option } = Select;
const message = Config.logColumn.modal;
const ColumnSelect = ({
  value,
  setValue,
  disabled,
  title,
  options,
  required,
}) => {
  return (
    <>
      <span className={`label ${required ?? true ? '' : 'nostar'}`}>
        {title}
      </span>
      <Select
        value={value}
        style={{ width: '100%' }}
        disabled={disabled}
        onChange={(v) => setValue(v)}
      >
        {options.map((item, idx) => (
          <Option value={item?.value ?? item} key={idx}>
            {item?.title ?? item}
          </Option>
        ))}
      </Select>
    </>
  );
};
ColumnSelect.propTypes = {
  value: PropTypes.string,
  setValue: PropTypes.func,
  disabled: PropTypes.bool,
  title: PropTypes.string,
  options: PropTypes.array,
  required: PropTypes.bool,
};

const ColumnInput = ({
  value,
  setValue,
  name,
  title,
  required,
  validator,
  useLabel,
  placeholder,
}) => {
  const onChangeFunc = (obj) => {
    const data = getParseData(obj);
    console.log(obj);
    console.log(data);
    setValue(data.id, data.value);
  };
  return (
    <>
      {useLabel && (
        <span className={`label ${required ?? true ? '' : 'nostar'}`}>
          {title ?? ''}
        </span>
      )}
      <InputForm.input
        formStyle={{ labelCol: { span: 5 }, wrapperCol: { span: 35 } }}
        formName={name}
        formLabel={undefined}
        changeFunc={onChangeFunc}
        required={required}
        value={value}
        regExp={validator}
        placeholder={placeholder}
      />
    </>
  );
};
ColumnInput.propTypes = {
  value: PropTypes.string,
  setValue: PropTypes.func,
  title: PropTypes.string,
  name: PropTypes.string,
  required: PropTypes.bool,
  validator: PropTypes.object,
  useLabel: PropTypes.bool,
  placeholder: PropTypes.string,
};
ColumnInput.defaultProps = {
  useLabel: true,
};
export const LogColumnModal = ({ onSave, info, onClose, type }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [setting, updateSetting] = useState(info);
  const {
    updateColumnDefineFunc,
    gLogColumnDataTypeList,
    gLogColumnDefaultTypeList,
  } = useConfiguration();
  const isHeaderType = useMemo(
    () => setting?.type === 'header',
    [setting.type],
  );
  const modalClose = () => {
    setIsVisible(false);
    onClose();
  };
  const modalOk = () => {
    const obj = (isHeaderType ? LogColumnHeaderList : LogColumnInfoList).reduce(
      (acc, key) => Object.assign(acc, { [key]: setting[key] }),
      {},
    );
    console.log('modalOk', obj);
    updateColumnDefineFunc.mutate(obj, {
      onSuccess: () => {
        onSave();
        modalClose();
      },
      onError: RequestOnError,
    });
  };
  const onChangeFunc = (key, value) => {
    updateSetting((prevState) =>
      ['def_type', 'output_column'].includes(key)
        ? {
            ...prevState,
            [key === 'def_type' ? 'def_val' : 'output_column_val']: value,
            [key]: value,
          }
        : {
            ...prevState,
            [key]: value,
          },
    );
  };
  const checkDisableApply = () => {
    let ret = false;
    if ((setting?.output_column ?? '').length === 0) {
      ret = true;
    }
    if (isHeaderType) {
      if ((setting?.data ?? '').length === 0) {
        ret = true;
      } else if (['integer', 'float'].includes(setting.data_type)) {
        if ((setting?.coef ?? '').length === 0) {
          ret = true;
        } else if (!coefRegex.test(setting?.coef)) {
          ret = true;
        }
      }
    }
    return ret;
  };
  console.log('=====setting', setting);
  return (
    <DraggableModal
      css={SS.ModalStyle}
      width={600}
      title={type === 'edit' ? message.edit_title : message.new_title}
      visible={isVisible}
      footer={
        <div css={SS.ModalFooterStyle}>
          <button
            css={SS.antdButtonStyle}
            className="white"
            style={{ borderRadius: '10px' }}
            onClick={modalClose}
          >
            {Common.Btn_Cancel}
          </button>
          <button
            css={SS.antdButtonStyle}
            className="blue"
            disabled={checkDisableApply()}
            style={{ borderRadius: '10px' }}
            onClick={modalOk}
          >
            {Common.Btn_OK}
          </button>
        </div>
      }
      cancelHandler={modalClose}
      maskClosable
    >
      <div css={SS.LogColumnModal}>
        <div className="modal-body-style">
          <div className="column-style">
            <ColumnSelect
              value={setting?.type}
              setValue={(v) => onChangeFunc('type', v)}
              title={message.type.title}
              disabled={type === 'edit'}
              options={LogColumnTypeList}
            />
          </div>
          {isHeaderType && (
            <div className="column-style">
              <ColumnInput
                value={setting?.data ?? ''}
                name={'data'}
                setValue={onChangeFunc}
                title={message.data}
                placeholder={'please enter the column data'}
              />
            </div>
          )}
          <div className="column-style">
            <ColumnInput
              value={setting?.output_column ?? ''}
              name={'output_column'}
              setValue={onChangeFunc}
              title={message.database_name}
              placeholder={'please enter the output column name'}
            />
          </div>
          <div className="column-style">
            <ColumnSelect
              value={setting?.data_type ?? ''}
              setValue={(v) => onChangeFunc('data_type', v)}
              title={message.database_type.title}
              options={gLogColumnDataTypeList ?? LogColumnDatabaseTypeList}
            />
          </div>
          <div
            css={SS.DefaultValueStyle}
            className={
              ['text', 'lambda'].includes(setting?.def_type) ? 'default' : ''
            }
          >
            <ColumnSelect
              value={setting?.def_type ?? ''}
              setValue={(v) => onChangeFunc('def_type', v)}
              title={message.def_type.title}
              options={gLogColumnDefaultTypeList ?? LogColumnDefaultTypeList}
            />
            {['text', 'lambda'].includes(setting?.def_type) && (
              <ColumnInput
                value={setting?.def_val ?? ''}
                name={'def_val'}
                setValue={onChangeFunc}
                required={false}
                useLabel={false}
              />
            )}
          </div>
          {isHeaderType && ['integer', 'float'].includes(setting.data_type) && (
            <Fragment>
              <div className="column-style">
                <ColumnInput
                  name={'coef'}
                  value={setting?.coef ?? ''}
                  setValue={onChangeFunc}
                  title={message.coef}
                  required={true}
                  validator={[
                    {
                      pattern: coefRegex,
                      message: message.err.tooltip.coef,
                    },
                  ]}
                />
              </div>
              <div className="column-style">
                <ColumnInput
                  name={'unit'}
                  value={setting?.unit ?? ''}
                  setValue={onChangeFunc}
                  title={message.unit}
                  placeholder={'please enter the unit'}
                  required={false}
                />
              </div>
            </Fragment>
          )}
        </div>
      </div>
    </DraggableModal>
  );
};
LogColumnModal.propTypes = {
  onClose: PropTypes.func,
  onSave: PropTypes.func,
  info: PropTypes.object,
  type: PropTypes.string,
};
