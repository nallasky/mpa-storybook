import { useState, Fragment, useMemo } from 'react';
import * as SS from './styles/ConfigurationStyle';
import { Input, Select } from 'antd';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import PropTypes from 'prop-types';
import { Config, Common } from '@assets/locale/en';
import {
  LogColumnDatabaseTypeList,
  LogColumnTypeList,
  LogColumnDefaultList,
  LogColumnInfoList,
  LogColumnHeaderList,
} from '@constants/ConfigurationDefault';
import { RequestOnError } from '@libs/util/common/common';
import { useConfiguration } from '@components/Configuration/hooks';

const { Option } = Select;
const message = Config.logColumn.modal;
const ColumnSelect = ({
  value,
  setValue,
  disabled,
  title,
  options,
  required,
}) => {
  return (
    <div className="column-style">
      <span className={`label ${required ?? true ? '' : 'nostar'}`}>
        {title}
      </span>
      <Select
        value={value}
        style={{ width: '100%' }}
        disabled={disabled}
        onChange={(v) => setValue(v)}
      >
        {options.map((item, idx) => (
          <Option value={item.value} key={idx}>
            {item.title}
          </Option>
        ))}
      </Select>
    </div>
  );
};
ColumnSelect.propTypes = {
  value: PropTypes.string,
  setValue: PropTypes.func,
  disabled: PropTypes.bool,
  title: PropTypes.string,
  options: PropTypes.array,
  required: PropTypes.bool,
};

const ColumnInput = ({ value, setValue, title, placeholder, required }) => {
  return (
    <div className="column-style">
      <span className={`label ${required ?? true ? '' : 'nostar'}`}>
        {title ?? ''}
      </span>
      <Input
        placeholder={placeholder}
        value={value}
        onChange={({ target: { value } }) => setValue(value)}
      />
    </div>
  );
};
ColumnInput.propTypes = {
  value: PropTypes.string,
  setValue: PropTypes.func,
  title: PropTypes.string,
  placeholder: PropTypes.string,
  required: PropTypes.bool,
};
export const LogColumnModal = ({ onSave, info, onClose, type }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [setting, updateSetting] = useState(info);
  const { updateColumnDefineFunc } = useConfiguration();
  const isHeaderType = useMemo(
    () => Boolean(setting?.type ?? 0),
    [setting.type],
  );
  const modalClose = () => {
    setIsVisible(false);
    onClose();
  };
  const modalOk = () => {
    const obj = (isHeaderType ? LogColumnHeaderList : LogColumnInfoList).reduce(
      (acc, key) => Object.assign(acc, { [key]: setting[key] }),
      {},
    );
    console.log('modalOk', obj);
    updateColumnDefineFunc.mutate(obj, {
      onSuccess: () => {
        onSave();
        modalClose();
      },
      onError: RequestOnError,
    });
  };
  const onChangeFunc = (key, value) => {
    updateSetting((prevState) => ({
      ...prevState,
      [key]: value,
    }));
  };

  return (
    <DraggableModal
      css={SS.ModalStyle}
      title={type === 'edit' ? message.edit_title : message.new_title}
      visible={isVisible}
      footer={
        <div css={SS.ModalFooterStyle}>
          <button
            css={SS.antdButtonStyle}
            className="white"
            style={{ borderRadius: '10px' }}
            onClick={modalClose}
          >
            {Common.Btn_Cancel}
          </button>
          <button
            css={SS.antdButtonStyle}
            className="blue"
            disabled={
              (setting?.output_column_name ?? '').length === 0 ||
              (isHeaderType && (setting?.data ?? '').length === 0)
            }
            style={{ borderRadius: '10px' }}
            onClick={modalOk}
          >
            {Common.Btn_OK}
          </button>
        </div>
      }
      cancelHandler={modalClose}
      maskClosable
    >
      <div css={SS.ConfigurationModalStyle}>
        <div className="modal-body-style">
          <ColumnSelect
            value={setting?.type ?? 0}
            setValue={(v) => onChangeFunc('type', +v)}
            title={message.type.title}
            disabled={type === 'edit'}
            options={LogColumnTypeList}
          />
          {isHeaderType && (
            <ColumnInput
              value={setting?.data ?? ''}
              setValue={(v) => onChangeFunc('data', v)}
              title={message.data}
              placeholder={'please enter the column data'}
            />
          )}
          <ColumnInput
            value={setting?.output_column_name ?? ''}
            setValue={(v) => onChangeFunc('output_column_name', v)}
            title={message.database_name}
            placeholder={'please enter the output column name'}
          />
          <ColumnSelect
            value={setting?.output_column_type ?? ''}
            setValue={(v) => onChangeFunc('output_column_type', v)}
            title={message.database_type.title}
            options={LogColumnDatabaseTypeList}
          />
          <ColumnSelect
            value={setting?.default_value ?? ''}
            setValue={(v) => onChangeFunc('default_value', v)}
            title={message.default_value.title}
            options={LogColumnDefaultList}
          />
          {setting?.default_value === 'custom' && (
            <ColumnInput
              value={setting?.custom_value ?? ''}
              setValue={(v) => onChangeFunc('custom_value', v)}
              required={false}
            />
          )}
          {isHeaderType &&
            ['integer', 'real'].includes(setting.output_column_type) && (
              <Fragment>
                <ColumnInput
                  value={setting?.coefficient ?? ''}
                  setValue={(v) => onChangeFunc('coefficient', v)}
                  title={message.coefficient_value}
                  required={false}
                />
                <ColumnInput
                  value={setting?.unit ?? ''}
                  setValue={(v) => onChangeFunc('unit', v)}
                  title={message.unit}
                  placeholder={'please enter the unit'}
                  required={false}
                />
              </Fragment>
            )}
        </div>
      </div>
    </DraggableModal>
  );
};
LogColumnModal.propTypes = {
  onClose: PropTypes.func,
  onSave: PropTypes.func,
  info: PropTypes.object,
  type: PropTypes.string,
};
