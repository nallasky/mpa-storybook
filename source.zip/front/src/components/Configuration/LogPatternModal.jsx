import { Fragment, useState } from 'react';
import * as SS from './styles/LogPatternStyle';
import { Input, Tooltip } from 'antd';
import LogPatternAddRemove from '@components/Configuration/LogPatternAddRemove';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import PropTypes from 'prop-types';
import { QuestionCircleOutlined } from '@ant-design/icons';
import { Config, Common } from '@assets/locale/en';
import { RequestOnError } from '@libs/util/common/common';
import { useConfiguration } from '@components/Configuration/hooks';
import { DEFINE_ENABLE_PATTERN_LOG_EDIT } from '@constants/ConfigurationDefault';
const message = Config.logPattern.modal;

export const LogPatternModal = ({ info, onSave, onClose, type }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [setting, updateSetting] = useState(info);
  const { updateLogPatternFunc } = useConfiguration();
  const modalClose = () => {
    setIsVisible(false);
    onClose();
  };
  const modalOk = () => {
    const obj = { ...setting };
    delete obj['idx'];
    console.log('obj', obj);
    updateLogPatternFunc.mutate(obj, {
      onSuccess: () => {
        onSave();
        modalClose();
      },
      onError: RequestOnError,
    });
  };
  return (
    <DraggableModal
      css={SS.ModalStyle}
      title={type === 'edit' ? message.edit_title : message.new_title}
      visible={isVisible}
      footer={
        <div css={SS.ModalFooterStyle}>
          <button
            css={SS.antdButtonStyle}
            className="white"
            style={{ borderRadius: '10px' }}
            onClick={modalClose}
          >
            {Common.Btn_Cancel}
          </button>
          <button
            css={SS.antdButtonStyle}
            className="blue"
            disabled={(setting?.log_name ?? '').length === 0}
            style={{ borderRadius: '10px' }}
            onClick={modalOk}
          >
            {Common.Btn_OK}
          </button>
        </div>
      }
      cancelHandler={modalClose}
      maskClosable
    >
      <div css={SS.LogPatternModal}>
        <div className="modal-body-style">
          <div className="modal-pattern">
            <span className="label">{message.logName}</span>
            <span className="label-name">
              {DEFINE_ENABLE_PATTERN_LOG_EDIT ? (
                <Input
                  placehold
                  placeholder="please enter the log name"
                  value={setting?.log_name ?? ''}
                  onChange={(e) =>
                    updateSetting((prevState) => ({
                      ...prevState,
                      log_name: e.target.value,
                    }))
                  }
                />
              ) : (
                <Fragment>{setting?.log_name}</Fragment>
              )}
            </span>
          </div>
          <div>
            <div css={SS.ToolTipStyle}>
              {message.pattern}
              <Tooltip title={message.tooltip}>
                <QuestionCircleOutlined />
              </Tooltip>
              {':'}
            </div>
            <div css={SS.LogPatternAddRemove}>
              <LogPatternAddRemove
                pattern={setting?.pattern ?? []}
                title={message.new_pattern}
                updatePattern={(list) =>
                  updateSetting((prevState) => ({
                    ...prevState,
                    pattern: list,
                  }))
                }
              />
            </div>
          </div>
          <div>
            <div css={SS.ToolTipStyle}>
              {message.ignore_pattern}
              <Tooltip title={message.ignore_tooltip}>
                <QuestionCircleOutlined />
              </Tooltip>
              {':'}
            </div>
            <div css={SS.LogPatternAddRemove}>
              <LogPatternAddRemove
                pattern={setting?.ignore_pattern ?? []}
                title={message.new_ignore_pattern}
                updatePattern={(list) =>
                  updateSetting((prevState) => ({
                    ...prevState,
                    ignore_pattern: list,
                  }))
                }
              />
            </div>
          </div>
        </div>
      </div>
    </DraggableModal>
  );
};
LogPatternModal.propTypes = {
  onClose: PropTypes.func,
  onSave: PropTypes.func,
  info: PropTypes.object,
  type: PropTypes.string,
};
