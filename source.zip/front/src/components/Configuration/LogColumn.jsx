import { useState, useEffect } from 'react';
import * as SS from '@components/Configuration/styles/ConfigurationStyle';
import { LogColumnModal } from '@components/Configuration/LogColumnModal';
import useModal from '@libs/util/modalControl/useModal';
import {
  PlusOutlined,
  NotificationOutlined,
  EditOutlined,
  DeleteOutlined,
} from '@ant-design/icons';
import {
  LogColumnTable,
  LogColumnDefaultItem,
} from '@constants/ConfigurationDefault';
import { Table, Button, Popconfirm, Skeleton } from 'antd';
import { useConfiguration } from '@components/Configuration/hooks';
import { MSG_CONFIRM_DELETE } from '@constants/Message';
import { Config, Common } from '@assets/locale/en';
import { RequestOnError } from '@libs/util/common/common';
const message = Config.logColumn;
const LogColumn = () => {
  const [reLoad, setReLoad] = useState(false);
  const { openModal } = useModal();
  const { gLogColumnList, getColumnDefineResource, deleteColumnDefineFunc } =
    useConfiguration();
  const { isLoading, error, isFetching } = getColumnDefineResource({
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });
  const onDeleteFunc = (id) => {
    deleteColumnDefineFunc.mutate(id, {
      onSuccess: () => setReLoad(true),
      onError: RequestOnError,
    });
  };

  const RenderFunc = (type, record, index) => {
    return type === 'edit' ? (
      <div>
        <Button
          type="dashed"
          icon={<EditOutlined />}
          onClick={() =>
            openModal(LogColumnModal, {
              type: 'edit',
              onSave: () => setReLoad(true),
              info: gLogColumnList.find((obj) => obj.id === record.id),
            })
          }
        />
        <Popconfirm
          title={MSG_CONFIRM_DELETE}
          onConfirm={() => onDeleteFunc(record.id)}
        >
          <Button type="dashed" icon={<DeleteOutlined />} />
        </Popconfirm>
      </div>
    ) : type === 'no' ? (
      index + 1
    ) : record['type'] === 0 &&
      ['column_data', 'coefficient_value', 'unit'].includes(type) ? (
      '-'
    ) : type === 'type' ? (
      record[type] ? (
        message.type.header
      ) : (
        message.type.info
      )
    ) : (
      record[type]
    );
  };
  useEffect(() => {
    console.log('LogDefine reLoad', reLoad);
    setReLoad(true);
  }, []);
  return (
    <div css={SS.DataBaseBody}>
      {error ?? false ? (
        <div className="remote-setting">
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <Skeleton
          loading={isLoading || isFetching}
          active
          paragraph={{ rows: 5 }}
        >
          <div className="remote-database">
            <div>
              <NotificationOutlined />
              <span className="menu-title">{message.title}</span>
            </div>
            <div className="remote-setting">
              <div style={{ display: 'flex', gap: '4px' }}>
                <button
                  css={SS.antdButtonStyle}
                  className="white"
                  style={{ marginRight: '10px' }}
                  onClick={() =>
                    openModal(LogColumnModal, {
                      type: 'new',
                      onSave: () => setReLoad(true),
                      info: {
                        ...LogColumnDefaultItem,
                        id: null,
                      },
                    })
                  }
                >
                  <PlusOutlined />
                  {message.add.title}
                </button>

                <span className="label">{Common.NumOfItems}</span>
                <span
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    color: '#1890ff',
                  }}
                >
                  {gLogColumnList.length}
                </span>
              </div>
            </div>
            <div className="table logColumnTable">
              <Table
                dataSource={gLogColumnList}
                bordered
                size="middle"
                tableLayout="fixed"
              >
                {LogColumnTable.map((column) => {
                  return (
                    <Table.Column
                      key={column.dataIndex}
                      title={column.title}
                      dataIndex={column.dataIndex}
                      render={(_, record, index) =>
                        RenderFunc(column.dataIndex, record, index)
                      }
                    />
                  );
                })}
              </Table>
            </div>
          </div>
        </Skeleton>
      )}
    </div>
  );
};
export default LogColumn;
