import { useState } from 'react';
import * as SS from '@components/Configuration/styles/LogColumnStyle';
import { LogColumnModal } from '@components/Configuration/LogColumnModal';
import useModal from '@libs/util/modalControl/useModal';
import {
  PlusOutlined,
  NotificationOutlined,
  EditOutlined,
  DeleteOutlined,
} from '@ant-design/icons';
import {
  LogColumnTable,
  LogColumnDefaultItem,
} from '@constants/ConfigurationDefault';
import { Table, Button, Popconfirm, Skeleton } from 'antd';
import { useConfiguration } from '@components/Configuration/hooks';
import { MSG_CONFIRM_DELETE } from '@constants/Message';
import { Config, Common } from '@assets/locale/en';
import { RequestOnError } from '@libs/util/common/common';
const message = Config.logColumn;
const LogColumn = () => {
  const [reLoad, setReLoad] = useState(true);
  const { openModal } = useModal();
  const { gLogColumnList, getColumnDefineResource, deleteColumnDefineFunc } =
    useConfiguration();
  const { isLoading, error, isFetching } = getColumnDefineResource({
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });
  const onDeleteFunc = (id) => {
    deleteColumnDefineFunc.mutate(id, {
      onSuccess: () => setReLoad(true),
      onError: RequestOnError,
    });
  };

  const RenderFunc = (type, record) => {
    return type === 'edit' ? (
      <div>
        <Button
          type="dashed"
          icon={<EditOutlined />}
          onClick={() =>
            openModal(LogColumnModal, {
              type: 'edit',
              onSave: () => setReLoad(true),
              info: gLogColumnList.find((obj) => obj.id === record.id),
            })
          }
        />
        <Popconfirm
          title={MSG_CONFIRM_DELETE}
          onConfirm={() => onDeleteFunc(record.id)}
        >
          <Button type="dashed" icon={<DeleteOutlined />} />
        </Popconfirm>
      </div>
    ) : type === 'no' ? (
      record.idx
    ) : record['type'] === 'info' &&
      ['column_data', 'coef', 'unit', 'data'].includes(type) ? (
      '-'
    ) : (
      record[type]
    );
  };

  return (
    <div css={SS.LogColumnBody}>
      {error ?? false ? (
        <div className="remote-setting">
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <Skeleton
          loading={isLoading || isFetching}
          active
          paragraph={{ rows: 5 }}
        >
          <div className="log-column">
            <div>
              <NotificationOutlined />
              <span className="menu-title">{message.title}</span>
            </div>
            <div className="log-column-content">
              <div className="log-column-setting">
                <div
                  style={{ display: 'flex', gap: '4px', alignItems: 'center' }}
                >
                  <button
                    css={SS.antdButtonStyle}
                    className="white"
                    style={{ marginRight: '10px' }}
                    onClick={() =>
                      openModal(LogColumnModal, {
                        type: 'new',
                        onSave: () => setReLoad(true),
                        info: {
                          ...LogColumnDefaultItem,
                          id: null,
                        },
                      })
                    }
                  >
                    <PlusOutlined />
                    {message.add.title}
                  </button>
                  <span className="number-label">{Common.NumOfItems}</span>
                  <span className="number-value-label">
                    {gLogColumnList.length}
                  </span>
                </div>
              </div>
              <div className="table logColumnTable">
                <Table
                  dataSource={gLogColumnList}
                  bordered
                  size="middle"
                  tableLayout="auto"
                >
                  {LogColumnTable.map((column) => {
                    return (
                      <Table.Column
                        key={column.dataIndex}
                        title={column.title}
                        dataIndex={column.dataIndex}
                        render={(_, record) =>
                          RenderFunc(column.dataIndex, record)
                        }
                      />
                    );
                  })}
                </Table>
              </div>
            </div>
          </div>
        </Skeleton>
      )}
    </div>
  );
};
export default LogColumn;
