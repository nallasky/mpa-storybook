import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Skeleton } from 'antd';

import * as SS from '@components/Configuration/styles/LogDefineStyle';
import { useConfiguration } from '@components/Configuration/hooks';
import LogDefineItem from '@components/Configuration/LogDefineItem';
import { Common, Config } from '@assets/locale/en';
import {
  NotificationOutlined,
  PlusOutlined,
  CloudUploadOutlined,
  CloudDownloadOutlined,
} from '@ant-design/icons';
import { NEW_LOG } from '@constants/URL';

const { logDefine: message } = Config;

export const LogDefine = () => {
  const [reLoad, setReLoad] = useState(true);
  const navigate = useNavigate();
  const { gLogDefineList, getLogDefineResource } = useConfiguration();
  const { isLoading, error, isFetching } = getLogDefineResource({
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });

  console.log('gLogDefineList', gLogDefineList);
  return (
    <div css={SS.LogDefineStyle}>
      {error ?? false ? (
        <div>
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <Skeleton
          loading={isLoading || isFetching}
          active
          paragraph={{ rows: 5 }}
        >
          <div>
            <NotificationOutlined />
            <span className="menu-title">{message.title}</span>
          </div>
          <div className="log-button-box">
            <div className="log-add-button-box">
              <button
                css={SS.antdButtonStyle}
                className="white"
                style={{ marginRight: '10px' }}
                onClick={() => navigate(NEW_LOG)}
              >
                <PlusOutlined />
                {message.add_log.title}
              </button>
              <div className="number-label-box">
                <span className="number-label">{`${Common.NumOfItems}: ${gLogDefineList.length}`}</span>
              </div>
            </div>
            <div className="log-import-button-box">
              <button css={SS.antdButtonStyle} className="white">
                <CloudUploadOutlined />
                {Common.Btn_Import}
              </button>
              <button
                css={SS.antdButtonStyle}
                className="white"
                style={{ marginLift: '10px' }}
              >
                <CloudDownloadOutlined />
                {Common.Btn_Export}
              </button>
            </div>
          </div>
          <div className="box-group">
            {gLogDefineList.map((log, idx) => (
              <LogDefineItem info={log} key={idx} />
            ))}
          </div>
        </Skeleton>
      )}
    </div>
  );
};
