import React, { useState } from 'react';
import * as SS from '@components/Configuration/styles/LogDefineStyle';
import {Common} from "@assets/locale/en";
import { Button } from 'antd';
import {
	DoubleRightOutlined,
	PlusOutlined,
	DoubleLeftOutlined,
	EditOutlined,
	DeleteOutlined,
} from '@ant-design/icons';

export const LogDefine = () => {
	const [detail, setDetail] = useState(false);

	return (
		<div css={SS.LogDefineStyle}>
			<div className="box-group">
				<div className="box-group-box">
					<div className="title-wrapper">
						<span className="box-title">LipsFocus</span>
						<div className="box-sub">
							<div>
								<span className="number-label">{Common.NumOfRules}</span>
								<span className="number-value-label">
									5
								</span>
							</div>
							<div>
								<button
									css={SS.antdButtonStyle}
									className="gold"
									onClick={() => {
										setDetail(!detail);
									}}
								>
									{!detail ? (
										<>
											<span>Detail</span>
											<DoubleRightOutlined />
										</>
									) : (
										<>
											<DoubleLeftOutlined />
											<span>Simply</span>
										</>
									)}
								</button>
							</div>
						</div>
					</div>
					{detail === false ? (
						<div className="box-simply-ContentGroup">
							<div className="simply-content">
								<span>12/10</span>
							</div>
							<div className="simply-content">
								<span>13/11</span>
							</div>
							<div className="simply-content">
								<span>12/12</span>
							</div>
							<div className="simply-content">
								<span>12/14</span>
							</div>
							<Button type="primary" shape="circle" icon={<PlusOutlined />} className="simply-content-plus" />
						</div>
					) : (
						<>
							<div className="box-detail-Content-group">
								<div className="detail-content">
									<div>
										<div className="detail-icon">12/10</div>
										<span className="box-label">INFO_2_HEADER_10</span>
									</div>
									<div className="detail-edit-box">
										<Button
											type="dashed"
											icon={<EditOutlined />}
										/>
										<Button
											type="dashed"
											icon={<DeleteOutlined />}
										/>
									</div>
								</div>
								<div className="detail-content">
									<div>
										<div className="detail-icon">13/11</div>
										<span className="Box-label">INFO_3_HEADER_11</span>
									</div>
									<div className="detail-edit-box">
										<Button
											type="dashed"
											icon={<EditOutlined />}
										/>
										<Button
											type="dashed"
											icon={<DeleteOutlined />}
										/>
									</div>
								</div>
								<div className="detail-content">
									<div>
										<div className="detail-icon">12/12</div>
										<span className="Box-label">INFO_2_HEADER_12</span>
									</div>
									<div className="detail-edit-box">
										<Button
											type="dashed"
											icon={<EditOutlined />}
										/>
										<Button
											type="dashed"
											icon={<DeleteOutlined />}
										/>
									</div>
								</div>
								<div className="detail-content">
									<div>
										<div className="detail-icon">12/14</div>
										<span className="box-label">INFO_2_HEADER_14</span>
									</div>
									<div className="detail-edit-box">
										<Button
											type="dashed"
											icon={<EditOutlined />}
										/>
										<Button
											type="dashed"
											icon={<DeleteOutlined />}
										/>
									</div>
								</div>
								<div className="detail-content">
									<div>
										<div className="detail-icon">12/17</div>
										<span className="box-label">INFO_2_HEADER_17</span>
									</div>
									<div className="detail-edit-box">
										<Button
											type="dashed"
											icon={<EditOutlined />}
										/>
										<Button
											type="dashed"
											icon={<DeleteOutlined />}
										/>
									</div>
								</div>
								<div className="detail-content">
									<div>
										<div className="detail-icon">12/17</div>
										<span className="box-label">INFO_2_HEADER_17</span>
									</div>
									<div className="detail-edit-box">
										<Button
											type="dashed"
											icon={<EditOutlined />}
										/>
										<Button
											type="dashed"
											icon={<DeleteOutlined />}
										/>
									</div>
								</div>
							</div>
							<div className="detail-content-button">
								<button
									css={SS.antdButtonStyle}
									className="blue"
								>
									ADD Rule
								</button>
							</div>
						</>
					)}
				</div>
			</div>
		</div>
	);
};

