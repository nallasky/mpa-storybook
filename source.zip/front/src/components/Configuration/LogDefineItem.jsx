import React, { Fragment, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Common, Config } from '@assets/locale/en';
import PropTypes from 'prop-types';
import { Button } from 'antd';
import * as SS from '@components/Configuration/styles/LogDefineStyle';
import {
  DoubleRightOutlined,
  PlusOutlined,
  DoubleLeftOutlined,
  EditOutlined,
  DeleteOutlined,
} from '@ant-design/icons';
import { EDIT_RULE, NEW_RULE } from '@constants/URL';
const { logDefine: message } = Config;

const LogDefineItem = ({ info }) => {
  const [mode, setMode] = useState(message.mode.simple);
  const navigate = useNavigate();
  const { log_name, rules } = info;
  const changeMode = () => {
    setMode((prevState) =>
      prevState === message.mode.simple
        ? message.mode.detail
        : message.mode.simple,
    );
  };
  return (
    <div className="box-group-box">
      <div className="title-wrapper">
        <div className="box-main">
          <span className="box-title">{log_name}</span>
          <button css={SS.antdButtonStyle} className="white dashed">
            <DeleteOutlined />
            DELETE
          </button>
        </div>
        <div className="box-sub">
          <div>
            <span className="number-label">{`${Common.NumOfRules}: ${rules.length}`}</span>
          </div>
          <div>
            <button
              css={SS.antdButtonStyle}
              className="gold"
              onClick={changeMode}
            >
              {mode === message.mode.detail ? (
                <Fragment>
                  <span>{message.mode.simple.toUpperCase()}</span>
                  <DoubleLeftOutlined />
                </Fragment>
              ) : (
                <Fragment>
                  <span>{message.mode.detail.toUpperCase()}</span>
                  <DoubleRightOutlined />
                </Fragment>
              )}
            </button>
          </div>
        </div>
      </div>
      {mode === message.mode.simple ? (
        <div className="box-simply-ContentGroup">
          {rules.map((item, idx) => (
            <div
              className="simply-content"
              key={idx}
            >
              <span>{item.header_count}</span>
            </div>
          ))}
          <div className="button-wrapper">
            <Button
              type="primary"
              shape="circle"
              icon={<PlusOutlined />}
              className="simply-content-plus"
            />
          </div>
        </div>
      ) : (
        <>
          <div className="box-detail-Content-group">
            {rules.map((item, idx) => (
              <div className="detail-content" key={idx}>
                <div>
                  <div className="detail-icon">{item.header_count}</div>
                  <span className="box-label">{item.rule_name}</span>
                </div>
                <div className="detail-edit-box">
                  <Button
                    type="dashed"
                    icon={<EditOutlined />}
                    onClick={() =>
                      navigate(`${EDIT_RULE}/${log_name}/${item.rule_id}`)
                    }
                  />
                  <Button type="dashed" icon={<DeleteOutlined />} />
                </div>
              </div>
            ))}
            <div className="detail-content-button">
              <button
                css={SS.antdButtonStyle}
                className="blue"
                onClick={() => navigate(`${NEW_RULE}/${log_name}`)}
              >
                {message.add_rule.title}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
LogDefineItem.propTypes = {
  info: PropTypes.object,
};
export default LogDefineItem;
