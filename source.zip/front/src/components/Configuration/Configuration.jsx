import { useEffect } from 'react';
import * as SS from './styles/ConfigurationStyle';
import { Tabs } from 'antd';
import { ConfigList } from '@constants/ConfigurationDefault';
import { Config } from '@assets/locale/en';
const Configuration = () => {
  const { TabPane } = Tabs;
  const message = Config.main;

  useEffect(() => {
    console.log('===========Configuration=============');
  }, []);

  return (
    <div css={SS.MainBody}>
      <div className="subTitle">
        <span className="title-text">{message.title}</span>
        <span className="title-text-sub">
          {message.explain.map((str, idx) => (
            <li key={idx}>{str}</li>
          ))}
        </span>
      </div>

      <Tabs css={SS.TabStyle} defaultActiveKey={1}>
        {ConfigList.map((item, idx) => (
          <TabPane
            tab={
              <span style={{ fontSize: 20, fontFamily: 'Poppins' }}>
                {item.title}
              </span>
            }
            key={idx + 1}
          >
            {item.component}
          </TabPane>
        ))}
      </Tabs>
    </div>
  );
};
export default Configuration;
