import { useState } from 'react';

import { useConfiguration } from '@components/Configuration/hooks';
import { RequestOnError } from '@libs/util/common/common';
import { AllowPathRegex } from '@libs/util/regExp';

const useLocalDatabase = () => {
  const [path, setPath] = useState(undefined);
  const { gLocalDbPath } = useConfiguration();
  const [errMsg, setErrMsg] = useState(undefined);
  const { updateLocalDatabaseFunc } = useConfiguration();
  const isValidPath = (path) => {
    if (!AllowPathRegex.test(path.trim())) {
      setErrMsg(`Unusable special characters: \n / * ? " < > | `);
    } else if (errMsg) {
      setErrMsg(undefined);
    }
  };
  const changeLocalDatabasePath = (event) => {
    const {
      target: { value },
    } = event;
    console.log('value ', value);
    isValidPath(value);
    setPath(value);
  };
  const resetLocalDatabasePath = () => {
    console.log('resetLocalDatabasePath');
    setPath(undefined);
  };
  const updateLocalDatabasePath = ({ onSuccess }) => {
    updateLocalDatabaseFunc.mutate(path.trim(), {
      onSuccess,
      onError: RequestOnError,
      onSettled: () => setPath(undefined),
    });
  };

  return {
    localDbPath: path,
    changeLocalDatabasePath,
    updateLocalDatabasePath,
    resetLocalDatabasePath,
    gLocalDbPath,
    errMsg,
    isLoading:
      updateLocalDatabaseFunc?.isLoading || updateLocalDatabaseFunc?.isFetching,
  };
};
export default useLocalDatabase;
