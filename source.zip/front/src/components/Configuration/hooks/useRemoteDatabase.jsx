import { useState } from 'react';
import { Workbook } from 'exceljs';
import { saveAs } from 'file-saver';
import { defaultUploadProps as defaultProps } from '@libs/util/common/common';
import { useConfiguration } from '@components/Configuration/hooks';
import {
  ExcelForm,
  excelFileType,
  csvFileType,
} from '@constants/ConfigurationDefault';
import { Config } from '@assets/locale/en';
import { getFileType } from '@libs/util/util';
import {
  usePostDatabaseSave,
  usePostDatabaseStatus,
} from '@hooks/query/configuration';
const exportCellStyle = (cell) => {
  cell.font = {
    name: 'MS PGothic',
    size: 11,
    color: { argb: '00000000' },
    bold: false,
  };
  cell.alignment = {
    vertical: 'middle',
    horizontal: 'center',
    wrapText: true,
  };
  return cell;
};
const exportTitleStyle = (cell) => {
  cell.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE6E6FA' },
  };
  cell.font = {
    name: 'MS PGothic',
    size: 11,
    color: { argb: '00000000' },
    bold: true,
  };
  cell.alignment = {
    vertical: 'middle',
    horizontal: 'center',
    wrapText: true,
  };
  return cell;
};
const useRemoteDatabase = () => {
  const [uploadFile, setUploadFile] = useState([]);
  const [importList, setImportList] = useState([]);
  const { gDatabaseList } = useConfiguration();
  const dataBaseCheckStatus = usePostDatabaseStatus();
  const dataBaseSave = usePostDatabaseSave();
  const fitToColumn = (columns, data, ws) => {
    for (const property of columns) {
      const width =
        Math.max(
          property ? property.toString().length : 0,
          ...data.map((obj) =>
            obj[property] ? obj[property].toString().length : 0,
          ),
        ) + 2;
      if (property) ws.getColumn(property.toString()).width = width;
    }
  };
  const downloadCommonSetting = () => {
    const excelData = gDatabaseList.map((obj, idx) => ({
      ...obj,
      no: idx + 1,
    }));
    const workbook = new Workbook();
    // add sheet
    const worksheet = workbook.addWorksheet(Config.dataBase.remote.title, {
      views: [{ state: 'frozen', ySplit: 1 }],
    });
    // definition column
    worksheet.columns = ExcelForm.map((obj) => ({ key: obj.key }));
    // title Row
    worksheet.addRow(
      ExcelForm.reduce((acc, obj) => ({ ...acc, [obj.key]: obj.title }), {}),
    );
    worksheet.addRows(excelData);
    return {
      workbook,
      data: excelData,
    };
  };
  const excelDownload = () => {
    const { workbook, data } = downloadCommonSetting();
    const worksheet = workbook.getWorksheet(Config.dataBase.remote.title);
    // Row styles fixed
    worksheet.eachRow((row, idx) =>
      row.eachCell((cell) =>
        idx === 1 ? exportTitleStyle(cell) : exportCellStyle(cell),
      ),
    );
    // column width fixed
    fitToColumn(
      ExcelForm.map((obj) => obj.key),
      data,
      worksheet,
    );

    // write file
    workbook.xlsx.writeBuffer().then((excelButter) => {
      const excelFile = new Blob([excelButter], {
        type: excelFileType,
      });
      saveAs(excelFile, 'remote_export_files.xlsx');
    });
  };
  const csvDownload = () => {
    const { workbook } = downloadCommonSetting();
    // write file
    workbook.csv.writeBuffer().then((excelButter) => {
      const csvFile = new Blob([excelButter], {
        type: csvFileType,
      });
      saveAs(csvFile, 'remote_export_files.csv');
    });
  };
  const castingString = (value) =>
    isNaN(+value)
      ? ['true', 'false'].includes(value.toLowerCase())
        ? value.toLowerCase() === 'true'
        : value
      : +value;
  const csvUpload = (columns, files) => {
    const allRows = files.split(/\r?\n|\r/);
    const List = [];
    allRows.forEach((row, index) => {
      if (index > 0) {
        const rowCells = row.split(',');
        const object = columns.reduce((acc, key, idx) => {
          Object.assign(acc, {
            [key]: castingString(rowCells[idx]),
          });
          return acc;
        }, {});
        console.log('Object', object);
        List.push({ ...object, sts: 'processing' });
      }
    });
    setImportList(List.length ? List : []);
  };
  const xlsxUpload = (columns, files) => {
    const workbook = new Workbook();
    workbook.xlsx.load(files).then(() => {
      const ws = workbook.getWorksheet(Config.dataBase.remote.title);
      const List = [];
      ws.eachRow({ includeEmpty: true }, (currRow, rowNumber) => {
        if (rowNumber > 1) {
          const object = columns.reduce((acc, key, idx) => {
            Object.assign(acc, {
              [key]: castingString(currRow.getCell(idx + 1).value),
            });
            return acc;
          }, {});
          console.log('object', object);
          List.push({ ...object, sts: 'processing' });
        }
      });
      setImportList(List.length ? List : []);
    });
  };
  const uploadFilesProps = {
    ...defaultProps(1, uploadFile, setUploadFile),
    onChange: () => {
      const reader = new FileReader();
      if (uploadFile.length > 0) {
        const type = getFileType(uploadFile) === 'text/csv' ? 'csv' : 'xlsx';
        if (type === 'csv') {
          reader.readAsText(uploadFile[0]);
        } else if (type === 'xlsx') {
          reader.readAsArrayBuffer(uploadFile[0]);
        }
        reader.onload = () => {
          const columns = ExcelForm.map((obj) => obj.key);
          if (type === 'csv') {
            csvUpload(columns, reader.result);
          } else {
            xlsxUpload(columns, reader.result);
          }
        };
      }
    },
    accept:
      '.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  };
  return {
    excelDownload,
    csvDownload,
    uploadFilesProps,
    remoteList: importList,
    updateRemoteList: setImportList,
    dataBaseCheckStatus,
    dataBaseSave,
  };
};
export default useRemoteDatabase;
