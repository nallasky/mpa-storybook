import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { EDIT_RULE, NEW_RULE } from '@constants/URL';
import {
  useDeleteLogDefineLog,
  useDeleteLogDefineRule,
  usePostLogDefineImport,
} from '@hooks/query/configuration';
import {
  defaultUploadProps as defaultProps,
  RequestOnError,
} from '@libs/util/common/common';
import { useConfiguration } from '@components/Configuration/hooks/index';
import { exportLogDefine } from '@libs/axios/configRequest';

const useLogDefine = () => {
  const [importLog, setImportLog] = useState([]);
  const navigate = useNavigate();
  const deleteRuleFunc = useDeleteLogDefineRule();
  const deleteLogFunc = useDeleteLogDefineLog();
  const importLogFunc = usePostLogDefineImport();

  const { gLogDefineList, updateLogDefineList } = useConfiguration();
  const importFilesProps = {
    ...defaultProps(1, importLog, setImportLog),
    accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  };

  const deleteLog = (log_id) => {
    console.log('deleteLog', log_id);

    deleteLogFunc.mutate(log_id, {
      onSuccess: (info) => {
        console.log('info', info);
        updateLogDefineList(gLogDefineList.filter((o) => o.log_id !== log_id));
      },
      onError: RequestOnError,
    });
  };
  const deleteRule = (log_id, rule_id) => {
    console.log('deleteRule : ', log_id, rule_id);
    deleteRuleFunc.mutate(rule_id, {
      onSuccess: (info) => {
        console.log('info', info);
        const logInfo = gLogDefineList.find((o) => o.log_id !== log_id);
        if (logInfo) {
          updateLogDefineList(
            gLogDefineList.map((item) =>
              item.log_id === log_id
                ? {
                    ...item,
                    rules: item.rules.filter((o) => o.rule_id !== rule_id),
                  }
                : item,
            ),
          );
        }
      },
      onError: RequestOnError,
    });
  };
  const editRule = (log_name, rule_id) => {
    navigate(`${EDIT_RULE}/${log_name}/${rule_id}`);
  };
  const addRule = (log_name) => {
    navigate(`${NEW_RULE}/${log_name}`);
  };
  const importLogDefineList = ({ onSuccessFunc }) => {
    console.log('importLog', importLog);
    const formData = new FormData();
    importLog.map((file) => formData.append('files', file));
    importLogFunc.mutate(formData, {
      onSuccess: () => {
        console.log('=====success=====');
        onSuccessFunc();
      },
      onError: RequestOnError,
    });
  };
  const exportLogDefineList = () => {
    exportLogDefine().then(() => console.log('export '));
  };

  return {
    deleteLog,
    deleteRule,
    editRule,
    addRule,
    importFilesProps,
    importLogDefineList,
    exportLogDefineList,
    isEnableImport: importLog.length,
    isImporting: importLogFunc.isLoading,
  };
};

export default useLogDefine;
