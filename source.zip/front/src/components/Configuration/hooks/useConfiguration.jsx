import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  getLogPatternList,
  getLogColumnList,
  getDBList,
  UpdateDatabaseReducer,
  UpdateLogPatternReducer,
  UpdateLogColumnReducer,
} from '@reducers/slices/ConfigurationInfo';
import {
  useDeleteColumnDefineInfo,
  useGetColumnDefineInfo,
  useGetDatabaseInfo,
  useGetLogPatternInfo,
  usePutColumnDefineInfo,
  usePutLogPatternInfo,
} from '@hooks/query/configuration';

const useConfiguration = () => {
  const dispatch = useDispatch();
  const gLogPatternList = useSelector(getLogPatternList);
  const gLogColumnList = useSelector(getLogColumnList);
  const gDatabaseList = useSelector(getDBList);
  const getDatabaseResource = ({ enabled, onSettled }) =>
    useGetDatabaseInfo({
      enabled,
      onSuccess: (info) => {
        updateDatabase(info ?? []);
      },
      onSettled,
    });
  const getLogPatternResource = ({ enabled, onSettled }) =>
    useGetLogPatternInfo({
      enabled,
      onSuccess: (info) => {
        updatePatternList(info ?? []);
      },
      onSettled,
    });
  const getColumnDefineResource = ({ enabled, onSettled }) =>
    useGetColumnDefineInfo({
      enabled,
      onSuccess: (info) => {
        updateLogColumnList(info ?? []);
      },
      onSettled,
    });
  const updateLogPatternFunc = usePutLogPatternInfo();
  const updateColumnDefineFunc = usePutColumnDefineInfo();
  const deleteColumnDefineFunc = useDeleteColumnDefineInfo();

  const updateDatabase = useCallback(
    (value) => {
      dispatch(UpdateDatabaseReducer(value));
    },
    [dispatch],
  );
  const updateLogColumnList = useCallback(
    (value) => {
      dispatch(UpdateLogColumnReducer(value));
    },
    [dispatch],
  );
  const updatePatternList = useCallback(
    (value) => {
      dispatch(UpdateLogPatternReducer(value));
    },
    [dispatch],
  );

  return {
    gLogPatternList,
    gLogColumnList,
    gDatabaseList,
    updateDatabase,
    updateLogColumnList,
    updatePatternList,
    getDatabaseResource,
    getLogPatternResource,
    getColumnDefineResource,
    updateLogPatternFunc,
    updateColumnDefineFunc,
    deleteColumnDefineFunc,
  };
};
export default useConfiguration;
