import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  getLogPatternList,
  getLogColumnList,
  getDBList,
  getLogDefineList,
  UpdateDatabaseReducer,
  UpdateLogPatternReducer,
  UpdateLogColumnReducer,
  UpdateLogDefineReducer,
} from '@reducers/slices/ConfigurationInfo';
import {
  useDeleteColumnDefineInfo,
  useGetColumnDefineInfo,
  useGetDatabaseInfo,
  useGetLogDefineInfo,
  useGetLogPatternInfo,
  usePutColumnDefineInfo,
  usePutLogPatternInfo,
} from '@hooks/query/configuration';

const useConfiguration = () => {
  const dispatch = useDispatch();
  const gLogPatternList = useSelector(getLogPatternList);
  const gLogColumnList = useSelector(getLogColumnList);
  const gLogDefineList = useSelector(getLogDefineList);
  const gDatabaseList = useSelector(getDBList);

  const getDatabaseResource = ({ enabled, onSettled }) =>
    useGetDatabaseInfo({
      enabled,
      onSuccess: (info) => {
        updateDatabase(info ?? []);
      },
      onSettled,
    });
  const getLogPatternResource = ({ enabled, onSettled }) =>
    useGetLogPatternInfo({
      enabled,
      onSuccess: (info) => {
        updatePatternList(info ?? []);
      },
      onSettled,
    });
  const getColumnDefineResource = ({ enabled, onSettled }) =>
    useGetColumnDefineInfo({
      enabled,
      onSuccess: (info) => {
        updateLogColumnList(info ?? []);
      },
      onSettled,
    });
  const getLogDefineResource = ({ enabled, onSettled }) =>
    useGetLogDefineInfo({
      enabled,
      onSuccess: (info) => {
        console.log(info);
        updateLogDefineList(info ?? []);
      },
      onSettled,
    });
  const updateLogPatternFunc = usePutLogPatternInfo();
  const updateColumnDefineFunc = usePutColumnDefineInfo();
  const deleteColumnDefineFunc = useDeleteColumnDefineInfo();

  const updateDatabase = useCallback(
    (value) => {
      dispatch(UpdateDatabaseReducer(value));
    },
    [dispatch],
  );
  const updateLogColumnList = useCallback(
    (value) => {
      dispatch(UpdateLogColumnReducer(value));
    },
    [dispatch],
  );
  const updatePatternList = useCallback(
    (value) => {
      dispatch(UpdateLogPatternReducer(value));
    },
    [dispatch],
  );
  const updateLogDefineList = useCallback(
    (value) => {
      dispatch(UpdateLogDefineReducer(value));
    },
    [dispatch],
  );

  return {
    gLogPatternList,
    gLogColumnList,
    gDatabaseList,
    gLogDefineList,
    updateDatabase,
    updateLogColumnList,
    updatePatternList,
    updateLogDefineList,
    getDatabaseResource,
    getLogPatternResource,
    getColumnDefineResource,
    getLogDefineResource,
    updateLogPatternFunc,
    updateColumnDefineFunc,
    deleteColumnDefineFunc,
  };
};
export default useConfiguration;
