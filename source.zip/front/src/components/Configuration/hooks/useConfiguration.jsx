import { createContext, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  getLogPatternList,
  getLogColumnList,
  getDBList,
  getLogDefineList,
  UpdateDatabaseReducer,
  UpdateLogPatternReducer,
  UpdateLogColumnReducer,
  UpdateLogDefineReducer,
  getLogColumnDefType,
  getLogColumnDataType,
  getLocalDBPath,
  UpdateLocalDatabaseReducer,
} from '@reducers/slices/ConfigurationInfo';
import {
  useDeleteColumnDefineInfo,
  useGetColumnDefineInfo,
  useGetRemoteDatabaseInfo,
  useGetLocalDatabaseInfo,
  usePutLocalDatabaseInfo,
  useGetLogDefineInfo,
  useGetLogPatternInfo,
  usePutColumnDefineInfo,
  usePutLogPatternInfo,
} from '@hooks/query/configuration';

const useConfiguration = () => {
  const dispatch = useDispatch();
  const gLogPatternList = useSelector(getLogPatternList);
  const gLogColumnDataTypeList = useSelector(getLogColumnDataType);
  const gLogColumnDefaultTypeList = useSelector(getLogColumnDefType);
  const gLogColumnList = useSelector(getLogColumnList);
  const gLogDefineList = useSelector(getLogDefineList);
  const gDatabaseList = useSelector(getDBList);
  const gLocalDbPath = useSelector(getLocalDBPath);

  const getDatabaseResource = ({ enabled, onSettled }) =>
    useGetRemoteDatabaseInfo({
      enabled,
      onSuccess: (info) => {
        const list = (info ?? []).map((item, index) => ({
          ...item,
          idx: index + 1,
        }));
        updateRemoteDatabase(list);
      },
      onSettled,
    });
  const getLocalDatabaseResource = ({ enabled, onSettled }) =>
    useGetLocalDatabaseInfo({
      enabled,
      onSuccess: (path) => {
        console.log('path', path);
        updateLocalDatabase(path);
      },
      onSettled,
    });
  const getLogPatternResource = ({ enabled, onSettled }) =>
    useGetLogPatternInfo({
      enabled,
      onSuccess: (info) => {
        const list = (info ?? []).map((item, index) => ({
          ...item,
          idx: index + 1,
        }));
        updatePatternList(list);
      },
      onSettled,
    });
  const getColumnDefineResource = ({ enabled, onSettled }) =>
    useGetColumnDefineInfo({
      enabled,
      onSuccess: (info) => {
        const list = (info.data ?? []).map((item, index) => ({
          ...item,
          idx: index + 1,
        }));
        updateLogColumnList({ ...info, data: list });
      },
      onSettled,
    });
  const getLogDefineResource = ({ enabled, onSettled }) =>
    useGetLogDefineInfo({
      enabled,
      onSuccess: (info) => {
        console.log(info);
        updateLogDefineList(info ?? []);
      },
      onSettled,
    });
  const updateLocalDatabaseFunc = usePutLocalDatabaseInfo();
  const updateLogPatternFunc = usePutLogPatternInfo();
  const updateColumnDefineFunc = usePutColumnDefineInfo();
  const deleteColumnDefineFunc = useDeleteColumnDefineInfo();

  const updateRemoteDatabase = useCallback(
    (value) => {
      dispatch(UpdateDatabaseReducer(value));
    },
    [dispatch],
  );
  const updateLocalDatabase = useCallback(
    (value) => {
      dispatch(UpdateLocalDatabaseReducer(value));
    },
    [dispatch],
  );
  const updateLogColumnList = useCallback(
    (value) => {
      dispatch(UpdateLogColumnReducer(value));
    },
    [dispatch],
  );
  const updatePatternList = useCallback(
    (value) => {
      dispatch(UpdateLogPatternReducer(value));
    },
    [dispatch],
  );
  const updateLogDefineList = useCallback(
    (value) => {
      dispatch(UpdateLogDefineReducer(value));
    },
    [dispatch],
  );

  return {
    gLogPatternList,
    gLogColumnList,
    gDatabaseList,
    gLocalDbPath,
    gLogDefineList,
    gLogColumnDataTypeList,
    gLogColumnDefaultTypeList,
    updateRemoteDatabase,
    updateLocalDatabase,
    updateLogColumnList,
    updatePatternList,
    updateLogDefineList,
    getDatabaseResource,
    getLocalDatabaseResource,
    getLogPatternResource,
    getColumnDefineResource,
    getLogDefineResource,
    updateLogPatternFunc,
    updateColumnDefineFunc,
    deleteColumnDefineFunc,
    updateLocalDatabaseFunc,
  };
};
export default useConfiguration;
export const LogDefineInfo = createContext(null);
