import { Fragment, useState, useEffect } from 'react';
import { Common, Config } from '@assets/locale/en';
import * as SS from '@components/Configuration/styles/ConfigurationStyle';
import { DatabaseListTable } from '@constants/ConfigurationDefault';
import { Table, Skeleton } from 'antd';
import {
  DatabaseOutlined,
  CloudUploadOutlined,
  CloudDownloadOutlined,
} from '@ant-design/icons';
import {
  useConfiguration,
  useRemoteDatabase,
} from '@components/Configuration/hooks';
import useModal from '@libs/util/modalControl/useModal';
import RemoteDatabaseImportModal from '@components/Configuration/RemoteDatabaseImportModal';
import StatusTag from '@components/common/atoms/StatusTag/StatusTag';

const message = Config.dataBase;

const RemoteDatabaseSetting = () => {
  const [reLoad, setReLoad] = useState(false);
  const { openModal } = useModal();
  const { gDatabaseList, getDatabaseResource } = useConfiguration();
  const { excelDownload, csvDownload } = useRemoteDatabase();
  const { isLoading, error, isFetching } = getDatabaseResource({
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });
  const RenderFunc = (type, record, index) => {
    return type === 'no' ? (
      index + 1
    ) : type === 'address' ? (
      `${record['dbname']}@${record['host']}`
    ) : type === 'sts' ? (
      <StatusTag status={record[type].toLowerCase()} />
    ) : (
      record[type]
    );
  };
  useEffect(() => {
    console.log('RemoteDatabase reLoad', reLoad);
    setReLoad(true);
  }, []);
  return (
    <Fragment>
      <div>
        <DatabaseOutlined />
        <span className="menu-title">{message.remote.title}</span>
      </div>
      {error ?? false ? (
        <div className="remote-setting">
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <Skeleton
          loading={isLoading || isFetching}
          active
          paragraph={{ rows: 5 }}
        >
          <div className="remote-setting">
            <div style={{ display: 'flex', gap: '4px' }}>
              <span className="label">{Common.NumOfItems}</span>
              <span style={{ color: '#1890ff' }}>{gDatabaseList.length}</span>
            </div>
            <div className="button">
              <button
                css={SS.antdButtonStyle}
                className="white"
                onClick={() =>
                  openModal(RemoteDatabaseImportModal, {
                    onSave: () => setReLoad(true),
                  })
                }
              >
                <CloudUploadOutlined />
                {Common.Btn_Import}
              </button>
              <button
                css={SS.antdButtonStyle}
                className="white"
                style={{ marginLift: '10px' }}
                onClick={() => {
                  excelDownload();
                  csvDownload();
                }}
              >
                <CloudDownloadOutlined />
                {Common.Btn_Export}
              </button>
            </div>
          </div>
          <div className="table remoteTable">
            <Table
              dataSource={gDatabaseList}
              bordered
              size="middle"
              tableLayout="fixed"
            >
              {DatabaseListTable.map((column) => {
                return (
                  column.dataIndex !== 'edit' && (
                    <Table.Column
                      key={column.dataIndex}
                      title={column.title}
                      dataIndex={column.dataIndex}
                      render={(_, record, index) =>
                        RenderFunc(column.dataIndex, record, index)
                      }
                      width={column.width}
                    />
                  )
                );
              })}
            </Table>
          </div>
        </Skeleton>
      )}
    </Fragment>
  );
};
export default RemoteDatabaseSetting;
