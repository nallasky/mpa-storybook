import { useState, useEffect } from 'react';
import { Common, Config } from '@assets/locale/en';
import * as SS from '@components/Configuration/styles/ConfigurationStyle';
import PropTypes from 'prop-types';
import { Table, Popconfirm, Button } from 'antd';
import { DeleteOutlined } from '@ant-design/icons';
import { DatabaseListTable } from '@constants/ConfigurationDefault';
import { MSG_CONFIRM_DELETE } from '@constants/Message';
import { Upload } from '@components/common/atoms/Upload';
import { useRemoteDatabase } from '@components/Configuration/hooks';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import { RequestOnError } from '@libs/util/common/common';
import StatusTag from '@components/common/atoms/StatusTag/StatusTag';

const message = Config.dataBase.remote.import;

const RemoteDatabaseImportModal = ({ onClose, onSave }) => {
  const [isVisible, setIsVisible] = useState(true);
  const {
    uploadFilesProps,
    remoteList,
    updateRemoteList,
    dataBaseCheckStatus,
    dataBaseSave,
    chkStatus,
    setChkStatus,
  } = useRemoteDatabase();
  const modalClose = () => {
    setIsVisible(false);
    onClose();
  };
  const modalOk = () => {
    const list = [];
    remoteList.forEach((obj) => {
      delete obj['idx'];
      delete obj['no'];
      delete obj['sts'];
      list.push(obj);
    });

    dataBaseSave.mutate(list, {
      onSuccess: () => {
        onSave();
        modalClose();
      },
      onError: RequestOnError,
    });
  };
  const RenderFunc = (type, record, index) => {
    return type === 'no' ? (
      index + 1
    ) : type === 'edit' ? (
      <div>
        <Popconfirm
          title={MSG_CONFIRM_DELETE}
          onConfirm={() =>
            updateRemoteList(
              remoteList.filter((obj) => obj.idx !== record['idx']),
            )
          }
        >
          <Button type="dashed" icon={<DeleteOutlined />} />
        </Popconfirm>
      </div>
    ) : type === 'address' ? (
      `${record['dbname']}@${record['host']}`
    ) : type === 'sts' ? (
      <StatusTag status={record[type]?.toUpperCase() ?? ''} />
    ) : (
      record[type]
    );
  };
  const connectionRequest = async () => {
    for (const remote of remoteList) {
      if (remote.sts === 'processing') {
        const obj = { ...remote };
        delete obj['idx'];
        delete obj['no'];
        delete obj['sts'];
        delete obj['name'];
        console.log('remote', remote, remoteList);
        await dataBaseCheckStatus
          .mutateAsync(remote)
          .then(() => {
            console.log('mutation then');
            updateRemoteList((prevState) =>
              prevState.map((db) =>
                db.idx === remote.idx ? { ...db, sts: 'success' } : db,
              ),
            );
          })
          .catch((err) => {
            console.log('err');
            RequestOnError(err);
            updateRemoteList((prevState) =>
              prevState.map((db) =>
                db.idx === remote.idx ? { ...db, sts: 'error' } : db,
              ),
            );
          });
      }
    }
  };
  useEffect(() => {
    if (chkStatus) {
      connectionRequest().finally(setChkStatus(false));
    }
  }, [chkStatus]);
  return (
    <DraggableModal
      css={SS.ModalStyle}
      title={message.title}
      visible={isVisible}
      width={800}
      footer={
        <div css={SS.ModalFooterStyle}>
          <button
            css={SS.antdButtonStyle}
            className="white"
            style={{ borderRadius: '10px' }}
            onClick={modalClose}
          >
            {Common.Btn_Cancel}
          </button>
          <button
            css={SS.antdButtonStyle}
            className="blue"
            style={{ borderRadius: '10px' }}
            onClick={modalOk}
          >
            {Common.Btn_OK}
          </button>
        </div>
      }
      cancelHandler={modalClose}
      maskClosable
      centered
    >
      <div css={SS.ConfigurationModalStyle}>
        <div className="modal-body-style upload-label">
          <Upload
            label={message.alert}
            type={'Drag'}
            uploadProps={uploadFilesProps}
          />
          <div className="table remote-modal-table">
            {remoteList.length > 0 ? (
              <Table
                dataSource={remoteList}
                bordered
                size="middle"
                tableLayout="auto"
              >
                {DatabaseListTable.map((column) => {
                  return (
                    <Table.Column
                      key={column.dataIndex}
                      title={column.title}
                      dataIndex={column.dataIndex}
                      render={(_, record, index) =>
                        RenderFunc(column.dataIndex, record, index)
                      }
                    />
                  );
                })}
              </Table>
            ) : (
              <div></div>
            )}
          </div>
        </div>
      </div>
    </DraggableModal>
  );
};
RemoteDatabaseImportModal.propTypes = {
  onClose: PropTypes.func,
  onSave: PropTypes.func,
};

export default RemoteDatabaseImportModal;
