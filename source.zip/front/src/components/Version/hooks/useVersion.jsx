import { useState } from 'react';
import { useSelector } from 'react-redux';
import { getVersionInfo } from '@reducers/slices/BasicInfo';
import { useGetVersionInfo } from '@hooks/query/main';
import useCommonInfo from '@hooks/common/useCommonInfo';
import { RequestOnError } from '@libs/util/common/common';

const useVersion = () => {
  const [visible, setVisible] = useState(false);
  const versionInfo = useSelector(getVersionInfo);
  const { setVersionInfo } = useCommonInfo();
  const getVersion = ({ enabled, onSettled }) =>
    useGetVersionInfo({
      enabled: enabled,
      onSuccess: (data) => {
        console.log(data);
        setVersionInfo(data);
      },
      onError: RequestOnError,
      onSettled,
    });

  const showDrawer = () => {
    setVisible(true);
  };
  const onClose = () => {
    setVisible(false);
  };
  return {
    showVersionDrawer: showDrawer,
    closeVersionDrawer: onClose,
    isVersionShow: visible,
    versionInfo,
    getVersion,
  };
};
export default useVersion;
