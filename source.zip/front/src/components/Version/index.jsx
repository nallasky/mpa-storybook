export { default as VersionInfo } from './Version';
