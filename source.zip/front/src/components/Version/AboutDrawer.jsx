import { Fragment } from 'react';
import { Divider, Drawer } from 'antd';
import PropTypes from 'prop-types';
import Markdown from 'markdown-to-jsx';
import {
  versionItemDiv as ItemDiv,
  versionItemLabel as ItemLabel,
} from './styles/versionStyle';

const AboutDrawer = ({ show, closeFunc, info }) => {
  const { title, version, app_mode, copyright, licenses } = info;

  return (
    <Fragment>
      <Drawer
        title={title}
        width={600}
        closable={true}
        onClose={closeFunc}
        visible={show}
        placement="right"
      >
        <div css={ItemDiv}>
          <p css={ItemLabel}>{'Version'}:</p>
          {version}
        </div>
        <div css={ItemDiv}>
          <p css={ItemLabel}>{'App Mode'}:</p>
          {app_mode}
        </div>
        <div css={ItemDiv}>
          <p css={ItemLabel}>{'CopyRight'}:</p>
          {copyright}
        </div>
        <Divider />
        <Markdown>{licenses}</Markdown>
      </Drawer>
    </Fragment>
  );
};

AboutDrawer.propTypes = {
  show: PropTypes.bool,
  closeFunc: PropTypes.func,
  info: PropTypes.object,
};

export default AboutDrawer;
