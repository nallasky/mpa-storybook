import { useState } from 'react';
import AboutDrawer from './AboutDrawer';
import useVersion from './hooks/useVersion';
import { css } from '@emotion/react';
import { Spin } from 'antd';
import { loadingWrapper } from '@components/Version/styles/versionStyle';

const Version = () => {
  const [reload, setReload] = useState(true);
  const {
    versionInfo,
    getVersion,
    showVersionDrawer,
    closeVersionDrawer,
    isVersionShow,
  } = useVersion();
  const { isLoading, error } = getVersion({
    enabled: reload,
    onSettled: () => setReload(false),
  });
  if (isLoading)
    return (
      <div css={loadingWrapper}>
        <Spin tip="Loading..." size="large" />
      </div>
    );

  if (error)
    return (
      <div>
        <p>error occurred</p>
        <p>{error?.message ?? 'ERROR'}</p>
      </div>
    );

  const { copyright, version, title } = versionInfo;

  return (
    <div css={footerStyle}>
      <div>
        <div
          onClick={showVersionDrawer}
          style={{ textDecoration: 'underline', cursor: 'pointer' }}
        >
          {title} {version}
        </div>
        <AboutDrawer
          show={isVersionShow}
          closeFunc={closeVersionDrawer}
          info={versionInfo}
        />
      </div>
      <div>{copyright}</div>
    </div>
  );
};

const footerStyle = css`
  display: flex;
  justify-content: space-between;
  width: 1440px;
  color: var(--ckr-gray-1);
`;

export default Version;
