import React, { useState } from 'react';
import { JobSetting } from '../../UI/organisms';
import ProgressModal from '../../UI/organisms/ProgressModal';
import { useHistory, useLocation } from 'react-router';
import {
  getEquipmentValidDate,
  getEquipmentList,
} from '../../../lib/api/axios/requests';
import useJobSettingInfo from '../../../hooks/useJobSettingInfo';
import {
  arrayRemove,
  arrayShift,
  arrayUnshift,
  getParseData,
} from '../../../lib/util/Util';
import { ANALYSIS, MAIN, PROCESS } from '../../../lib/api/Define/URL';
import NotificationBox from '../../UI/molecules/NotificationBox/Notification';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { QUERY_KEY } from '../../../lib/api/Define/QueryKey';
import {
  getConvertJobStatus,
  getRequestIdFromJobSetting,
  getResource_JobSetting,
  uploadFiles_JobSetting,
  deleteHistoryJob,
} from '../../../lib/api/axios/useJobSettingRequest';
import {
  MSG_LOCAL,
  MSG_REMOTE,
  MSG_SQL,
} from '../../../lib/api/Define/Message';
import { R_OK } from '../../../lib/api/Define/etc';

const Job = () => {
  const [isProcessJob, setProcessJob] = useState(false);
  const [refetchInterval, setRefetchInterval] = useState(0);
  const [reloadEquipment, setReloadEquipment] = useState(false);
  const [reloadPeriod, setReloadPeriod] = useState(false);
  const history = useHistory();
  const location = useLocation();
  const queryClient = useQueryClient();
  const {
    isOpenCreateJob,
    closeCreateJob,
    openCreateJob,
    setJobSettingResource,
    jobSettingInfo,
    setJobSettingInfo,
    currentPath,
    setCurrentPath,
    urlList,
    jobResource,
  } = useJobSettingInfo();

  const jobSettingResource = useQuery(
    [QUERY_KEY.JOBSETTING_INIT, currentPath[0]],
    () => getResource_JobSetting({ func_id: currentPath[0] }),
    {
      enabled: !!(
        urlList?.map((obj) => obj.func).includes(currentPath[0]) ?? false
      ),
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: ({ info }) => {
        openCreateJob();
        setReloadPeriod(false);
        setReloadEquipment(false);
        setJobSettingResource(info, currentPath[0]);
      },
    },
  );
  useQuery(
    [
      QUERY_KEY.JOBSETTING_USER_FAB_EQUIPMENT_LIST,
      jobSettingInfo?.db_id,
      jobSettingInfo?.table_name,
    ],
    () =>
      getEquipmentList({
        db_id: jobSettingInfo?.db_id,
        table_name: jobSettingInfo?.table_name,
      }),
    {
      enabled:
        reloadEquipment &&
        jobSettingInfo?.job_type === MSG_REMOTE &&
        !!jobSettingInfo?.db_id &&
        !!jobSettingInfo?.table_name,
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: ({ info }) => {
        setJobSettingInfo((prev) => {
          return {
            ...prev,
            info: info,
          };
        });
      },
      onSettled: () => {
        setReloadEquipment(false);
      },
    },
  );

  useQuery(
    [
      QUERY_KEY.JOBSETTING_EQUIPMENT_VALID_DATE,
      jobSettingInfo?.db_id,
      jobSettingInfo?.table_name,
    ],
    () =>
      getEquipmentValidDate({
        db_id: jobSettingInfo?.db_id,
        table_name: jobSettingInfo?.table_name,
        equipment_name: jobSettingInfo?.equipment_name,
      }),
    {
      enabled:
        reloadPeriod &&
        jobSettingInfo?.job_type === MSG_REMOTE &&
        !!jobSettingInfo?.db_id &&
        !!jobSettingInfo?.table_name &&
        !!jobSettingInfo?.equipment_name,

      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: ({ info }) => {
        setJobSettingInfo((prev) => {
          return {
            ...prev,
            period: { start: info.start, end: info.end },
            selected: { start: info.start, end: info.end },
          };
        });
      },
      onSettled: () => {
        setReloadPeriod(false);
      },
    },
  );
  const deleteHistory = useMutation(
    [QUERY_KEY.JOBSETTING_DELETE_HISTORY],
    (historyId) => deleteHistoryJob({ HistoryId: historyId }),
    {
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: (status) => {
        if (status === R_OK) {
          queryClient
            .invalidateQueries([QUERY_KEY.JOBSETTING_INIT, currentPath[0]])
            .then((_) => _);
        }
      },
    },
  );
  const convertJobStatus = useQuery(
    [QUERY_KEY.JOBSETTING_CONVERT_JOB_STATUS, jobSettingInfo?.job_id],
    () => getConvertJobStatus({ jobId: jobSettingInfo?.job_id }),
    {
      enabled:
        jobSettingInfo?.job_type === MSG_LOCAL &&
        !!(jobSettingInfo?.job_id ?? false),
      refetchInterval: refetchInterval,
      onSuccess: (data) => {
        if (data.percent === '100' && data.status !== 'running')
          setRefetchInterval(0);
      },
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
        setRefetchInterval(0);
      },
    },
  );

  const localJobConvert = useMutation(
    [QUERY_KEY.JOBSETTING_LOCAL_JOB],
    ({ upload_id }) =>
      getRequestIdFromJobSetting({
        source: jobSettingInfo?.source,
        object: jobSettingInfo,
        files: upload_id,
      }),
    {
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: ({ rid }) => {
        console.log('[jobConvert]JobId', rid);
        setJobSettingInfo({ ...jobSettingInfo, job_id: rid });
        setRefetchInterval(1000);
      },
    },
  );
  const jobFileUpload = useMutation(
    [QUERY_KEY.JOBSETTING_FILE_UPLOAD],
    (src_file) => uploadFiles_JobSetting(src_file),
    {
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: ({ upload_id }) => {
        console.log('[getResource_JobSetting]upload_id', upload_id);
        localJobConvert.mutate({ upload_id: upload_id });
      },
    },
  );

  const remoteJob = useMutation(
    [QUERY_KEY.JOBSETTING_REMOTE_JOB],
    ({ source }) =>
      getRequestIdFromJobSetting({ source: source, object: jobSettingInfo }),
    {
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: ({ rid }) => {
        goAnalysisPage(
          urlList.find((obj) => obj.func === jobSettingInfo.func_id) ?? {
            func: '',
            path: [],
          },
          rid,
        );
        closeCreateJob();
      },
    },
  );
  const goAnalysisPage = (jobPath, rid) => {
    if (jobPath.func !== '') {
      const newPath = currentPath.slice(currentPath.indexOf(MAIN)); //
      newPath.unshift(jobPath.func); //
      newPath.unshift(ANALYSIS); //
      setCurrentPath(newPath);
    }
    if (rid ?? false) {
      history.push({
        pathname: ANALYSIS,
        state: {
          history_id: `${jobSettingInfo?.history_id ?? undefined}`,
          equipment_name: `${jobSettingInfo?.equipment_name ?? undefined}`,
          job_type: `${jobSettingInfo.job_type}`,
          func_id: `${jobSettingInfo.func_id}`,
          job_id: `${rid}`,
          db_id: `${jobSettingInfo?.db_id ?? undefined}`,
          sql: `${jobSettingInfo?.sql ?? undefined}`,
        },
      });
    } else {
      NotificationBox('ERROR', 'Failed to create jobID', 4.5);
    }
  };

  const startEnableCheck = () => {
    const source = jobSettingInfo?.source ?? MSG_LOCAL;
    if (source === MSG_LOCAL) {
      return Boolean(
        !!jobSettingInfo?.src_file &&
          !!jobSettingInfo?.log_name &&
          deleteHistory.isLoading === false,
      );
    } else if (source === MSG_REMOTE) {
      return Boolean(
        !!jobSettingInfo?.db_id &&
          !!jobSettingInfo?.equipment_name &&
          deleteHistory.isLoading === false,
      );
    } else if (source === MSG_SQL) {
      return Boolean(
        !!jobSettingInfo?.db_id &&
          !!jobSettingInfo?.sql &&
          deleteHistory.isLoading === false,
      );
    } else {
      //history??
      console.log('jobsetting source: ', jobSettingInfo?.job_type);
      return Boolean(deleteHistory.isLoading === false);
    }
  };
  const startAnalysis = async () => {
    console.log('jobSettingInfo', jobSettingInfo);
    const { src_file } = jobSettingInfo;

    if ((jobSettingInfo?.source || 'local') === 'local') {
      closeJobModal({ next: PROCESS });
      setProcessJob(true);
      jobFileUpload.mutate(src_file);
    } else {
      closeJobModal({ next: undefined });
      //      closeCreateJob();
      await remoteJob.mutate({ source: jobSettingInfo.job_type });
    }
  };

  const closeJobModal = ({ next }) => {
    closeCreateJob();
    Array.isArray(next)
      ? setCurrentPath(next)
      : next === undefined
      ? setCurrentPath(arrayShift(currentPath))
      : setCurrentPath(arrayUnshift(currentPath, next));
  };

  const endProcessModal = async (status, converted) => {
    if (status === 'COMPLETE' && converted > 0) {
      const jobPath = urlList.find(
        (obj2) => obj2.func === jobSettingInfo?.func_id,
      ) ?? { func: '', path: [] };
      if (jobPath.func !== undefined) {
        const newPath = currentPath.slice(currentPath.indexOf(MAIN));
        newPath.unshift(jobPath.func);
        newPath.unshift(ANALYSIS);
        setCurrentPath(newPath);
      }
      history.push({
        pathname: ANALYSIS,
        state: {
          job_type: `${jobSettingInfo?.type ?? 'local'}`,
          func_id: `${jobSettingInfo?.func_id ?? undefined}`,
          job_id: `${jobSettingInfo.job_id}`,
          path: jobPath?.path ?? [],
        },
      });
      setProcessJob(false);
      setJobSettingInfo(undefined);
    } else if (converted === -1) {
      setCurrentPath(arrayRemove(currentPath, location.pathname));
      setProcessJob(false);
      setJobSettingInfo(undefined);
    }
  };

  const contentChange = async (event) => {
    const item = getParseData(event);
    console.log('contentChange', item);
    if (item.id === 'source') {
      const { formList } = jobResource;
      const JobInfo = formList.find((obj) => obj.key === item.value) ?? {};
      setJobSettingInfo((prevState) =>
        JobInfo.type === 'history'
          ? {
              ...prevState,
              [item.id]: item.value,
              ['history_id']: JobInfo.history_id,
              ['job_type']: JobInfo.type,
            }
          : {
              ...prevState,
              [item.id]: item.value,
              ['job_type']: JobInfo.type,
            },
      );
    } else if (item.id === 'DELETE_HISTORY') {
      const { formList } = jobResource;
      const JobInfo = formList.find((obj) => obj.key === item.value) ?? {};
      deleteHistory.mutate(JobInfo.history_id);
    } else if (item.id === 'db_id') {
      setJobSettingInfo((prevState) => ({
        ...prevState,
        db_id: item.value,
        equipment_name: '',
        user_fab: '',
        selected: { start: '', end: '' },
        period: { start: '', end: '' },
      }));
      setReloadEquipment(true);
    } else if (item.id === 'user_fab') {
      setJobSettingInfo((prevState) => ({
        ...prevState,
        equipment_name: '',
        user_fab: item.value,
        selected: { start: '', end: '' },
        period: { start: '', end: '' },
      }));
    } else if (item.id === 'equipment_name') {
      setJobSettingInfo((prevState) => ({
        ...prevState,
        equipment_name: item.value,
        selected: { start: '', end: '' },
        period: { start: '', end: '' },
      }));
      setReloadPeriod(true);
    } else if (item.id === 'period') {
      setJobSettingInfo((prevState) => ({
        ...prevState,
        selected: item.value,
      }));
    } else if (item.id === 'src_file') {
    setJobSettingInfo((prevState) => ({
        ...prevState,
        [item.id]: item.value,
        file_name: item.value,
      }));
    } else {
      setJobSettingInfo((prevState) => ({
        ...prevState,
        [item.id]: item.value,
      }));
    }
  };

  const checkAnalysisStatus = async (
    setStatusFunc,
    setPercentFunc,
    contentsFunc,
  ) => {
    setStatusFunc(convertJobStatus?.data?.status ?? undefined);
    setPercentFunc(convertJobStatus?.data?.percent ?? 0);
    contentsFunc(convertJobStatus?.data?.detail ?? undefined);
  };

  if (jobSettingResource.isLoading) return <></>;
  return (
    <>
      {' '}
      <JobSetting
        isOpen={isOpenCreateJob}
        startFunc={startAnalysis}
        closeFunc={closeJobModal}
        changeFunc={contentChange}
        resource={jobResource}
        info={jobSettingInfo}
        enableCheckFunc={startEnableCheck}
      />
      <ProgressModal
        isOpen={isProcessJob}
        closeFunc={endProcessModal}
        statusFunc={checkAnalysisStatus}
      />
    </>
  );
};

export default Job;
