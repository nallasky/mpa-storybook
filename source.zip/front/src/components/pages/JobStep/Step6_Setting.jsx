import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Empty, Button, Popconfirm } from 'antd';
import { css } from '@emotion/react';
import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import { SettingFilled, CloseCircleFilled } from '@ant-design/icons';
import {
  E_STEP_5,
  E_SINGLE_TYPE,
  E_STEP_2,
  E_STEP_3,
} from '../../../lib/api/Define/etc';
import GraphAddEdit from '../../UI/organisms/GraphAddEdit/GraphAddEdit';
import {
  graphWrapper,
  graphBodyStyle,
  emptyWrapper,
} from '../JobAnalysis/AnalysisGraph/styleGroup';
import { drawGraph } from '../JobAnalysis/AnalysisGraph/functionGroup';
import VisualSetting from './VisualSetting';
import { getParseData } from '../../../lib/util/Util';

const mainWrapper = css`
  font-family: saira;
  width: 100%;
`;
const addGraphButtonEvent = () => {
  console.log('[STEP6]addGraphButtonEvent');
};
const ContentsForm = ({ data }) => {
  return <VisualSetting data={data} type={E_SINGLE_TYPE} />;
};
ContentsForm.propTypes = {
  data: PropTypes.object,
};

const PreviewForm = ({ type }) => {
  const {
    visualStepInfo,
    updateVisualInfo,
    ruleStepConfig,
    funcStepInfo,
  } = useRuleSettingInfo();
  const [isOpen, setIsOpen] = useState(false);
  const [currentIdx, setCurrentIdx] = useState('');
  const [sInfo, setInfo] = useState({
    step: undefined,
    origin_data: undefined,
  });

  const getVisualStep_OriginalData = ({ type, funcStepInfo }) => {
    return type === E_SINGLE_TYPE
      ? E_STEP_5
      : funcStepInfo.use_org_analysis === true
      ? E_STEP_2
      : E_STEP_3;
  };
  const openEdit = (idx) => {
    setCurrentIdx(idx);
    setIsOpen(true);
  };

  const onDelete = (idx) => {
    updateVisualInfo({
      ...visualStepInfo,
      items: visualStepInfo.items.filter((v, i) => {
        return i !== idx;
      }),
    });
  };

  useEffect(() => {
    console.log('[useEffect]visualStepInfo', visualStepInfo);
    if (visualStepInfo.items.length > 0) {
      drawGraph(
        sInfo.origin_data?.row ??
          sInfo.origin_data?.data?.map((o) => {
            const pData = getParseData(o);
            return { [pData.id]: pData.value.row };
          }) ??
          {},
        visualStepInfo.items,
        visualStepInfo,
        'step',
      );
    }
  }, [visualStepInfo]);

  useEffect(() => {
    const step = getVisualStep_OriginalData({ type, funcStepInfo });
    const step_data = ruleStepConfig.find((v) => v.step === step);
    setInfo({
      step: step,
      origin_data: step_data.data,
    });
  }, []);
  return (
    <>
      <div css={mainWrapper}>
        <div
          css={visualStepInfo.items.length > 0 ? graphBodyStyle : emptyWrapper}
        >
          {visualStepInfo.items.length > 0 ? (
            visualStepInfo.items.map((k, i) => {
              return (
                <div key={i} css={graphWrapper}>
                  <div>
                    <Button
                      type="dashed"
                      shape="round"
                      icon={<SettingFilled />}
                      onClick={() => openEdit(i)}
                    >
                      Edit
                    </Button>
                    <Popconfirm
                      title="Are you sure you want to delete this graph?"
                      onConfirm={() => onDelete(i)}
                    >
                      <Button
                        type="dashed"
                        shape="round"
                        icon={<CloseCircleFilled />}
                      >
                        Delete
                      </Button>
                    </Popconfirm>
                  </div>
                  <div id={`step_graph_${i}`} />
                </div>
              );
            })
          ) : (
            <Empty description="No graphs to display." />
          )}
        </div>
      </div>

      {sInfo?.origin_data ?? false ? (
        <GraphAddEdit
          data={sInfo.origin_data}
          closer={() => setIsOpen(false)}
          isOpen={isOpen}
          mode="edit"
          index={currentIdx}
        />
      ) : (
        ''
      )}
    </>
  );
};
PreviewForm.propTypes = {
  type: PropTypes.string,
};
const Step6_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step6_Setting.propTypes = {
  children: PropTypes.node,
};
Step6_Setting.btn_addGraph = addGraphButtonEvent;
Step6_Setting.view_contents = ContentsForm;
Step6_Setting.view_preview = PreviewForm;

export default Step6_Setting;
