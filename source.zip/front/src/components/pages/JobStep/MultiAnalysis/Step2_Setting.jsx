import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
//import { useParams } from 'react-router';
import { Avatar, Button, Divider, List, Spin, Table, Tabs } from 'antd';
import { FormCard } from '../../../UI/atoms/Modal';
import useCommonJob from '../../../../hooks/useBasicInfo';
import InputForm from '../../../UI/atoms/Input/InputForm';
import {
  CheckOutlined,
  ClockCircleOutlined,
  CloseOutlined,
  EditOutlined,
  PaperClipOutlined,
} from '@ant-design/icons';
import {
  MSG_LOCAL,
  MSG_REMOTE,
  MSG_SQL,
} from '../../../../lib/api/Define/Message';
import {
  getFindData,
  getParseData,
  getTableForm,
} from '../../../../lib/util/Util';
import StatusTag from '../../../UI/atoms/StatusTag/StatusTag';
import { useQueries, useQuery, useQueryClient } from 'react-query';
import { QUERY_KEY } from '../../../../lib/api/Define/QueryKey';
import {
  getJobIdStep2MultiFunc,
  getStep2MultiPreview,
  getStep2MultiResource,
} from '../../../../lib/api/axios/useJobStepRequest';
import { StepInputForm } from '../../../UI/organisms/StepInputForm';
import Text from 'antd/lib/typography/Text';
import useRuleSettingInfo from '../../../../hooks/useRuleSettingInfo';
import { AnyRegex } from '../../../../lib/util/RegExp';
import { NotificationBox } from '../../../UI/molecules/NotificationBox';
import {
  getEquipmentList,
  getEquipmentValidDate,
  getRequestParam,
} from '../../../../lib/api/axios/requests';
import { getConvertJobStatus } from '../../../../lib/api/axios/useJobSettingRequest';
import useJobStepSettingInfo from '../../../../hooks/useJobSetpSettingInfo';
import {
  E_MULTI_TYPE,
  E_SINGLE_TYPE,
  E_STEP_2,
  E_STEP_3,
  E_STEP_4,
  R_OK,
} from '../../../../lib/api/Define/etc';
import { MultiJobStepConf as steps } from '../../../../hooks/useJobStepInfo';
import { useParams } from 'react-router';
import DeleteButton from '../../../UI/molecules/PopConfirmButton/DeleteButton';

const tableWrapper = css`
  display: contents;
`;

const FormWrapper = css`
  min-width: 500px;
  min-height: 550px;
  border: 1px dashed #1890ff4d;
  background-color: #f0f5ff;
  margin: 1rem;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;
const TabWrapper = css`
  & div.ant-tabs-nav {
    margin: 0px;
  }
`;

const FunctionListWrapper = css`
  min-height: calc(59%);
  font-weight: 400;
  max-height: 385px;
`;

const PreviewRequest = () => {
  return { data: undefined, step: undefined };
};

const NextRequest = async ({ funcStepInfo, func_id }) => {
  const { use_org_analysis } = funcStepInfo;
  const isEditMode = !!(func_id ?? false);
  console.log('use_org_analysis', use_org_analysis);
  const { info, status } = await getRequestParam(
    isEditMode
      ? `${steps[E_STEP_2].edit}/${func_id}`
      : `${steps[E_STEP_2].new}`,
    undefined,
  );
  if (status === R_OK) {
    return {
      info: { config: info },
      next: use_org_analysis ?? false ? E_STEP_4 : E_STEP_3,
      preview: undefined,
    };
  }
};
const NextButtonEvent = async ({ setLoading, funcStepInfo, func_id }) => {
  setLoading(true);
  /* if (EnableCheck(funcStepInfo) ?? false) {
    PreviewRequest({
      funcStepInfo,
      updateFuncInfo,
    });
  }*/
  return NextRequest({ funcStepInfo, func_id }).then((_) => _);
};
const PreviewButtonEvent = async ({ updateFuncInfo, funcStepInfo }) => {
  updateFuncInfo({
    ...funcStepInfo,
    list: funcStepInfo.list.map((o) => {
      return { ...o, status: 'processing' };
    }),
  });
  return PreviewRequest();
};
const PreviousButtonEvent = () => {};

const EnableCheck = ({ funcStepInfo }) => {
  const list = funcStepInfo?.list ?? [];
  if (list.length > 0) {
    const result = list.map((o) => {
      return (
        Boolean(AnyRegex.test(o?.tab_name ?? '')) &&
        (o.source_type === MSG_LOCAL
          ? Boolean(o?.file_name?.length ?? 0)
          : o.source_type === MSG_SQL
          ? Boolean(o?.info?.db_id ?? 0) && Boolean(o?.info?.sql?.length ?? 0)
          : o.source_type === MSG_REMOTE
          ? Boolean(o?.info?.db_id ?? 0) &&
            Boolean(o?.info?.equipment_name?.length ?? 0) &&
            Boolean(o?.info?.selected?.start?.length ?? 0) &&
            Boolean(o?.info?.selected?.end?.length ?? 0)
          : false)
      );
    });
    return result.filter((o) => o === false).length === 0;
  } else {
    return false;
  }
};

/*============================================================================
==                         STEP 2 CONTENTS                                  ==
============================================================================*/
const initData = {
  id: '',
  func_id: '',
  tab_name: '',
  info: '',
  source_type: '',
  status: '',
  form: undefined,
};
const ContentsForm = ({ onChange, data }) => {
  const { func_id } = useParams();
  const { supportUrl, MenuInfo } = useCommonJob();
  const [funcList, setFuncList] = useState([]);
  const [selected, setSelected] = useState(0);
  const { funcStepInfo, updateFuncInfo } = useRuleSettingInfo();
  const { addCurrentStepPreview } = useJobStepSettingInfo();

  const queryClient = useQueryClient();

  const customSwitch = {
    checkedChildren: <CheckOutlined />,
    unCheckedChildren: <CloseOutlined />,
  };
  const FuncInfo =
    funcStepInfo?.list?.find((obj) => obj.id === selected) ?? undefined;
  //============================================================================
  useQuery(
    [QUERY_KEY.STEP2_MULTI_RESOURCE, selected],
    () =>
      getStep2MultiResource({
        func_id: FuncInfo?.func_id ?? 0,
      }),
    {
      enabled:
        !!selected &&
        Boolean(FuncInfo?.func_id ?? false) &&
        Boolean(FuncInfo?.form ?? true),
      onSuccess: ({ info }) => {
        console.log(info);
        const source_type = info.source_type ?? MSG_LOCAL;
        updateFuncInfo({
          ...funcStepInfo,
          list: funcStepInfo.list.map((obj) =>
            obj.id === selected
              ? {
                  ...obj,
                  source_type: source_type,
                  tab_name:
                    obj?.tab_name ??
                    getFindData(info.form, 'tab_name', 'content'),
                  info:
                    source_type === MSG_LOCAL
                      ? {
                          log_name: getFindData(
                            info.form,
                            'log_name',
                            'content',
                          ),
                        }
                      : source_type === MSG_REMOTE
                      ? {
                          db_id: getFindData(info.form, 'db_id', undefined),
                          table_name: getFindData(
                            info.form,
                            'table_name',
                            undefined,
                          ),
                          user_fab: getFindData(
                            info.form,
                            'user_fab',
                            undefined,
                          ),
                          equipment_name: getFindData(
                            info.form,
                            'equipment_name',
                            undefined,
                          ),
                          period: getFindData(info.form, 'period', undefined),
                          selected: getFindData(info.form, 'period', undefined),
                        }
                      : source_type === MSG_SQL
                      ? {
                          db_id: getFindData(info.form, 'db_id', undefined),
                          sql: getFindData(info.form, 'sql', undefined),
                        }
                      : {},
                  form: info.form,
                }
              : obj,
          ),
        });
      },
    },
  );

  /*
   *  1. DB_ID & Table Name 하나라도 변경 되면, 요청을 한다.
   *  2. Edit 로 들어온 경우에도 user/Fab/Equipment 가 필요하다.
   * */

  useQuery(
    [
      QUERY_KEY.STEP2_USER_FAB_EQUIPMENT_LIST,
      FuncInfo?.info?.db_id,
      FuncInfo?.info?.table_name,
    ],
    () =>
      getEquipmentList({
        db_id: FuncInfo?.info?.db_id,
        table_name: FuncInfo?.info?.table_name,
      }),
    {
      enabled: !!FuncInfo?.info?.db_id && !!FuncInfo?.info?.table_name,
      onSuccess: ({ info }) => {
        updateFuncInfo({
          ...funcStepInfo,
          list: funcStepInfo.list.map((o) =>
            o.id === selected
              ? {
                  ...o,
                  ...info,
                }
              : o,
          ),
        });
      },
    },
  );

  /*
   *  1. DB_ID /TABLE_NAME/EQUIPMENT_NAME 이 설정 되면 Equipment 의 유효한 정보를 가져온다.
   * */

  useQuery(
    [
      QUERY_KEY.STEP2_EQUIPMENT_VALID_DATE,
      FuncInfo?.info?.db_id,
      FuncInfo?.info?.table_name,
      FuncInfo?.info?.equipment_name,
    ],
    () =>
      getEquipmentValidDate({
        db_id: FuncInfo?.info?.db_id,
        table_name: FuncInfo?.info?.table_name,
        equipment_name: FuncInfo?.info?.equipment_name,
      }),
    {
      enabled:
        !!FuncInfo?.info?.db_id &&
        !!FuncInfo?.info?.table_name &&
        !!FuncInfo?.info?.equipment_name,
      onSuccess: ({ info }) => {
        updateFuncInfo({
          ...funcStepInfo,
          list: funcStepInfo.list.map((o) =>
            o.id === selected
              ? {
                  ...o,
                  info: {
                    ...o.info,
                    period: { start: info.start, end: info.end },
                    selected: { start: info.start, end: info.end },
                  },
                }
              : o,
          ),
        });
      },
    },
  );

  useQueries(
    funcStepInfo?.list?.map((object) => {
      return {
        queryKey: [QUERY_KEY.STEP2_MULTI_PREVIEW, object?.id ?? 0],
        onError: (err) => {
          NotificationBox('ERROR', err.message, 0);
        },
        queryFn: () =>
          getJobIdStep2MultiFunc({
            LocalStatus,
            object,
            data:
              object?.source_type === MSG_LOCAL
                ? data.src_file.find((o) => o.id === object.id)?.value
                : undefined,
          }),
        enabled: (object?.status ?? '') === 'processing',
        onSuccess: ({ id, rid, fid, status }) => {
          updateFuncInfo({
            ...funcStepInfo,
            list: funcStepInfo.list.map((obj) => {
              return obj.id === id
                ? { ...obj, status: status, rid: rid, fid: fid }
                : obj;
            }),
          });
        },
      };
    }) ?? [],
  );

  useQuery(
    [QUERY_KEY.STEP2_MULTI_PREVIEW2],
    () =>
      getStep2MultiPreview({
        list: funcStepInfo?.list ?? [],
        use_org_analysis: funcStepInfo?.use_org_analysis ?? false,
      }),
    {
      enabled:
        (funcStepInfo?.list?.length ?? 0) > 0 &&
        (funcStepInfo?.list ?? []).filter(
          (object) => object.status !== 'completed',
        ).length === 0,
      onSuccess: ({ info }) => {
        addCurrentStepPreview({ current: E_STEP_2, info: info });
        const tableData = {};
        info.data.map((obj) => {
          Object.assign(
            tableData,
            Object.fromEntries(
              Object.entries(obj).map(([v1, v2]) => [
                v1,
                getTableForm({ info: v2, max_row: 5 }),
              ]),
            ),
          );
        });
        console.log('tableData ', tableData);
        onChange({
          log_header: Object.fromEntries(
            Object.entries(tableData).map(([key, val]) => [key, val.columns]),
          ),
          log_data: Object.fromEntries(
            Object.entries(tableData).map(([key, val]) => [
              key,
              val.dataSource,
            ]),
          ),
          log_error: undefined,
        });
        updateFuncInfo({
          ...funcStepInfo,
          list:
            funcStepInfo?.list.map((o) => {
              return { ...o, status: 'success' };
            }) ?? [],
        });
      },
      onError: (err) => {
        NotificationBox('ERROR', err.message, 0);
      },
    },
  );
  const LocalStatus = async ({ rid }) => {
    return await queryClient
      .fetchQuery([QUERY_KEY.STEP2_MULTI_LOCAL_JOB_STATUS, rid], () =>
        getConvertJobStatus({ jobId: rid }),
      )
      .then((_) => _);
  };

  const ChangeFunc = (event) => {
    const item = getParseData(event);

    switch (item.id) {
      case 'tab_name':
        updateFuncInfo({
          ...funcStepInfo,
          list: funcStepInfo.list.map((o) =>
            o.id === selected ? { ...o, ...event } : o,
          ),
        });
        break;
      case 'src_file':
        {
          console.log('item.value', item.value);
          const files_name =
            item.value?.getAll('files').map((o) => o.name) ?? null;
          updateFuncInfo({
            ...funcStepInfo,
            list: funcStepInfo.list.map((o) =>
              o.id === selected
                ? {
                    ...o,
                    file_name: files_name,
                  }
                : o,
            ),
          });
          onChange({
            src_file:
              (data?.src_file?.findIndex((o) => o.id === selected) ?? -1) !== -1
                ? data?.src_file.map((o) =>
                    o.id === selected ? { id: selected, value: item.value } : o,
                  )
                : data?.src_file?.length > 0 ?? false
                ? [...data?.src_file, { id: selected, value: item.value }]
                : [{ id: selected, value: item.value }],
          });
        }
        break;
      case 'use_org_analysis':
        console.log('use_org_analysis', item.value);
        updateFuncInfo({
          ...funcStepInfo,
          use_org_analysis: item.value,
        });
        break;
      case 'db_id':
      case 'table_name':
      case 'equipment_name':
      case 'user_fab':
      case 'period':
        RemoteConfigChange(event);
        break;
    }
  };
  const RemoteConfigChange = (event) => {
    const item = getParseData(event);

    switch (item.id) {
      case 'equipment_name':
        updateFuncInfo({
          ...funcStepInfo,
          list: funcStepInfo.list.map((o) =>
            o.id === selected
              ? {
                  ...o,
                  info: {
                    ...o.info,
                    [item.id]: item.value,
                    period: { start: '', end: '' },
                    selected: { start: '', end: '' },
                  },
                }
              : o,
          ),
        });
        break;
      case 'db_id':
        updateFuncInfo({
          ...funcStepInfo,
          list: funcStepInfo.list.map((o) =>
            o.id === selected
              ? {
                  ...o,
                  info:
                    FuncInfo.source_type === MSG_REMOTE
                      ? {
                          ...o.info,
                          [item.id]: item.value,
                          equipment_name: '',
                          user_fab: '',
                          period: { start: '', end: '' },
                          selected: { start: '', end: '' },
                        }
                      : {
                          ...o.info,
                          [item.id]: item.value,
                        },
                }
              : o,
          ),
        });
        break;
      case 'user_fab':
        updateFuncInfo({
          ...funcStepInfo,
          list: funcStepInfo.list.map((o) =>
            o.id === selected
              ? {
                  ...o,
                  info: {
                    ...o.info,
                    [item.id]: item.value,
                    equipment_name: '',
                    period: { start: '', end: '' },
                    selected: { start: '', end: '' },
                  },
                }
              : o,
          ),
        });
        break;
      case 'period':
        {
          updateFuncInfo({
            ...funcStepInfo,
            list: funcStepInfo.list.map((o) =>
              o.id === selected
                ? {
                    ...o,
                    info: {
                      ...o.info,
                      selected: {
                        start: item.value.start,
                        end: item.value.end,
                      },
                    },
                  }
                : o,
            ),
          });
        }
        break;
    }
  };
  const addHandler = (id) => {
    console.log('addHandler', id);
    const list = [...(funcStepInfo?.list ?? '')];
    const idList = list.map((obj) => obj.id);
    const func_info = supportUrl.find((obj) => obj.func === id) ?? {};
    const newData = { ...initData };
    const maxKeyValue = idList.length === 0 ? 0 : Math.max(...idList);
    newData.id = maxKeyValue + 1;
    newData.func_id = id;
    newData.category = func_info.category;
    newData.func_name = func_info.func_name;
    newData.tab_name = list.map((obj) => obj.func_id).includes(id)
      ? `${func_info.func_name}_${list
          .map((obj) => obj.func_id)
          .reduce((arr, e) => arr + (id === e), 0)}`
      : func_info.func_name;
    updateFuncInfo({
      ...funcStepInfo,
      list:
        funcStepInfo?.list ?? false
          ? [...funcStepInfo.list, newData]
          : [newData],
    });
    setSelected(maxKeyValue + 1);
  };

  const deleteHandler = (id) => {
    console.log('deleteHandler', id);
    const dInfo = funcStepInfo.list.find((obj) => obj.id === id);
    updateFuncInfo({
      ...funcStepInfo,
      list: funcStepInfo.list.filter((obj) => obj.id !== id),
    });
    if (dInfo.source_type === MSG_LOCAL) {
      onChange({
        src_file: data?.src_file?.filter((o) => o.id !== id) ?? [],
      });
    }
    if (selected === id) {
      setSelected(0);
    }
  };
  //============================================================================

  useEffect(() => {
    setFuncList(
      MenuInfo.body
        ?.filter(
          (obj1) =>
            obj1?.func.length > 0 &&
            obj1.func.filter((o) => o.info.Source !== 'multi').length > 0,
        )
        .map((category) => {
          return {
            title: category.title,
            value: `category_${category.category_id}`,
            key: `category_${category.category_id}`,
            children: category.func
              ?.filter((o) => o.info.Source !== 'multi')
              .map((func) => {
                return {
                  title: func.title,
                  value: func.func_id,
                  key: func.func_id,
                };
              }),
          };
        }),
    );
    if (func_id ?? false) {
      console.log('func_id', func_id);
      //편집시 데이터 설정 자리
    } else if (funcStepInfo?.use_org_analysis === undefined) {
      updateFuncInfo({ ...funcStepInfo, use_org_analysis: false });
    }
    return () => {
      console.log('contents components unmount');
    };
  }, []);

  //============================================================================

  return (
    <div
      css={{
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
      }}
    >
      <div css={FormWrapper}>
        <div>
          <FormCard
            title={'1. Select Function'}
            formStyle={{ maxHeight: '110px' }}
          >
            <div>
              <InputForm.selectOption
                formName={'function'}
                changeFunc={addHandler}
                treeData={funcList}
              />
            </div>
          </FormCard>
          <Divider
            orientation={'left'}
            style={{ margin: '0px', background: 'rgb(240 245 255)' }}
          >
            <Text code style={{ fontSize: '13px' }}>
              Function List
            </Text>
          </Divider>
          <FormCard
            titleStyle={{ fontWeight: '400' }}
            formStyle={FunctionListWrapper}
          >
            <List
              itemLayout="horizontal"
              dataSource={funcStepInfo?.list ?? []}
              css={{ maxHeight: '300px', overflowY: 'auto' }}
              renderItem={(item) => (
                <List.Item>
                  <List.Item.Meta
                    avatar={<Avatar icon={<PaperClipOutlined />} />}
                    title={`${item?.category}/${item.func_name}/${item.tab_name}`}
                    description={
                      <div>
                        <span css={{ padding: '0px 4px' }}>
                          {item?.source_type ?? ''
                            ? `Source: ${item.source_type}`
                            : ''}
                        </span>
                        <span css={{ padding: '0px 4px' }}>
                          {item?.info?.log_name ?? ''
                            ? `log_name: ${item.info.log_name}`
                            : ''}
                        </span>
                      </div>
                    }
                  />
                  <div style={{ width: '80px' }}>
                    {item.status === 'completed' ? (
                      <StatusTag
                        status={'waiting'}
                        color={'warning'}
                        icon={<ClockCircleOutlined />}
                      />
                    ) : item.status !== '' ? (
                      <StatusTag status={item.status} />
                    ) : (
                      <></>
                    )}
                  </div>
                  <div style={{ margin: '0px 6px' }}>
                    <Button
                      type="dashed"
                      icon={<EditOutlined />}
                      onClick={() => setSelected(item.id)}
                    />
                    <DeleteButton
                      deleteHandler={() => deleteHandler(item.id)}
                    />
                  </div>
                </List.Item>
              )}
            />
          </FormCard>
        </div>
        <div>
          <Divider
            orientation={'left'}
            style={{ margin: '0px', background: 'rgb(240 245 255)' }}
          />
          <FormCard
            title={'2. Use Original Analysis'}
            formStyle={{ maxHeight: '125px' }}
          >
            <div>
              <InputForm.switch
                formLabel={''}
                formName={'use_org_analysis'}
                changeFunc={ChangeFunc}
                custom={customSwitch}
              />
            </div>
          </FormCard>
        </div>
      </div>
      <div css={FormWrapper}>
        <div
          css={{
            backgroundColor: '#0F73BB',
            height: '55px',
            color: '#FFFFFF',
            padding: '16px 24px',
          }}
        >
          {FuncInfo?.category}/{FuncInfo?.func_name ?? ''}
        </div>
        {FuncInfo?.form?.map((item, idx) => (
          <div key={idx}>
            <FormCard title={item.title} titleStyle={{ fontWeight: '400' }}>
              <div>
                {item.items.map((idx2, i) => (
                  <StepInputForm
                    key={i}
                    data={
                      FuncInfo?.source_type === MSG_LOCAL ?? true
                        ? {
                            ...FuncInfo,
                            file_name:
                              data?.src_file?.find((o) => o.id === FuncInfo.id)
                                ?.value ?? undefined,
                          }
                        : FuncInfo
                    }
                    item={item.items[i]}
                    changeFunc={ChangeFunc}
                  />
                ))}
              </div>
            </FormCard>
          </div>
        )) ?? (selected !== 0 ? <Spin tip=" Data Loading..." /> : <></>)}
        <div css={{ backgroundColor: '#0F73BB', height: '55px' }} />
      </div>
    </div>
  );
};
ContentsForm.propTypes = {
  onChange: PropTypes.func,
  data: PropTypes.object,
};
const { TabPane } = Tabs;
const PreviewForm = ({ data, type }) => {
  const [tabSetting, setTabSetting] = useState({ list: [], selected: '' });
  if (data == null) return <></>;
  const { log_header, log_data } = data;

  const TabChangeEvent = (e) => {
    setTabSetting((prev) => {
      return { ...prev, selected: e };
    });
  };

  useEffect(() => {
    if (type === E_MULTI_TYPE) {
      const keyList = Object.keys(log_header ?? {});
      setTabSetting({ list: keyList ?? [], selected: keyList[0] });
    }
  }, [log_header]);

  if (log_header === undefined || log_data === undefined) return <></>;
  if (type === E_SINGLE_TYPE) return <></>;

  return (
    <div css={{ display: 'inline-grid' }}>
      <Tabs
        type="card"
        onChange={TabChangeEvent}
        activeKey={tabSetting.selected}
        css={TabWrapper}
      >
        {tabSetting.list.map((tab) => (
          <>
            <TabPane tab={tab} key={tab}>
              <div css={tableWrapper}>
                <Table
                  bordered
                  pagination={false}
                  columns={log_header?.[tab] ?? []}
                  dataSource={log_data?.[tab] ?? []}
                  size="middle"
                  rowKey="key"
                  scroll={{ x: 'max-content' }}
                />
              </div>
            </TabPane>
          </>
        ))}
      </Tabs>
    </div>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
  type: PropTypes.string,
};
const Step2_Multi_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step2_Multi_Setting.propTypes = {
  children: PropTypes.node,
};

Step2_Multi_Setting.btn_next = NextButtonEvent;
Step2_Multi_Setting.btn_previous = PreviousButtonEvent;
Step2_Multi_Setting.btn_preview = PreviewButtonEvent;
Step2_Multi_Setting.check_next = EnableCheck;
Step2_Multi_Setting.check_preview = EnableCheck;
Step2_Multi_Setting.view_contents = ContentsForm;
Step2_Multi_Setting.view_preview = PreviewForm;

export default Step2_Multi_Setting;
