/*
#=========================================#
| Job TACT Color data                     |
#=========================================#
*/
export const JobTactColor = [
  {
    id: '315A07A1/1LAA1EE',
    color: '#40a9ff',
  },
  {
    id: '425B03A1/1LAA2EE',
    color: '#ffa940',
  },
  {
    id: '546B0DLS/1LDB2EE',
    color: '#52c41a',
  },
];

/*
#=========================================#
| PlateTACT Color Data                    |
#=========================================#
*/
export const PlateTactColor = [
  {
    id: 'Step',
    color: '#f5222d',
  },
  {
    id: 'Measurement',
    color: '#8c8c8c',
  },
  {
    id: 'Calibration',
    color: '#da3c88',
  },
  {
    id: 'Exposure',
    color: '#e1e51d',
  },
  {
    id: 'Error',
    color: '#7a8179',
  },
  {
    id: 'Other',
    color: '#84b2e9',
  },
];

/*
#=========================================#
| Predictive Color Data                   |
#=========================================#
*/
export const Predictive = [
  {
    id: 'Step',
    color: '#f5222d',
  },
  {
    id: 'Measurement',
    color: '#8c8c8c',
  },
  {
    id: 'Calibration',
    color: '#da3c88',
  },
  {
    id: 'Exposure',
    color: '#e1e51d',
  },
  {
    id: 'Error',
    color: '#7a8179',
  },
  {
    id: 'Other',
    color: '#84b2e9',
  },
];

/*
#=========================================#
| DifferenceColor Color Data              |
#=========================================#
*/
export const DifferenceColor = [
  {
    id: 'Step',
    color: '#f5222d',
  },
  {
    id: 'Measurement',
    color: '#8c8c8c',
  },
  {
    id: 'Calibration',
    color: '#da3c88',
  },
  {
    id: 'Exposure',
    color: '#e1e51d',
  },
  {
    id: 'Error',
    color: '#7a8179',
  },
  {
    id: 'Other',
    color: '#84b2e9',
  },
];

/*
#=========================================#
| PlateDetailColor Data                   |
#=========================================#
*/
export const PlateDetailColor = [
  {
    id: 'Step',
    color: '#f5222d',
  },
  {
    id: 'Measurement',
    color: '#8c8c8c',
  },
  {
    id: 'Calibration',
    color: '#da3c88',
  },
  {
    id: 'Exposure',
    color: '#e1e51d',
  },
  {
    id: 'Error',
    color: '#7a8179',
  },
  {
    id: 'Other',
    color: '#84b2e9',
  },
];
