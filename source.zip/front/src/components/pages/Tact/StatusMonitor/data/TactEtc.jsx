export const E_TACT_JOBTACT = 'JobTACT';
export const E_TACT_PLATETACT = 'PlateTACT';
export const E_TACT_PLATEDETAILTACT = 'PlateDetailTACT';

export const E_SETTING_PLATETACT = 'SettingPlateTACT';
export const E_SETTING_PLATEDETAILTACT = 'SettingPlateDetailTACT';
export const E_SETTING_PLATETACTEVENT = 'SettingPlateTACTEvent';
export const E_SETTING_NAME = 'SettingName';
export const E_SETTING_PRIMARY = 'SettingPrimary';