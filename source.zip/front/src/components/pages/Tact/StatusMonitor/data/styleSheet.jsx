import { css, keyframes } from '@emotion/react';

/*
#=========================================#
| TactStatusMonitor CSS                   |
#=========================================#
*/

export const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  width: 100%;
  padding: 1rem;
`;

const moveLeft = keyframes`
  25% {
    transform: translateX(-25px);
  }
  50% {
    transform: translateX(0);
  }
`;

export const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 300px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  &.stretch {
    align-self: stretch;
  }
  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 1rem;
    grid-column: 1 / span 2;
  }
  & .source-button-wrapper {
    float: right;
    margin-top: 10px;
  }
  & > .ant-spin {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    row-gap: 0.5rem;
    background-color: white;
    border-radius: 4px;
    &.ant-spin-spinning {
      z-index: 1200;
    }
  }
  & .foreground {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 4px;
    display: none;
    justify-content: center;
    align-items: center;
    background-color: white;
    &.active {
      display: flex;
      z-index: 5;
      & > div {
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        row-gap: 1rem;
        & > svg {
          position: relative;
          animation: ${moveLeft} 1.5s ease-in-out infinite;
        }
        & > p {
          font-size: 20px;
          font-weight: bold;
        }
      }
    }
  }
`;

export const componentTitleStyle = css`
  font-size: 24px;
  color: #1890ff;
`;

export const contentWrapperStyle = css`
  position: relative;
  margin-top: 3rem;
  min-height: 300px;
  &.mg-bottom {
    margin-bottom: 13px;
  }
  &.ts-source-button-wrapper {
    position: relative;
    text-align-last: center;
    right: -477px;
  }
`;

export const contentStyle = css`
  margin: 0 auto;
  width: 60%;
  &.full-width {
    width: 100%;
  }
  & > div + div {
    margin-top: 2rem;
  }
`;

export const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column-2 {
    grid-template-columns: 0.4fr 1fr;
  }
  &.column-3 {
    grid-template-columns: 0.4fr 1fr 1fr;
  }
  &.flex-between {
    display: flex;
    justify-content: space-between;
  }
  &.etc {
    display: flex;
    justify-content: space-between;
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      &.label {
        &::before {
          display: inline-block;
          color: red;
          font-size: 16px;
          content: '*';
          margin-right: 0.3rem;
        }
        &::after {
          display: inline-block;
          content: ':';
        }
      }
    }
     &.label-2 {
        &::after {
          display: inline-block;
          content: ':';
        }
      }
    }
  }
  &.upload {
    & > span {
      &:first-of-type {
        align-self: start;
      }
      &:last-of-type {
        width: 100%;
        max-width: 471.9px;
        & .ant-upload-list-text {
          margin-top: 0.5rem;
          overflow: auto;
          max-height: 70px;
          &::-webkit-scrollbar {
            width: 8px;
          }
          &::-webkit-scrollbar-track {
            background-color: transparent;
          }
          &::-webkit-scrollbar-thumb {
            border-radius: 4px;
            background-color: rgba(0, 0, 0, 0.2);
          }
          &::-webkit-scrollbar-button {
            width: 0;
            height: 0;
          }
        }
      }
    }
    & .full-width {
      & > .ant-upload-select-text,
      & button {
        width: 100%;
      }
    }
  }
  & > .title {
    width: 100%;
    text-align: center;
    font-size: 20px;
  }
  & > .preset-setting {
    display: flex;
    column-gap: 1rem;
  }
  & .radio-cp-vs {
    display: grid;
    grid-template-columns: repeat(3, 18rem);
    column-gap: 1rem;
    grid-column: span 2;
  }
  & .margin-lr {
    margin: 0 1rem;
  }
  & .margin-r {
    margin-right: 1rem;
  }
  & .tx-right {
    text-align: right;
  }
  & ~ div {
    margin-top: 2rem;
    &.table-wrapper {
      margin-top: 1rem;
    }
  }
  .ant-form-item {
    width: 289px;
    margin-bottom: 0px;
  }
  .ant-form-item-explain-connected {
    min-height: 0px;
  }
  .ant-col-16 {
    max-width: 100%;
  }
`;

export const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-color: white;
  border: none;
  &.color-picker {
    grid-area: 2/1/2/4;
    padding: 0.5rem;
    border-top: 1px solid #f0f0f0;
  }
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: #1890ff;
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: 15px;
    right: 50px;
    & > span:first-of-type {
      color: #52c41a;
    }
  }
  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
    & > span:first-of-type {
      color: #c9c9c9;
    }
  }
`;

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: white;
    border: 1px dashed #d9d9d9;
    &:disabled {
      background-color: #d9d9d9;
      color: transparent;
      &::before {
        position: absolute;
        width: 100%;
        top: 5px;
        left: 0;
        content: 'X';
        color: white;
        font-weight: bold;
        font-size: 20px;
      }
    }
  }
  &.blue {
    color: white;
    background-color: #1890ff;
    border: 1px solid #1890ff;
  }
  &.color-picker {
    width: 100%;
    border-radius: unset;
    font-weight: 400;
  }
  &.tact-download {
    margin-left: 8px;
    font-weight: 400;
  }
  &.view-graph {
    width: 136px;
    float: right;
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;

export const controlStyle = css`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  &.tact {
    padding-bottom: 1rem;
    border-bottom: 2px solid #d9d9d9;
  }
`;

export const tactGraphColorButtonStyle = css`
  display: block;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 8px 16px;
  background: #ffffff;
  border: 1px dashed #d9d9d9;
  box-sizing: border-box;
  border-radius: 10px;
  margin: 0px 30px;
  &:hover {
    display: block;
    background: #ffffff;
    border: 1px dashed #69c0ff;
    box-sizing: border-box;
    border-radius: 10px;
  }
`;

export const tactGraphColorSettingStyle = css`
  margin: 0 auto;
  width: 60%;
  display: flex;
  padding: 1rem 0rem;
  align-items: center;
`;
export const colorSettingStyle = css`
  display: flex;
  justify-content: space-between;
  padding: 10px 16px;
  border-bottom: 1px solid #f0f0f0;
  background-color: #ffff;
  & > span {
    font-size: 20px;
    font-weight: bold;
  }
  & > button {
    background-color: #ffff;
    border: unset;
    cursor: pointer;
    & > span {
      color: #bfbfbf;
    }
  }
  & button:hover {
      & > span {
        color: #262626;
      }
    }
  }
`;

export const tactColorBoxStyle = css`
  display: grid;
  grid-template-columns: auto 218px;
  padding: 1rem 1rem 0rem;
  border-radius: 10px;
  background: #ffffff;
  grid-gap: 5px;
  min-height: 240px;
  & > div {
    max-height: 250px;
    overflow: auto;
    &::-webkit-scrollbar {
      width: 8px;
    }
    &::-webkit-scrollbar-track {
      background-color: transparent;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 4px;
      background-color: #91d5ff;
    }
    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }
    &:first-of-type > div {
      padding: 10px 5px;
    }
  }
  & .rc-color-picker-trigger {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    border: none;
  }
`;

/*
#=========================================#
| TactTSMemoryDump CSS                    |
#=========================================#
*/

export const tsComponentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 300px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  &.stretch {
    align-self: stretch;
  }
  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 2rem;
  }
`;

export const tsMemoryDumpSectionStyle = css`
  display: grid;
  position: relative;
  width: 100%;
  padding: 1rem;
  row-gap: 1rem;
`;

export const tsMemoryDumpContentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  margin: 0 auto;
  width: 50%;
  &.column-2 {
    grid-template-columns: 0.4fr 1fr;
  }
  &.column-3 {
    grid-template-columns: 0.4fr 1fr 1fr;
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      &.label {
        &::before {
          display: inline-block;
          color: red;
          font-size: 16px;
          content: '*';
          margin-right: 0.3rem;
        }
        &::after {
          display: inline-block;
          content: ':';
        }
      }
    }
  }
  &.upload {
    & > span {
      &:first-of-type {
        align-self: start;
      }
      &:last-of-type {
        width: 100%;
        & .ant-upload-list-text {
          margin-top: 0.5rem;
          overflow: auto;
          height: 60px;
          &::-webkit-scrollbar {
            width: 8px;
          }
          &::-webkit-scrollbar-track {
            background-color: transparent;
          }
          &::-webkit-scrollbar-thumb {
            border-radius: 4px;
            background-color: rgba(0, 0, 0, 0.2);
          }
          &::-webkit-scrollbar-button {
            width: 0;
            height: 0;
          }
        }
      }
    }
    & .full-width {
      & > .ant-upload-select-text,
      & button {
        width: 100%;
      }
    }
  }
  & .radioStyle {
    display: flex;
    justify-content: space-between;
  }
`;

export const tsTableStyle = css`
  padding: 1rem;
  & .ant-table-thead > tr > th {
    font-weight: 900;
    text-align: center;
  }
  & .ant-table-tbody > tr {
    & td:nth-child(n + 3):nth-child(-n + 5) {
      text-align: center;
    }
  }
  .ant-tag {
    margin-right: 50px;
  }
  & ul {
    display: none;
  }
`;

export const tactMainRibbon = css`
  & > div {
    padding: 2rem;
  }
  & .ant-card-body {
    min-height: 125px;
    border: 1px solid #91d5ff !important;
  }
`;
export const tactRibbonStyle = css`
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  width: 200px;
  height: 41px;
  left: 8px;
  background: #40a9ff;
  border-radius: 6px 6px 6px 0px !important;
  &::after {
    position: absolute;
    left: 0px;
    top: 41px;
    border: 13px solid #003a8c;
    z-index: 5;
    border-left-color: transparent;
    border-bottom-color: transparent;
    content: '';
  }
  & > div {
    display: none;
  }
  & .sub-Ribbon-Style {
    position: absolute;
    width: 43.31px;
    height: 37.86px;
    left: 20.94px;
    top: 16px;
    background: #003a8c;
    transform: rotate(33.58deg);
  }
  &.ant-ribbon.ant-ribbon-placement-end {
    right: unset;
  }
  &.ant-ribbon-corner {
    display: none;
  }
`;
export const tactSVGStyle = css`
  & > span > svg {
    position: absolute;
    width: 70px;
    height: 70px;
    left: 50px;
    top: 30px;
    color: #003a8c;
  }
`;
export const jobTactScaleStyle = css`
  display: flex;
  justify-content: space-between;
  align-items: center;
  & > div {
    display: flex;
    align-items: center;
    & > span {
      white-space: nowrap;
    }
  }
`;

export const subColorStyle = css`
  display: flex;
  align-items: center;
  margin-right: 20px;
  & > div {
    display: flex;
  }
  & button {
    border: none;
    height: 15px;
    width: 15px;
    border-radius: 50%;
    margin-right: 5px;
    cursor: default;
  }
`;

export const testDropDown = css`
  .dropBtn {
    cursor: pointer;
  }

  .dropdown-content {
    display: block;
    position: absolute;
    z-index: 1;
    box-shadow: 0px 0px 5px 2px rgb(0 0 0 / 15%);
  }
`;

export const rightButton = css`
  display: flex;
  justify-content: end;
  gap: 10px;
`;

/*
#=========================================#
| TactSetting CSS                    |
#=========================================#
*/

export const SettingTactButtonStyle = css`
  display: flex;
  justify-content: space-between;
`;
