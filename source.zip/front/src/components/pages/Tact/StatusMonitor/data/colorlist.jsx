import React from 'react';
import PropTypes from 'prop-types';
import * as SS from './styleSheet';

export const ColorList = ({ colorList }) => {
  return (
    <div style={{ display: 'flex' }}>
      {colorList.length > 0
        ? colorList.map((color, i) => (
            <div css={SS.subColorStyle} key={i}>
              <button
                className="rc-color-picker-trigger"
                style={{ backgroundColor: `${color.color}` }}
              />
              <span>{color.id}</span>
            </div>
          ))
        : ''}
    </div>
  );
};

ColorList.defaultProps = {
  colorList: [],
};
ColorList.propTypes = {
  colorList: PropTypes.array,
};
