/*
#=========================================#
| STATUS_TACT                             |
#=========================================#
*/
import {
  E_TACT_JOBTACT,
  E_TACT_PLATETACT,
  E_TACT_PLATEDETAILTACT,
  E_SETTING_PLATETACT,
  E_SETTING_PLATEDETAILTACT,
  E_SETTING_PLATETACTEVENT,
  E_SETTING_NAME,
  E_SETTING_PRIMARY,
} from './TactEtc';

export const JOB_TACT = {
  id: E_TACT_JOBTACT,
  title: 'JobTACT',
};
export const PLETE_TACT = {
  id: E_TACT_PLATETACT,
  title: 'PlateTACT',
};

export const PLATEDETAIL_TACT = {
  id: E_TACT_PLATEDETAILTACT,
  title: 'PlateDetailTACT',
};

/*
#=========================================#
| SETTING_TACT                            |
#=========================================#
*/
export const SETTING_PLATETACT = {
  id: E_SETTING_PLATETACT,
  title: 'Plate TACT',
};
export const SETTING_PLATEDETAILTACT = {
  id: E_SETTING_PLATEDETAILTACT,
  title: 'Plate Detail TACT',
};
export const SETTING_PLATETACTEVENT = {
  id: E_SETTING_PLATETACTEVENT,
  title: 'Plate TACT Event',
};
export const SETTING_NAME = {
  id: E_SETTING_NAME,
  title: 'Name.dat',
};
export const SETTING_PRIMARY = {
  id: E_SETTING_PRIMARY,
  title: 'Primary PU',
};

export const TACT_LIST = [JOB_TACT, PLETE_TACT, PLATEDETAIL_TACT];
export const SETTING_TACT_LIST = [
  SETTING_PLATETACT,
  SETTING_PLATEDETAILTACT,
  SETTING_PLATETACTEVENT,
  SETTING_NAME,
  SETTING_PRIMARY];
