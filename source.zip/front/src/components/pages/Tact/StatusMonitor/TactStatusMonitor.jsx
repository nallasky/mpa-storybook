import React from 'react';
import { SelectLog } from './Main/SelectLog';
import { SourceTarget } from './Main/SourceTarget';
import { sectionStyle } from './data/styleSheet';
import { JobTact } from './Main/JobTACT';

const TactStatusMonitor = () => {
  console.log('TactStatusMonitor');
  return (
    <>
      <section css={sectionStyle}>
        <SelectLog />
        <SourceTarget />
        <JobTact />
      </section>
    </>
  );
};
export default TactStatusMonitor;
