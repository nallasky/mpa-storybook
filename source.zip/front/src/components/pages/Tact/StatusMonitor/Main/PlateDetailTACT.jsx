import React, { useState } from 'react';
import * as SS from '../data/styleSheet';
import {
  DownCircleFilled,
  FormatPainterOutlined,
  SettingOutlined,
} from '@ant-design/icons';
import { Button, Badge, Card, Input } from 'antd';
import { ColorMenu } from './ColorMenu';
import { ColorList } from '../data/colorlist';
import { PlateDetailColor } from '../data/ColorData';

export const PlateDetailTACT = () => {
  const [down, setdown] = useState(false);
  const [defaultColorList, setDefaultColorList] = useState(PlateDetailColor);

  return (
    <>
      <div css={SS.tactMainRibbon}>
        <Badge.Ribbon text="Graph Setting" css={SS.tactRibbonStyle}>
          <Card>
            <div css={SS.tactSVGStyle}>
              <SettingOutlined />
            </div>
            <div css={SS.contentStyle}>
              <div css={SS.contentItemStyle} className="flex-between">
                <span className="label-2">Scale Unit</span>
                <div css={SS.jobTactScaleStyle}>
                  <div>
                    <Input
                      style={{ width: '100%', marginRight: '10px' }}
                      defaultValue={1000}
                    />
                    Msec
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </Badge.Ribbon>
      </div>
      <div css={SS.tactMainRibbon}>
        <Badge.Ribbon text="Graph Color Setting" css={SS.tactRibbonStyle}>
          <Card>
            <div css={SS.tactSVGStyle}>
              <FormatPainterOutlined />
            </div>
            <div>
              <div css={SS.tactGraphColorSettingStyle}>
                <div css={SS.testDropDown}>
                  <span className="dropdown">
                    <Button
                      css={SS.tactGraphColorButtonStyle}
                      className="dropBtn"
                      onClick={() => setdown(!down)}
                    >
                      Plate Tact Color Change
                      <DownCircleFilled />
                    </Button>
                    {down ? (
                      <div className="dropdown-content">
                        <ColorMenu
                          closer={() => setdown(false)}
                          changeFunc={setDefaultColorList}
                          colorList={defaultColorList}
                        />
                      </div>
                    ) : (
                      ''
                    )}
                  </span>
                </div>
                <ColorList colorList={defaultColorList} />
              </div>
            </div>
          </Card>
        </Badge.Ribbon>
      </div>
    </>
  );
};
