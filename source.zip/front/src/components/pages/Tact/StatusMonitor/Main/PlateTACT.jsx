import React, { useState } from 'react';
import * as SS from '../data/styleSheet';
import {
  DownCircleFilled,
  FormatPainterOutlined,
  SettingOutlined,
  ShrinkOutlined,
} from '@ant-design/icons';
import { Input, Switch, Button, Badge, Card, Select, DatePicker } from 'antd';
import { ColorMenu } from './ColorMenu';
import { ColorList } from '../data/colorlist';
import { PlateTactColor, Predictive, DifferenceColor } from '../data/ColorData';

const { Option } = Select;

export const PlateTact = () => {
  const [down, setdown] = useState(false);
  const [down1, setdown1] = useState(false);
  const [down2, setdown2] = useState(false);
  const [defaultColorList, setDefaultColorList] = useState(PlateTactColor);
  const [defaultColorList1, setDefaultColorList1] = useState(Predictive);
  const [defaultColorList2, setDefaultColorList2] = useState(DifferenceColor);
  return (
    <>
      <div css={SS.tactMainRibbon}>
        <Badge.Ribbon text="Comparison Setting" css={SS.tactRibbonStyle}>
          <Card>
            <div css={SS.tactSVGStyle}>
              <ShrinkOutlined />
            </div>
            <div css={SS.contentStyle}>
              <div css={SS.contentItemStyle} className="column-2">
                <span className="label-2">Period</span>
                <div css={SS.jobTactScaleStyle}>
                  <DatePicker.RangePicker
                    style={{ width: '100%' }}
                    inputReadOnly
                    allowClear={false}
                  />
                </div>
              </div>
              <div css={SS.contentItemStyle} className="column-2">
                <span className="label-2">Job</span>
                <Select style={{ width: '100%' }} />
              </div>
            </div>
          </Card>
        </Badge.Ribbon>
      </div>
      <div css={SS.tactMainRibbon}>
        <Badge.Ribbon text="Graph Setting" css={SS.tactRibbonStyle}>
          <Card>
            <div css={SS.tactSVGStyle}>
              <SettingOutlined />
            </div>
            <div css={SS.contentStyle}>
              <div css={SS.contentItemStyle} className="column-2">
                <span className="label-2">Type</span>
                <Select defaultValue="Throughput" style={{ width: '100%' }}>
                  <Option value="Throughput">Throughput</Option>
                  <Option value="Working">Working</Option>
                  <Option value="Waiting">Waiting</Option>
                </Select>
              </div>
              <div css={SS.contentItemStyle} className="column-2">
                <span className="label-2">ADC/FDC</span>
                <Select defaultValue="All" style={{ width: '100%' }}>
                  <Option value="ALL">All</Option>
                  <Option value="ADC">ADC</Option>
                  <Option value="FDC">FDC</Option>
                </Select>
              </div>
              <div css={SS.contentItemStyle} className="flex-between">
                <span className="label-2">Job Tact Scale</span>
                <div css={SS.jobTactScaleStyle}>
                  <div>
                    <span>Y:Upper Limit</span>
                    <Input
                      defaultValue={2500}
                      style={{ width: '100%', marginLeft: '5px' }}
                    />
                  </div>
                </div>
              </div>
              <div css={SS.contentItemStyle} className="flex-between">
                <span className="label-2">Show Predictive Value</span>
                <Switch
                  checkedChildren="ON"
                  unCheckedChildren="OFF"
                  defaultChecked
                />
              </div>
              <div css={SS.contentItemStyle} className="flex-between">
                <span className="label-2">Show Data Table</span>
                <Switch
                  checkedChildren="ON"
                  unCheckedChildren="OFF"
                  defaultChecked
                />
              </div>
            </div>
          </Card>
        </Badge.Ribbon>
      </div>
      <div css={SS.tactMainRibbon}>
        <Badge.Ribbon text="Graph Color Setting" css={SS.tactRibbonStyle}>
          <Card>
            <div css={SS.tactSVGStyle}>
              <FormatPainterOutlined />
            </div>
            <div>
              <div css={SS.tactGraphColorSettingStyle}>
                <div css={SS.testDropDown}>
                  <span className="dropdown">
                    <Button
                      css={SS.tactGraphColorButtonStyle}
                      className="dropBtn"
                      onClick={() => setdown(!down)}
                    >
                      Plate Tact Color Change
                      <DownCircleFilled />
                    </Button>
                    {down ? (
                      <div className="dropdown-content">
                        <ColorMenu
                          closer={() => setdown(false)}
                          changeFunc={setDefaultColorList}
                          colorList={defaultColorList}
                        />
                      </div>
                    ) : (
                      ''
                    )}
                  </span>
                </div>
                <ColorList colorList={defaultColorList} />
              </div>
              <div css={SS.tactGraphColorSettingStyle}>
                <div css={SS.testDropDown}>
                  <span className="dropdown">
                    <Button
                      css={SS.tactGraphColorButtonStyle}
                      className="dropBtn"
                      onClick={() => setdown1(!down1)}
                    >
                      Predictive Change
                      <DownCircleFilled />
                    </Button>
                    {down1 ? (
                      <div className="dropdown-content">
                        <ColorMenu
                          closer={() => setdown1(false)}
                          changeFunc={setDefaultColorList1}
                          colorList={defaultColorList1}
                        />
                      </div>
                    ) : (
                      ''
                    )}
                  </span>
                </div>
                <ColorList colorList={defaultColorList1} />
              </div>
              <div css={SS.tactGraphColorSettingStyle}>
                <div css={SS.testDropDown}>
                  <span className="dropdown">
                    <Button
                      css={SS.tactGraphColorButtonStyle}
                      className="dropBtn"
                      onClick={() => setdown2(!down2)}
                    >
                      Difference Graph Color Change
                      <DownCircleFilled />
                    </Button>
                    {down2 ? (
                      <div className="dropdown-content">
                        <ColorMenu
                          closer={() => setdown2(false)}
                          changeFunc={setDefaultColorList2}
                          colorList={defaultColorList2}
                        />
                      </div>
                    ) : (
                      ''
                    )}
                  </span>
                </div>
                <ColorList colorList={defaultColorList2} />
              </div>
            </div>
          </Card>
        </Badge.Ribbon>
      </div>
    </>
  );
};
