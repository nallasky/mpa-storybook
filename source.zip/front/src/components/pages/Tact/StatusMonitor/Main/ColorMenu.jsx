import * as SS from '../data/styleSheet';
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Panel from 'rc-color-picker/lib/Panel';
import { CloseOutlined } from '@ant-design/icons';

export const ColorMenu = ({ closer, colorList, changeFunc }) => {
  const [currentColor, setCurrentColor] = useState({
    selected: null,
    color: null,
  });
  const [innerColorList, setInnerColorList] = useState(colorList);

  const changeColor = (colors) => {
    const { color } = colors;
    setCurrentColor({
      ...currentColor,
      color: color,
    });
    setInnerColorList(
      innerColorList.map((item) => {
        return item.id === currentColor.selected
          ? { ...item, color: color }
          : item;
      }),
    );
  };

  const onApply = () => {
    changeFunc(innerColorList);
    closer();
  };
  const onCloser = () => {
    closer();
  };

  useEffect(() => {
    if (colorList.length > 0) {
      setCurrentColor({
        selected: colorList[0].id,
        color: colorList[0].color,
      });
    }
  }, []);

  return (
    <>
      <div css={SS.colorSettingStyle}>
        <span>Color Setting</span>
        <button onClick={onCloser}>
          <CloseOutlined />
        </button>
      </div>
      <div css={SS.tactColorBoxStyle}>
        <div>
          {innerColorList.length > 0
            ? innerColorList.map((item, i) => (
                <div css={SS.subColorStyle} key={i}>
                  <button
                    className="rc-color-picker-trigger"
                    onClick={() =>
                      setCurrentColor({
                        selected: item.id,
                        color: item.color,
                      })
                    }
                    style={{ backgroundColor: `${item.color}` }}
                  />
                  <div style={{ display: 'block' }}>
                    <div>{item.id}</div>
                    <div>{item.color}</div>
                  </div>
                </div>
              ))
            : ''}
        </div>
        <div>
          <Panel
            enableAlpha={false}
            color={currentColor.color}
            onChange={changeColor}
          />
        </div>
        <div css={SS.customButtonStyle} className="color-picker">
          <button
            css={SS.antdButtonStyle}
            className="blue color-picker"
            onClick={onApply}
          >
            Apply
          </button>
        </div>
      </div>
    </>
  );
};

ColorMenu.defaultProps = {
  colorList: [],
};
ColorMenu.propTypes = {
  closer: PropTypes.func.isRequired,
  colorList: PropTypes.array,
  changeFunc: PropTypes.func.isRequired,
};
