import React, { useState } from 'react';
import * as SS from '../data/styleSheet';
import {
  CloudDownloadOutlined,
  DownCircleFilled,
  SettingOutlined,
  FormatPainterOutlined,
} from '@ant-design/icons';
import { MSG_DOWNLOAD } from '../../../../../constants/Message';
import { Input, Switch, Button, Badge, Card, Select } from 'antd';
import CustomRadioGroup from '../../../../common/molecules/CustomRadioGroup/CustomRadioGroup';
import { TACT_LIST } from '../data/TactDefault';
import { ColorMenu } from './ColorMenu';
import { E_TACT_JOBTACT, E_TACT_PLATETACT } from '../data/TactEtc';
import { PlateTact } from './PlateTACT';
import { PlateDetailTACT } from './PlateDetailTACT';
import { JobTactColor } from '../data/ColorData';
import { ColorList } from '../data/colorlist';

const { Option } = Select;
export const JobTact = () => {
  const [down, setdown] = useState(false);
  const [currentTab, setCurrentTab] = useState(E_TACT_JOBTACT);
  const [defaultColorList, setDefaultColorList] = useState(JobTactColor);
  const changeTab = (id) => {
    setCurrentTab(id);
  };

  return (
    <div css={SS.componentStyle} className="span">
      <div css={SS.controlStyle} className="tact">
        <div>
          <CustomRadioGroup
            changeFunc={changeTab}
            currentChecked={currentTab}
            options={TACT_LIST}
            name="result-type"
          />
        </div>
        <div css={SS.customButtonStyle}>
          <button css={SS.antdButtonStyle} className="white tact-download">
            <CloudDownloadOutlined />
            {MSG_DOWNLOAD}
          </button>
        </div>
      </div>
      {currentTab === E_TACT_JOBTACT ? (
        <>
          <div css={SS.tactMainRibbon}>
            <Badge.Ribbon text="Graph Setting" css={SS.tactRibbonStyle}>
              <Card>
                <div css={SS.tactSVGStyle}>
                  <SettingOutlined />
                </div>
                <div css={SS.contentStyle}>
                  <div css={SS.contentItemStyle} className="column-2">
                    <span className="label-2">ADC/FDC</span>
                    <Select defaultValue="All" style={{ width: '100%' }}>
                      <Option value="All">All</Option>
                      <Option value="ADC">ADC</Option>
                      <Option value="FDC">FDC</Option>
                    </Select>
                  </div>
                  <div css={SS.contentItemStyle} className="flex-between">
                    <span className="label-2">Display Outlier</span>
                    <Switch
                      checkedChildren="ON"
                      unCheckedChildren="OFF"
                      defaultChecked
                    />
                  </div>
                  <div css={SS.contentItemStyle} className="column-2">
                    <span className="label-2">Job Tact Scale</span>
                    <div css={SS.jobTactScaleStyle}>
                      <div>
                        <span>Y:Lower Limit</span>
                        <Input
                          defaultValue={2500}
                          style={{ width: '100%', marginLeft: '5px' }}
                        />
                      </div>
                      <div>
                        <span>Y:Upper Limit</span>
                        <Input
                          defaultValue={2500}
                          style={{ width: '100%', marginLeft: '5px' }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            </Badge.Ribbon>
          </div>
          <div css={SS.tactMainRibbon}>
            <Badge.Ribbon text="Graph Color Setting" css={SS.tactRibbonStyle}>
              <Card>
                <div css={SS.tactSVGStyle}>
                  <FormatPainterOutlined />
                </div>
                <div css={SS.tactGraphColorSettingStyle}>
                  <div css={SS.testDropDown}>
                    <span className="dropdown">
                      <Button
                        css={SS.tactGraphColorButtonStyle}
                        className="dropBtn"
                        onClick={() => setdown(!down)}
                      >
                        Plate Tact Color Change
                        <DownCircleFilled />
                      </Button>
                      {down ? (
                        <div className="dropdown-content">
                          <ColorMenu
                            closer={() => setdown(false)}
                            changeFunc={setDefaultColorList}
                            colorList={defaultColorList}
                          />
                        </div>
                      ) : (
                        ''
                      )}
                    </span>
                  </div>
                  <ColorList colorList={defaultColorList} />
                </div>
              </Card>
            </Badge.Ribbon>
          </div>
        </>
      ) : currentTab === E_TACT_PLATETACT ? (
        <>
          <PlateTact />
        </>
      ) : (
        <>
          <PlateDetailTACT />
        </>
      )}
    </div>
  );
};
