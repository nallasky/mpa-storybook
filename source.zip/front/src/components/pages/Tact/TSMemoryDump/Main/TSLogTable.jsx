import React from 'react';
import { columns, data } from '../data/data';
import { Table } from 'antd';
import { CloudDownloadOutlined } from '@ant-design/icons';
import * as SS from '../../StatusMonitor/data/styleSheet';

const rowSelection = {
  onChange: (selectedRowKeys, selectedRows) => {
    console.log(
      `selectedRowKeys: ${selectedRowKeys}`,
      'selectedRows: ',
      selectedRows,
    );
  },
  onSelect: (record, selected, selectedRows) => {
    console.log(record, selected, selectedRows);
  },
};

export const TSLogTable = () => {
  return (
    <>
      <div css={SS.tsComponentStyle} className="span">
        <div css={SS.controlStyle}>
          <div css={SS.componentTitleStyle}>Log Table</div>
          <div css={SS.customButtonStyle}>
            <button css={SS.antdButtonStyle} className="white tact-download">
              <CloudDownloadOutlined />
              Download
            </button>
          </div>
        </div>
        <div css={SS.tsTableStyle}>
          <Table
            columns={columns}
            rowSelection={{ ...rowSelection }}
            dataSource={data}
          />
        </div>
        <div>
          <button css={SS.antdButtonStyle} className="blue view-graph">
            View Graph
          </button>
        </div>
      </div>
    </>
  );
};
