import React from 'react';
import * as SS from '../../StatusMonitor/data/styleSheet';
import { CloudDownloadOutlined } from '@ant-design/icons';

export const TSDrawingGraph = () => {
  return (
    <>
      <div css={SS.tsComponentStyle} className="span">
        <div css={SS.controlStyle}>
          <div css={SS.componentTitleStyle}>Drawing Graph</div>
          <div>
            <div css={SS.customButtonStyle}>
              <button css={SS.antdButtonStyle} className="white tact-download">
                <CloudDownloadOutlined />
                Enter The Palate No.
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
