import React from 'react';
import { tsMemoryDumpSectionStyle } from '../StatusMonitor/data/styleSheet';
import { TSSelectLog } from './Main/TSSelectLog';
import { TSLogTable } from './Main/TSLogTable';
import { TSDrawingGraph } from './Main/TSDrawingGraph';

const TactMemoryDump = () => {
  console.log('TactMemoryDump');
  return (
    <>
      <section css={tsMemoryDumpSectionStyle}>
        <TSSelectLog />
        <TSLogTable />
        <TSDrawingGraph />
      </section>
    </>
  );
};
export default TactMemoryDump;
