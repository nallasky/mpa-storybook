import React from 'react';
import { css } from '@emotion/react';
import {
  SelectSource,
  SelectTarget,
  SelectResult,
} from '../Fragments/CommonFragments';

const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 0.4fr 0.6fr;
  gap: 1rem;
  width: 100%;
  padding: 1rem;
`;

const Correction = () => {
  return (
    <section css={sectionStyle}>
      <SelectSource mode="correction" />
      <SelectTarget mode="correction" />
      <SelectResult mode="correction" />
    </section>
  );
};

export default Correction;
