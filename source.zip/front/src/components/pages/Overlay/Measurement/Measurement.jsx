import React from 'react';
import { css } from '@emotion/react';
import {
  SelectSource,
  SelectTarget,
  SelectResult,
} from '../Fragments/CommonFragments';

const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 0.4fr 0.6fr;
  gap: 1rem;
  width: 100%;
  padding: 1rem;
`;

const Measurement = () => {
  return (
    <section css={sectionStyle}>
      <SelectSource />
      <SelectTarget />
      <SelectResult />
    </section>
  );
};
export default Measurement;
