import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import {
  Select,
  Upload,
  DatePicker,
  Input,
  Switch,
  Radio,
  Button,
  InputNumber,
} from 'antd';
import {
  InboxOutlined,
  PlayCircleOutlined,
  TableOutlined,
  DotChartOutlined,
  BarChartOutlined,
  AlignLeftOutlined,
  CloudDownloadOutlined,
  DownOutlined,
  UploadOutlined,
} from '@ant-design/icons';

const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 0.4fr 0.6fr;
  gap: 1rem;
  width: 100%;
  padding: 1rem;
`;

const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 400px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  &.stretch {
    align-self: stretch;
  }
  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 2rem;
    grid-column: 1 / span 2;
  }
`;

const componentTitleStyle = css`
  font-size: 24px;
  color: #1890ff;
`;

const contentWrapperStyle = css`
  position: relative;
  margin-top: 3rem;
  &.mg-bottom {
    margin-bottom: 13px;
  }
`;

const contentStyle = css`
  margin: 0 auto;
  width: 60%;
  &.full-width {
    width: 100%;
  }
  & > div + div {
    margin-top: 2rem;
  }
`;

const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column-2 {
    grid-template-columns: 0.4fr 1fr;
  }
  &.column-3 {
    grid-template-columns: 0.4fr 1fr 1fr;
  }
  &.etc {
    display: flex;
    justify-content: space-between;
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      &.label::before {
        display: inline-block;
        color: red;
        font-size: 16px;
        content: '*';
        margin-right: 0.3rem;
      }
    }
    &.switch-wrapper {
      text-align: center;
    }
  }
  &.upload {
    & > span {
      &:first-of-type {
        align-self: start;
      }
      &:last-of-type {
        width: 100%;
      }
    }
  }
  & > .title {
    width: 100%;
    text-align: center;
    font-size: 20px;
  }
  & > .preset-setting {
    display: flex;
    column-gap: 1rem;
  }
  & .radio-cp-vs {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    column-gap: 1rem;
    grid-column: span 2;
  }
  & .margin-lr {
    margin: 0 1rem;
  }
  & .margin-r {
    margin-right: 1rem;
  }
  & .tx-right {
    text-align: right;
  }
`;

const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: #1890ff;
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: -5px;
    right: 10px;
    & > span:first-of-type {
      color: #52c41a;
    }
  }
`;

const controlStyle = css`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
`;

const radioGroupStyle = css`
  & > label {
    display: inline-block;
    & + label {
      margin-left: 1rem;
    }
    & > input[type='radio'] {
      display: none;
      &:checked {
        & + .button {
          background-color: #f5f5f5;
          &::after {
            opacity: 1;
          }
        }
      }
    }
    & > .button {
      position: relative;
      z-index: 1;
      padding: 0.5rem 1rem;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease-in-out;
      &::after {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        content: '';
        opacity: 0;
        border-radius: 8px;
        box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
        transition: opacity 0.3s ease-in-out;
      }
      & svg {
        margin-right: 0.3rem;
      }
    }
  }
`;

const settingStyle = css`
  position: relative;
  padding-bottom: 1rem;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  & > .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1rem;
    & > span {
      font-size: 18px;
    }
    & > div > button + button {
      margin-left: 1rem;
    }
  }
  & > .main {
    & > div + div {
      margin-top: 0.1rem;
    }
  }
`;

const antdButtonStyle = css`
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: white;
    border: 1px dashed #d9d9d9;
  }
  &.blue {
    color: white;
    background-color: #1890ff;
    border: 1px solid #1890ff;
  }
`;

const settingContentStyle = css`
  position: relative;
  margin: 0 auto;
  width: 60%;
  &.etc {
    width: 40%;
  }
  & .content {
    & > div:not(.table-wrapper) + div:not(.table-wrapper) {
      margin-top: 2rem;
    }
    & > div + .table-wrapper {
      margin-top: 1rem;
    }
    & > .table-wrapper + div {
      margin-top: 1rem;
    }
  }
`;

const resultStyle = css`
  position: relative;
  min-height: 300px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  padding: 1rem;
`;

const tableStyle = css`
  margin: 0 auto;
  border: 1px solid #d9d9d9;
  border-collapse: collapse;
  table-layout: auto;
  text-align: center;
  & th,
  td {
    border: 1px solid #d9d9d9;
    padding: 0.5rem;
  }
  & th {
    background-color: #fafafa;
  }
`;

const Measurement = () => {
  const [resultType, setResultType] = useState('map');

  return (
    <section css={sectionStyle}>
      <div css={componentStyle} className="stretch">
        <div css={componentTitleStyle}>Select Source</div>
        <div css={contentWrapperStyle}>
          <div css={contentStyle} className="full-width">
            <div css={contentItemStyle} className="column-2">
              <span className="label">From:</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Local</Select.Option>
                <Select.Option value="2">Remote</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="upload column-2">
              <span className="label">Log Files:</span>
              <Upload.Dragger>
                <p className="ant-upload-drag-icon">
                  <InboxOutlined />
                </p>
                <p className="ant-upload-text">
                  Click or drag file to this area to upload
                </p>
              </Upload.Dragger>
            </div>
          </div>
        </div>
      </div>
      <div css={componentStyle}>
        <div css={componentTitleStyle}>Select Target</div>
        <div css={contentWrapperStyle} className="mg-bottom">
          <div css={contentStyle}>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Fab:</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Fab1600</Select.Option>
                <Select.Option value="2">Fab1700</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Equipment:</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Tool1600_1</Select.Option>
                <Select.Option value="2">Tool1700_1</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Period:</span>
              <DatePicker.RangePicker style={{ width: '100%' }} />
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Job:</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Job1</Select.Option>
                <Select.Option value="2">Job2</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Lot ID:</span>
              <Select
                defaultValue="1"
                style={{ width: '100%' }}
                mode="multiple"
              >
                <Select.Option value="1">item 1</Select.Option>
                <Select.Option value="2">item 2</Select.Option>
                <Select.Option value="3">item 3</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">Mean Deviation Diff.:</span>
              <Select
                defaultValue="1"
                style={{ width: '100%' }}
                mode="multiple"
              >
                <Select.Option value="1">item 1</Select.Option>
                <Select.Option value="2">item 2</Select.Option>
                <Select.Option value="3">item 3</Select.Option>
              </Select>
            </div>
            <div css={contentItemStyle} className="column-2">
              <span className="label">AE Correction:</span>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Off</Select.Option>
                <Select.Option value="2">On</Select.Option>
              </Select>
            </div>
          </div>
          <div css={customButtonStyle} className="absolute">
            <PlayCircleOutlined />
            <span>Start</span>
          </div>
        </div>
      </div>
      <div css={componentStyle} className="span">
        <div css={controlStyle}>
          <div css={radioGroupStyle}>
            <label htmlFor="map">
              <input
                type="radio"
                name="option"
                id="map"
                checked={resultType === 'map'}
                onChange={() => setResultType('map')}
              />
              <div className="button">
                <TableOutlined />
                Map
              </div>
            </label>
            <label htmlFor="variation">
              <input
                type="radio"
                name="option"
                id="variation"
                checked={resultType === 'variation'}
                onChange={() => setResultType('variation')}
              />
              <div className="button">
                <DotChartOutlined />
                Variation
              </div>
            </label>
            <label htmlFor="reproducibility">
              <input
                type="radio"
                name="option"
                id="reproducibility"
                checked={resultType === 'reproducibility'}
                onChange={() => setResultType('reproducibility')}
              />
              <div className="button">
                <BarChartOutlined />
                Reproducibility
              </div>
            </label>
            <label htmlFor="anova">
              <input
                type="radio"
                name="option"
                id="anova"
                checked={resultType === 'anova'}
                onChange={() => setResultType('anova')}
              />
              <div className="button">
                <AlignLeftOutlined />
                Anova
              </div>
            </label>
          </div>
          <div css={customButtonStyle}>
            <CloudDownloadOutlined />
            <span>Download</span>
          </div>
        </div>
        <div css={settingStyle}>
          <div className="header">
            <span>Map Setting</span>
            <div>
              <button css={antdButtonStyle} className="blue">
                Apply
              </button>
            </div>
          </div>
          <div className="main">
            <OverlaySettingAccordion title="Offset X/Y" defaultValue={false}>
              <div css={settingContentStyle}>
                <div className="content">
                  <div css={contentItemStyle} className="column-3">
                    <span className="switch-wrapper">
                      <Switch
                        checkedChildren="Auto"
                        unCheckedChildren="Manual"
                        defaultChecked
                      />
                    </span>
                    <span className="title">Offset X</span>
                    <span className="title">Offset Y</span>
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 1:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 2:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 3:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 4:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 5:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Shot 6:</span>
                    <Input placeholder="Offset X" />
                    <Input placeholder="Offset Y" />
                  </div>
                </div>
              </div>
            </OverlaySettingAccordion>
            <OverlaySettingAccordion title="CP / VS">
              <div css={settingContentStyle}>
                <div className="content">
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Preset:</span>
                    <Select defaultValue="1" style={{ width: '100%' }}>
                      <Select.Option value="1">Job1</Select.Option>
                      <Select.Option value="2">Job2</Select.Option>
                    </Select>
                    <div className="preset-setting">
                      <Input placeholder="Enter preset name." />
                      <button css={antdButtonStyle} className="blue">
                        Save Preset
                      </button>
                    </div>
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">CP/VS:</span>
                    <Radio.Group value="1" className="radio-cp-vs">
                      <Radio value="1">Set CP/VS for each shot</Radio>
                      <Radio value="2">
                        Reflect the CP/VS of shot1 on all shots
                      </Radio>
                    </Radio.Group>
                  </div>
                  <div className="table-wrapper">
                    <table css={tableStyle}>
                      <thead>
                        <tr>
                          <th>SHOT</th>
                          <th>CP1</th>
                          <th>CP2</th>
                          <th>CP3</th>
                          <th>VS1</th>
                          <th>VS2</th>
                          <th>VS3</th>
                          <th>DISPLAY</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>01</td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Select defaultValue="1" style={{ width: '100%' }}>
                              <Select.Option value="1">Job1</Select.Option>
                              <Select.Option value="2">Job2</Select.Option>
                            </Select>
                          </td>
                        </tr>
                        <tr>
                          <td>02</td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Select defaultValue="1" style={{ width: '100%' }}>
                              <Select.Option value="1">Job1</Select.Option>
                              <Select.Option value="2">Job2</Select.Option>
                            </Select>
                          </td>
                        </tr>
                        <tr>
                          <td>03</td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Select defaultValue="1" style={{ width: '100%' }}>
                              <Select.Option value="1">Job1</Select.Option>
                              <Select.Option value="2">Job2</Select.Option>
                            </Select>
                          </td>
                        </tr>
                        <tr>
                          <td>04</td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Input type="text" />
                          </td>
                          <td>
                            <Select defaultValue="1" style={{ width: '100%' }}>
                              <Select.Option value="1">Job1</Select.Option>
                              <Select.Option value="2">Job2</Select.Option>
                            </Select>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div css={contentItemStyle} className="column-3">
                    <span className="label">Job data file:</span>
                    <Upload>
                      <Button icon={<UploadOutlined />}>Load</Button>
                    </Upload>
                  </div>
                </div>
              </div>
            </OverlaySettingAccordion>
            <OverlaySettingAccordion title="Etc.">
              <div css={settingContentStyle} className="etc">
                <div className="content">
                  <div css={contentItemStyle} className="etc">
                    <span className="label">Display Map</span>
                    <div>
                      <InputNumber />
                      <span className="margin-lr">~</span>
                      <InputNumber />
                    </div>
                  </div>
                  <div css={contentItemStyle} className="etc">
                    <span className="label">Number of Columns to Display:</span>
                    <InputNumber />
                  </div>
                  <div css={contentItemStyle} className="etc">
                    <span className="label">Div:</span>
                    <div className="tx-right">
                      <span className="margin-r">Upper Row</span>
                      <Input style={{ width: '40%' }} />
                    </div>
                  </div>
                  <div css={contentItemStyle} className="etc">
                    <span className="label">Plate Size:</span>
                    <div className="tx-right">
                      <span className="margin-r">Size_X</span>
                      <Input style={{ width: '30%' }} />
                      <span className="margin-lr">Size_Y</span>
                      <Input style={{ width: '30%' }} />
                    </div>
                  </div>
                  <div css={contentItemStyle} className="etc">
                    <span className="label">Map Show Data</span>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>
            </OverlaySettingAccordion>
          </div>
        </div>
        <div css={resultStyle}>result</div>
      </div>
    </section>
  );
};

const accordionStyle = css`
  position: relative;
  width: 100%;
  & > div {
    width: 100%;
    &:first-of-type {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem;
      background-color: #f5f5f5;
      cursor: pointer;
      & > .title {
        font-size: 18px;
      }
      & svg {
        transition: all 0.5s;
      }
    }
    &:last-of-type {
      max-height: 800px;
      transition: all 0.7s;
      overflow: hidden;
      & > .contents {
        padding: 1rem;
      }
    }
  }
  &.collapsed {
    & > div {
      &:first-of-type {
        & svg {
          transform: rotate(180deg);
        }
      }
      &:last-of-type {
        max-height: 0;
      }
    }
  }
`;

const OverlaySettingAccordion = ({ title, children, defaultValue }) => {
  const [isCollapsed, setIsCollapsed] = useState(defaultValue);

  return (
    <div css={accordionStyle} className={isCollapsed ? 'collapsed' : ''}>
      <div
        onClick={() => setIsCollapsed(!isCollapsed)}
        onKeyDown={() => setIsCollapsed(!isCollapsed)}
        role="button"
        tabIndex="-1"
      >
        <span className="title">{title}</span>
        <DownOutlined />
      </div>
      <div>
        <div className="contents">{children}</div>
      </div>
    </div>
  );
};
OverlaySettingAccordion.displayName = 'OverlaySettingAccordion';
OverlaySettingAccordion.propTypes = {
  title: PropTypes.string,
  children: PropTypes.node.isRequired,
  defaultValue: PropTypes.bool,
};
OverlaySettingAccordion.defaultProps = {
  defaultValue: true,
};

export default Measurement;
