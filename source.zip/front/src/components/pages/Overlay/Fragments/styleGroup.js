import { css, keyframes } from '@emotion/react';

export const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 400px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  &.stretch {
    align-self: stretch;
  }
  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 2rem;
    grid-column: 1 / span 2;
  }
  & .source-button-wrapper {
    position: absolute;
    bottom: 30px;
    right: 16px;
  }
`;

export const componentTitleStyle = css`
  font-size: 24px;
  color: #1890ff;
`;

export const contentWrapperStyle = css`
  position: relative;
  margin-top: 3rem;
  &.mg-bottom {
    margin-bottom: 13px;
  }
`;

export const contentStyle = css`
  margin: 0 auto;
  width: 60%;
  &.full-width {
    width: 100%;
  }
  & > div + div {
    margin-top: 2rem;
  }
`;

export const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column-2 {
    grid-template-columns: 0.4fr 1fr;
  }
  &.column-3 {
    grid-template-columns: 0.4fr 1fr 1fr;
  }
  &.etc {
    display: flex;
    justify-content: space-between;
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      &.label {
        &::before {
          display: inline-block;
          color: red;
          font-size: 16px;
          content: '*';
          margin-right: 0.3rem;
        }
        &::after {
          display: inline-block;
          content: ':';
        }
      }
    }
  }
  &.upload {
    & > span {
      &:first-of-type {
        align-self: start;
      }
      &:last-of-type {
        width: 100%;
      }
    }
    & .full-width {
      & > .ant-upload-select-text,
      & button {
        width: 100%;
      }
    }
  }
  & > .title {
    width: 100%;
    text-align: center;
    font-size: 20px;
  }
  & > .preset-setting {
    display: flex;
    column-gap: 1rem;
  }
  & .radio-cp-vs {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    column-gap: 1rem;
    grid-column: span 2;
  }
  & .margin-lr {
    margin: 0 1rem;
  }
  & .margin-r {
    margin-right: 1rem;
  }
  & .tx-right {
    text-align: right;
  }
  & ~ div {
    margin-top: 2rem;
    &.table-wrapper {
      margin-top: 1rem;
    }
  }
`;

export const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: #1890ff;
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: -5px;
    right: 10px;
    & > span:first-of-type {
      color: #52c41a;
    }
  }
`;

export const accordionStyle = css`
  position: relative;
  width: 100%;
  & > div {
    width: 100%;
    &:first-of-type {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem;
      background-color: #f5f5f5;
      cursor: pointer;
      & > .title {
        font-size: 18px;
      }
      & svg {
        transition: all 0.5s;
      }
    }
    &:last-of-type {
      max-height: 800px;
      transition: all 0.7s;
      overflow: hidden;
      & > .contents {
        padding: 1rem;
      }
    }
  }
  &.collapsed {
    & > div {
      &:first-of-type {
        & svg {
          transform: rotate(180deg);
        }
      }
      &:last-of-type {
        max-height: 0;
      }
    }
  }
`;

const bounce = keyframes`
  50% {
    transform: scale(1.2);
  }
  75% {
    transform: scale(.9);
  }
  100% {
    transform: scale(1);
  }
`;

export const controlTableStyle = css`
  margin: 0 auto;
  border-top: 1px solid #d9d9d9;
  table-layout: auto;
  border-collapse: collapse;
  & input[type='checkbox'] {
    display: none;
  }
  & label.only-checkbox {
    cursor: pointer;
    text-align: center;
    & > input[type='checkbox'] {
      &:checked ~ .mode-slider-wrapper > .slider {
        transform: translateY(-17px);
      }
    }
    & > .mode-slider-wrapper {
      overflow: hidden;
      height: 17px;
      font-weight: normal;
      text-transform: uppercase;
      & > .slider {
        display: flex;
        flex-direction: column;
        align-items: center;
        transition: transform 0.3s ease-in-out;
        row-gap: 2px;
        & > span {
          display: inline-block;
          font-size: 10px;
          border-radius: 4px;
          width: fit-content;
          padding: 0 0.2rem;
          color: white;
          &:first-of-type {
            background-color: red;
          }
          &:last-of-type {
            background-color: #1890ff;
          }
        }
      }
    }
  }
  & svg {
    display: block;
    pointer-events: none;
    fill: none;
    stroke-width: 2px;
    stroke-linecap: round;
    stroke-linejoin: round;
    stroke: #1890ff;
    position: absolute;
    transform: scale(0) translateZ(0);
  }
  & th {
    position: relative;
    padding: 0.5rem;
    border-bottom: 1px solid #d9d9d9;
    background-color: #f0f5ff;
    text-transform: uppercase;
    font-size: 12px;
    line-height: initial;
    & svg {
      top: 10px !important;
      left: 40px !important;
      width: 24px !important;
      height: 24px !important;
    }
  }
  & td {
    position: relative;
    border: none;
    border-bottom: 1px solid #d9d9d9;
    font-size: 12px;
    color: rgba(0, 0, 0, 0.8);
    line-height: initial;
    & > .text-checkbox {
      position: relative;
      & > input[type='text'] {
        font-family: Saira, sans-serif;
        border: none;
        outline: none !important;
        font-size: 12px;
        max-width: 125px;
        padding: 0.7rem 2rem 0.7rem 0.7rem;
        transition: background-color 0.3s ease-in-out;
        &:read-only {
          background-color: #f5f5f5;
        }
      }
      & > label {
        cursor: pointer;
        & > input[type='checkbox'] {
          &:checked ~ {
            & .svg-wrapper > svg {
              animation: ${bounce} 0.4s linear forwards;
            }
          }
        }
        & > .svg-wrapper {
          position: absolute;
          top: 6px;
          right: 3px;
          width: 24px;
          height: 24px;
          padding: 1px;
          border-radius: 4px;
          border: 1px solid #dadada;
          background-color: white;
        }
      }
    }
  }
`;

export const radioGroupStyle = css`
  & > label {
    display: inline-block;
    & + label {
      margin-left: 1rem;
    }
    & > input[type='radio'] {
      display: none;
      &:checked {
        & + .button {
          background-color: #f5f5f5;
          &::after {
            opacity: 1;
          }
        }
      }
    }
    & > .button {
      position: relative;
      z-index: 1;
      padding: 0.5rem 1rem;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease-in-out;
      &::after {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        content: '';
        opacity: 0;
        border-radius: 8px;
        box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
        transition: opacity 0.3s ease-in-out;
      }
      & svg {
        margin-right: 0.3rem;
      }
    }
  }
`;

export const tableStyle = css`
  margin: 0 auto;
  border: 1px solid #d9d9d9;
  border-collapse: collapse;
  table-layout: auto;
  text-align: center;
  & th,
  td {
    border: 1px solid #d9d9d9;
    padding: 0.5rem;
  }
  & th {
    background-color: #fafafa;
  }
`;

export const settingContentStyle = css`
  position: relative;
  margin: 0 auto;
  width: 60%;
  &.etc {
    width: 40%;
  }
  &.full-width {
    width: 100%;
  }
  &.correction-cp-vs {
    width: 70%;
  }
  & .table-wrapper ~ div,
  & .content > .radio-wrapper ~ .tab {
    margin-top: 1rem;
  }
`;

export const antdButtonStyle = css`
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: white;
    border: 1px dashed #d9d9d9;
  }
  &.blue {
    color: white;
    background-color: #1890ff;
    border: 1px solid #1890ff;
  }
`;

export const controlStyle = css`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
`;

export const settingStyle = css`
  position: relative;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  & > .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1rem;
    & > span {
      font-size: 18px;
    }
    & > div > button + button {
      margin-left: 1rem;
    }
  }
  & > .main {
    & > div + div {
      margin-top: 0.1rem;
    }
  }
`;

export const resultStyle = css`
  position: relative;
  min-height: 300px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  padding: 1rem;
`;

export const customSelectStyle = css`
  display: flex;
  align-items: center;
  column-gap: 8px;
  padding: 0 8px;
  & > .button {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-size: 16px;
    padding: 2px;
    & svg {
      stroke: black;
      stroke-width: 30px;
    }
  }
`;
