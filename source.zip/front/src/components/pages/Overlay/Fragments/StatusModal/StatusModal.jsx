import React, { useEffect, useState } from 'react';
import styled from '@emotion/styled';
import PropTypes from 'prop-types';
import { Modal, Button, Progress } from 'antd';
import { getStatus } from './functionGroup';
import useOverlayInfo from '../../../../../hooks/useOverlaySettingInfo';
import { OVERLAY_ADC_CATEGORY, V_OFF } from '../../../../../lib/api/Define/etc';

const Contents = styled.div`
  display: flex;
  justify-content: space-around;
  align-items: center;
  & > div {
    &:first-of-type {
      display: flex;
      flex-direction: column;
      row-gap: 1rem;
    }
  }
`;

const StatusModal = ({ id, category, onClose }) => {
  const {
    adcMeasurementSet,
    correctionSet,
    updateAdcMeasurementSetting,
    updateCorrectionSetting,
  } = useOverlayInfo();
  const [statusInfo, setStatusInfo] = useState({
    status: 'running',
    percent: 0,
    detail: {
      error_files: 0,
      success_files: 0,
      total_files: 0,
      converted: 0,
    },
    targetInfo: {},
  });

  useEffect(() => {
    if (statusInfo.status === 'running') {
      const interval = setInterval(() => {
        getStatus(id, category, setStatusInfo)
          .then((data) => {
            setStatusInfo(
              data
                ? data
                : {
                    ...statusInfo,
                    status: 'error',
                  },
            );
          })
          .catch((e) => console.log(e));
      }, 1500);
      return () => clearInterval(interval);
    } else {
      if (statusInfo.status === 'success') {
        setTimeout(onClose, 2000);
        const currentData =
          category === OVERLAY_ADC_CATEGORY
            ? adcMeasurementSet.targetInfo
            : correctionSet.targetInfo;
        const periodSet =
          statusInfo.targetInfo.period.length > 0
            ? statusInfo.targetInfo.period
            : undefined;
        const newTargetData = {
          ...currentData,
          fab_list: statusInfo.targetInfo.fab,
          period: periodSet ?? currentData.period,
          selected: periodSet ?? currentData.selected,
          job_list: statusInfo.targetInfo.job,
          lot_id_list: statusInfo.targetInfo.lot_id,
          mean_dev_diff_list: statusInfo.targetInfo.plate,
          ae_correction: V_OFF,
          stage_correction_list: statusInfo.targetInfo.stage_correction ?? {},
          adc_correction_list: statusInfo.targetInfo.adc_correction ?? {},
        };

        category === OVERLAY_ADC_CATEGORY
          ? updateAdcMeasurementSetting({
              ...adcMeasurementSet,
              targetInfo: newTargetData,
            })
          : updateCorrectionSetting({
              ...correctionSet,
              targetInfo: newTargetData,
            });
      }
    }
  }, [statusInfo.status]);

  return (
    <Modal
      visible
      centered
      title={
        statusInfo.status === 'running'
          ? 'PROCESS'
          : statusInfo.status === 'success'
          ? 'COMPLETE'
          : 'ERROR'
      }
      width={400}
      footer={[
        <Button key="button" type="primary" onClick={onClose}>
          {statusInfo.status === 'running' ? 'Cancel' : 'Close'}
        </Button>,
      ]}
      closable={false}
    >
      <Contents>
        <div>
          <div>{`Success files: ${statusInfo.detail.success_files}`}</div>
          <div>{`Error files: ${statusInfo.detail.error_files}`}</div>
          <div>{`Total files: ${statusInfo.detail.total_files}`}</div>
          <div>{`Converted rows: ${statusInfo.detail.converted}`}</div>
        </div>
        <div>
          <Progress
            type="circle"
            percent={statusInfo.percent}
            status={
              statusInfo.status === 'running'
                ? 'normal'
                : statusInfo.status === 'success'
                ? 'success'
                : 'exception'
            }
          />
        </div>
      </Contents>
    </Modal>
  );
};
StatusModal.propTypes = {
  id: PropTypes.string.isRequired,
  category: PropTypes.string.isRequired,
  onClose: PropTypes.func.isRequired,
};

export default StatusModal;
