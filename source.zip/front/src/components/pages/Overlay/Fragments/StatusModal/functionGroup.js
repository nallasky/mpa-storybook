import {
  get_Overlay_Local_ConvertStatus,
  get_Overlay_Analysis_Info,
} from '../../../../../lib/api/axios/useOverlayRequest';

export const getStatus = async (id, cat) => {
  let result = undefined;

  await get_Overlay_Local_ConvertStatus({ jobId: id, category: cat })
    .then((data) => {
      result = data;
    })
    .catch((e) => console.log(e));

  return result;
};

export const getAnalysisInfo = async (id, cat) => {
  let result = undefined;

  await get_Overlay_Analysis_Info(cat, id)
    .then((data) => {
      result = data;
    })
    .catch((e) => console.log(e));

  return result;
};
