import { get_Overlay_Local_ConvertStatus } from '../../../../../lib/api/axios/useOverlayRequest';

export const getStatus = async (id, cat) => {
  let result = undefined;

  await get_Overlay_Local_ConvertStatus({ jobId: id, category: cat })
    .then((data) => {
      result = data;
    })
    .catch((e) => console.log(e));

  return result;
};
