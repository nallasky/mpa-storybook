import React, { useMemo, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
  DatePicker,
  Divider,
  Input,
  Radio,
  Select,
  Space,
  TreeSelect,
} from 'antd';
import { PlayCircleOutlined, PlusCircleOutlined } from '@ant-design/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import dayjs from 'dayjs';
import useOverlayInfo from '../../../../../hooks/useOverlaySettingInfo';
import useModal from '../../../../../lib/util/modalControl/useModal';
import ProcessingModal from '../ProcessingModal/ProcessingModal';
import { displayNotification } from '../../../JobAnalysis/functionGroup';
import { post_Overlay_Analysis } from '../../../../../lib/api/axios/useOverlayRequest';
import {
  DATE_FORMAT,
  OVERLAY_ADC_CATEGORY,
} from '../../../../../lib/api/Define/etc';
import { RenderSelectOptions } from '../../../JobAnalysis/AnalysisTable/functionGroup';
import {
  createTreeSelectData,
  createInitTreeValues,
  createPostData,
  disabledDate,
} from './functionGroup';
import * as SG from '../styleGroup';
import { CustomSelect } from './styleGroup';

const SelectTarget = ({ mode }) => {
  const { openModal, closeModal } = useModal();
  const {
    adcMeasurementSet,
    correctionSet,
    updateCorrectionSetting,
    updateAdcMeasurementSetting,
  } = useOverlayInfo();

  const [fabName, setFabName] = useState('');
  const [radioAdc, setRadioAdc] = useState('ADC Measurement');
  const [inputError, setInputError] = useState(false);

  const currentData = useMemo(
    () =>
      mode === OVERLAY_ADC_CATEGORY
        ? adcMeasurementSet.targetInfo
        : correctionSet.targetInfo,
    [adcMeasurementSet.targetInfo, correctionSet.targetInfo],
  );
  const lotIdOptions = useMemo(() => {
    return createTreeSelectData(currentData.lot_id_list, 'all');
  }, [currentData.lot_id_list]);
  const stageCorrectionOptions = useMemo(() => {
    return createTreeSelectData(currentData.stage_correction_list, 'all');
  }, [currentData.stage_correction_list]);
  const adcCorrectionOptions = useMemo(() => {
    return createTreeSelectData(currentData.adc_correction_list, radioAdc);
  }, [currentData.adc_correction_list, radioAdc]);

  const checkName = () => {
    if (inputError) return;

    if (currentData.fab_list.includes(fabName)) {
      setInputError(true);
    } else {
      changeRedux(
        mode === OVERLAY_ADC_CATEGORY
          ? [...adcMeasurementSet.targetInfo.fab_list, fabName]
          : [...correctionSet.targetInfo.fab_list, fabName],
        'fab_list',
      );
    }
  };

  const changeName = (v) => {
    if (inputError) setInputError(false);
    setFabName(v);
  };

  const changeRedux = (v, key) => {
    mode === OVERLAY_ADC_CATEGORY
      ? updateAdcMeasurementSetting({
          ...adcMeasurementSet,
          targetInfo: { ...currentData, [key]: v },
        })
      : updateCorrectionSetting({
          ...correctionSet,
          targetInfo: { ...currentData, [key]: v },
        });
  };

  const processStart = async () => {
    let isError = undefined;
    const postData = createPostData(
      mode === OVERLAY_ADC_CATEGORY ? adcMeasurementSet : correctionSet,
      mode,
      mode !== OVERLAY_ADC_CATEGORY ? radioAdc : undefined,
    );

    openModal(ProcessingModal, {
      title: 'Analysing',
      message: 'Analysing data',
    });

    await post_Overlay_Analysis(postData)
      .then((data) => console.log('gtpark data', data))
      .catch((e) => {
        console.log(e);
        isError = e;
      })
      .finally(() => {
        closeModal(ProcessingModal);
        displayNotification({
          message: isError ? 'Error occurred' : 'Analysis Success',
          description: isError
            ? 'An error occurred during the analysis. Please check the settings.'
            : 'The analysis was successful.',
          duration: 3,
          style: isError
            ? { borderLeft: '5px solid red' }
            : { borderLeft: '5px solid green' },
        });
      });
  };

  useEffect(() => {
    changeRedux(
      createInitTreeValues(currentData.adc_correction_list, 'adc_correction'),
      'adc_correction',
    );
  }, [radioAdc]);

  useEffect(() => {
    if (mode !== OVERLAY_ADC_CATEGORY) {
      const newStageData = createInitTreeValues(
        currentData.stage_correction_list,
        'stage_correction',
      );
      const newAdcData = createInitTreeValues(
        currentData.adc_correction_list,
        'adc_correction',
      );

      updateCorrectionSetting({
        ...correctionSet,
        targetInfo: {
          ...correctionSet.targetInfo,
          stage_correction: newStageData,
          adc_correction: newAdcData,
        },
      });

      let findKey = undefined;

      Object.keys(currentData.adc_correction_list).forEach((v) => {
        if (
          Object.keys(currentData.adc_correction_list[v]).find(
            (x) => (x === 'selected') === currentData.adc_correction_list[v][x],
          )
        ) {
          findKey = v;
        }
      });

      if (findKey) {
        setRadioAdc(findKey);
      }
    }
  }, [currentData.adc_correction_list, currentData.stage_correction_list]);

  return (
    <div css={SG.componentStyle}>
      <div
        className={
          'foreground' +
          ((mode === OVERLAY_ADC_CATEGORY &&
            adcMeasurementSet.source_info.files_rid === '' &&
            adcMeasurementSet.source_info.db.id === '') ||
          (mode !== OVERLAY_ADC_CATEGORY &&
            correctionSet.source_info.files_rid === '' &&
            correctionSet.source_info.db.id === '')
            ? ' active'
            : '')
        }
      >
        <div>
          <FontAwesomeIcon icon={faArrowLeft} size="10x" />
          <p>Please first set the left.</p>
        </div>
      </div>
      <div css={SG.componentTitleStyle}>Select Target</div>
      <div css={SG.contentWrapperStyle} className="mg-bottom">
        <div css={SG.contentStyle}>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Fab</span>
            <Select
              style={{ width: '100%' }}
              value={currentData.fab_name}
              onChange={(v) => changeRedux(v, 'fab_name')}
              dropdownRender={(menu) => (
                <>
                  <CustomSelect>
                    <Input
                      type="text"
                      style={{ width: '100%' }}
                      value={fabName}
                      onChange={(e) => changeName(e.target.value)}
                      maxLength="20"
                      className={inputError ? 'input-error' : ''}
                    />
                    <div
                      className={'button' + (inputError ? ' error' : '')}
                      role="button"
                      onKeyDown={undefined}
                      tabIndex="-1"
                      onClick={checkName}
                    >
                      <PlusCircleOutlined />
                    </div>
                  </CustomSelect>
                  <Divider style={{ margin: '4px 0' }} />
                  {menu}
                </>
              )}
            >
              {currentData.fab_list.map(RenderSelectOptions)}
            </Select>
          </div>
          {mode !== OVERLAY_ADC_CATEGORY ? (
            <div css={SG.contentItemStyle} className="column-2">
              <span className="label">Equipment</span>
              <Select style={{ width: '100%' }}>
                <Select.Option value="1">Tool1600_1</Select.Option>
                <Select.Option value="2">Tool1700_1</Select.Option>
              </Select>
            </div>
          ) : (
            ''
          )}
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Period</span>
            <DatePicker.RangePicker
              value={
                currentData.selected[0] !== ''
                  ? [
                      dayjs(currentData.selected[0]),
                      dayjs(currentData.selected[1]),
                    ]
                  : currentData.period
              }
              placeholder={
                currentData.period[0] !== ''
                  ? [
                      dayjs(currentData.period[0]).format(DATE_FORMAT),
                      dayjs(currentData.period[1]).format(DATE_FORMAT),
                    ]
                  : currentData.period
              }
              onChange={(v) =>
                changeRedux(
                  [
                    dayjs(v[0]).format(DATE_FORMAT),
                    dayjs(v[1]).format(DATE_FORMAT),
                  ],
                  'selected',
                )
              }
              style={{ width: '100%' }}
              disabledDate={(v) => disabledDate(currentData.period, v)}
              inputReadOnly
              allowClear={false}
              showTime
            />
          </div>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Job</span>
            <Select
              style={{ width: '100%' }}
              value={currentData.job}
              onChange={(v) => changeRedux(v, 'job')}
            >
              {currentData.job_list.map(RenderSelectOptions)}
            </Select>
          </div>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Lot ID</span>
            <TreeSelect
              treeData={lotIdOptions}
              value={currentData.lot_id}
              onChange={(v) => changeRedux(v, 'lot_id')}
              showCheckedStrategy={TreeSelect.SHOW_CHILD}
              style={{ width: '100%' }}
              maxTagCount="responsive"
              treeCheckable
              treeDefaultExpandAll
            />
          </div>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">Mean Deviation Diff.</span>
            <Select
              style={{ width: '100%' }}
              mode="multiple"
              maxTagCount="responsive"
              value={currentData.mean_dev_diff}
              onChange={(v) => changeRedux(v, 'mean_dev_diff')}
            >
              {currentData.mean_dev_diff_list.map(RenderSelectOptions)}
            </Select>
          </div>
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">AE Correction</span>
            <Select
              style={{ width: '100%' }}
              value={currentData.ae_correction}
              onChange={(v) => changeRedux(v, 'ae_correction')}
            >
              <Select.Option value="off">Off</Select.Option>
              <Select.Option value="on">On</Select.Option>
            </Select>
          </div>
          {mode !== OVERLAY_ADC_CATEGORY ? (
            <>
              <div css={SG.contentItemStyle} className="column-2">
                <span className="label">Stage Correction</span>
                <TreeSelect
                  treeData={stageCorrectionOptions}
                  value={currentData.stage_correction}
                  onChange={(v) => changeRedux(v, 'stage_correction')}
                  showCheckedStrategy={TreeSelect.SHOW_CHILD}
                  style={{ width: '100%' }}
                  maxTagCount="responsive"
                  treeCheckable
                  treeDefaultExpandAll
                />
              </div>
              <div css={SG.contentItemStyle} className="column-2">
                <span className="label">ADC Correction</span>
                <TreeSelect
                  treeData={adcCorrectionOptions}
                  value={currentData.adc_correction}
                  onChange={(v) => changeRedux(v, 'adc_correction')}
                  showCheckedStrategy={TreeSelect.SHOW_CHILD}
                  style={{ width: '100%' }}
                  maxTagCount="responsive"
                  treeCheckable
                  treeDefaultExpandAll
                  dropdownRender={(menu) => (
                    <div>
                      <div style={{ padding: '8px' }}>
                        <Radio.Group
                          value={radioAdc}
                          onChange={(e) => setRadioAdc(e.target.value)}
                        >
                          <Space direction="vertical">
                            <Radio value="ADC Measurement">
                              ADC Measurement
                            </Radio>
                            <Radio value="ADC Offset">ADC Offset</Radio>
                            <Radio value="ADC Measurement + Offset">
                              ADC Measurement + Offset
                            </Radio>
                          </Space>
                        </Radio.Group>
                      </div>
                      {menu}
                    </div>
                  )}
                />
              </div>
            </>
          ) : (
            ''
          )}
        </div>
        <div
          css={SG.customButtonStyle}
          className="absolute"
          onClick={processStart}
          tabIndex="-1"
          onKeyDown={undefined}
          role="button"
        >
          <PlayCircleOutlined />
          <span>Start</span>
        </div>
      </div>
    </div>
  );
};
SelectTarget.propTypes = {
  mode: PropTypes.string,
};
SelectTarget.defaultProps = {
  mode: OVERLAY_ADC_CATEGORY,
};

export default SelectTarget;
