import dayjs from 'dayjs';
import { OVERLAY_CORRECTION_CATEGORY } from '../../../../../lib/api/Define/etc';

export const createTreeSelectData = (data, key) => {
  if (Object.keys(data).length === 0) return [];

  const findOrgData = key === 'all' ? data : data[key];
  let tmpData = [
    {
      title: 'ALL',
      value: '0',
      key: '0',
      children: [],
    },
  ];

  const createArrayType = (obj) => {
    return Array.isArray(obj)
      ? obj
      : Object.keys(obj).filter(
          (v) =>
            (Array.isArray(obj[v]) && obj[v].length > 0) ||
            !Array.isArray(obj[v]),
        );
  };

  Object.keys(findOrgData).forEach((v) => {
    tmpData[0].children.push(
      key.match('ADC') !== null && v !== 'selected'
        ? {
            title: v,
            value: `0-${v}`,
            key: `0-${v}`,
          }
        : {
            title: v,
            value: `0-${v}`,
            key: `0-${v}`,
            children:
              createArrayType(findOrgData[v]).length > 0
                ? createArrayType(findOrgData[v]).map((x) => {
                    return {
                      title: x,
                      value: `0-${v}-${x}`,
                      key: `0-${v}-${x}`,
                      children:
                        createArrayType(findOrgData[v][x]).length > 0
                          ? createArrayType(findOrgData[v][x]).map((y) => {
                              return {
                                title: y,
                                value: `0-${v}-${x}-${y}`,
                                key: `0-${v}-${x}-${y}`,
                              };
                            })
                          : [],
                    };
                  })
                : [],
          },
    );
  });

  return tmpData;
};

export const createInitTreeValues = (data, key) => {
  const selectValues = [];

  if (Object.keys(data).length > 0) {
    Object.keys(data).forEach((v) => {
      let initValue = '0';
      if (key !== 'adc_correction') {
        Object.keys(data[v]).forEach((x) => {
          if (data[v][x]) {
            selectValues.push(`${initValue}-${v}-${x}`);
          }
        });
      } else {
        Object.keys(data[v]).forEach((z) => {
          const isSelected = Object.keys(data[v]).find(
            (w) => w === 'selected' && data[v][w],
          );
          if (isSelected && data[v][z]) {
            selectValues.push(`${initValue}-${z}`);
          }
        });
      }
    });
  }

  return selectValues;
};

export const createPostData = (data, category, adcKey) => {
  let result = {
    category: category,
    rid: data.source_info.files_rid,
    fab_nm: data.targetInfo.fab_name,
    period:
      data.targetInfo.selected[0] === ''
        ? data.targetInfo.period.join('~')
        : data.targetInfo.selected.join('~'),
    job: data.targetInfo.job,
    lot_id: data.targetInfo.lot_id.map((v) => {
      const splitStr = v.split('-');
      return splitStr[splitStr.length - 1];
    }),
    mean_dev_diff:
      data.targetInfo.mean_dev_diff.length > 0
        ? data.targetInfo.mean_dev_diff.map((v) => Number(v))
        : [],
    ae_correction: data.targetInfo.ae_correction,
  };

  if (category === OVERLAY_CORRECTION_CATEGORY) {
    let stageInfo = {},
      adcInfo = {};

    data.targetInfo.stage_correction.forEach((v) => {
      const splitStr = v.split('-');
      stageInfo[splitStr[1]] = {
        ...stageInfo[splitStr[1]],
        [splitStr[2]]: true,
      };
    });

    data.targetInfo.adc_correction.forEach((v) => {
      const splitStr = v.split('-');
      adcInfo[adcKey] = splitStr[1];
    });

    result = {
      ...result,
      stage_correction: stageInfo,
      adc_correction: adcInfo,
    };
  }

  return result;
};

export const disabledDate = (date, v) => {
  return date[0] === ''
    ? false
    : v &&
        (dayjs(v).isBefore(dayjs(date[0]), 'd') ||
          dayjs(v).isAfter(dayjs(date[1]), 'd'));
};
