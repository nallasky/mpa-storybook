import React, { useState, useMemo } from 'react';
import PropTypes from 'prop-types';
import { Button, Select, Upload, Spin } from 'antd';
import { InboxOutlined, UploadOutlined } from '@ant-design/icons';
import useModal from '../../../../../lib/util/modalControl/useModal';
import useOverlayInfo from '../../../../../hooks/useOverlaySettingInfo';
import { getRemoteDBInfo } from '../../../../../lib/api/axios/useMgmtRequest';
import { post_Overlay_Local_FilesUpload } from '../../../../../lib/api/axios/useOverlayRequest';
import { displayNotification } from '../../../JobAnalysis/functionGroup';
import { OVERLAY_ADC_CATEGORY } from '../../../../../lib/api/Define/etc';
import { overlay_source } from '../../../../../lib/api/Define/OverlayDefault';
import { MSG_LOCAL, MSG_REMOTE } from '../../../../../lib/api/Define/Message';
import { RenderSelectOptions } from '../../../JobAnalysis/AnalysisTable/functionGroup';
import StatusModal from '../StatusModal/StatusModal';
import ProcessingModal from '../ProcessingModal/ProcessingModal';
import * as SG from '../styleGroup';

const SelectSource = ({ mode }) => {
  const { openModal, closeModal } = useModal();
  const {
    adcMeasurementSet,
    correctionSet,
    updateAdcMeasurementSetting,
    updateCorrectionSetting,
  } = useOverlayInfo();
  const [from, setFrom] = useState(
    mode === OVERLAY_ADC_CATEGORY
      ? adcMeasurementSet.source
      : correctionSet.source,
  );
  const [dataBaseInfo, setDataBaseInfo] = useState('');
  const [loadState, setLoadState] = useState(false);
  const [addedFiles, setAddedFiles] = useState([]);

  const dbOptionList = useMemo(() => {
    if (from === 'remote') {
      setLoadState(true);

      let result = [];
      const fetch = async () => {
        const data = await getRemoteDBInfo({ db_id: undefined });
        return (
          data?.items?.map((obj) => ({ id: obj.id, name: obj.name })) ?? []
        );
      };

      fetch()
        .then((data) => console.log(data))
        .catch((e) => {
          console.log(e);
        })
        .finally(() => setLoadState(false));

      return result;
    }
  }, [from]);

  const processStart = async () => {
    const formData = new FormData();
    let upload_id = undefined;

    addedFiles.forEach((v) => {
      formData.append('files', v);
    });
    formData.append('category', mode);

    openModal(ProcessingModal, {
      title: 'Converting',
      message: 'Converting files',
    });

    await post_Overlay_Local_FilesUpload(formData)
      .then((id) => (upload_id = id.upload_id))
      .catch((e) => console.log(e))
      .finally(() => closeModal(ProcessingModal));

    if (upload_id === undefined || upload_id === '0') {
      displayNotification({
        message: 'Error occurred',
        description: 'Please select another file.',
        duration: 3,
        style: { borderLeft: '5px solid red' },
      });
    } else {
      if (mode === OVERLAY_ADC_CATEGORY) {
        updateAdcMeasurementSetting({
          ...adcMeasurementSet,
          source_info: {
            db:
              from === MSG_REMOTE
                ? dbOptionList.find((v) => v.id === dataBaseInfo)
                : adcMeasurementSet.source_info.db,
            files_rid:
              from !== MSG_REMOTE
                ? upload_id
                : adcMeasurementSet.source_info.files_rid,
          },
        });
      } else {
        updateCorrectionSetting({
          ...correctionSet,
          source_info: {
            db:
              from === MSG_REMOTE
                ? dbOptionList.find((v) => v.id === dataBaseInfo)
                : correctionSet.source_info.db,
            files_rid:
              from !== MSG_REMOTE
                ? upload_id
                : correctionSet.source_info.files_rid,
          },
        });
      }

      openModal(StatusModal, {
        id: upload_id,
        category: mode,
      });
    }
  };

  return (
    <div css={SG.componentStyle} className="stretch">
      <Spin size="large" tip="Loading..." spinning={loadState} />
      <div css={SG.componentTitleStyle}>Select Source</div>
      <div css={SG.contentWrapperStyle}>
        <div css={SG.contentStyle} className="full-width">
          <div css={SG.contentItemStyle} className="column-2">
            <span className="label">From</span>
            <Select
              value={from}
              style={{ width: '100%' }}
              onChange={(v) => setFrom(v)}
            >
              {overlay_source.map(RenderSelectOptions)}
            </Select>
          </div>
          {from === MSG_LOCAL ? (
            <div css={SG.contentItemStyle} className="upload column-2">
              <span className="label">Log Files</span>
              {mode === OVERLAY_ADC_CATEGORY ? (
                <Upload.Dragger
                  onChange={(e) => {
                    setAddedFiles(
                      e.fileList.length > 0
                        ? e.fileList.map((v) => v.originFileObj)
                        : [],
                    );
                  }}
                  beforeUpload={() => false}
                >
                  <p className="ant-upload-drag-icon">
                    <InboxOutlined />
                  </p>
                  <p className="ant-upload-text">
                    Click or drag file to this area to upload
                  </p>
                </Upload.Dragger>
              ) : (
                <Upload
                  onChange={(e) => {
                    setAddedFiles(
                      e.fileList.length > 0
                        ? [e.fileList[0].originFileObj]
                        : [],
                    );
                  }}
                  beforeUpload={() => false}
                  maxCount="1"
                  className="full-width"
                >
                  <Button icon={<UploadOutlined />}>Upload zip only</Button>
                </Upload>
              )}
            </div>
          ) : (
            <div css={SG.contentItemStyle} className="column-2">
              <span className="label">DB From</span>
              <Select
                value={dataBaseInfo}
                style={{ width: '100%' }}
                onChange={(v) => setDataBaseInfo(v)}
              >
                {dbOptionList?.map((db) => {
                  return (
                    <>
                      <Select.Option value={db.id}>{db.name}</Select.Option>
                    </>
                  );
                }) ?? <></>}
              </Select>
            </div>
          )}
        </div>
      </div>
      {from === MSG_LOCAL ? (
        <div className="source-button-wrapper">
          <button
            css={SG.antdButtonStyle}
            className="white"
            disabled={addedFiles.length === 0}
            onClick={processStart}
          >
            Load Start
          </button>
        </div>
      ) : (
        ''
      )}
    </div>
  );
};
SelectSource.propTypes = {
  mode: PropTypes.string,
};
SelectSource.defaultProps = {
  mode: OVERLAY_ADC_CATEGORY,
};

export default SelectSource;
