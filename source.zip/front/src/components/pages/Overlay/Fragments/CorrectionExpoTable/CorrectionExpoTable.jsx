import React from 'react';
import PropTypes from 'prop-types';
import CustomTextCheckBox from '../CustomTextCheckBox/CustomTextCheckBox';
import * as tStyle from './styleGroup';

const CorrectionExpoTable = ({ columns, rows }) => {
  if (columns === undefined || rows === undefined) return;

  return (
    <div className="table-wrapper">
      <table css={tStyle.controlTableStyle}>
        <thead>
          <tr>
            {Object.keys(columns).map((v, i) => {
              return (
                <th key={i}>
                  {v === 'shot' ? (
                    v
                  ) : (
                    <CustomTextCheckBox id={`header_${v}`} label={v} />
                  )}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {rows.map((v, idx) => {
            return (
              <tr key={idx}>
                {Object.keys(v).map((x, i) => {
                  return (
                    <td key={i}>
                      <CustomTextCheckBox
                        id={`${idx}_${i}`}
                        isChecked={
                          x === 'shot' ? v[x].mode === 'auto' : v[x].checked
                        }
                        label={x === 'shot' ? v[x].id : undefined}
                        useText={x !== 'shot'}
                        value={x !== 'shot' ? v[x].value : undefined}
                        onText="auto"
                        offText="manual"
                      />
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
CorrectionExpoTable.propTypes = {
  columns: PropTypes.object.isRequired,
  rows: PropTypes.array.isRequired,
};

export default CorrectionExpoTable;
