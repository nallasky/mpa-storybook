import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import PropTypes from 'prop-types';
import Plotly from 'plotly.js-dist';
import { global_adc_mea_data } from '../../../../../lib/api/axios/tempResponse';
import {
  MapDefaultScript,
  ReproducibilityDefaultScript,
  VariationDefaultScript,
  AnovaDefaultScript,
  BaraDefaultScript,
} from '../../../../../lib/util/Graph';
import {
  E_OVERLAY_ANOVA,
  E_OVERLAY_COMPONENT,
  E_OVERLAY_IMAGE,
  E_OVERLAY_MAP,
  E_OVERLAY_REPRODUCIBILITY,
  E_OVERLAY_VARIATION,
} from '../../../../../lib/api/Define/etc';
import useOverlayResultInfo from '../../../../../hooks/useOverlayResultInfo';
import {
  MSG_3SIGMA_X,
  MSG_3SIGMA_Y,
} from '../../../../../lib/api/Define/Message';
import { Divider } from 'antd';

const script = [
  { id: E_OVERLAY_MAP, script: MapDefaultScript, data: global_adc_mea_data },
  {
    id: E_OVERLAY_VARIATION,
    script: [BaraDefaultScript, VariationDefaultScript],
    data: global_adc_mea_data,
  },
  {
    id: E_OVERLAY_REPRODUCIBILITY,
    script: ReproducibilityDefaultScript,
    data: global_adc_mea_data,
  },
  {
    id: E_OVERLAY_ANOVA,
    script: AnovaDefaultScript,
    data: global_adc_mea_data,
  },
  {
    id: E_OVERLAY_IMAGE,
    script: undefined,
    data: global_adc_mea_data,
  },
  {
    id: E_OVERLAY_COMPONENT,
    script: undefined,
    data: global_adc_mea_data,
  },
];
const common = { screen_width: 1700, screen_height: 500 };
const Reproducibility_X = {
  ...common,
  title: MSG_3SIGMA_X,
  disp_name: 'X',
};
const Reproducibility_Y = {
  ...common,
  title: MSG_3SIGMA_Y,
  disp_name: 'Y',
};
const OverlayResultGraph = ({ type }) => {
  const graphArea = useRef(null);
  const graphArea2 = useRef(null);
  const { gReproducibility, gMap, gVariation } = useOverlayResultInfo();
  const getScriptObject = useCallback((id) => {
    return script.find((o) => o.id === id);
  }, []);
  const typeObject = useMemo(() => getScriptObject(type), [
    type,
    getScriptObject,
  ]);
  useEffect(() => {
    if ((graphArea.current ?? false) && type !== E_OVERLAY_REPRODUCIBILITY) {
      const data = getScriptObject(type);
      const renderFunc = new Function('return ' + data?.script ?? null)();
      renderFunc(Plotly, graphArea.current, data?.data ?? {}, 5);
    }
  }, [gMap, type]);
  useEffect(() => {
    if ((graphArea.current ?? false) && type === E_OVERLAY_REPRODUCIBILITY) {
      const renderFunc = new Function('return ' + typeObject?.script ?? null)();
      renderFunc(Plotly, graphArea.current, typeObject?.data ?? {}, {
        ...Reproducibility_X,
        upper_limit: gReproducibility.three_sigma_x,
      });
      renderFunc(Plotly, graphArea2.current, typeObject?.data ?? {}, {
        ...Reproducibility_Y,
        upper_limit: gReproducibility.three_sigma_y,
      });
    }
  }, [gReproducibility, type]);

  useEffect(() => {
    if ((graphArea.current ?? false) && type === E_OVERLAY_VARIATION) {
      const renderFunc = new Function(
        'return ' + typeObject?.script[0] ?? null,
      )();
      renderFunc(Plotly, graphArea.current, typeObject?.data ?? {}, {
        ...gVariation,
        ...common,
        select_shot: gVariation?.select_shot ?? 'all',
      });
      const renderFunc2 = new Function(
        'return ' + typeObject?.script[1] ?? null,
      )();
      renderFunc2(Plotly, graphArea2.current, typeObject?.data ?? {});
    }
  }, [gVariation, type]);

  return (
    <>
      <div ref={graphArea} />
      {[E_OVERLAY_REPRODUCIBILITY, E_OVERLAY_VARIATION].includes(type) ? (
        <>
          {' '}
          <Divider />
          <div ref={graphArea2} />
        </>
      ) : (
        <></>
      )}
    </>
  );
};
OverlayResultGraph.propTypes = {
  type: PropTypes.string,
};
export default OverlayResultGraph;
