import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import PropTypes from 'prop-types';
import Plotly from 'plotly.js-dist';
import {
  MapDefaultScript,
  ReproducibilityDefaultScript,
  VariationDefaultScript,
  AnovaDefaultScript,
  BaraDefaultScript,
  CorrectionCompScript,
  CorrectImageScript,
} from '../../../../../lib/util/Graph';
import {
  E_OVERLAY_ANOVA,
  E_OVERLAY_COMPONENT,
  E_OVERLAY_IMAGE,
  E_OVERLAY_MAP,
  E_OVERLAY_REPRODUCIBILITY,
  E_OVERLAY_VARIATION,
} from '../../../../../lib/api/Define/etc';
import useOverlayResultInfo from '../../../../../hooks/useOverlayResultInfo';
import {
  MSG_3SIGMA_X,
  MSG_3SIGMA_Y,
  MSG_X,
  MSG_Y,
} from '../../../../../lib/api/Define/Message';
import { Divider } from 'antd';
import { AnovaTab, AnovaTable } from '../AnovaSetting';
import useOverlaySettingInfo from '../../../../../hooks/useOverlaySettingInfo';
import MapLotTable from '../MapSetting/MapLotTable';

const gScript = [
  { id: E_OVERLAY_MAP, func: [MapDefaultScript] },
  {
    id: E_OVERLAY_VARIATION,
    func: [BaraDefaultScript, VariationDefaultScript],
  },
  {
    id: E_OVERLAY_REPRODUCIBILITY,
    func: [ReproducibilityDefaultScript, ReproducibilityDefaultScript],
  },
  {
    id: E_OVERLAY_ANOVA,
    func: [AnovaDefaultScript],
  },
  {
    id: E_OVERLAY_IMAGE,
    func: [CorrectImageScript],
  },
  {
    id: E_OVERLAY_COMPONENT,
    func: [CorrectionCompScript],
  },
];
const common = { screen_width: 1700, screen_height: 500 };
const DISP_NAME = (msg) => ({ disp_name: msg });
const Reproducibility_X = {
  ...common,
  title: MSG_3SIGMA_X,
  ...DISP_NAME(MSG_X),
};
const Reproducibility_Y = {
  ...common,
  title: MSG_3SIGMA_Y,
  ...DISP_NAME(MSG_Y),
};

const OverlayResultGraph = ({ type, origin_data }) => {
  const graphArea = useRef(null);
  const graphArea2 = useRef(null);
  /*  const itemsRef = useRef([]);*/
  const { adcCommonInfo: adcCommon } = useOverlaySettingInfo();
  const {
    gReproducibility,
    gMap,
    gVariation,
    gAnova,
    updateAnovaSetting,
  } = useOverlayResultInfo();
  const getScriptObject = useCallback((id) => {
    return gScript.find((o) => o.id === id);
  }, []);
  const RenderGraph = useCallback(({ renderFunc, element, object }) => {
    renderFunc(Plotly, element, origin_data ?? {}, object);
  }, []);
  const typeObject = useMemo(() => getScriptObject(type), [
    type,
    getScriptObject,
  ]);
  const drawRenderObject = {
    [E_OVERLAY_ANOVA]: [{ ...common, ...DISP_NAME(gAnova.selected) }],
    [E_OVERLAY_MAP]: [gMap],
    [E_OVERLAY_VARIATION]: [
      {
        ...gVariation,
        ...common,
        select_shot:
          gVariation.select_shot === 'all'
            ? adcCommon?.shot
            : gVariation.select_shot,
      },
      {},
    ],
    [E_OVERLAY_REPRODUCIBILITY]: [
      {
        ...Reproducibility_X,
        upper_limit: gReproducibility.three_sigma_x,
      },
      {
        ...Reproducibility_Y,
        upper_limit: gReproducibility.three_sigma_y,
      },
    ],
    [E_OVERLAY_IMAGE]: {},
    [E_OVERLAY_COMPONENT]: {},
  };
  const drawGraph = () => {
    if ((graphArea.current ?? false) && type !== undefined) {
      typeObject?.func?.map((_, i) => {
        RenderGraph({
          renderFunc: typeObject?.func[i] ?? null,
          object: drawRenderObject[type][i],
          element: i === 0 ? graphArea.current : graphArea2.current,
        });
      });
    }
  };
  useEffect(() => {
    console.log('draw type change / gAnova or gReproducibility');
    drawGraph();
  }, [type, gAnova, gReproducibility]);

  useEffect(() => {
    console.log('draw Map');
    drawGraph();
  }, [
    gMap.column_num,
    gMap.offset.info,
    gMap.div,
    gMap.display_map,
    gMap.show_extra_info,
    gMap.plate_size,
    gVariation,
  ]);

  return (
    <>
      {type === E_OVERLAY_ANOVA ? (
        <>
          <AnovaTab
            list={gAnova.list}
            selected={gAnova.selected}
            changeEvent={(e) => updateAnovaSetting({ ...gAnova, selected: e })}
          />
          <AnovaTable
            origin={adcCommon.origin?.anova ?? {}}
            selected={gAnova.selected}
          />{' '}
          <Divider />
        </>
      ) : type === E_OVERLAY_MAP && gMap.show_extra_info ? (
        <>
          <MapLotTable
            origin={adcCommon?.origin?.data}
            lot_id={Object.keys(adcCommon?.origin?.data)[0]}
            lot_idx={1}
          />
          <Divider />
        </>
      ) : (
        <></>
      )}
      <div ref={graphArea} />
      {[E_OVERLAY_REPRODUCIBILITY, E_OVERLAY_VARIATION].includes(type) ? (
        <>
          {' '}
          <Divider />
          <div ref={graphArea2} />
        </>
      ) : (
        <></>
      )}
    </>
  );
};
OverlayResultGraph.propTypes = {
  type: PropTypes.string,
  origin_data: PropTypes.object,
};
export default OverlayResultGraph;
