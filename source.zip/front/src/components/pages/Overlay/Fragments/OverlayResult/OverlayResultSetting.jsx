import React, { useEffect, useState } from 'react';
import * as SG from '../styleGroup';
import OffsetSetting from '../MapSetting/OffsetSetting';
import CpVsSetting from '../MapSetting/CpVsSetting';
import EtcSetting from '../MapSetting/EtcSetting';
import PropTypes from 'prop-types';
import {
  MSG_RE_START,
  MSG_SETTING,
} from '../../../../../lib/api/Define/Message';
import {
  E_OVERLAY_COMPONENT,
  E_OVERLAY_IMAGE,
  E_OVERLAY_MAP,
  E_OVERLAY_REPRODUCIBILITY,
  E_OVERLAY_VARIATION,
  OVERLAY_ADC_CATEGORY,
} from '../../../../../lib/api/Define/etc';
import ThreeSigmaRangeSetting from '../ReproducibilitySetting/ThreeSigmaRangeSetting';
import RangeAndShotSetting from '../VariationSetting/RangeAndShotSetting';
import {
  createPostData,
  process_Overlay_Start,
} from '../SelectTarget/functionGroup';
import useOverlaySettingInfo from '../../../../../hooks/useOverlaySettingInfo';
import useModal from '../../../../../lib/util/modalControl/useModal';
import { PlayCircleOutlined } from '@ant-design/icons';
import { CPVS_MODE } from '../../../../../lib/api/Define/OverlayDefault';
import useOverlayResultInfo from '../../../../../hooks/useOverlayResultInfo';

const ResultGraphSetting = ({ mode, type }) => {
  const {
    adcMeasurementSet,
    correctionSet,
    updateOriginDataSetting,
  } = useOverlaySettingInfo();
  const { gCorrectionMap, gMap } = useOverlayResultInfo();
  const { openModal, closeModal } = useModal();
  const [isReAnalysis, setReAnalysis] = useState(false);

  const reAnalysis = () => {
    let postData = createPostData(
      mode === OVERLAY_ADC_CATEGORY ? adcMeasurementSet : correctionSet,
      mode,
    );
    const adc_cp_list = (cp_vs) => {
      const shots = Object.keys(cp_vs.shots);
      const shots_value = Object.values(cp_vs.shots);
      return Object.keys(shots_value[0]).reduce(
        (acc, cp) => ({
          ...acc,
          [cp]:
            cp_vs.mode === CPVS_MODE.SAME
              ? shots_value.reduce(
                  (acc2, _, i) => ({ ...acc2, [shots[i]]: shots_value[0][cp] }),
                  {},
                )
              : shots_value.reduce(
                  (acc2, o2, i) => ({ ...acc2, [shots[i]]: o2[cp] }),
                  {},
                ),
        }),
        {},
      );
    };
    const correction_cpvs_list = (cp_vs) => {
      console.log(cp_vs);
      const cpVskeylist = Object.keys(cp_vs);
      const shots = cp_vs[cpVskeylist[0]].map((o) => o.shot.id);
      const shots_value = Object.keys(shots);
      const getCpVsValue = (cp_vs, key) => {
        return {
          [key]: cp_vs.reduce(
            (acc, o) => ({ ...acc, [o.shot.id]: o[key] }),
            {},
          ),
        };
      };
      return shots_value.reduce((acc, cp) => {
        const key_list = Object.keys(cp_vs?.[cp]?.[0]).filter((o) => o !== 'shot'); //cp1, cp12d.....
        return key_list.reduce(
          (acc2, obj2) =>
            Object.assign(acc2, { [obj2]: getCpVsValue(cp_vs[cp], obj2) }),
          {},
        );
      }, {});
    };
    postData = {
      ...postData,
      cp_vs:
        mode === OVERLAY_ADC_CATEGORY
          ? {
              use_from_log:
                adcMeasurementSet?.graph?.map?.cp_vs?.mode ===
                CPVS_MODE.FROM_LOG,
              adc_measurement: adc_cp_list(adcMeasurementSet.graph.map.cp_vs),
            }
          : {
              use_from_log:
                correctionSet?.graph?.cp_vs?.adc_measurement ===
                CPVS_MODE.FROM_LOG,
              adc_measurement: adc_cp_list(
                correctionSet?.graph?.cp_vs?.adc_measurement,
              ),
              correction: correction_cpvs_list(
                correctionSet?.graph?.cp_vs?.correction.shots,
              ),
            },
    };
    process_Overlay_Start({
      postData,
      openModal,
      closeModal,
      mode,
      updateOriginDataSetting,
    }).then(() => setReAnalysis(false));
  };
  useEffect(() => {
    setReAnalysis(true);
    console.log('update Analysis');
  }, [gMap.cp_vs, gCorrectionMap.cp_vs]);

  return (
    <>
      <div className="header">
        <span style={{ fontWeight: 400 }}>
          {type.title} {MSG_SETTING}
        </span>
        <div>
          {[E_OVERLAY_IMAGE, E_OVERLAY_COMPONENT, E_OVERLAY_MAP].includes(
            type.id,
          ) ? (
            <button
              css={SG.customButtonStyle}
              className="blue"
              onClick={reAnalysis}
              disabled={isReAnalysis === false}
            >
              <PlayCircleOutlined />
              <span>{MSG_RE_START}</span>
            </button>
          ) : (
            <></>
          )}
        </div>
      </div>
      <div className="main">
        {[E_OVERLAY_COMPONENT, E_OVERLAY_IMAGE, E_OVERLAY_MAP].includes(
          type.id,
        ) ? (
          <>
            <OffsetSetting mode={mode} type={type.id} />
            <CpVsSetting mode={mode} type={type.id} />
            <EtcSetting mode={mode} type={type.id} />
          </>
        ) : type.id === E_OVERLAY_VARIATION ? (
          <RangeAndShotSetting />
        ) : type.id === E_OVERLAY_REPRODUCIBILITY ? (
          <ThreeSigmaRangeSetting />
        ) : (
          <></>
        )}
      </div>
    </>
  );
};
ResultGraphSetting.propTypes = {
  mode: PropTypes.string,
  type: PropTypes.object,
};
export default ResultGraphSetting;
