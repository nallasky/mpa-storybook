import React from 'react';
import * as SG from '../styleGroup';
import OffsetSetting from '../MapSetting/OffsetSetting';
import CpVsSetting from '../MapSetting/CpVsSetting';
import EtcSetting from '../MapSetting/EtcSetting';
import PropTypes from 'prop-types';
import { MSG_APPLY, MSG_SETTING } from '../../../../../lib/api/Define/Message';
import {
  E_OVERLAY_COMPONENT,
  E_OVERLAY_IMAGE,
  E_OVERLAY_MAP,
  E_OVERLAY_REPRODUCIBILITY,
  E_OVERLAY_VARIATION,
} from '../../../../../lib/api/Define/etc';
import ThreeSigmaRangeSetting from '../ReproducibilitySetting/ThreeSigmaRangeSetting';
import RangeAndShotSetting from '../VariationSetting/RangeAndShotSetting';

const ResultGraphSetting = ({ mode, type }) => {
  return (
    <>
      <div className="header">
        <span style={{ fontWeight: 400 }}>
          {type.title} {MSG_SETTING}
        </span>
        <div>
          {type.id === E_OVERLAY_MAP ? (
            <button css={SG.antdButtonStyle} className="blue">
              {MSG_APPLY}
            </button>
          ) : (
            <></>
          )}
        </div>
      </div>
      <div className="main">
        {type.id === E_OVERLAY_MAP ? (
          <>
            <OffsetSetting />
            <CpVsSetting mode={mode} />
            <EtcSetting mode={mode} />
          </>
        ) : type.id === E_OVERLAY_VARIATION ? (
          <RangeAndShotSetting />
        ) : type.id === E_OVERLAY_REPRODUCIBILITY ? (
          <ThreeSigmaRangeSetting />
        ) : type.id === E_OVERLAY_COMPONENT ? (
          <>{'3Sigma'}</>
        ) : type.id === E_OVERLAY_IMAGE ? (
          <>{'3Sigma'}</>
        ) : (
          <></>
        )}
      </div>
    </>
  );
};
ResultGraphSetting.propTypes = {
  mode: PropTypes.string,
  type: PropTypes.object,
};
export default ResultGraphSetting;
