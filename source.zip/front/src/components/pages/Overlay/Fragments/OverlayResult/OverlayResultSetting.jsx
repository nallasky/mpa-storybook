import React from 'react';
import * as SG from '../styleGroup';
import OffsetSetting from '../MapSetting/OffsetSetting';
import CpVsSetting from '../MapSetting/CpVsSetting';
import EtcSetting from '../MapSetting/EtcSetting';
import PropTypes from 'prop-types';
import { MSG_APPLY, MSG_SETTING } from '../../../../../lib/api/Define/Message';
import {
  E_OVERLAY_COMPONENT,
  E_OVERLAY_IMAGE,
  E_OVERLAY_MAP,
  E_OVERLAY_REPRODUCIBILITY,
  E_OVERLAY_VARIATION,
} from '../../../../../lib/api/Define/etc';
import ThreeSigmaRangeSetting from '../ReproducibilitySetting/ThreeSigmaRangeSetting';
import RangeAndShotSetting from '../VariationSetting/RangeAndShotSetting';

const ResultGraphSetting = ({ mode, type }) => {

  const reAnalysis = ()=>{
    console.log("reAnalysis");
  }

  return (
    <>
      <div className="header">
        <span style={{ fontWeight: 400 }}>
          {type.title} {MSG_SETTING}
        </span>
        <div>
          {type.id === E_OVERLAY_MAP ? (
            <button css={SG.antdButtonStyle} className="blue" onClick={reAnalysis} >
              {MSG_APPLY}
            </button>
          ) : (
            <></>
          )}
        </div>
      </div>
      <div className="main">
        {[E_OVERLAY_COMPONENT, E_OVERLAY_IMAGE, E_OVERLAY_MAP].includes(
          type.id,
        ) ? (
          <>
            <OffsetSetting mode={mode} type={type.id} />
            <CpVsSetting mode={mode} type={type.id} />
            <EtcSetting mode={mode} type={type.id} />
          </>
        ) : type.id === E_OVERLAY_VARIATION ? (
          <RangeAndShotSetting />
        ) : type.id === E_OVERLAY_REPRODUCIBILITY ? (
          <ThreeSigmaRangeSetting />
        ) : (
          <></>
        )}
      </div>
    </>
  );
};
ResultGraphSetting.propTypes = {
  mode: PropTypes.string,
  type: PropTypes.string,
};
export default ResultGraphSetting;
