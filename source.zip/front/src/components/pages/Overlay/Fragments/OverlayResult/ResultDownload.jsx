import React, { useMemo } from "react";
import { CloudDownloadOutlined } from '@ant-design/icons';
import { MSG_DOWNLOAD } from '../../../../../lib/api/Define/Message';
import * as SG from '../styleGroup';
import { postFormdataRequestExport } from '../../../../../lib/api/axios/requests';
import { URL_EXPORT_OVERLAY } from '../../../../../lib/api/Define/URL';
import useOverlaySettingInfo from '../../../../../hooks/useOverlaySettingInfo';
import PropTypes from 'prop-types';
import { OVERLAY_ADC_CATEGORY } from '../../../../../lib/api/Define/etc';
import { getGraphImage2 } from '../../../../../lib/util/plotly-test';
import useOverlayResultInfo from "../../../../../hooks/useOverlayResultInfo";

const ResultDownload = ({ mode }) => {
  const { correctionSet, adcMeasurementSet } = useOverlaySettingInfo();
  const { gCorrectionData, gAdcMeasurementData } = useOverlayResultInfo();
  const originInfo = useMemo(()=>{
    return mode === OVERLAY_ADC_CATEGORY ? adcMeasurementSet : correctionSet
  },[gAdcMeasurementData,gCorrectionData ])
  const deleteProperties = (object) => {
    const tmp = { ...object };
    delete tmp['info'];
    return tmp;
  };
  const downloadFunc = async () => {
    const FormObj = new FormData();
    console.log('==============settings.json======================');
    const obj = deleteProperties(
      originInfo,
    );
    FormObj.append(
      'setting',
      new Blob([JSON.stringify(obj)], {
        type: 'application/json',
      }),
    );
    console.log('==============getGraphImage======================');
    const imgData = await getGraphImage2();
    imgData.forEach((v) => {
      FormObj.append('files', new File([v.url], v.filename));
    });
    const { status } = await postFormdataRequestExport(
      `${URL_EXPORT_OVERLAY}/${mode}/${obj.source_info.files_rid}`,
      FormObj,
    );
    console.log('status', status);
  };
  return (
    <>
      <button
        css={SG.antdButtonStyle}
        className="white"
        style={{ marginLeft: '8px', fontWeight: 400 }}
        onClick={downloadFunc}
      >
        <CloudDownloadOutlined />
        <span> {MSG_DOWNLOAD} </span>
      </button>
    </>
  );
};
ResultDownload.propTypes = {
  mode: PropTypes.string,
};
export default ResultDownload;
