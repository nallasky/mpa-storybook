import React from 'react';
import Button from '../../../../UI/atoms/Button';
import { CloudDownloadOutlined } from '@ant-design/icons';
import { MSG_DOWNLOAD } from '../../../../../lib/api/Define/Message';

const ResultDownload = () => {
  return (
    <>
      <Button
        style={{ marginLeft: '8px', fontWeight: 400 }}
        onClick={(e) => {
          console.log(e);
        }}
      >
        <CloudDownloadOutlined />
        <span>{MSG_DOWNLOAD} </span>
      </Button>
    </>
  );
};
export default ResultDownload;
