import React from 'react';
import { Button, Upload } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import * as SG from '../styleGroup';
import CpVsOption from './CpVsOption';
import CommonCpVsTable from './CommonCpVsTable';

const CpVsMeasurement = () => {
  return (
    <>
      <CpVsOption />
      <CommonCpVsTable />
      <div css={SG.contentItemStyle} className="column-3">
        <span className="label">Job data file</span>
        <Upload>
          <Button icon={<UploadOutlined />}>Load</Button>
        </Upload>
      </div>
    </>
  );
};

export default CpVsMeasurement;
