import React from 'react';
import CpVsOption from './CpVsOption';
import CommonCpVsTable from './CommonCpVsTable';
import JobFileUpload from './JobFileUpload';
import PropTypes from 'prop-types';

const CpVsMeasurement = ({ mode }) => {
  return (
    <>
      <CpVsOption mode={mode} />
      <CommonCpVsTable mode={mode} />
      <JobFileUpload />
    </>
  );
};
CpVsMeasurement.propTypes = {
  mode: PropTypes.string,
};

export default CpVsMeasurement;
