import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import * as SG from '../styleGroup';
import CorrectionExpoTable from '../CorrectionExpoTable/CorrectionExpoTable';
import CustomAccordion from '../../../../UI/molecules/CustomAccordion/CustomAccodion';
import CustomRadioGroup from '../../../../UI/molecules/CustomRadioGroup/CustomRadioGroup';
import CpVsMeasurement from './CpVsMeasurement';
import CpVsOption from './CpVsOption';

const CpVsSetting = ({ mode }) => {
  const [tab, setTab] = useState('measurement');
  const [tmpArray, setTmpArray] = useState([]);

  const createDummyData = () => {
    const tmpBuf = [];

    for (let i = 0; i < 6; i++) {
      const flag = i < 3;
      tmpBuf.push({
        shot: {
          id: i + 1,
          mode: flag ? 'manual' : 'auto',
        },
        cp1: {
          checked: flag,
          value: '-600.000000',
        },
        'cp12`': {
          checked: !flag,
          value: '-450.000000',
        },
        'cp1`': {
          checked: flag,
          value: '-300.000000',
        },
        'cp21`': {
          checked: !flag,
          value: '-150.000000',
        },
        cp2: {
          checked: flag,
          value: '0.000000',
        },
        'cp23`': {
          checked: !flag,
          value: '150.000000',
        },
        'cp3`': {
          checked: flag,
          value: '300.000000',
        },
        'cp32`': {
          checked: !flag,
          value: '450.000000',
        },
        cp3: {
          checked: flag,
          value: '600.000000',
        },
      });
    }

    setTmpArray(tmpBuf);
  };

  useEffect(() => {
    createDummyData();
  }, []);

  return (
    <CustomAccordion title="CP / VS">
      <div
        css={SG.settingContentStyle}
        className={mode !== 'measurement' ? 'full-width' : ''}
      >
        <div className="content">
          {mode === 'measurement' ? (
            <CpVsMeasurement />
          ) : (
            <>
              <div className="radio-wrapper">
                <CustomRadioGroup
                  changeFunc={(v) => setTab(v)}
                  currentChecked={tab}
                  options={[
                    {
                      id: 'measurement',
                      title: 'ADC Measurement',
                      icon: undefined,
                    },
                    {
                      id: 'comp-exposure',
                      title: 'Correction component of exposure',
                      icon: undefined,
                    },
                  ]}
                  name="cp-vs-option"
                  className="cp-vs"
                />
              </div>
              <div
                css={SG.settingContentStyle}
                className={
                  'tab ' + (tab === 'measurement' ? '' : 'correction-cp-vs')
                }
              >
                {tab === 'measurement' ? (
                  <CpVsMeasurement />
                ) : (
                  <div>
                    <CpVsOption />
                    <div className="table-wrapper">
                      <CorrectionExpoTable
                        rows={tmpArray}
                        columns={tmpArray[0]}
                      />
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </CustomAccordion>
  );
};
CpVsSetting.propTypes = {
  mode: PropTypes.string,
};
CpVsSetting.defaultProps = {
  mode: 'measurement',
};

export default CpVsSetting;
