import React from 'react';
import { Input, InputNumber, Switch } from 'antd';
import PropTypes from 'prop-types';
import * as SG from '../styleGroup';
import CustomAccordion from '../../../../UI/molecules/CustomAccordion/CustomAccodion';

const EtcSetting = ({ mode }) => {
  return (
    <CustomAccordion title="Etc.">
      <div css={SG.settingContentStyle} className="etc">
        <div className="content">
          <div css={SG.contentItemStyle} className="etc">
            <span className="label">Display Map</span>
            <div>
              <InputNumber />
              <span className="margin-lr">~</span>
              <InputNumber />
            </div>
          </div>
          <div css={SG.contentItemStyle} className="etc">
            <span className="label">Number of Columns to Display</span>
            <InputNumber />
          </div>
          <div css={SG.contentItemStyle} className="etc">
            <span className="label">Div</span>
            <div className="tx-right">
              <span className="margin-r">Upper Row</span>
              <Input style={{ width: '40%' }} />
            </div>
          </div>
          <div css={SG.contentItemStyle} className="etc">
            <span className="label">Plate Size</span>
            <div className="tx-right">
              <span className="margin-r">Size_X</span>
              <Input style={{ width: '30%' }} />
              <span className="margin-lr">Size_Y</span>
              <Input style={{ width: '30%' }} />
            </div>
          </div>
          {mode === 'measurement' ? (
            <div css={SG.contentItemStyle} className="etc">
              <span className="label">Map Show Data</span>
              <Switch defaultChecked />
            </div>
          ) : (
            ''
          )}
        </div>
      </div>
    </CustomAccordion>
  );
};
EtcSetting.propTypes = {
  mode: PropTypes.string,
};
EtcSetting.defaultProps = {
  mode: 'measurement',
};

export default EtcSetting;
