import React, { useMemo } from 'react';
import { InputNumber, Switch, Button } from 'antd';
import PropTypes from 'prop-types';
import * as SG from '../styleGroup';
import CustomAccordion from '../../../../UI/molecules/CustomAccordion/CustomAccodion';
import {
  MSG_APPLY,
  MSG_DISPLAY_MAP,
  MSG_DIV,
  MSG_NUMBER_OF_COLUMNS,
  MSG_PLATE_SIZE,
  MSG_SHOW_EXTRA_INFO,
  MSG_SIZE_X,
  MSG_SIZE_Y,
  MSG_STILDE,
  MSG_UPPER_ROW,
} from '../../../../../lib/api/Define/Message';
import useOverlayResultInfo from '../../../../../hooks/useOverlayResultInfo';
import { css } from '@emotion/react';
import { useMutation } from 'react-query';
import { QUERY_KEY } from '../../../../../lib/api/Define/QueryKey';
import { put_Overlay_etc_setting } from '../../../../../lib/api/axios/useOverlayRequest';
import NotificationBox from '../../../../UI/molecules/NotificationBox/Notification';
const BlockWrapper = css`
  min-width: 50%;
  padding: 15px !important;
  background-color: aliceblue;
`;
const contentsWrapper = css`
  display: flex;
  flex-direction: row;
`;

const EtcSetting = ({ mode }) => {
  const {
    gMap: AdcMapinfo,
    updateMapSetting,
    gAdcMeasurementFabName: fab_name,
    updateEtcSetting,
    isEtcUpdating,
  } = useOverlayResultInfo();

  console.log('mode', mode);

  const updateMutation = useMutation(
    [QUERY_KEY.OVERLAY_ETC_SETTING_UPDATE, fab_name],
    put_Overlay_etc_setting,
    {
      onSuccess: () => {
        console.log('update success ');
      },
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSettled: () => {
        updateEtcSetting(false);
      },
    },
  );

  const ApplyButtonEnable = useMemo(() => {
    const { div, plate_size } = AdcMapinfo;
    return !!div.div_upper && !!plate_size.size_x && !!plate_size.size_y;
  }, [AdcMapinfo.div, AdcMapinfo.plate_size]);


  return (
    <CustomAccordion title="Etc." defaultValue={true}>
      <div css={SG.settingContentStyle} className="etc">
        <div className="content" css={contentsWrapper}>
          <div css={[BlockWrapper]}>
            {' '}
            {/*Left*/}
            <div css={SG.contentItemStyle} className="etc">
              <span className="label">{MSG_DISPLAY_MAP}</span>
              <div>
                <InputNumber
                  min={1}
                  max={AdcMapinfo?.display_map?.max ?? 999}
                  defaultValue={AdcMapinfo?.display_map?.min ?? 1}
                  onChange={(e) =>
                    updateMapSetting({
                      ...AdcMapinfo,
                      display_map: { ...AdcMapinfo.display_map, min: e },
                    })
                  }
                />
                <span className="margin-lr">{MSG_STILDE}</span>
                <InputNumber
                  min={AdcMapinfo?.display_map?.min ?? 1}
                  max={AdcMapinfo?.display_map?.max ?? 999}
                  defaultValue={AdcMapinfo?.display_map?.max ?? 1}
                  onChange={(e) =>
                    updateMapSetting({
                      ...AdcMapinfo,
                      display_map: { ...AdcMapinfo.display_map, max: e },
                    })
                  }
                />
              </div>
            </div>
            <div css={SG.contentItemStyle} className="etc">
              <span className="label">{MSG_NUMBER_OF_COLUMNS}</span>
              <InputNumber
                min={1}
                max={AdcMapinfo?.display_map?.max ?? 999}
                value={AdcMapinfo?.column_num ?? 5}
                onChange={(e) =>
                  updateMapSetting({ ...AdcMapinfo, column_num: e })
                }
              />
            </div>
            <div css={SG.contentItemStyle} className="etc">
              <span className="label">{MSG_SHOW_EXTRA_INFO}</span>
              <Switch
                checked={AdcMapinfo?.show_extra_info ?? false}
                onChange={(e) =>
                  updateMapSetting({ ...AdcMapinfo, show_extra_info: e })
                }
              />
            </div>
          </div>
          <div css={[BlockWrapper, { marginLeft: '10px' }]}>
            {' '}
            {/*right*/}
            <div css={SG.contentItemStyle} className="etc">
              <span className="label">{MSG_DIV}</span>
              <div className="tx-right">
                <span className="margin-r">{MSG_UPPER_ROW}</span>
                <InputNumber
                  style={{ width: '40%' }}
                  value={AdcMapinfo?.div?.div_upper ?? ''}
                  onChange={(e) =>
                    updateMapSetting({
                      ...AdcMapinfo,
                      div: { ...AdcMapinfo.div, div_upper: e },
                    })
                  }
                />
              </div>
            </div>
            <div css={SG.contentItemStyle} className="etc">
              <span className="label">{MSG_PLATE_SIZE}</span>
              <div className="tx-right">
                <span className="margin-r">{MSG_SIZE_X}</span>
                <InputNumber
                  style={{ width: '30%' }}
                  value={AdcMapinfo?.plate_size?.size_x ?? ''}
                  onChange={(e) =>
                    updateMapSetting({
                      ...AdcMapinfo,
                      plate_size: { ...AdcMapinfo.plate_size, size_x: e },
                    })
                  }
                />
                <span className="margin-lr">{MSG_SIZE_Y}</span>
                <InputNumber
                  style={{ width: '30%' }}
                  value={AdcMapinfo?.plate_size?.size_y ?? ''}
                  onChange={(e) =>
                    updateMapSetting({
                      ...AdcMapinfo,
                      plate_size: { ...AdcMapinfo.plate_size, size_y: e },
                    })
                  }
                />
              </div>
            </div>
            <div css={SG.contentItemStyle} className="etc">
              <Button
                type="dashed"
                shape="round"
                disabled={!ApplyButtonEnable}
                onClick={() => {
                  updateEtcSetting(true);
                  updateMutation.mutate({ obj: AdcMapinfo, fab_name });
                }}
                loading={isEtcUpdating}
              >
                {''} {MSG_APPLY}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </CustomAccordion>
  );
};
EtcSetting.propTypes = {
  mode: PropTypes.string,
};

export default EtcSetting;
