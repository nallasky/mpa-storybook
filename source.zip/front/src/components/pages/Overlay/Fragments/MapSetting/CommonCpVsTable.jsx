import React from 'react';
import { Input, Select } from 'antd';
import * as SG from '../styleGroup';

const CommonCpVsTable = () => {
  return (
    <div className="table-wrapper">
      <table css={SG.tableStyle}>
        <thead>
          <tr>
            <th>SHOT</th>
            <th>CP1</th>
            <th>CP2</th>
            <th>CP3</th>
            <th>VS1</th>
            <th>VS2</th>
            <th>VS3</th>
            <th>DISPLAY</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Job1</Select.Option>
                <Select.Option value="2">Job2</Select.Option>
              </Select>
            </td>
          </tr>
          <tr>
            <td>2</td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Job1</Select.Option>
                <Select.Option value="2">Job2</Select.Option>
              </Select>
            </td>
          </tr>
          <tr>
            <td>3</td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Job1</Select.Option>
                <Select.Option value="2">Job2</Select.Option>
              </Select>
            </td>
          </tr>
          <tr>
            <td>4</td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Input type="text" />
            </td>
            <td>
              <Select defaultValue="1" style={{ width: '100%' }}>
                <Select.Option value="1">Job1</Select.Option>
                <Select.Option value="2">Job2</Select.Option>
              </Select>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default CommonCpVsTable;