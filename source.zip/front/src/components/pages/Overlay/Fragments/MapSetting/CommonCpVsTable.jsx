import React from 'react';
import { Input, Select } from 'antd';
import * as SG from '../styleGroup';
import {
  CP_VS_DISPLAY_LIST,
  CPVS_MODE as Mode,
} from '../../../../../lib/api/Define/OverlayDefault';
import useOverlayResult from '../../../../../hooks/useOverlayResultInfo';
import PropTypes from 'prop-types';
import { OVERLAY_ADC_CATEGORY } from "../../../../../lib/api/Define/etc";

const CpVsColumn = ({ shotN, shotInfo, changeEvent }) => {
  const { gAdcMeasurementCPVS: adc_cp_vs, gMap } = useOverlayResult();
  const ChangeFunc = (key, value) => {
    changeEvent({ shot: shotN, info: { ...shotInfo, [key]: value } });
  };
  return (
    <tr>
      <td style={{ minWidth: '70px' }}>Shot {shotN}:</td>
      {Object.keys(shotInfo).map((o) => (
        <>
          <td>
            {o === 'display' ? (
              <>
                <Select
                  style={{ minWidth: '100px' }}
                  disabled={adc_cp_vs.expo_mode !== 30}
                  value={shotInfo[o]}
                  onChange={(v) => ChangeFunc(o, v)}
                >
                  {CP_VS_DISPLAY_LIST.map((item, j) => (
                    <>
                      <Select.Option value={item} key={j}>
                        {item}
                      </Select.Option>
                    </>
                  ))}
                </Select>
              </>
            ) : (
              <Input
                value={gMap.cp_vs.mode === Mode.FROM_LOG ? '' : shotInfo[o]}
                onChange={(v) => ChangeFunc(o, v.target.value)}
                disabled={
                  gMap.cp_vs.mode === Mode.FROM_LOG ||
                  (gMap.cp_vs.mode === Mode.SAME &&
                    parseInt(shotN) !== adc_cp_vs.shot[0])
                }
              />
            )}
          </td>
        </>
      ))}
    </tr>
  );
};
CpVsColumn.propTypes = {
  shotN: PropTypes.string,
  shotInfo: PropTypes.object,
  changeEvent: PropTypes.func,
};
const CommonCpVsTable = ({ mode }) => {
  const {
    gAdcMeasurementCPVS: cp_vs,
    gMap,
    updateMapSetting,
  } = useOverlayResult();
  const changeEvent = (e) => {
    if(mode === OVERLAY_ADC_CATEGORY){
      updateMapSetting({
        ...gMap,
        cp_vs: {
          ...gMap.cp_vs,
          shots: { ...gMap.cp_vs.shots, [e.shot]: e.info },
        },
      });
    }
  };
  return (
    <div className="table-wrapper">
      <table css={SG.tableStyle}>
        <thead>
          <tr>
            <th>{'SHOT'}</th>
            {Object.keys(cp_vs?.default ?? {})?.map((o) => (
              <>
                <th>{o.toUpperCase()}</th>
              </>
            ))}
          </tr>
        </thead>
        <tbody>
          {Object.entries(gMap?.cp_vs?.shots ?? {})?.map((shot) => {
            return (
              <>
                <CpVsColumn
                  changeEvent={changeEvent}
                  shotInfo={shot[1]}
                  shotN={shot[0]}
                />
              </>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
CommonCpVsTable.propTypes = {
  mode: PropTypes.string,
};

export default CommonCpVsTable;
