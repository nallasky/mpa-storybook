import React from 'react';
import { Button, Upload } from "antd";
import * as SG from '../styleGroup';
import { UploadOutlined } from "@ant-design/icons";

const JobFileUpload = () => {

  return (
    <div css={SG.contentItemStyle} className="column-3">
      <span className="label">Job data file</span>
      <Upload>
        <Button icon={<UploadOutlined />}>Load</Button>
      </Upload>
    </div>
  );
};

export default JobFileUpload;
