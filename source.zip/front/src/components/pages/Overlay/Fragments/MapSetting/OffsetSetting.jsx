import React from 'react';
import { Input } from 'antd';
import * as SG from '../styleGroup';
import CustomAccordion from '../../../../UI/molecules/CustomAccordion/CustomAccodion';

const OffsetSetting = () => {
  return (
    <CustomAccordion title="Offset X/Y" defaultValue={false}>
      <div css={SG.settingContentStyle}>
        <div className="content">
          <div css={SG.contentItemStyle} className="column-3">
            <div className="switch-wrapper" />
            <span className="title">Offset X</span>
            <span className="title">Offset Y</span>
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 1</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 2</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 3</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 4</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 5</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
          <div css={SG.contentItemStyle} className="column-3">
            <span className="label">Shot 6</span>
            <Input placeholder="Offset X" />
            <Input placeholder="Offset Y" />
          </div>
        </div>
      </div>
    </CustomAccordion>
  );
};

export default OffsetSetting;
