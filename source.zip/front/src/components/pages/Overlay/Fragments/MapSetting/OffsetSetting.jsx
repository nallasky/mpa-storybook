import React from 'react';
import { Button, Input, Switch } from 'antd';
import * as SG from '../styleGroup';
import CustomAccordion from '../../../../UI/molecules/CustomAccordion/CustomAccodion';
import PropTypes from 'prop-types';
import useOverlaySettingInfo from '../../../../../hooks/useOverlaySettingInfo';
import {
  MSG_OFFSET_X,
  MSG_OFFSET_XY,
  MSG_OFFSET_Y,
} from '../../../../../lib/api/Define/Message';
import { E_OVERLAY_MAP, OVERLAY_ADC_CATEGORY } from "../../../../../lib/api/Define/etc";
import useOverlayResult from '../../../../../hooks/useOverlayResultInfo';
import { getParseData } from '../../../../../lib/util/Util';

const OffsetSetting = ({ mode, type }) => {
  const { gMap, updateMapSetting } = useOverlayResult();
  const { adcCommonInfo, correctionCommonInfo } = useOverlaySettingInfo();
  const offset_data =
    (type === E_OVERLAY_MAP ? gMap : correctionCommonInfo)?.offset ?? {};

  const onChangeFunc = (e) => {
    const data = getParseData(e);
    if (data.id === 'mode') {
      updateMapSetting({ ...gMap, offset: { ...gMap.offset, ...e } });
    } else {
      updateMapSetting({
        ...gMap,
        offset: {
          ...gMap.offset,
          info: {
            ...gMap.offset.info,
            [data.id]: { ...gMap.offset.info[data.id], ...data.value },
          },
        },
      });
    }
  };
  const resetOffset = () => {
    updateMapSetting({
      ...gMap,
      offset: {
        ...gMap.offset,
        info: adcCommonInfo?.origin?.offset ?? {},
      },
    });
  };

  return (
    <CustomAccordion title={MSG_OFFSET_XY} defaultValue={true}>
      <div css={SG.settingContentStyle}>
        <div className="content">
          <div css={SG.contentItemStyle} className="column-3">
            <div
              className="switch-wrapper"
              style={{
                display: 'inline-flex',
                flexDirection: 'column',
                width: '80px',
              }}
            >
              <Switch
                checkedChildren={'auto'}
                unCheckedChildren={'Manual'}
                checked={offset_data?.mode === 'auto'}
                onChange={(e) =>
                  onChangeFunc({ mode: e === true ? 'auto' : 'manual' })
                }
                style={{ marginBottom: '5px' }}
              />
              <Button
                type="dashed"
                size="small"
                shape="round"
                disabled={offset_data?.mode === 'auto'}
                style={{ height: '21px', fontWeight: '600' }}
                onClick={resetOffset}
              >
                {'RESET'}
              </Button>
            </div>
            <span className="title">{MSG_OFFSET_X}</span>
            <span className="title">{MSG_OFFSET_Y}</span>
          </div>
          {(mode === OVERLAY_ADC_CATEGORY
            ? adcCommonInfo
            : correctionCommonInfo
          ).shot.map((shotN) => (
            <>
              <div css={SG.contentItemStyle} className="column-3">
                <span className="label">{`Shot ${shotN}`}</span>
                <Input
                  placeholder="Offset X"
                  value={offset_data?.info?.[shotN]?.x ?? ''}
                  onChange={(e) =>
                    onChangeFunc({ [shotN]: { x: e.target.value } })
                  }
                  disabled={offset_data?.mode === 'auto'}
                />
                <Input
                  placeholder="Offset Y"
                  value={offset_data?.info?.[shotN]?.y ?? ''}
                  onChange={(e) =>
                    onChangeFunc({ [shotN]: { y: e.target.value } })
                  }
                  disabled={offset_data?.mode === 'auto'}
                />
              </div>
            </>
          ))}
        </div>
      </div>
    </CustomAccordion>
  );
};
OffsetSetting.propTypes = {
  mode: PropTypes.string,
  type: PropTypes.string,
};

export default OffsetSetting;
