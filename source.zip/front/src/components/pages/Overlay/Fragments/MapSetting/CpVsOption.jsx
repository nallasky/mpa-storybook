import React, { useMemo, useState } from 'react';
import { Button, Input, Popconfirm, Radio, Select, Spin } from 'antd';
import * as SG from '../styleGroup';
import {
  MSG_CP_VS,
  MSG_CP_VS_EACH_SHOT,
  MSG_CP_VS_FROM_LOG,
  MSG_CP_VS_SHOT1_SAME,
  MSG_DEFAULT,
  MSG_NEW_PRESET,
  MSG_PRESET,
  MSG_SAVE_PRESET,
  MSG_UPDATE_PRESET,
} from '../../../../../lib/api/Define/Message';
import useOverlayResultInfo from '../../../../../hooks/useOverlayResultInfo';
import {
  CPVS_MODE,
  CPVS_MODE as Mode,
} from '../../../../../lib/api/Define/OverlayDefault';
import { useMutation, useQuery } from 'react-query';
import { QUERY_KEY } from '../../../../../lib/api/Define/QueryKey';
import {
  add_Overlay_preset_info,
  delete_Overlay_preset_info,
  get_Overlay_preset_Info,
  update_Overlay_preset_info,
} from '../../../../../lib/api/axios/useOverlayRequest';
import {
  E_Default,
  E_New,
  OVERLAY_ADC_CATEGORY,
} from '../../../../../lib/api/Define/etc';
import { DeleteOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';
import { NotificationBox } from '../../../../UI/molecules/NotificationBox';

const { Option } = Select;

const CpVsOption = ({ mode }) => {
  const {
    gMap,
    gAdcMeasurementCPVS: CP_VS,
    updateMapSetting,
    gAdcMeasurementFabName: fab_name,
  } = useOverlayResultInfo();
  const defaultShotInfo = useMemo(
    () =>
      CP_VS?.shot?.reduce(
        (acc, o) =>
          Object.assign(acc, {
            [o]: CP_VS?.default,
          }),
        {},
      ),
    [CP_VS.shot, CP_VS.default],
  );
  const [loading, setLoading] = useState({ mode: undefined, status: false });
  const [preset, setPreset] = useState({ id: E_Default, title: E_Default });

  const updateShotAndPresetInfo = (info) => {
    updateMapSetting({
      ...gMap,
      cp_vs: {
        ...gMap.cp_vs,
        mode: info?.mode ?? gMap.cp_vs.mode,
        shots: info?.shot ?? gMap.cp_vs.shots,
        preset: info?.preset ?? gMap.cp_vs.preset,
      },
    });
  };
  const updatePresetInfo = ({ preset }) => {
    updateShotAndPresetInfo({ preset });
  };
  const updateShotInfo = ({ mode, shot }) => {
    updateShotAndPresetInfo({ mode, shot });
  };
  const ChangeEvent = (e) => {
    if (mode === OVERLAY_ADC_CATEGORY) {
      updateShotInfo({ mode: e.target.value });
    }
  };
  useQuery(
    [QUERY_KEY.OVERLAY_PRESET_GET, preset.id],
    () => get_Overlay_preset_Info({ mode, id: preset.id }),
    {
      enabled:
        ![E_Default, E_New].includes(preset.id) &&
        loading.mode === 'get' &&
        loading.status,
      onSuccess: (info) => {
        if (mode === OVERLAY_ADC_CATEGORY) {
          updateShotInfo({ mode: info.mode, shot: info?.step ?? info.shot });
        }
      },
      onError: (error) => {
        NotificationBox('ERROR', error.message, 0);
      },
      onSettled: () => {
        setLoading({ mode: undefined, status: false });
      },
    },
  );
  const addMutation = useMutation(
    [QUERY_KEY.OVERLAY_PRESET_ADD],
    add_Overlay_preset_info,
    {
      onSuccess: (info) => {
        if (mode === OVERLAY_ADC_CATEGORY) {
          updatePresetInfo({
            preset: { ...gMap.cp_vs.preset, [info]: preset.title },
          });
        }
        setPreset((prev) => ({ ...prev, id: info }));
      },
      onSettled: () => {
        setLoading({ mode: undefined, status: false });
      },
    },
  );
  const updateMutation = useMutation(
    [QUERY_KEY.OVERLAY_PRESET_UPDATE],
    update_Overlay_preset_info,
    {
      onSuccess: () => {
        if (mode === OVERLAY_ADC_CATEGORY) {
          updatePresetInfo({
            preset: { ...gMap.cp_vs.preset, [preset.id]: preset.title },
          });
        }
      },
      onSettled: () => {
        setLoading({ mode: undefined, status: false });
      },
    },
  );
  const deleteMutation = useMutation(
    [QUERY_KEY.OVERLAY_PRESET_DELETE],
    delete_Overlay_preset_info,
    {
      onSuccess: ({ id }) => {
        if (mode === OVERLAY_ADC_CATEGORY) {
          const clone = { ...gMap.cp_vs.preset };
          delete clone[id];
          updatePresetInfo({ preset: clone });
          updateShotAndPresetInfo({
            preset: clone,
            mode: CPVS_MODE.FROM_LOG,
            shot: defaultShotInfo,
          });
        }
        setPreset({ title: E_Default, id: E_Default });
      },
      onSettled: () => {
        setLoading({ mode: undefined, status: false });
      },
    },
  );

  const savePreset = () => {
    setLoading({ mode: 'add/update', status: true });
    if (preset.id === E_New) {
      addMutation.mutate({
        preset: { name: preset.title, fab_nm: fab_name, mode: gMap.cp_vs.mode },
        shots: gMap.cp_vs.shots,
        mode,
      });
    } else {
      updateMutation.mutate({
        preset: { name: preset.title, mode: gMap.cp_vs.mode },
        shots: gMap.cp_vs.shots,
        mode,
        preset_id: preset.id,
      });
    }
  };
  const deletePreset = (id) => {
    setLoading({ mode: 'delete', status: true });
    deleteMutation.mutate({ id, mode });
  };

  const selectPreset = (id) => {
    if ([E_Default, E_New].includes(id)) {
      setPreset({ id: id, title: id === E_Default ? E_Default : '' });
      if (id === E_Default) {
        updateShotInfo({ mode: CPVS_MODE.FROM_LOG, shot: defaultShotInfo });
      }
    } else {
      setPreset({ id: id, title: gMap.cp_vs.preset[id] });
      setLoading({ mode: 'get', status: true });
    }
  };

  return (
    <>
      <Spin tip="Loading..." spinning={loading.status}>
        <div
          css={SG.contentItemStyle}
          className="column-3"
          style={{ paddingBottom: '10px' }}
        >
          <span className="label">{MSG_PRESET}</span>
          <Select
            style={{ width: '100%' }}
            onChange={(v) => selectPreset(v)}
            value={preset.id}
          >
            <Option value={E_Default}>{MSG_DEFAULT}</Option>;
            {Object.entries(gMap?.cp_vs?.preset ?? {}).map(([id, title]) => (
              <>
                <Option value={id}>
                  {' '}
                  {title}
                  <Popconfirm
                    title={`Are you sure to delete Preset [${title}] ? `}
                    onConfirm={(e) => {
                      e.stopPropagation();
                      deletePreset(id);
                    }}
                  >
                    <Button
                      type="text"
                      icon={<DeleteOutlined />}
                      style={{ float: 'right' }}
                      onClick={(e) => e.stopPropagation()}
                    />
                  </Popconfirm>
                </Option>
              </>
            ))}
            <Option value={E_New}>{MSG_NEW_PRESET}</Option>;
          </Select>
          <div className="preset-setting">
            <Input
              placeholder="Enter preset name."
              value={preset.title}
              disabled={preset.id === E_Default}
              onChange={(e) => setPreset({ ...preset, title: e.target.value })}
            />
            <button
              css={SG.antdButtonStyle}
              className="blue"
              onClick={savePreset}
              disabled={preset.id === E_Default}
            >
              {[E_Default, E_New].includes(preset.id)
                ? MSG_SAVE_PRESET
                : MSG_UPDATE_PRESET}
            </button>
          </div>
        </div>
      </Spin>
      <div css={SG.contentItemStyle} className="column-3">
        <span className="label">{MSG_CP_VS}</span>
        <Radio.Group
          value={gMap?.cp_vs?.mode ?? Mode.FROM_LOG}
          className="radio-cp-vs"
          onChange={(e) => ChangeEvent(e)}
        >
          <Radio value={Mode.FROM_LOG} disabled={CP_VS.included === false}>
            {MSG_CP_VS_FROM_LOG}
          </Radio>
          <Radio value={Mode.EACH}>{MSG_CP_VS_EACH_SHOT}</Radio>
          <Radio value={Mode.SAME}>{MSG_CP_VS_SHOT1_SAME}</Radio>
        </Radio.Group>
      </div>
    </>
  );
};
CpVsOption.propTypes = {
  mode: PropTypes.string,
};
export default CpVsOption;
