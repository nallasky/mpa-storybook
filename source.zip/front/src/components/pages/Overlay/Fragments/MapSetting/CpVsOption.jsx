import React from 'react';
import { Input, Radio, Select } from 'antd';
import * as SG from '../styleGroup';

const CpVsOption = () => {
  return (
    <>
      <div css={SG.contentItemStyle} className="column-3">
        <span className="label">Preset</span>
        <Select defaultValue="1" style={{ width: '100%' }}>
          <Select.Option value="1">Job1</Select.Option>
          <Select.Option value="2">Job2</Select.Option>
        </Select>
        <div className="preset-setting">
          <Input placeholder="Enter preset name." />
          <button css={SG.antdButtonStyle} className="blue">
            Save Preset
          </button>
        </div>
      </div>
      <div css={SG.contentItemStyle} className="column-3">
        <span className="label">CP/VS</span>
        <Radio.Group value="1" className="radio-cp-vs">
          <Radio value="1">Set CP/VS for each shot</Radio>
          <Radio value="2">Reflect the CP/VS of shot1 on all shots</Radio>
        </Radio.Group>
      </div>
    </>
  );
};

export default CpVsOption;
