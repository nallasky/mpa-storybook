import React, { useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { Table } from 'antd';
import { css } from '@emotion/react';
import { getTableForm } from '../../../../../lib/util/Util';
const tableWrapper = css`
  display: contents;
`;

const AnovaTable = ({ origin, selected }) => {
  const getTableFuc = useCallback((data) => {
    const data_value = Object.values(data);
    const disp_order = Object.keys(data_value?.[0] ?? {});
    const row = Object.keys(data).map((key, i) => ({
      ...data_value[i],
      ADC: key,
    }));
    return getTableForm({
      info: { disp_order: ['ADC'].concat(disp_order), row: row } ?? {},
    });
  }, []);
  const tableData = useMemo(() => getTableFuc(origin?.[selected]), [
    [selected, origin, getTableFuc],
  ]);

  return (
    <>
      <div css={tableWrapper}>
        <Table
          bordered
          pagination={false}
          columns={tableData.columns ?? []}
          dataSource={tableData.dataSource ?? []}
          size="middle"
          rowKey="key"
          scroll={{ x: 'max-content' }}
        />
      </div>
    </>
  );
};
AnovaTable.propTypes = {
  origin: PropTypes.object,
  selected: PropTypes.string,
};

export default AnovaTable;
