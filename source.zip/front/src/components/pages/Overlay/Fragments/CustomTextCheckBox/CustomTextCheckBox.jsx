import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';

const CustomTextCheckBox = ({
  value,
  isChecked,
  id,
  useText,
  label,
  onText,
  offText,
}) => {
  const [checked, setChecked] = useState(isChecked);
  const [textVal, setTextVal] = useState(value);

  useEffect(() => {
    if (useText) {
      setTextVal(value);
    }
  }, [value]);

  useEffect(() => {
    setChecked(isChecked);
  }, [isChecked]);

  return !useText ? (
    <label htmlFor={id} className="only-checkbox">
      <input
        type="checkbox"
        id={id}
        checked={checked}
        onChange={() => setChecked(!checked)}
      />
      <div>{label}</div>
      <div className="mode-slider-wrapper">
        <div className="slider">
          <span>{offText}</span>
          <span>{onText}</span>
        </div>
      </div>
    </label>
  ) : (
    <div className="text-checkbox">
      <input
        type="text"
        value={textVal}
        onChange={(e) => setTextVal(e.target.value)}
        readOnly={!checked}
      />
      <label htmlFor={id}>
        <input
          type="checkbox"
          id={id}
          checked={checked}
          onChange={() => setChecked(!checked)}
        />
        <div className="svg-wrapper">
          <svg viewBox="0 1 21 21">
            <polyline points="5 10.75 8.5 14.25 14 7.8" />
          </svg>
        </div>
      </label>
    </div>
  );
};
CustomTextCheckBox.propTypes = {
  value: PropTypes.string,
  isChecked: PropTypes.bool,
  id: PropTypes.string.isRequired,
  useText: PropTypes.bool,
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  onText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  offText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
CustomTextCheckBox.defaultProps = {
  value: '',
  isChecked: false,
  useText: false,
  onText: 'on',
  offText: 'off',
};

export default CustomTextCheckBox;
