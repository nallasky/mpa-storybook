import { useRef, useEffect } from 'react';
import Plotly from 'plotly.js-dist';

const filterAxisData = (rows, key, xKey) => {
  let result = {
    x: [],
    main: [],
  };

  const checkData = (d, k) => {
    return (
      (d['No.'] === undefined || d['No.'] !== 'ALL') &&
      (d['period'] === undefined || d['period'] !== 'NaT') &&
      (d['log_time'] === undefined || d['log_time'] !== 'NaT') &&
      d[k]
    );
  };

  Object.keys(rows).reduce((acc, v) => {
    if (checkData(rows[v], key)) {
      acc.main = [...acc.main, rows[v][key]];
      acc.x = [...acc.x, rows[v][xKey]];
    }
    return acc;
  }, result);

  return result;
};

export const createAxisData = (rows, keys, type, isMulti) => {
  const tmpYObj = {};
  let tmpXarr = [],
    tmpZarr = [],
    newRows = {};

  if (type === 'step' && isMulti) {
    rows.forEach((v) => {
      const newKey = Object.keys(v)[0];
      newRows[newKey] = v[newKey];
    });
  } else {
    newRows = rows;
  }

  if (keys.y.length > 0 && Object.keys(newRows).length > 0) {
    keys.y.reduce((acc, v) => {
      const key = Array.isArray(v) ? v[1] : v;
      const accKey = Array.isArray(v) ? v.join('_') : key;
      const { x, main } = filterAxisData(
        isMulti ? newRows[v[0]] : newRows,
        key,
        keys.x,
      );

      acc[accKey] = main;
      tmpXarr = [...tmpXarr, ...x];
      return acc;
    }, tmpYObj);
  }

  if (Array.isArray(keys.z)) {
    if (keys.z.length !== 1) {
      const { x, main } = filterAxisData(newRows[keys.z[0]], keys.z[1], keys.x);
      tmpZarr = main;
      tmpXarr = [...tmpXarr, ...x];
    }
  } else {
    if (
      keys.z !== '0' &&
      keys.z !== '' &&
      keys.z !== null &&
      Object.keys(newRows).length > 0
    ) {
      const { x, main } = filterAxisData(newRows, keys.z, keys.x);
      tmpZarr = main;
      tmpXarr = [...tmpXarr, ...x];
    }
  }

  return {
    xaxisData: tmpXarr,
    yaxisData: tmpYObj,
    zaxisData: tmpZarr,
  };
};

export const drawGraph = (rows, item, ref, type, index) => {
  const currentInfo = ref.graph_list.find((v) => v.name === item.type[0]);
  const currentScript = ref.function_graph_type.find((x) => {
    return currentInfo.type === 'user'
      ? x.name === currentInfo.name
      : x.type === currentInfo.type;
  }).script;
  const newFunc = new Function('return ' + currentScript)();
  const { xaxisData, yaxisData, zaxisData } = createAxisData(
    rows,
    {
      x: item.x_axis,
      y: item.y_axis,
      z: item.z_axis,
    },
    type,
    Array.isArray(item.y_axis[0]),
  );

  const params = {
    type: item.type,
    x: xaxisData,
    y: yaxisData,
    z: zaxisData,
    title: item.title,
    range: {
      x: item.x_range_min !== '' ? [item.x_range_min, item.x_range_max] : [],
      y: item.y_range_min !== '' ? [item.y_range_min, item.y_range_max] : [],
      z: item.z_range_min !== '' ? [item.z_range_min, item.z_range_max] : [],
    },
  };
  newFunc(Plotly, document.getElementById(`${type}_graph_${index}`), params);
};

export const usePrevious = (v) => {
  const ref = useRef();

  useEffect(() => {
    ref.current = v;
  });

  return ref.current;
};
