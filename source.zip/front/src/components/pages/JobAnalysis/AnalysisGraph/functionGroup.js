import Plotly from 'plotly.js-dist';

const filterAxisData = (rows, key, type, isMulti) => {
  const arr = [];

  const checkData = (d, k) => {
    return (
      (d['No.'] === undefined || d['No.'] !== 'ALL') &&
      (d['period'] === undefined || d['period'] !== 'NaT') &&
      (d['log_time'] === undefined || d['log_time'] !== 'NaT') &&
      d[k]
    );
  };

  if (type === 'step') {
    const getReduceValue = (rows, key_name, key, array) => {
      const result = Object.values(rows).reduce((acc, v) => {
        if (checkData(v, key)) {
          acc.push(v[key]);
        }
        return acc;
      }, array);
      return key_name === undefined ? result : { [key_name]: result };
    };
    if (key ?? false) {
      if (Array.isArray(rows)) {
        Array.isArray(key)
          ? rows.map((row) =>
              getReduceValue(row?.[key[0]] ?? row, key.join('/'), key[1], arr),
            )
          : rows.map((row) =>
              Object.entries(row).forEach(([i, j]) =>
                getReduceValue(j, `${i}/${j}`, key, arr),
              ),
            );
      } else {
        getReduceValue(rows, undefined, key, arr);
      }
    }
  } else {
    if (isMulti) {
      Object.values(rows).forEach((v) => {
        Object.values(v).reduce((acc, x) => {
          if (checkData(x, key)) {
            acc.push(x[key]);
          }
          return acc;
        }, arr);
      });
    } else {
      Object.values(rows).reduce((acc, v) => {
        if (checkData(v, key)) {
          acc.push(v[key]);
        }
        return acc;
      }, arr);
      console.log('gtpark arr', arr);
    }
  }

  return arr;
};

export const createAxisData = (rows, keys, type, isMulti) => {
  const tmpYObj = {};
  let tmpZarr = [];

  if (keys.y.length > 0 && Object.keys(rows).length > 0) {
    keys.y.reduce((acc, v) => {
      const key = Array.isArray(v) ? v[1] : v;
      acc[key] = filterAxisData(rows, key, type, isMulti);
      return acc;
    }, tmpYObj);
  }

  if (Array.isArray(keys.z)) {
    tmpZarr =
      keys.z.length === 1 ? [] : filterAxisData(rows, keys.z[1], type, isMulti);
  } else {
    tmpZarr =
      keys.z !== '0' &&
      keys.z !== '' &&
      keys.z !== null &&
      Object.keys(rows).length > 0
        ? filterAxisData(rows, keys.z, type, isMulti)
        : [];
  }

  return {
    xaxisData:
      keys.x !== '0' &&
      keys.x !== '' &&
      keys.x !== null &&
      Object.keys(rows).length > 0
        ? filterAxisData(rows, keys.x, type, isMulti)
        : [],
    yaxisData: tmpYObj,
    zaxisData: tmpZarr,
  };
};

export const drawGraph = (rows, items, ref, type) => {
  items.forEach((v, i) => {
    const currentInfo = ref.graph_list.find((z) => z.name === v.type[0]);
    const currentScript = ref.function_graph_type.find((x) => {
      return currentInfo.type === 'user'
        ? x.name === currentInfo.name
        : x.type === currentInfo.type;
    }).script;
    const newFunc = new Function('return ' + currentScript)();
    const { xaxisData, yaxisData, zaxisData } = createAxisData(
      rows,
      {
        x: v.x_axis,
        y: v.y_axis,
        z: v.z_axis,
      },
      type,
      Array.isArray(v.y_axis[0]),
    );

    const params = {
      type: v.type,
      x: xaxisData,
      y: yaxisData,
      z: zaxisData,
      title: v.title,
      range: {
        x: v.x_range_min !== '' ? [v.x_range_min, v.x_range_max] : [],
        y: v.y_range_min !== '' ? [v.y_range_min, v.y_range_max] : [],
        z: v.z_range_min !== '' ? [v.z_range_min, v.z_range_max] : [],
      },
    };
    newFunc(Plotly, document.getElementById(`${type}_graph_${i}`), params);
  });
};
