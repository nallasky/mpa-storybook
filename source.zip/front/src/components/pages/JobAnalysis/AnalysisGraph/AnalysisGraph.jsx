import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Empty, Popconfirm } from 'antd';
import {
  CloseCircleFilled,
  LineChartOutlined,
  SettingFilled,
} from '@ant-design/icons';
import { drawGraph } from './functionGroup';
import GraphAddEdit from '../../../UI/organisms/GraphAddEdit/GraphAddEdit';
import useModal from '../../../../lib/util/modalControl/useModal';
import useResultInfo from '../../../../hooks/useResultInfo';
import * as sg from './styleGroup';

const AnalysisGraph = React.memo(({ rows, info, type }) => {
  const { openModal } = useModal();
  const {
    visualization,
    analysisGraphInfo,
    originalGraphInfo,
    setAnalysisGraphInfo,
    setOriginalGraphInfo,
  } = useResultInfo();

  const handleClick = (idx, mode) => {
    openModal(GraphAddEdit, {
      isOpen: true,
      mode: mode,
      index: idx,
      type: type,
    });
  };

  const onDelete = (idx) => {
    if (type === 'analysis') {
      setAnalysisGraphInfo(
        analysisGraphInfo.filter((v, i) => {
          return i !== idx;
        }),
      );
    } else {
      setOriginalGraphInfo(
        originalGraphInfo.filter((v, i) => {
          return i !== idx;
        }),
      );
    }
  };

  useEffect(() => {
    if (info.length > 0 && Object.keys(rows).length > 0) {
      drawGraph(rows, info, visualization, type);
    }
  }, [rows, info]);

  if (Object.keys(rows).length === 0) return '';

  return (
    <>
      <div css={sg.mainWrapper}>
        <div>
          <span>Visualization</span>
          <Button
            type="dashed"
            icon={<LineChartOutlined />}
            onClick={() => handleClick(null, 'add')}
          >
            Add Graph
          </Button>
        </div>
        <div>
          <div css={info.length > 0 ? sg.graphBodyStyle : sg.emptyWrapper}>
            {info.length > 0 ? (
              info.map((k, i) => {
                return (
                  <div key={i} css={sg.graphWrapper}>
                    <div>
                      <Button
                        type="dashed"
                        shape="round"
                        icon={<SettingFilled />}
                        onClick={() => handleClick(i, 'edit')}
                      >
                        Edit
                      </Button>
                      <Popconfirm
                        title="Are you sure you want to delete this graph?"
                        onConfirm={() => onDelete(i)}
                      >
                        <Button
                          type="dashed"
                          shape="round"
                          icon={<CloseCircleFilled />}
                        >
                          Delete
                        </Button>
                      </Popconfirm>
                    </div>
                    <div id={`${type}_graph_${i}`} />
                  </div>
                );
              })
            ) : (
              <Empty description="No graphs to display." />
            )}
          </div>
        </div>
      </div>
    </>
  );
});
AnalysisGraph.propTypes = {
  rows: PropTypes.object.isRequired,
  info: PropTypes.array.isRequired,
  type: PropTypes.string,
};
AnalysisGraph.defaultProps = {
  type: 'analysis',
};
AnalysisGraph.displayName = 'AnalysisGraph';

export default AnalysisGraph;
