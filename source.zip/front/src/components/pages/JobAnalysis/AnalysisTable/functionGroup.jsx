import React from 'react';
import { notification, Select } from 'antd';
import dayjs from 'dayjs';

export const createDataSource = (obj) => {
  const tmpArr = [];

  Object.keys(obj).reduce((acc, k, i) => {
    const tmpObj = Object.assign({}, obj[k]);
    tmpObj['key'] = i;
    acc.push(tmpObj);
    return acc;
  }, tmpArr);

  return tmpArr;
};

export const createColumns = (arr) => {
  const tmpArr = [];

  arr.reduce((acc, v) => {
    acc.push({
      Header: v,
      accessor: v,
    });
    return acc;
  }, tmpArr);

  return tmpArr;
};

export const initFilterValue = (arr) => {
  const tmpObj = {};
  if (Array.isArray(arr)) {
    arr.reduce((acc, v) => {
      acc[v.target] =
        v.mode === 'plural'
          ? (Array.isArray(v.selected) && v.selected[0] === null) ||
            v.selected === null
            ? undefined
            : v.selected
          : Array.isArray(v.selected)
          ? v.selected[0]
          : v.selected;
      return acc;
    }, tmpObj);
  }
  return tmpObj;
};

export const filteringData = (orgData, filter) => {
  const tmpArr = [];

  orgData.reduce((acc, v) => {
    let isValid = true;

    Object.keys(filter).forEach((i) => {
      if (isValid) {
        if (Array.isArray(filter[i])) {
          if (filter[i].findIndex((j) => v[i] === j) === -1) {
            isValid = false;
          }
        } else {
          if (filter[i] !== v[i]) {
            isValid = false;
          }
        }
      }
    });

    if (isValid) {
      acc.push(v);
    }
    return acc;
  }, tmpArr);

  return tmpArr;
};

export const createGraphData = (obj, filter) => {
  const tmpObj = {};
  let i = 0;

  Object.keys(obj).reduce((acc, v) => {
    let isValid = true;

    Object.keys(filter).forEach((j) => {
      if (isValid) {
        if (Array.isArray(filter[j])) {
          if (filter[j].findIndex((k) => obj[v][j] === k) === -1) {
            isValid = false;
          }
        } else {
          if (filter[j] !== obj[v][j]) {
            isValid = false;
          }
        }
      }
    });

    if (isValid) {
      acc[i] = obj[v];
      i++;
    }
    return acc;
  }, tmpObj);

  return tmpObj;
};

export const initPeriod = (period) => {
  return period.selected !== undefined && period.selected.length > 0
    ? [
        period.selected[0].length > 0 ? dayjs(period.selected[0]) : '',
        period.selected[1].length > 0 ? dayjs(period.selected[1]) : '',
      ]
    : ['', ''];
};

export const initAggregation = (aggregation) => {
  return aggregation === undefined
    ? {}
    : {
        main: Object.keys(aggregation).length > 0 ? aggregation.selected : '',
        sub:
          Object.keys(aggregation).length > 0
            ? aggregation.selected.toLowerCase().indexOf('all') === -1 &&
              aggregation.selected.length > 0
              ? aggregation.subItem[aggregation.selected].selected
              : ''
            : '',
      };
};

export const initColumnData = (col) => {
  return createColumns(col).map((v) => ({
    ...v,
    onHeaderCell: (c) => {
      return {
        style: {
          minWidth: c.width,
        },
      };
    },
  }));
};

export const displayError = () => {
  const args = {
    message: 'Filter Setting Error',
    description:
      'There are some items that have not been set yet. Please check the item.',
    duration: 3,
    style: { borderLeft: '5px solid red' },
  };

  notification.open(args);
};

export const RenderSelectOptions = (v) => {
  return (
    <Select.Option value={v} key={v}>
      {v}
    </Select.Option>
  );
};
