import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import ReactTable from '../../../UI/atoms/Table/ReactTable';

const AnalysisTableComponent = ({ tableOrder, tableData, selectRow }) => {
  const columnData = useMemo(() => tableOrder, [JSON.stringify(tableOrder)]);
  const rowData = useMemo(() => tableData, [JSON.stringify(tableData)]);

  return (
    <ReactTable
      columns={columnData}
      data={rowData}
      disableSelectRows={!selectRow}
    />
  );
};

AnalysisTableComponent.displayName = 'TableComponent';
AnalysisTableComponent.propTypes = {
  tableOrder: PropTypes.array.isRequired,
  tableData: PropTypes.array.isRequired,
  selectRow: PropTypes.bool.isRequired,
};

export default AnalysisTableComponent;
