import { css } from '@emotion/react';

export const popupBackground = css`
  position: fixed;
  display: none;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
  z-index: 1000;
  background: rgba(0, 0, 0, 0.1);
  outline: none;
`;

export const popupStyle = css`
  position: absolute;
  display: none;
  left: -10px;
  top: 46px;
  z-index: 1000;
  width: 400px;
  background: var(--ckr-gray-1);
  border-radius: 4px;
  box-shadow: 0 3px 6px -4px rgba(0, 0, 0, 0.12),
    0 6px 16px 0 rgba(0, 0, 0, 0.12), 0 9px 28px 8px rgba(0, 0, 0, 0.05);
  font-family: Saira;
  &::before {
    position: absolute;
    transform: rotate(-45deg);
    top: -4px;
    left: 21px;
    width: 10px;
    height: 10px;
    content: '';
    border: 5px solid var(--ckr-gray-4);
    border-color: var(--ckr-gray-1) var(--ckr-gray-1) transparent transparent;
    box-shadow: 2px -2px 6px rgba(0, 0, 0, 0.06);
  }
  &::after {
    position: absolute;
    top: -10px;
    left: 0;
    width: 100%;
    height: 20px;
    content: '';
    background: transparent;
  }
  & > div {
    width: 100%;
    padding: 0.5rem 1rem;
    &:first-of-type {
      font-weight: bold;
      border-bottom: 1px solid var(--ckr-gray-4);
    }
    &:nth-of-type(2) {
      font-size: 12px;
      & > div + div {
        margin-top: 0.5rem;
      }
    }
    &:last-of-type {
      padding-top: 0.3rem;
      text-align: right;
      & > button {
        font-size: 12px;
      }
      & > button + button {
        margin-left: 1rem;
      }
    }
  }
`;

export const selectWrapper = css`
  display: flex;
  align-items: center;
  & > label {
    font-size: 12px;
    margin-left: 0.5rem;
  }
`;

export const aggregationWrapper = css`
  display: flex;
`;

export const aggSingleItemWrapper = css`
  width: 100%;
`;
