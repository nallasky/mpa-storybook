import { css } from '@emotion/react';

export const mainWrapper = css`
  position: relative;
  & .ant-picker-input > input {
    font-size: 12px;
  }
  & > .table-wrapper {
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    border-radius: 8px;
    border: 1px solid #dddddd;
    box-shadow: 0px 2px 2px 0px rgba(0, 0, 0, 0.1);
    margin: 1rem 0;
    & > div {
      &:first-of-type {
        padding: 1rem;
        border-bottom: 1px solid #dddddd;
        background-color: var(--ckr-gray-3);
        border-radius: 8px 8px 0 0;
      }
      &:last-of-type {
        margin: 1rem;
        overflow: auto;
      }
    }
    & .select-wrapper {
      margin-bottom: 1rem;
      & > span {
        font-weight: bold;
      }
    }
  }
  & > .header-wrapper {
    position: relative;
    display: flex;
    justify-content: space-between;
    & > .popup-wrapper {
      display: flex;
      align-items: center;
      column-gap: 0.5rem;
      flex-wrap: nowrap;
      & > span {
        font-weight: bold;
      }
      &.ant-picker {
        margin-left: 0.5rem;
        margin-right: 1rem;
      }
      & > .filter-component {
        position: relative;
        display: inline-block;
        & > button:hover + div:first-of-type {
          display: block;
        }
        & > div:first-of-type {
          position: absolute;
          display: none;
          font-size: 12px;
          color: var(--ckr-gray-1);
          top: 3px;
          right: -90px;
          padding: 4px;
          border-radius: 2px;
          background: rgba(0, 0, 0, 0.65);
          &::after {
            position: absolute;
            content: '';
            border-style: solid;
            border-color: transparent rgba(0, 0, 0, 0.65) transparent
              transparent;
            border-width: 4px;
            top: 9px;
            left: -8px;
          }
        }
      }
    }
  }
`;

export const emptyWrapper = css`
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 463px;
`;
