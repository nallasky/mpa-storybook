import styled from '@emotion/styled';

export const DatabaseBackground = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 500;
`;

export const DatabaseContainer = styled.div`
  position: relative;
  top: 8px;
  left: 0;
  z-index: 501;
  display: flex;
  flex-direction: column;
  width: 400px;
  border-radius: 4px;
  border: 1px solid #dbdbdb;
  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3),
    0 2px 6px 2px rgba(60, 64, 67, 0.15);
  & .ant-spin {
    min-height: auto !important;
  }
  & > .db-popup-header {
    padding: 1rem;
    font-size: 14px;
    font-weight: bold;
    background-color: #efefef;
    border-radius: 4px 4px 0 0;
    border-bottom: 1px solid #c7c7c7;
  }
  & .db-popup-contents {
    padding: 1rem;
    font-size: 12px;
    background-color: var(--ckr-gray-1);
    & > .setting-content {
      & > .form {
        & > p {
          margin-top: 0;
          margin-bottom: 0.25rem;
          color: var(--ckr-blue-6);
          font-weight: bold;
        }
        & > .form-item {
          display: grid;
          grid-template-columns: 25% auto;
          align-items: center;
          row-gap: 0.5rem;
          & > .title-wrapper {
            text-indent: 8px;
            & > .title {
              position: relative;
              &::before {
                position: absolute;
                top: 2px;
                left: -16px;
                content: '*';
                color: red;
                font-size: 12px;
              }
              &::after {
                position: absolute;
                right: -3px;
                content: ':';
              }
            }
          }
          & + .form-item {
            margin-top: 0.5rem;
          }
        }
      }
      & + .setting-content {
        margin-top: 1rem;
      }
    }
  }
  & .db-popup-footer {
    padding: 0 1rem 1rem 1rem;
    text-align: right;
    border-radius: 0 0 4px 4px;
    background-color: var(--ckr-gray-1);
    & > button {
      position: relative;
      font-size: 12px;
      border: 1px solid var(--ckr-gray-6);
      border-radius: 8px;
      background-color: var(--ckr-gray-1);
      padding: 0.5rem 0.75rem;
      box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.25);
      cursor: pointer;
      transition: all 0.1s;
      &:active:not(:disabled) {
        transform: translateY(3px);
        box-shadow: none;
      }
      &:disabled {
        background-color: var(--ckr-gray-4);
        color: var(--ckr-gray-6);
        cursor: not-allowed;
      }
    }
  }
`;
