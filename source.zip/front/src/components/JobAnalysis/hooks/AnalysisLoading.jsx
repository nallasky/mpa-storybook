import React from 'react';
import PropTypes from 'prop-types';
import { Spin } from 'antd';

const AnalysisLoading = ({ state, useCancel, onCancel }) => {
  return (
    state && (
      <>
        <Spin
          size="large"
          tip="Loading..."
          spinning={state}
          className="job-analysis"
        />
        {state && useCancel && (
          <button
            className="button-request-cancel job-analysis"
            onClick={onCancel}
          >
            Cancel
          </button>
        )}
      </>
    )
  );
};
AnalysisLoading.displayName = 'AnalysisLoading';
AnalysisLoading.propTypes = {
  state: PropTypes.bool,
  useCancel: PropTypes.bool,
  onCancel: PropTypes.func,
};

export default AnalysisLoading;
