import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Select, Spin } from 'antd';
import { useLocation } from 'react-router-dom';
import useResultInfo from '../../../hooks/common/useResultInfo';
import { getEquipmentValidDate, getEquipmentList } from '@libs/axios/requests';
import {
  displayNotification,
  RenderSelectOptions,
} from '@libs/util/common/functionGroup';
import { getResource_JobSetting } from '@libs/axios/jobSettingRequest';
import { getRemoteDatabaseInfo } from '@libs/axios/configRequest';
import {
  DatabaseBackground,
  DatabaseContainer,
} from '../styles/useDatabasePopupStyles';

const DatabasePopup = ({ open, closer }) => {
  const { user_fab, time_column, table_name, func_id } = useLocation().state;
  const {
    originalData,
    selectedDatabase,
    selectedEquipment,
    remoteApplyInfo,
    setRemoteApplyInfo,
  } = useResultInfo();
  const [optionInfo, setOptionInfo] = useState({
    database: [],
    tableName: '',
    fab: [],
    equipment: {},
    period: {},
    time_col: '',
  });
  const [database, setDatabase] = useState('');
  const [fab, setFab] = useState('');
  const [equipment, setEquipment] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const changeDatabase = async (v) => {
    setIsLoading(true);
    setDatabase(v);
    try {
      const data = await getEquipmentList({
        db_id: database,
        table_name: optionInfo.tableName,
      });
      setOptionInfo({
        ...optionInfo,
        fab: data.info.user_fab,
        equipment: data.info.equipment_name,
      });
      setFab('');
      setEquipment('');
    } catch (e) {
      displayNotification({
        message: 'Failed to acquire',
        description:
          e.response.data.msg ?? 'Failed to acquire fab/equipment information.',
        duration: 3,
        style: { borderLeft: '5px solid red' },
      });
    } finally {
      setIsLoading(false);
    }
  };

  const changeEquipment = async (v) => {
    setIsLoading(true);
    setEquipment(v);
    try {
      const { info } = await getEquipmentValidDate({
        db_id: database,
        table_name: optionInfo.tableName,
        equipment_name: v,
        time_column: optionInfo.time_col,
      });
      setOptionInfo({ ...optionInfo, period: info });
    } catch (e) {
      displayNotification({
        message: 'Failed to acquire',
        description:
          e.response.data.msg ?? 'Failed to acquire period information.',
        duration: 3,
        style: { borderLeft: '5px solid red' },
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onApply = async () => {
    closer();
    setRemoteApplyInfo({
      ...remoteApplyInfo,
      type: 'db',
      func_id,
      db_id: database,
      equipment_name: equipment,
      period: optionInfo.period,
    });
  };

  useEffect(() => {
    const fetch = async () => {
      const { info } = await getResource_JobSetting({ func_id });
      const dbList = await getRemoteDatabaseInfo();
      return {
        data: info.form.remote,
        dbList,
      };
    };
    if (open) {
      setIsLoading(true);
      fetch()
        .then(({ data, dbList }) => {
          if (data) {
            const fabOption = data.find((v) => v.title.includes('Equipment'))
              .items[0];
            const databaseOptions = dbList.length
              ? dbList.map((v) => ({
                  id: v.id,
                  name: v.name,
                }))
              : [];
            const equipmentOptions = {};
            if (databaseOptions.length) {
              fabOption.options.forEach((v) => {
                equipmentOptions[v] = fabOption.subItem.options.find(
                  (x) => Object.keys(x)[0] === v,
                )[v];
              });
            }
            setOptionInfo({
              database: databaseOptions,
              tableName: table_name,
              fab: databaseOptions.length ? fabOption.options : [],
              equipment: equipmentOptions,
              period: databaseOptions.length
                ? {
                    start: originalData.period.selected[0],
                    end: originalData.period.selected[1],
                  }
                : {},
              time_col: time_column,
            });

            if (databaseOptions.length) {
              if (
                databaseOptions.find((v) => v.id === Number(selectedDatabase))
              ) {
                setDatabase(Number(selectedDatabase));
                if (fabOption.options.length) {
                  if (fabOption.options.find((v) => v === user_fab)) {
                    setFab(user_fab);
                    if (
                      Object.keys(equipmentOptions).length &&
                      Object.keys(equipmentOptions).find((v) => v === user_fab)
                    ) {
                      setEquipment(selectedEquipment);
                    }
                  }
                }
              }
            }
          }
        })
        .catch((e) =>
          displayNotification({
            message: 'Failed to acquire',
            description:
              e.response.data.msg ?? 'Failed to acquire information.',
            duration: 3,
            style: { borderLeft: '5px solid red' },
          }),
        )
        .finally(() => setIsLoading(false));
    }
  }, [open]);

  return (
    open && (
      <>
        <DatabaseBackground onClick={closer} />
        <DatabaseContainer>
          <div className="db-popup-header">Change DB & Equipment</div>
          <Spin spinning={isLoading} tip="Loading...">
            <div className="db-popup-contents">
              <div className="setting-content">
                <div className="form">
                  <p>Select Database</p>
                  <div className="form-item">
                    <div className="title-wrapper">
                      <span className="title">From</span>
                    </div>
                    <Select
                      style={{ width: '100%' }}
                      value={database}
                      onChange={(v) => changeDatabase(v)}
                    >
                      {optionInfo.database.length &&
                        optionInfo.database.map((v) => (
                          <Select.Option key={v.id} value={v.id}>
                            {v.name}
                          </Select.Option>
                        ))}
                    </Select>
                  </div>
                </div>
              </div>
              <div className="setting-content">
                <div className="form">
                  <p>Select Equipment</p>
                  <div className="form-item">
                    <div className="title-wrapper">
                      <span className="title">User/Fab</span>
                    </div>
                    <Select
                      style={{ width: '100%' }}
                      value={fab}
                      onChange={(v) => {
                        setFab(v);
                        setEquipment('');
                      }}
                    >
                      {optionInfo.fab.length &&
                        optionInfo.fab.map(RenderSelectOptions)}
                    </Select>
                  </div>
                  <div className="form-item">
                    <div className="title-wrapper">
                      <span className="title">Equipment</span>
                    </div>
                    <Select
                      style={{ width: '100%' }}
                      value={equipment}
                      onChange={(v) => changeEquipment(v)}
                    >
                      {optionInfo.equipment[fab]?.length &&
                        optionInfo.equipment[fab].map(RenderSelectOptions)}
                    </Select>
                  </div>
                </div>
              </div>
            </div>
            <div className="db-popup-footer">
              <button
                disabled={
                  !database.toString().length ||
                  !fab.length ||
                  !equipment.length
                }
                onClick={onApply}
              >
                Apply
              </button>
            </div>
          </Spin>
        </DatabaseContainer>
      </>
    )
  );
};
DatabasePopup.propTypes = {
  open: PropTypes.bool.isRequired,
  closer: PropTypes.func.isRequired,
};

export default DatabasePopup;
