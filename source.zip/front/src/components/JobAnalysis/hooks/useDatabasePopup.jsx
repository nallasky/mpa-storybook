import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import dayjs from 'dayjs';
import { Select, Spin } from 'antd';
import { useLocation } from 'react-router-dom';
import useResultInfo from '../../../hooks/common/useResultInfo';
import useModal from '../../../libs/util/modalControl/useModal';
import {
  getEquipmentValidDate,
  getRemoteOriginalInfo,
  getEquipmentList,
} from '@libs/axios/requests';
import {
  displayNotification,
  RenderSelectOptions,
  createPageData,
  createGraphItems,
} from '@libs/util/common/functionGroup';
import ProcessingModal from '../../common/organisms/ProcessingModal/ProcessingModal';
import {
  getRequestIdFromJobSetting,
  getResource_JobSetting,
} from '@libs/axios/jobSettingRequest';
import { DATE_FORMAT } from '../../../constants/etc';
import {
  DatabaseBackground,
  DatabaseContainer,
} from '../styles/useDatabasePopupStyles';
import { getDBList } from '@reducers/slices/ConfigurationInfo';

const DatabasePopup = ({ open, closer, id, tabChanger }) => {
  const { user_fab, time_column, table_name } = useLocation().state;
  const {
    analysisData,
    originalData,
    selectedDatabase,
    selectedEquipment,
    setAnalysisInfo,
    setSelectedRow,
    setOriginalFilteredRows,
    setOriginalGraphInfo,
    setOriginalInfo,
    setVisualization,
    setAnalysisGraphInfo,
    setSelectedEquipment,
    setSelectedDatabase,
  } = useResultInfo();
  const dbList = useSelector(getDBList);
  const { openModal, closeModal } = useModal();
  const [optionInfo, setOptionInfo] = useState({
    database: [],
    tableName: '',
    fab: [],
    equipment: {},
    period: {},
    time_col: '',
  });
  const [database, setDatabase] = useState('');
  const [fab, setFab] = useState('');
  const [equipment, setEquipment] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const changeDatabase = async (v) => {
    setIsLoading(true);
    setDatabase(v);
    setSelectedDatabase(v);
    await getEquipmentList({
      db_id: database,
      table_name: optionInfo.tableName,
    })
      .then((data) => {
        setOptionInfo({
          ...optionInfo,
          fab: data.info.user_fab,
          equipment: data.info.equipment_name,
        });
        setFab('');
        setEquipment('');
      })
      .catch((e) =>
        displayNotification({
          message: 'Failed to acquire',
          description:
            e.response.data.msg ??
            'Failed to acquire fab/equipment information.',
          duration: 3,
          style: { borderLeft: '5px solid red' },
        }),
      )
      .finally(() => setIsLoading(false));
  };

  const changeEquipment = async (v) => {
    setIsLoading(true);
    setEquipment(v);
    setSelectedEquipment(v);
    await getEquipmentValidDate({
      db_id: database,
      table_name: optionInfo.tableName,
      equipment_name: v,
      time_column: optionInfo.time_col,
    })
      .then(({ info }) => setOptionInfo({ ...optionInfo, period: info }))
      .catch((e) =>
        displayNotification({
          message: 'Failed to acquire',
          description:
            e.response.data.msg ?? 'Failed to acquire period information.',
          duration: 3,
          style: { borderLeft: '5px solid red' },
        }),
      )
      .finally(() => setIsLoading(false));
  };

  const onApply = async () => {
    closer();
    openModal(ProcessingModal, {
      title: 'Analysing',
      message: 'Analysing data',
    });

    let currentId,
      errorMsg = undefined;

    await getRequestIdFromJobSetting({
      source: 'remote',
      object: {
        func_id: id,
        db_id: database,
        equipment_name: equipment,
        selected: optionInfo.period,
      },
    })
      .then(({ rid }) => {
        currentId = rid;
        return getRemoteOriginalInfo(id, rid);
      })
      .then(({ info }) => {
        const newData = createPageData(info.analysis_type, info.data, 'row');
        setOriginalInfo({
          ...originalData,
          jobId: currentId,
          period: {
            ...info.period,
            start:
              info.period.start.length
                ? dayjs(info.period.start).format(DATE_FORMAT)
                : '',
            end:
              info.period.end.length
                ? dayjs(info.period.end).format(DATE_FORMAT)
                : '',
          },
          aggregation: info.aggregation ?? originalData.aggregation,
          dispOrder: createPageData(
            info.analysis_type,
            info.data,
            'disp_order',
          ),
          dispGraph: createPageData(
            info.analysis_type,
            info.data,
            'disp_graph',
          ),
          data: newData,
        });
        setVisualization({ ...info.visualization });
        setOriginalFilteredRows(newData);
        setAnalysisGraphInfo([]);
        setAnalysisInfo({
          dispOrder: [],
          dispGraph: [],
          data: {},
          common_axis_x: [],
        });
        tabChanger('1');
      })
      .catch(
        (e) =>
          (errorMsg =
            e?.response?.data?.msg ??
            'Analysis of the selected equipment failed.'),
      )
      .finally(() => {
        closeModal(ProcessingModal);
        displayNotification({
          message: errorMsg ? 'Analysis Fail' : 'Analysis Success',
          description:
            errorMsg ?? 'Analysis of the selected equipment was successful.',
          duration: 3,
          style: { borderLeft: errorMsg ? '5px solid red' : '5px solid green' },
        });
      });
  };

  useEffect(() => {
    const fetch = async () => {
      const { info } = await getResource_JobSetting({ func_id: id });
      return info.form.remote;
    };
    if (open) {
      setIsLoading(true);
      fetch()
        .then((data) => {
          if (data) {
            const fabOption = data.find((v) => v.title.includes('Equipment'))
              .items[0];
            const databaseOptions =
              dbList.length
                ? dbList.map((v) => ({
                    id: v.id,
                    name: v.name,
                  }))
                : [];
            const equipmentOptions = {};
            if (databaseOptions.length) {
              fabOption.options.forEach((v) => {
                equipmentOptions[v] = fabOption.subItem.options.find(
                  (x) => Object.keys(x)[0] === v,
                )[v];
              });
            }
            setOptionInfo({
              database: databaseOptions,
              tableName: table_name,
              fab: databaseOptions.length ? fabOption.options : [],
              equipment: equipmentOptions,
              period:
                databaseOptions.length
                  ? {
                      start: analysisData.period.selected[0],
                      end: analysisData.period.selected[1],
                    }
                  : {},
              time_col: time_column,
            });

            if (databaseOptions.length) {
              if (
                databaseOptions.find((v) => v.id === Number(selectedDatabase))
              ) {
                setDatabase(Number(selectedDatabase));
                if (fabOption.options.length) {
                  if (fabOption.options.find((v) => v === user_fab)) {
                    setFab(user_fab);
                    if (
                      Object.keys(equipmentOptions).length &&
                      Object.keys(equipmentOptions).find((v) => v === user_fab)
                    ) {
                      setEquipment(selectedEquipment);
                    }
                  }
                }
              }
            }
          }
        })
        .catch((e) =>
          displayNotification({
            message: 'Failed to acquire',
            description:
              e.response.data.msg ?? 'Failed to acquire information.',
            duration: 3,
            style: { borderLeft: '5px solid red' },
          }),
        )
        .finally(() => setIsLoading(false));
    }
  }, [open]);

  return (
    open && (
      <>
        <DatabaseBackground onClick={closer} />
        <DatabaseContainer>
          <div className="db-popup-header">Change DB & Equipment</div>
          <Spin spinning={isLoading} tip="Loading...">
            <div className="db-popup-contents">
              <div className="setting-content">
                <div className="form">
                  <p>Select Database</p>
                  <div className="form-item">
                    <div className="title-wrapper">
                      <span className="title">From</span>
                    </div>
                    <Select
                      style={{ width: '100%' }}
                      value={database}
                      onChange={(v) => changeDatabase(v)}
                    >
                      {optionInfo.database.length &&
                        optionInfo.database.map((v) => (
                          <Select.Option key={v.id} value={v.id}>
                            {v.name}
                          </Select.Option>
                        ))}
                    </Select>
                  </div>
                </div>
              </div>
              <div className="setting-content">
                <div className="form">
                  <p>Select Equipment</p>
                  <div className="form-item">
                    <div className="title-wrapper">
                      <span className="title">User/Fab</span>
                    </div>
                    <Select
                      style={{ width: '100%' }}
                      value={fab}
                      onChange={(v) => {
                        setFab(v);
                        setEquipment('');
                      }}
                    >
                      {optionInfo.fab.length &&
                        optionInfo.fab.map(RenderSelectOptions)}
                    </Select>
                  </div>
                  <div className="form-item">
                    <div className="title-wrapper">
                      <span className="title">Equipment</span>
                    </div>
                    <Select
                      style={{ width: '100%' }}
                      value={equipment}
                      onChange={(v) => changeEquipment(v)}
                    >
                      {optionInfo.equipment[fab]?.length &&
                        optionInfo.equipment[fab].map(RenderSelectOptions)}
                    </Select>
                  </div>
                </div>
              </div>
            </div>
            <div className="db-popup-footer">
              <button
                disabled={
                  !database.toString().length ||
                  !fab.length ||
                  !equipment.length
                }
                onClick={onApply}
              >
                Apply
              </button>
            </div>
          </Spin>
        </DatabaseContainer>
      </>
    )
  );
};
DatabasePopup.propTypes = {
  open: PropTypes.bool.isRequired,
  closer: PropTypes.func.isRequired,
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  tabChanger: PropTypes.func.isRequired,
};

export default DatabasePopup;
