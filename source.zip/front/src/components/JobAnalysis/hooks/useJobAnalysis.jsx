import Plotly from 'plotly.js-dist';
import { jsonToCSV } from '../../../libs/util/plotly-test';

const getTableData = (row, column) => {
  const jsonArr = Object.keys(row).reduce((accMain, v) => {
    const tmpObj = column.reduce((accSub, i) => {
      Object.assign(accSub, { [i]: row[v][i] });
      return accSub;
    }, {});
    accMain.push(tmpObj);
    return accMain;
  }, []);
  return jsonToCSV(jsonArr);
};

export const createExportTableData = (rows, columns, key, form) => {
  if (Array.isArray(columns)) {
    form.append(
      'files',
      new File([getTableData(rows, columns)], `${key}.table.csv`),
    );
  } else {
    Object.keys(rows).forEach((v) => {
      if (Object.keys(rows[v]).length > 0) {
        form.append(
          'files',
          new File(
            [getTableData(rows[v], columns[v])],
            `${key}.${v}_table.csv`,
          ),
        );
      }
    });
  }
};

export const createGraphImage = async () => {
  const imgArr = [];
  const components = document.querySelectorAll('div[class^="js-plotly-plot"]');

  for (let i = 0; i < components.length; i++) {
    const data = components[i];
    const title = components[i].querySelector(
      'text[class^="gtitle"]',
    ).innerHTML;
    const nameHeader = components[i].id.split('_')[0];

    await Plotly.toImage(data, {
      format: 'png',
      filename: `graph_${title}_${i}`,
    }).then((url) => {
      imgArr.push({
        url: url,
        filename: `${nameHeader}.${title}_${i}.png`,
      });
    });
  }

  return imgArr;
};

export const createHistoryInfo = (data) => {
  let result = data.list
    ? data.list
    : {
        rid: data.job_id,
      };

  if (data.list === undefined) {
    switch (data.job_type) {
      case 'remote':
        result = {
          ...result,
          equipment_name: data.equipment_name,
          db_id: data.db_id,
        };
        break;

      case 'sql':
        result = {
          ...result,
          db_id: data.db_id,
          sql: data.sql,
        };
        break;

      case 'script':
        result = {
          ...result,
          db_id: data.db_id,
          equipment_name: data.equipment_name,
          sql: data.sql,
        };
        break;

      default:
        break;
    }
  }

  return result;
};
