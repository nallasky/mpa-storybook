import React, { useState, useRef, useEffect, useMemo } from 'react';
import PropTypes from 'prop-types';
import { useLocation } from 'react-router-dom';
import dayjs from 'dayjs';
import { Button, Select, Input, DatePicker } from 'antd';
import {
  DeleteOutlined,
  FrownOutlined,
  DoubleLeftOutlined,
  DoubleRightOutlined,
  RightOutlined,
  LeftOutlined,
} from '@ant-design/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus, faSave, faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import styled from '@emotion/styled';
import useResultInfo from '@hooks/common/useResultInfo';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import {
  RenderSelectOptions,
  filteringTableData,
  periodFilteringData,
  remoteUpdateCheck,
} from '@libs/util/common/functionGroup';
import { BasicDateRegex } from '@libs/util/regExp';
import { DATE_FORMAT } from '@constants/etc';

const conditionDefaultHeight = '109px';
const conditionAddHeight = '49px';
const numberDateOptions = [
  {
    title: 'less (and under)',
    value: 'less',
  },
  {
    title: 'more (and over)',
    value: 'more',
  },
  {
    title: 'equal',
    value: 'equal',
  },
  {
    title: 'under',
    value: 'under',
  },
  {
    title: 'over',
    value: 'over',
  },
];
const stringDataOptions = [
  {
    title: 'match',
    value: 'match',
  },
  {
    title: 'not match',
    value: 'not_match',
  },
  {
    title: 'include',
    value: 'include',
  },
  {
    title: 'start',
    value: 'start',
  },
  {
    title: 'end',
    value: 'end',
  },
];

const Contents = styled.div`
  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
  & > div + div {
    margin-top: 1rem;
  }
  & > .aggregation {
    & > .label {
      white-space: pre;
    }
    display: flex;
    align-items: center;
    column-gap: 1rem;
  }
  & > .filter {
    animation: none;
    opacity: 0;
    &.display {
      animation: none;
      opacity: 1;
    }
    &.hide {
      animation: fade-in 0.5s ease-in-out both reverse;
    }
    &.show {
      animation: fade-in 0.5s ease-in-out both;
    }
    & > .table-wrapper {
      & > .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        & > .title {
          font-weight: 500;
        }
        & > button {
          outline: none;
          border-radius: 50%;
          border: 1px solid var(--ckr-blue-6);
          color: white;
          background-color: var(--ckr-blue-6);
          cursor: pointer;
        }
        & + table,
        & + .empty {
          margin-top: 0.5rem;
        }
      }
      & > .empty {
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        row-gap: 1rem;
        & > span {
          font-size: 128px;
        }
        & > p {
          font-size: 18px;
        }
      }
      & > .pagination {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        column-gap: 0.5rem;
        margin-top: 0.5rem;
        & > button {
          border: 1px solid var(--ckr-gray-5);
          background-color: var(--ckr-gray-4);
          cursor: pointer;
          transition: all 0.2s ease-in-out;
          padding: 0.25rem 0.5rem;
          &:disabled {
            cursor: not-allowed;
            color: var(--ckr-gray-6);
          }
        }
      }
      & > table {
        width: 100%;
        & tr {
          border-top: 1px solid var(--ckr-gray-5);
          border-bottom: 1px solid var(--ckr-gray-5);
        }
        & th,
        td {
          padding: 0.5rem;
          text-align: center;
          cursor: default;
          & .tag {
            padding: 0.2rem;
            border: 1px solid var(--ckr-gray-5);
            border-radius: 4px;
            &.and {
              border: 1px solid var(--ckr-red-6);
              background-color: var(--ckr-red-4);
              color: var(--ckr-red-6);
            }
            &.or {
              border: 1px solid var(--ckr-blue-6);
              background-color: var(--ckr-blue-4);
              color: var(--ckr-blue-6);
            }
            & + .tag {
              margin-left: 0.3rem;
            }
          }
        }
        & th {
          &.information {
            position: relative;
            & > .anticon {
              cursor: help;
              margin-left: 0.25rem;
              &:hover {
                & + .tooltip-wrapper {
                  transform: scale(1);
                }
              }
            }
            & > .tooltip-wrapper {
              position: absolute;
              top: -60px;
              left: 58%;
              padding: 0.5rem;
              background-color: white;
              border-radius: 4px;
              border: 1px solid var(--ckr-gray-5);
              transform: scale(0);
              transform-origin: 0;
              transition: all 0.3s ease-in-out;
              & > .item {
                display: flex;
                align-items: center;
                column-gap: 0.25rem;
                & > .tag {
                  display: block;
                  width: 20px;
                  height: 20px;
                  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3),
                    0 2px 6px 2px rgba(60, 64, 67, 0.15);
                }
                + .item {
                  margin-top: 0.25rem;
                }
              }
            }
          }
        }
        & td {
          &.information {
            padding: 0;
            & > .tag-wrapper {
              position: relative;
              padding: 0.5rem;
              overflow: hidden;
              display: flex;
              justify-content: center;
              width: 100%;
              &::before {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                line-height: 2.8;
                content: 'Click for more information.';
                background-color: var(--ckr-blue-6);
                color: white;
                transition: all 0.5s ease-in-out;
                opacity: 0;
                pointer-events: none;
              }
              &:hover {
                &::before {
                  opacity: 0.9;
                }
              }
            }
          }
        }
        & > thead {
          & > tr {
            background-color: rgba(0, 0, 0, 0.07);
          }
        }
        & > tbody {
          & td:last-of-type {
            cursor: pointer;
          }
        }
      }
    }
    & > .setting-wrapper {
      & > div + div {
        margin-top: 0.5rem;
      }
      & > .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        & > .title {
          font-weight: 500;
        }
        & > .button-wrapper {
          & > button {
            outline: none;
            border-radius: 50%;
            border: 1px solid var(--ckr-blue-6);
            color: white;
            background-color: var(--ckr-blue-6);
            cursor: pointer;
            & + button {
              margin-left: 0.5rem;
            }
            &:disabled {
              cursor: not-allowed;
              background-color: white;
              border-color: var(--ckr-gray-5);
              color: var(--ckr-gray-5);
            }
          }
        }
      }
      & > .select-column {
        display: flex;
        column-gap: 1rem;
        align-items: center;
      }
      & > .add-filter {
        overflow: hidden;
        transition: all 0.3s;
        padding: 1rem;
        border: 1px solid var(--ckr-gray-5);
        border-radius: 2px;
        &.add-1 {
          height: ${conditionDefaultHeight};
        }
        &.add-2 {
          height: calc(${conditionDefaultHeight} + ${conditionAddHeight});
        }
        &.add-3 {
          height: calc(${conditionDefaultHeight} + (${conditionAddHeight} * 2));
        }
        &.add-4 {
          height: calc(${conditionDefaultHeight} + (${conditionAddHeight} * 3));
        }
        &.add-5 {
          height: calc(${conditionDefaultHeight} + (${conditionAddHeight} * 4));
        }
        & > .header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          & > .title {
            font-weight: 500;
          }
          & > button {
            outline: none;
            border-radius: 50%;
            border: 1px solid var(--ckr-blue-6);
            color: white;
            background-color: var(--ckr-blue-6);
            cursor: pointer;
            &:disabled {
              &.hidden {
                opacity: 0;
                cursor: default;
              }
              cursor: not-allowed;
              background-color: white;
              border-color: var(--ckr-gray-5);
              color: var(--ckr-gray-5);
            }
          }
        }
        & > .form {
          display: flex;
          column-gap: 0.5rem;
          position: relative;
          & > button {
            cursor: pointer;
            outline: none;
            transition: all 0.3s;
            border: 1px solid transparent;
            border-radius: 4px;
            background-color: var(--ckr-red-6);
            color: white;
            white-space: pre;
            &.switch {
              position: relative;
              min-width: 55px;
              overflow: hidden;
              transition: all 0.3s;
              &.adjust-width {
                width: 55px;
                height: 32px;
              }
              &.on {
                background-color: var(--ckr-blue-6);
                & > .tag {
                  transform: translateX(-37px);
                }
              }
              & > .tag {
                display: flex;
                column-gap: 1.5rem;
                transition: all 0.3s;
                transform: translateX(12px);
                & > span {
                  transition: all 0.3s linear;
                }
              }
            }
            &.delete {
              background-color: white;
              border: 1px dashed var(--ckr-gray-5);
              color: black;
            }
          }
        }
        & > div + div {
          margin-top: 17px;
        }
      }
    }
  }
`;

const dataTypeCheck = (data) => {
  if (BasicDateRegex.test(data)) return 'date';
  return isNaN(Number(data)) ? 'string' : 'number';
};

const filterInitialValue = {
  column_id: '',
  data_type: 'string',
  conditions: Array.from(Array(5), (_, i) => ({
    logical_type: !i ? 'default' : 'and',
    filter_value: '',
    filter_type: 'match',
  })),
};

const FilterModal = ({ loadingSet, type, beforePeriod, onClose }) => {
  const { job_type, source_type, func_id } = useLocation().state;
  const {
    originalData,
    selectedDatabase,
    selectedEquipment,
    savedAggregation,
    setOriginalInfo,
    setOriginalFilteredRows,
    setSavedAggregation,
    setAnalysisInfo,
    setRemoteApplyInfo,
  } = useResultInfo();
  const [isVisible, setIsVisible] = useState(true);
  const [aggregationVal, setAggregationVal] = useState(savedAggregation);
  const [innerFilterInfo, setInnerFilterInfo] = useState(originalData.filter);
  const [addedCount, setAddedCount] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [currentDisplay, setCurrentDisplay] = useState('default');
  const [currentFilterInfo, setCurrentFilterInfo] =
    useState(filterInitialValue);
  const filterRef = useRef();
  const isAllDisable = type === 'analysis';
  const columnList = Array.isArray(originalData.dispOrder)
    ? originalData.dispOrder
    : [
        ...new Set(
          Object.values(originalData.dispOrder).reduce(
            (acc, v) => [...acc, ...v],
            [],
          ),
        ),
      ];
  let rowList = {};
  let i = 0;

  if (Array.isArray(originalData.dispOrder)) {
    rowList = originalData.data;
  } else {
    Object.values(originalData.data).forEach((rows) => {
      for (const row of Object.values(rows)) {
        rowList[i] = row;
        i++;
      }
    });
  }

  const changeComponent = (key) => {
    filterRef.current.classList.add('hide');
    setTimeout(() => {
      filterRef.current.classList.remove('display', 'hide');
      setCurrentDisplay(key);
      filterRef.current.classList.add('show');
    }, 510);
    setTimeout(() => {
      filterRef.current.classList.add('display');
      filterRef.current.classList.remove('show');
    }, 1020);
  };

  const changeAggregation = (key, val) => {
    setAggregationVal((prevState) => {
      if (key === 'type') {
        return {
          type: val,
          val:
            val.toLowerCase().indexOf('all') === -1
              ? originalData.aggregation.subItem[val].selected
              : null,
        };
      } else {
        return {
          ...prevState,
          [key]: val,
        };
      }
    });
  };

  const changeColumn = (id) => {
    const findSampleData = Object.values(rowList).find(
      (row) => row[id] !== '' && row[id] !== undefined && row[id] !== null,
    )[id];
    const newDataType = dataTypeCheck(findSampleData);
    setCurrentFilterInfo({
      column_id: id,
      data_type: newDataType,
      conditions: currentFilterInfo.conditions.map((v) => ({
        ...v,
        filter_type: newDataType === 'string' ? 'match' : 'less',
      })),
    });
  };

  const changeCondition = (condition, index) => {
    setCurrentFilterInfo({
      ...currentFilterInfo,
      conditions: currentFilterInfo.conditions.map((v, j) =>
        j !== index ? v : condition,
      ),
    });
  };

  const deleteCondition = (index) => {
    setAddedCount(addedCount - 1);
    const tmpConditions = currentFilterInfo.conditions.filter(
      (_, j) => j !== index,
    );
    tmpConditions.push({
      filter_value: '',
      filter_type: currentFilterInfo.data_type === 'string' ? 'match' : 'less',
      logical_type: 'and',
    });
    setTimeout(() => {
      setCurrentFilterInfo({
        ...currentFilterInfo,
        conditions: tmpConditions,
      });
    }, 300);
  };

  const detailClick = (id) => {
    const tmpConditions = Array(5).fill(0);

    for (let k = 0; k < 5; k++) {
      const currentInfo = innerFilterInfo[id][k];
      tmpConditions[k] = currentInfo
        ? {
            filter_value:
              currentInfo.data_type === 'date'
                ? dayjs(currentInfo.condition.filter_value)
                : currentInfo.condition.filter_value,
            filter_type: currentInfo.condition.filter_type,
            logical_type: currentInfo.logical_type,
          }
        : {
            filter_value: '',
            filter_type:
              innerFilterInfo[id][0].data_type === 'string' ? 'match' : 'less',
            logical_type: 'and',
          };
    }
    setCurrentFilterInfo({
      column_id: id,
      data_type: innerFilterInfo[id][0].data_type,
      conditions: tmpConditions,
    });
    setAddedCount(innerFilterInfo[id].length);
    changeComponent('edit');
  };

  const saveDisableCheck = () => {
    if (!currentFilterInfo.column_id) return true;
    return !currentFilterInfo.conditions.filter((v) => v.filter_value !== '')
      .length;
  };

  const saveFilter = () => {
    setInnerFilterInfo({
      ...innerFilterInfo,
      [currentFilterInfo.column_id]: currentFilterInfo.conditions
        .filter((v) => v.filter_value !== '')
        .map((condition) => ({
          logical_type: condition.logical_type,
          data_type: currentFilterInfo.data_type,
          condition: {
            filter_type: condition.filter_type,
            filter_value:
              currentFilterInfo.data_type === 'date'
                ? dayjs(condition.filter_value).format(DATE_FORMAT)
                : condition.filter_value.toString(),
          },
        })),
    });
    changeComponent('default');
    setTimeout(() => {
      setCurrentFilterInfo(filterInitialValue);
      setAddedCount(1);
    }, 510);
  };

  const deleteFilter = () => {
    const result = {};

    Object.entries(innerFilterInfo).forEach((filter) => {
      if (currentFilterInfo.column_id !== filter[0]) {
        result[filter[0]] = filter[1];
      }
    });

    setInnerFilterInfo(result);
    changeComponent('default');
    setTimeout(() => {
      setCurrentFilterInfo(filterInitialValue);
      setAddedCount(1);
    }, 510);
  };

  const onApply = async () => {
    if (Object.keys(originalData.aggregation).length) {
      setSavedAggregation(aggregationVal);
    }
    setIsVisible(false);
    if (
      (job_type === 'remote' || source_type === 'remote') &&
      remoteUpdateCheck(beforePeriod, originalData.period.selected)
    ) {
      setRemoteApplyInfo({
        type: 'filter',
        func_id,
        db_id: selectedDatabase,
        equipment_name: selectedEquipment,
        period: originalData.period,
        beforePeriod,
        filter: innerFilterInfo,
      });
    } else {
      loadingSet(true);
      if (
        JSON.stringify(originalData.filter) !== JSON.stringify(innerFilterInfo)
      ) {
        setOriginalInfo({
          ...originalData,
          filter: innerFilterInfo,
        });
        setOriginalFilteredRows(
          filteringTableData(
            innerFilterInfo,
            periodFilteringData(
              originalData.period.selected,
              originalData.multiCurrentTable
                ? originalData.data[originalData.multiCurrentTable]
                : originalData.data,
            ),
          ),
        );
        setAnalysisInfo({
          dispOrder: [],
          dispGraph: [],
          data: {},
          common_axis_x: [],
          multiCurrentTable: '',
        });
      }
      setTimeout(() => loadingSet(false), 2000);
    }
  };

  useEffect(() => {
    if (!isVisible) {
      onClose();
    }
  }, [isVisible]);

  return (
    <DraggableModal
      visible={isVisible}
      title="Filter Setting"
      cancelHandler={() => setIsVisible(false)}
      footer={[
        <Button
          key="cancel"
          type={isAllDisable ? 'primary' : 'default'}
          onClick={() => setIsVisible(false)}
        >
          {isAllDisable ? 'Close' : 'Cancel'}
        </Button>,
        isAllDisable ? undefined : (
          <Button key="ok" type="primary" onClick={onApply}>
            Apply
          </Button>
        ),
      ]}
      width={650}
    >
      <Contents>
        {!!Object.keys(originalData.aggregation).length && (
          <div className="aggregation">
            <span className="label">Aggregation by:</span>
            <Select
              value={aggregationVal.type}
              style={{ width: '100%' }}
              onChange={(v) => changeAggregation('type', v)}
              disabled={isAllDisable}
            >
              {originalData.aggregation.options.map(RenderSelectOptions)}
            </Select>
            {aggregationVal.type === 'column' ? (
              <Select
                value={aggregationVal.val}
                style={{ width: '100%' }}
                onChange={(v) => changeAggregation('val', v)}
                disabled={isAllDisable}
              >
                {originalData.aggregation.subItem.column.options.map(
                  RenderSelectOptions,
                )}
              </Select>
            ) : aggregationVal.type === 'period' ? (
              <Input
                type="text"
                value={aggregationVal.val}
                onChange={(e) => changeAggregation('val', e.target.value)}
                disabled={isAllDisable}
              />
            ) : (
              ''
            )}
          </div>
        )}
        <div className="filter display" ref={filterRef}>
          {currentDisplay === 'default' ? (
            <div className="table-wrapper">
              <div className="header">
                <span className="title">Filter Management</span>
                {!isAllDisable && (
                  <button
                    onClick={() => changeComponent('add')}
                    disabled={
                      columnList.length === Object.keys(innerFilterInfo).length
                    }
                  >
                    <FontAwesomeIcon icon={faPlus} />
                  </button>
                )}
              </div>
              {Object.keys(innerFilterInfo).length ? (
                <>
                  <table>
                    <thead>
                      <tr>
                        <th>Column</th>
                        <th>Registered information</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Object.entries(innerFilterInfo)
                        .slice(currentPage * 5 - 5, currentPage * 5)
                        .map((conditions, i) => {
                          return (
                            <tr key={i}>
                              <td>{conditions[0]}</td>
                              <td className="information">
                                <div
                                  className="tag-wrapper"
                                  onClick={() => detailClick(conditions[0])}
                                  role="button"
                                  onKeyDown={() => {}}
                                  onKeyPress={() => {}}
                                  tabIndex="0"
                                >
                                  {`${conditions[1].length} condition is registered.`}
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                  {Object.keys(innerFilterInfo).length > 5 && (
                    <div className="pagination">
                      <button
                        onClick={() => setCurrentPage(1)}
                        disabled={currentPage === 1}
                      >
                        <DoubleLeftOutlined />
                      </button>
                      <button
                        onClick={() => setCurrentPage(currentPage - 1)}
                        disabled={currentPage === 1}
                      >
                        <LeftOutlined />
                      </button>
                      <button
                        onClick={() => setCurrentPage(currentPage + 1)}
                        disabled={
                          currentPage * 5 >
                          Object.keys(innerFilterInfo).length - 1
                        }
                      >
                        <RightOutlined />
                      </button>
                      <button
                        onClick={() =>
                          setCurrentPage(
                            Math.ceil(Object.keys(innerFilterInfo).length / 5),
                          )
                        }
                        disabled={
                          currentPage * 5 >
                          Object.keys(innerFilterInfo).length - 1
                        }
                      >
                        <DoubleRightOutlined />
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <div className="empty">
                  <FrownOutlined />
                  <p>Filter is not registered.</p>
                </div>
              )}
            </div>
          ) : (
            <div className="setting-wrapper">
              <div className="header">
                <span className="title">
                  {isAllDisable
                    ? 'Registered filter information'
                    : currentDisplay === 'edit'
                    ? 'Edit registered filter'
                    : 'Register filter'}
                </span>
                <div className="button-wrapper">
                  <button
                    onClick={() => {
                      changeComponent('default');
                      setTimeout(() => {
                        setCurrentFilterInfo(filterInitialValue);
                        setAddedCount(1);
                      }, 750);
                    }}
                  >
                    <FontAwesomeIcon icon={faArrowLeft} />
                  </button>
                  {currentDisplay === 'edit' && !isAllDisable && (
                    <button onClick={deleteFilter}>
                      <DeleteOutlined />
                    </button>
                  )}
                  {!isAllDisable && (
                    <button disabled={saveDisableCheck()} onClick={saveFilter}>
                      <FontAwesomeIcon icon={faSave} />
                    </button>
                  )}
                </div>
              </div>
              <div className="select-column">
                <Select
                  value={currentFilterInfo.column_id}
                  onChange={(v) => changeColumn(v)}
                  disabled={isAllDisable}
                  style={{ width: '100%' }}
                >
                  {columnList
                    .filter((column) => {
                      return (
                        !!Object.values(rowList).find(
                          (v) =>
                            v[column] !== undefined &&
                            v[column] !== '' &&
                            v[column] !== null,
                        ) && !innerFilterInfo[column]
                      );
                    })
                    .map(RenderSelectOptions)}
                </Select>
              </div>
              <div className={`add-filter add-${addedCount}`}>
                <div className="header">
                  <span className="title">Registered condition</span>
                  <button
                    onClick={() => setAddedCount(addedCount + 1)}
                    disabled={addedCount === 5 || isAllDisable}
                    className={isAllDisable ? 'hidden' : ''}
                  >
                    <FontAwesomeIcon icon={faPlus} />
                  </button>
                </div>
                {currentFilterInfo.conditions.map((v, i) => (
                  <FilterInput
                    key={i}
                    info={v}
                    index={i}
                    setInfo={changeCondition}
                    onDelete={deleteCondition}
                    dataType={currentFilterInfo.data_type}
                    allDisable={isAllDisable}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </Contents>
    </DraggableModal>
  );
};
FilterModal.displayName = 'FilterModal';
FilterModal.propTypes = {
  loadingSet: PropTypes.func,
  type: PropTypes.string,
  beforePeriod: PropTypes.array,
  onClose: PropTypes.func,
};

const FilterInput = ({
  info,
  index,
  setInfo,
  onDelete,
  dataType,
  allDisable,
}) => {
  const typeOptionList = useMemo(() => {
    return dataType === 'string' ? stringDataOptions : numberDateOptions;
  }, [dataType]);

  const changeInfo = (key, v) => {
    const newCondition = {
      ...info,
      [key]: v,
    };
    setInfo(newCondition, index);
  };

  return (
    <div className="form">
      {info.logical_type !== 'default' && (
        <button
          className={'switch' + (info.logical_type === 'or' ? ' on' : '')}
          onClick={() =>
            changeInfo(
              'logical_type',
              info.logical_type === 'or' ? 'and' : 'or',
            )
          }
          disabled={allDisable}
        >
          <span className="tag">
            <span className="off">AND</span>
            <span className="on">OR</span>
          </span>
        </button>
      )}
      {dataType === 'date' ? (
        <DatePicker
          value={info.filter_value}
          onChange={(v) => changeInfo('filter_value', v)}
          showTime
          inputReadOnly
          allowClear
          showNow={false}
          style={{ width: '400px' }}
          disabled={allDisable}
        />
      ) : (
        <Input
          type="text"
          value={info.filter_value}
          onChange={(e) => changeInfo('filter_value', e.target.value)}
          style={{ width: '400px' }}
          disabled={allDisable}
        />
      )}
      <Select
        value={info.filter_type}
        onChange={(v) => changeInfo('filter_type', v)}
        style={{ width: '160px' }}
        disabled={allDisable}
      >
        {typeOptionList.map((v, i) => (
          <Select.Option key={i} value={v.value}>
            {v.title}
          </Select.Option>
        ))}
      </Select>
      {info.logical_type !== 'default' && !allDisable && (
        <button className="delete" onClick={() => onDelete(index)}>
          <DeleteOutlined />
        </button>
      )}
    </div>
  );
};
FilterInput.displayName = 'FilterInput';
FilterInput.propTypes = {
  info: PropTypes.object,
  index: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  setInfo: PropTypes.func,
  onDelete: PropTypes.func,
  dataType: PropTypes.string,
  allDisable: PropTypes.bool,
};

export default FilterModal;
