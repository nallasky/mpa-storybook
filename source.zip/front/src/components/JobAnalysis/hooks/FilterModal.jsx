import React, { useState, useRef, useEffect, useMemo } from 'react';
import dayjs from 'dayjs';
import { Select, Input, DatePicker } from 'antd';
import {
  DeleteOutlined,
  QuestionCircleOutlined,
  FrownOutlined,
  DoubleLeftOutlined,
  DoubleRightOutlined,
  RightOutlined,
  LeftOutlined
} from '@ant-design/icons';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus, faSave, faArrowLeft } from "@fortawesome/free-solid-svg-icons";
import styled from '@emotion/styled';
import useResultInfo from "@hooks/common/useResultInfo";
import DraggableModal from "@components/common/organisms/DraggableModal/DraggableModal";
import { RenderSelectOptions, filteringTableData, periodFilteringData } from "@libs/util/common/functionGroup";
import { BasicDateRegex } from "@libs/util/regExp";
import { DATE_FORMAT } from "@constants/etc";

const conditionDefaultHeight = '109px';
const conditionAddHeight = '49px';
const numberDataOptions = [
  {
    title: 'less (and under)',
    value: 'less'
  },
  {
    title: 'more (and over)',
    value: 'more',
  },
  {
    title: 'equal',
    value: 'equal',
  },
  {
    title: 'under',
    value: 'under',
  },
  {
    title: 'over',
    value: 'over',
  },
];
const stringDataOptions = [
  {
    title: 'match',
    value: 'match'
  },
  {
    title: 'not match',
    value: 'not_match',
  },
  {
    title: 'include',
    value: 'include',
  },
  {
    title: 'start',
    value: 'start',
  },
  {
    title: 'end',
    value: 'end',
  },
];

const Contents = styled.div`
  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
  & > div + div {
    margin-top: 1rem;
  }
  & > .aggregation {
    & > .label {
      white-space: pre;
    }
    display: flex;
    align-items: center;
    column-gap: 1rem;
  }
  & > .filter {
    animation: none;
    opacity: 0;
    &.display {
      animation: none;
      opacity: 1;
    }
    &.hide {
      animation: fade-in 0.5s ease-in-out both reverse;
    }
    &.show {
      animation: fade-in 0.5s ease-in-out both;
    }
    & > .table-wrapper {
      & > .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        & > .title {
          font-weight: 500;
        }
        & > button {
          outline: none;
          border-radius: 50%;
          border: 1px solid #1890ff;
          color: white;
          background-color: #1890ff;
          cursor: pointer;
        }
        & + table,
        & + .empty {
          margin-top: 0.5rem;
        }
      }
      & > .empty {
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        row-gap: 1rem;
        & > span {
          font-size: 128px;
        }
        & > p {
          font-size: 18px;
        }
      }
      & > .pagination {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        column-gap: 0.5rem;
        margin-top: 0.5rem;
        & > button {
          border: 1px solid var(--ckr-gray-5);
          background-color: var(--ckr-gray-4);
          cursor: pointer;
          transition: all 0.2s ease-in-out;
          padding: 0.25rem 0.5rem;
          &:disabled {
            cursor: not-allowed;
            color: var(--ckr-gray-6);
          }
        }
      }
      & > table {
        width: 100%;
        & tr {
          border-top: 1px solid #dadada;
          border-bottom: 1px solid #dadada;
        }
        & th, td {
          padding: 0.5rem;
          text-align: center;
          cursor: default;
          & .tag {
            padding: 0.2rem;
            border: 1px solid #dadada;
            border-radius: 4px;
            &.and {
              border: 1px solid #ff1a1a;
              background-color: #ffc7c7;
              color: #fa1a1a;
            }
            &.or {
              border: 1px solid #1890ff;
              background-color: #cee7ff;
              color: #1890ff;
            }
            & + .tag {
              margin-left: 0.3rem;
            }
          }
        }
        & th {
          &.information {
            position: relative;
            & > .anticon {
              cursor: help;
              margin-left: 0.25rem;
              &:hover {
                & + .tooltip-wrapper {
                  transform: scale(1);
                }
              }
            }
            & > .tooltip-wrapper {
              position: absolute;
              top: -60px;
              left: 58%;
              padding: 0.5rem;
              background-color: white;
              border-radius: 4px;
              border: 1px solid #dadada;
              transform: scale(0);
              transform-origin: 0;
              transition: all 0.3s ease-in-out;
              & > .item {
                display: flex;
                align-items: center;
                column-gap: 0.25rem;
                & > .tag {
                  display: block;
                  width: 20px;
                  height: 20px;
                  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3), 0 2px 6px 2px rgba(60, 64, 67, 0.15);
                }
                + .item {
                  margin-top: 0.25rem;
                }
              }
            }
          }
        }
        & td {
          &.information {
            padding: 0;
            & > .tag-wrapper {
              position: relative;
              padding: 0.5rem;
              overflow: hidden;
              display: flex;
              justify-content: center;
              &::before {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                line-height: 3.3;
                content: 'Click for more information.';
                background-color: #1890ff;
                color: white;
                transition: all 0.5s ease-in-out;
                opacity: 0;
                pointer-events: none;;
              }
              &:hover {
                &::before {
                  opacity: 0.9;
                }
              }
            }
          }
        }
        & > thead {
          & > tr {
            background-color: rgba(0,0,0,0.07);
          }
        }
        & > tbody {
          & td:last-of-type {
            cursor: pointer;
          }
        }
      }
    }
    & > .setting-wrapper {
      & > div + div {
        margin-top: 0.5rem;
      }
      & > .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        & > .title {
          font-weight: 500;
        }
        & > .button-wrapper {
          & > button {
            outline: none;
            border-radius: 50%;
            border: 1px solid #1890ff;
            color: white;
            background-color: #1890ff;
            cursor: pointer;
            & + button {
              margin-left: 0.5rem;
            }
            &:disabled {
              cursor: not-allowed;
              background-color: white;
              border-color: var(--ckr-gray-5);
              color: var(--ckr-gray-5);
            }
          } 
        }
      }
      & > .select-column {
        display: flex;
        column-gap: 1rem;
        align-items: center;
      }
      & > .add-filter {
        overflow: hidden;
        transition: all 0.3s;
        padding: 1rem;
        border: 1px solid #dadada;
        border-radius: 2px;
        &.add-1 {
          height: ${conditionDefaultHeight};
        }
        &.add-2 {
          height: calc(${conditionDefaultHeight} + ${conditionAddHeight});
        }
        &.add-3 {
          height: calc(${conditionDefaultHeight} + (${conditionAddHeight} * 2));
        }
        &.add-4 {
          height: calc(${conditionDefaultHeight} + (${conditionAddHeight} * 3));
        }
        &.add-5 {
          height: calc(${conditionDefaultHeight} + (${conditionAddHeight} * 4));
        }
        & > .header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          & > .title {
            font-weight: 500;
          }
          & > button {
            outline: none;
            border-radius: 50%;
            border: 1px solid #1890ff;
            color: white;
            background-color: #1890ff;
            cursor: pointer;
            &:disabled {
              cursor: not-allowed;
              background-color: white;
              border-color: var(--ckr-gray-5);
              color: var(--ckr-gray-5);
            }
          }
        }
        & > .form {
          display: flex;
          column-gap: 0.5rem;
          position: relative;
          & > button {
            cursor: pointer;
            outline: none;
            transition: all 0.3s;
            border: 1px solid transparent;
            border-radius: 4px;
            background-color: #1890ff;
            color: white;
            white-space: pre;
            &.switch {
              position: relative;
              min-width: 55px;
              overflow: hidden;
              transition: all 0.3s;
              &.adjust-width {
                width: 55px;
                height: 32px;
              }
              &.on {
                background-color: #f5222d;
                & > .tag {
                  transform: translateX(-37px);
                }
              }
              & > .tag {
                display: flex;
                column-gap: 1.5rem;
                transition: all 0.3s;
                transform: translateX(12px);
                & > span {
                  transition: all 0.3s linear;
                }
              }
            }
            &.add {
              display: flex;
              align-items: center;
              & > span {
                transition: all 0.3s;
                margin-right: 0.3rem
              }
              &:disabled {
                cursor: not-allowed;
                background-color: #bfbfbf;
              }
            }
            &.delete {
              background-color: white;
              border: 1px dashed #dadada;
              color: black;
            }
          }
        }
        & > div + div {
          margin-top: 17px;
        }
      }
    }
  }
`;

const dataTypeCheck = (data) => {
  if (BasicDateRegex.test(data))
    return 'date';
  return isNaN(Number(data)) ? 'string' : 'number';
}

const filterInitialValue = {
  column_id: '',
  data_type: 'string',
  conditions: [
    {
      filter_value: '',
      filter_type: 'match',
      logical_type: 'default',
    },
    {
      filter_value: '',
      filter_type: 'match',
      logical_type: 'and',
    },
    {
      filter_value: '',
      filter_type: 'match',
      logical_type: 'and',
    },
    {
      filter_value: '',
      filter_type: 'match',
      logical_type: 'and',
    },
    {
      filter_value: '',
      filter_type: 'match',
      logical_type: 'and',
    }
  ],
}

const FilterModal = ({ loadingSet, onClose }) => {
  const { originalData, setOriginalInfo, setOriginalFilteredRows, savedAggregation, setSavedAggregation } = useResultInfo();
  const [isVisible, setIsVisible] = useState(true);
  const [aggregationVal, setAggregationVal] = useState(savedAggregation);
  const [innerFilterInfo, setInnerFilterInfo] = useState(originalData.filter);
  const [addedCount, setAddedCount] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [currentDisplay, setCurrentDisplay] = useState('default');
  const [currentFilterInfo, setCurrentFilterInfo] = useState(filterInitialValue);
  const filterRef = useRef();

  const changeComponent = (key) => {
    filterRef.current.classList.add("hide");
    setTimeout(() => {
      filterRef.current.classList.remove("display", "hide");
      setCurrentDisplay(key);
      filterRef.current.classList.add("show");
    }, 510);
    setTimeout(() => {
      filterRef.current.classList.add("display");
      filterRef.current.classList.remove("show");
    }, 1020);
  };

  const changeAggregation = (key, val) => {
    setAggregationVal((prevState) => {
      if (key === 'type') {
        return {
          type: val,
          val: val.toLowerCase().indexOf('all') === -1 ? originalData.aggregation.subItem[val].selected : null,
        };
      } else {
        return {
          ...prevState,
          [key]: val,
        };
      }
    });
  };

  const changeColumn = (id) => {
    const findSampleData = Object.values(originalData.data).find((row) => !!row[id])[id];
    const newDataType = dataTypeCheck(findSampleData);
    setCurrentFilterInfo({
      column_id: id,
      data_type: newDataType,
      conditions: currentFilterInfo.conditions.map((v) => ({
        ...v,
        filter_type: newDataType === 'string' ? 'match' : 'less',
      })),
    });
  };

  const changeCondition = (condition, index) => {
    setCurrentFilterInfo({
      ...currentFilterInfo,
      conditions: currentFilterInfo.conditions.map((v, i) => i !== index ? v : condition),
    })
  };

  const deleteCondition = (index) => {
    setAddedCount(addedCount - 1);
    setTimeout(() => {
      setCurrentFilterInfo({
        ...currentFilterInfo,
        conditions: currentFilterInfo.conditions.map((v, i) => i !== index ? v : {
          filter_value: '',
          filter_type: currentFilterInfo.data_type === 'string' ? 'match' : 'less',
          logical_type: 'and',
        }),
      });
    }, 300);
  };

  const detailClick = (id) => {
    setCurrentFilterInfo({
      column_id: id,
      data_type: innerFilterInfo[id][0].data_type,
      conditions: innerFilterInfo[id].map((v) => (
        {
          filter_value: innerFilterInfo[id][0].data_type === 'date' ? dayjs(v.condition.filter_value) : v.condition.filter_value,
          filter_type: v.condition.filter_type,
          logical_type: v.logical_type,
        }
      )),
    });
    changeComponent('edit');
  };

  const saveDisableCheck = () => {
    if (!currentFilterInfo.column_id) return true;
    return !currentFilterInfo.conditions.filter((v) => v.filter_value !== '').length;
  };

  const saveFilter = () => {
    setInnerFilterInfo({
      ...innerFilterInfo,
      [currentFilterInfo.column_id]: currentFilterInfo.conditions.filter((v) => v.filter_value !== '').map((condition) => (
        {
          logical_type: condition.logical_type,
          data_type: currentFilterInfo.data_type,
          condition: {
            filter_type: condition.filter_type,
            filter_value: currentFilterInfo.data_type === 'date' ? dayjs(condition.filter_value).format(DATE_FORMAT) : condition.filter_value.toString(),
          }
        }
      )),
    });
    changeComponent('default');
    setTimeout(() => setCurrentFilterInfo(filterInitialValue), 510);
  };

  const deleteFilter = () => {
    const result = {};

    Object.entries((filter) => {
      if (currentFilterInfo.column_id !== filter[0]) {
        result[filter[0]] = filter[1];
      }
    });

    setInnerFilterInfo(result);
    changeComponent('default');
    setTimeout(() => setCurrentFilterInfo(filterInitialValue), 510);
  }

  const onApply = () => {
    setSavedAggregation(aggregationVal);
    setIsVisible(false);
    loadingSet(true);
    if (JSON.stringify(originalData.filter) !== JSON.stringify(innerFilterInfo)) {
      setOriginalInfo({
        ...originalData,
        filter: innerFilterInfo,
      });
      setOriginalFilteredRows(
        filteringTableData(innerFilterInfo,
          !!originalData.period.selected[0]
            ? periodFilteringData(originalData.period.selected, originalData.data)
            : originalData.data)
      );
    }
    setTimeout(() => loadingSet(false), 2000);
  };

  useEffect(() => {
    if (!isVisible) {
      onClose();
    }
  }, [isVisible]);

  return (
    <DraggableModal
      visible={isVisible}
      title="Filter Setting"
      okText="Apply"
      cancelText="Cancel"
      okHandler={onApply}
      cancelHandler={() => setIsVisible(false)}
      width={650}
      centered
    >
      <Contents>
        <div className="aggregation">
          <span className="label">Aggregation by:</span>
          <Select value={aggregationVal.type} style={{ width: "100%" }} onChange={(v) => changeAggregation('type', v)}>
            {originalData.aggregation.options.map(RenderSelectOptions)}
          </Select>
          {aggregationVal.type === 'column' ? (
            <Select value={aggregationVal.val}  style={{ width: "100%" }} onChange={(v) => changeAggregation('val', v)}>
              {originalData.aggregation.subItem.column.options.map(RenderSelectOptions)}
            </Select>
          ) : aggregationVal.type === 'period' ? (
            <Input type="text" value={aggregationVal.val} onChange={(e) => changeAggregation('val', e.target.value)} />
          ) : ''}
        </div>
        <div className="filter display" ref={filterRef}>
          {currentDisplay === 'default' ? (
            <div className="table-wrapper">
              <div className="header">
                <span className="title">Filter Management</span>
                <button onClick={() => changeComponent('add')}>
                  <FontAwesomeIcon icon={faPlus} />
                </button>
              </div>
              {Object.keys(innerFilterInfo).length ? (
                <>
                  <table>
                    <thead>
                    <tr>
                      <th>Column</th>
                      <th className="information">
                        Details
                        <QuestionCircleOutlined />
                        <div className="tooltip-wrapper">
                          <div className="item">
                            <span className="tag" />
                            <span className="description">
                              basic condition
                            </span>
                          </div>
                          <div className="item">
                            <span className="tag and" />
                            <span className="description">and</span>
                          </div>
                          <div className="item">
                            <span className="tag or" />
                            <span className="description">or</span>
                          </div>
                        </div>
                      </th>
                    </tr>
                    </thead>
                    <tbody>
                    {Object.entries(innerFilterInfo).slice(currentPage * 5 - 5, currentPage * 5).map((conditions, i, ) => {
                      return (
                        <tr key={i}>
                          <td>{conditions[0]}</td>
                          <td
                            className="information"
                            onClick={() => detailClick(conditions[0])}
                          >
                            <div className="tag-wrapper">
                            {conditions[1].map(({logical_type, condition}, j) => (
                              <span
                                key={j}
                                className={logical_type === 'and' ? 'tag and' : logical_type === 'or' ? 'tag or' : 'tag' }
                              >
                                {stringDataOptions.concat(numberDataOptions).find((v) => v.value === condition.filter_type).title}
                              </span>
                            ))}
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                    </tbody>
                  </table>
                  {Object.keys(innerFilterInfo).length && (
                    <div className="pagination">
                      <button
                        onClick={() => setCurrentPage(1)}
                        disabled={currentPage === 1}
                      >
                        <DoubleLeftOutlined />
                      </button>
                      <button
                        onClick={() => setCurrentPage(currentPage - 1)}
                        disabled={currentPage === 1}
                      >
                        <LeftOutlined />
                      </button>
                      <button
                        onClick={() => setCurrentPage(currentPage + 1)}
                        disabled={
                          currentPage * 5 >
                          Object.keys(innerFilterInfo).length - 1
                        }
                      >
                        <RightOutlined />
                      </button>
                      <button
                        onClick={() => setCurrentPage(Math.ceil(Object.keys(innerFilterInfo).length / 5))}
                        disabled={
                          currentPage * 5 >
                          Object.keys(innerFilterInfo).length - 1
                        }
                      >
                        <DoubleRightOutlined />
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <div className="empty">
                  <FrownOutlined />
                  <p>Filter is not registered.</p>
                </div>
              )}
            </div>
          ) : (
            <div className="setting-wrapper">
              <div className="header">
                <span className="title">Register filter</span>
                <div className="button-wrapper">
                  <button onClick={() => {
                    changeComponent('default');
                    setTimeout(() => setCurrentFilterInfo(filterInitialValue), 750);
                  }}>
                    <FontAwesomeIcon icon={faArrowLeft} />
                  </button>
                  {currentDisplay === 'edit' && (
                    <button onClick={deleteFilter}>
                      <DeleteOutlined />
                    </button>
                  )}
                  <button disabled={saveDisableCheck()} onClick={saveFilter}>
                    <FontAwesomeIcon icon={faSave} />
                  </button>
                </div>
              </div>
              <div className="select-column">
                <Select value={currentFilterInfo.column_id} onChange={(v) => changeColumn(v)} style={{ width: "100%" }}>
                  {originalData.dispOrder.filter((column) => {
                    return !!Object.values(originalData.data).find((v) => !!v[column]) && !innerFilterInfo[column];
                  }).map(RenderSelectOptions)}
                </Select>
              </div>
              <div className={`add-filter add-${addedCount}`}>
                <div className="header">
                  <span className="title">Registered condition</span>
                  <button onClick={() => setAddedCount(addedCount + 1)} disabled={addedCount === 5}>
                    <FontAwesomeIcon icon={faPlus} />
                  </button>
                </div>
                {currentFilterInfo.conditions.map((v, i) => (
                  <FilterInput
                    key={i}
                    info={v}
                    index={i}
                    setInfo={changeCondition}
                    onDelete={deleteCondition}
                    dataType={currentFilterInfo.data_type}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </Contents>
    </DraggableModal>
  )
};

const FilterInput = ({ info, index, setInfo, onDelete, dataType }) => {
  const typeOptionList = useMemo(() => {
    return dataType === 'string' ? stringDataOptions : numberDataOptions;
  }, [dataType]);

  const changeInfo = (key, v) => {
    const newCondition = {
      ...info,
      [key]: v,
    };
    setInfo(newCondition, index);
  };

  return (
    <div className="form">
      {info.logical_type !== 'default' && (
        <button
          className={"switch" + (info.logical_type === 'or' ? " on" : "")}
          onClick={() => changeInfo('logical_type', info.logical_type === 'or' ? 'and' : 'or')}
        >
        <span className="tag">
          <span className="off">AND</span>
          <span className="on">OR</span>
        </span>
        </button>
      )}
      {dataType === 'date' ? (
        <DatePicker
          value={info.filter_value}
          onChange={(v) => changeInfo('filter_value', v)}
          showTime
          inputReadOnly
          allowClear
          showNow={false}
          style={{ width: '400px' }}
        />
      ) : (
        <Input type="text" value={info.filter_value} onChange={(e) => changeInfo('filter_value', e.target.value)} style={{ width: '400px' }} />
      )}
      <Select value={info.filter_type} onChange={(v) => changeInfo('filter_type', v)} style={{ width: '160px' }}>
        {typeOptionList.map((v, i) => (
          <Select.Option key={i} value={v.value}>
            {v.title}
          </Select.Option>
        ))}
      </Select>
      {info.logical_type !== 'default' && (
        <button
          className="delete"
          onClick={() => onDelete(index)}
        >
          <DeleteOutlined />
        </button>
      )}
    </div>
  );
};

export default FilterModal;