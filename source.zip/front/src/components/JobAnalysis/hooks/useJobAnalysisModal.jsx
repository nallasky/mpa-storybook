import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import DraggableModal from '../../common/organisms/DraggableModal/DraggableModal';
import { Form, Input } from 'antd';
import * as sg from '../styles/JobAnalysisStyles';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChartBar, faTable } from '@fortawesome/free-solid-svg-icons';

const JobAnalysisModal = ({
  title,
  okText,
  ok,
  width,
  type,
  info,
  onClose,
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [historyName, setHistoryName] = useState(info.historyName ?? '');
  const [checkTable, setCheckTable] = useState(info.checkTable ?? false);
  const [checkGraph, setCheckGraph] = useState(info.checkGraph ?? false);

  useEffect(() => {
    if (!isVisible) {
      onClose();
    }
  }, [isVisible]);

  return (
    <DraggableModal
      visible={isVisible}
      title={title}
      okHandler={() => {
        setIsVisible(false);
        ok(type === 'history' ? historyName : { checkTable, checkGraph });
      }}
      cancelHandler={() => setIsVisible(false)}
      okText={okText ? okText : 'OK'}
      width={width ?? 520}
      footer="default"
    >
      {type === 'history' ? (
        <Form.Item label="Title" style={{ marginBottom: 0 }}>
          <Input
            value={historyName}
            onChange={(e) => setHistoryName(e.target.value)}
            maxLength="20"
          />
        </Form.Item>
      ) : (
        <div
          css={[
            sg.exportModalWrapper,
            !info.isRenderGraph ? { gridTemplateColumns: 'auto' } : {},
          ]}
        >
          <input
            type="checkbox"
            id="table"
            checked={checkTable}
            onChange={() => setCheckTable(!checkTable)}
          />
          <label htmlFor="table">
            <svg viewBox="0 0 21 21">
              <polyline points="5 10.75 8.5 14.25 16 6" />
            </svg>
            <FontAwesomeIcon icon={faTable} size="2x" />
            <span>Table</span>
          </label>
          {info.isRenderGraph && (
            <>
              <input
                type="checkbox"
                id="graph"
                checked={checkGraph}
                onChange={() => setCheckGraph(!checkGraph)}
              />
              <label htmlFor="graph">
                <svg viewBox="0 0 21 21">
                  <polyline points="5 10.75 8.5 14.25 16 6" />
                </svg>
                <FontAwesomeIcon icon={faChartBar} size="2x" />
                <span>Graph</span>
              </label>
            </>
          )}
        </div>
      )}
    </DraggableModal>
  );
};

JobAnalysisModal.displayName = 'JobAnalysisModal';
JobAnalysisModal.propTypes = {
  title: PropTypes.string.isRequired,
  okText: PropTypes.string,
  ok: PropTypes.func.isRequired,
  width: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  type: PropTypes.string,
  info: PropTypes.object.isRequired,
  onClose: PropTypes.func.isRequired,
};
JobAnalysisModal.defaultProps = {
  type: 'history',
};

export default JobAnalysisModal;
