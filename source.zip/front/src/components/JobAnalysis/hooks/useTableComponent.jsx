import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import ReactTable from '../../common/atoms/Table/ReactTable';
import useResultInfo from '../../../hooks/common/useResultInfo';
import { GraphDateRegex } from '@libs/util/regExp';

const searchKey = (data) => {
  let result = Object.keys(data).find((v) => v === 'period')
    ? 'period'
    : undefined;

  if (!result) {
    for (const key of Object.keys(data)) {
      if (GraphDateRegex.test(data[key])) {
        result = key;
        break;
      }
    }
  }
  return result;
};

const AnalysisTableComponent = ({ tableOrder, tableData }) => {
  const columnData = useMemo(() => tableOrder, [JSON.stringify(tableOrder)]);
  const rowData = useMemo(() => tableData, [JSON.stringify(tableData)]);

  return <ReactTable columns={columnData} data={rowData} />;
};

AnalysisTableComponent.displayName = 'TableComponent';
AnalysisTableComponent.propTypes = {
  tableOrder: PropTypes.array.isRequired,
  tableData: PropTypes.array.isRequired,
};

export default AnalysisTableComponent;
