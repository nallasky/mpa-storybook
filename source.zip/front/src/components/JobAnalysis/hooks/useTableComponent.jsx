import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import ReactTable from '../../common/atoms/Table/ReactTable';
import useResultInfo from '../../../hooks/common/useResultInfo';
import { GraphDateRegex } from '@libs/util/regExp';

const tmpFilterFormat = {
  lot_id: [
    {
      logical_type: 'default',
      data_type: 'string',
      condition: {
        filter_type: 'match',
        filter_value: 'test',
      }
    },
    {
      logical_type: 'or',
      data_type: 'string',
      condition: {
        filter_type: 'match',
        filter_value: '2',
      }
    },
  ],
}

const searchKey = (data) => {
  let result = Object.keys(data).find((v) => v === 'period')
    ? 'period'
    : undefined;

  if (!result) {
    for (const key of Object.keys(data)) {
      if (GraphDateRegex.test(data[key])) {
        result = key;
        break;
      }
    }
  }
  return result;
};

const filteringTableData = (list, data) => {
  if (!Object.keys(list).length) return data;
  const result = Array(data.length).fill(0);
  let idx = 0;

  data.forEach((row) => {
    let isAdd = false;

    for (const [key, item] of Object.entries(list)) {
      let innerCheckFlag = checkValue(row[key], item[0].condition);

      if (
        !innerCheckFlag &&
        !item.slice(1).filter(({ logical_type }) => logical_type === 'or').length
      ) {
        break;
      }

      for (const { logical_type, condition } of item.slice(1)) {
        if (innerCheckFlag) {
          if (logical_type === 'or') {
            continue;
          }
        } else {
          if (logical_type === 'and') {
            continue;
          }
        }

        innerCheckFlag = checkValue(row[key], condition);
      }

      isAdd = innerCheckFlag;
    }

    if (isAdd) {
      result[idx] = row;
      idx++;
    }
  });

  return result.filter((v) => v !== 0);
};

const checkValue = (value, { filter_type, filter_value }) => {
  let isValid = false;

  switch (filter_type) {
    case 'more':
      if (value >= filter_value) isValid = true;
      break;

    case 'less':
      if (value <= filter_value) isValid = true;
      break;

    case 'over':
      if (value > filter_value) isValid = true;
      break;

    case 'under':
      if (value < filter_value) isValid = true;
      break;

    case 'equal':
    case 'match':
      if (value === filter_value) isValid = true;
      break;

    case 'not_match':
      if (value !== filter_value) isValid = true;
      break;

    case 'include':
      if (value.includes(filter_value)) isValid = true;
      break;

    case 'start':
      if (value.startsWith(filter_value)) isValid = true;
      break;

    case 'end':
      if (value.endsWith(filter_value)) isValid = true;
      break;

    default:
      break;
  }

  return isValid;
};

const AnalysisTableComponent = ({ tableOrder, tableData }) => {
  const columnData = useMemo(() => tableOrder, [JSON.stringify(tableOrder)]);
  const rowData = useMemo(() => tableData, [JSON.stringify(tableData)]);

  return <ReactTable columns={columnData} data={rowData} />;
};

AnalysisTableComponent.displayName = 'TableComponent';
AnalysisTableComponent.propTypes = {
  tableOrder: PropTypes.array.isRequired,
  tableData: PropTypes.array.isRequired,
};

export default AnalysisTableComponent;
