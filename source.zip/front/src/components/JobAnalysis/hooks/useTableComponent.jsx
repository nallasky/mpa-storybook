import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import ReactTable from '../../common/atoms/Table/ReactTable';
import useResultInfo from '../../../hooks/common/useResultInfo';
import { GraphDateRegex } from '@libs/util/regExp';

const searchKey = (data) => {
  let tmpKey = Object.keys(data).find((v) => v === 'period')
    ? 'period'
    : undefined;

  if (tmpKey === undefined) {
    Object.keys(data).forEach((x) => {
      if (GraphDateRegex.test(data[x])) {
        tmpKey = x;
      }
    });
  }
  return tmpKey;
};

const filteringTableData = (list, data) => {
  return data.reduce((acc, row) => {
    let isAdd = false;

    for (const [key, item] of Object.entries(list)) {
      let innerCheckFlag = checkValue(row[key], item.default);

      if (!innerCheckFlag && item.conditions.filter(({type}) => type === 'or').length === 0) {
        break;
      }

      for (const subItem of item.conditions) {
        if (subItem.type === 'and' && !innerCheckFlag) {
          continue;
        }

        innerCheckFlag = checkValue(row[key], subItem.condition);
      }

      isAdd = innerCheckFlag;
    }

    return isAdd ? [...acc, row] : acc;
  }, []);
};

const checkValue = (value, { main, sub }) => {
  let isValid = false;

  switch(main) {
    case 'more':
      if (value >= sub) isValid = true;
      break;

    case 'less':
      if(value <= sub) isValid = true;
      break;

    case 'over':
      if(value > sub) isValid = true;
      break;

    case 'under':
      if(value < sub) isValid = true;
      break;

    case 'equal':
    case 'match':
      if(value === sub) isValid = true;
      break;

    case 'not_match':
      if (value !== sub) isValid = true;
      break;

    case 'include':
      if (value.includes(sub)) isValid = true;
      break;

    case 'start':
      if(value.startsWith(sub)) isValid = true;
      break;

    case 'end':
      if(value.endsWith(sub)) isValid = true;
      break;

    default:
      break;
  }

  return isValid;
};

const AnalysisTableComponent = ({ tableOrder, tableData, selectRow }) => {
  const { savedAnalysisAggregation, setSelectedRow } = useResultInfo();
  const columnData = useMemo(() => tableOrder, [JSON.stringify(tableOrder)]);
  const rowData = useMemo(() => tableData, [JSON.stringify(tableData)]);

  const changeSelectedRow = (v) => {
    const key =
      savedAnalysisAggregation.main.toLowerCase() === 'period'
        ? searchKey(tableData[0])
        : savedAnalysisAggregation.main.toLowerCase().indexOf('all') === -1
        ? savedAnalysisAggregation.sub
        : undefined;

    if (key !== undefined) {
      setSelectedRow(
        v.reduce((acc, i) => {
          if (
            tableData[i]['No.'] === undefined ||
            tableData[i]['No.'] !== 'ALL'
          )
            acc.push(tableData[i][key]);
          return acc;
        }, []),
      );
    } else {
      setSelectedRow(['all']);
    }
  };

  return (
    <ReactTable
      columns={columnData}
      data={rowData}
      disableSelectRows={!selectRow}
      func={changeSelectedRow}
    />
  );
};

AnalysisTableComponent.displayName = 'TableComponent';
AnalysisTableComponent.propTypes = {
  tableOrder: PropTypes.array.isRequired,
  tableData: PropTypes.array.isRequired,
  selectRow: PropTypes.bool.isRequired,
  func: PropTypes.func,
};

export default AnalysisTableComponent;
