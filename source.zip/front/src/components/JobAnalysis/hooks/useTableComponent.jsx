import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import ReactTable from '../../common/atoms/Table/ReactTable';

const AnalysisTableComponent = ({ tableOrder, tableData, type }) => {
  const columnData = useMemo(() => tableOrder, [JSON.stringify(tableOrder)]);
  const rowData = useMemo(() => tableData, [JSON.stringify(tableData)]);

  return (
    <ReactTable
      columns={columnData}
      data={rowData}
      useColumnFilter={type === 'data'}
    />
  );
};

AnalysisTableComponent.displayName = 'TableComponent';
AnalysisTableComponent.propTypes = {
  tableOrder: PropTypes.array.isRequired,
  tableData: PropTypes.array.isRequired,
  type: PropTypes.string,
};

export default AnalysisTableComponent;
