import React, { useCallback, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import dayjs from 'dayjs';
import { Button, Input, Select, DatePicker } from 'antd';
import { SettingOutlined, SyncOutlined } from '@ant-design/icons';
import { useLocation } from 'react-router-dom';
import {
  displayNotification,
  createAnalysisData,
  RenderSelectOptions,
} from '@libs/util/common/functionGroup';
import { default as Btn } from '../../common/atoms/Button';
import useResultInfo from '../../../hooks/common/useResultInfo';
import { DATE_FORMAT } from '@constants/etc';
import { getAnalysisData } from '@libs/axios/requests';
import * as sg from '../styles/useHeaderSettingStyles';

const createGraphData = (obj, isMulti) => {
  let tmpObj = {};

  const createData = (data) => {
    let i = 0;

    return Object.keys(data).reduce((acc, v) => {
      acc[i] = data[v];
      i++;
      return acc;
    }, {});
  };

  if (isMulti) {
    Object.keys(obj).forEach((v) => {
      tmpObj[v] = createData(obj[v]);
    });
  } else {
    tmpObj = createData(obj);
  }

  return tmpObj;
};

const initPeriod = (period) => {
  return period.selected !== undefined && period.selected.length > 0
    ? [
        period.selected[0].length > 0 ? dayjs(period.selected[0]) : '',
        period.selected[1].length > 0 ? dayjs(period.selected[1]) : '',
      ]
    : ['', ''];
};

const initAggregation = (aggregation) => {
  return aggregation === undefined
    ? {}
    : {
        main: Object.keys(aggregation).length > 0 ? aggregation.selected : '',
        sub:
          Object.keys(aggregation).length > 0
            ? aggregation.selected.toLowerCase().indexOf('all') === -1 &&
              aggregation.selected.length > 0
              ? aggregation.subItem[aggregation.selected].selected
              : ''
            : '',
      };
};

const HeaderSetting = ({
  period,
  aggregation,
  loadingSet,
  useUpdate,
}) => {
  const { func_id, job_type, source_type } = useLocation().state;
  const {
    analysisData,
    setAnalysisInfo,
    setOriginalInfo,
    setOriginalFilteredRows,
    setAnalysisFilteredRows,
    setSavedAnalysisAggregation,
    selectedDatabase,
    selectedEquipment,
  } = useResultInfo();
  const [periodVal, setPeriodVal] = useState(['', '']);
  const [showPopup, setShowPopup] = useState(false);
  const [aggregationVal, setAggregationVal] = useState({});
  const [beforeInfo, setBeforeInfo] = useState(null);

  const closeRangePicker = () => {
    if (showPopup) {
      setShowPopup(false);
    }
  };

  const closePopup = () => {
    setShowPopup(false);
    setAggregationVal(beforeInfo);
  };

  const changeAggregation = (key, val) => {
    setAggregationVal((prevState) => {
      if (key === 'main' && val.toLowerCase().indexOf('all') === -1) {
        return {
          main: val,
          sub: aggregation.subItem[val].selected,
        };
      } else {
        return {
          ...prevState,
          [key]: val,
        };
      }
    });
  };

  const changePeriod = (date) => {
    setPeriodVal(date);
  };

  const applyFilter = async () => {
    let description = '';

    setShowPopup(false);
    loadingSet(true);

    if (Object.keys(aggregation).length > 0 &&
      aggregationVal.main.indexOf('all') === -1 &&
      (aggregationVal.sub === null || aggregationVal.sub === '')) {
      displayNotification({
        message: 'Filter Setting Error',
        description:
          'There are some items that have not been set yet. Please check the item.',
        duration: 3,
        style: { borderLeft: '5px solid red' },
      });
    } else {
      const param = {
        fId: func_id,
        rId: analysisData.jobId,
        start:
          periodVal === null || periodVal[0].length === 0
            ? period.start
            : periodVal[0].format(DATE_FORMAT),
        end:
          periodVal === null || periodVal[1].length === 0
            ? period.end
            : periodVal[1].format(DATE_FORMAT),
        agMain: aggregationVal.main,
        agSub: aggregationVal.sub,
      };

      const { data, option, message } = await getAnalysisData(
        param,
        analysisData.type,
        job_type === 'remote' || source_type === 'remote'
          ? { db_id: selectedDatabase, equipment_name: selectedEquipment }
          : undefined,
      );

      if (message === '') {
        const newData = createAnalysisData(analysisData.type, data, 'row');
        setOriginalFilteredRows({});
        setOriginalInfo({
          period: {},
          filter: [],
          aggregation: {},
          dispOrder: [],
          dispGraph: [],
          data: {},
        });
        setAnalysisInfo({
          ...analysisData,
          period: option.period,
          filter: option.filter,
          aggregation: option.aggregation ?? {},
          dispOrder: createAnalysisData(
            analysisData.type,
            data,
            'disp_order',
          ),
          dispGraph: createAnalysisData(
            analysisData.type,
            data,
            'disp_graph',
          ),
          data: newData,
        });
        setAnalysisFilteredRows(newData);
      } else {
        description = message;
      }
    }


    setBeforeInfo(aggregationVal);
    loadingSet(false);

    if (description !== '') {
      displayNotification({
        message: 'Update failed',
        description: description,
        duration: 3,
        style: { borderLeft: '5px solid red' },
      });
    }
  };

  const disabledDate = useCallback(
    (v) => {
      return Object.keys(period).length === 0
        ? false
        : v &&
            (dayjs(v).isBefore(dayjs(period.start), 'd') ||
              dayjs(v).isAfter(dayjs(period.end), 'd'));
    },
    [JSON.stringify(period)],
  );

  useEffect(() => {
    setPeriodVal(initPeriod(period));
  }, [period]);

  useEffect(() => {
    const newAgg = initAggregation(aggregation);
    setAggregationVal(newAgg);
    setBeforeInfo(newAgg);
    if (type === 'analysis') {
      setSavedAnalysisAggregation(newAgg);
    }
  }, [aggregation]);

  useEffect(() => {
    return () => {
      if (type !== 'analysis') {
        setOriginalFilteredRows({});
        setOriginalInfo({});
      }
      return null;
    };
  }, []);

  return (
    <div className="header-wrapper">
      <div className="popup-wrapper">
        <span>Period:</span>
        <DatePicker.RangePicker
          value={periodVal}
          onOpenChange={closeRangePicker}
          onChange={changePeriod}
          disabledDate={disabledDate}
          disabled={!useUpdate}
          showTime
          placeholder={[period.start, period.end]}
          inputReadOnly
          allowClear={false}
        />
        {aggregation !== undefined &&
        Object.keys(aggregation).length > 0 && (
          <>
            <div className="filter-component">
              <Button
                type="dashed"
                shape="circle"
                icon={<SettingOutlined />}
                onClick={() => setShowPopup(true)}
              />
              <div>Filter Setting</div>
              <div
                css={[
                  sg.popupBackground,
                  showPopup ? { display: 'block' } : '',
                ]}
                onClick={() => closePopup()}
                onKeyDown={() => closePopup()}
                role="button"
                tabIndex="0"
              />
              <div css={[sg.popupStyle, showPopup ? { display: 'block' } : '']}>
                <div>Filter Setting</div>
                <div>
                  {Object.keys(aggregationVal).length > 0 && (
                    <div>
                      <div>{aggregation.title + ':'}</div>
                      <div
                        css={
                          aggregationVal.main.toLowerCase().indexOf('all') !==
                          -1
                            ? sg.aggSingleItemWrapper
                            : sg.aggregationWrapper
                        }
                      >
                        <Select
                          value={aggregationVal.main}
                          style={{ fontSize: '12px', width: '100%' }}
                          onChange={(val) => changeAggregation('main', val)}
                        >
                          {aggregation.options.map(RenderSelectOptions)}
                        </Select>
                        {aggregationVal.main.toLowerCase().indexOf('all') ===
                          -1 &&
                        aggregation.subItem[aggregationVal.main] !==
                          undefined ? (
                          aggregation.subItem[aggregationVal.main].type ===
                          'select' ? (
                            <Select
                              value={aggregationVal.sub}
                              style={{
                                fontSize: '12px',
                                width: '100%',
                                marginLeft: '0.5rem',
                              }}
                              onChange={(val) => changeAggregation('sub', val)}
                            >
                              {aggregation.subItem[
                                aggregationVal.main
                              ].options.map(RenderSelectOptions)}
                            </Select>
                          ) : (
                            <Input
                              value={aggregationVal.sub}
                              style={{
                                fontSize: '12px',
                                marginLeft: '0.5rem',
                              }}
                              onChange={(e) =>
                                changeAggregation('sub', e.target.value)
                              }
                            />
                          )
                        ) : (
                          ''
                        )}
                      </div>
                    </div>
                  )}
                </div>
                <div>
                  <Button type="primary" onClick={applyFilter}>
                    {type === 'analysis' || useUpdate ? 'Save' : 'Apply'}
                  </Button>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
      {type === 'analysis' || useUpdate && (
        <div>
          <Btn
            theme="white"
            style={{ fontWeight: 'normal' }}
            onClick={applyFilter}
          >
            <SyncOutlined /> Update
          </Btn>
        </div>
      )}
    </div>
  );
};

HeaderSetting.displayName = 'HeaderSetting';
HeaderSetting.propTypes = {
  period: PropTypes.object.isRequired,
  aggregation: PropTypes.object,
  loadingSet: PropTypes.func,
  useUpdate: PropTypes.bool.isRequired,
};

export default HeaderSetting;
