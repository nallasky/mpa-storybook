import React from 'react';
import PropTypes from 'prop-types';
import dayjs from 'dayjs';
import { Button, DatePicker } from 'antd';
import { SettingOutlined, SyncOutlined } from '@ant-design/icons';
import { filteringTableData, periodFilteringData} from '@libs/util/common/functionGroup';
import { default as Btn } from '../../common/atoms/Button';
import useResultInfo from '../../../hooks/common/useResultInfo';
import useModal from "@libs/util/modalControl/useModal";
import FilterModal from "@components/JobAnalysis/hooks/FilterModal";
import { DATE_FORMAT } from "@constants/etc";

const HeaderSetting = ({ period, loadingSet, type }) => {
  const { originalData, setOriginalFilteredRows, setOriginalInfo } = useResultInfo();
  const { openModal } = useModal();

  const changePeriod = (date) => {
    setOriginalInfo({
      ...originalData,
      period: {
        ...originalData.period,
        selected: [dayjs(date[0]).format(DATE_FORMAT), dayjs(date[1]).format(DATE_FORMAT)],
      }
    })
  };

  const applyFilter = () => {
    loadingSet(true);
    if ((Object.keys(originalData.period).length && !!originalData.period.selected[0])
      || Object.keys(originalData.filter).length) {
      setOriginalFilteredRows(
        filteringTableData(originalData.filter,
          !!originalData.period.selected[0]
            ? periodFilteringData(originalData.period.selected, originalData.data)
            : originalData.data)
      );
    }
    setTimeout(() => loadingSet(false), 2000);
  };

  const disabledDate = (v) => {
    return !Object.keys(period).length
      ? false
      : v &&
          (dayjs(v).isBefore(dayjs(period.start), 'd') ||
            dayjs(v).isAfter(dayjs(period.end), 'd'));
  };

  return (
    <div className="header-wrapper">
      <div className="popup-wrapper">
        <span>Period:</span>
        <DatePicker.RangePicker
          value={originalData.period.selected ? [
            !!originalData.period.selected[0] ? dayjs(period.selected[0]) : '',
            !!originalData.period.selected[1] ? dayjs(period.selected[1]) : '',
          ] : ['', '']}
          onChange={changePeriod}
          disabledDate={disabledDate}
          disabled={type !== 'data'}
          showTime
          placeholder={[period.start, period.end]}
          inputReadOnly
          allowClear={false}
        />
        <Button
          type="dashed"
          shape="circle"
          icon={<SettingOutlined />}
          title="Filter Setting"
          onClick={() => openModal(FilterModal, { loadingSet })}
        />
      </div>
      {type === 'data' && (
        <div>
          <Btn
            theme="white"
            style={{ fontWeight: 'normal' }}
            onClick={applyFilter}
          >
            <SyncOutlined /> Update
          </Btn>
        </div>
      )}
    </div>
  );
};

HeaderSetting.displayName = 'HeaderSetting';
HeaderSetting.propTypes = {
  period: PropTypes.object.isRequired,
  type: PropTypes.string.isRequired,
  loadingSet: PropTypes.func,
};

export default HeaderSetting;
