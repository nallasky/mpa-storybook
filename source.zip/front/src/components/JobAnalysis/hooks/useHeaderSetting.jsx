import React from 'react';
import PropTypes from 'prop-types';
import { useLocation } from 'react-router-dom';
import dayjs from 'dayjs';
import { Button, DatePicker } from 'antd';
import { SettingOutlined, SyncOutlined } from '@ant-design/icons';
import {
  filteringTableData,
  periodFilteringData,
  usePrevious,
  remoteUpdateCheck,
  disabledDate,
} from '@libs/util/common/functionGroup';
import { default as Btn } from '../../common/atoms/Button';
import useResultInfo from '../../../hooks/common/useResultInfo';
import useModal from '@libs/util/modalControl/useModal';
import FilterModal from '@components/JobAnalysis/hooks/FilterModal';
import { DATE_FORMAT } from '@constants/etc';

const HeaderSetting = ({ period, loadingSet, type }) => {
  const { job_type, source_type, func_id } = useLocation().state;
  const {
    originalData,
    selectedDatabase,
    selectedEquipment,
    setOriginalFilteredRows,
    setOriginalInfo,
    setAnalysisInfo,
    setRemoteApplyInfo,
  } = useResultInfo();
  const { openModal } = useModal();
  const beforePeriod = usePrevious(originalData.period.selected);

  const changePeriod = (date) => {
    setOriginalInfo({
      ...originalData,
      period: {
        ...originalData.period,
        selected: date.map((v) => dayjs(v).format(DATE_FORMAT)),
      },
    });
  };

  const onUpdate = async () => {
    if (
      (job_type === 'remote' || source_type === 'remote') &&
      remoteUpdateCheck(beforePeriod, originalData.period.selected)
    ) {
      setRemoteApplyInfo({
        type: 'header',
        func_id,
        db_id: selectedDatabase,
        equipment_name: selectedEquipment,
        period: originalData.period,
        beforePeriod,
        filter: originalData.filter,
      });
    } else {
      loadingSet(true);
      if (
        JSON.stringify(originalData.period.selected) !==
        JSON.stringify(beforePeriod)
      ) {
        setOriginalFilteredRows(
          filteringTableData(
            originalData.filter,
            periodFilteringData(
              originalData.period.selected,
              originalData.multiCurrentTable
                ? originalData.data[originalData.multiCurrentTable]
                : originalData.data,
            ),
          ),
        );
        setAnalysisInfo({
          dispOrder: [],
          dispGraph: [],
          data: {},
          common_axis_x: [],
          multiCurrentTable: '',
        });
      }
      setTimeout(() => loadingSet(false), 2000);
    }
  };

  return (
    <>
      <div className="header-wrapper">
        <div className="popup-wrapper">
          <span>Period:</span>
          <DatePicker.RangePicker
            value={
              originalData.period.selected
                ? [
                    originalData.period.selected[0]
                      ? dayjs(period.selected[0])
                      : '',
                    originalData.period.selected[1]
                      ? dayjs(period.selected[1])
                      : '',
                  ]
                : ['', '']
            }
            onChange={changePeriod}
            disabledDate={(v) => disabledDate([period.start, period.end], v)}
            disabled={type !== 'data'}
            showTime
            placeholder={[period.start, period.end]}
            inputReadOnly
            allowClear={false}
          />
          <Button
            type="dashed"
            shape="circle"
            icon={<SettingOutlined />}
            title="Filter Setting"
            onClick={() =>
              openModal(FilterModal, {
                loadingSet,
                type,
                beforePeriod,
              })
            }
          />
        </div>
        {type === 'data' && (
          <div>
            <Btn
              theme="white"
              style={{ fontWeight: 'normal' }}
              onClick={onUpdate}
            >
              <SyncOutlined /> Update
            </Btn>
          </div>
        )}
      </div>
    </>
  );
};

HeaderSetting.displayName = 'HeaderSetting';
HeaderSetting.propTypes = {
  period: PropTypes.object.isRequired,
  type: PropTypes.string.isRequired,
  loadingSet: PropTypes.func,
};

export default HeaderSetting;
