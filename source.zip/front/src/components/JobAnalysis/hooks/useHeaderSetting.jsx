import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import dayjs from 'dayjs';
import { Button, Input, Select, DatePicker } from 'antd';
import { SettingOutlined, SyncOutlined } from '@ant-design/icons';
import { displayNotification, RenderSelectOptions } from '@libs/util/common/functionGroup';
import { default as Btn } from '../../common/atoms/Button';
import useResultInfo from '../../../hooks/common/useResultInfo';
import * as sg from '../styles/useHeaderSettingStyles';

const createGraphData = (obj, isMulti) => {
  let tmpObj = {};

  const createData = (data) => {
    let i = 0;

    return Object.keys(data).reduce((acc, v) => {
      acc[i] = data[v];
      i++;
      return acc;
    }, {});
  };

  if (isMulti) {
    Object.keys(obj).forEach((v) => {
      tmpObj[v] = createData(obj[v]);
    });
  } else {
    tmpObj = createData(obj);
  }

  return tmpObj;
};

const initPeriod = (period) => {
  return !!period.selected && period.selected.length
    ? [
        period.selected[0].length > 0 ? dayjs(period.selected[0]) : '',
        period.selected[1].length > 0 ? dayjs(period.selected[1]) : '',
      ]
    : ['', ''];
};

const initAggregation = (aggregation) => {
  return aggregation === undefined
    ? {}
    : {
        main: Object.keys(aggregation).length ? aggregation.selected : '',
        sub:
          Object.keys(aggregation).length
            ? aggregation.selected.toLowerCase().indexOf('all') === -1 &&
              aggregation.selected.length
              ? aggregation.subItem[aggregation.selected].selected
              : ''
            : '',
      };
};

const HeaderSetting = ({ period, aggregation, loadingSet, type }) => {
  const { setSavedAnalysisAggregation } = useResultInfo();
  const [periodVal, setPeriodVal] = useState(['', '']);
  const [showPopup, setShowPopup] = useState(false);
  const [aggregationVal, setAggregationVal] = useState({});
  const [beforeInfo, setBeforeInfo] = useState(null);

  const closeRangePicker = () => {
    if (showPopup) {
      setShowPopup(false);
    }
  };

  const closePopup = () => {
    setShowPopup(false);
    setAggregationVal(beforeInfo);
  };

  const changeAggregation = (key, val) => {
    setAggregationVal((prevState) => {
      if (key === 'main' && val.toLowerCase().indexOf('all') === -1) {
        return {
          main: val,
          sub: aggregation.subItem[val].selected,
        };
      } else {
        return {
          ...prevState,
          [key]: val,
        };
      }
    });
  };

  const changePeriod = (date) => {
    setPeriodVal(date);
  };

  const applyFilter = async () => {
    let description = '';

    setShowPopup(false);
    loadingSet(true);

    if (
      Object.keys(aggregation).length &&
      aggregationVal.main.indexOf('all') === -1 &&
      !aggregationVal.sub
    ) {
      displayNotification({
        message: 'Filter Setting Error',
        description:
          'There are some items that have not been set yet. Please check the item.',
        duration: 3,
        style: { borderLeft: '5px solid red' },
      });
    }

    setBeforeInfo(aggregationVal);
    loadingSet(false);

    if (description !== '') {
      displayNotification({
        message: 'Update failed',
        description: description,
        duration: 3,
        style: { borderLeft: '5px solid red' },
      });
    }
  };

  const disabledDate = (v) => {
    return !Object.keys(period).length
      ? false
      : v &&
          (dayjs(v).isBefore(dayjs(period.start), 'd') ||
            dayjs(v).isAfter(dayjs(period.end), 'd'));
  };

  useEffect(() => {
    setPeriodVal(initPeriod(period));
  }, [period]);

  useEffect(() => {
    const newAgg = initAggregation(aggregation);
    setAggregationVal(newAgg);
    setBeforeInfo(newAgg);
    if (type === 'data') {
      setSavedAnalysisAggregation(newAgg);
    }
  }, [aggregation]);

  return (
    <div className="header-wrapper">
      <div className="popup-wrapper">
        <span>Period:</span>
        <DatePicker.RangePicker
          value={periodVal}
          onOpenChange={closeRangePicker}
          onChange={changePeriod}
          disabledDate={disabledDate}
          disabled={type !== 'data'}
          showTime
          placeholder={[period.start, period.end]}
          inputReadOnly
          allowClear={false}
        />
        <Button
          type="dashed"
          shape="circle"
          icon={<SettingOutlined />}
          onClick={() => setShowPopup(true)}
          title="Filter Setting"
        />
      </div>
      {type === 'data' && (
        <div>
          <Btn
            theme="white"
            style={{ fontWeight: 'normal' }}
            onClick={applyFilter}
          >
            <SyncOutlined /> Update
          </Btn>
        </div>
      )}
    </div>
  );
};

HeaderSetting.displayName = 'HeaderSetting';
HeaderSetting.propTypes = {
  period: PropTypes.object.isRequired,
  type: PropTypes.string.isRequired,
  aggregation: PropTypes.object,
  loadingSet: PropTypes.func,
};

export default HeaderSetting;
