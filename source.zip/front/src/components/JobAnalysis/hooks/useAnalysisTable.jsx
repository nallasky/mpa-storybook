import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Select, Empty } from 'antd';
import HeaderSetting from './useHeaderSetting';
import AnalysisTableComponent from './useTableComponent';
import { RenderSelectOptions } from '@libs/util/common/functionGroup';
import * as sg from '../styles/useAnalysisTableStyles';

const createDataSource = (data, idx) => {
  if ((Array.isArray(data) && !data.length) || (!Array.isArray(data) && !Object.keys(data).length)) return undefined;

  const dataObj =
    idx === 'single'
      ? data
      : typeof idx === 'number'
      ? Object.values(data)[idx]
      : data[idx];
  const result = Array(Object.keys(dataObj).length).fill(0);
  Object.keys(dataObj).forEach((k, i) => {
    result[i] = {
      ...dataObj[k],
      key: i
    }
  });
  return result;
};

const createColumns = (data, idx) => {
  if ((Array.isArray(data) && !data.length) || (!Array.isArray(data) && !Object.keys(data).length)) return undefined;
  const tmpData = Array.isArray(data)
    ? data
    : typeof idx === 'number'
    ? Object.values(data)[idx]
    : data[idx];
  const result = Array(tmpData.length).fill(0);
  tmpData.forEach((v, i) => {
    result[i] = {
      Header: v,
      accessor: (value) => (v === 'No.' ? value['No.'] : value[v]),
    }
  });
  return result;
};

const AnalysisTable = ({
  period,
  aggregation,
  tableOrder,
  tableData,
  type,
  onLoad,
}) => {
  const [currentColumn, setCurrentColumn] = useState(undefined);
  const [currentRow, setCurrentRow] = useState(undefined);
  const [currentTable, setCurrentTable] = useState(undefined);

  const changeTable = (v) => {
    setCurrentTable(v);
    setCurrentColumn(createColumns(tableOrder, v));
    setCurrentRow(createDataSource(tableData, v));
  };

  useEffect(() => {
    setCurrentColumn(createColumns(tableOrder, 0));
    setCurrentRow(
      createDataSource(tableData, !Array.isArray(tableOrder) ? 0 : 'single'),
    );
    if (!Array.isArray(tableOrder) && !currentTable) {
      setCurrentTable(Object.keys(tableOrder)[0]);
    }
  }, [tableOrder, tableData]);

  return (
    <div css={sg.mainWrapper}>
      <HeaderSetting
        period={period}
        aggregation={aggregation}
        loadingSet={onLoad}
        type={type}
      />
      {currentColumn && currentRow ? (
        <div className="table-wrapper">
          <div>{type === 'analysis' ? 'Analysis Result' : 'Original Data'}</div>
          <div>
            {!Array.isArray(tableOrder) && (
              <div className="select-wrapper">
                <span>Current table:</span>
                <Select
                  value={currentTable}
                  style={{ width: '300px', marginLeft: '0.5rem' }}
                  onChange={changeTable}
                >
                  {Object.keys(tableOrder).map(RenderSelectOptions)}
                </Select>
              </div>
            )}
            {currentRow.length ? (
              <AnalysisTableComponent
                tableData={currentRow}
                tableOrder={currentColumn}
              />
            ) : (
              <div css={sg.emptyWrapper}>
                <Empty />
              </div>
            )}
          </div>
        </div>
      ) : (
        <div css={sg.emptyWrapper}>
          <Empty />
        </div>
      )}
    </div>
  );
};

AnalysisTable.displayName = 'AnalysisTable';
AnalysisTable.propTypes = {
  period: PropTypes.object.isRequired,
  aggregation: PropTypes.object,
  tableOrder: PropTypes.oneOfType([PropTypes.array, PropTypes.object])
    .isRequired,
  tableData: PropTypes.object.isRequired,
  type: PropTypes.string.isRequired,
  onLoad: PropTypes.func,
};

export default AnalysisTable;
