import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Select, Empty } from 'antd';
import HeaderSetting from './useHeaderSetting';
import AnalysisTableComponent from './useTableComponent';
import { RenderSelectOptions } from '@libs/util/common/functionGroup';
import * as sg from '../styles/useAnalysisTableStyles';

const createDataSource = (data, idx) => {
  if (data.length === 0 || Object.keys(data).length === 0) return undefined;

  const dataObj =
    idx === 'single'
      ? data
      : typeof idx === 'number'
      ? Object.values(data)[idx]
      : data[idx];

  return Object.keys(dataObj).reduce((acc, k, i) => {
    const tmpObj = Object.assign({}, dataObj[k]);
    tmpObj['key'] = i;
    acc.push(tmpObj);
    return acc;
  }, []);
};

const createColumns = (data, idx) => {
  if (data.length === 0 || Object.keys(data).length === 0) return undefined;

  const tmpData = Array.isArray(data)
    ? data
    : typeof idx === 'number'
    ? Object.values(data)[idx]
    : data[idx];
  const tmpArr = [];

  tmpData.reduce((acc, v) => {
    acc.push({
      Header: v,
      accessor: (value) => (v === 'No.' ? value['No.'] : value[v]),
    });
    return acc;
  }, tmpArr);

  return tmpArr.length > 0 ? tmpArr : undefined;
};

const filteringData = (orgData, filter) => {
  if (orgData === undefined) {
    return [];
  }

  return orgData.reduce((acc, v) => {
    let isValid = true;

    Object.keys(filter).forEach((i) => {
      if (isValid) {
        if (Array.isArray(filter[i])) {
          if (filter[i].findIndex((j) => v[i] === j) === -1) {
            isValid = false;
          }
        } else {
          if (filter[i] !== v[i]) {
            isValid = false;
          }
        }
      }
    });

    if (isValid) {
      acc.push(v);
    }
    return acc;
  }, []);
};

const AnalysisTable = ({
  period,
  aggregation,
  tableOrder,
  tableData,
  type,
  onLoad,
  useUpdate,
  detailType,
}) => {
  const [currentColumn, setCurrentColumn] = useState(undefined);
  const [currentRow, setCurrentRow] = useState(undefined);
  const [currentTable, setCurrentTable] = useState(undefined);

  const changeTable = (v) => {
    setCurrentTable(v);
    setCurrentColumn(createColumns(tableOrder, v));
    setCurrentRow(createDataSource(tableData, v));
  };

  useEffect(() => {
    setCurrentColumn(createColumns(tableOrder, 0));
    setCurrentRow(createDataSource(tableData, !Array.isArray(tableOrder) ? 0 : 'single'));
    if (!Array.isArray(tableOrder) && currentTable === undefined) {
      setCurrentTable(Object.keys(tableOrder)[0]);
    }
  }, [tableOrder, tableData]);

  return (
    <div css={sg.mainWrapper}>
      {aggregation !== undefined &&
      Object.keys(aggregation).length > 0 &&
      period.start !== null &&
      period.end !== null &&
      period.select.length > 0 &&
      type === 'analysis' && (
        <HeaderSetting
          period={period}
          aggregation={aggregation}
          loadingSet={onLoad}
          useUpdate={useUpdate}
        />
      )}
      {currentColumn && currentRow ? (
        <div className="table-wrapper">
          <div>{type === 'analysis' ? 'Analysis Result' : 'Original Data'}</div>
          <div>
            {!Array.isArray(tableOrder) && (
              <div className="select-wrapper">
                <span>Current table:</span>
                <Select
                  value={currentTable}
                  style={{ width: '300px', marginLeft: '0.5rem' }}
                  onChange={changeTable}
                >
                  {Object.keys(tableOrder).map(RenderSelectOptions)}
                </Select>
              </div>
            )}
            {currentRow.length > 0 ? (
              <AnalysisTableComponent
                tableData={currentRow}
                tableOrder={currentColumn}
                selectRow={
                  type === 'analysis' && detailType.match(/setting/) !== null
                }
              />
            ) : (
              <div css={sg.emptyWrapper}>
                <Empty />
              </div>
            )}
          </div>
        </div>
      ) : (
        <div css={sg.emptyWrapper}>
          <Empty />
        </div>
      )}
    </div>
  );
};

AnalysisTable.displayName = 'AnalysisTable';
AnalysisTable.propTypes = {
  period: PropTypes.object.isRequired,
  aggregation: PropTypes.object,
  tableOrder: PropTypes.oneOfType([PropTypes.array, PropTypes.object])
    .isRequired,
  tableData: PropTypes.object.isRequired,
  type: PropTypes.string.isRequired,
  onLoad: PropTypes.func,
  useUpdate: PropTypes.bool.isRequired,
  detailType: PropTypes.string,
};

export default AnalysisTable;
