import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Select, Empty } from 'antd';
import HeaderSetting from './useHeaderSetting';
import AnalysisTableComponent from './useTableComponent';
import {
  RenderSelectOptions,
  usePrevious,
  filteringTableData,
  periodFilteringData,
} from '@libs/util/common/functionGroup';
import useResultInfo from '@hooks/common/useResultInfo';
import * as sg from '../styles/useAnalysisTableStyles';

const createDataSource = (data) => {
  if (
    (Array.isArray(data) && !data.length) ||
    (!Array.isArray(data) && !Object.keys(data).length)
  )
    return undefined;
  const result = Array(Object.keys(data).length).fill(0);
  Object.keys(data).forEach((k, i) => {
    result[i] = {
      ...data[k],
      key: i,
    };
  });
  return result;
};

const createColumns = (data, idx, filter) => {
  if (
    (Array.isArray(data) && !data.length) ||
    (!Array.isArray(data) && !Object.keys(data).length)
  )
    return undefined;
  const tmpData = Array.isArray(data)
    ? data
    : typeof idx === 'number'
    ? Object.values(data)[idx]
    : data[idx];
  const result = Array(tmpData.length).fill(0);
  tmpData.forEach((v, i) => {
    result[i] = {
      Header: v,
      accessor: (value) => (v === 'No.' ? value['No.'] : value[v]),
      filtered: !Object.keys(filter).length
        ? false
        : !!Object.keys(filter).find((k) => k === v),
    };
  });
  return result;
};

const AnalysisTable = ({
  period,
  aggregation,
  tableOrder,
  tableData,
  filter,
  type,
  onLoad,
}) => {
  const { originalData, analysisData, setOriginalInfo, setAnalysisInfo } =
    useResultInfo();
  const [currentColumn, setCurrentColumn] = useState(undefined);
  const [currentRow, setCurrentRow] = useState(undefined);
  const beforeFilter = usePrevious(filter);

  const changeTable = (v) => {
    if (type === 'data') {
      setOriginalInfo({
        ...originalData,
        multiCurrentTable: v,
      });
    } else {
      setAnalysisInfo({
        ...analysisData,
        multiCurrentTable: v,
      });
    }
    setCurrentColumn(createColumns(tableOrder, v, filter));
    setCurrentRow(
      createDataSource(
        type === 'data'
          ? filteringTableData(
              filter,
              periodFilteringData(
                originalData.period.selected,
                originalData.data[v],
              ),
            )
          : analysisData.data[v],
      ),
    );
  };

  useEffect(() => {
    const idx = Array.isArray(tableOrder)
      ? 0
      : type === 'data'
      ? originalData.multiCurrentTable
      : analysisData.multiCurrentTable;
    setCurrentColumn(createColumns(tableOrder, idx, filter));
    setCurrentRow(createDataSource(tableData));
  }, [tableOrder, tableData]);

  useEffect(() => {
    if (JSON.stringify(beforeFilter) !== JSON.stringify(filter)) {
      setCurrentColumn(
        createColumns(
          tableOrder,
          !Array.isArray(tableOrder) ? originalData.multiCurrentTable : 0,
          filter,
        ),
      );
    }
  }, [filter]);

  return (
    <div css={sg.mainWrapper}>
      <HeaderSetting
        period={period}
        aggregation={aggregation}
        loadingSet={onLoad}
        type={type}
      />
      <div className="table-wrapper">
        <div>{type === 'analysis' ? 'Analysis Result' : 'Original Data'}</div>
        <div>
          {!Array.isArray(tableOrder) && (
            <div className="select-wrapper">
              <span>Current table:</span>
              <Select
                value={
                  type === 'data'
                    ? originalData.multiCurrentTable
                    : analysisData.multiCurrentTable
                }
                style={{ width: '300px', marginLeft: '0.5rem' }}
                onChange={changeTable}
              >
                {Object.keys(tableOrder).map(RenderSelectOptions)}
              </Select>
            </div>
          )}
          {currentRow && currentRow.length ? (
            <AnalysisTableComponent
              tableData={currentRow}
              tableOrder={currentColumn}
              type={type}
            />
          ) : (
            <div
              css={sg.emptyWrapper}
              className={!Array.isArray(tableOrder) ? 'data' : ''}
            >
              <Empty />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

AnalysisTable.displayName = 'AnalysisTable';
AnalysisTable.propTypes = {
  period: PropTypes.object.isRequired,
  aggregation: PropTypes.object,
  tableOrder: PropTypes.oneOfType([PropTypes.array, PropTypes.object])
    .isRequired,
  tableData: PropTypes.object.isRequired,
  filter: PropTypes.object,
  type: PropTypes.string.isRequired,
  onLoad: PropTypes.func,
  initialTableName: PropTypes.string,
};

export default AnalysisTable;
