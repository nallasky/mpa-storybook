import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
import axios from 'axios';
import { Tabs } from 'antd';
import Button from '../common/atoms/Button';
import {
  SaveOutlined,
  SlidersFilled,
  CloudDownloadOutlined,
  DatabaseOutlined,
} from '@ant-design/icons';
import {
  getOriginalOptionInfo,
  getAnalysisData,
  postHistoryData,
  postRequestExport,
  getRemoteOriginalInfo,
} from '@libs/axios/requests';
import { RESPONSE_OK, DATE_FORMAT } from '@constants/etc';
import AnalysisTable from './hooks/useAnalysisTable';
import AnalysisGraph from './hooks/useAnalysisGraph';
import DatabasePopup from './hooks/useDatabasePopup';
import JobAnalysisModal from './hooks/useJobAnalysisModal';
import AnalysisLoading from '@components/JobAnalysis/hooks/AnalysisLoading';
import useModal from '../../libs/util/modalControl/useModal';
import useResultInfo from '../../hooks/common/useResultInfo';
import {
  displayNotification,
  createPageData,
  initAggregation,
  createGraphItems,
  filteringTableData,
  periodFilteringData,
} from '@libs/util/common/functionGroup';
import {
  createExportTableData,
  createGraphImage,
  createHistoryInfo,
} from './hooks/useJobAnalysis';
import * as sg from './styles/JobAnalysisStyles';
import { getRequestIdFromJobSetting } from '@libs/axios/jobSettingRequest';

const JobAnalysis = () => {
  const { openModal } = useModal();
  const {
    func_id,
    job_id,
    job_type,
    history_id,
    equipment_name,
    db_id,
    sql,
    list,
    source_type,
  } = useLocation().state;
  let navigate = useNavigate();
  const {
    analysisData,
    originalData,
    originalFilteredRows,
    analysisGraphInfo,
    originalGraphInfo,
    selectedDatabase,
    selectedEquipment,
    savedAggregation,
    remoteApplyInfo,
    setOriginalInfo,
    setAnalysisInfo,
    setAnalysisGraphInfo,
    setOriginalGraphInfo,
    setOriginalFilteredRows,
    setVisualization,
    setSelectedDatabase,
    setSelectedEquipment,
    setSavedAggregation,
    setRemoteApplyInfo,
    initializing,
  } = useResultInfo();
  const [activeTab, setActiveTab] = useState('1');
  const [loadState, setLoadState] = useState(true);
  const [isRenderGraph, setIsRenderGraph] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [isInitial, setIsInitial] = useState(true);
  const cancelTokenSource = useRef();

  const changeTab = (v) => {
    setActiveTab(v);
  };

  const changeLoadState = (v) => {
    setLoadState(v);
  };

  const analysisStart = async () => {
    changeLoadState('analysis');
    const dateStr = originalData.period.selected.length
      ? originalData.period.selected
      : [originalData.period.start, originalData.period.end];
    let param = {
      period: dateStr.join('~'),
      aggregation: savedAggregation.type ? { ...savedAggregation } : {},
      filter: originalData.filter,
    };

    if (job_type === 'remote' || source_type === 'remote') {
      param = {
        ...param,
        equipment_name: selectedEquipment,
        db_id: selectedDatabase,
      };
    }

    try {
      cancelTokenSource.current = new AbortController();
      const response = await getAnalysisData(
        param,
        func_id,
        originalData.jobId,
        !!originalData.type.match(/multi/),
        cancelTokenSource.current.signal,
      );
      const isSingle = !!Object.keys(response.data).find(
        (v) => v === 'disp_order',
      );
      let isDataEmpty = true;
      if (isSingle) {
        isDataEmpty = !Object.keys(response.data.row).length;
      } else {
        for (const item of Object.values(response.data)) {
          if (!isDataEmpty) break;
          for (const row of Object.values(item.row)) {
            if (Object.keys(row).length) {
              isDataEmpty = false;
              break;
            }
          }
        }
      }
      if (!isDataEmpty) {
        const rowData = createPageData(originalData.type, response.data, 'row');
        setAnalysisInfo({
          dispOrder: createPageData(
            originalData.type,
            response.data,
            'disp_order',
          ),
          dispGraph: createPageData(
            originalData.type,
            response.data,
            'disp_graph',
          ),
          data: rowData,
          common_axis_x: response?.visualization?.common_axis_x ?? [],
          multiCurrentTable: !isSingle ? Object.keys(response.data)[0] : '',
        });
        changeTab('2');
      }
      setTimeout(() => {
        changeLoadState(false);
        if (isDataEmpty) {
          displayNotification({
            message: 'No analysis data.',
            description: 'There is no analysis data to be displayed.',
            duration: 3,
            style: { borderLeft: '5px solid green' },
          });
        }
      }, 2000);
    } catch (e) {
      if (!axios.isCancel(e)) {
        displayNotification({
          message: 'Error occurred',
          description: e.response.data.message,
          duration: 3,
          style: { borderLeft: '5px solid red' },
        });
      }
      changeLoadState(false);
    }
  };

  const saveHistory = async (historyName) => {
    setLoadState(true);
    const infoKey = job_type === 'multi' || !!list ? 'infos' : 'info';
    const findSourceType =
      infoKey === 'infos'
        ? 'multi'
        : history_id !== 'undefined' && history_id !== undefined
        ? source_type
        : job_type;
    let tmpObj = {
      func_id,
      source: findSourceType,
      title: historyName,
      period: {
        start: !originalData.period.selected.length
          ? originalData.period.start
          : originalData.period.selected[0],
        end: !originalData.period.selected.length
          ? originalData.period.end
          : originalData.period.selected[1],
      },
      filter: originalData.filter,
      aggregation: Object.keys(originalData.aggregation).length
        ? {
            [savedAggregation.type]: savedAggregation.val,
          }
        : {},
      visualization: {
        items: {},
      },
    };

    const filteringGraphInfo = (key) => {
      const currentInfo =
        key === 'analysis' ? analysisGraphInfo : originalGraphInfo;
      return currentInfo
        .filter((v) => !!v)
        .map((v) => {
          return {
            ...v,
            y_axis: !Array.isArray(v.y_axis[0])
              ? v.y_axis
              : v.y_axis.map((x) => x.join('/')),
            z_axis: Array.isArray(v.z_axis) ? v.z_axis.join('/') : v.z_axis,
          };
        });
    };
    if (analysisGraphInfo.filter((v) => !!v).length) {
      tmpObj.visualization.items['analysis'] = filteringGraphInfo('analysis');
    }
    if (originalGraphInfo.filter((v) => !!v).length) {
      tmpObj.visualization.items['data'] = filteringGraphInfo('data');
    }
    const isRemote = job_type === 'remote' || source_type === 'remote';
    tmpObj[infoKey] = createHistoryInfo({
      func_id,
      job_id: originalData.jobId,
      job_type:
        originalData.type === 'script'
          ? 'script'
          : isRemote
          ? 'remote'
          : findSourceType,
      history_id,
      equipment_name: isRemote ? selectedEquipment : equipment_name,
      db_id: isRemote ? selectedDatabase : db_id,
      sql,
      list,
    });

    let status = '';

    try {
      cancelTokenSource.current = new AbortController();
      status = await postHistoryData(tmpObj, cancelTokenSource.current.signal);
    } catch (e) {
      status = axios.isCancel(e) ? 'cancel' : 'NG';
    } finally {
      setTimeout(
        () => {
          if (status !== 'cancel') {
            displayNotification({
              message:
                status.toString() === RESPONSE_OK
                  ? 'History Save Successful'
                  : 'History Save Failed',
              description:
                status.toString() === RESPONSE_OK
                  ? 'Successfully saved history.'
                  : 'Failed to save history. Please change the name and try again.',
              duration: 3,
              style:
                status.toString() === RESPONSE_OK
                  ? { borderLeft: '5px solid green' }
                  : { borderLeft: '5px solid red' },
            });
          }
          setLoadState(false);
        },
        status === 'cancel' ? 0 : 2000,
      );
    }
  };

  const executeExport = async (info) => {
    setLoadState(true);
    const form = new FormData();

    if (info.checkTable) {
      let filteredData = {};

      if (Array.isArray(originalData.dispOrder)) {
        filteredData = originalFilteredRows;
      } else {
        for (const [key, value] of Object.entries(originalData.data)) {
          filteredData[key] = filteringTableData(
            originalData.filter,
            periodFilteringData(originalData.period.selected, value),
          );
        }
      }

      createExportTableData(filteredData, originalData.dispOrder, 'data', form);
      if (Object.keys(analysisData.data).length) {
        createExportTableData(
          analysisData.data,
          analysisData.dispOrder,
          'analysis',
          form,
        );
      }
    }
    if (info && isRenderGraph) {
      const imgData = await createGraphImage();
      imgData.forEach((v) => {
        form.append('files', new File([v.url], v.filename));
      });
    }

    const status = await postRequestExport(form);
    setTimeout(() => {
      setLoadState(false);
      displayNotification({
        message: status === RESPONSE_OK ? 'Export Successful' : 'Export Failed',
        description:
          status === RESPONSE_OK
            ? 'Successfully export data.'
            : 'Failed to export data. Please try again.',
        duration: 3,
        style:
          status === RESPONSE_OK
            ? { borderLeft: '5px solid green' }
            : { borderLeft: '5px solid red' },
      });
    }, 2000);
  };

  const openExport = () => {
    const graphCheck = !!document.querySelectorAll(
      'div[class^="js-plotly-plot"]',
    ).length;
    setIsRenderGraph(graphCheck);
    openModal(JobAnalysisModal, {
      title: 'Export',
      ok: executeExport,
      okText: 'Download',
      width: 400,
      info: { isRenderGraph: graphCheck },
      type: 'export',
    });
  };

  const buttonDisableCheck = () => {
    if (originalData.type.match(/multi/)) {
      return activeTab !== '1';
    } else {
      return activeTab !== '1' || !!originalData.type.match(/none/);
    }
  };

  const openHistory = () => {
    openModal(JobAnalysisModal, {
      title: 'Save History',
      ok: saveHistory,
      okText: 'Save',
      info: {
        historyName: dayjs().format(DATE_FORMAT),
      },
    });
  };

  useEffect(() => {
    const fetch = async () => {
      try {
        cancelTokenSource.current = new AbortController();
        const rid =
          history_id !== 'undefined' && history_id !== undefined
            ? history_id
            : job_id;
        const data = await getOriginalOptionInfo(
          func_id,
          rid,
          job_type,
          job_type === 'remote' || source_type === 'remote'
            ? { db_id, equipment_name }
            : undefined,
          cancelTokenSource.current.signal,
        );
        const newData = createPageData(data.analysis_type, data.data, 'row');
        const isMultiTable = !Object.keys(data.data).find(
          (v) => v === 'disp_order',
        );
        const tableName = isMultiTable ? Object.keys(data.data)[0] : undefined;
        setOriginalInfo({
          type: data.analysis_type,
          jobId: data.rid ?? rid ?? '',
          period: {
            start: dayjs(data.period.start).format(DATE_FORMAT),
            end: dayjs(data.period.end).format(DATE_FORMAT),
            selected: data.period.selected.map((v) =>
              dayjs(v).format(DATE_FORMAT),
            ),
          },
          filter: Array.isArray(data.filter) ? {} : data.filter,
          aggregation: data.aggregation ?? {},
          dispOrder: createPageData(
            data.analysis_type,
            data.data,
            'disp_order',
          ),
          dispGraph: createPageData(
            data.analysis_type,
            data.data,
            'disp_graph',
          ),
          data: newData,
          common_axis_x: data.visualization?.common_axis_x ?? [],
          multiCurrentTable: tableName ?? '',
        });
        setVisualization({ ...data.visualization });
        setSavedAggregation(initAggregation(data.aggregation));
        setOriginalFilteredRows(
          Object.keys(data.filter).length
            ? filteringTableData(
                data.filter,
                isMultiTable ? newData[tableName] : newData,
              )
            : isMultiTable
            ? newData[tableName]
            : newData,
        );
        if (data.visualization.items.data) {
          setOriginalGraphInfo(
            createGraphItems({
              function_graph_type: data.visualization.function_graph_type,
              graph_list: data.visualization.graph_list,
              items: data.visualization.items.data,
            }),
          );
        }
        if (data.visualization.items.analysis) {
          setAnalysisGraphInfo(
            createGraphItems({
              function_graph_type: data.visualization.function_graph_type,
              graph_list: data.visualization.graph_list,
              items: data.visualization.items.analysis,
            }),
          );
        }
        if (job_type === 'remote' || source_type === 'remote') {
          setSelectedDatabase(db_id);
          setSelectedEquipment(equipment_name);
        }
      } catch (e) {
        console.log(e);
      } finally {
        setIsInitial(false);
        changeLoadState(false);
      }
    };
    fetch();
    // eslint-disable-next-line react/display-name
    return () => {
      initializing();
      const plotlyElement = document.getElementById('js-plotly-tester');
      if (plotlyElement) {
        plotlyElement.remove();
      }
      return null;
    };
  }, [func_id, job_type, history_id, job_id]);

  useEffect(() => {
    if (activeTab !== '1') setActiveTab('1');
  }, [originalData.data]);

  useEffect(() => {
    const fetch = async () => {
      const { type } = remoteApplyInfo;
      let errorMsg = undefined;
      try {
        setLoadState(true);
        cancelTokenSource.current = new AbortController();
        const { rid } = await getRequestIdFromJobSetting({
          source: 'remote',
          object: {
            func_id: remoteApplyInfo.func_id,
            db_id: remoteApplyInfo.db_id,
            equipment_name: remoteApplyInfo.equipment_name,
            selected: remoteApplyInfo.period,
            signal: cancelTokenSource.current.signal,
          },
        });
        cancelTokenSource.current = new AbortController();
        const { info } = await getRemoteOriginalInfo(
          func_id,
          rid,
          cancelTokenSource.current.signal,
        );
        const newData = createPageData(info.analysis_type, info.data, 'row');
        setOriginalInfo({
          ...originalData,
          jobId: rid,
          data: newData,
          filter:
            type === 'filter' ? remoteApplyInfo.filter : originalData.filter,
          period:
            type !== 'db'
              ? originalData.period
              : {
                  start: dayjs(info.period.start).format(DATE_FORMAT),
                  end: dayjs(info.period.end).format(DATE_FORMAT),
                  selected: info.period.selected.map((v) =>
                    dayjs(v).format(DATE_FORMAT),
                  ),
                },
        });
        setOriginalFilteredRows(
          filteringTableData(
            remoteApplyInfo.type === 'filter'
              ? remoteApplyInfo.filter
              : originalData.filter,
            originalData.multiCurrentTable
              ? originalData.data[originalData.multiCurrentTable]
              : originalData.data,
          ),
        );
        setAnalysisInfo({
          dispOrder: [],
          dispGraph: [],
          data: {},
          common_axis_x: [],
          multiCurrentTable: '',
        });
        if (type === 'db') {
          setSelectedDatabase(remoteApplyInfo.db_id);
          setSelectedEquipment(remoteApplyInfo.equipment_name);
        }
      } catch (e) {
        if (axios.isCancel(e)) {
          errorMsg = 'cancel';
        } else {
          errorMsg =
            e?.response?.data?.msg ??
            'Update data of the selected equipment failed.';
        }
      } finally {
        setTimeout(
          () => {
            setLoadState(false);
            if (errorMsg !== 'cancel') {
              displayNotification({
                message: errorMsg ? 'Update fail' : 'Update success',
                description:
                  errorMsg ??
                  'Update data of the selected equipment was successful.',
                duration: 3,
                style: {
                  borderLeft: errorMsg ? '5px solid red' : '5px solid green',
                },
              });
            } else {
              if (type !== 'db') {
                setOriginalInfo({
                  ...originalData,
                  period: {
                    ...originalData.period,
                    selected: remoteApplyInfo.beforePeriod.map((v) =>
                      dayjs(v).format(DATE_FORMAT),
                    ),
                  },
                });
              }
            }
            setRemoteApplyInfo({
              type: '',
              func_id: '',
              db_id: '',
              equipment_name: '',
              period: {},
              beforePeriod: {},
              filter: {},
            });
          },
          errorMsg === 'cancel' ? 0 : 2000,
        );
      }
    };

    if (remoteApplyInfo.type !== '') {
      fetch();
    }
  }, [remoteApplyInfo]);

  return (
    <div css={sg.mainWrapper}>
      <div css={sg.buttonWrapper}>
        {(job_type === 'remote' || source_type === 'remote') && (
          <Button
            theme="white"
            style={{ fontWeight: 'normal' }}
            onClick={() => setIsOpen(!isOpen)}
          >
            <DatabaseOutlined /> Change Data
          </Button>
        )}
        <Button
          theme="white"
          style={{ fontWeight: 'normal' }}
          disabled={buttonDisableCheck()}
          onClick={analysisStart}
        >
          <SlidersFilled /> Analysis
        </Button>
        <Button
          theme="white"
          style={{ fontWeight: 'normal' }}
          onClick={openHistory}
        >
          <SaveOutlined /> Save History
        </Button>
        <Button
          theme="white"
          style={{ fontWeight: 'normal' }}
          onClick={openExport}
        >
          <CloudDownloadOutlined /> Export
        </Button>
        {(job_type === 'remote' || source_type === 'remote') && (
          <DatabasePopup open={isOpen} closer={() => setIsOpen(false)} />
        )}
      </div>
      <Tabs activeKey={activeTab} onChange={changeTab}>
        <Tabs.TabPane tab="Data" key="1">
          <div css={sg.tableWrapper}>
            <AnalysisTable
              period={originalData.period}
              filter={originalData.filter}
              aggregation={originalData.aggregation}
              tableData={originalFilteredRows}
              tableOrder={originalData.dispOrder}
              type="data"
              onLoad={changeLoadState}
            />
            <AnalysisGraph
              rows={
                Array.isArray(originalData.dispOrder)
                  ? originalFilteredRows
                  : originalData.data
              }
              info={originalGraphInfo}
              useFilter={!Array.isArray(originalData.dispOrder)}
              type="data"
            />
          </div>
        </Tabs.TabPane>
        {!!Object.keys(analysisData.data).length && (
          <Tabs.TabPane tab="Analysis" key="2">
            <div css={sg.tableWrapper}>
              <AnalysisTable
                period={originalData.period}
                filter={originalData.filter}
                aggregation={originalData.aggregation}
                tableData={
                  analysisData.multiCurrentTable
                    ? analysisData.data[analysisData.multiCurrentTable]
                    : analysisData.data
                }
                tableOrder={analysisData.dispOrder}
                type="analysis"
                onLoad={changeLoadState}
                detailType={analysisData.type}
              />
              <AnalysisGraph
                rows={analysisData.data}
                info={analysisGraphInfo}
                type="analysis"
              />
            </div>
          </Tabs.TabPane>
        )}
      </Tabs>
      <AnalysisLoading
        useCancel={
          isInitial || !!remoteApplyInfo.type || loadState === 'analysis'
        }
        state={!!loadState}
        onCancel={() => {
          cancelTokenSource.current.abort();
          if (isInitial) navigate(-1);
        }}
      />
    </div>
  );
};
JobAnalysis.displayName = 'JobAnalysis';

export default JobAnalysis;
