import React, { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import dayjs from 'dayjs';
import { Tabs, Spin } from 'antd';
import Button from '../common/atoms/Button';
import {
  SaveOutlined,
  SlidersFilled,
  CloudDownloadOutlined,
  DatabaseOutlined,
} from '@ant-design/icons';
import {
  getAnalysisOptionInfo,
  getOriginalData,
  postHistoryData,
  postRequestExport,
} from '@libs/axios/requests';
import { RESPONSE_OK, DATE_FORMAT } from '@constants/etc';
import AnalysisTable from './hooks/useAnalysisTable';
import AnalysisGraph from './hooks/useAnalysisGraph';
import DatabasePopup from './hooks/useDatabasePopup';
import JobAnalysisModal from './hooks/useJobAnalysisModal';
import useModal from '../../libs/util/modalControl/useModal';
import useResultInfo from '../../hooks/common/useResultInfo';
import {
  displayNotification,
  createGraphItems,
  createAnalysisData,
} from '@libs/util/common/functionGroup';
import {
  createExportTableData,
  createGraphImage,
  createHistoryInfo,
} from './hooks/useJobAnalysis';
import * as sg from './styles/JobAnalysisStyles';

const JobAnalysis = React.memo(() => {
  const { openModal } = useModal();
  const {
    func_id,
    job_id,
    job_type,
    history_id,
    equipment_name,
    db_id,
    sql,
    list,
    source_type,
  } = useLocation().state;
  const {
    visualization,
    analysisData,
    originalData,
    originalFilteredRows,
    analysisGraphInfo,
    originalGraphInfo,
    selectedRow,
    selectedDatabase,
    selectedEquipment,
    setAnalysisInfo,
    setOriginalInfo,
    setOriginalFilteredRows,
    setVisualization,
    setAnalysisGraphInfo,
    setOriginalGraphInfo,
    setSelectedDatabase,
    setSelectedEquipment,
    initializing,
  } = useResultInfo();
  const [activeTab, setActiveTab] = useState('1');
  const [loadState, setLoadState] = useState(true);
  const [isRenderGraph, setIsRenderGraph] = useState(false);
  const [isOriginal, setIsOriginal] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const changeTab = useCallback((v) => {
    setActiveTab(v);
  }, []);

  const changeLoadState = useCallback((v) => {
    setLoadState(v);
  }, []);

  const clickData = async () => {
    changeLoadState(true);

    const dateStr =
      analysisData.period.selected.length > 0
        ? analysisData.period.selected
        : [analysisData.period.start, analysisData.period.end];
    let param = {
      fId: func_id,
      start: dateStr[0],
      end: dateStr[1],
    };

    if (
      analysisData.type.match(/multi/) === null ||
      analysisData.type.match(/setting/)
    ) {
      param = {
        ...param,
        rId: analysisData.jobId,
        agMain:
          Object.keys(analysisData.aggregation).length > 0
            ? analysisData.aggregation.selected
            : '',
        agSub:
          Object.keys(analysisData.aggregation).length > 0
            ? analysisData.aggregation.selected.indexOf('all') === -1
              ? analysisData.aggregation.subItem[
                  analysisData.aggregation.selected
                ].selected
              : ''
            : '',
        filter: analysisData.filter,
        selected: selectedRow[0] === 'all' ? [] : selectedRow,
      };
    }

    const { data, option, items, message, common_axis_x } =
      await getOriginalData(param, analysisData.type);
    const rowData = createAnalysisData(analysisData.type, data, 'row');

    changeLoadState(false);

    if (message !== '') {
      displayNotification({
        message: 'Error occurred',
        description: message,
        duration: 3,
        style: { borderLeft: '5px solid red' },
      });
    } else {
      setOriginalInfo({
        period: analysisData.period,
        filter: option.filter,
        aggregation: {},
        dispOrder: createAnalysisData(analysisData.type, data, 'disp_order'),
        dispGraph: createAnalysisData(analysisData.type, data, 'disp_graph'),
        data: rowData,
        common_axis_x: common_axis_x,
      });
      setOriginalFilteredRows(rowData);
      setOriginalGraphInfo(
        createGraphItems({
          function_graph_type: visualization.function_graph_type,
          graph_list: visualization.graph_list,
          items: items,
        }),
      );

      if (Object.keys(rowData).length > 0) {
        changeTab('2');
      } else {
        displayNotification({
          message: 'No Data',
          description: 'There is no data to display.',
          duration: 3,
          style: { borderLeft: '5px solid green' },
        });
      }
    }
  };

  const saveHistory = async (historyName) => {
    setLoadState(true);
    const infoKey = job_type === 'multi' ? 'infos' : 'info';
    const tmpFilter = analysisData.filter.reduce((acc, v) => {
      acc[v.target] =
        v.selected === undefined || v.selected === null ? '' : v.selected;
      return acc;
    }, {});
    let tmpObj = {
      func_id: func_id,
      source:
        history_id !== 'undefined' && history_id !== undefined
          ? source_type
          : job_type,
      title: historyName,
      period: {
        start:
          analysisData.period.selected.length === 0
            ? analysisData.period.start
            : analysisData.period.selected[0],
        end:
          analysisData.period.selected.length === 0
            ? analysisData.period.end
            : analysisData.period.selected[1],
      },
      filter: tmpFilter,
      aggregation:
        Object.keys(analysisData.aggregation).length === 0
          ? {}
          : {
              [analysisData.aggregation.selected]:
                analysisData.aggregation.selected.indexOf('all') === -1
                  ? analysisData.aggregation.subItem[
                      analysisData.aggregation.selected
                    ].selected
                  : '',
            },
      visualization: {
        items:
          analysisGraphInfo.length === 0
            ? []
            : analysisGraphInfo
                .filter((v) => v !== '')
                .map((v) => {
                  return {
                    ...v,
                    y_axis: !Array.isArray(v.y_axis[0])
                      ? v.y_axis
                      : v.y_axis.map((x) => x.join('/')),
                    z_axis: Array.isArray(v.z_axis)
                      ? v.z_axis.join('/')
                      : v.z_axis,
                  };
                }),
      },
    };

    const isRemote = job_type === 'remote' || source_type === 'remote';

    tmpObj[infoKey] = createHistoryInfo({
      func_id,
      job_id: analysisData.jobId,
      job_type:
        analysisData.type === 'script'
          ? 'script'
          : isRemote
          ? 'remote'
          : job_type,
      history_id,
      equipment_name: isRemote ? selectedEquipment : equipment_name,
      db_id: isRemote ? selectedDatabase : db_id,
      sql,
      list,
    });

    const { status } = await postHistoryData(tmpObj);
    setLoadState(false);

    displayNotification({
      message:
        status === RESPONSE_OK
          ? 'History Save Successful'
          : 'History Save Failed',
      description:
        status === RESPONSE_OK
          ? 'Successfully saved history.'
          : 'Failed to save history. Please change the name and try again.',
      duration: 3,
      style:
        status === RESPONSE_OK
          ? { borderLeft: '5px solid green' }
          : { borderLeft: '5px solid red' },
    });
  };

  const executeExport = async (info) => {
    setLoadState(true);
    const form = new FormData();

    if (info.checkTable) {
      createExportTableData(
        analysisData.data,
        analysisData.dispOrder,
        'analysis',
        form,
      );
      if (Object.keys(originalData.data).length > 0) {
        createExportTableData(
          originalData.data,
          originalData.dispOrder,
          'data',
          form,
        );
      }
    }

    if (info && isRenderGraph) {
      const imgData = await createGraphImage();
      imgData.forEach((v) => {
        form.append('files', new File([v.url], v.filename));
      });
    }

    const status = await postRequestExport(form);
    setLoadState(false);

    displayNotification({
      message: status === RESPONSE_OK ? 'Export Successful' : 'Export Failed',
      description:
        status === RESPONSE_OK
          ? 'Successfully export data.'
          : 'Failed to export data. Please try again.',
      duration: 3,
      style:
        status === RESPONSE_OK
          ? { borderLeft: '5px solid green' }
          : { borderLeft: '5px solid red' },
    });
  };

  const openExport = () => {
    setIsRenderGraph(
      document.querySelectorAll('div[class^="js-plotly-plot"]').length > 0,
    );
    openModal(JobAnalysisModal, {
      title: 'Export',
      ok: executeExport,
      okText: 'Download',
      width: 400,
      info: { isRenderGraph },
      type: 'export',
    });
  };

  const buttonDisableCheck = () => {
    if (analysisData.type.match(/multi/) === null) {
      return activeTab !== '1' || selectedRow.length === 0;
    } else {
      return activeTab !== '1' || analysisData.type.match(/none/) !== null;
    }
  };

  const openHistory = () => {
    openModal(JobAnalysisModal, {
      title: 'Save History',
      ok: saveHistory,
      okText: 'Save',
      info: {
        historyName: dayjs().format(DATE_FORMAT),
      },
    });
  };

  useEffect(() => {
    const fetch = async () => {
      const rid =
        history_id !== 'undefined' && history_id !== undefined
          ? history_id
          : job_id;
      const data = await getAnalysisOptionInfo(
        func_id,
        rid,
        job_type,
        job_type === 'remote' || source_type === 'remote'
          ? { db_id, equipment_name }
          : undefined,
      );
      return {
        id: rid,
        data: data,
      };
    };
    fetch()
      .then((info) => {
        setAnalysisInfo({
          type: info.data.analysis_type,
          jobId: info.data.rid ?? info.id,
          period: {
            ...info.data.period,
            start:
              info.data.period.start.length > 0
                ? dayjs(info.data.period.start).format(DATE_FORMAT)
                : '',
            end:
              info.data.period.end.length > 0
                ? dayjs(info.data.period.end).format(DATE_FORMAT)
                : '',
          },
          filter: info.data.filter,
          aggregation: info.data.aggregation ?? {},
          dispOrder: createAnalysisData(
            info.data.analysis_type,
            info.data.data,
            'disp_order',
          ),
          dispGraph: createAnalysisData(
            info.data.analysis_type,
            info.data.data,
            'disp_graph',
          ),
          data: createAnalysisData(
            info.data.analysis_type,
            info.data.data,
            'row',
          ),
          common_axis_x: info.data.analysis_type.match(/multi/)
            ? info.data.visualization.common_axis_x
            : [],
        });
        setVisualization({ ...info.data.visualization });
        setAnalysisGraphInfo(createGraphItems(info.data.visualization));

        if (job_type === 'remote' || source_type === 'remote') {
          setSelectedDatabase(db_id);
          setSelectedEquipment(equipment_name);
        }

        if (info.data.analysis_type.match(/none/)) {
          setIsOriginal(true);
        }
      })
      .catch((e) => console.log(e))
      .finally(() => changeLoadState(false));
    return () => {
      initializing();
      const plotlyElement = document.getElementById('js-plotly-tester');
      if (plotlyElement) {
        plotlyElement.remove();
      }
      return null;
    };
  }, [func_id, job_type, history_id, job_id]);

  return (
    <div css={sg.mainWrapper} className={loadState ? 'loading' : ''}>
      <div css={sg.buttonWrapper}>
        {(job_type === 'remote' || source_type === 'remote') && (
          <Button
            theme="white"
            style={{ fontWeight: 'normal' }}
            onClick={() => setIsOpen(!isOpen)}
          >
            <DatabaseOutlined /> Change Data
          </Button>
        )}
        <Button
          theme="white"
          style={{ fontWeight: 'normal' }}
          disabled={buttonDisableCheck()}
          onClick={clickData}
        >
          <SlidersFilled /> Show Data
        </Button>
        <Button
          theme="white"
          style={{ fontWeight: 'normal' }}
          onClick={openHistory}
          disabled={Object.keys(analysisData.data).length === 0}
        >
          <SaveOutlined /> Save History
        </Button>
        <Button
          theme="white"
          style={{ fontWeight: 'normal' }}
          onClick={openExport}
          disabled={Object.keys(analysisData.data).length === 0}
        >
          <CloudDownloadOutlined /> Export
        </Button>
        {(job_type === 'remote' || source_type === 'remote') && (
          <DatabasePopup
            open={isOpen}
            closer={() => setIsOpen(false)}
            id={func_id}
            tabChanger={changeTab}
          />
        )}
      </div>
      <Spin size="large" tip="Loading..." spinning={loadState}>
        <Tabs activeKey={activeTab} onChange={changeTab}>
          <Tabs.TabPane tab="Analysis" key="1">
            <div css={sg.tableWrapper}>
              <AnalysisTable
                period={analysisData.period}
                filter={analysisData.filter}
                aggregation={analysisData.aggregation}
                tableData={analysisData.data}
                tableOrder={analysisData.dispOrder}
                type={isOriginal ? 'data' : 'analysis'}
                onLoad={changeLoadState}
                detailType={analysisData.type}
                useUpdate
              />
              <AnalysisGraph
                rows={analysisData.data}
                info={analysisGraphInfo}
              />
            </div>
          </Tabs.TabPane>
          {originalData.data !== undefined &&
            Object.keys(originalData.data).length > 0 && (
              <Tabs.TabPane tab="Data" key="2">
                <div css={sg.tableWrapper}>
                  <AnalysisTable
                    period={originalData.period}
                    filter={originalData.filter}
                    aggregation={originalData.aggregation}
                    tableData={originalFilteredRows}
                    tableOrder={originalData.dispOrder}
                    type="data"
                    onLoad={changeLoadState}
                    useUpdate={false}
                  />
                  <AnalysisGraph
                    rows={originalFilteredRows}
                    info={originalGraphInfo}
                    type="data"
                  />
                </div>
              </Tabs.TabPane>
            )}
        </Tabs>
      </Spin>
    </div>
  );
});
JobAnalysis.displayName = 'JobAnalysis';

export default JobAnalysis;
