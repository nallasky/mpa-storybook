import React, { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import dayjs from 'dayjs';
import { Tabs, Spin } from 'antd';
import Button from '../common/atoms/Button';
import {
  SaveOutlined,
  SlidersFilled,
  CloudDownloadOutlined,
  DatabaseOutlined,
} from '@ant-design/icons';
import {
  getOriginalOptionInfo,
  getAnalysisData,
  postHistoryData,
  postRequestExport,
} from '@libs/axios/requests';
import { RESPONSE_OK, DATE_FORMAT } from '@constants/etc';
import AnalysisTable from './hooks/useAnalysisTable';
import AnalysisGraph from './hooks/useAnalysisGraph';
import DatabasePopup from './hooks/useDatabasePopup';
import JobAnalysisModal from './hooks/useJobAnalysisModal';
import useModal from '../../libs/util/modalControl/useModal';
import useResultInfo from '../../hooks/common/useResultInfo';
import {
  displayNotification,
  createGraphItems,
  createPageData,
  initAggregation,
} from '@libs/util/common/functionGroup';
import {
  createExportTableData,
  createGraphImage,
  createHistoryInfo,
} from './hooks/useJobAnalysis';
import * as sg from './styles/JobAnalysisStyles';

const tmpFilterFormat = {
  lot_id: [
    {
      logical_type: 'default',
      data_type: 'string',
      condition: {
        filter_type: 'match',
        filter_value: 'test',
      }
    },
    {
      logical_type: 'or',
      data_type: 'string',
      condition: {
        filter_type: 'match',
        filter_value: '2',
      }
    },
  ],
}

const JobAnalysis = React.memo(() => {
  const { openModal } = useModal();
  const {
    func_id,
    job_id,
    job_type,
    history_id,
    equipment_name,
    db_id,
    sql,
    list,
    source_type,
  } = useLocation().state;
  const {
    visualization,
    analysisData,
    originalData,
    originalFilteredRows,
    analysisGraphInfo,
    originalGraphInfo,
    selectedDatabase,
    selectedEquipment,
    savedAggregation,
    setAnalysisInfo,
    setOriginalInfo,
    setOriginalFilteredRows,
    setVisualization,
    setAnalysisGraphInfo,
    setSelectedDatabase,
    setSelectedEquipment,
    setSavedAggregation,
    initializing,
  } = useResultInfo();
  const [activeTab, setActiveTab] = useState('1');
  const [loadState, setLoadState] = useState(true);
  const [isRenderGraph, setIsRenderGraph] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const changeTab = useCallback((v) => {
    setActiveTab(v);
  }, []);

  const changeLoadState = useCallback((v) => {
    setLoadState(v);
  }, []);

  const analysisStart = async () => {
    changeLoadState(true);

    const dateStr =
      originalData.period.selected.length
        ? originalData.period.selected
        : [originalData.period.start, originalData.period.end];
    let param = {
      period: {
        start: dateStr[0],
        end: dateStr[1],
      },
      aggregation: {
        type: savedAggregation.type,
        val: savedAggregation.val,
      },
      filter: originalData.filter,
    };

    if (job_type === 'remote' || source_type === 'remote') {
      param = {
        ...param,
        equipment_name: selectedEquipment,
        db_id: selectedDatabase,
      }
    }

    const resuilt = await getAnalysisData(param, func_id, originalData.jobId);
    console.log('gtpark result', result);
    /*
    const rowData = createPageData(originalData.type, data, 'row');

    changeLoadState(false);

    if (message !== '') {
      displayNotification({
        message: 'Error occurred',
        description: message,
        duration: 3,
        style: { borderLeft: '5px solid red' },
      });
    } else {
      setAnalysisInfo({
        dispOrder: createPageData(originalData.type, data, 'disp_order'),
        dispGraph: createPageData(originalData.type, data, 'disp_graph'),
        data: rowData,
        common_axis_x: common_axis_x,
      });
      setAnalysisGraphInfo(
        createGraphItems({
          function_graph_type: visualization.function_graph_type,
          graph_list: visualization.graph_list,
          items: items,
        }),
      );

      if (Object.keys(rowData).length) {
        changeTab('2');
      } else {
        displayNotification({
          message: 'No Data',
          description: 'There is no data to display.',
          duration: 3,
          style: { borderLeft: '5px solid green' },
        });
      }
    }
     */
  };

  const saveHistory = async (historyName) => {
    setLoadState(true);
    const infoKey = job_type === 'multi' ? 'infos' : 'info';
    let tmpObj = {
      func_id: func_id,
      source:
        history_id !== 'undefined' && history_id !== undefined
          ? source_type
          : job_type,
      title: historyName,
      period: {
        start:
          !originalData.period.selected.length
            ? originalData.period.start
            : originalData.period.selected[0],
        end:
          !originalData.period.selected.length
            ? originalData.period.end
            : originalData.period.selected[1],
      },
      filter: originalData.filter,
      aggregation:
        !Object.keys(originalData.aggregation).length
          ? {}
          : {
              [originalData.aggregation.selected]:
                originalData.aggregation.selected.indexOf('all') === -1
                  ? originalData.aggregation.subItem[
                    originalData.aggregation.selected
                    ].selected
                  : '',
            },
      visualization: {
        items:
          !analysisGraphInfo.length
            ? []
            : analysisGraphInfo
                .filter((v) => v !== '')
                .map((v) => {
                  return {
                    ...v,
                    y_axis: !Array.isArray(v.y_axis[0])
                      ? v.y_axis
                      : v.y_axis.map((x) => x.join('/')),
                    z_axis: Array.isArray(v.z_axis)
                      ? v.z_axis.join('/')
                      : v.z_axis,
                  };
                }),
      },
    };

    const isRemote = job_type === 'remote' || source_type === 'remote';

    tmpObj[infoKey] = createHistoryInfo({
      func_id,
      job_id: originalData.jobId,
      job_type:
        originalData.type === 'script'
          ? 'script'
          : isRemote
          ? 'remote'
          : job_type,
      history_id,
      equipment_name: isRemote ? selectedEquipment : equipment_name,
      db_id: isRemote ? selectedDatabase : db_id,
      sql,
      list,
    });

    const { status } = await postHistoryData(tmpObj);
    setLoadState(false);

    displayNotification({
      message:
        status === RESPONSE_OK
          ? 'History Save Successful'
          : 'History Save Failed',
      description:
        status === RESPONSE_OK
          ? 'Successfully saved history.'
          : 'Failed to save history. Please change the name and try again.',
      duration: 3,
      style:
        status === RESPONSE_OK
          ? { borderLeft: '5px solid green' }
          : { borderLeft: '5px solid red' },
    });
  };

  const executeExport = async (info) => {
    setLoadState(true);
    const form = new FormData();

    if (info.checkTable) {
      createExportTableData(
        analysisData.data,
        analysisData.dispOrder,
        'analysis',
        form,
      );
      if (Object.keys(originalData.data).length > 0) {
        createExportTableData(
          originalData.data,
          originalData.dispOrder,
          'data',
          form,
        );
      }
    }

    if (info && isRenderGraph) {
      const imgData = await createGraphImage();
      imgData.forEach((v) => {
        form.append('files', new File([v.url], v.filename));
      });
    }

    const status = await postRequestExport(form);
    setLoadState(false);

    displayNotification({
      message: status === RESPONSE_OK ? 'Export Successful' : 'Export Failed',
      description:
        status === RESPONSE_OK
          ? 'Successfully export data.'
          : 'Failed to export data. Please try again.',
      duration: 3,
      style:
        status === RESPONSE_OK
          ? { borderLeft: '5px solid green' }
          : { borderLeft: '5px solid red' },
    });
  };

  const openExport = () => {
    setIsRenderGraph(
      document.querySelectorAll('div[class^="js-plotly-plot"]').length > 0,
    );
    openModal(JobAnalysisModal, {
      title: 'Export',
      ok: executeExport,
      okText: 'Download',
      width: 400,
      info: { isRenderGraph },
      type: 'export',
    });
  };

  const buttonDisableCheck = () => {
    if (!originalData.type.match(/multi/)) {
      return activeTab !== '1';
    } else {
      return activeTab !== '1' || originalData.type.match(/none/);
    }
  };

  const openHistory = () => {
    openModal(JobAnalysisModal, {
      title: 'Save History',
      ok: saveHistory,
      okText: 'Save',
      info: {
        historyName: dayjs().format(DATE_FORMAT),
      },
    });
  };

  useEffect(() => {
    const fetch = async () => {
      const rid =
        history_id !== 'undefined' && history_id !== undefined
          ? history_id
          : job_id;
      const data = await getOriginalOptionInfo(
        func_id,
        rid,
        job_type,
        job_type === 'remote' || source_type === 'remote'
          ? { db_id, equipment_name }
          : undefined,
      );
      return {
        id: rid,
        data: data,
      };
    };
    fetch()
      .then(({ id, data }) => {
        const newData = createPageData(
          data.analysis_type,
          data.data,
          'row',
        );
        setOriginalInfo({
          ...originalData,
          type: data.analysis_type,
          jobId: data.rid ?? id,
          period: {
            ...data.period,
            start:
              data.period.start.length
                ? dayjs(data.period.start).format(DATE_FORMAT)
                : '',
            end:
              data.period.end.length
                ? dayjs(data.period.end).format(DATE_FORMAT)
                : '',
          },
          aggregation: data.aggregation ?? {},
          dispOrder: createPageData(
            data.analysis_type,
            data.data,
            'disp_order',
          ),
          dispGraph: createPageData(
            data.analysis_type,
            data.data,
            'disp_graph',
          ),
          data: newData,
          common_axis_x: data.analysis_type.match(/multi/)
            ? data.visualization.common_axis_x
            : [],
        });
        setVisualization({ ...data.visualization });
        setSavedAggregation(initAggregation(data.aggregation));
        setOriginalFilteredRows(newData);

        if (job_type === 'remote' || source_type === 'remote') {
          setSelectedDatabase(db_id);
          setSelectedEquipment(equipment_name);
        }
      })
      .catch((e) => console.log(e))
      .finally(() => changeLoadState(false));
    return () => {
      initializing();
      const plotlyElement = document.getElementById('js-plotly-tester');
      if (plotlyElement) {
        plotlyElement.remove();
      }
      return null;
    };
  }, [func_id, job_type, history_id, job_id]);

  return (
    <div css={sg.mainWrapper} className={loadState ? 'loading' : ''}>
      <div css={sg.buttonWrapper}>
        {(job_type === 'remote' || source_type === 'remote') && (
          <Button
            theme="white"
            style={{ fontWeight: 'normal' }}
            onClick={() => setIsOpen(!isOpen)}
          >
            <DatabaseOutlined /> Change Data
          </Button>
        )}
        <Button
          theme="white"
          style={{ fontWeight: 'normal' }}
          disabled={buttonDisableCheck()}
          onClick={analysisStart}
        >
          <SlidersFilled /> Analysis
        </Button>
        <Button
          theme="white"
          style={{ fontWeight: 'normal' }}
          onClick={openHistory}
        >
          <SaveOutlined /> Save History
        </Button>
        <Button
          theme="white"
          style={{ fontWeight: 'normal' }}
          onClick={openExport}
        >
          <CloudDownloadOutlined /> Export
        </Button>
        {(job_type === 'remote' || source_type === 'remote') && (
          <DatabasePopup
            open={isOpen}
            closer={() => setIsOpen(false)}
            id={func_id}
            tabChanger={changeTab}
          />
        )}
      </div>
      <Spin size="large" tip="Loading..." spinning={loadState}>
        <Tabs activeKey={activeTab} onChange={changeTab}>
          <Tabs.TabPane tab="Data" key="1">
            <div css={sg.tableWrapper}>
              <AnalysisTable
                period={originalData.period}
                filter={originalData.filter}
                aggregation={originalData.aggregation}
                tableData={originalFilteredRows}
                tableOrder={originalData.dispOrder}
                type="data"
                onLoad={changeLoadState}
              />
              <AnalysisGraph
                rows={originalFilteredRows}
                info={originalGraphInfo}
                type="data"
              />
            </div>
          </Tabs.TabPane>
          {Object.keys(analysisData.data).length && (
            <Tabs.TabPane tab="Analysis" key="2">
              <div css={sg.tableWrapper}>
                <AnalysisTable
                  period={originalData.period}
                  filter={originalData.filter}
                  aggregation={originalData.aggregation}
                  tableData={analysisData.data}
                  tableOrder={analysisData.dispOrder}
                  type="analysis"
                  onLoad={changeLoadState}
                  detailType={analysisData.type}
                />
                <AnalysisGraph
                  rows={analysisData.data}
                  info={analysisGraphInfo}
                  type="analysis"
                />
              </div>
            </Tabs.TabPane>
          )}
        </Tabs>
      </Spin>
    </div>
  );
});
JobAnalysis.displayName = 'JobAnalysis';

export default JobAnalysis;
