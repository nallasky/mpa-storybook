export { default } from './about';
