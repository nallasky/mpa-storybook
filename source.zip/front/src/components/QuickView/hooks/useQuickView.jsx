import dayjs from 'dayjs';
import Plotly from 'plotly.js-dist';
import { GraphDateRegex, GraphRangeRegex } from '../../../libs/util/regExp';
import { compareErrorCheck } from '../../../libs/util/common/functionGroup';

export const renderGraph = (
  axisInfo,
  layoutInfo,
  editableInfo,
  setRelayout,
  setRestyle,
) => {
  const axisResult = [];
  let commonLayout = {
    font: {
      family: "Saira, 'Nunito Sans'",
    },
    title: editableInfo['title.text'] ?? 'Quick View Graph',
    xaxis: {
      range: [
        typeof layoutInfo.rangeX.min !== 'string' &&
        typeof layoutInfo.rangeX.min !== 'number'
          ? dayjs(layoutInfo.rangeX.min).format('YYYY-MM-DD HH:mm:ss')
          : layoutInfo.rangeX.min,
        typeof layoutInfo.rangeX.max !== 'string' &&
        typeof layoutInfo.rangeX.max !== 'number'
          ? dayjs(layoutInfo.rangeX.max).format('YYYY-MM-DD HH:mm:ss')
          : layoutInfo.rangeX.max,
      ],
      title: {
        text: editableInfo['xaxis.title.text'] ?? axisInfo[0],
        standoff: 16,
      },
      automargin: true,
    },
    yaxis: {
      range: [layoutInfo.rangeY.min, layoutInfo.rangeY.max],
      title: {
        text: editableInfo['yaxis.title.text'] ?? '',
        standoff: 16,
      },
      automargin: true,
    },
    height: 600,
  };

  axisInfo
    .filter((v) => typeof v === 'object')
    .forEach((x) => {
      let dataObj = {};
      if (layoutInfo.type === 'scatter' || layoutInfo.type === 'bar') {
        dataObj = {
          ...x,
          type: layoutInfo.type,
          name: x.name,
        };
      } else if (layoutInfo.type === 'dot-plot') {
        dataObj = {
          ...x,
          mode: 'markers',
          name: x.name,
          marker: {
            size: 8,
          },
        };
      } else if (layoutInfo.type === 'box') {
        dataObj = {
          y: x.y,
          name: x.name,
          type: layoutInfo.type,
        };
      } else {
        dataObj = {
          ...x,
          mode: 'markers',
          type: 'scatter',
          name: x.name,
        };
      }
      axisResult.push(dataObj);

      if (layoutInfo.type === 'density') {
        axisResult.push({
          ...x,
          ncontours: 20,
          colorscale: 'Blues',
          reversescale: true,
          showscale: false,
          type: 'histogram2dcontour',
        });
      }
    });

  if (layoutInfo.type === 'dot-plot') {
    commonLayout = {
      ...commonLayout,
      xaxis: {
        ...commonLayout.xaxis,
        showgrid: false,
        showline: true,
        autotick: true,
        ticks: 'outside',
      },
      hovermode: 'closest',
      margin: {
        l: 140,
        r: 40,
      },
    };
  } else if (layoutInfo.type === 'density') {
    commonLayout = {
      ...commonLayout,
      xaxis: {
        ...commonLayout.xaxis,
        showgrid: false,
        zeroline: false,
      },
      yaxis: {
        ...commonLayout.yaxis,
        showgrid: false,
        zeroline: false,
      },
      hovermode: 'closest',
      bargap: 0,
    };
  }

  const elements = document.getElementById('quick-view-graph');
  elements.childNodes[0]?.remove();
  Plotly.newPlot(elements, axisResult, commonLayout, { editable: true });
  elements.on('plotly_restyle', (e) => setRestyle(e));
  elements.on('plotly_relayout', (e) => setRelayout(e));
};

export const errorCheck = (columns, graphOptions, startLine) => {
  const result = [];
  const isBox = graphOptions.type === 'box';

  if (!isBox) {
    if (
      typeof graphOptions.rangeX.min !== 'object' &&
      (!GraphRangeRegex.test(graphOptions.rangeX.min) ||
        compareErrorCheck(graphOptions.rangeX.min, graphOptions.rangeX.max))
    )
      result.push('minX');

    if (
      typeof graphOptions.rangeX.max !== 'object' &&
      (!GraphRangeRegex.test(graphOptions.rangeX.max) ||
        compareErrorCheck(graphOptions.rangeX.min, graphOptions.rangeX.max))
    )
      result.push('maxX');
  }

  if (
    !GraphRangeRegex.test(graphOptions.rangeY.min) ||
    compareErrorCheck(graphOptions.rangeY.min, graphOptions.rangeY.max)
  )
    result.push('minY');

  if (
    !GraphRangeRegex.test(graphOptions.rangeY.max) ||
    compareErrorCheck(graphOptions.rangeY.min, graphOptions.rangeY.max)
  )
    result.push('maxY');

  if (startLine === '') result.push('radio');

  const selectedX = columns.filter((v) => v.selected.x).length;
  const selectedY = columns.filter((v) => v.selected.y).length;
  columns.forEach((v) => {
    if ((!isBox && selectedX === 0) || selectedY === 0) {
      result.push(v.id);
    }
  });

  return result;
};

export const isDateType = (key, rowData) => {
  if (key === undefined) return false;
  return GraphDateRegex.test(rowData[key]);
};

export const createGraphData = (xaxis, yaxis, rows) => {
  return yaxis.reduce(
    (acc, v) => {
      acc.push({
        name: v.name,
        x: xaxis ? rows.map((x) => x[xaxis.id]) : [],
        y: rows.map((x) => x[v.id]),
      });
      return acc;
    },
    [xaxis ? xaxis.name : ''],
  );
};

export const createColumns = (sampleRows) => {
  let useIndex = true;
  const findHeader =
    sampleRows.find((v) =>
      Object.values(v).find((x) => {
        const isSharp = x !== null && x.toString().trim().startsWith('#');
        if (isSharp) useIndex = false;
        return isSharp;
      }),
    ) ?? sampleRows[0];

  return Object.keys(findHeader).reduce((acc, v) => {
    acc.push({
      id: v,
      name:
        useIndex || findHeader[v] === null
          ? v
          : findHeader[v].toString().replace(/#/, ''),
      selected: {
        x: false,
        y: false,
      },
    });
    return acc;
  }, []);
};

export const createRows = (rows) => {
  let i = 0;
  return Object.values(rows).reduce((acc, v) => {
    const currentValue = Object.values(v)[0];
    const acceptPush =
      currentValue === null
        ? true
        : !currentValue.toString().trim().startsWith('#');
    if (acceptPush) {
      acc.push({
        ...v,
        uniqueId: `${i}`,
      });
      i++;
    }
    return acc;
  }, []);
};
