import React from 'react';
import PropTypes from 'prop-types';

const QuickViewTableColumn = ({
  changeFunc,
  columnData,
  errorList,
  disableX,
  ...rest
}) => {
  const changeCheck = (key) => {
    const newColumnData = columnData.map((column) => ({
      ...column,
      selected: {
        x:
          key === 'y'
            ? column.selected.x
            : column.id === rest.id && key === 'x' && !rest.selected.x,
        y:
          column.id === rest.id && key === 'y'
            ? !rest.selected.y
            : column.selected.y,
      },
    }));
    changeFunc(newColumnData, key === 'x' ? rest.id : undefined);
  };

  const changeTitle = (v) => {
    changeFunc(
      columnData.map((column) =>
        column.id !== rest.id ? column : { ...column, name: v },
      ),
    );
  };

  return (
    <th className={errorList.find((v) => v === rest.id) ? 'column-error' : ''}>
      <div className="custom-column">
        <div className="dropdown-wrapper">
          <div className="dropdown-trigger">
            {rest.selected.x ? <div className="option-x">X</div> : ''}
            {rest.selected.y ? <div className="option-y">Y</div> : ''}
            {(!rest.selected.x || disableX) && !rest.selected.y ? (
              <div className="option-none">-</div>
            ) : (
              ''
            )}
          </div>
          <div className="custom-dropdown">
            <label htmlFor={`option-x-${rest.id}`}>
              <input
                type="checkbox"
                id={`option-x-${rest.id}`}
                checked={rest.selected.x}
                onChange={() => changeCheck('x')}
                disabled={disableX}
              />
              <div className="check-x">X</div>
            </label>
            <label htmlFor={`option-y-${rest.id}`}>
              <input
                type="checkbox"
                id={`option-y-${rest.id}`}
                checked={rest.selected.y}
                onChange={() => changeCheck('y')}
              />
              <div className="check-y">Y</div>
            </label>
          </div>
        </div>
        <input
          type="text"
          value={rest.name}
          onChange={(e) => changeTitle(e.target.value)}
        />
      </div>
    </th>
  );
};
QuickViewTableColumn.propTypes = {
  changeFunc: PropTypes.func.isRequired,
  columnData: PropTypes.array.isRequired,
  errorList: PropTypes.array.isRequired,
  disableX: PropTypes.bool.isRequired,
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  name: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  selected: PropTypes.object.isRequired,
};

export default QuickViewTableColumn;
