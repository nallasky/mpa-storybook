import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import dayjs from 'dayjs';
import { Upload, Input, Select, Empty, DatePicker } from 'antd';
import {
  InboxOutlined,
  DoubleLeftOutlined,
  LeftOutlined,
  RightOutlined,
  DoubleRightOutlined,
  CloseOutlined,
} from '@ant-design/icons';
import CustomAccordion from '../common/molecules/CustomAccordion/CustomAccordion';
import { postRequestFormData } from '@libs/axios/requests';
import { URL_PREVIEW_SAMPLELOG } from '@constants/URL';
import { displayNotification } from '@libs/util/common/functionGroup';
import TableHeader from '../common/molecules/TableHeader/TableHeader';
import QuickViewTableColumn from './hooks/useQuickViewTableColumn';
import DraggableModal from '../common/organisms/DraggableModal/DraggableModal';
import * as SG from './styles/QuickViewStyles';
import {
  renderGraph,
  isDateType,
  createRows,
  createColumns,
  errorCheck,
  createGraphData,
} from './hooks/useQuickView';
import {
  Contents,
  Spinner,
} from '../common/organisms/ProcessingModal/styleGroup';
import { GraphDateRegex } from '@libs/util/regExp';

const initialGraphEditableInfo = {
  'title.text': undefined,
  'xaxis.title.text': undefined,
  'yaxis.title.text': undefined,
};

const QuickView = ({ onClose }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [logFile, setLogFile] = useState(undefined);
  const [graphOptions, setGraphOptions] = useState({
    type: 'bar',
    rangeX: {
      min: '',
      max: '',
    },
    rangeY: {
      min: '',
      max: '',
    },
  });
  const [tableOptions, setTableOptions] = useState({
    currentPage: 1,
    startLine: '',
  });
  const [graphEditableInfo, setGraphEditableInfo] = useState(
    initialGraphEditableInfo,
  );
  const [errorList, setErrorList] = useState([]);
  const [originRowData, setOriginRowData] = useState([]);
  const [columnData, setColumnData] = useState([]);
  const [rowData, setRowData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isInnerChange, setIsInnerChange] = useState(false);
  const [availableCancel, setAvailableCancel] = useState(true);
  const cancelTokenSource = useRef();
  const timeout = useRef(null);

  const onRelayout = (v) => {
    if (
      Object.keys(initialGraphEditableInfo).find((x) => x === Object.keys(v)[0])
    ) {
      setGraphEditableInfo({
        ...graphEditableInfo,
        [Object.keys(v)[0]]: Object.values(v)[0],
      });
    } else {
      let tmpX = undefined,
        tmpY = undefined;

      if (v['xaxis.range[0]'] !== undefined || v['xaxis.autorange']) {
        if (
          v['xaxis.autorange'] ||
          (!GraphDateRegex.test(v['xaxis.range[0]']) &&
            isNaN(parseInt(v['xaxis.range[0]'])))
        ) {
          tmpX = {
            min: '',
            max: '',
          };
        } else {
          tmpX = {
            min:
              GraphDateRegex.test(v['xaxis.range[0]']) &&
              graphOptions.type !== 'box'
                ? dayjs(v['xaxis.range[0]'])
                : v['xaxis.range[0]'],
            max:
              GraphDateRegex.test(v['xaxis.range[1]']) &&
              graphOptions.type !== 'box'
                ? dayjs(v['xaxis.range[1]'])
                : v['xaxis.range[1]'],
          };
        }
      }

      if (v['yaxis.range[0]'] !== undefined || v['yaxis.autorange']) {
        tmpY = {
          min: v['yaxis.autorange'] ? '' : v['yaxis.range[0]'],
          max: v['yaxis.autorange'] ? '' : v['yaxis.range[1]'],
        };
      }

      setGraphOptions({
        ...graphOptions,
        rangeX: tmpX ?? graphOptions.rangeX,
        rangeY: tmpY ?? graphOptions.rangeY,
      });
    }
    setIsInnerChange(true);
  };

  const onRestyle = (v) => {
    if (Object.keys(v[0])[0] === 'name') {
      let j = 0;
      const currentKey =
        graphOptions.type === 'density' && v[1][0] !== 0
          ? v[1][0] - 1
          : v[1][0];
      setColumnData(
        columnData.map((item) => {
          let newItem = item;
          if (item.selected.y) {
            newItem = {
              ...item,
              name: j === currentKey ? Object.values(v[0])[0] : item.name,
            };
            j++;
          }
          return newItem;
        }),
      );
      setIsInnerChange(true);
    }
  };

  const changeRange = (v, pKey, cKey) => {
    setGraphOptions(
      Array.isArray(v)
        ? {
            ...graphOptions,
            rangeX: {
              min: v[0],
              max: v[1],
            },
          }
        : {
            ...graphOptions,
            [pKey]: {
              ...graphOptions[pKey],
              [cKey]: v,
            },
          },
    );
    clearTimeout(timeout.current);
  };

  const changeType = (v) => {
    setGraphOptions({
      ...graphOptions,
      type: v,
      rangeX:
        v === 'box' && typeof graphOptions.rangeX.min === 'object'
          ? {
              min: '',
              max: '',
            }
          : graphOptions.rangeX,
    });
    if (v === 'box') {
      setColumnData(
        columnData.map((x) => ({
          ...x,
          selected: { ...x.selected, x: false },
        })),
      );
    }
    clearTimeout(timeout.current);
  };

  const changeColumn = (data, id) => {
    const currentRowData =
      tableOptions.startLine === ''
        ? originRowData[0]
        : originRowData.filter((v) => v.uniqueId >= tableOptions.startLine)[0];
    const prevDateType = isDateType(
      columnData.find((v) => v.selected.x)?.id,
      currentRowData,
    );
    const newDateType = isDateType(id, currentRowData);

    if (id && prevDateType !== newDateType) {
      setGraphOptions({
        ...graphOptions,
        rangeX: {
          min: '',
          max: '',
        },
      });
    }

    setColumnData(data);
    clearTimeout(timeout.current);
  };

  const changeStartLine = (v) => {
    setTableOptions({
      ...tableOptions,
      startLine: v,
    });
    clearTimeout(timeout.current);
  };

  const searchData = (text) => {
    const newRowData =
      text.length > 0
        ? originRowData.filter(
            (row) =>
              Object.values(row).filter(
                (v) =>
                  v !== null &&
                  v.toString().toLowerCase().includes(text.toLowerCase()),
              ).length > 0,
          )
        : originRowData;

    setRowData(newRowData);
    setTableOptions({
      ...tableOptions,
      currentPage: 1,
    });
  };

  const closeModal = () => {
    setIsVisible(false);
  };

  const cancelRequest = () => {
    cancelTokenSource.current.abort();
  };

  const uploadFile = async (file) => {
    if (!file.length) {
      setLogFile(undefined);
      return;
    }

    const currentFile = file[0].originFileObj;
    let newRows = [];
    let errorMsg = undefined;

    try {
      setIsLoading(true);
      const formData = new FormData();
      formData.append('files', currentFile);
      formData.append('source', 'local');
      cancelTokenSource.current = new AbortController();

      const { info } = await postRequestFormData(
        URL_PREVIEW_SAMPLELOG,
        formData,
        cancelTokenSource.current.signal,
      );
      setAvailableCancel(false);

      if (info) {
        setTableOptions({
          currentPage: 1,
          startLine: '',
        });
        setGraphOptions({
          ...graphOptions,
          rangeX: {
            min: '',
            max: '',
          },
          rangeY: {
            min: '',
            max: '',
          },
        });

        newRows = createRows(info.data.row);

        if (newRows.length) {
          setOriginRowData(newRows);
          setColumnData(createColumns(Object.values(info.data.row)));
          setRowData(newRows);
        }
      }
    } catch (e) {
      errorMsg = axios.isCancel(e) ? 'cancel' : e.response.data.msg;
    } finally {
      setTimeout(
        () => {
          setIsLoading(false);
          setAvailableCancel(true);
          if (errorMsg !== 'cancel') {
            displayNotification({
              message: errorMsg ? 'Error occurred' : 'Analysis Success',
              description:
                errorMsg ?? newRows.length > 0
                  ? 'The analysis was successful.'
                  : 'No data to display.',
              duration: 3,
              style: {
                borderLeft: errorMsg ? '5px solid red' : '5px solid green',
              },
            });
          }
        },
        errorMsg === 'cancel' ? 0 : 3000,
      );
      setLogFile(currentFile);
    }
  };

  useEffect(() => {
    if ((originRowData.length > 0 && columnData.length > 0) || isInnerChange) {
      if (isInnerChange) {
        renderGraph(
          createGraphData(
            columnData.find((v) => v.selected.x),
            columnData.filter((v) => v.selected.y),
            originRowData.filter((v) => v.uniqueId >= tableOptions.startLine),
          ),
          graphOptions,
          graphEditableInfo,
          onRelayout,
          onRestyle,
        );
        setIsInnerChange(false);
      } else {
        setErrorList([]);
        timeout.current = setTimeout(() => {
          const eList = errorCheck(
            columnData,
            graphOptions,
            tableOptions.startLine,
          );

          if (eList.length > 0) {
            setErrorList(eList);
          } else {
            renderGraph(
              createGraphData(
                columnData.find((v) => v.selected.x),
                columnData.filter((v) => v.selected.y),
                originRowData.filter(
                  (v) => v.uniqueId >= tableOptions.startLine,
                ),
              ),
              graphOptions,
              graphEditableInfo,
              onRelayout,
              onRestyle,
            );
          }
        }, 3000);
      }
    }
    // eslint-disable-next-line react/display-name
    return () => {
      clearTimeout(timeout.current);
      return null;
    };
  }, [
    graphOptions,
    tableOptions.startLine,
    columnData,
    originRowData,
    isInnerChange,
  ]);

  useEffect(() => {
    if (!isVisible) {
      onClose();
    }
  }, [isVisible]);

  return (
    <DraggableModal
      visible={isVisible}
      width={1600}
      title={
        <div css={SG.headerStyle}>
          <span>Quick Viewer</span>
          <button onClick={() => closeModal()} disabled={isLoading}>
            <CloseOutlined />
          </button>
        </div>
      }
      footer={[
        <button
          key="close"
          onClick={() => closeModal()}
          disabled={isLoading}
          css={SG.footerButtonStyle}
        >
          Close
        </button>,
      ]}
      maskClosable={false}
      closable={false}
    >
      <div css={SG.containerStyle}>
        <div className="quick-view-wrapper">
          <div
            className={'quick-view-contents' + (isLoading ? ' loading' : '')}
          >
            {isLoading ? (
              <Contents>
                <Spinner>
                  <div className="spinner-item" />
                  <div className="spinner-item" />
                  <div className="spinner-item" />
                  <div className="spinner-item" />
                  <div className="spinner-item" />
                </Spinner>
                <div className="message">
                  Analysing data
                  <span>.</span>
                  <span>.</span>
                  <span>.</span>
                </div>
                {availableCancel && (
                  <button
                    className="button-request-cancel"
                    onClick={() => cancelRequest()}
                  >
                    Cancel
                  </button>
                )}
              </Contents>
            ) : (
              <>
                <CustomAccordion title="Select Source File" quickView>
                  <>
                    <div className="upload-wrapper">
                      <Upload.Dragger
                        onChange={({ fileList }) => uploadFile(fileList)}
                        beforeUpload={() => false}
                        maxCount={1}
                        fileList={logFile ? [logFile] : []}
                      >
                        <p className="ant-upload-drag-icon">
                          <InboxOutlined />
                        </p>
                        <p className="ant-upload-text">
                          Click or drag file to this area to upload
                        </p>
                      </Upload.Dragger>
                    </div>
                    <div className="table-component">
                      {columnData.length > 0 ? (
                        <>
                          <TableHeader
                            currentPage={tableOptions.currentPage}
                            dataLength={rowData.length}
                            setPage={(v) =>
                              setTableOptions({
                                ...tableOptions,
                                currentPage: v,
                              })
                            }
                            onSearch={searchData}
                            rowSize={5}
                            disableSetRowSize
                          />
                          <div className="table-component-contents">
                            {rowData.length > 0 ? (
                              <>
                                <div className="table-wrapper">
                                  <table>
                                    <thead>
                                      <tr>
                                        <th
                                          className={
                                            errorList.find((v) => v === 'radio')
                                              ? 'column-error'
                                              : ''
                                          }
                                        >
                                          Start Line
                                        </th>
                                        {columnData.map((col) => (
                                          <QuickViewTableColumn
                                            key={col.id}
                                            changeFunc={changeColumn}
                                            columnData={columnData}
                                            errorList={errorList}
                                            disableX={
                                              graphOptions.type === 'box'
                                            }
                                            {...col}
                                          />
                                        ))}
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {rowData
                                        .slice(
                                          tableOptions.currentPage * 5 - 5,
                                          tableOptions.currentPage * 5,
                                        )
                                        .map((row, i) => (
                                          <tr key={i}>
                                            <td>
                                              <label
                                                className="radio-wrapper"
                                                htmlFor={`radio-${row.uniqueId}`}
                                              >
                                                <input
                                                  type="radio"
                                                  name="start-line"
                                                  id={`radio-${row.uniqueId}`}
                                                  value={row.uniqueId}
                                                  onChange={(e) =>
                                                    changeStartLine(
                                                      e.target.value,
                                                    )
                                                  }
                                                  checked={
                                                    tableOptions.startLine ===
                                                    row.uniqueId
                                                  }
                                                />
                                              </label>
                                            </td>
                                            {Object.keys(row)
                                              .filter((v) => v !== 'uniqueId')
                                              .map((k, j) => (
                                                <td key={j} title={row[k]}>
                                                  {row[k]}
                                                </td>
                                              ))}
                                          </tr>
                                        ))}
                                    </tbody>
                                  </table>
                                </div>
                                {rowData.length > 5 && (
                                  <div className="pagination">
                                    <button
                                      onClick={() =>
                                        setTableOptions({
                                          ...tableOptions,
                                          currentPage: 1,
                                        })
                                      }
                                      disabled={tableOptions.currentPage === 1}
                                    >
                                      <DoubleLeftOutlined />
                                    </button>
                                    <button
                                      onClick={() =>
                                        setTableOptions({
                                          ...tableOptions,
                                          currentPage:
                                            tableOptions.currentPage - 1,
                                        })
                                      }
                                      disabled={tableOptions.currentPage === 1}
                                    >
                                      <LeftOutlined />
                                    </button>
                                    <button
                                      onClick={() =>
                                        setTableOptions({
                                          ...tableOptions,
                                          currentPage:
                                            tableOptions.currentPage + 1,
                                        })
                                      }
                                      disabled={
                                        tableOptions.currentPage * 5 >
                                        rowData.length - 1
                                      }
                                    >
                                      <RightOutlined />
                                    </button>
                                    <button
                                      onClick={() =>
                                        setTableOptions({
                                          ...tableOptions,
                                          currentPage: Math.ceil(
                                            rowData.length / 5,
                                          ),
                                        })
                                      }
                                      disabled={
                                        tableOptions.currentPage * 5 >
                                        rowData.length - 1
                                      }
                                    >
                                      <DoubleRightOutlined />
                                    </button>
                                  </div>
                                )}
                              </>
                            ) : (
                              <Empty />
                            )}
                          </div>
                        </>
                      ) : (
                        <Empty />
                      )}
                    </div>
                  </>
                </CustomAccordion>
                <div className="graph-component">
                  <div className="graph-component-header">Graph</div>
                  <div className="graph-component-contents">
                    <div className="graph-setting">
                      <div className="graph-setting-header">Setting</div>
                      <div className="graph-setting-contents">
                        <div className="graph-setting-contents-wrapper">
                          <div>
                            <span>Graph Type:</span>
                            <Select
                              value={graphOptions.type}
                              onChange={(v) => changeType(v)}
                              style={{ width: '400px' }}
                            >
                              <Select.Option value="bar">Bar</Select.Option>
                              <Select.Option value="scatter">
                                Line
                              </Select.Option>
                              <Select.Option value="dot-plot">
                                Dot Plot
                              </Select.Option>
                              <Select.Option value="box">
                                Box Plot
                              </Select.Option>
                              <Select.Option value="density">
                                Density Plot
                              </Select.Option>
                            </Select>
                          </div>
                          <div>
                            <span>X Range:</span>
                            <div className="input-range">
                              {isDateType(
                                columnData.find((v) => v.selected.x)?.id,
                                tableOptions.startLine === ''
                                  ? originRowData[0]
                                  : originRowData.filter(
                                      (v) =>
                                        v.uniqueId >= tableOptions.startLine,
                                    )[0],
                              ) && graphOptions.type !== 'box' ? (
                                <DatePicker.RangePicker
                                  showTime
                                  inputReadOnly
                                  allowClear={false}
                                  style={{ width: '507.99px' }}
                                  value={
                                    graphOptions.rangeX.min === ''
                                      ? []
                                      : [
                                          graphOptions.rangeX.min,
                                          graphOptions.rangeX.max,
                                        ]
                                  }
                                  onChange={(v) => changeRange(v)}
                                />
                              ) : (
                                <>
                                  <Input
                                    type="text"
                                    style={{ width: '250px' }}
                                    value={graphOptions.rangeX.min}
                                    onChange={(e) =>
                                      changeRange(
                                        e.target.value,
                                        'rangeX',
                                        'min',
                                      )
                                    }
                                    className={
                                      errorList.find((v) => v === 'minX')
                                        ? 'input-error'
                                        : ''
                                    }
                                  />
                                  <Input
                                    type="text"
                                    style={{ width: '250px' }}
                                    value={graphOptions.rangeX.max}
                                    onChange={(e) =>
                                      changeRange(
                                        e.target.value,
                                        'rangeX',
                                        'max',
                                      )
                                    }
                                    className={
                                      errorList.find((v) => v === 'maxX')
                                        ? 'input-error'
                                        : ''
                                    }
                                  />
                                </>
                              )}
                            </div>
                          </div>
                          <div>
                            <span>Y Range:</span>
                            <div className="input-range">
                              <Input
                                type="text"
                                style={{ width: '250px' }}
                                value={graphOptions.rangeY.min}
                                onChange={(e) =>
                                  changeRange(e.target.value, 'rangeY', 'min')
                                }
                                className={
                                  errorList.find((v) => v === 'minY')
                                    ? 'input-error'
                                    : ''
                                }
                              />
                              <Input
                                type="text"
                                style={{ width: '250px' }}
                                value={graphOptions.rangeY.max}
                                onChange={(e) =>
                                  changeRange(e.target.value, 'rangeY', 'max')
                                }
                                className={
                                  errorList.find((v) => v === 'maxY')
                                    ? 'input-error'
                                    : ''
                                }
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="graph-render" id="quick-view-graph">
                      {originRowData.length === 0 &&
                        columnData.length === 0 && <Empty />}
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </DraggableModal>
  );
};

QuickView.propTypes = {
  onClose: PropTypes.func.isRequired,
};

export default QuickView;
