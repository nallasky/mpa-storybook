import { css } from '@emotion/react';

export const headerStyle = css`
  display: flex;
  align-items: center;
  justify-content: space-between;
  & > span {
    font-size: 18px;
    font-weight: bold;
  }
  & > button {
    background: none;
    border: none;
    cursor: pointer;
    &:hover > span {
      color: var(--ckr-gray-10);
    }
    & > span {
      color: var(--ckr-gray-7);
      cursor: pointer;
      transition: all 0.2s ease-in-out;
    }
  }
`;

export const footerButtonStyle = css`
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  background-color: var(--ckr-blue-6);
  color: var(--ckr-gray-1);
  box-shadow: 0px 2px 4px 2px rgba(0, 0, 0, 0.15);
  cursor: pointer;
  &:disabled {
    cursor: not-allowed;
    background-color: var(--ckr-gray-5);
  }
`;

export const containerStyle = css`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  & .quick-view-wrapper {
    height: 100%;
    width: 100%;
    background-color: var(--ckr-gray-1);
    & > div {
      padding: 1rem;
    }
    & > .quick-view-contents {
      width: 100%;
      &.loading {
        height: 80vh;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      @keyframes shadow {
        50% {
          box-shadow: none;
        }
      }
      & .input-error {
        animation: shadow 2s ease-in-out infinite;
        box-shadow: 0px 0px 3px 1px var(--ckr-red-6);
      }
      & .column-error {
        animation: shadow 2s ease-in-out infinite;
        box-shadow: 0px 0px 3px 1px var(--ckr-red-6) inset;
      }
      & > div + div {
        margin-top: 1rem;
      }
      & .upload-wrapper {
        display: flex;
        justify-content: center;
        & .ant-upload-drag {
          width: 600px;
        }
        & .ant-upload-list {
          height: 30px;
        }
      }
      & .table-component {
        margin-top: 3rem;
        & > .ant-empty {
          margin-bottom: 3rem;
        }
        & > div + div {
          margin-top: 1rem;
        }
        & > .table-component-contents {
          & .table-wrapper {
            overflow: auto;
            padding: 0.25rem 0;
            &::-webkit-scrollbar {
              height: 8px;
              width: 8px;
            }
            &::-webkit-scrollbar-track {
              background-color: transparent;
            }
            &::-webkit-scrollbar-thumb {
              border-radius: 2px;
              background-color: rgba(0, 0, 0, 0.2);
            }
            &::-webkit-scrollbar-button {
              width: 0;
              height: 0;
            }
            & > table {
              table-layout: fixed;
              width: 100%;
              & th,
              td {
                text-align: center;
                border: 1px solid var(--ckr-gray-5);
              }
              & th {
                width: 200px;
                background-color: var(--ckr-gray-4);
                transition: all 0.2s ease-in-out;
                &.disable {
                  opacity: 0.4;
                }
                &:first-of-type {
                  width: 80px;
                }
                & > .custom-column {
                  display: flex;
                  padding: 0.5rem;
                  align-items: center;
                  column-gap: 0.4rem;
                  width: 100%;
                  & > input[type='text'] {
                    width: 100%;
                    border: 1px solid transparent;
                    background-color: transparent;
                    outline: none;
                    font-weight: bold;
                    border-radius: 4px;
                    cursor: default;
                    &:focus {
                      border-radius: 4px;
                      font-weight: 400;
                      background-color: var(--ckr-gray-1);
                      cursor: text;
                    }
                  }
                  & .dropdown-wrapper {
                    position: relative;
                    display: flex;
                    align-items: center;
                    & .dropdown-trigger {
                      display: flex;
                      column-gap: 0.25rem;
                      &:not(.disable):hover ~ .custom-dropdown {
                        display: flex;
                      }
                      & > div {
                        border: 1px solid var(--ckr-gray-5);
                        border-radius: 2px;
                        background-color: var(--ckr-gray-1);
                        width: 22px;
                        height: 22px;
                        text-align: center;
                        font-size: 12px;
                        cursor: default;
                        &.option-x {
                          color: var(--ckr-blue-6);
                          border-color: var(--ckr-blue-3);
                          background-color: var(--ckr-blue-1);
                        }
                        &.option-y {
                          color: var(--ckr-red-6);
                          border-color: var(--ckr-red-3);
                          background-color: var(--ckr-red-1);
                        }
                        &.option-none {
                          color: var(--ckr-purple-6);
                          border-color: var(--ckr-purple-3);
                          background-color: var(--ckr-purple-1);
                        }
                      }
                    }
                  }
                  & .custom-dropdown {
                    &:hover {
                      display: flex;
                    }
                    position: absolute;
                    display: none;
                    z-index: 50;
                    left: -6px;
                    bottom: -46px;
                    align-items: center;
                    justify-content: space-between;
                    padding: 0.5rem;
                    background-color: var(--ckr-gray-1);
                    box-shadow: 0px 0px 3px 2px rgba(0, 0, 0, 0.15);
                    border-radius: 4px;
                    width: 65px;
                    & input[type='checkbox'] {
                      display: none;
                    }
                    &::after {
                      position: absolute;
                      content: '';
                      top: -8px;
                      left: 0;
                      width: 100%;
                      height: 14px;
                      background-color: transparent;
                    }
                    & label {
                      & > div {
                        border: 1px solid var(--ckr-gray-5);
                        border-radius: 2px;
                        background-color: var(--ckr-gray-1);
                        width: 22px;
                        height: 22px;
                        text-align: center;
                        font-size: 12px;
                        transition: all 0.3s;
                        cursor: pointer;
                      }
                      & > input[type='checkbox'] {
                        &:checked {
                          & ~ .check-x {
                            color: var(--ckr-blue-6);
                            border-color: var(--ckr-blue-3);
                            background-color: var(--ckr-blue-1);
                          }
                          & ~ .check-y {
                            color: var(--ckr-red-6);
                            border-color: var(--ckr-red-3);
                            background-color: var(--ckr-red-1);
                          }
                        }
                        &:disabled ~ div {
                          cursor: not-allowed;
                          color: var(--ckr-gray-3);
                          background-color: var(--ckr-gray-5);
                        }
                      }
                    }
                  }
                }
              }
              & td {
                background-color: var(--ckr-gray-1);
                padding: 0.5rem;
                white-space: pre;
                text-overflow: ellipsis;
                overflow: hidden;
                & > .radio-wrapper {
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  cursor: pointer;
                  & > input[type='radio'] {
                    cursor: pointer;
                  }
                }
              }
            }
          }
          & .pagination {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            column-gap: 0.5rem;
            margin-top: 0.5rem;
            & > button {
              border: 1px solid var(--ckr-gray-5);
              background-color: var(--ckr-gray-4);
              cursor: pointer;
              transition: all 0.2s ease-in-out;
              padding: 0.5rem;
              &:disabled {
                cursor: not-allowed;
                color: var(--ckr-gray-6);
              }
            }
          }
        }
      }
      & .graph-component {
        border: 1px solid var(--ckr-gray-5);
        border-radius: 4px;
        & > .graph-component-header {
          padding: 1rem;
          background-color: var(--ckr-gray-3);
          border-bottom: 1px solid var(--ckr-gray-5);
          border-radius: 4px 4px 0 0;
          font-size: 18px;
        }
        & > .graph-component-contents {
          padding: 1rem;
          background-color: var(--ckr-gray-2);
          border-radius: 0 0 4px 4px;
          & > .graph-setting {
            background-color: var(--ckr-gray-1);
            border: 1px solid var(--ckr-gray-5);
            border-radius: 4px;
            & > .graph-setting-header {
              font-size: 16px;
              padding: 1rem;
              border-bottom: 1px solid var(--ckr-gray-5);
              border-radius: 4px 4px 0 0;
            }
            & > .graph-setting-contents {
              padding: 1rem;
              border-radius: 0 0 4px 4px;
              & > .graph-setting-contents-wrapper {
                display: grid;
                grid-template-columns: repeat(2, auto);
                row-gap: 1rem;
                & > div {
                  display: flex;
                  align-items: center;
                  column-gap: 0.5rem;
                  width: 100%;
                  justify-content: flex-end;
                  &:first-of-type {
                    justify-content: flex-start;
                  }
                  & > .input-range {
                    display: flex;
                    column-gap: 0.5rem;
                  }
                  & > span {
                    white-space: pre;
                  }
                  &:last-of-type {
                    grid-area: 2 / 2;
                  }
                }
              }
            }
          }
          & > .graph-render {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 400px;
            margin-top: 1rem;
            background-color: var(--ckr-gray-1);
            border-radius: 4px;
            padding: 1rem;
            & > .plot-container {
              margin: 0 auto;
            }
          }
        }
      }
    }
  }
`;
