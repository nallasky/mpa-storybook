import styled from '@emotion/styled';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';

export const FocusImportFileWrapper = styled.div`
  width: 100%;
  max-width: ${(props) => `${props.mw}px`};
  & .ant-upload-list {
    max-width: ${(props) => `${props.mw}px`};
    height: ${(props) => `${props.mh}px`};
    overflow: auto;
    ${mixinList.customScroll({ radius: '0' })}
    & .ant-upload-list-item-name {
      max-width: calc(${(props) => `${props.mw}px`} - 50px);
    }
    & .ant-upload-span {
      justify-content: space-between;
    }
  }
`;
