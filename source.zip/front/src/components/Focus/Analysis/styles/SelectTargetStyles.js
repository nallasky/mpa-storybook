import styled from '@emotion/styled';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';

export const FocusSelectTargetWrapper = styled.div`
  position: relative;
  & > div + div {
    margin-top: 2rem;
  }
  & > button {
    ${mixinList.twoLineButton({ bottom: '0.5rem', right: '0' })}
  }
`;
