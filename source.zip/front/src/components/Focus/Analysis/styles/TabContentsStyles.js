import styled from '@emotion/styled';

export const FocusTabContentsWrapper = styled.div`
  display: ${(props) => props.isDisplay};
  & > div + div {
    margin-top: 1rem;
  }
`;
