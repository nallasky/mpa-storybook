import styled from '@emotion/styled';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';

export const FocusGraphSettingModalToleranceTableWrapper = styled.div`
  margin: 0 1.5rem;
  overflow: auto;
  max-height: calc((57px * 6) + 48px);
  ${mixinList.customScroll({ bgColor: 'var(--ckr-blue-3)' })}
`;
