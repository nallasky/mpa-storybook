import styled from '@emotion/styled';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';

export const FocusGraphDrawComponentWrapper = styled.div`
  position: relative;
  ${mixinList.flex({
    direction: 'column',
    align: 'flex-start',
    justify: 'center',
  })}
  width: 1408px;
  overflow: auto;
  ${mixinList.customScroll({})}
  & + div {
    margin-top: 1rem;
  }
  & .js-plotly-plot {
    & .plotly {
      & .modebar {
        width: 280px;
        left: 75px;
      }
    }
  }
`;

export const FocusGraphDrawComponentTableWrapper = styled.div`
  position: relative;
  width: 0;
  height: 0;
  overflow: visible;
  & > table {
    position: relative;
    user-select: none;
    pointer-events: none;
    z-index: 1;
    left: 75px;
    top: 25px;
    & td {
      padding: 0 0.25rem;
    }
  }
`;

export const FocusGraphDrawComponentTagWrapper = styled.div`
  ${mixinList.flex({ align: 'center' })}
  column-gap: 0.2rem;
  & > span:last-of-type {
    font-family: verdana;
    font-size: 12px;
    color: rgb(68, 68, 68);
  }
`;

export const FocusGraphDrawComponentColorCircle = styled.span`
  display: block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: ${(props) => props.color};
`;
