import React from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { LabelComponent } from '@components/Focus/Analysis/styles/CommonStyles';

const CommonInputFormWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: ${(props) => props.justify ?? 'flex-start'};
  column-gap: 1rem;
  width: 100%;
`;

const MiddleLineFormWrapper = styled.div`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 0;
  & > * {
    z-index: 2;
    background-color: white;
  }
  & > .title {
    margin-left: 2rem;
    padding: 0rem 0.5rem;
  }
  & > .control {
    padding-left: 0.5rem;
  }
  &::before {
    position: absolute;
    top: calc(50% + 1px);
    left: 0;
    content: '';
    height: 1px;
    width: 100%;
    background-color: #f0f0f0;
  }
`;

export const CommonInputForm = ({
  children,
  title,
  labelWidth,
  justify,
  useRequire,
}) => {
  return (
    <CommonInputFormWrapper justify={justify}>
      {title && (
        <LabelComponent labelWidth={labelWidth} useRequire={useRequire}>
          {title}
        </LabelComponent>
      )}
      {children}
    </CommonInputFormWrapper>
  );
};
CommonInputForm.propTypes = {
  children: PropTypes.node,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  labelWidth: PropTypes.number,
  justify: PropTypes.string,
  useRequire: PropTypes.bool,
};

export const MiddleLineForm = ({ children, title }) => {
  return (
    <MiddleLineFormWrapper>
      <span className="title">{title}</span>
      <div className="control">{children}</div>
    </MiddleLineFormWrapper>
  );
};
MiddleLineForm.propTypes = {
  children: PropTypes.node,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
