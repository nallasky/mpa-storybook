import styled from '@emotion/styled';

export const FocusFileGridWrapper = styled.div`
  display: grid;
  grid-template-columns: 160pxs 1fr;
  align-items: center;
  grid-template-areas:
    'label segment'
    '. file';
  row-gap: 1rem;
  & > .label-wrapper {
    grid-area: label;
  }
  & > .segment-wrapper {
    grid-area: segment;
  }
  & > div:last-of-type {
    grid-area: file;
  }
`;
