import styled from '@emotion/styled';

export const LabelComponent = styled.span`
  position: relative;
  display: inline-block;
  width: ${(props) => (props.labelWidth ? `${props.labelWidth}px` : '200px')};
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  ${(props) =>
    props.useRequire &&
    `
    padding-left: 12px;
    &::before {
      position: absolute;
      top: 0;
      left: 0;
      transform: translateY(3px);
      content: "*";
      color: var(--ckr-red-6);
    }
  `}
`;

export const ToleranceTable = styled.table`
  width: 100%;
  border: 1px solid var(--ckr-gray-4);
  & th,
  td {
    padding: 0.75rem 1rem;
    border: 1px solid var(--ckr-gray-4);
  }
  & > thead {
    & > tr {
      & > th {
        background-color: var(--ckr-gray-3);
        font-weight: normal;
      }
    }
  }
`;

export const TitleComponent = styled.p`
  font-size: 24px;
  color: var(--ckr-blue-6);
`;

export const mixinList = {
  flex: (props) => `
    display: flex;
    flex-direction: ${props.direction ?? 'row'};
    align-items: ${props.align ?? 'flex-start'};
    justify-content: ${props.justify ?? 'flex-start'};
  `,
  customScroll: (props) => `
    &::-webkit-scrollbar {
      width: ${props.width ?? '8px'};
      height: ${props.height ?? '8px'};
    }
    &::-webkit-scrollbar-track {
      background-color: rgba(0, 0, 0, 0.04);
    }
    &::-webkit-scrollbar-thumb {
      border-radius: ${props.radius ?? '2px'};
      background-color: ${props.bgColor ?? 'rgba(0, 0, 0, 0.2)'};
    }
    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }
  `,
  basicStyle: `
    border-radius: 4px;
    background-color: white;
    box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3), 0 2px 6px 2px rgba(60, 64, 67, 0.15);
  `,
  whiteButton: (props) => `
    position: ${props.position ?? 'absolute'};
    z-index: ${props.zIndex ?? 'auto'};
    top: ${props.top ?? 'initial'};
    right: ${props.right ?? 'initial'};
    left: ${props.left ?? 'initial'};
    bottom: ${props.bottom ?? 'initial'};
    font-size: ${props.fontSize ?? 'inherit'};
    width: fit-content;
    outline: none;
    background-color: var(--ckr-gray-1);
    border: 1px solid var(--ckr-gray-5);
    cursor: pointer;
    border-radius: ${props.radius ?? '0.5rem'};
    padding: ${props.padding ?? '0.25rem 1rem'};
    transition: all 0.2s;
    white-space: nowrap;
    & > span {
      margin-right: 0.5rem;
    }
    &::before {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      content: '';
      border-radius: ${props.radius ?? '0.5rem'};
      box-shadow: 0px 3px 3px 0px rgba(0, 0, 0, 0.15);
      transition: all 0.2s;
    }
    &:disabled {
      cursor: not-allowed;
      color: var(--ckr-gray-6);
      background-color: var(--ckr-gray-3);
    }
    &:active:not(:disabled) {
      transform: translateY(3px);
      &::before {
        box-shadow: none;
      }
    }
  `,
  twoLineButton: (props) => `
    position: absolute;
    top: ${props.top ?? 'initial'};
    left: ${props.left ?? 'initial'}; 
    bottom: ${props.bottom ?? 'initial'};
    right: ${props.right ?? 'initial'};
    padding: 0;
    ${mixinList.flex({
      direction: 'column',
      align: 'center',
      justify: 'center',
    })}
    cursor: pointer;
    background-color: white;
    border: none;
    outline: none;
    & > span {
      &:first-of-type {
        font-size: 26px;
        color: ${props.color ?? 'var(--ckr-green-6)'};
      }
      &:last-of-type {
        font-size: 8px;
        font-weight: 600;
      }
    }
    &:disabled {
      cursor: not-allowed;
      opacity: 0.5;
      & > span:first-of-type {
        color: var(--ckr-gray-6);
      }
    }
  `,
};

export const GraphCommonWrapper = styled.div`
  ${mixinList.flex({ align: 'center' })}
  min-height: 150px;
  & > div {
    &:first-of-type {
      flex-basis: 30%;
      ${mixinList.flex({ align: 'center', justify: 'center' })}
      font-size: 96px;
      color: var(--ckr-blue-9);
    }
    &:last-of-type {
      flex-basis: 100%;
      & > div + div {
        margin-top: 0.5rem;
      }
    }
  }
`;
