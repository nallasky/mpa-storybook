import styled from '@emotion/styled';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';

export const FocusOptionSettingWrapper = styled.div`
  position: relative;
  display: flex;
  overflow: hidden;
  width: 100%;
  &.active {
    & > div:last-of-type {
      transform: translateX(calc(-100%));
    }
  }
  & > div {
    flex-shrink: 0;
    width: 100%;
    background-color: white;
    transition: transform 0.3s;
    border: 1px solid white;
  }
  & > button {
    ${mixinList.whiteButton({
      zIndex: '2',
      top: '4px',
      right: '0',
      radius: '50%',
      padding: '0.25rem 0.5rem',
    })}
  }
`;
