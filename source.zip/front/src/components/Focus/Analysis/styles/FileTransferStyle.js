import styled from '@emotion/styled';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';

export const FileTransferRightTitleButton = styled.button`
  outline: none;
  border: 1px solid var(--ckr-blue-6);
  border-radius: 2px;
  background-color: var(--ckr-blue-6);
  color: white;
  height: 20px;
  font-size: 12px;
  padding: 0 0.75rem;
  cursor: pointer;
  line-height: 0;
  transition: all 0.2s;
  &:disabled {
    cursor: not-allowed;
    color: var(--ckr-gray-6);
    border-color: var(--ckr-gray-6);
    background-color: var(--ckr-gray-3);
  }
`;

export const FileTransferLeftTitleButton = styled.button`
  ${mixinList.flex({ align: 'center', justify: 'center' })}
  outline: none;
  border: none;
  background-color: transparent;
  color: var(--ckr-gray-9);
  cursor: pointer;
`;

export const FileTransferWrapper = styled.div`
  display: flex;
  align-items: center;
  column-gap: 0.75rem;
  background-color: white;
`;

export const FileTransferListWrapper = styled.div`
  display: flex;
  flex-direction: column;
  border: 1px solid #d9d9d9;
  border-radius: 2px;
  width: 100%;
  height: 200px;
  & input[type='text'] {
    font-size: 12px;
  }
  & > .list-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 12px;
    padding: 8px 12px 9px;
    border-bottom: 1px solid #d9d9d9;
  }
  & > .list-content {
    display: flex;
    flex: auto;
    flex-direction: column;
    overflow: hidden;
    font-size: 10px;
    & > .search-wrapper {
      padding: 12px;
      & .anticon-search {
        color: rgb(0 0 0 / 25%);
      }
    }
    & > .list-wrapper {
      flex: auto;
      overflow: auto;
      ${mixinList.customScroll({})}
      & .ant-tree-title {
        line-height: 1.15;
        vertical-align: middle;
        & > span {
          max-width: 210px;
        }
      }
      & .ant-checkbox-wrapper {
        & > .ant-checkbox {
          top: 0;
          line-height: unset;
        }
        & > span {
          line-height: 0.9;
        }
      }
      & > ul {
        margin: 0;
        padding: 0;
        list-style: none;
        & > li {
          display: flex;
          align-items: center;
          min-height: 32px;
          padding: 6px 12px;
          line-height: 20px;
          transition: all 0.3s;
          & > label {
            font-size: 10px;
            align-items: center;
          }
        }
      }
      & .site-tree-search-value {
        color: #f50;
      }
    }
  }
`;

export const FileTransferButtonWrapper = styled.div`
  display: flex;
  flex-direction: column;
  row-gap: 0.25rem;
  & > button {
    transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
    outline: none;
    border: 1px solid #1890ff;
    border-radius: 2px;
    cursor: pointer;
    color: white;
    background-color: #1890ff;
    text-shadow: 0 -1px 0 rgb(0 0 0 / 12%);
    box-shadow: 0 2px rgb(0 0 0 / 4%);
    &:disabled {
      cursor: not-allowed;
      color: rgb(0 0 0 / 25%);
      border-color: #d9d9d9;
      background: #f5f5f5;
      text-shadow: none;
      box-shadow: none;
    }
  }
`;

export const FileTransferLabelWrapper = styled.span`
  display: inline-block;
  max-width: 258.7px;
  font-size: 10px;
  white-space: pre;
  overflow: hidden;
  text-overflow: ellipsis;
`;
