import styled from '@emotion/styled';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';

export const FocusGraphSettingToleranceWrapper = styled.div`
  & button {
    ${mixinList.whiteButton({ position: 'relative', fontSize: '12px' })}
  }
  & > div:last-of-type {
    padding-left: 8rem;
    overflow: auto;
    max-height: calc((47px * 6) + 1px);
    ${mixinList.customScroll({ bgColor: 'var(--ckr-blue-3)' })}
  }
`;
