import styled from '@emotion/styled';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';

export const FocusFileStatusWrapper = styled.div`
  position: relative;
  & > button {
    ${mixinList.whiteButton({
      bottom: '10px',
      right: '0',
      fontSize: '12px',
    })}
  }
`;

export const FocusFileStatusTableComponent = styled.table`
  width: 100%;
  table-layout: fixed;
  border: 1px solid var(--ckr-gray-5);
  color: var(--ckr-gray-9);
  font-size: 12px;
  & th,
  td {
    padding: 0.5rem;
    border: 1px solid var(--ckr-gray-5);
    &.log-name,
    &.unknown {
      padding: 0;
    }
  }
  & > thead {
    & > tr {
      & > th {
        background-color: var(--ckr-gray-2);
        border-bottom: 1px solid var(--ckr-gray-5);
        &:first-of-type {
          width: 90px;
        }
        &:nth-of-type(2) {
          width: 200px;
        }
      }
    }
  }
  & > tbody {
    & > tr {
      & > td {
        &.title {
          text-align: center;
        }
      }
    }
  }
`;

export const FocusFileStatusFileNameWrapper = styled.div`
  @keyframes file-tag-blank {
    0% {
      opacity: 1;
    }
    25% {
      opacity: 0;
    }
    50% {
      opacity: 1;
    }
    75% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
  ${mixinList.flex({ align: 'center' })}
  overflow: hidden;
  column-gap: 0.5rem;
  & span {
    display: block;
    min-width: 40px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: pre;
    cursor: default;
    color: var(--ckr-blue-6);
    &.add {
      animation: file-tag-blank 1.5s both;
    }
    &.delete {
      animation: file-tag-blank 1.5s both reverse;
    }
    &.normal {
      animation: none;
    }
  }
`;

export const FocusFileStatusLogNameTypeWrapper = styled.div`
  @keyframes file-add {
    0% {
      opacity: 0;
      transform: translate(calc(-100% - 0.5rem), calc(-100% + 0.5rem));
    }
    40% {
      opacity: 1;
      transform: translate(-0.5rem, calc(-100% + 0.5rem));
    }
    100% {
      opacity: 0;
      transform: translate(-0.5rem, calc(-100% + 0.5rem));
    }
  }
  @keyframes file-delete {
    0% {
      opacity: 0;
      transform: translate(calc(100% - 0.5rem), calc(-100% + 0.5rem));
    }
    40% {
      opacity: 1;
      transform: translate(-0.5rem, calc(-100% + 0.5rem));
    }
    100% {
      opacity: 0;
      transform: translate(-0.5rem, calc(-100% + 0.5rem));
    }
  }
  position: relative;
  padding: 0.5rem;
  overflow: hidden;
  & > .title {
    position: relative;
    ${(props) =>
      props.isMust &&
      `
      text-indent: 8px;
      &::before {
        position: absolute;
        content: '*';
        transform: translate(-1rem, 2px);
        color: var(--ckr-red-6);
      }
    `}
  }
  & > .file-add {
    padding: 0.5rem 0;
    background-color: var(--ckr-blue-4);
    color: white;
    text-align: center;
    width: 100%;
    position: absolute;
    transform: translate(calc(-100% - 0.5rem), calc(-100% + 0.5rem));
    &.animate {
      animation: file-add 1.2s cubic-bezier(0.42, 0, 0, 1);
    }
  }
  & > .file-delete {
    padding: 0.5rem 0;
    background-color: var(--ckr-red-4);
    text-align: center;
    color: white;
    width: 100%;
    position: absolute;
    transform: translate(calc(100% - 0.5rem), calc(-100% + 0.5rem));
    &.animate {
      animation: file-delete 1.2s cubic-bezier(0.42, 0, 0, 1);
    }
  }
`;

export const FocusFileStatusPopoverTitleWrapper = styled.div`
  font-size: 18px;
  font-weight: bold;
  padding: 0.3rem 0;
`;

export const FocusFileStatusPopoverFileListWrapper = styled.div`
  ${mixinList.flex({ direction: 'column' })}
  row-gap: 1rem;
  max-height: calc(42.56px * 5 + 4rem);
  overflow: auto;
  ${mixinList.customScroll({ width: '6px', height: '6px', bgColor: '#91d5ff' })}
`;

export const FocusFileStatusPopoverFileListItem = styled.div`
  ${mixinList.flex({ align: 'center' })}
  column-gap: 1rem;
  pointer-events: none;
  & > .icon-wrapper {
    background-color: #1890ff;
    font-size: 22px;
    text-align: center;
    padding: 0.25rem 0.75rem;
    border-radius: 4px;
    color: white;
  }
  & > .info-wrapper {
    & > p {
      width: 295px;
      white-space: pre;
      text-overflow: ellipsis;
      overflow: hidden;
      margin-bottom: 0;
    }
    & > .file-name {
      font-size: 14px;
      font-weight: 500;
    }
    & > .log-name {
      font-size: 12px;
      color: #8c8c8c;
    }
  }
`;

export const FocusFileStatusGuardComponent = styled.div`
  position: fixed;
  display: block;
  height: 100%;
  width: 100%;
  z-index: 10000;
  background-color: transparent;
`;
