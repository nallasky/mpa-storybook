import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faExchangeAlt } from '@fortawesome/free-solid-svg-icons';
import FocusAnalysisFileStatus from '@components/Focus/Analysis/FileStatus';
import FocusAnalysisSelectTarget from '@components/Focus/Analysis/SelectTarget';
import {
  targetInfoRidSelector,
  targetInfoCurrentTabSelector,
  focusTargetInfoActions,
} from '@reducers/slices/FocusInfo';
import { FocusOptionSettingWrapper } from '@components/Focus/Analysis/styles/OptionSettingStyles';

const FocusAnalysisOptionSetting = () => {
  const rid = useSelector(targetInfoRidSelector);
  const currentTab = useSelector(targetInfoCurrentTabSelector);
  const dispatch = useDispatch();

  const changeComponent = () => {
    dispatch(
      focusTargetInfoActions.UpdateTargetInfoCurrentTab(
        currentTab === 'target' ? 'status' : 'target',
      ),
    );
  };

  return (
    <FocusOptionSettingWrapper
      className={currentTab === 'target' && rid ? 'active' : ''}
    >
      <button onClick={changeComponent} disabled={!rid}>
        <FontAwesomeIcon icon={faExchangeAlt} />
      </button>
      <FocusAnalysisFileStatus />
      <FocusAnalysisSelectTarget />
    </FocusOptionSettingWrapper>
  );
};

export default FocusAnalysisOptionSetting;
