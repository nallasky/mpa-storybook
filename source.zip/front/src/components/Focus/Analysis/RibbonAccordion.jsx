import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { UpOutlined } from '@ant-design/icons';

const Wrapper = styled.div`
  position: relative;
  padding-top: 22px;
`;

const AccordionTitle = styled.button`
  position: absolute;
  display: inline-block;
  top: 0;
  left: 0;
  outline: none;
  border: none;
  color: white;
  background-color: #40a9ff;
  line-height: 28px;
  min-height: 28px;
  padding: 0.5rem 0;
  border-radius: 6px 6px 6px 0px;
  cursor: pointer;
  &::before {
    position: absolute;
    bottom: -24px;
    left: 0;
    border: 16px solid #003a8c;
    border-top-width: 12px;
    border-bottom-width: 12px;
    border-left-color: transparent;
    border-bottom-color: transparent;
    content: '';
  }
  & > span {
    padding: 0 1rem;
    &:last-of-type {
      &.collapse {
        & > span {
          transform: rotate(180deg);
        }
      }
    }
  }
`;

const AccordionBody = styled.div`
  width: calc(100% - 2rem);
  margin-left: 2rem;
  border: 1px solid #91d5ff;
  padding: 22px 1rem;
  & > div {
    &.hidden {
      display: none;
    }
  }
`;

const RibbonAccordion = ({ children, initialState, title }) => {
  const [collapse, setCollapse] = useState(initialState ?? false);
  return (
    <Wrapper>
      <AccordionTitle onClick={() => setCollapse(!collapse)}>
        <span>{title}</span>
        <span className={collapse ? 'collapse' : ''}>
          <UpOutlined />
        </span>
      </AccordionTitle>
      <AccordionBody>
        <div className={collapse ? 'hidden' : ''}>{children}</div>
      </AccordionBody>
    </Wrapper>
  );
};
RibbonAccordion.propTypes = {
  children: PropTypes.node,
  initialState: PropTypes.bool,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

export default RibbonAccordion;
