import React from 'react';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';
import FocusAnalysisGraphDrawComponent from '@components/Focus/Analysis/GraphDrawComponent';
import { graphRenderInfoSelector } from '@reducers/slices/FocusInfo';

const FocusAnalysisGraphDisplay = ({ type, callbackFunc }) => {
  const graphInfo = useSelector(graphRenderInfoSelector);
  const {
    graph_data,
    graph_scale: {
      line_graph_left_scale,
      stacked_graph_left_scale,
      stacked_graph_right_scale,
    },
    graph_setting,
    selected_shot,
  } = graphInfo;

  return (
    <div>
      <FocusAnalysisGraphDrawComponent
        type={type}
        data={{
          graph_data: graph_data[type],
          graph_scale: {
            line_graph_left_scale,
          },
          graph_setting: graph_setting[type],
          selected_shot: selected_shot[type],
        }}
        graphType="line"
        callbackFunc={callbackFunc}
      />
      <FocusAnalysisGraphDrawComponent
        type={type}
        data={{
          graph_data: graph_data[type],
          graph_scale: {
            stacked_graph_left_scale,
            stacked_graph_right_scale,
          },
          graph_setting: graph_setting[type],
          selected_shot: selected_shot[type],
        }}
        graphType="stacked"
        callbackFunc={callbackFunc}
      />
    </div>
  );
};
FocusAnalysisGraphDisplay.propTypes = {
  type: PropTypes.string,
  callbackFunc: PropTypes.func,
};

export default FocusAnalysisGraphDisplay;
