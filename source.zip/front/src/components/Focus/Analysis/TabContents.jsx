import React from 'react';
import PropTypes from 'prop-types';
import FocusAnalysisGraphSetting from '@components/Focus/Analysis/GraphSetting';
import FocusAnalysisGraphColorSetting from '@components/Focus/Analysis/GraphColorSetting';
import FocusAnalysisGraphDisplay from '@components/Focus/Analysis/GraphDisplay';
import { FocusTabContentsWrapper } from '@components/Focus/Analysis/styles/TabContentsStyles';

const FocusAnalysisTabContents = ({ type, display, callbackFunc }) => {
  return (
    <FocusTabContentsWrapper
      id={`${type.replace(' ', '_')}`}
      isDisplay={display ? 'block' : 'none'}
    >
      <FocusAnalysisGraphSetting type={type} />
      <FocusAnalysisGraphColorSetting type={type} />
      <FocusAnalysisGraphDisplay type={type} callbackFunc={callbackFunc} />
    </FocusTabContentsWrapper>
  );
};
FocusAnalysisTabContents.propTypes = {
  type: PropTypes.string,
  display: PropTypes.bool,
  callbackFunc: PropTypes.func,
};

export default FocusAnalysisTabContents;
