import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import dayjs from 'dayjs';
import { LineChartOutlined, CloudDownloadOutlined } from '@ant-design/icons';
import CustomRadioGroup from '@components/common/molecules/CustomRadioGroup/CustomRadioGroup';
import FocusAnalysisTabContents from '@components/Focus/Analysis/TabContents';
import ProcessingModal from '@components/common/organisms/ProcessingModal/ProcessingModal';
import useModal from '@libs/util/modalControl/useModal';
import {
  graphDataSelector,
  targetInfoExportSelector,
  initialGraphData,
} from '@reducers/slices/FocusInfo';
import { post_Focus_Export_File } from '@libs/axios/focusRequest';
import {
  getFocusAnalysisGraphImgUrl,
  displayError,
} from '@libs/util/common/functionGroup';
import { FocusCommonMainComponent } from '@components/Focus/Common/CommonElements';

const radioArr = [
  {
    id: 'PS Z',
    icon: <LineChartOutlined />,
    title: 'PS Z',
    disabled: false,
  },
  {
    id: 'PS Pitch',
    icon: <LineChartOutlined />,
    title: 'PS Pitch',
    disabled: false,
  },
  {
    id: 'PS Roll',
    icon: <LineChartOutlined />,
    title: 'PS Roll',
    disabled: false,
  },
];

const graphIdArr = [
  'PS_Z_line',
  'PS_Z_stacked',
  'PS_Pitch_line',
  'PS_Pitch_stacked',
  'PS_Roll_line',
  'PS_Roll_stacked',
];
const tabContentsIdList = [
  ['PS Z', 'PS_Z'],
  ['PS Pitch', 'PS_Pitch'],
  ['PS Roll', 'PS_Roll'],
];
const defaultTitleList = ['shot', 'plate', 'glass_id'];
const csvFileNameList = {
  'PS Z': 'PS_Z.Focus_analysis_ps_z_',
  'PS Pitch': 'PS_Pitch.Focus_analysis_ps_pitch_',
  'PS Roll': 'PS_Roll.Focus_analysis_ps_roll_',
};
const pngFileNameList = {
  PS_Z_line: 'PS_Z.focus_ps_z_line.png',
  PS_Z_stacked: 'PS_Z.focus_ps_z_stacked.png',
  PS_Pitch_line: 'PS_Pitch.focus_ps_pitch_line.png',
  PS_Pitch_stacked: 'PS_Pitch.focus_ps_pitch_stacked.png',
  PS_Roll_line: 'PS_Roll.focus_ps_roll_line.png',
  PS_Roll_stacked: 'PS_Roll.focus_ps_roll_stacked.png',
};

const changeStyleDisplay = (currentTab, isDisplay) => {
  for (const [tab, id] of tabContentsIdList) {
    if (tab === currentTab) continue;
    const element = document.getElementById(id);
    if (isDisplay) {
      element.style.display = 'block';
    } else {
      element.removeAttribute('style');
    }
  }
};

const createCsvString = (rows, titles) => {
  const titleList = defaultTitleList.concat(titles);
  let csvString = titleList.join(',') + '\r\n';
  for (const row of rows) {
    for (const title of titleList) {
      csvString += `${row[title]},`;
    }
    csvString = csvString.slice(0, -1) + '\r\n';
  }
  return csvString;
};

const FocusAnalysisResult = () => {
  const { openModal, closeModal } = useModal();
  const savedDataInfo = useSelector(graphDataSelector);
  const exportInfo = useSelector(targetInfoExportSelector);

  const [currentTab, setCurrentTab] = useState('PS Z');

  const changeLoadState = (v) => {
    const { isOpen, ...etc } = v;
    if (isOpen) {
      openModal(ProcessingModal, {
        ...etc,
        useCancel: false,
      });
    } else {
      closeModal(ProcessingModal);
    }
  };

  const onClickDownload = () => {
    changeLoadState({
      isOpen: true,
      title: 'Download data',
      message: 'Creating download data',
    });
    const pngFiles = {
      PS_Z_line: '',
      PS_Z_stacked: '',
      PS_Pitch_line: '',
      PS_Pitch_stacked: '',
      PS_Roll_line: '',
      PS_Roll_stacked: '',
    };
    const csvFiles = {
      'PS Pitch': '',
      'PS Roll': '',
      'PS Z': '',
    };
    setTimeout(() => {
      changeStyleDisplay(currentTab, true);
      Promise.all(
        graphIdArr.map(async (id) => {
          const element = document.getElementById(id);
          if (!element) return undefined;
          const url = await getFocusAnalysisGraphImgUrl(element);
          return { id, url };
        }),
      )
        .then((result) => {
          changeStyleDisplay(currentTab, false);
          for (const item of result) {
            if (!item) continue;
            const { id, url } = item;
            pngFiles[id] = url;
          }
          for (const [key, value] of Object.entries(savedDataInfo)) {
            csvFiles[key] = createCsvString(
              value,
              Object.keys(value[0]).filter(
                (k) => !defaultTitleList.includes(k),
              ),
            );
          }
        })
        .then(async () => {
          const formData = new FormData();
          const currentTime = dayjs().format('YYYYMMDDHHmmss');
          for (const [id, url] of Object.entries(csvFiles)) {
            formData.append(
              'files',
              new File([url], `${csvFileNameList[id]}${currentTime}.csv`),
            );
          }
          for (const [id, url] of Object.entries(pngFiles)) {
            if (!url) continue;
            formData.append('files', new File([url], pngFileNameList[id]));
          }
          formData.append(
            'setting',
            new Blob([JSON.stringify(exportInfo)], {
              type: 'application/json',
            }),
            'setting.json',
          );
          await post_Focus_Export_File(formData);
        })
        .catch((e) => {
          displayError(e?.message ?? e);
        })
        .finally(() => {
          changeLoadState({ isOpen: false });
        });
    }, 250);
  };

  if (JSON.stringify(initialGraphData) === JSON.stringify(savedDataInfo))
    return;

  return (
    <FocusCommonMainComponent isResult>
      <button onClick={onClickDownload}>
        <CloudDownloadOutlined />
        <span>Download</span>
      </button>
      <CustomRadioGroup
        options={radioArr}
        changeFunc={(v) => setCurrentTab(v)}
        useTransition={false}
      />
      <div>
        {radioArr.map(({ id }) => (
          <FocusAnalysisTabContents
            key={id}
            type={id}
            display={currentTab === id}
            callbackFunc={changeLoadState}
          />
        ))}
      </div>
    </FocusCommonMainComponent>
  );
};

export default FocusAnalysisResult;
