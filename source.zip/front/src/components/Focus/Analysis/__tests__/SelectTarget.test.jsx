import React from 'react';
import FocusAnalysisSelectTarget, { focusAnalysisTargetOnStart, focusAnalysisTargetChangePeriod, focusAnalysisTargetChangeFab, focusAnalysisTargetCommonChangeSelect, focusAnalysisTargetCheckFabName } from "@components/Focus/Analysis/SelectTarget";
import { screen, fireEvent, waitFor, act } from '@testing-library/react';
import renderWithProviders from "@libs/util/testReduxWrapper";
import { initialTargetInfoState } from "@reducers/slices/FocusInfo";
import dayjs from 'dayjs'
import advancedFormat from 'dayjs/plugin/advancedFormat'
import customParseFormat from 'dayjs/plugin/customParseFormat'
import localeData from 'dayjs/plugin/localeData'
import weekday from 'dayjs/plugin/weekday'
import weekOfYear from 'dayjs/plugin/weekOfYear'
import weekYear from 'dayjs/plugin/weekYear'

dayjs.extend(customParseFormat)
dayjs.extend(advancedFormat)
dayjs.extend(weekday)
dayjs.extend(localeData)
dayjs.extend(weekOfYear)
dayjs.extend(weekYear)

const reduxDefaultTargetState = {
  ...initialTargetInfoState,
  rid: 'request_20230127_114601672646',
  fab_name: '',
  fab_list: ['test'],
  period: ["2021-12-08 11:39:16", "2021-12-18 14:47:58"],
  selectedPeriod: ["2021-12-08 11:39:16", "2021-12-18 14:47:58"],
  job_list: ["2X2_TACT/oas_cit3", "2X2_TACT/oas_cit4", 'eval7101/1st_cits'],
  lot_id_list: {
    "2X2_TACT/oas_cit3": {
      normal_lot_id: [],
      pseudo_lot_id: ["DLID20211208113904_", "DLID20211208115332_"],
    },
    "2X2_TACT/oas_cit4": {
      normal_lot_id: ["DLID20211002131800"],
      pseudo_lot_id: ["DLID20211208113904_", "DLID20211208115332_"]
    },
    "eval7101/1st_cits": {
      normal_lot_id: [],
      pseudo_lot_id: ["DLID20211208142838_LOTID_2021-12-08_0"],
    },
  }
};

describe('FocusAnalysisSelectTarget', () => {
  test('render case 1', async () => {
    renderWithProviders(<FocusAnalysisSelectTarget />, { preloadedState: { FocusTargetInfo: reduxDefaultTargetState }});
    expect(screen.getByText('Select Target')).toBeInTheDocument();
    //screen.debug(undefined, 300000);

    const startButton = screen.getByTestId('focus-common-target-start-analysis-button');
    expect(startButton).toBeDisabled();

    const selectFab = screen.getByTestId('focus-analysis-target-fab');
    expect(selectFab.querySelectorAll('input[type="search"]')[0]).toHaveValue('');
    fireEvent.mouseDown(selectFab.firstElementChild);
    await waitFor(() => screen.getByRole('option', { name: 'test' }));
    fireEvent.click(screen.getByRole('option', { name: 'test' }));

    const periodStart = screen.getByPlaceholderText('Start date');
    fireEvent.mouseDown(periodStart);
    fireEvent.change(periodStart, { target: { value: "2021-12-09 11:39:16" } });
    fireEvent.click(document.querySelectorAll(".ant-picker-cell-selected")[0]);
    expect(periodStart.value).toBe("2021-12-09 11:39:16");

    const periodEnd = screen.getByPlaceholderText('End date');
    fireEvent.mouseDown(periodEnd);
    fireEvent.change(periodEnd, { target: { value: "2021-12-17 14:47:58" } });
    fireEvent.click(document.querySelectorAll(".ant-picker-cell-selected")[0]);
    expect(periodEnd.value).toBe("2021-12-17 14:47:58")

    const selectJob = screen.getByTestId('focus-analysis-target-job');
    expect(selectJob.querySelectorAll('input[type="search"]')[0]).toHaveValue('');
    fireEvent.mouseDown(selectJob.firstElementChild);
    await waitFor(() => screen.getByRole('option', { name: '2X2_TACT/oas_cit3' }));
    fireEvent.click(screen.getByRole('option', { name: '2X2_TACT/oas_cit3' }));
  });

  test('render case 2', () => {
    renderWithProviders(<FocusAnalysisSelectTarget />, {
      preloadedState: {
        FocusTargetInfo: {
          ...reduxDefaultTargetState,
          fab_name: 'test',
        }
      }
    });
  });

  test('render case 3', async () => {
    renderWithProviders(<FocusAnalysisSelectTarget />, {
      preloadedState: {
        FocusTargetInfo: {
          ...reduxDefaultTargetState,
          fab_name: 'test',
          job: '2X2_TACT/oas_cit3',
        }
      }
    });

    const selectLotId = screen.getByTestId('focus-analysis-target-lotid');
    expect(selectLotId.querySelectorAll('input[type="search"]')[0]).toHaveValue('');
    fireEvent.mouseDown(selectLotId.firstElementChild);
    await waitFor(() => screen.getByRole('option', { name: 'DLID20211208113904_' }));
    fireEvent.click(screen.getByRole('option', { name: 'DLID20211208113904_' }));
  });

  test('render case 4', async  () => {
    renderWithProviders(<FocusAnalysisSelectTarget />, {
      preloadedState: {
        FocusTargetInfo: {
          ...reduxDefaultTargetState,
          fab_name: 'test',
          job: '2X2_TACT/oas_cit3',
          lot_id: 'DLID20211208113904_',
        }
      }
    });
    const startButton = screen.getByTestId('focus-common-target-start-analysis-button');
    expect(startButton).not.toBeDisabled();
    await act(async () => await fireEvent.click(startButton));
  });
});

describe('focusAnalysisTargetOnStart', () => {
  test('success ', async () => {
    await waitFor(() => focusAnalysisTargetOnStart(
      jest.fn(),
      {
        ...reduxDefaultTargetState,
        fab_name: 'test',
        job: '2X2_TACT/oas_cit3',
        lot_id: 'DLID20211208113904_'
      },
      jest.fn(),
      jest.fn(),
    ));
  });

  test('response data is empty', async () => {
    await waitFor(() => focusAnalysisTargetOnStart(
      jest.fn(),
      {
        ...reduxDefaultTargetState,
        fab_name: 'empty',
        job: '2X2_TACT/oas_cit3',
        lot_id: 'DLID20211208113904_'
      },
      jest.fn(),
      jest.fn(),
    ));
  });

  test('error case 1', async () => {
    await waitFor(() => focusAnalysisTargetOnStart(
      jest.fn(),
      {
        ...reduxDefaultTargetState,
        fab_name: 'error_object',
      },
      jest.fn(),
      jest.fn(),
    ));
  });

  test('error case 2', async () => {
    await act(() => focusAnalysisTargetOnStart(
      jest.fn(),
      undefined,
      jest.fn(),
      jest.fn(),
    ));
  });
})

describe('focusAnalysisTargetChangePeriod', () => {
  test('success', async () => {
    await act(() => focusAnalysisTargetChangePeriod([dayjs("2021-12-18 11:39:16"), dayjs("2021-12-28 14:47:58")], jest.fn(), reduxDefaultTargetState));
  });

  test('error case', async () => {
    await act(() => focusAnalysisTargetChangePeriod(undefined, jest.fn(), reduxDefaultTargetState));
  });
});

describe('focusAnalysisTargetChangeFab', () => {
  test('success', async () => {
    await act(() => focusAnalysisTargetChangeFab(jest.fn(), 'new_fab_name'));
  });

  test('error case', async () => {
    await act(() => focusAnalysisTargetChangeFab(jest.fn(), 'error'));
  });
});

describe('focusAnalysisTargetCommonChangeSelect', () => {
  test('success', () => {
    act(() => focusAnalysisTargetCommonChangeSelect(jest.fn(), { key: 'fab_name', value: 'new_fab_name' }));
  })
});

describe('focusAnalysisTargetCheckFabName', () => {
  test('case 1 (already registered fab name)', () => {
    act(() => focusAnalysisTargetCheckFabName(['test', 'test1'], 'test'));
  })
  test('case 2 (regex error)', () => {
    act(() => focusAnalysisTargetCheckFabName(['test', 'test1'], '!!!!!!!!!!'));
  })
});