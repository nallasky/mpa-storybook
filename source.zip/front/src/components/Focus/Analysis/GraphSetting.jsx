import React, { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { SettingOutlined, EditOutlined } from '@ant-design/icons';
import FocusCommonRibbonAccordion from '@components/Focus/Common/RibbonAccordion';
import { ToleranceTable } from '@components/Focus/Common/styles/CommonStyles';
import { displayError } from '@libs/util/common/functionGroup';
import {
  FocusCommonMiddleLineForm,
  FocusCommonGraphScaleView,
  FocusCommonGraphShotSelectForm,
  FocusCommonGraphAccordionBodyComponent,
} from '@components/Focus/Common/CommonElements';
import useModal from '@libs/util/modalControl/useModal';
import { FocusToleranceModal } from '@components/Focus/Analysis/ToleranceEditModal';
import { FocusCommonScaleEditModal } from '@components/Focus/Common/ScaleEditModal';
import {
  graphShotSettingSelector,
  graphScaleSelector,
  graphSettingSelector,
  targetInfoFabSelector,
  focusSavedGraphInfoActions,
  initialGraphScale,
} from '@reducers/slices/FocusInfo';
import {
  put_Focus_Save_Scale,
  put_Focus_Save_Tolerance,
} from '@libs/axios/focusRequest';
import { FocusGraphSettingToleranceWrapper } from '@components/Focus/Analysis/styles/GraphSettingStyles';

const allTitle = 'Applies to all tabs(PSZ/PS Pitch/PS Roll).';

const FocusAnalysisGraphSetting = ({ type }) => {
  const shotInfo = useSelector(graphShotSettingSelector);
  const scaleInfo = useSelector(graphScaleSelector);
  const settingInfo = useSelector(graphSettingSelector);
  const {
    list: shotOptionList,
    selected: shotSelected,
    isAll: shotIsAll,
  } = shotInfo;

  return (
    <FocusCommonRibbonAccordion title="Graph setting" initialState={true}>
      <FocusCommonGraphAccordionBodyComponent icon={<SettingOutlined />}>
        <div>
          <FocusAnalysisGraphShotSelect
            type={type}
            optionList={shotOptionList}
            selectValue={shotSelected[type]}
            switchValue={shotIsAll}
          />
          <FocusAnalysisGraphScale
            data={{
              line_graph_left_scale: scaleInfo.line_graph_left_scale,
              stacked_graph_left_scale: scaleInfo.stacked_graph_left_scale,
              stacked_graph_right_scale: scaleInfo.stacked_graph_right_scale,
            }}
          />
          <FocusAnalysisGraphTolerance
            type={type}
            data={{
              'PS Pitch': settingInfo['PS Pitch'],
              'PS Roll': settingInfo['PS Roll'],
              'PS Z': settingInfo['PS Z'],
            }}
          />
        </div>
      </FocusCommonGraphAccordionBodyComponent>
    </FocusCommonRibbonAccordion>
  );
};
FocusAnalysisGraphSetting.propTypes = {
  type: PropTypes.string,
};
FocusAnalysisGraphSetting.displayName = 'GraphSetting';

const FocusAnalysisGraphShotSelect = ({
  type,
  optionList,
  selectValue,
  switchValue,
}) => {
  const dispatch = useDispatch();

  const onShotChange = useCallback(
    (allFlag, v) => {
      setTimeout(() => {
        if (allFlag) {
          dispatch(
            focusSavedGraphInfoActions.UpdateSavedGraphInfoShotSelectedAll({
              isAll: allFlag,
              value: v,
            }),
          );
        } else {
          dispatch(
            focusSavedGraphInfoActions.UpdateSavedGraphInfoShotSelected({
              key: type,
              value: v,
            }),
          );
        }
      }, 200);
    },
    [type],
  );

  const onChangeShotSwitch = useCallback(() => {
    setTimeout(
      () => {
        dispatch(
          focusSavedGraphInfoActions.UpdateSavedGraphInfoShotSelectedAll({
            isAll: !switchValue,
            value: selectValue,
          }),
        );
      },
      !switchValue ? 200 : 0,
    );
  }, [switchValue, selectValue]);

  return (
    <FocusCommonGraphShotSelectForm
      selectProps={{
        style: { minWidth: '300px' },
        value: selectValue,
        onChange: (v) => onShotChange(switchValue, v),
      }}
      optionList={optionList}
      allButtonInfo={{
        title: allTitle,
        props: {
          checked: switchValue,
          onChange: onChangeShotSwitch,
        },
      }}
    />
  );
};
FocusAnalysisGraphShotSelect.propTypes = {
  type: PropTypes.string,
  optionList: PropTypes.array,
  selectValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  switchValue: PropTypes.bool,
};
FocusAnalysisGraphShotSelect.displayName = 'GraphShotSelect';

const graphScaleKeyTitleInfo = {
  line_graph_left_scale: "Line graph's left scale",
  stacked_graph_left_scale: "Stacked graph's left scale",
  stacked_graph_right_scale: "Stacked graph's right scale",
};

const FocusAnalysisGraphScale = ({ data }) => {
  const dispatch = useDispatch();
  const { openModal } = useModal();

  const onSave = (v) => {
    const updateData = {
      ...initialGraphScale,
      ...v,
    };
    setTimeout(() => {
      dispatch(
        focusSavedGraphInfoActions.UpdateSavedGraphInfoSingle({
          key: 'graph_scale',
          value: updateData,
        }),
      );
      put_Focus_Save_Scale('focus', v).catch((e) => displayError(e?.message ?? e));
    }, 200);
  };

  const onEditClick = useCallback(() => {
    openModal(FocusCommonScaleEditModal, {
      data,
      titles: graphScaleKeyTitleInfo,
      saveCallback: onSave,
    });
  }, [data]);

  return (
    <FocusCommonGraphScaleView
      onEditClick={onEditClick}
      data={data}
      titles={graphScaleKeyTitleInfo}
    />
  );
};
FocusAnalysisGraphScale.propTypes = {
  data: PropTypes.object,
};
FocusAnalysisGraphScale.displayName = 'GraphScale';

const FocusAnalysisGraphTolerance = React.memo(
  ({ type, data }) => {
    const currentFab = useSelector(targetInfoFabSelector);
    const dispatch = useDispatch();
    const { openModal } = useModal();

    const onModalApply = (v) => {
      setTimeout(() => {
        dispatch(
          focusSavedGraphInfoActions.UpdateSavedGraphInfoTolerance({
            type,
            list: v,
          }),
        );
        put_Focus_Save_Tolerance(currentFab, type, v).catch((e) =>
          displayError(e?.message ?? e),
        );
      }, 200);
    };

    const onEdit = () => {
      openModal(FocusToleranceModal, {
        data: Object.entries(data[type]).reduce((acc, [key, value]) => {
          if (!Object.hasOwn(value, 'upper_limit')) return acc;
          const { lower_limit, upper_limit } = value;
          acc[key] = {
            lower_limit,
            upper_limit,
          };
          return acc;
        }, {}),
        saveCallback: onModalApply,
      });
    };

    return (
      <FocusGraphSettingToleranceWrapper>
        <FocusCommonMiddleLineForm title="Tolerance">
          <button onClick={onEdit}>
            <EditOutlined />
            Edit
          </button>
        </FocusCommonMiddleLineForm>
        <div>
          <ToleranceTable>
            <thead>
              <tr>
                <th>Name</th>
                <th>Y: lower limit</th>
                <th>Y: upper limit</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(data[type])
                .filter((v) => Object.hasOwn(v[1], 'lower_limit'))
                .map(([key, value]) => (
                  <GraphToleranceRow key={key} title={key} value={value} />
                ))}
            </tbody>
          </ToleranceTable>
        </div>
      </FocusGraphSettingToleranceWrapper>
    );
  },
  (prev, next) => {
    return JSON.stringify(prev.data) === JSON.stringify(next.data);
  },
);
FocusAnalysisGraphTolerance.propTypes = {
  type: PropTypes.string,
  data: PropTypes.object,
};
FocusAnalysisGraphTolerance.displayName = 'GraphTolerance';

const GraphToleranceRow = React.memo(
  ({ title, value }) => {
    return (
      <tr>
        <td>{title}</td>
        <td>{value.lower_limit}</td>
        <td>{value.upper_limit}</td>
      </tr>
    );
  },
  (prev, next) => {
    return JSON.stringify(prev) === JSON.stringify(next);
  },
);
GraphToleranceRow.propTypes = {
  title: PropTypes.string,
  value: PropTypes.object,
};
GraphToleranceRow.displayName = 'GraphToleranceRow';

export default FocusAnalysisGraphSetting;
