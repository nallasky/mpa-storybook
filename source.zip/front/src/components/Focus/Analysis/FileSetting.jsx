import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { FolderOutlined, FileOutlined } from '@ant-design/icons';
import FocusCommonCustomSegmented from '@components/Focus/Common/CustomSegmented';
import FocusAnalysisImportFile from '@components/Focus/Analysis/ImportFile';
import { LabelComponent } from '@components/Focus/Common/styles/CommonStyles';
import { get_Focus_Analysis_Saved_Info } from '@libs/axios/focusRequest';
import {
  fileInfoSelector,
  targetInfoCurrentTabSelector,
  focusFileInfoActions,
  focusSavedGraphInfoActions,
  focusTargetInfoActions,
  initialGraphScale,
  initialGraphSetting,
} from '@reducers/slices/FocusInfo';
import {
  displayError,
  readFirstLineFromFile,
} from '@libs/util/common/functionGroup';
import { FocusFileGridWrapper } from '@components/Focus/Analysis/styles/FileSettingStyles';
import { FocusCommonMainComponent } from '@components/Focus/Common/CommonElements';

const segmentArr = [
  {
    icon: <FolderOutlined />,
    title: 'Directory',
    value: 'directory',
  },
  {
    icon: <FileOutlined />,
    title: 'File',
    value: 'file',
  },
];

const machineNameList = ['cons.data', 'main.data'];
const passLogName = [
  'StatusMonitor',
  'ILLUMINANCEMULTITABLE',
  'machine',
  'process',
  'unknown',
];

const findDevice = async (file) => {
  const firstLine = await readFirstLineFromFile(file);
  return firstLine.split(',');
};

const deleteDeviceProList = (list, originKey) =>
  Object.entries(list).reduce((acc, [key, value]) => {
    if (key !== originKey) return { ...acc, [key]: value };
    if (value === 1) return acc;
    return {
      ...acc,
      [key]: value - 1,
    };
  }, {});

const FocusAnalysisFileSetting = () => {
  const fileInfo = useSelector(fileInfoSelector);
  const currentTab = useSelector(targetInfoCurrentTabSelector);
  const dispatch = useDispatch();

  const [currentType, setCurrentType] = useState('directory');

  const fileListRef = useRef([]);
  const patternRef = useRef({});

  const changeFileList = async (v) => {
    if (!v.length) {
      dispatch(focusFileInfoActions.resetFileInfo());
      fileListRef.current = [];
      return;
    }

    const newFileList = { ...fileInfo.fileList };
    const newDeviceList = { ...fileInfo.deviceList };

    if (v.length > fileListRef.current.length) {
      let needUpdate = false;
      let needDevUpdate = false;
      const currentLength = fileListRef.current.length;
      fileListRef.current = v;
      for (const { name, originFileObj } of v.slice(currentLength)) {
        let logName = undefined;
        for (const [key, value] of Object.entries(patternRef.current)) {
          const { pattern, ignore_pattern } = value;
          if (
            ignore_pattern.find((p) =>
              key !== 'machine' ? name.indexOf(p) !== -1 : name === p,
            )
          ) {
            logName = 'trash';
            break;
          }
          if (
            pattern.find((p) =>
              key !== 'machine' ? name.indexOf(p) !== -1 : name === p,
            )
          ) {
            logName = key;
            break;
          }
        }
        if (!logName) {
          logName = 'unknown';
        }
        if (logName !== 'trash') {
          needUpdate = true;
          const currentDevProInfo = !passLogName.includes(logName)
            ? await findDevice(originFileObj)
            : [];
          const [device] = currentDevProInfo;
          const listKey = logName === 'process' ? 'unknown' : logName;
          if (logName === 'machine' && machineNameList.includes(name)) {
            const filteredMachineFileList = newFileList.machine.filter(
              ({ name: mName }) => mName !== name,
            );
            newFileList.machine = [
              ...filteredMachineFileList,
              {
                uid: originFileObj.uid,
                name,
                fileObj: originFileObj,
                logName,
                changedLogName: undefined,
                device,
                isProcess: false,
              },
            ];
          } else {
            newFileList[listKey] = [
              ...newFileList[listKey],
              {
                uid: originFileObj.uid,
                name,
                fileObj: originFileObj,
                logName,
                changedLogName:
                  logName === 'unknown' || logName === 'process'
                    ? 'unknown'
                    : undefined,
                device,
                isProcess: logName === 'process',
              },
            ];
          }
          if (currentDevProInfo.length) {
            needDevUpdate = true;
            newDeviceList[device] = newDeviceList[device]
              ? newDeviceList[device] + 1
              : 1;
          }
        }
      }
      if (needUpdate) {
        if (currentTab !== 'status') {
          dispatch(
            focusTargetInfoActions.UpdateTargetInfoSingle({
              key: 'currentTab',
              value: 'status',
            }),
          );
        }
        if (needDevUpdate) {
          dispatch(
            focusFileInfoActions.UpdateFileInfoAll({
              fileList: { ...newFileList },
              deviceList: { ...newDeviceList },
              deleteList: [],
            }),
          );
        } else {
          dispatch(
            focusFileInfoActions.UpdateFileInfoSingle({
              key: 'fileList',
              value: newFileList,
            }),
          );
        }
      }
    } else {
      const deleteFile = fileListRef.current.find(
        ({ uid }) => !v.find((x) => uid === x.uid),
      );
      const findFileFromRedux = Object.values(newFileList)
        .flat()
        .find(({ uid }) => uid === deleteFile.uid);
      if (findFileFromRedux) {
        const { logName, device, uid, isProcess } = findFileFromRedux;
        const defineKey = isProcess ? 'unknown' : logName;
        newFileList[defineKey] = newFileList[defineKey].filter(
          ({ uid: cUid }) => cUid !== uid,
        );
        if (currentTab !== 'status') {
          dispatch(
            focusTargetInfoActions.UpdateTargetInfoSingle({
              key: 'currentTab',
              value: 'status',
            }),
          );
        }
        if (device) {
          const deleteDeviceList = deleteDeviceProList(newDeviceList, device);
          dispatch(
            focusFileInfoActions.UpdateFileInfoAll({
              fileList: {
                ...newFileList,
                unknown: [
                  ...newFileList.unknown.map((file) => {
                    if (
                      file.isProcess &&
                      !Object.keys(deleteDeviceList).includes(
                        file.changedLogName,
                      )
                    )
                      return { ...file, changedLogName: 'unknown' };
                    return file;
                  }),
                ],
              },
              deviceList: { ...deleteDeviceList },
              deleteList: [],
            }),
          );
        } else {
          dispatch(
            focusFileInfoActions.UpdateFileInfoSingle({
              key: 'fileList',
              value: newFileList,
            }),
          );
        }
      }
      fileListRef.current = v;
    }
  };

  useEffect(() => {
    const fetch = async () => {
      try {
        const { info: { log_pattern, settings } } = await get_Focus_Analysis_Saved_Info();
        const { graph_setting, ...scales } = settings;
        patternRef.current = log_pattern;
        dispatch(
          focusSavedGraphInfoActions.UpdateSavedGraphInfoSingle([
            {
              key: 'graph_setting',
              value: {
                ...initialGraphSetting,
                ...graph_setting,
              },
            },
            {
              key: 'graph_scale',
              value: {
                ...initialGraphScale,
                ...scales,
              },
            },
          ]),
        );
      } catch (e) {
        displayError(e?.message ?? e);
      }
    };
    fetch();
  }, []);

  return (
    <FocusCommonMainComponent title="Select Source" width="70%" isInner>
      <FocusFileGridWrapper>
        <div className="label-wrapper">
          <LabelComponent useRequire useFullColon>
            Log files
          </LabelComponent>
        </div>
        <div className="segment-wrapper">
          <FocusCommonCustomSegmented
            items={segmentArr}
            callbackFunc={setCurrentType}
          />
        </div>
        <FocusAnalysisImportFile
          type={currentType}
          callbackFunc={changeFileList}
        />
      </FocusFileGridWrapper>
    </FocusCommonMainComponent>
  );
};

export default FocusAnalysisFileSetting;
