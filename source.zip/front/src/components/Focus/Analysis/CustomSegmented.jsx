import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { CommonInputForm } from '@components/Focus/Analysis/styles/CommonElements';

const SegmentedWrapper = styled.div`
  display: inline-block;
  padding: 2px;
  color: rgb(0 0 0 / 65%);
  background-color: rgb(0 0 0 / 4%);
  border-radius: 2px;
  & > .segmented-group {
    position: relative;
    display: flex;
    width: 100%;
    & > .selected,
    & > .thumb {
      background-color: #fff;
      border-radius: 2px;
      box-shadow: 0 2px 8px -2px rgb(0 0 0 / 5%), 0 1px 4px -1px rgb(0 0 0 / 7%),
        0 0 1px rgb(0 0 0 / 8%);
      color: #262626;
    }
    & > .thumb {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 1;
      &.motion {
        transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
      }
    }
    & > label {
      position: relative;
      text-align: center;
      cursor: pointer;
      transition: color 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
      z-index: 2;
      & > input {
        display: none;
      }
      & > .label-wrapper {
        min-height: 28px;
        padding: 0 11px;
        line-height: 28px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        word-break: keep-all;
        & > span + span {
          margin-left: 6px;
        }
      }
    }
  }
`;

const SegmentThumb = styled.div`
  height: ${(props) => props.thumbHeight}px;
  width: ${(props) => props.thumbWidth}px;
  transform: translateX(${(props) => props.left}px);
`;

const getTotalLeftDistance = (elements, limit) => {
  let result = 0;
  let i = 0;

  while (i < limit) {
    result += elements[i].getBoundingClientRect().width;
    i++;
  }

  return result;
};

const CustomSegmented = ({
  items,
  initialSelected,
  title,
  labelWidth,
  useRequire,
  justify,
  callbackFunc,
}) => {
  const [segmentChecked, setSegmentChecked] = useState(initialSelected ?? 0);
  const [thumbProps, setThumbProps] = useState({
    width: 0,
    left: 0,
    height: 0,
    motion: false,
  });
  const segmentRef = useRef();

  const onSegmentChange = (idx) => {
    setThumbProps((prev) => ({
      ...prev,
      width:
        segmentRef.current.children[segmentChecked].getBoundingClientRect()
          .width,
      left: getTotalLeftDistance(segmentRef.current.children, segmentChecked),
    }));

    setTimeout(() => {
      segmentRef.current.children[segmentChecked].classList.remove('selected');
      setThumbProps((prev) => ({
        ...prev,
        width: segmentRef.current.children[idx].getBoundingClientRect().width,
        left: getTotalLeftDistance(segmentRef.current.children, idx),
        motion: true,
      }));
    }, 5);
    setTimeout(() => {
      setSegmentChecked(idx);
      if (callbackFunc) {
        callbackFunc(items[idx].value);
      }
    }, 305);
  };

  useEffect(() => {
    setThumbProps((prev) => ({
      ...prev,
      height: segmentRef.current.children[0].offsetHeight,
    }));
  }, []);

  return (
    <CommonInputForm
      title={title}
      labelWidth={labelWidth}
      useRequire={useRequire}
      justify={justify}
    >
      <SegmentedWrapper>
        <div className="segmented-group" ref={segmentRef}>
          {items.map((v, i) => (
            <label key={i} className={segmentChecked === i ? 'selected' : ''}>
              <input
                type="radio"
                checked={segmentChecked === i}
                onChange={() => onSegmentChange(i)}
              />
              <div className="label-wrapper">
                {v.icon && <span>{v.icon}</span>}
                <span>{v.title}</span>
              </div>
            </label>
          ))}
          <SegmentThumb
            thumbHeight={thumbProps.height}
            thumbWidth={thumbProps.width}
            left={thumbProps.left}
            className={'thumb' + (thumbProps.motion ? ' motion' : '')}
          />
        </div>
      </SegmentedWrapper>
    </CommonInputForm>
  );
};
CustomSegmented.propTypes = {
  items: PropTypes.array,
  initialSelected: PropTypes.number,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  labelWidth: PropTypes.number,
  useRequire: PropTypes.bool,
  justify: PropTypes.string,
  callbackFunc: PropTypes.func,
};

export default CustomSegmented;
