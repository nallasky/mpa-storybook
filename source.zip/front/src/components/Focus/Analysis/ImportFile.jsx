import React, { useRef, useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { Upload } from 'antd';
import { InboxOutlined } from '@ant-design/icons';
import {
  fileDeleteListSelector,
  focusFileInfoActions,
} from '@reducers/slices/FocusInfo';
import { FocusImportFileWrapper } from '@components/Focus/Analysis/styles/ImportFileStyles';

const FocusAnalysisImportFile = ({ type, callbackFunc }) => {
  const deleteList = useSelector(fileDeleteListSelector);
  const dispatch = useDispatch();

  const [innerFileList, setInnerFileList] = useState([]);
  const beforeFileList = useRef([]);
  const timeout = useRef(null);

  const onChangeFile = (v) => {
    const { file, fileList } = v;
    if (!fileList.length) {
      setInnerFileList([]);
      return;
    }
    if (file.status) {
      setInnerFileList((prev) => prev.filter(({ uid }) => file.uid !== uid));
    } else {
      const findFile = fileList.find(({ uid }) => uid === file.uid);
      setInnerFileList((prev) => [...prev, findFile]);
    }
    clearTimeout(timeout.current);
  };

  useEffect(() => {
    if (deleteList.length) {
      const newInnerFileList = innerFileList.filter(
        ({ uid }) => !deleteList.includes(uid),
      );
      setInnerFileList(newInnerFileList);
      dispatch(
        focusFileInfoActions.UpdateFileInfoSingle({
          key: 'deleteList',
          value: [],
        }),
      );
    }
  }, [deleteList]);

  useEffect(() => {
    if (
      JSON.stringify(innerFileList) !== JSON.stringify(beforeFileList.current)
    ) {
      timeout.current = setTimeout(() => {
        beforeFileList.current = innerFileList;
        callbackFunc(innerFileList);
      }, 200);
    }
    return () => clearTimeout(timeout.current);
  }, [innerFileList]);

  return (
    <FocusImportFileWrapper mw="400" mh="470">
      <Upload.Dragger
        beforeUpload={() => false}
        multiple={type === 'file'}
        directory={type === 'directory'}
        fileList={innerFileList}
        onChange={(v) => onChangeFile(v)}
      >
        <p className="ant-upload-drag-icon">
          <InboxOutlined />
        </p>
        <p className="ant-upload-text">
          Click or drag file to this area to upload.
        </p>
      </Upload.Dragger>
    </FocusImportFileWrapper>
  );
};
FocusAnalysisImportFile.propTypes = {
  type: PropTypes.string,
  callbackFunc: PropTypes.func,
};

export default FocusAnalysisImportFile;
