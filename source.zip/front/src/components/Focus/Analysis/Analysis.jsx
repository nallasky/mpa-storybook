import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
  focusFileInfoActions,
  focusTargetInfoActions,
  focusSavedGraphInfoActions,
} from '@reducers/slices/FocusInfo';
import FocusAnalysisFileSetting from '@components/Focus/Analysis/FileSetting';
import FocusAnalysisOptionSetting from '@components/Focus/Analysis/OptionSetting';
import FocusAnalysisResult from '@components/Focus/Analysis/AnalysisResult';
import {
  FocusMainWrapper,
  FocusMainSettingWrapper,
} from '@components/Focus/Common/styles/CommonStyles';

const FocusAnalysisComponent = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    return () => {
      dispatch(focusFileInfoActions.resetFileInfo());
      dispatch(focusTargetInfoActions.resetTargetInfo());
      dispatch(focusSavedGraphInfoActions.resetSavedGraphInfo());
    };
  }, []);

  return (
    <FocusMainWrapper>
      <FocusMainSettingWrapper isBasicAnalysis isSelect>
        <FocusAnalysisFileSetting />
        <FocusAnalysisOptionSetting />
      </FocusMainSettingWrapper>
      <FocusAnalysisResult />
    </FocusMainWrapper>
  );
};

export default FocusAnalysisComponent;
