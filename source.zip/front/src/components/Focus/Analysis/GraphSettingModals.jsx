import React, { useState } from 'react';
import styled from '@emotion/styled';
import PropTypes from 'prop-types';
import { Input } from 'antd';
import { BulbOutlined } from '@ant-design/icons';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import {
  ToleranceTable,
  mixinList,
} from '@components/Focus/Analysis/styles/CommonStyles';

const AlertWrapper = styled.div`
  padding: 0.5rem 1.5rem;
  background-color: #e6f7ff;
  display: flex;
  align-items: center;
  column-gap: 0.5rem;
  margin-bottom: 0.5rem;
  & > span {
    &:first-of-type {
      font-size: 18px;
      color: #1890ff;
    }
    &:last-of-type {
      color: #0050b3;
    }
  }
`;

const ToleranceTableWrapper = styled.div`
  margin: 0 1.5rem;
  overflow: auto;
  max-height: calc((57px * 6) + 48px);
  ${mixinList.customScroll({ bgColor: 'var(--ckr-blue-3)' })}
`;

export const FocusToleranceModal = ({ data, saveCallback, onClose }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [inputValues, setInputValues] = useState(data);

  const onInputChange = (pKey, sKey, v) => {
    setInputValues((prev) => ({
      ...prev,
      [pKey]: {
        ...prev[pKey],
        [sKey]: v,
      },
    }));
  };

  const onApply = () => {
    const setLimitValue = (currentValue, compareValue, initValue, type) => {
      if (isNaN(Number(currentValue)) || isNaN(Number(compareValue)))
        return Number(initValue);
      if (type === 'upper' && Number(currentValue) < Number(compareValue))
        return Number(initValue);
      if (type === 'lower' && Number(currentValue) > Number(compareValue))
        return Number(initValue);
      return Number(currentValue);
    };

    const currentInputValues = Object.entries(inputValues).reduce(
      (acc, [key, value]) => {
        const { lower_limit, upper_limit } = value;
        acc[key] = {
          lower_limit: setLimitValue(
            lower_limit,
            upper_limit,
            data[key].lower_limit,
            'lower',
          ),
          upper_limit: setLimitValue(
            upper_limit,
            lower_limit,
            data[key].upper_limit,
            'upper',
          ),
        };
        return acc;
      },
      {},
    );
    closeModal();
    if (JSON.stringify(data) !== JSON.stringify(currentInputValues)) {
      setTimeout(() => {
        saveCallback(currentInputValues);
      }, 250);
    }
  };

  const closeModal = () => {
    setIsVisible(false);
    onClose();
  };

  return (
    <DraggableModal
      visible={isVisible}
      title="Tolerance"
      bodyStyle={{ padding: '0 0 0.5rem 0' }}
      cancelHandler={closeModal}
      okHandler={onApply}
      okText="Apply"
      width={960}
    >
      <AlertWrapper>
        <BulbOutlined />
        <span>Message</span>
      </AlertWrapper>
      <ToleranceTableWrapper>
        <ToleranceTable>
          <thead>
            <tr>
              <th>Name</th>
              <th>Y: lower limit</th>
              <th>Y: upper limit</th>
            </tr>
          </thead>
          <tbody>
            {Object.keys(data).map((key) => (
              <tr key={key}>
                <td>{key}</td>
                <td>
                  <Input
                    value={inputValues[key].lower_limit}
                    onChange={(e) =>
                      onInputChange(key, 'lower_limit', e.target.value)
                    }
                  />
                </td>
                <td>
                  <Input
                    value={inputValues[key].upper_limit}
                    onChange={(e) =>
                      onInputChange(key, 'upper_limit', e.target.value)
                    }
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </ToleranceTable>
      </ToleranceTableWrapper>
    </DraggableModal>
  );
};
FocusToleranceModal.propTypes = {
  data: PropTypes.object,
  saveCallback: PropTypes.func,
  onClose: PropTypes.func,
};
