import React, { useState, useMemo, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Input, Checkbox, Tree } from 'antd';
import {
  SearchOutlined,
  RightOutlined,
  LeftOutlined,
  DeleteOutlined,
} from '@ant-design/icons';
import {
  FileTransferButtonWrapper,
  FileTransferLabelWrapper,
  FileTransferLeftTitleButton,
  FileTransferListWrapper,
  FileTransferRightTitleButton,
  FileTransferWrapper,
} from '@components/Focus/Analysis/styles/FileTransferStyle';

const treeData = [
  {
    title: 'Log name',
    name: 'Log name',
    key: 'logName',
    checkable: false,
    selectable: false,
    children: [
      {
        key: 'machine',
        title: 'Machine',
        name: 'Machine',
        type: 'logName',
        checkable: false,
        selectable: true,
        disabled: false,
        children: [],
      },
      {
        key: 'FOCUSLOGDETAIL',
        title: 'Focus log detail',
        name: 'Focus log detail',
        type: 'logName',
        checkable: false,
        selectable: true,
        disabled: false,
        children: [],
      },
      {
        key: 'STAGEPOSITIONMONITOR',
        title: 'Stage position monitor',
        name: 'Stage position monitor',
        type: 'logName',
        checkable: false,
        selectable: true,
        disabled: false,
        children: [],
      },
      {
        key: 'StatusMonitor',
        title: 'Status monitor',
        name: 'Status monitor',
        type: 'logName',
        checkable: false,
        selectable: true,
        disabled: false,
        children: [],
      },
      {
        key: 'ILLUMINANCEMULTITABLE',
        title: 'IlluminanceMultiTable',
        name: 'IlluminanceMultiTable',
        type: 'logName',
        checkable: false,
        selectable: true,
        disabled: false,
        children: [],
      },
      {
        key: 'PLATEAUTOFOCUSCOMPENSATION',
        title: 'PlateAutoFocusCompensation',
        name: 'PlateAutoFocusCompensation',
        type: 'logName',
        checkable: false,
        selectable: true,
        disabled: false,
        children: [],
      },
      {
        key: 'PRESCANCOMPENSATIONMONITOR',
        title: 'PrescenCompensationMonitor',
        name: 'PrescenCompensationMonitor',
        type: 'logName',
        checkable: false,
        selectable: true,
        disabled: false,
        children: [],
      },
      {
        key: 'PLATEFOCUSINTERLOCKMONITOR',
        title: 'PlateFocusInterlockMonitor',
        name: 'PlateFocusInterlockMonitor',
        type: 'logName',
        checkable: false,
        selectable: true,
        disabled: false,
        children: [],
      },
    ],
  },
  {
    key: 'device',
    title: 'Device',
    name: 'Device',
    checkable: false,
    selectable: false,
    children: [],
  },
];

const logNameKeyList = [
  'machine',
  'FOCUSLOGDETAIL',
  'STAGEPOSITIONMONITOR',
  'StatusMonitor',
  'ILLUMINANCEMULTITABLE',
  'PLATEAUTOFOCUSCOMPENSATION',
  'PRESCANCOMPENSATIONMONITOR',
  'PLATEFOCUSINTERLOCKMONITOR',
];

const createOriginFileList = (originFileList, currentFileList, deviceList) => {
  const result = [];
  originFileList.forEach(({ uid, name, changedLogName, type }) => {
    const findFileInfo = currentFileList.find(({ uid: cUid }) => cUid === uid);
    if (findFileInfo) {
      const needChangeUnknown =
        type === 'process' && !deviceList.includes(findFileInfo.changedLogName);
      result.push({
        key: findFileInfo.uid,
        title: findFileInfo.name,
        name: findFileInfo.name,
        changedLogName: needChangeUnknown
          ? 'unknown'
          : findFileInfo.changedLogName,
        type: findFileInfo.type,
      });
    } else {
      result.push({
        key: uid,
        title: name,
        name,
        changedLogName:
          type === 'process' && !deviceList.includes(changedLogName)
            ? 'unknown'
            : changedLogName,
        type,
      });
    }
  });
  return result;
};

const createLeftFileList = (fileList) => {
  return fileList.map(({ uid, name, changedLogName, type }) => ({
    key: uid,
    title: name,
    name,
    changedLogName,
    type,
  }));
};

const createRightFileItemTitle = (title, searchText = '') => {
  const index = title.indexOf(searchText);
  const beforeStr = title.substring(0, index);
  const afterStr = title.slice(index + searchText.length);
  return index > -1 ? (
    <FileTransferLabelWrapper title={title}>
      {beforeStr}
      <span className="site-tree-search-value">{searchText}</span>
      {afterStr}
    </FileTransferLabelWrapper>
  ) : (
    <FileTransferLabelWrapper title={title}>{title}</FileTransferLabelWrapper>
  );
};

const createRightDetailFileList = (
  children,
  originFileList,
  deviceList,
  searchText,
  type,
) => {
  if (type === 'logName') {
    return children.map((v) => {
      const tmpArr = [];
      originFileList
        .filter(({ changedLogName }) => changedLogName === v.key)
        .forEach((x) => {
          const findFile = v.children.find(({ key }) => key === x.uid);
          if (findFile) {
            tmpArr.push({
              ...findFile,
              title: createRightFileItemTitle(findFile.name, searchText),
            });
          } else {
            tmpArr.push({
              title: createRightFileItemTitle(x.name, searchText),
              key: x.uid,
              name: x.name,
              type,
              checkable: true,
              selectable: false,
            });
          }
        });
      return {
        ...v,
        title: createRightFileItemTitle(v.name, searchText),
        checkable: !!tmpArr.length,
        children: tmpArr,
      };
    });
  } else {
    return deviceList.map((v) => {
      const findDevice = children.includes(v);
      if (findDevice) {
        const tmpArr = [];
        originFileList
          .filter(({ changedLogName }) => changedLogName === v)
          .forEach((a) => {
            const findFile = findDevice.children.find(
              ({ key }) => key === a.uid,
            );
            if (findFile) {
              tmpArr.push({
                ...findFile,
                title: createRightFileItemTitle(findFile.name, searchText),
              });
            } else {
              tmpArr.push({
                key: a.uid,
                title: createRightFileItemTitle(a.name, searchText),
                name: a.name,
                type,
                checkable: true,
                selectable: false,
              });
            }
          });
        return {
          ...findDevice,
          checkable: !!tmpArr.length,
          children: tmpArr,
        };
      }
      return {
        title: createRightFileItemTitle(v, searchText),
        key: v,
        name: v,
        type,
        checkable: false,
        selectable: false,
        children: originFileList
          .filter(({ changedLogName }) => changedLogName === v)
          .map((b) => ({
            key: b.uid,
            title: createRightFileItemTitle(b.name, searchText),
            name: b.name,
            type,
            checkable: true,
            selectable: false,
          })),
      };
    });
  }
};

const createRightFileList = (originFileList, deviceList, searchText) => {
  return treeData.map((item, i) => {
    return {
      ...item,
      title: createRightFileItemTitle(item.name, searchText),
      children: createRightDetailFileList(
        item.children,
        originFileList,
        deviceList,
        searchText,
        !i ? 'logName' : 'process',
      ),
    };
  });
};

const generateList = (data, buffer) => {
  for (const element of data) {
    const node = element;
    buffer.push(node);
    if (node.children) {
      generateList(node.children, buffer);
    }
  }
};

const getParentKey = (key, tree) => {
  let parentKey;
  for (const element of tree) {
    const node = element;
    if (node.children) {
      if (node.children.some((item) => item.key === key)) {
        parentKey = node.key;
      } else if (getParentKey(key, node.children)) {
        parentKey = getParentKey(key, node.children);
      }
    }
  }
  return parentKey;
};

const FocusAnalysisFileTransfer = ({ fileList, deviceList, saveCallback }) => {
  const [leftFileList, setLeftFileList] = useState([]);
  const [leftCheckedList, setLeftCheckedList] = useState({
    type: 'all',
    list: [],
  });
  const [leftSearchText, setLeftSearchText] = useState('');
  const [rightFileList, setRightFileList] = useState([]);
  const [rightSearchText, setRightSearchText] = useState('');
  const [rightSelectedKeys, setRightSelectedKeys] = useState([]);
  const [rightCheckedKeys, setRightCheckedKeys] = useState([]);
  const [expandedKeys, setExpandedKeys] = useState([]);
  const [autoExpandParent, setAutoExpandParent] = useState(true);

  const fileListRef = useRef([]);

  const leftSelectedCount = useMemo(() => {
    return leftFileList.filter(({ key, name }) => {
      const { list } = leftCheckedList;
      const isChecked = list.includes(key);
      if (!isChecked) return false;
      if (leftSearchText === '') return true;
      return name.indexOf(leftSearchText) !== -1 && isChecked;
    }).length;
  }, [leftCheckedList, leftSearchText]);

  const filteringRightFileList = (list, searchText) => {
    const dataList = [];
    generateList(list, dataList);
    const newExpandedKeys = dataList
      .map((item) => {
        if (item.name.indexOf(searchText) > -1) {
          return getParentKey(item.key, list);
        }
        return null;
      })
      .filter((item, i, self) => item && self.indexOf(item) === i);
    setExpandedKeys(newExpandedKeys);
    setAutoExpandParent(true);
    setRightFileList(list);
  };

  const onExpand = (newExpandedKeys) => {
    setExpandedKeys(newExpandedKeys);
    setAutoExpandParent(false);
  };

  const onRightSearchTextChange = (v) => {
    const newRightFileList = createRightFileList(
      fileListRef.current.filter(
        ({ changedLogName }) => changedLogName !== 'unknown',
      ),
      deviceList,
      v,
    );
    filteringRightFileList(newRightFileList, v);
    setRightSearchText(v);
  };

  const onChangeLeftFileCheck = (type, key, checked) => {
    if (checked) {
      setLeftCheckedList((prev) => ({
        type,
        list: [...prev.list, key],
      }));
      setRightFileList((prev) => {
        return prev.map((v) => ({
          ...v,
          children: v.children.map((x) => ({
            ...x,
            selectable: type === x.type,
          })),
        }));
      });
      if (rightSelectedKeys.length) {
        if (type === 'process') {
          if (logNameKeyList.includes(rightSelectedKeys[0])) {
            setRightSelectedKeys([]);
          }
        } else {
          if (deviceList.includes(rightSelectedKeys[0])) {
            setRightSelectedKeys([]);
          }
        }
      }
    } else {
      const newList = leftCheckedList.list.filter((v) => v !== key);
      const newType = !newList.length ? 'all' : leftCheckedList.type;
      setLeftCheckedList({
        type: newType,
        list: newList,
      });
      setRightFileList((prev) => {
        return prev.map((v) => ({
          ...v,
          children: v.children.map((x) => ({
            ...x,
            selectable: newType === 'all' ? true : newType === x.type,
          })),
        }));
      });
    }
  };

  const moveRight = () => {
    const { list } = leftCheckedList;
    const newFileRef = fileListRef.current.map((v) => {
      if (list.includes(v.uid)) {
        return { ...v, changedLogName: rightSelectedKeys[0] };
      }
      return v;
    });
    setLeftFileList(
      createLeftFileList(
        newFileRef.filter(({ changedLogName }) => changedLogName === 'unknown'),
      ),
    );
    setLeftCheckedList({
      type: 'all',
      list: [],
    });
    const newRightFileList = createRightFileList(
      newFileRef,
      deviceList,
      rightSearchText,
    );
    filteringRightFileList(newRightFileList, rightSearchText);
    fileListRef.current = newFileRef;
  };

  const moveLeft = () => {
    const filterCheckedKeys = rightCheckedKeys.filter(
      (v) => !logNameKeyList.includes(v) && !deviceList.includes(v),
    );
    const newFileRef = fileListRef.current.map((v) => {
      if (filterCheckedKeys.includes(v.uid)) {
        return { ...v, changedLogName: 'unknown' };
      }
      return v;
    });
    setLeftFileList(
      createLeftFileList(
        newFileRef.filter(({ changedLogName }) => changedLogName === 'unknown'),
      ),
    );
    const newRightFileList = createRightFileList(
      newFileRef,
      deviceList,
      rightSearchText,
    );
    filteringRightFileList(newRightFileList, rightSearchText);
    setRightCheckedKeys([]);
    fileListRef.current = newFileRef;
  };

  const onDelete = () => {
    saveCallback(leftCheckedList.list, 'delete');
  };

  const onSave = () => {
    saveCallback(fileListRef.current, 'save');
  };

  useEffect(() => {
    const newOriginFileList = createOriginFileList(
      fileList,
      fileListRef.current,
      deviceList,
    );
    const newLeftCheckedList = leftCheckedList.list.filter((v) =>
      newOriginFileList.find(({ key }) => key === v),
    );
    setLeftFileList(
      newOriginFileList.filter(
        ({ changedLogName }) => changedLogName === 'unknown',
      ),
    );
    setLeftCheckedList((prev) => ({
      type: !newLeftCheckedList.length ? 'all' : prev.type,
      list: newLeftCheckedList,
    }));

    const newRightFileList = createRightFileList(
      newOriginFileList
        .filter(({ changedLogName }) => changedLogName !== 'unknown')
        .map(({ key, title, changedLogName, type }) => {
          return {
            uid: key,
            name: title,
            changedLogName,
            type,
          };
        }),
      deviceList,
      rightSearchText,
    );
    filteringRightFileList(newRightFileList, rightSearchText);
    fileListRef.current = newOriginFileList.map(
      ({ key, name, type, changedLogName }) => ({
        name,
        uid: key,
        changedLogName,
        type,
      }),
    );
  }, [fileList, deviceList]);

  return (
    <FileTransferWrapper>
      <FileTransferListWrapper>
        <div className="list-header">
          <div>{`${leftSelectedCount} Items`}</div>
          <div>
            <FileTransferLeftTitleButton
              onClick={onDelete}
              disabled={!leftCheckedList.list.length}
            >
              <DeleteOutlined />
            </FileTransferLeftTitleButton>
          </div>
        </div>
        <div className="list-content">
          <div className="search-wrapper">
            <Input
              prefix={<SearchOutlined />}
              placeholder="Search here"
              style={{ fontSize: '12px' }}
              value={leftSearchText}
              onChange={(e) => setLeftSearchText(e.target.value)}
            />
          </div>
          <div className="list-wrapper">
            <ul>
              {leftFileList
                .filter(({ title }) =>
                  !leftSearchText ? true : title.indexOf(leftSearchText) !== -1,
                )
                .map(({ title, type, key }, i) => {
                  const disabled =
                    leftCheckedList.type === 'all'
                      ? type === 'process' && !deviceList.length
                      : type !== leftCheckedList.type;
                  return (
                    <li key={i}>
                      <Checkbox
                        disabled={disabled}
                        checked={leftCheckedList.list.includes(key)}
                        onChange={({ target: { checked } }) =>
                          onChangeLeftFileCheck(type, key, checked)
                        }
                      >
                        <FileTransferLabelWrapper title={title}>
                          {title}
                        </FileTransferLabelWrapper>
                      </Checkbox>
                    </li>
                  );
                })}
            </ul>
          </div>
        </div>
      </FileTransferListWrapper>
      <FileTransferButtonWrapper>
        <button
          disabled={!leftCheckedList.list.length || !rightSelectedKeys.length}
          onClick={moveRight}
        >
          <RightOutlined />
        </button>
        <button disabled={!rightCheckedKeys.length} onClick={moveLeft}>
          <LeftOutlined />
        </button>
      </FileTransferButtonWrapper>
      <FileTransferListWrapper>
        <div className="list-header">
          <div>{`${
            rightCheckedKeys.filter(
              (v) => !logNameKeyList.includes(v) && !deviceList.includes(v),
            ).length
          } Items`}</div>
          <div>
            <FileTransferRightTitleButton
              onClick={onSave}
              disabled={
                JSON.stringify(fileList) === JSON.stringify(fileListRef.current)
              }
            >
              Save
            </FileTransferRightTitleButton>
          </div>
        </div>
        <div className="list-content">
          <div className="search-wrapper">
            <Input
              prefix={<SearchOutlined />}
              placeholder="Search here"
              value={rightSearchText}
              onChange={(e) => onRightSearchTextChange(e.target.value)}
            />
          </div>
          <div className="list-wrapper">
            <Tree
              checkable
              treeData={rightFileList}
              onExpand={onExpand}
              expandedKeys={expandedKeys}
              autoExpandParent={autoExpandParent}
              selectedKeys={rightSelectedKeys}
              onSelect={(selectedKeys) => setRightSelectedKeys(selectedKeys)}
              checkedKeys={rightCheckedKeys}
              onCheck={(checkedKeys) => setRightCheckedKeys(checkedKeys)}
            />
          </div>
        </div>
      </FileTransferListWrapper>
    </FileTransferWrapper>
  );
};
FocusAnalysisFileTransfer.propTypes = {
  fileList: PropTypes.array,
  deviceList: PropTypes.array,
  saveCallback: PropTypes.func,
};

export default FocusAnalysisFileTransfer;
