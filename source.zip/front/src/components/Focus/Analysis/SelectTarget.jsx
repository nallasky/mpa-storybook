import React from 'react';
import axios from 'axios';
import dayjs from 'dayjs';
import { useDispatch, useSelector } from 'react-redux';
import { Select } from 'antd';
import {
  FocusCommonSelectTarget,
  FocusCommonInputPeriod,
  FocusCommonInputSelect,
} from '@components/Focus/Common/CommonElements';
import {
  RenderSelectOptions,
  displayError,
  disabledDate,
  displayNotification,
} from '@libs/util/common/functionGroup';
import { CommonRegex } from '@libs/util/regExp';
import CustomOptionListHeader from '@components/common/molecules/CustomOptionListHeader/CustomOptionListHeader';
import {
  get_Focus_Tolerance_Info,
  get_Focus_Lot_Id_Info,
  post_Focus_Analysis_Start,
} from '@libs/axios/focusRequest';
import {
  targetInfoAllSelector,
  focusTargetInfoActions,
  focusSavedGraphInfoActions,
  initialGraphData,
} from '@reducers/slices/FocusInfo';
import ProcessingModal from "@components/common/organisms/ProcessingModal/ProcessingModal";
import useModal from "@libs/util/modalControl/useModal";
import { DATE_FORMAT } from "@constants/etc";

const labelGap = 300;

export const focusAnalysisTargetOnStart = async (dispatch, currentInfo, openModalFunc, closeModalFunc) => {
  try {
    let cancelTokenSource = new AbortController();
    openModalFunc(cancelTokenSource);
    const { rid, fab_name: fab_nm, job, lot_id } = currentInfo;
    const requestInfo = {
      rid,
      fab_nm,
      job,
      lot_id,
    };

    cancelTokenSource = new AbortController();
    const { info } = await post_Focus_Analysis_Start(
      requestInfo,
      cancelTokenSource.signal,
    );
    const shot_list = [
      ...new Set(
        Object.values(info['PS Pitch'])
          .map(({ shot }) => shot)
          .sort(),
      ),
    ];
    const initialShotValue = shot_list.length ? shot_list[0] : '';
    dispatch(
      focusSavedGraphInfoActions.UpdateSavedGraphInfoSingle([
        {
          key: 'shot_setting',
          value: {
            list: shot_list,
            selected: {
              'PS Pitch': initialShotValue,
              'PS Roll': initialShotValue,
              'PS Z': initialShotValue,
            },
            isAll: false,
          },
        },
        {
          key: 'graph_data',
          value: {
            ...initialGraphData,
            ...info,
          },
        },
      ]),
    );
    displayNotification({
      message: 'Analysis completed',
      description: 'Analysis has been successfully completed.',
      duration: 3,
      style: { borderLeft: '8px solid green' },
    });
  } catch (e) {
    if (!axios.isCancel(e))
      displayError(e.response?.data?.msg ?? e?.message);
  } finally {
    closeModalFunc();
  }
};

export const focusAnalysisTargetChangePeriod = async (v, dispatch, prevInfo) => {
  try {
    const convertPeriod = v.map((date) => dayjs(date).format(DATE_FORMAT));
    const { info } = await get_Focus_Lot_Id_Info(prevInfo.rid, 'focus', convertPeriod);
    dispatch(
      focusTargetInfoActions.UpdateTargetInfoAll({
        ...prevInfo,
        selectedPeriod: convertPeriod,
        job: '',
        job_list: info.job,
        lot_id: [],
        lot_id_list: info.lot_id,
      }),
    );
  } catch (e) {
    displayError(e.response?.data?.msg ?? e?.message);
  }
};

export const focusAnalysisTargetChangeFab = async (dispatch, value) => {
  try {
    const { info: { tolerance } } = await get_Focus_Tolerance_Info(value);
    dispatch(
      focusTargetInfoActions.UpdateTargetInfoSingle({
        key: 'fab_name',
        value,
      }),
    );
    dispatch(
      focusSavedGraphInfoActions.UpdateSavedGraphInfoTolerance({
        type: 'all',
        list: tolerance,
      }),
    );
  } catch (e) {
    displayError(e.response?.data?.msg ?? e?.message);
  }
}

export const focusAnalysisTargetCommonChangeSelect = (dispatch, info) => {
  dispatch(focusTargetInfoActions.UpdateTargetInfoSingle(info));
};

export const focusAnalysisTargetCheckFabName = (list, v) =>
  list.includes(v) || !CommonRegex.test(v);

const FocusAnalysisSelectTarget = () => {
  const { openModal, closeModal } = useModal();
  const targetInfo = useSelector(targetInfoAllSelector);
  const dispatch = useDispatch();

  return (
    <FocusCommonSelectTarget
      isInner
      startDisabled={
        !targetInfo.fab_name || !targetInfo.job || !targetInfo.lot_id.length
      }
      onStart={() => focusAnalysisTargetOnStart(
        dispatch,
        targetInfo,
        (token) => {
          openModal(ProcessingModal, {
            title: 'Analyzing',
            message: 'Analyzing files',
            useCancel: true,
            onCancel: () => token.abort(),
          });
        },
        () => closeModal(ProcessingModal)
      )}
    >
      <FocusCommonInputSelect
        title="Fab"
        labelGap={labelGap}
        selectProps={{
          value: targetInfo.fab_name,
          onChange: (v) => focusAnalysisTargetChangeFab(dispatch, v),
          dropdownRender: (menu) => (
            <>
              <CustomOptionListHeader
                saveCallback={(v) => focusAnalysisTargetCommonChangeSelect(dispatch, {
                  key: 'fab_list',
                  value: [...targetInfo.fab_list, v],
                })}
                invalidCheckFunc={(v) => focusAnalysisTargetCheckFabName(targetInfo.fab_list, v)}
              />
              {menu}
            </>
          ),
          "data-testid": 'focus-analysis-target-fab',
        }}
      >
        {targetInfo.fab_list.map(RenderSelectOptions)}
      </FocusCommonInputSelect>
      <FocusCommonInputPeriod
        title="Period"
        labelGap={labelGap}
        periodProps={{
          style: { width: '100%' },
          value: targetInfo.selectedPeriod.map((v) => dayjs(v)),
          placeHolder: targetInfo.period,
          onChange: (v) => focusAnalysisTargetChangePeriod(v, dispatch, targetInfo),
          disabledDate: (v) => disabledDate(targetInfo.period, v),
          inputReadOnly: true,
          allowClear: false,
          showTime: true,
          "data-testid": 'focus-analysis-target-period',
        }}
      />
      <FocusCommonInputSelect
        title="Job"
        labelGap={labelGap}
        selectProps={{
          value: targetInfo.job,
          onChange: (value) => {
            focusAnalysisTargetCommonChangeSelect(dispatch,[
              {
                key: 'job',
                value,
              },
              { key: 'lot_id', value: '' },
            ]);
          },
          "data-testid": 'focus-analysis-target-job',
        }}
      >
        {targetInfo.job_list.map(RenderSelectOptions)}
      </FocusCommonInputSelect>
      <FocusCommonInputSelect
        title="Lot ID"
        labelGap={labelGap}
        selectProps={{
          value: targetInfo.lot_id,
          onChange: (value) => {
            focusAnalysisTargetCommonChangeSelect(dispatch,{
              key: 'lot_id',
              value,
            });
          },
          "data-testid": 'focus-analysis-target-lotid',
        }}
      >
        {!!targetInfo.job &&
          !!Object.keys(targetInfo.lot_id_list).length &&
          Object.entries(targetInfo.lot_id_list[targetInfo.job]).map(
            ([key, value], i) => (
              <Select.OptGroup key={i} label={key}>
                {value.map(RenderSelectOptions)}
              </Select.OptGroup>
            ),
          )}
      </FocusCommonInputSelect>
    </FocusCommonSelectTarget>
  );
};

export default FocusAnalysisSelectTarget;
