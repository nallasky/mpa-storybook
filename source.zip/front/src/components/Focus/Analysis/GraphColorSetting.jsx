import React, { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { FormatPainterOutlined } from '@ant-design/icons';
import FocusCommonRibbonAccordion from '@components/Focus/Common/RibbonAccordion';
import useModal from '@libs/util/modalControl/useModal';
import GraphColorDisplaySettingModal from '@components/common/organisms/GraphColorDisplaySettingModal/GraphColorDisplaySettingModal';
import {
  graphSettingSelector,
  focusSavedGraphInfoActions,
} from '@reducers/slices/FocusInfo';
import { put_Focus_Save_Color } from '@libs/axios/focusRequest';
import { displayError } from '@libs/util/common/functionGroup';
import {
  FocusCommonGraphColorView,
  FocusCommonGraphAccordionBodyComponent,
} from '@components/Focus/Common/CommonElements';

const FocusAnalysisGraphColorSetting = ({ type }) => {
  const { openModal } = useModal();
  const settingInfo = useSelector(graphSettingSelector);
  const dispatch = useDispatch();

  const onColorChange = useCallback(() => {
    openModal(GraphColorDisplaySettingModal, {
      data: Object.entries(settingInfo[type]).reduce((acc, [key, value]) => {
        const { color, display } = value;
        acc[key] = Object.hasOwn(value, 'display')
          ? {
              color,
              display,
            }
          : {
              color,
            };
        return acc;
      }, {}),
      saveCallback: saveInfo,
    });
  }, [type, settingInfo]);

  const saveInfo = (v) => {
    setTimeout(() => {
      dispatch(
        focusSavedGraphInfoActions.UpdateSavedGraphInfoColor({
          key: type,
          value: v,
        }),
      );
      put_Focus_Save_Color(type, v).catch((e) => displayError(e?.message ?? e));
    }, 200);
  };

  return (
    <FocusCommonRibbonAccordion title="Graph color setting" initialState={true}>
      <FocusCommonGraphAccordionBodyComponent icon={<FormatPainterOutlined />}>
        <FocusCommonGraphColorView
          title={type}
          data={settingInfo[type]}
          onModalOpen={onColorChange}
        />
      </FocusCommonGraphAccordionBodyComponent>
    </FocusCommonRibbonAccordion>
  );
};
FocusAnalysisGraphColorSetting.propTypes = {
  type: PropTypes.string,
};

export default FocusAnalysisGraphColorSetting;
