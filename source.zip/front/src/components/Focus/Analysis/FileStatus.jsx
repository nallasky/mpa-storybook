import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import axios from 'axios';
import { Popover } from 'antd';
import { FileFilled } from '@ant-design/icons';
import FocusAnalysisFileTransfer from '@components/Focus/Analysis/FileTransfer';
import { TitleComponent } from '@components/Focus/Common/styles/CommonStyles';
import {
  post_Focus_File_Convert,
  get_Focus_Target_Initial_Info,
  get_Focus_File_Convert_Status,
  get_Focus_Lot_Id_Info,
} from '@libs/axios/focusRequest';
import useModal from '@libs/util/modalControl/useModal';
import ProcessingModal from '@components/common/organisms/ProcessingModal/ProcessingModal';
import StatusModal from '@components/common/organisms/StatusModal/StatusModal';
import { displayError, usePrevious } from '@libs/util/common/functionGroup';
import {
  fileInfoSelector,
  focusFileInfoActions,
  focusTargetInfoActions,
  initialTargetInfoState,
} from '@reducers/slices/FocusInfo';
import {
  FocusFileStatusWrapper,
  FocusFileStatusFileNameWrapper,
  FocusFileStatusGuardComponent,
  FocusFileStatusLogNameTypeWrapper,
  FocusFileStatusPopoverFileListItem,
  FocusFileStatusPopoverFileListWrapper,
  FocusFileStatusPopoverTitleWrapper,
  FocusFileStatusTableComponent,
} from '@components/Focus/Analysis/styles/FileStatusStyles';

const rowInfo = [
  {
    rowSpan: 3,
    typeTitle: 'New version',
    logNameTitle: 'Focus log detail',
    key: 'FOCUSLOGDETAIL',
  },
  {
    rowSpan: undefined,
    typeTitle: undefined,
    logNameTitle: 'Stage position monitor',
    key: 'STAGEPOSITIONMONITOR',
  },
  {
    rowSpan: undefined,
    typeTitle: undefined,
    logNameTitle: 'Status monitor',
    key: 'StatusMonitor',
  },
  {
    rowSpan: 8,
    typeTitle: 'Old version',
    logNameTitle: 'Machine',
    key: 'machine',
  },
  {
    rowSpan: undefined,
    typeTitle: undefined,
    logNameTitle: 'IlluminanceMultiTable',
    key: 'ILLUMINANCEMULTITABLE',
  },
  {
    rowSpan: undefined,
    typeTitle: undefined,
    logNameTitle: 'PlateAutoFocusCompensation',
    key: 'PLATEAUTOFOCUSCOMPENSATION',
  },
  {
    rowSpan: undefined,
    typeTitle: undefined,
    logNameTitle: 'PrescanCompensationMonitor',
    key: 'PRESCANCOMPENSATIONMONITOR',
  },
  {
    rowSpan: undefined,
    typeTitle: undefined,
    logNameTitle: 'Stage position monitor',
    key: 'STAGEPOSITIONMONITOR',
  },
  {
    rowSpan: undefined,
    typeTitle: undefined,
    logNameTitle: 'PlateFocusInterlockMonitor',
    key: 'PLATEFOCUSINTERLOCKMONITOR',
  },
  {
    rowSpan: undefined,
    typeTitle: undefined,
    logNameTitle: 'Process',
    key: 'process',
  },
  {
    rowSpan: undefined,
    typeTitle: undefined,
    logNameTitle: 'Status monitor',
    key: 'StatusMonitor',
  },
  {
    rowSpan: undefined,
    typeTitle: 'unknown',
    logNameTitle: undefined,
    key: 'unknown',
  },
];

const FocusAnalysisFileStatus = () => {
  const { openModal, closeModal } = useModal();
  const { fileList, deviceList } = useSelector(fileInfoSelector);
  const dispatch = useDispatch();

  const [displayGuard, setDisplayGuard] = useState(false);

  const cancelTokenSource = useRef();

  const changeGuardDisplay = (v) => {
    setDisplayGuard(v);
  };

  const saveUnknownCategory = (list, type) => {
    const newUnknownList =
      type === 'save'
        ? fileList.unknown.map((v) => {
            const findFile = list.find(({ uid }) => uid === v.uid);
            if (!findFile) return v;
            return {
              ...v,
              changedLogName: findFile.changedLogName,
            };
          })
        : fileList.unknown.filter(({ uid }) => !list.includes(uid));
    const newFileInfoArr = [
      {
        key: 'fileList',
        value: { ...fileList, unknown: [...newUnknownList] },
      },
    ];
    if (type === 'delete') {
      newFileInfoArr.push({
        key: 'deleteList',
        value: list,
      });
    }
    dispatch(focusFileInfoActions.UpdateFileInfoSingle(newFileInfoArr));
  };

  const setTargetInfo = async (id) => {
    cancelTokenSource.current = new AbortController();
    const { info } = await get_Focus_Target_Initial_Info(
      id,
      cancelTokenSource.current.signal,
    );
    const { info: subInfo } = await get_Focus_Lot_Id_Info(
      id,
      info.period,
    );
    dispatch(
      focusTargetInfoActions.UpdateTargetInfoAll({
        ...initialTargetInfoState,
        rid: id,
        fab_list: info.fab,
        period: info.period,
        selectedPeriod: info.period,
        job_list: subInfo.job,
        lot_id_list: subInfo.lot_id,
        currentTab: 'target',
      }),
    );
  };

  const onLoadStart = async () => {
    if (
      fileList.unknown.filter(
        ({ changedLogName }) => changedLogName === 'unknown',
      ).length
    ) {
      displayError(
        'Cannot start because there are files that have not yet been classified in the unknown file list.',
      );
      return;
    }

    try {
      const form = new FormData();
      for (const [key, files] of Object.entries(fileList).filter(
        ([k]) => k !== 'unknown',
      )) {
        const allFiles = files.concat(
          fileList.unknown.filter(
            ({ changedLogName }) => key === changedLogName,
          ),
        );
        for (const { fileObj, name } of allFiles) {
          form.append(key, fileObj, name);
        }
      }
      const findProcessList = fileList.unknown.filter(
        ({ changedLogName, isProcess }) =>
          changedLogName !== 'unknown' && isProcess,
      );
      for (const { fileObj, changedLogName, name } of findProcessList) {
        form.append('process', fileObj, `${changedLogName},${name}`);
      }

      cancelTokenSource.current = new AbortController();
      openModal(ProcessingModal, {
        title: 'Converting',
        message: 'Converting files',
        useCancel: true,
        onCancel: () => cancelTokenSource.current.abort(),
      });

      cancelTokenSource.current = new AbortController();
      const response = await post_Focus_File_Convert(
        form,
        cancelTokenSource.current.signal,
      );
      closeModal(ProcessingModal);
      setTimeout(() => {
        openModal(StatusModal, {
          startCallback: () => setTargetInfo(response),
          intervalCallback: () => get_Focus_File_Convert_Status(response),
        });
      }, 220);
    } catch (e) {
      closeModal(ProcessingModal);
      if (!axios.isCancel(e))
        displayError(e.response?.data?.msg ?? e?.message ?? e);
    }
  };

  const startDisable = () => {
    return (
      !fileList['STAGEPOSITIONMONITOR'].length &&
      !fileList.unknown.filter(
        ({ changedLogName }) => changedLogName === 'STAGEPOSITIONMONITOR',
      ).length
    );
  };

  return (
    <FocusFileStatusWrapper>
      {displayGuard && <FocusFileStatusGuardComponent />}
      <TitleComponent>Analysis file status</TitleComponent>
      <FocusFileStatusTableComponent>
        <thead>
          <tr>
            <th>Type</th>
            <th>Log name</th>
            <th>File</th>
          </tr>
        </thead>
        <tbody>
          {rowInfo.map(({ key, ...rest }, i) => {
            const createList =
              key === 'process'
                ? fileList.unknown.filter(
                    ({ changedLogName, isProcess }) =>
                      changedLogName !== 'unknown' && isProcess,
                  )
                : key !== 'unknown'
                ? fileList[key].concat(
                    fileList.unknown.filter(
                      ({ changedLogName }) => changedLogName === key,
                    ),
                  )
                : fileList.unknown;
            return (
              <TableBodyRowComponent
                {...rest}
                fileList={createList}
                key={i}
                deviceList={
                  key === 'unknown' ? Object.keys(deviceList) : undefined
                }
                saveCallback={saveUnknownCategory}
                guardChanger={changeGuardDisplay}
              />
            );
          })}
        </tbody>
      </FocusFileStatusTableComponent>
      <button onClick={onLoadStart} disabled={startDisable()}>
        Load Start
      </button>
    </FocusFileStatusWrapper>
  );
};

const createInitialFileList = (prev, next) => {
  if (!prev || !prev.length) {
    return next.map(({ fileObj: { name }, uid, changedLogName }) => ({
      name,
      uid,
      changedLogName,
      status: 'add',
    }));
  }
  if (prev.length > next.length) {
    return prev.map(({ fileObj: { name }, uid, changedLogName }) => ({
      name,
      uid,
      changedLogName,
      status: next.find(({ uid: sUid }) => sUid === uid) ? 'normal' : 'delete',
    }));
  } else {
    return next.map(({ fileObj: { name }, uid, changedLogName }) => ({
      name,
      uid,
      changedLogName,
      status: prev.find(({ uid: sUid }) => sUid === uid) ? 'normal' : 'add',
    }));
  }
};

const TableBodyRowComponent = ({
  rowSpan,
  typeTitle,
  logNameTitle,
  fileList,
  deviceList,
  saveCallback,
  guardChanger,
}) => {
  const fileListRef = usePrevious(fileList);
  const [innerFileList, setInnerFileList] = useState([]);

  const createMoreClassName = () => {
    const moreFileList = innerFileList.slice(5);
    if (moreFileList.find(({ status }) => status === 'delete')) {
      return 'delete';
    }
    if (moreFileList.find(({ status }) => status === 'add')) {
      return 'add';
    }
    return 'normal';
  };

  const createLogNameTitleClassName = (type, logName) => {
    const newFileList =
      logName === 'unknown'
        ? innerFileList.filter(
            ({ changedLogName }) => changedLogName === 'unknown',
          )
        : innerFileList;
    if (type === 'add' && newFileList.find(({ status }) => status === 'add')) {
      return 'file-add animate';
    }
    if (
      type === 'delete' &&
      newFileList.find(({ status }) => status === 'delete')
    ) {
      return 'file-delete animate';
    }
    return type === 'add' ? 'file-add' : 'file-delete';
  };

  useEffect(() => {
    if (fileListRef && fileListRef.length !== fileList.length) {
      guardChanger(true);
      setInnerFileList(createInitialFileList(fileListRef, fileList));
    }
  }, [fileList]);

  useEffect(() => {
    if (
      innerFileList.length &&
      innerFileList.find(({ status }) => status !== 'normal')
    ) {
      setTimeout(() => {
        setInnerFileList((prev) => {
          return prev
            .filter(({ status }) => status !== 'delete')
            .map((v) => ({ ...v, status: 'normal' }));
        });
        guardChanger(false);
      }, 1510);
    }
  }, [innerFileList]);

  return (
    <tr>
      {typeTitle && (
        <td
          rowSpan={rowSpan}
          className={'title' + (typeTitle === 'unknown' ? ' unknown' : '')}
        >
          {typeTitle !== 'unknown' ? (
            typeTitle
          ) : (
            <FocusFileStatusLogNameTypeWrapper>
              <div className="title">{typeTitle}</div>
              <div className={createLogNameTitleClassName('add', 'unknown')}>
                File added
              </div>
              <div className={createLogNameTitleClassName('delete', 'unknown')}>
                File deleted
              </div>
            </FocusFileStatusLogNameTypeWrapper>
          )}
        </td>
      )}
      {logNameTitle && (
        <td className="log-name">
          <FocusFileStatusLogNameTypeWrapper
            isMust={logNameTitle === 'Stage position monitor'}
          >
            <div className="title">{logNameTitle}</div>
            <div className={createLogNameTitleClassName('add')}>File added</div>
            <div className={createLogNameTitleClassName('delete')}>
              File deleted
            </div>
          </FocusFileStatusLogNameTypeWrapper>
        </td>
      )}
      {typeTitle === 'unknown' && (
        <td colSpan="2">
          <FocusAnalysisFileTransfer
            fileList={fileList.map(
              ({ name, uid, changedLogName, isProcess }) => ({
                name,
                uid,
                changedLogName,
                type: isProcess ? 'process' : 'logName',
              }),
            )}
            deviceList={deviceList}
            saveCallback={saveCallback}
          />
        </td>
      )}
      {fileList && typeTitle !== 'unknown' && (
        <td>
          <FocusFileStatusFileNameWrapper>
            {innerFileList.slice(0, 4).map(({ name, status }, i) => (
              <span key={i} title={name} className={status}>
                {name}
              </span>
            ))}
            {!!innerFileList.slice(5).length && (
              <Popover
                placement="left"
                trigger="hover"
                title={
                  <FocusFileStatusPopoverTitleWrapper>
                    Registered files
                  </FocusFileStatusPopoverTitleWrapper>
                }
                content={
                  <FocusFileStatusPopoverFileListWrapper>
                    {innerFileList.slice(5).map(({ name }, i) => (
                      <FocusFileStatusPopoverFileListItem key={i}>
                        <div className="icon-wrapper">
                          <FileFilled />
                        </div>
                        <div className="info-wrapper" title={name}>
                          <p className="file-name">{name}</p>
                          <p className="log-name">{logNameTitle}</p>
                        </div>
                      </FocusFileStatusPopoverFileListItem>
                    ))}
                  </FocusFileStatusPopoverFileListWrapper>
                }
              >
                <span className={createMoreClassName()}>more...</span>
              </Popover>
            )}
          </FocusFileStatusFileNameWrapper>
        </td>
      )}
    </tr>
  );
};
TableBodyRowComponent.propTypes = {
  rowSpan: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  typeTitle: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  logNameTitle: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  fileList: PropTypes.array,
  deviceList: PropTypes.array,
  saveCallback: PropTypes.func,
  guardChanger: PropTypes.func,
};
TableBodyRowComponent.defaultProps = {
  rowSpan: 1,
};
TableBodyRowComponent.displayName = 'TableBodyRowComponent';

export default FocusAnalysisFileStatus;
