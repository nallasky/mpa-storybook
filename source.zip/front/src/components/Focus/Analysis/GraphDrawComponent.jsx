import React, { useMemo, useRef } from 'react';
import PropTypes from 'prop-types';
import Plot from 'react-plotly.js';
import download from 'downloadjs';
import { getFocusAnalysisGraphImgUrl } from '@libs/util/common/functionGroup';
import {
  FocusGraphDrawComponentColorCircle,
  FocusGraphDrawComponentTableWrapper,
  FocusGraphDrawComponentTagWrapper,
  FocusGraphDrawComponentWrapper,
} from '@components/Focus/Analysis/styles/GraphDrawComponentStyles';

const cameraIcon = {
  width: 1000,
  height: 1000,
  path: 'm500 450c-83 0-150-67-150-150 0-83 67-150 150-150 83 0 150 67 150 150 0 83-67 150-150 150z m400 150h-120c-16 0-34 13-39 29l-31 93c-6 15-23 28-40 28h-340c-16 0-34-13-39-28l-31-94c-6-15-23-28-40-28h-120c-55 0-100-45-100-100v-450c0-55 45-100 100-100h800c55 0 100 45 100 100v450c0 55-45 100-100 100z m-400-550c-138 0-250 112-250 250 0 138 112 250 250 250 138 0 250-112 250-250 0-138-112-250-250-250z m365 380c-19 0-35 16-35 35 0 19 16 35 35 35 19 0 35-16 35-35 0-19-16-35-35-35z',
  transform: 'matrix(1 0 0 -1 0 850)',
};

const initialLineLayoutFormat = {
  showlegend: false,
  xaxis: {
    gridcolor: 'rgba(0,0,0,0)',
    linecolor: 'rgba(0,0,0,0.1)',
    linewidth: 1,
    zerolinecolor: 'rgba(0,0,0,0.25)',
    mirror: true,
    ticks: 'outside',
    tickcolor: 'rgba(0,0,0,0.1)',
    tickwidth: 1,
    ticklen: 10,
    autotick: false,
  },
  yaxis: {
    gridcolor: 'rgba(0,0,0,0.25)',
    linecolor: 'rgba(0,0,0,0.1)',
    zerolinecolor: 'rgba(0,0,0,0.25)',
    linewidth: 1,
    mirror: true,
    tickformat: '.3f',
  },
  margin: {
    t: 70,
    l: 100,
    r: 50,
    b: 40,
  },
  annotations: [
    {
      x: 0,
      xshift: -33,
      y: 1,
      yshift: 30,
      xref: 'paper',
      yref: 'paper',
      text: '[um]',
      showarrow: false,
    },
  ],
};

const initialStackedLayoutFormat = {
  barmode: 'relative',
  showlegend: false,
  xaxis: {
    gridcolor: 'rgba(0,0,0,0)',
    linecolor: 'rgba(0,0,0,0.1)',
    linewidth: 1,
    zerolinecolor: 'rgba(0,0,0,0.25)',
    mirror: true,
    ticks: 'outside',
    tickcolor: 'rgba(0,0,0,0.1)',
    tickwidth: 1,
    ticklen: 10,
    autotick: false,
  },
  yaxis: {
    gridcolor: 'rgba(0,0,0,0.25)',
    linecolor: 'rgba(0,0,0,0.1)',
    zerolinecolor: 'rgba(0,0,0,0.25)',
    linewidth: 1,
    mirror: true,
    tickformat: '.3f',
  },
  yaxis2: {
    overlaying: 'y',
    side: 'right',
    gridcolor: 'transparent',
    linecolor: 'transparent',
    linewidth: 1,
    tickformat: '.3f',
    automargin: 'right',
  },
  margin: {
    t: 70,
    l: 100,
    r: 100,
    b: 40,
  },
  annotations: [
    {
      x: 0,
      y: 1,
      xshift: -33,
      yshift: 30,
      xref: 'paper',
      yref: 'paper',
      text: '[um]',
      showarrow: false,
    },
    {
      x: 1,
      y: 1,
      xshift: 33,
      yshift: 30,
      xref: 'paper',
      yref: 'paper',
      text: '[um]',
      showarrow: false,
    },
  ],
};

const convertMinusItems = [
  'AFC_Drive_Offset_Z',
  'LiPS_PSZ',
  'Each_Shot_AFC_i',
  'Plate_Thickness_Z_i',
  'Chuck_Lock_AFC_Z',
];

const stackedLineKeyList = ['Expoready_Z', 'Expoready_Pitch', 'Expoready_Roll'];

const infoToArr = (obj, type, data) => {
  if (!data.length) return [];
  return Object.entries(obj).filter((v) => {
    if (!Object.hasOwn(data[0], v[0])) return false;
    return (
      (type === 'line' &&
        Object.hasOwn(v[1], 'display') &&
        v[1].display === 'true') ||
      type === 'stacked'
    );
  });
};

const FocusAnalysisGraphDrawComponent = React.memo(
  ({ type, data, graphType, callbackFunc }) => {
    const graphRef = useRef();

    const legendInfo = useMemo(() => {
      const { graph_setting, graph_data, selected_shot } = data;
      const findData = graph_data.filter(({ shot }) => shot === selected_shot);
      return arrayDivision(
        infoToArr(graph_setting, graphType, findData).map(([k, v]) => [
          k,
          v.color,
        ]),
        4,
      );
    }, [data]);

    const graphData = useMemo(() => {
      const result = [];
      const { graph_setting, graph_data, selected_shot } = data;
      const findData = graph_data.filter(({ shot }) => shot === selected_shot);
      if (!findData.length) return result;

      infoToArr(graph_setting, graphType, findData).forEach(([key, value]) => {
        const { color, lower_limit, upper_limit } = value;
        if (graphType === 'line') {
          result.push({
            x: findData.map(({ plate }) => plate),
            y: findData.map((v) => v[key]),
            type: 'scatter',
            mode: 'lines+markers',
            name: key,
            marker: {
              color,
              opacity: 1,
              size:
                !Object.hasOwn(value, 'lower_limit') ||
                lower_limit === upper_limit
                  ? 6
                  : findData.map((v) =>
                      v[key] <= upper_limit && v[key] >= lower_limit ? 6 : 12,
                    ),
            },
            line: {
              color,
            },
            hovertemplate: `<b>Plate</b>: %{x}<br><b>${key}</b>: %{y}<br><b>Glass ID</b>: ${findData[0].glass_id}<br><extra></extra>`,
          });
        } else {
          result.push(
            !stackedLineKeyList.includes(key)
              ? {
                  x: findData.map(({ plate }) => plate),
                  y: findData.map((v) =>
                    convertMinusItems.includes(key) ? -v[key] : v[key],
                  ),
                  name: key,
                  type: 'bar',
                  width: 0.35,
                  marker: {
                    color,
                    opacity: 1,
                  },
                  hovertemplate: `<b>Plate</b>: %{x}<br><b>${key}</b>: %{y}<br><b>Glass ID</b>: ${findData[0].glass_id}<br><extra></extra>`,
                }
              : {
                  x: findData.map(({ plate }) => plate),
                  y: findData.map((v) => v[key]),
                  type: 'scatter',
                  mode: 'lines+markers',
                  name: key,
                  marker: {
                    color,
                    opacity: 1,
                  },
                  line: {
                    color,
                  },
                  hovertemplate: `<b>Plate</b>: %{x}<br><b>${key}</b>: %{y}<br><b>Glass ID</b>: ${findData[0].glass_id}<br><extra></extra>`,
                  yaxis: 'y2',
                },
          );
        }
      });
      return result;
    }, [data]);

    const graphLayout = useMemo(() => {
      const { graph_data, graph_scale, selected_shot } = data;

      const plateArr = graph_data
        .filter(({ shot }) => shot === selected_shot)
        .map(({ plate }) => Number(plate));
      const itemLength = plateArr.length;
      const width =
        graphType === 'line' ? 220 + 30 * itemLength : 270 + 30 * itemLength;
      const marginTop = 70 + legendInfo.length * 15;

      if (graphType === 'line') {
        const {
          type: scaleType,
          upper_limit,
          lower_limit,
        } = graph_scale.line_graph_left_scale;
        return scaleType === 'auto' || upper_limit === lower_limit
          ? {
              ...initialLineLayoutFormat,
              width,
              xaxis: {
                ...initialLineLayoutFormat.xaxis,
                range: [Math.min(...plateArr) - 1, Math.max(...plateArr) + 1],
              },
              margin: {
                ...initialLineLayoutFormat.margin,
                t: marginTop,
              },
            }
          : {
              ...initialLineLayoutFormat,
              width,
              xaxis: {
                ...initialLineLayoutFormat.xaxis,
                range: [Math.min(...plateArr) - 1, Math.max(...plateArr) + 1],
              },
              yaxis: {
                ...initialLineLayoutFormat.yaxis,
                autorange: false,
                range: [lower_limit, upper_limit],
              },
              margin: {
                ...initialLineLayoutFormat.margin,
                t: marginTop,
              },
            };
      } else {
        const {
          type: leftScaleType,
          upper_limit: leftUpperLimit,
          lower_limit: leftLowerLimit,
        } = graph_scale.stacked_graph_left_scale;
        const {
          type: rightScaleType,
          upper_limit: rightUpperLimit,
          lower_limit: rightLowerLimit,
        } = graph_scale.stacked_graph_right_scale;
        const leftLayout =
          leftScaleType === 'auto' || leftUpperLimit === leftLowerLimit
            ? initialStackedLayoutFormat.yaxis
            : {
                ...initialStackedLayoutFormat.yaxis,
                autorange: false,
                range: [leftLowerLimit, leftUpperLimit],
              };
        const rightLayout =
          rightScaleType === 'auto' || rightUpperLimit === rightLowerLimit
            ? initialStackedLayoutFormat.yaxis2
            : {
                ...initialStackedLayoutFormat.yaxis2,
                autorange: false,
                range: [rightLowerLimit, rightUpperLimit],
              };
        return {
          ...initialStackedLayoutFormat,
          width,
          xaxis: {
            ...initialStackedLayoutFormat.xaxis,
            range: [Math.min(...plateArr) - 1, Math.max(...plateArr) + 1],
          },
          yaxis: leftLayout,
          yaxis2: rightLayout,
          margin: {
            ...initialStackedLayoutFormat.margin,
            t: marginTop,
          },
        };
      }
    }, [data]);

    const handleClickTakeScreenShot = () => {
      callbackFunc({
        isOpen: true,
        title: 'Download graph image',
        message: 'Creating download image',
      });
      setTimeout(async () => {
        const url = await getFocusAnalysisGraphImgUrl(graphRef.current);
        await download(url, `${type}-${graphType}.png`);
        callbackFunc({ isOpen: false });
      }, 500);
    };

    if (!graphData.length) return;

    return (
      <FocusGraphDrawComponentWrapper
        id={`${type.replace(' ', '_')}_${graphType}`}
        ref={graphRef}
      >
        <FocusGraphDrawComponentTableWrapper>
          <table>
            <tbody>
              {legendInfo.map((items, i) => {
                return (
                  <tr key={i}>
                    {items.map(([title, color], j) => (
                      <LegendItem key={j} title={title} color={color} />
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </FocusGraphDrawComponentTableWrapper>
        <Plot
          data={graphData}
          layout={graphLayout}
          config={{
            modeBarButtonsToAdd: [
              {
                name: 'Download image',
                icon: cameraIcon,
                click: handleClickTakeScreenShot,
              },
            ],
            modeBarButtonsToRemove: ['toImage'],
            displaylogo: false,
          }}
        />
      </FocusGraphDrawComponentWrapper>
    );
  },
  (prev, next) => {
    return JSON.stringify(prev.data) === JSON.stringify(next.data);
  },
);
FocusAnalysisGraphDrawComponent.propTypes = {
  type: PropTypes.string,
  data: PropTypes.object,
  graphType: PropTypes.string,
  callbackFunc: PropTypes.func,
};
FocusAnalysisGraphDrawComponent.displayName = 'FocusGraphDrawComponent';

const arrayDivision = (arr, n) => {
  const len = arr.length;
  const cnt = Math.floor(len / n) + (Math.floor(len % n) > 0 ? 1 : 0);
  const result = [];
  for (let i = 0; i < cnt; i++) {
    result.push(arr.splice(0, n));
  }
  return result;
};

const LegendItem = React.memo(({ color, title }) => {
  return (
    <td>
      <FocusGraphDrawComponentTagWrapper>
        <FocusGraphDrawComponentColorCircle color={color} />
        <span>{title}</span>
      </FocusGraphDrawComponentTagWrapper>
    </td>
  );
});
LegendItem.propTypes = {
  color: PropTypes.string,
  title: PropTypes.string,
};
LegendItem.displayName = 'LegendItem';

export default FocusAnalysisGraphDrawComponent;
