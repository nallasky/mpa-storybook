import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import Plot from 'react-plotly.js';
import { FocusCommonGraphElementContainer } from '@components/Focus/Common/CommonElements';

const graphLayoutSetting = {
  legend: {
    x: 0,
    y: 1.25,
    orientation: 'h',
  },
  xaxis: {
    gridcolor: 'rgba(0,0,0,0)',
    linecolor: 'rgba(0,0,0,0.1)',
    linewidth: 1,
    zerolinecolor: 'rgba(0,0,0,0.25)',
    mirror: true,
    ticks: 'outside',
    tickcolor: 'rgba(0,0,0,0.1)',
    tickwidth: 1,
    ticklen: 10,
    title: {
      text: 'msy',
    },
  },
  width: 690,
  height: 600,
  yaxis: {
    gridcolor: 'rgba(0,0,0,0.25)',
    linecolor: 'rgba(0,0,0,0.1)',
    zerolinecolor: 'rgba(0,0,0,0.25)',
    linewidth: 1,
    mirror: true,
    tickformat: '.1f',
  },
  annotations: [
    {
      x: 0,
      xshift: -33,
      y: 1,
      yshift: 30,
      xref: 'paper',
      yref: 'paper',
      text: '[um]',
      showarrow: false,
    },
    {
      x: 1.01,
      xshift: 33,
      y: -0.19,
      yshift: 30,
      xref: 'paper',
      yref: 'paper',
      text: '[um]',
      showarrow: false,
    },
  ],
  margin: {
    t: 120,
    b: 70,
  },
};

const FocusCommonGraphRender = ({ graphData, graphSetting, graphScale }) => {
  if (!graphData.length) return;

  const graphDataList = useMemo(() => {
    const { selectedShot, shots, ...colors } = graphSetting;
    console.log(shots);
    if (selectedShot === undefined) return [];
    const newProps = [];
    graphData.forEach((data) => {
      const { plate_no, glass_id, msy, ...values } = data;
      newProps.push({
        title: `Glass: ${glass_id} / Plate: ${plate_no}`,
        data: Object.entries(values).reduce((acc, [key, value]) => {
          const { display, color } = colors[key];
          if (display === 'false') return acc;
          return [
            ...acc,
            {
              x: msy,
              y: value,
              name: key,
              type: 'scatter',
              hovertemplate: `<b>${key}</b>: %{y}<br><b>msy</b>: %{x}<br><extra></extra>`,
              marker: {
                color,
                opacity: 1,
              },
              line: {
                color,
              },
            },
          ];
        }, []),
      });
    });
    return newProps;
  }, [graphData, graphSetting]);

  const layout = useMemo(() => {
    const yaxisLayout = {};
    if (graphScale.graph_left_scale.type === 'manual') {
      yaxisLayout.autorange = false;
      yaxisLayout.range = [
        graphScale.graph_left_scale.lower_limit,
        graphScale.graph_left_scale.upper_limit,
      ];
    } else {
      yaxisLayout.autorange = true;
    }
    return {
      ...graphLayoutSetting,
      yaxis: {
        ...graphLayoutSetting.yaxis,
        ...yaxisLayout,
      },
    };
  }, [graphScale]);

  return (
    <>
      {graphDataList.map((prop) => {
        const { title, data } = prop;
        return (
          <FocusCommonGraphElementContainer title={title} key={title}>
            <CommonPlotElement data={data} layout={layout} />
          </FocusCommonGraphElementContainer>
        );
      })}
    </>
  );
};
FocusCommonGraphRender.propTypes = {
  graphData: PropTypes.array,
  graphSetting: PropTypes.object,
  graphScale: PropTypes.object,
};

const CommonPlotElement = React.memo(
  ({ data, layout }) => {
    return <Plot data={data} layout={layout} config={{ displaylogo: false }} />;
  },
  (prev, next) =>
    JSON.stringify(prev.data) === JSON.stringify(next.data) &&
    JSON.stringify(prev.layout) === JSON.stringify(next.layout),
);
CommonPlotElement.propTypes = {
  data: PropTypes.array,
  layout: PropTypes.object,
};
CommonPlotElement.displayName = 'CommonPlotElement';

export default FocusCommonGraphRender;
