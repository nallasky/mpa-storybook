import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { BulbOutlined } from '@ant-design/icons';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import { FocusGraphSettingModalAlertWrapper } from '@components/Focus/Common/styles/CommonStyles';
import { FocusCommonGraphScaleInputForm } from '@components/Focus/Common/CommonElements';

const scaleSegmentArr = [
  {
    icon: undefined,
    title: 'Auto',
    value: 0,
  },
  {
    icon: undefined,
    title: 'Manual',
    value: 1,
  },
];

export const FocusCommonScaleEditModal = ({
  data,
  onClose,
  titles,
  saveCallback,
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [inputValues, setInputValues] = useState(data);

  const onSegmentChange = (key, v) => {
    setInputValues((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        type: !v ? 'auto' : 'manual',
      },
    }));
  };

  const onInputChange = (pKey, sKey, v) => {
    setInputValues((prev) => {
      return {
        ...prev,
        [pKey]: {
          ...prev[pKey],
          [sKey]: v,
        },
      };
    });
  };

  const closeModal = () => {
    setIsVisible(false);
    onClose();
  };

  const onApply = () => {
    const setLimitValue = (
      type,
      initValue,
      currentValue,
      compareValue,
      isUpper,
    ) => {
      if (
        type === 'auto' ||
        isNaN(Number(currentValue)) ||
        isNaN(Number(compareValue))
      ) {
        return Number(initValue);
      }
      if (isUpper && Number(currentValue) < Number(compareValue))
        return Number(initValue);
      if (!isUpper && Number(currentValue) > Number(compareValue))
        return Number(initValue);
      return Number(currentValue);
    };
    const currentInputValues = Object.entries(inputValues).reduce(
      (acc, [key, value]) => {
        const { type, lower_limit, upper_limit } = value;
        const newLowerLimit = setLimitValue(
          type,
          data[key].lower_limit,
          lower_limit,
          upper_limit,
          false,
        );
        const newUpperLimit = setLimitValue(
          type,
          data[key].upper_limit,
          upper_limit,
          lower_limit,
          true,
        );
        acc[key] = {
          type: newLowerLimit === newUpperLimit ? 'auto' : type,
          lower_limit: newLowerLimit,
          upper_limit: newUpperLimit,
        };
        return acc;
      },
      {},
    );
    closeModal();
    if (JSON.stringify(data) !== JSON.stringify(currentInputValues)) {
      setTimeout(() => {
        saveCallback(currentInputValues);
      }, 250);
    }
  };

  return (
    <DraggableModal
      visible={isVisible}
      title="Graph scale"
      bodyStyle={{ padding: '0 0 0.5rem 0' }}
      cancelHandler={closeModal}
      okText="Apply"
      okHandler={onApply}
    >
      <FocusGraphSettingModalAlertWrapper>
        <BulbOutlined />
        <span>
          {`The Graph's scales are saved in the DB and shared within this
          Function.`}
        </span>
      </FocusGraphSettingModalAlertWrapper>
      {Object.entries(data).map(([key, value]) => (
        <FocusCommonGraphScaleInputForm
          key={key}
          title={titles[key]}
          segmentedInfo={{
            initialSelected: value.type === 'auto' ? 0 : 1,
            items: scaleSegmentArr,
            callbackFunc: (v) => onSegmentChange(key, v),
          }}
          rangeInfo={{
            low: {
              value: inputValues[key].lower_limit,
              disabled: inputValues[key].type === 'auto',
              onChange: (e) =>
                onInputChange(key, 'lower_limit', e.target.value),
            },
            upper: {
              value: inputValues[key].upper_limit,
              disabled: inputValues[key].type === 'auto',
              onChange: (e) =>
                onInputChange(key, 'upper_limit', e.target.value),
            },
          }}
        />
      ))}
    </DraggableModal>
  );
};
FocusCommonScaleEditModal.propTypes = {
  data: PropTypes.object,
  onClose: PropTypes.func,
  titles: PropTypes.object,
  saveCallback: PropTypes.func,
};
