import React from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { Input, Tooltip, Select, Switch, DatePicker } from 'antd';
import {
  EditOutlined,
  QuestionCircleOutlined,
  SyncOutlined,
  PlayCircleOutlined,
} from '@ant-design/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import {
  LabelComponent,
  mixinList,
  TitleComponent,
} from '@components/Focus/Common/styles/CommonStyles';
import FocusCommonCustomSegmented from '@components/Focus/Common/CustomSegmented';
import {
  RenderSelectOptions,
  convertAndSortDataObjectToArray,
} from '@libs/util/common/functionGroup';

const CommonInputFormWrapper = styled.div`
  display: flex;
  align-items: ${(props) => props.align ?? 'center'};
  justify-content: ${(props) => props.justify ?? 'flex-start'};
  column-gap: 1rem;
  width: 100%;
  & > .label-wrapper {
    width: ${(props) => `${props.labelWidth}px` ?? 'fit-content'};
    & > .sub-title {
      display: block;
      font-size: 10px;
      color: var(--ckr-blue-5);
    }
    & > span + span {
      margin-top: 0.25rem;
    }
  }
`;

export const FocusCommonInputForm = ({
  children,
  title,
  labelWidth,
  justify,
  align,
  useRequire,
  useFullColon,
  subTitle,
}) => (
  <CommonInputFormWrapper
    justify={justify}
    align={align}
    labelWidth={labelWidth}
  >
    {title && (
      <div className="label-wrapper">
        <LabelComponent useRequire={useRequire} useFullColon={useFullColon}>
          {title}
        </LabelComponent>
        <span className="sub-title">{subTitle}</span>
      </div>
    )}
    {children}
  </CommonInputFormWrapper>
);
FocusCommonInputForm.propTypes = {
  children: PropTypes.node,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  labelWidth: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  justify: PropTypes.string,
  align: PropTypes.string,
  useRequire: PropTypes.bool,
  useFullColon: PropTypes.bool,
  subTitle: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

const MiddleLineFormWrapper = styled.div`
  position: relative;
  ${mixinList.flex({ align: 'center', justify: 'space-between' })}
  padding: 1rem 0;
  & > * {
    z-index: 2;
    background-color: white;
  }
  & > .title {
    margin-left: 2rem;
    padding: 0rem 0.5rem;
    & > span {
      margin-left: 0.3rem;
      color: var(--ckr-blue-6);
    }
  }
  & > .control {
    padding-left: 0.5rem;
  }
  &::before {
    position: absolute;
    top: calc(50% + 1px);
    left: 0;
    content: '';
    height: 1px;
    width: 100%;
    background-color: #f0f0f0;
  }
`;

export const FocusCommonMiddleLineForm = ({
  children,
  title,
  toolTipTitle,
}) => (
  <MiddleLineFormWrapper>
    <span className="title">
      {title}
      {toolTipTitle && (
        <Tooltip title={toolTipTitle}>
          <QuestionCircleOutlined />
        </Tooltip>
      )}
    </span>
    <div className="control">{children}</div>
  </MiddleLineFormWrapper>
);
FocusCommonMiddleLineForm.propTypes = {
  children: PropTypes.node,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  toolTipTitle: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

const FocusGraphSettingModalScaleContentWrapper = styled.div`
  margin: 0 1.5rem;
  padding: 0 0.5rem 0.5rem 0.5rem;
  border: 1px dashed #d9d9d9;
  border-radius: 8px;
  & > div {
    &:last-of-type {
      ${mixinList.flex({ align: 'center', justify: 'space-between' })}
      column-gap: 4rem;
      & > div {
        ${mixinList.flex({ align: 'center', justify: 'space-between' })}
        column-gap: 0.5rem;
      }
    }
  }
  & + div {
    margin-top: 1rem;
  }
`;

export const FocusCommonGraphScaleInputForm = React.memo(
  ({ title, segmentedInfo, rangeInfo }) => (
    <FocusGraphSettingModalScaleContentWrapper>
      <FocusCommonMiddleLineForm title={title} />
      <div>
        <FocusCommonCustomSegmented {...segmentedInfo} />
        <div>
          <Input type="text" style={{ width: '100%' }} {...rangeInfo.low} />
          <span>~</span>
          <Input type="text" style={{ width: '100% ' }} {...rangeInfo.upper} />
        </div>
      </div>
    </FocusGraphSettingModalScaleContentWrapper>
  ),
  (prev, next) => {
    return (
      JSON.stringify(prev.segmentedInfo) ===
        JSON.stringify(next.segmentedInfo) &&
      JSON.stringify(prev.rangeInfo) === JSON.stringify(next.rangeInfo)
    );
  },
);
FocusCommonGraphScaleInputForm.propTypes = {
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  segmentedInfo: PropTypes.object,
  rangeInfo: PropTypes.object,
};
FocusCommonGraphScaleInputForm.displayName = 'FocusCommonGraphScaleInputForm';

const FocusGraphSettingScaleWrapper = styled.div`
  & button {
    ${mixinList.whiteButton({ position: 'relative', fontSize: '12px' })}
  }
  & > .scale-info {
    padding: 0 8rem;
    & > div + div {
      margin-top: 1rem;
    }
  }
`;

const FocusGraphSettingScaleContent = styled.div`
  ${mixinList.flex({ align: 'center' })};
  & > span {
    flex-basis: 40%;
  }
  & > div {
    ${mixinList.flex({ align: 'center', justify: 'space-between' })};
    flex-basis: 100%;
    & > .limit-wrapper {
      & > .value {
        margin-left: 0.3rem;
      }
    }
  }
`;

const FocusGraphSettingScaleTagWrapper = styled.span`
  border: 1px solid var(--ckr-blue-3);
  color: var(--ckr-blue-5);
  background-color: #e6f7ff;
  font-size: 12px;
  padding: 0.2rem 0.5rem;
  border-radius: 10px;
  cursor: default;
  user-select: none;
  &.magenta {
    border-color: var(--ckr-magenta-3);
    color: var(--ckr-magenta-5);
    background-color: var(--ckr-magenta-1);
  }
`;

export const FocusCommonGraphScaleView = React.memo(
  ({ onEditClick, data, titles }) => (
    <FocusGraphSettingScaleWrapper>
      <FocusCommonMiddleLineForm title="Graph scale">
        <button onClick={onEditClick}>
          <EditOutlined />
          Edit
        </button>
      </FocusCommonMiddleLineForm>
      <div className="scale-info">
        {Object.entries(data).map(([key, value]) => {
          const { type, lower_limit, upper_limit } = value;
          return (
            <FocusGraphSettingScaleContent key={key}>
              <span>{titles[key]}</span>
              <div>
                <FocusGraphSettingScaleTagWrapper
                  className={type === 'manual' ? 'magenta' : ''}
                >
                  {type === 'auto' ? 'Auto' : 'Manual'}
                </FocusGraphSettingScaleTagWrapper>
                {type === 'manual' && (
                  <>
                    <div className="limit-wrapper">
                      <span>Y(lower limit):</span>
                      <span className="value">{lower_limit}</span>
                    </div>
                    <div className="limit-wrapper">
                      <span>Y(upper limit):</span>
                      <span className="value">{upper_limit}</span>
                    </div>
                  </>
                )}
              </div>
            </FocusGraphSettingScaleContent>
          );
        })}
      </div>
    </FocusGraphSettingScaleWrapper>
  ),
  (prev, next) => {
    return JSON.stringify(prev.data) === JSON.stringify(next.data);
  },
);
FocusCommonGraphScaleView.propTypes = {
  onEditClick: PropTypes.func,
  data: PropTypes.object,
  titles: PropTypes.object,
};
FocusCommonGraphScaleView.displayName = 'FocusCommonGraphScaleView';

const FocusGraphSettingShotSelectWrapper = styled.div`
  ${mixinList.flex({ align: 'center' })};
  width: 100%;
  column-gap: 2rem;
  & > div {
    &:first-of-type {
      width: 100%;
    }
    &.all-button-wrapper {
      ${mixinList.flex({ align: 'center' })};
      column-gap: 0.5rem;
      & > span {
        white-space: nowrap;
        & > span {
          cursor: help;
          margin: 0 0.2rem;
        }
      }
    }
  }
`;

export const FocusCommonGraphShotSelectForm = React.memo(
  ({ selectProps, optionList, allButtonInfo, tooltipTitle }) => (
    <FocusGraphSettingShotSelectWrapper>
      <FocusCommonMiddleLineForm
        title="Shot select"
        toolTipTitle={tooltipTitle}
      >
        <Select {...selectProps}>
          {optionList && optionList.map(RenderSelectOptions)}
        </Select>
      </FocusCommonMiddleLineForm>
      {allButtonInfo && (
        <div className="all-button-wrapper">
          <span>
            All
            <Tooltip title={allButtonInfo.title}>
              <QuestionCircleOutlined />
            </Tooltip>
            :
          </span>
          <Switch {...allButtonInfo.props} />
        </div>
      )}
    </FocusGraphSettingShotSelectWrapper>
  ),
  (prev, next) => {
    return JSON.stringify(prev) === JSON.stringify(next);
  },
);
FocusCommonGraphShotSelectForm.propTypes = {
  selectProps: PropTypes.object,
  optionList: PropTypes.array,
  allButtonInfo: PropTypes.object,
  tooltipTitle: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
FocusCommonGraphShotSelectForm.displayName = 'FocusCommonGraphShotSelectForm';

const FocusGraphColorComponentWrapper = styled.div`
  display: flex;
  column-gap: 2rem;
  & > div {
    ${mixinList.flex({ align: 'center' })};
    &:first-of-type {
      & > button {
        ${mixinList.whiteButton({ position: 'relative' })}
      }
    }
    &:last-of-type {
      gap: 1rem;
      flex-wrap: wrap;
    }
  }
`;

export const FocusCommonGraphColorView = ({ title, data, onModalOpen }) => (
  <FocusGraphColorComponentWrapper>
    <div>
      <button onClick={onModalOpen}>
        <SyncOutlined />
        {title ? `${title} color change` : 'color change'}
      </button>
    </div>
    <GraphColorItem data={data} />
  </FocusGraphColorComponentWrapper>
);
FocusCommonGraphColorView.propTypes = {
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  data: PropTypes.object,
  onModalOpen: PropTypes.func,
};

const FocusGraphColorItemWrapper = styled.span`
  ${mixinList.flex({ align: 'center' })};
  column-gap: 0.25rem;
  opacity: ${(props) => props.opacity};
`;

const FocusGraphColorIcon = styled.span`
  display: inline-block;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background-color: ${(props) => props.color};
`;

const GraphColorItem = React.memo(
  ({ data }) => (
    <div>
      {convertAndSortDataObjectToArray(data).map(([title, value]) => {
        const { color, display } = value;
        return (
          <FocusGraphColorItemWrapper
            opacity={display === 'true' || !display ? 1 : 0.5}
            key={title}
          >
            <FocusGraphColorIcon color={color} />
            <span className="title">{title}</span>
          </FocusGraphColorItemWrapper>
        );
      })}
    </div>
  ),
  (prev, next) => JSON.stringify(prev) === JSON.stringify(next),
);
GraphColorItem.propTypes = {
  data: PropTypes.object,
};
GraphColorItem.displayName = 'GraphColorItem';

const GraphAccordionBodyWrapper = styled.div`
  ${mixinList.flex({ align: 'center' })}
  min-height: 150px;
  & > div {
    &:first-of-type {
      flex-basis: 30%;
      ${mixinList.flex({ align: 'center', justify: 'center' })}
      font-size: 96px;
      color: var(--ckr-blue-9);
    }
    &:last-of-type {
      flex-basis: 100%;
      & > div + div {
        margin-top: 0.5rem;
      }
    }
  }
`;

export const FocusCommonGraphAccordionBodyComponent = ({ icon, children }) => {
  return (
    <GraphAccordionBodyWrapper>
      <div>{icon}</div>
      {children}
    </GraphAccordionBodyWrapper>
  );
};
FocusCommonGraphAccordionBodyComponent.propTypes = {
  icon: PropTypes.node,
  children: PropTypes.node,
};

const FocusCommonMainWrapper = styled.div`
  position: relative;
  width: ${(props) => `${props.width}`};
  padding: 1rem;
  ${(props) => !props.isInner && `${mixinList.basicStyle}`}
  ${(props) =>
    props.isResult &&
    `
    & > button {
      ${mixinList.twoLineButton({
        color: 'var(--ckr-blue-6)',
        top: '1rem',
        right: '1rem',
      })}
    }
    & > div + div {
      margin-top: 1rem;
    }
    `}
  ${(props) =>
    props.isTarget &&
    `
    & > div + div {
      margin-top: 2rem;
    }
    & > button {
      ${mixinList.twoLineButton({
        bottom: '0.5rem',
        right: props.isInner ? '0' : '1rem',
      })}
    }
    `}
`;

export const FocusCommonMainComponent = ({
  title,
  children,
  isResult,
  isInner,
  width,
  isTarget,
}) => {
  return (
    <FocusCommonMainWrapper
      isResult={isResult}
      isInner={isInner}
      width={width}
      isTarget={isTarget}
    >
      {title && <TitleComponent>{title}</TitleComponent>}
      {children}
    </FocusCommonMainWrapper>
  );
};

FocusCommonMainComponent.propTypes = {
  title: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  children: PropTypes.node,
  isResult: PropTypes.bool,
  isInner: PropTypes.bool,
  width: PropTypes.string,
  isTarget: PropTypes.bool,
};
FocusCommonMainComponent.defaultProps = {
  width: '100%',
  isInner: false,
};

const GraphElementWrapper = styled.div`
  width: calc(50% - 0.5rem);
  & > span {
    display: inline-block;
    padding: 0.5rem;
    font-style: italic;
    background-color: var(--ckr-blue-5);
    color: white;
    border-radius: 8px 8px 0 0;
  }
  & > div {
    ${mixinList.flex({ justify: 'center', align: 'center' })}
    border-radius: 0 4px 4px 4px;
    border: 1px dashed var(--ckr-blue-4);
    padding: 0.5rem;
  }
`;

export const FocusCommonGraphElementContainer = ({ title, children }) => {
  return (
    <GraphElementWrapper>
      <span>{title}</span>
      <div>{children}</div>
    </GraphElementWrapper>
  );
};
FocusCommonGraphElementContainer.propTypes = {
  title: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  children: PropTypes.node,
};

export const FocusCommonSelectTarget = ({
  isInner,
  startDisabled,
  children,
  onStart,
}) => {
  return (
    <FocusCommonMainComponent title="Select Target" isTarget isInner={isInner}>
      {children}
      <button onClick={onStart} disabled={startDisabled} data-testid="focus-common-target-start-analysis-button">
        <PlayCircleOutlined />
        <span>Start</span>
      </button>
    </FocusCommonMainComponent>
  );
};
FocusCommonSelectTarget.propTypes = {
  isInner: PropTypes.bool,
  onStart: PropTypes.func,
  startDisabled: PropTypes.bool,
  children: PropTypes.node,
};

const ArrowMessageWrapper = styled.div`
  @keyframes moveLeft {
    25% {
      transform: translateX(-25px);
    }
    50% {
      transform: translateX(0px);
    }
  }
  width: 100%;
  height: 100%;
  ${mixinList.flex({ direction: 'column', align: 'center', justify: 'center' })}
  & > p {
    font-size: 24px;
    font-weight: bold;
  }
  & > svg {
    animation: moveLeft 2s ease-in-out infinite;
  }
`;

export const FocusCommonArrowMessage = () => {
  return (
    <FocusCommonMainComponent>
      <ArrowMessageWrapper>
        <FontAwesomeIcon icon={faArrowLeft} size="10x" />
        <p>Please first set the left.</p>
      </ArrowMessageWrapper>
    </FocusCommonMainComponent>
  );
};

export const FocusCommonInputPeriod = ({ title, labelGap, periodProps }) => {
  return (
    <FocusCommonInputForm
      title={title}
      labelWidth={labelGap}
      useRequire
      useFullColon
    >
      <DatePicker.RangePicker
        { ...periodProps }
      />
    </FocusCommonInputForm>
  );
};
FocusCommonInputPeriod.propTypes = {
  title: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  labelGap: PropTypes.number,
  periodProps: PropTypes.object,
};

export const FocusCommonInputSelect = ({
  title,
  labelGap,
  selectProps,
  children,
}) => {
  return (
    <FocusCommonInputForm
      title={title}
      labelWidth={labelGap}
      useFullColon
      useRequire
    >
      <Select style={{ width: '100%' }} {...selectProps}>
        {children}
      </Select>
    </FocusCommonInputForm>
  );
};
FocusCommonInputSelect.propTypes = {
  title: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  labelGap: PropTypes.number,
  selectProps: PropTypes.object,
  children: PropTypes.node,
};
