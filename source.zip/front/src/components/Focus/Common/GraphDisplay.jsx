import React from 'react';
import styled from '@emotion/styled';
import { useSelector } from 'react-redux';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';
import FocusCommonGraphRender from '@components/Focus/Common/GraphRender';
import {
  graphDataSelector,
  graphScaleSelector,
  graphSettingSelector,
} from '@reducers/slices/FocusInfo';

const GraphDisplayWrapper = styled.div`
  ${mixinList.flex({ justify: 'space-between' })}
  width: 100%;
  flex-wrap: wrap;
  row-gap: 1rem;
`;

const FocusCommonGraphDisplay = () => {
  const settingInfo = useSelector(graphSettingSelector);
  const scaleInfo = useSelector(graphScaleSelector);
  const dataInfo = useSelector(graphDataSelector);
  const { type } = settingInfo;

  return (
    <GraphDisplayWrapper>
      <FocusCommonGraphRender
        graphData={
          dataInfo[type].find(
            ({ shot_no }) => shot_no === settingInfo[type]?.selectedShot,
          )?.data || []
        }
        graphSetting={settingInfo[type]}
        graphScale={{
          graph_left_scale: scaleInfo.graph_left_scale,
          graph_right_scale: scaleInfo.graph_right_scale,
        }}
      />
    </GraphDisplayWrapper>
  );
};

export default FocusCommonGraphDisplay;
