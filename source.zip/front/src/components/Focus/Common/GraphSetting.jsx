import React, { useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { SettingOutlined } from '@ant-design/icons';
import FocusCommonRibbonAccordion from '@components/Focus/Common/RibbonAccordion';
import {
  FocusCommonGraphAccordionBodyComponent,
  FocusCommonGraphShotSelectForm,
  FocusCommonGraphScaleView,
} from '@components/Focus/Common/CommonElements';
import {
  graphSettingSelector,
  focusSavedGraphInfoActions,
  graphScaleSelector,
  graphTypeSelector,
} from '@reducers/slices/FocusInfo';
import useModal from '@libs/util/modalControl/useModal';
import { FocusCommonScaleEditModal } from '@components/Focus/Common/ScaleEditModal';
import { put_Focus_Temp_Save_Scale } from '@libs/axios/focusRequest';
import { displayError } from '@libs/util/common/functionGroup';

const FocusCommonGraphSetting = () => {
  return (
    <FocusCommonRibbonAccordion title="Graph Setting" initialState={true}>
      <FocusCommonGraphAccordionBodyComponent icon={<SettingOutlined />}>
        <div>
          <GraphShotSelect />
          <GraphScaleView />
        </div>
      </FocusCommonGraphAccordionBodyComponent>
    </FocusCommonRibbonAccordion>
  );
};

const GraphShotSelect = () => {
  const graphSettings = useSelector(graphSettingSelector);
  const { type } = graphSettings;
  const { shots, selectedShot } = graphSettings[type];
  const dispatch = useDispatch();

  const changeShot = (v) => {
    dispatch(
      focusSavedGraphInfoActions.UpdateSavedGraphSetting({
        key: type,
        value: {
          selectedShot: v,
        },
      }),
    );
  };

  return (
    <FocusCommonGraphShotSelectForm
      tooltipTitle="test"
      optionList={shots}
      selectProps={{
        value: selectedShot,
        onChange: changeShot,
        style: { minWidth: '300px' },
      }}
    />
  );
};

const scaleTitles = {
  graph_left_scale: `Graph's Left Scale`,
  graph_right_scale: `Graph's Right Scale`,
};

const GraphScaleView = () => {
  const scaleInfo = useSelector(graphScaleSelector);
  const type = useSelector(graphTypeSelector);
  const { openModal } = useModal();
  const dispatch = useDispatch();

  const saveScale = (v) => {
    setTimeout(() => {
      dispatch(
        focusSavedGraphInfoActions.UpdateSavedGraphInfoSingle({
          key: 'graph_scale',
          value: {
            ...scaleInfo,
            ...v,
          },
        }),
      );
      put_Focus_Temp_Save_Scale(v, type).catch((e) =>
        displayError(e?.message ?? e),
      );
    }, 200);
  };

  const onEdit = useCallback(() => {
    openModal(FocusCommonScaleEditModal, {
      data: {
        graph_left_scale: scaleInfo.graph_left_scale,
      },
      titles: scaleTitles,
      saveCallback: saveScale,
    });
  }, [scaleInfo]);

  return (
    <FocusCommonGraphScaleView
      data={
        type === 'prescan'
          ? {
              graph_left_scale: scaleInfo.graph_left_scale,
            }
          : {
              graph_left_scale: scaleInfo.graph_left_scale,
              graph_right_scale: scaleInfo.graph_right_scale,
            }
      }
      titles={scaleTitles}
      onEditClick={onEdit}
    />
  );
};

export default FocusCommonGraphSetting;
