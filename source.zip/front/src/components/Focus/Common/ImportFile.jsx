import React from 'react';
import PropTypes from 'prop-types';
import { Upload } from 'antd';
import { InboxOutlined } from '@ant-design/icons';
import { FocusCommonInputForm } from '@components/Focus/Common/CommonElements';
import { FocusImportFileWrapper } from '@components/Focus/Analysis/styles/ImportFileStyles';

const FocusCommonImportFile = ({
  title,
  useRequire,
  labelWidth,
  align,
  mw,
  mh,
  subTitle,
  onChangeFile,
  type,
}) => {
  return (
    <FocusCommonInputForm
      title={title}
      useRequire={useRequire}
      useFullColon
      align={align}
      labelWidth={labelWidth}
      justify="space-between"
      subTitle={subTitle}
    >
      <FocusImportFileWrapper mw={mw} mh={mh}>
        <Upload.Dragger
          beforeUpload={() => false}
          onChange={({ fileList }) => onChangeFile(fileList, type)}
          multiple
        >
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">
            Click or drag file to this area to upload.
          </p>
        </Upload.Dragger>
      </FocusImportFileWrapper>
    </FocusCommonInputForm>
  );
};

FocusCommonImportFile.propTypes = {
  title: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  useRequire: PropTypes.bool,
  labelWidth: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  align: PropTypes.string,
  mw: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  mh: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  subTitle: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  type: PropTypes.string,
  onChangeFile: PropTypes.func,
};

export default FocusCommonImportFile;
