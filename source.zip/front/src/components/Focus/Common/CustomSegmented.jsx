import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
  CustomSegmentedWrapper,
  CustomSegmentThumb,
} from '@components/Focus/Common/styles/CustomSegmentedStyles';

const getTotalLeftDistance = (elements, limit) => {
  let result = 0;
  let i = 0;

  while (i < limit) {
    result += elements[i].getBoundingClientRect().width;
    i++;
  }

  return result;
};

const FocusCommonCustomSegmented = ({
  items,
  initialSelected,
  callbackFunc,
}) => {
  const [segmentChecked, setSegmentChecked] = useState(initialSelected ?? 0);
  const [thumbProps, setThumbProps] = useState({
    width: 0,
    left: 0,
    height: 0,
    motion: false,
  });
  const segmentRef = useRef();

  const onSegmentChange = (idx) => {
    setThumbProps((prev) => ({
      ...prev,
      width:
        segmentRef.current.children[segmentChecked].getBoundingClientRect()
          .width,
      left: getTotalLeftDistance(segmentRef.current.children, segmentChecked),
    }));

    setTimeout(() => {
      segmentRef.current.children[segmentChecked].classList.remove('selected');
      setThumbProps((prev) => ({
        ...prev,
        width: segmentRef.current.children[idx].getBoundingClientRect().width,
        left: getTotalLeftDistance(segmentRef.current.children, idx),
        motion: true,
      }));
    }, 5);

    setTimeout(() => {
      setSegmentChecked(idx);
      if (callbackFunc) {
        callbackFunc(items[idx].value);
      }
    }, 305);
  };

  useEffect(() => {
    setThumbProps((prev) => ({
      ...prev,
      height: segmentRef.current.children[0].offsetHeight,
    }));
  }, []);

  return (
    <CustomSegmentedWrapper>
      <div className="segmented-group" ref={segmentRef}>
        {items.map((v, i) => (
          <label key={i} className={segmentChecked === i ? 'selected' : ''}>
            <input
              type="radio"
              checked={segmentChecked === i}
              onChange={() => onSegmentChange(i)}
            />
            <div className="label-wrapper">
              {v.icon && <span>{v.icon}</span>}
              <span>{v.title}</span>
            </div>
          </label>
        ))}
        <CustomSegmentThumb
          thumbHeight={thumbProps.height}
          thumbWidth={thumbProps.width}
          left={thumbProps.left}
          className={'thumb' + (thumbProps.motion ? ' motion' : '')}
        />
      </div>
    </CustomSegmentedWrapper>
  );
};
FocusCommonCustomSegmented.propTypes = {
  items: PropTypes.array,
  initialSelected: PropTypes.number,
  callbackFunc: PropTypes.func,
};

export default FocusCommonCustomSegmented;
