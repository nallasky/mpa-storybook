import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { FormatPainterOutlined } from '@ant-design/icons';
import FocusCommonRibbonAccordion from '@components/Focus/Common/RibbonAccordion';
import {
  FocusCommonGraphAccordionBodyComponent,
  FocusCommonGraphColorView,
} from '@components/Focus/Common/CommonElements';
import {
  graphSettingSelector,
  focusSavedGraphInfoActions,
} from '@reducers/slices/FocusInfo';
import useModal from '@libs/util/modalControl/useModal';
import GraphColorDisplaySettingModal from '@components/common/organisms/GraphColorDisplaySettingModal/GraphColorDisplaySettingModal';
import { put_Focus_Temp_Save_Color } from '@libs/axios/focusRequest';
import { displayError } from '@libs/util/common/functionGroup';

const FocusCommonGraphColorSetting = () => {
  const settingInfo = useSelector(graphSettingSelector);
  const { type } = settingInfo;
  const { shots, selectedShot, ...colors } = settingInfo[type];
  const { openModal } = useModal();
  const dispatch = useDispatch();

  console.log(shots);
  console.log(selectedShot);

  const onSave = (v) => {
    setTimeout(() => {
      dispatch(
        focusSavedGraphInfoActions.UpdateSavedGraphInfoColor({
          key: type,
          value: v,
        }),
      );
      put_Focus_Temp_Save_Color(type, v).catch((e) =>
        displayError(e?.message ?? e),
      );
    }, 200);
  };

  const onEdit = () => {
    openModal(GraphColorDisplaySettingModal, {
      data: colors,
      saveCallback: onSave,
    });
  };

  return (
    <FocusCommonRibbonAccordion title="Graph Color Setting" initialState={true}>
      <FocusCommonGraphAccordionBodyComponent icon={<FormatPainterOutlined />}>
        <FocusCommonGraphColorView
          title={type}
          data={colors}
          onModalOpen={onEdit}
        />
      </FocusCommonGraphAccordionBodyComponent>
    </FocusCommonRibbonAccordion>
  );
};

export default FocusCommonGraphColorSetting;
