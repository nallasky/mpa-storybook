import React from 'react';
import { useSelector } from 'react-redux';
import styled from '@emotion/styled';
import { CloudDownloadOutlined } from '@ant-design/icons';
import { FocusCommonMainComponent } from '@components/Focus/Common/CommonElements';
import FocusCommonGraphSetting from '@components/Focus/Common/GraphSetting';
import FocusCommonGraphColorSetting from '@components/Focus/Common/GraphColorSetting';
import FocusCommonGraphDisplay from '@components/Focus/Common/GraphDisplay';
import {
  graphDataSelector,
  graphTypeSelector,
  initialGraphData,
} from '@reducers/slices/FocusInfo';

const ResultBodyWrapper = styled.div`
  margin-top: calc(2rem + 22px);
  & > div + div {
    margin-top: 1rem;
  }
`;

const FocusCommonResult = () => {
  const graphData = useSelector(graphDataSelector);
  const type = useSelector(graphTypeSelector);

  if (
    JSON.stringify(initialGraphData[type]) === JSON.stringify(graphData[type])
  )
    return;

  return (
    <FocusCommonMainComponent isResult>
      <button>
        <CloudDownloadOutlined />
        <span>Download</span>
      </button>
      <ResultBodyWrapper>
        <FocusCommonGraphSetting />
        <FocusCommonGraphColorSetting />
        <FocusCommonGraphDisplay />
      </ResultBodyWrapper>
    </FocusCommonMainComponent>
  );
};

export default FocusCommonResult;
