import React from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { FocusCommonMainComponent } from '@components/Focus/Common/CommonElements';
import FocusCommonImportFile from '@components/Focus/Common/ImportFile';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';

const ImportFilesWrapper = styled.div`
  position: relative;
  & > div + div {
    margin-top: 1rem;
  }
  & > button {
    ${mixinList.whiteButton({
      bottom: '-48px',
      right: '0',
      fontSize: '12px',
    })}
  }
`;

const commonProps = {
  title: 'Log Files',
  align: 'flex-start',
  labelWidth: '160',
  mw: '500',
  mh: '180',
};

const FocusCommonSelectSource = ({
  subTitles,
  onStartClick,
  startDisabled,
  onChangeFile,
}) => {
  return (
    <FocusCommonMainComponent title="Select Source">
      <ImportFilesWrapper>
        <FocusCommonImportFile
          {...commonProps}
          subTitle={subTitles[0] ?? ''}
          useRequire
          onChangeFile={onChangeFile}
          type="main"
        />
        <FocusCommonImportFile
          {...commonProps}
          subTitle={subTitles[1] ?? ''}
          useRequire={false}
          onChangeFile={onChangeFile}
          type="sub"
        />
        <button onClick={onStartClick} disabled={startDisabled}>
          Load Start
        </button>
      </ImportFilesWrapper>
    </FocusCommonMainComponent>
  );
};
FocusCommonSelectSource.propTypes = {
  subTitles: PropTypes.array,
  onStartClick: PropTypes.func,
  startDisabled: PropTypes.bool,
  onChangeFile: PropTypes.func,
};

export default FocusCommonSelectSource;
