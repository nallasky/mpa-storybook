import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { UpOutlined } from '@ant-design/icons';
import {
  FocusRibbonAccordionBody,
  FocusRibbonAccordionTitle,
  FocusRibbonAccordionWrapper,
} from '@components/Focus/Common/styles/RibbonAccordionStyles';

const FocusCommonRibbonAccordion = ({ children, initialState, title }) => {
  const [collapse, setCollapse] = useState(initialState ?? false);
  return (
    <FocusRibbonAccordionWrapper>
      <FocusRibbonAccordionTitle onClick={() => setCollapse(!collapse)}>
        <span>{title}</span>
        <span className={collapse ? 'collapse' : ''}>
          <UpOutlined />
        </span>
      </FocusRibbonAccordionTitle>
      <FocusRibbonAccordionBody>
        <div className={collapse ? 'hidden' : ''}>{children}</div>
      </FocusRibbonAccordionBody>
    </FocusRibbonAccordionWrapper>
  );
};
FocusCommonRibbonAccordion.propTypes = {
  children: PropTypes.node,
  initialState: PropTypes.bool,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

export default FocusCommonRibbonAccordion;
