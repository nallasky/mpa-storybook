import { css } from '@emotion/react';

export const FocusLogStyle = css`
  & > .box-group {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-template-rows: auto;
    gap: 1rem;
    padding: 1rem;
    & > .box-group-box {
      width: 100%;
      background-color: var(--ckr-gray-1);
      border-radius: 10px;
      & .header {
        background-color: var(--ckr-cyan-2);
        height: 16px;
        border-radius: 8px 8px 0 0;
      }
      & .title-wrapper {
        padding: 1rem;
        & .label {
          padding: 0.3rem 0;
          font-size: 15px;
          font-weight: 500;
          color: var(--ckr-gray-7);
        }
        & .title {
          text-align: center;
          font-size: 18px;
          font-weight: 500;
          color: var(--ckr-blue-6);
        }
        & > .button-box {
          display: flex;
          justify-content: space-around;
          & .upload-button {
            width: 140px;
            border: 1px dashed #d9d9d9;
            border-radius: 8px;
            padding: 0 16px;
          }
          & .ant-upload-list {
            width: 140px;
            text-overflow: ellipsis;
            overflow: hidden;
            color: var(--ckr-blue-6);
          }
        }
      }
    }
  }
`;
