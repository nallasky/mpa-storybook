import { useCommonFocusLog } from '@components/Focus/hooks/useCommonFocusLog';
import {
  useDeleteFocusLogScriptFile,
  useGetFocusLogInfo,
  usePostFocusLogScriptFile,
} from '@hooks/query/focus/fousLogSetting';

const useFocusLogSetting = () => {
  const { updateFocusLogSetting, gFocusLogList } = useCommonFocusLog();
  const updateScriptFile = usePostFocusLogScriptFile();
  const deleteScriptFile = useDeleteFocusLogScriptFile();

  const getFocusLogListInfo = ({ enabled, onSettled }) =>
    useGetFocusLogInfo({
      enabled,
      onSuccess: ({ data }) => {
        updateFocusLogSetting(data);
      },
      onSettled,
    });
  return {
    gFocusLogList,
    getFocusLogListInfo,
    deleteScriptFile,
    updateScriptFile,
  };
};
export default useFocusLogSetting;
