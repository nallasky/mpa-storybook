import { useState } from 'react';
import * as SS from '@components/Focus/Log/styles/FocusLogStyle';
import { Skeleton } from 'antd';
import LogSetting from '@components/common/organisms/LogSetting';
import useFocusLogSetting from './hooks/useFocusLogSetting';

export const FocusLogSetting = () => {
  const [reLoad, setReLoad] = useState(true);
  const {
    getFocusLogListInfo,
    gFocusLogList,
    updateScriptFile,
    deleteScriptFile,
  } = useFocusLogSetting();
  const { isLoading, error, isFetching } = getFocusLogListInfo({
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });

  return (
    <div css={SS.FocusLogStyle}>
      {error ?? false ? (
        <div className="remote-setting">
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <Skeleton
          loading={isLoading || isFetching}
          active
          paragraph={{ rows: 5 }}
        >
          <div className="box-group">
            {gFocusLogList.map((logObj, i) => {
              return (
                <div className="box-group-box" key={i}>
                  <LogSetting
                    LogInfo={logObj}
                    action={{
                      delete: deleteScriptFile,
                      refresh: () => setReLoad(true),
                      add: updateScriptFile,
                    }}
                  />
                </div>
              );
            })}
          </div>
        </Skeleton>
      )}
    </div>
  );
};
