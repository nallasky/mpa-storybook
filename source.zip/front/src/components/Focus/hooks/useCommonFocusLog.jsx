import { useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  focusLogSettingSelector,
  focusLogSettingActions,
} from '@reducers/slices/FocusInfo';

export const useCommonFocusLog = () => {
  const gFocusLogList = useSelector(focusLogSettingSelector);

  const dispatch = useDispatch();

  const updateFocusLogSetting = useCallback(
    (value) => {
      dispatch(focusLogSettingActions.UpdateLogList(value));
    },
    [dispatch],
  );

  return { gFocusLogList, updateFocusLogSetting };
};
