import React, { useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import {
  fileInfoSelector,
  focusFileInfoActions,
  focusSavedGraphInfoActions,
  focusTargetInfoActions,
  initialGraphSetting,
  initialGraphScale,
  initialTargetInfoState,
} from '@reducers/slices/FocusInfo';
import {
  displayError,
  readFirstLineFromFile,
} from '@libs/util/common/functionGroup';
import {
  get_Focus_Common_Saved_Info,
  post_Focus_Temp_File_Convert,
  get_Focus_Temp_Target_Initial_Info,
  get_Focus_Temp_Lot_Id_Info,
  get_Focus_Temp_File_Convert_Status,
} from '@libs/axios/focusRequest';
import useModal from '@libs/util/modalControl/useModal';
import ProcessingModal from '@components/common/organisms/ProcessingModal/ProcessingModal';
import StatusModal from '@components/common/organisms/StatusModal/StatusModal';
import FocusCommonSelectSource from '@components/Focus/Common/SelectSource';

const titles = ['(LogServer log)', '(Status Monitor log)'];

const compareWord = 'PRSCAN';

const FocusPreScanSelectSource = () => {
  const { openModal, closeModal } = useModal();
  const { fileList } = useSelector(fileInfoSelector);
  const dispatch = useDispatch();
  const preScanFileList = fileList.prescan;
  const cancelTokenSource = useRef();

  const fileListRef = useRef({
    main: [],
    sub: [],
  });
  const patternRef = useRef({});

  const onChangeFile = async (v, type) => {
    if (v.length > fileListRef.current[type].length) {
      const uploadFileList = [];
      const currentLength = fileListRef.current[type].length;
      fileListRef.current[type] = v;

      for (const { name, originFileObj } of v.slice(currentLength)) {
        const firstLine = await readFirstLineFromFile(originFileObj);
        const word = firstLine.split(',')[1];

        if (!word) {
          continue;
        }

        if (word === compareWord) {
          uploadFileList.push({
            name,
            uid: originFileObj.uid,
            fileObj: originFileObj,
            type: 'logserver',
          });
          continue;
        }

        for (const value of Object.values(patternRef.current)) {
          const { pattern, ignore_pattern } = value;
          if (ignore_pattern.find((p) => name.indexOf(p) !== -1)) {
            break;
          }

          if (pattern.find((p) => name.indexOf(p) !== -1)) {
            uploadFileList.push({
              name,
              uid: originFileObj.uid,
              fileObj: originFileObj,
              type: 'StatusMonitor',
            });
            break;
          }
        }
      }

      if (uploadFileList.length) {
        dispatch(
          focusFileInfoActions.UpdateFileInfoSingle({
            key: 'fileList',
            value: {
              ...fileList,
              prescan: [...preScanFileList, ...uploadFileList],
            },
          }),
        );
      }
    } else if (v.length < fileListRef.current[type].length) {
      const deleteFile = fileListRef.current[type].find(
        ({ uid }) => !v.find((x) => uid === x.uid),
      );

      if (
        deleteFile &&
        preScanFileList.find(({ uid }) => uid === deleteFile.uid)
      ) {
        dispatch(
          focusFileInfoActions.UpdateFileInfoSingle({
            key: 'fileList',
            value: {
              ...fileList,
              prescan: preScanFileList.filter(
                ({ uid }) => uid !== deleteFile.uid,
              ),
            },
          }),
        );
      }
      fileListRef.current[type] = v;
    }
  };

  const setTargetInfo = async (id) => {
    cancelTokenSource.current = new AbortController();

    const { info } = await get_Focus_Temp_Target_Initial_Info(
      id,
      'prescan',
      cancelTokenSource.current.signal,
    );
    const { info: subInfo } =
      await get_Focus_Temp_Lot_Id_Info(id, 'prescan', info.period);

    dispatch(
      focusTargetInfoActions.UpdateTargetInfoAll({
        ...initialTargetInfoState,
        rid: id,
        period: info.period,
        selectedPeriod: info.period,
        job_list: subInfo.job,
        lot_id_list: subInfo.lot_id,
      }),
    );
  };

  const onLoadStart = async () => {
    try {
      const form = new FormData();
      preScanFileList.forEach(({ type, fileObj }) =>
        form.append(type, fileObj),
      );

      cancelTokenSource.current = new AbortController();
      openModal(ProcessingModal, {
        title: 'Converting',
        message: 'Converting files',
        useCancel: true,
        onCancel: () => cancelTokenSource.current.abort(),
      });

      cancelTokenSource.current = new AbortController();
      const rid = await post_Focus_Temp_File_Convert(
        form,
        cancelTokenSource.current.signal,
      );
      closeModal(ProcessingModal);
      setTimeout(() => {
        openModal(StatusModal, {
          startCallback: () => setTargetInfo(rid),
          intervalCallback: () => get_Focus_Temp_File_Convert_Status(rid),
        });
      }, 220);
    } catch (e) {
      closeModal(ProcessingModal);
      if (!axios.isCancel(e))
        displayError(e.response?.data?.msg ?? e?.message ?? e);
    }
  };

  useEffect(() => {
    const fetch = async () => {
      try {
        const { info: { log_pattern, settings } } = await get_Focus_Common_Saved_Info('prescan');
        const { graph_setting, graph_left_scale } = settings;
        dispatch(
          focusSavedGraphInfoActions.UpdateSavedGraphInfoSingle([
            {
              key: 'graph_setting',
              value: {
                ...initialGraphSetting,
                prescan: { ...graph_setting },
                type: 'prescan',
              },
            },
            {
              key: 'graph_scale',
              value: {
                ...initialGraphScale,
                graph_left_scale,
              },
            },
          ]),
        );
        patternRef.current = log_pattern;
      } catch (e) {
        displayError(e?.message ?? e);
      }
    };
    fetch();
  }, []);

  return (
    <FocusCommonSelectSource
      subTitles={titles}
      startDisabled={!preScanFileList.find(({ type }) => type === 'logserver')}
      onChangeFile={onChangeFile}
      onStartClick={onLoadStart}
    />
  );
};

export default FocusPreScanSelectSource;
