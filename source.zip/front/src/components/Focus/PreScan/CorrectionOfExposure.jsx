import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
  focusFileInfoActions,
  focusTargetInfoActions,
  focusSavedGraphInfoActions,
} from '@reducers/slices/FocusInfo';
import {
  FocusMainWrapper,
  FocusMainSettingWrapper,
} from '@components/Focus/Common/styles/CommonStyles';
import FocusPreScanSelectSource from '@components/Focus/PreScan/SelectSource';
import FocusPreScanSelectTarget from '@components/Focus/PreScan/SelectTarget';
import FocusCommonResult from '@components/Focus/Common/Result';

const FocusCorrectionOfExposureComponent = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    return () => {
      dispatch(focusFileInfoActions.resetFileInfo());
      dispatch(focusTargetInfoActions.resetTargetInfo());
      dispatch(focusSavedGraphInfoActions.resetSavedGraphInfo());
    };
  }, []);

  return (
    <FocusMainWrapper>
      <FocusMainSettingWrapper isSelect>
        <FocusPreScanSelectSource />
        <FocusPreScanSelectTarget />
      </FocusMainSettingWrapper>
      <FocusCommonResult type="prescan" />
    </FocusMainWrapper>
  );
};

export default FocusCorrectionOfExposureComponent;
