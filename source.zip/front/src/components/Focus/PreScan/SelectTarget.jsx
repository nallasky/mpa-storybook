import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import styled from '@emotion/styled';
import dayjs from 'dayjs';
import { Select } from 'antd';
import {
  targetInfoAllSelector,
  initialTargetInfoState,
  focusTargetInfoActions,
  focusSavedGraphInfoActions,
  initialGraphData,
} from '@reducers/slices/FocusInfo';
import {
  FocusCommonSelectTarget,
  FocusCommonArrowMessage,
  FocusCommonInputPeriod,
  FocusCommonInputSelect,
} from '@components/Focus/Common/CommonElements';
import {
  get_Focus_Temp_Job_And_Lot_Id_Info,
  get_Focus_Temp_Mean_Deviation_Info,
  post_Focus_Temp_Analysis_Start,
} from '@libs/axios/focusRequest';
import {
  disabledDate,
  displayError,
  RenderSelectOptions,
} from '@libs/util/common/functionGroup';
import { MeanAll } from '@components/Overlay/SelectTarget/styles/styleGroup';
import { DATE_FORMAT } from "@constants/etc";
import useModal from "@libs/util/modalControl/useModal";
import ProcessingModal from "@components/common/organisms/ProcessingModal/ProcessingModal";

const FormWrapper = styled.div`
  position: relative;
  width: 100%;
  & > div + div {
    margin-top: 3rem;
  }
`;

const labelGap = 200;

const getRandomIntInclusive = (min, max) => {
  return (
    Math.floor(Math.random() * (Math.floor(max) - Math.ceil(min) + 1)) +
    Math.ceil(min)
  );
};

const tempData = [
  {
    shot_no: 1,
    data: [
      {
        plate_no: 1,
        glass_id: '000000000000',
        msy: Array.from({ length: 15 }, (_, i) => i + 1),
        Plate_Shape_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Plate_Shape_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Plate_Shape_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Focus_Ofs_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Focus_Ofs_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Focus_Ofs_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        PreScan_Comp_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        PreScan_Comp_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        PreScan_Comp_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Prescan_Meas_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Prescan_Meas_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Prescan_Meas_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
      },
    ],
  },
  {
    shot_no: 2,
    data: [
      {
        plate_no: 1,
        glass_id: '000000000000',
        msy: Array.from({ length: 15 }, (_, i) => i + 1),
        Plate_Shape_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Plate_Shape_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Plate_Shape_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Focus_Ofs_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Focus_Ofs_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Focus_Ofs_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        PreScan_Comp_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        PreScan_Comp_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        PreScan_Comp_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Prescan_Meas_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Prescan_Meas_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Prescan_Meas_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
      },
      {
        plate_no: 2,
        glass_id: '000000000000',
        msy: Array.from({ length: 15 }, (_, i) => i + 1),
        Plate_Shape_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Plate_Shape_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Plate_Shape_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Focus_Ofs_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Focus_Ofs_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Focus_Ofs_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        PreScan_Comp_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        PreScan_Comp_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        PreScan_Comp_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Prescan_Meas_L: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Prescan_Meas_C: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
        Prescan_Meas_R: Array.from({ length: 15 }, () =>
          getRandomIntInclusive(1, 100),
        ),
      },
    ],
  },
];

export const focusPreScanTargetChangePeriod = async (v, dispatch, prevInfo) => {
  const convertPeriod = v.map((date) => dayjs(date).format(DATE_FORMAT));
  let getInfo = undefined;
  try {
    const { info } = await get_Focus_Temp_Job_And_Lot_Id_Info(prevInfo.rid, 'prescan', convertPeriod);
    getInfo = info;
  } catch (e) {
    displayError(e?.message ?? e);
  } finally {
    dispatch(
      focusTargetInfoActions.UpdateTargetInfoAll({
        ...prevInfo,
        selectedPeriod: getInfo ? convertPeriod : prevInfo.selectedPeriod.map((date) =>
          typeof date !== 'string' ? dayjs(date).format(DATE_FORMAT) : date,
        ),
        job: getInfo?.job ? '' : prevInfo.job,
        job_list: getInfo?.job ?? prevInfo.job_list,
        lot_id: getInfo?.lot_id ? [] : prevInfo.lot_id,
        lot_id_list: getInfo?.lot_id ?? prevInfo.lot_id_list,
        mean_dev_diff: [],
        mean_dev_diff_list: [],
      }),
    );
  }
};

export const focusPreScanTargetCommonChangeSelect = (dispatch, info) => {
  dispatch(focusTargetInfoActions.UpdateTargetInfoSingle(info));
};

export const focusPreScanTargetChangeLotId = async (dispatch, prevInfo, value) => {
  let meanList = undefined;
  try {
    const {
      status,
      info: { plate },
    } = await get_Focus_Temp_Mean_Deviation_Info(
      prevInfo.rid,
      'prescan',
      prevInfo.selectedPeriod,
      prevInfo.job,
      value,
    );
    meanList = plate;
  } catch (e) {
    displayError(e?.message ?? e);
  } finally {
    if (meanList) {
      dispatch(
        focusTargetInfoActions.UpdateTargetInfoSingle([
          {
            key: 'lot_id',
            value,
          },
          {
            key: 'mean_dev_diff',
            value: [],
          },
          {
            key: 'mean_dev_diff_list',
            value: meanList,
          },
        ]),
      );
    } else {
      dispatch(
        focusTargetInfoActions.UpdateTargetInfoSingle({
          key: 'lot_id',
          value: prevInfo.lot_id,
        })
      );
    }
  }
};

export const focusPreScanTargetAnalysisStart = async (dispatch, currentInfo, openModalFunc, closeModalFunc) => {
  try {
    let cancelTokenSource = new AbortController();
    openModalFunc(() => cancelTokenSource.abort());

    const reqJson = {
      category: 'prescan',
      period: currentInfo.selectedPeriod.join('~'),
      rid: currentInfo.rid,
      job: currentInfo.job,
      lot_id: currentInfo.lot_id,
      mean_dev_diff: currentInfo.mean_dev_diff.map((v) => Number(v)),
    };

    cancelTokenSource = new AbortController();
    const { info } = await post_Focus_Temp_Analysis_Start(
      reqJson,
      cancelTokenSource.signal,
    );
    console.log('gtpark info', info);

    const shots = [...new Set(tempData.map(({ shot_no }) => shot_no))];
    const initialShot = shots.length ? shots[0] : '';

    dispatch(
      focusSavedGraphInfoActions.UpdateSavedGraphInfoSingle({
        key: 'graph_data',
        value: {
          ...initialGraphData,
          prescan: tempData,
        },
      }),
    );
    dispatch(
      focusSavedGraphInfoActions.UpdateSavedGraphSetting({
        key: 'prescan',
        value: {
          shots,
          selectedShot: initialShot,
        },
      }),
    );
  } catch (e) {
    if (!axios.isCancel(e))
      displayError(e.response?.data?.msg ?? e?.message ?? e);
  } finally {
    closeModalFunc();
  }
};

const FocusPreScanSelectTarget = () => {
  const { openModal, closeModal } = useModal();
  const targetInfo = useSelector(targetInfoAllSelector);
  const dispatch = useDispatch();

  if (JSON.stringify(initialTargetInfoState) === JSON.stringify(targetInfo)) {
    return <FocusCommonArrowMessage />;
  }

  return (
    <FocusCommonSelectTarget
      startDisabled={!targetInfo.lot_id}
      onStart={() => focusPreScanTargetAnalysisStart(
        dispatch,
        targetInfo,
        (cancelFunc) => {
          openModal(ProcessingModal, {
            title: 'Analyzing',
            message: 'Analyzing files',
            useCancel: true,
            onCancel: cancelFunc,
          });
        },
        () => closeModal(ProcessingModal)
      )}
    >
      <FormWrapper>
        <FocusCommonInputPeriod
          title="Period"
          labelGap={labelGap}
          periodProps={{
            style: { width: '100%' },
            value: targetInfo.selectedPeriod.map((v) => dayjs(v)),
            placeHolder: targetInfo.period.map((v) => dayjs(v).format(DATE_FORMAT)),
            onChange: (v) => focusPreScanTargetChangePeriod(v, dispatch, targetInfo),
            disabledDate: (v) => disabledDate(targetInfo.period, v),
            inputReadOnly: true,
            allowClear: false,
            showTime: true,
          }}
        />
        <FocusCommonInputSelect
          title="Job"
          labelGap={labelGap}
          selectProps={{
            value: targetInfo.job,
            onChange: (value) => focusPreScanTargetCommonChangeSelect(dispatch, [
              {
                key: 'job',
                value,
              },
              { key: 'lot_id', value: '' },
              { key: 'mean_dev_diff', value: [] },
            ]),
            "data-testid": 'focus-target-select-job'
          }}
        >
          {targetInfo.job_list.map(RenderSelectOptions)}
        </FocusCommonInputSelect>
        <FocusCommonInputSelect
          title="Lot ID"
          labelGap={labelGap}
          selectProps={{
            value: targetInfo.lot_id,
            onChange: (value) => focusPreScanTargetChangeLotId(dispatch, targetInfo, value),
          }}
        >
          {targetInfo.job &&
            Object.entries(targetInfo.lot_id_list[targetInfo.job])?.map(
              ([key, value], i) => (
                <Select.OptGroup key={i} label={key}>
                  {value.map(RenderSelectOptions)}
                </Select.OptGroup>
              ),
            )}
        </FocusCommonInputSelect>
        <FocusCommonInputSelect
          title="Mean Deviation Diff"
          selectProps={{
            mode: 'multiple',
            maxTagCount: 'responsive',
            value: targetInfo.mean_dev_diff,
            onChange: (value) => focusPreScanTargetCommonChangeSelect(dispatch, {
              key: 'mean_dev_diff',
              value,
            }),
            dropdownRender: (menu) => {
              return !targetInfo.mean_dev_diff_list.length ? menu :
                (
                  <>
                    <MeanAll>
                      <label>
                        <input
                          type="checkbox"
                          checked={
                            targetInfo.mean_dev_diff_list.length &&
                            targetInfo.mean_dev_diff.length ===
                              targetInfo.mean_dev_diff_list.length
                          }
                          onChange={(e) => focusPreScanTargetCommonChangeSelect(dispatch, {
                            key: 'mean_dev_diff',
                            value: e.target.checked ? targetInfo.mean_dev_diff_list : [],
                          })}
                        />
                        <div className="button">All</div>
                      </label>
                    </MeanAll>
                    {menu}
                  </>
                );
            },
          }}
        >
          {targetInfo.mean_dev_diff_list.map(RenderSelectOptions)}
        </FocusCommonInputSelect>
      </FormWrapper>
    </FocusCommonSelectTarget>
  );
};

export default FocusPreScanSelectTarget;
