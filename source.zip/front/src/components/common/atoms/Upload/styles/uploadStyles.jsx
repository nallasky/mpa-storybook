import { css } from '@emotion/react';

export const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column {
    grid-template-columns: 0.4fr 1fr;
  }
  &.flex-between {
    display: flex;
    justify-content: space-between;
  }
  &.etc {
    display: flex;
    justify-content: space-between;
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      &.label {
        &:not(.no-after) {
      align-self: center;
    }
    &:not(.nostar) {
      &::before {
        display: inline-block;
        color: var(--ckr-red-6);
        font-size: 14px;
        content: '*';
        margin-right: 0.3rem;
      }
    }
    &::after:not(.no-after) {
      display: inline-block;
      content: ':';
      margin-left: 3px;
    }
      }
    }
     &.label-2 {
        &::after {
          display: inline-block;
          content: ':';
        }
      }
    }
  }
  &.upload {
    & > span {
      &:first-of-type {
        align-self: start;
      }
      &:last-of-type {
        width: 100%;
        max-width: 471.9px;
        & .ant-upload-list-text {
          margin-top: 0.5rem;
          overflow: auto;
          max-height: 70px;
          &::-webkit-scrollbar {
            width: 8px;
          }
          &::-webkit-scrollbar-track {
            background-color: transparent;
          }
          &::-webkit-scrollbar-thumb {
            border-radius: 4px;
            background-color: rgba(0, 0, 0, 0.2);
          }
          &::-webkit-scrollbar-button {
            width: 0;
            height: 0;
          }
        }
      }
    }
    & .full-width {
      & > .ant-upload-select-text,
      & button {
        width: 100%;
      }
    }
  }
  & > .title {
    width: 100%;
    text-align: center;
    font-size: 20px;
  }
  & > .preset-setting {
    display: flex;
    column-gap: 1rem;
  }
  & .radio-cp-vs {
    display: grid;
    grid-template-columns: repeat(3, 18rem);
    column-gap: 1rem;
    grid-column: span 2;
  }
  & .margin-lr {
    margin: 0 1rem;
  }
  & .margin-r {
    margin-right: 1rem;
  }
  & .tx-right {
    text-align: right;
  }
  & ~ div {
    margin-top: 2rem;
    &.table-wrapper {
      margin-top: 1rem;
    }
  }

`;
