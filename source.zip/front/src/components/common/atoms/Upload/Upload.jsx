import React from 'react';
import { Button, Upload } from 'antd';
import { CloudUploadOutlined, InboxOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';

const UploadComp = ({ type, label, btnMsg, uploadProps, required }) => {
  return type === 'Drag' ? (
    <>
      <span className={'label' + (required ?? true ? ' required' : '')}>
        {label}
      </span>
      <Upload.Dragger {...uploadProps}>
        <p className="ant-upload-drag-icon">
          <InboxOutlined />
        </p>
        <p className="ant-upload-text">
          Click or drag file to this area to upload
        </p>
      </Upload.Dragger>
    </>
  ) : (
    <>
      <span className={'label' + (required ?? false ? ' required' : '')}>
        {label}
      </span>
      <Upload {...uploadProps}>
        <Button icon={<CloudUploadOutlined />}>{btnMsg}</Button>
      </Upload>
    </>
  );
};
UploadComp.propTypes = {
  type: PropTypes.string,
  label: PropTypes.string,
  btnMsg: PropTypes.string,
  uploadProps: PropTypes.object,
  required: PropTypes.bool,
};
export default UploadComp;
