import React, { Fragment } from 'react';
import { Button, Upload } from 'antd';
import { CloudUploadOutlined, InboxOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';

const UploadComp = ({ type, label, btnMsg, uploadProps, required }) => {
  return type === 'Drag' ? (
    <Fragment>
      <span
        className={'label no-after' + (required ?? true ? ' required' : '')}
      >
        {label ?? ''}
      </span>
      <Upload.Dragger {...uploadProps}>
        <p className="ant-upload-drag-icon">
          <InboxOutlined />
        </p>
        <p className="ant-upload-text">
          Click or drag file to this area to upload
        </p>
      </Upload.Dragger>
    </Fragment>
  ) : (
    <Fragment>
      {label && (
        <span className={'label' + (required ?? false ? ' required' : '')}>
          {label}
        </span>
      )}
      <Upload {...uploadProps}>
        <Button className="upload-button" icon={<CloudUploadOutlined />}>
          {btnMsg}
        </Button>
      </Upload>
    </Fragment>
  );
};
UploadComp.propTypes = {
  type: PropTypes.string,
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  btnMsg: PropTypes.string,
  uploadProps: PropTypes.object,
  required: PropTypes.bool,
};
export default UploadComp;
