import React from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';

const FormCard = ({ title, children, formStyle, titleStyle }) => {
  return (
    <div css={[formMainStyle, formStyle]}>
      <div css={[formTitleStyle, titleStyle]}>{title}</div>
      {children}
    </div>
  );
};

FormCard.displayName = 'FormCard';
FormCard.propTypes = {
  title: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.node,
  ]),
  children: PropTypes.node.isRequired,
  formStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  titleStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};
FormCard.defaultProps = {
  title: '',
};

const formMainStyle = css`
  padding: 1rem;
  background: var(--ckr-geekblue-1);
`;

const formTitleStyle = css`
  color: var(--ckr-blue-6);
  font-weight: 600;
  margin-bottom: 1em;
  font-size: 16px;
}
`;

export default FormCard;
