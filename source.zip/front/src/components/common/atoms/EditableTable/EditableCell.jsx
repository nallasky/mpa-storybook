import React, { useContext, useEffect, useRef, useState } from 'react';
import { Form, Input, Select } from 'antd';
import PropTypes from 'prop-types';
const { Option } = Select;

import { EditableContext } from './EditableRow';
import { getParseJsonData } from '../../../../libs/util/util';
import { TACT_SET_DATA } from '../../../../constants/TactDefault';
const checkType = (c) =>
  ['true', 'false'].includes(c.toLowerCase()) ? JSON.parse(c) : c;

const EditableCell = ({
  title,
  editable,
  editType,
  children,
  dataIndex,
  record,
  handleSave,
  selectList,
  validator,
  ...restProps
}) => {
  const [editing, setEditing] = useState(false);
  const inputRef = useRef(null);
  const form = useContext(EditableContext);
  useEffect(() => {
    if (editing) {
      if (editType === 'input') inputRef.current.focus();
    }
  }, [editing]);
  const toggleEdit = () => {
    setEditing(!editing);
    form.setFieldsValue({
      [dataIndex]: record[dataIndex],
    });
  };

  const save = async () => {
    try {
      const values = await form.validateFields();
      toggleEdit();
      handleSave({ ...record, ...values });
    } catch (errInfo) {
      console.log('Save failed:', errInfo);
    }
  };
  const selectSave = async (v) => {
    form.setFieldsValue({ [dataIndex]: v });
    try {
      const values = await form.validateFields();
      toggleEdit();
      handleSave({ ...record, ...values });
    } catch (errInfo) {
      console.log('Save failed:', errInfo);
    }
  };

  let childNode = children;
  if (editable) {
    childNode = editing ? (
      <Form.Item
        style={{
          margin: 0,
        }}
        name={dataIndex}
        validateTrigger={['onChange']}
        rules={[
          {
            required: true,
            message: `${title} is required.`,
          },
          {
            validator: async (_, value) => {
              if (
                typeof value === 'string' &&
                (validator.duplicatedCell ?? []).includes(
                  (value ?? '').toLowerCase(),
                )
              ) {
                return Promise.reject(new Error(`duplicated ${title} !!`));
              } else if (validator.sameCell === value) {
                const name =
                  dataIndex === TACT_SET_DATA.TACT_SET_EVENT_START
                    ? 'End'
                    : 'Start';
                return Promise.reject(
                  new Error(`[${value}] is same ${name} name!!`),
                );
              }
            },
          },
        ]}
      >
        {editType === 'input' ? (
          <Input ref={inputRef} onPressEnter={save} onBlur={save} />
        ) : editType === 'select' ? (
          <>
            <Select
              defaultOpen={true}
              value={record[dataIndex]}
              onChange={selectSave}
              onBlur={save}
            >
              {Array.isArray(selectList)
                ? selectList?.map((d) => (
                    <Option key={d} value={d}>
                      {d}
                    </Option>
                  )) ?? <></>
                : getParseJsonData(selectList).map((d) => (
                    <Option key={d.value} value={checkType(d.id)}>
                      {d.value}
                    </Option>
                  ))}
            </Select>
          </>
        ) : (
          <></>
        )}
      </Form.Item>
    ) : (
      <div
        className="editable-cell-value-wrap"
        style={{
          paddingRight: 24,
        }}
        onClick={toggleEdit}
        onKeyPress={toggleEdit}
        role="button"
        tabIndex={0}
      >
        {children}
      </div>
    );
  }

  return <td {...restProps}>{childNode}</td>;
};
EditableCell.propTypes = {
  title: PropTypes.string,
  editable: PropTypes.bool,
  editType: PropTypes.string,
  children: PropTypes.array,
  dataIndex: PropTypes.string,
  record: PropTypes.object,
  handleSave: PropTypes.func,
  selectList: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  validator: PropTypes.object,
};

export default EditableCell;
