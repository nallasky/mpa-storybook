export { default } from './Divider';
