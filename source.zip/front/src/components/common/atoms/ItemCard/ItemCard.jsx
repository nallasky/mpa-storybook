import React from 'react';
import PropTypes from 'prop-types';
import { EditFilled, DeleteFilled, CopyOutlined } from '@ant-design/icons';
import styled from '@emotion/styled';
import { Popconfirm } from 'antd';
import { MSG_CONFIRM_DELETE } from '@constants/Message';

const Item = styled.div`
  display: flex;
  align-items: center;
  column-gap: 1rem;
  padding: 1rem;
  background-color: var(--ckr-gray-1);
  flex-basis: 32%;
  border-radius: 4px;
  background-image: linear-gradient(
    120deg,
    transparent 0%,
    transparent 50%,
    var(--ckr-blue-1) 50%
  );
  background-size: 230%;
  min-width: 450px;
  transition: all 0.5s;
  & > .icon {
    color: var(--ckr-blue-8);
    padding: 0.5rem 1rem;
    background-color: #ecedf2;
    border-radius: 4px;
    font-size: 32px;
  }
  & > .titles-and-buttons {
    display: flex;
    align-items: center;
    justify-content: space-between;
    column-gap: 1rem;
    width: 100%;
    & > .titles {
      width: 255px;
      & > p {
        pointer-events: none;
        margin-bottom: 0;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        &.main {
          color: var(--ckr-gray-10);
          font-size: 16px;
          font-weight: 700;
        }
        &.sub {
          color: var(--ckr-gray-7);
          font-size: 12px;
        }
      }
    }
    & > .buttons {
      display: flex;
      & > button {
        padding: 0.25rem 0.5rem;
        background-color: var(--ckr-gray-1);
        border-radius: 2px;
        border: 1px dashed var(--ckr-gray-5);
        cursor: pointer;
        transition: all 0.2s;
        outline: none;
        & + button {
          margin-left: 0.2rem;
        }
        &:disabled {
          color: var(--ckr-gray-5);
          background-color: var(--ckr-gray-3);
        }
        &:hover:not(:disabled) {
          color: var(--ckr-blue-7);
          border-color: var(--ckr-blue-7);
        }
      }
    }
  }
  &.view-mode {
    cursor: pointer;
    box-shadow: 0px 2px 4px 1px rgb(0 0 0 / 20%);
    &:hover {
      background-position: 95%;
      background-color: var(--ckr-blue-5);
    }
    &:active {
      transition: all 0.2s;
      box-shadow: none;
      transform: translateY(2px);
    }
    & > .titles-and-buttons {
      & > .titles {
        width: 100%;
        max-width: 307px;
      }
      & > .buttons {
        display: none;
      }
    }
  }
`;

const ItemCard = ({
  icon,
  title,
  subTitle,
  onContent,
  onEdit,
  onDelete,
  viewMode,
}) => {
  return (
    <Item className={viewMode ? 'view-mode' : ''} onClick={onContent}>
      <div className="icon">{icon}</div>
      <div className="titles-and-buttons">
        <div className="titles">
          <p className="main">{title}</p>
          {subTitle && <p className="sub">LogName: {subTitle}</p>}
        </div>
        {onEdit && onDelete && !viewMode && (
          <div className="buttons">
            <button onClick={onEdit}>
              <EditFilled />
            </button>
            <Popconfirm title={MSG_CONFIRM_DELETE} onConfirm={onDelete}>
              <button>
                <DeleteFilled />
              </button>
            </Popconfirm>
          </div>
        )}
      </div>
    </Item>
  );
};

ItemCard.displayName = 'ItemCard';
ItemCard.propTypes = {
  icon: PropTypes.node,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  subTitle: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  onContent: PropTypes.func,
  onEdit: PropTypes.func,
  onDelete: PropTypes.func,
  viewMode: PropTypes.bool,
};
ItemCard.defaultProps = {
  icon: <CopyOutlined />,
};

export default ItemCard;
