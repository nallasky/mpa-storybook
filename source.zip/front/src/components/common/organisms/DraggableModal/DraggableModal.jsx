import React, { useState } from 'react';
import { Modal, Button } from 'antd';
import PropTypes from 'prop-types';
import Draggable from 'react-draggable';

const initialPositionInfo = {
  x: 0,
  y: 0,
};

const DraggableModal = ({
  children,
  className,
  title,
  titleStyle,
  visible,
  cancelHandler,
  okHandler,
  footer,
  width,
  okText,
  cancelText,
  maskClosable,
  centered,
  closable,
  bodyStyle,
}) => {
  const [isDisable, setIsDisable] = useState(true);
  const [positionInfo, setPositionInfo] = useState(initialPositionInfo);

  const onDrag = (_, data) => {
    setPositionInfo({
      x: positionInfo.x + data.deltaX,
      y: positionInfo.y + data.deltaY,
    });
  };

  return (
    <Modal
      wrapClassName={className}
      title={
        <div
          style={{
            width: width ? `${width - 48}px` : '472px',
            cursor: 'move',
            minHeight: '24px',
            overflow: 'hidden',
            whiteSpace: 'pre',
            textOverflow: 'ellipsis',
            ...titleStyle,
          }}
          onMouseOver={() => {
            if (isDisable) {
              setIsDisable(false);
            }
          }}
          onMouseOut={() => setIsDisable(true)}
          onFocus={() => {}}
          onBlur={() => {}}
        >
          {title}
        </div>
      }
      visible={visible}
      onCancel={() => {
        if (cancelHandler) {
          cancelHandler();
        }
      }}
      onOk={() => {
        if (okHandler) {
          okHandler();
        }
      }}
      okText={okText}
      cancelText={cancelText}
      footer={
        footer === 'default'
          ? [
              <Button key="close" onClick={() => cancelHandler()}>
                {cancelText ? cancelText : 'Cancel'}
              </Button>,
              <Button key="ok" type="primary" onClick={() => okHandler()}>
                {okText ? okText : 'OK'}
              </Button>,
            ]
          : footer
      }
      width={width ?? 520}
      afterClose={() => setPositionInfo(initialPositionInfo)}
      modalRender={(modal) => (
        <Draggable
          disabled={isDisable}
          onDrag={(e, data) => onDrag(e, data)}
          position={positionInfo}
        >
          {modal}
        </Draggable>
      )}
      destroyOnClose
      maskClosable={maskClosable}
      centered={centered}
      closable={closable}
      bodyStyle={bodyStyle}
    >
      {children}
    </Modal>
  );
};

DraggableModal.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  title: PropTypes.node,
  titleStyle: PropTypes.object,
  visible: PropTypes.bool,
  cancelHandler: PropTypes.func,
  okHandler: PropTypes.func,
  footer: PropTypes.node,
  width: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  okText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  cancelText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  maskClosable: PropTypes.bool,
  centered: PropTypes.bool,
  closable: PropTypes.bool,
  bodyStyle: PropTypes.object,
};
DraggableModal.defaultProps = {
  className: '',
  title: 'Draggable Modal',
  titleStyle: {},
  visible: true,
  maskClosable: true,
  centered: false,
  closable: true,
  bodyStyle: {},
};

export default DraggableModal;
