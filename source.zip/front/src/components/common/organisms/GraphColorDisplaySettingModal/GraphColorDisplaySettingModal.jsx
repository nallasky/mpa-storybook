import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Panel as ColorPickerPanel } from 'rc-color-picker';
import { BulbOutlined, CheckOutlined } from '@ant-design/icons';
import { convertAndSortDataObjectToArray } from '@libs/util/common/functionGroup';
import { Common } from '@assets/locale/en';
import {
  AlertWrapper,
  ColorFooterWrapper,
  ColorContentItem,
  ColorContentWrapper,
} from '@components/common/organisms/GraphColorDisplaySettingModal/styles/styles';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';

const GraphColorDisplaySettingModal = ({ data, onClose, saveCallback }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [savedInnerValues, setSavedInnerValues] = useState(data);
  const [currentSelected, setCurrentSelected] = useState(
    convertAndSortDataObjectToArray(data)[0][0],
  );

  const onChangeCheckBox = (key, v) => {
    setSavedInnerValues((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        display: v ? 'true' : 'false',
      },
    }));
  };

  const onButtonClick = (v) => {
    if (v === currentSelected) return;
    setCurrentSelected(v);
  };

  const onColorPanelChange = (v) => {
    if (!currentSelected) return;
    setSavedInnerValues((prev) => ({
      ...prev,
      [currentSelected]: {
        ...prev[currentSelected],
        color: v,
      },
    }));
  };

  const onApply = () => {
    closeModal();
    if (JSON.stringify(data) !== JSON.stringify(savedInnerValues)) {
      setTimeout(() => {
        saveCallback(savedInnerValues);
      }, 250);
    }
  };

  const closeModal = () => {
    setIsVisible(false);
    onClose();
  };

  return (
    <DraggableModal
      visible={isVisible}
      bodyStyle={{ padding: '0 0 0.5rem 0' }}
      title={Common.Graph.label}
      cancelHandler={closeModal}
      footer={
        <ColorFooterWrapper>
          <button className="cancel" onClick={closeModal}>
            Cancel
          </button>
          <button className="apply" onClick={onApply}>
            Apply
          </button>
        </ColorFooterWrapper>
      }
    >
      <AlertWrapper>
        <BulbOutlined />
        <span>{Common.Graph.modal_msssage}</span>
      </AlertWrapper>
      <ColorContentWrapper>
        <div>
          {convertAndSortDataObjectToArray(data).map(([key]) => (
            <ColorItem
              key={key}
              isSelected={currentSelected === key}
              id={key}
              data={savedInnerValues[key]}
              onButtonClick={onButtonClick}
              onChangeCheckBox={onChangeCheckBox}
            />
          ))}
        </div>
        <div>
          <ColorPickerPanel
            enableAlpha={false}
            color={savedInnerValues[currentSelected].color}
            onChange={({ color }) => onColorPanelChange(color)}
            mode="RGB"
          />
        </div>
      </ColorContentWrapper>
    </DraggableModal>
  );
};
GraphColorDisplaySettingModal.propTypes = {
  data: PropTypes.object,
  onClose: PropTypes.func,
  saveCallback: PropTypes.func,
};

const ColorItem = React.memo(
  ({ isSelected, id, data, onButtonClick, onChangeCheckBox }) => {
    return (
      <ColorContentItem
        buttonBgColor={data.color}
        isSelected={isSelected}
        onClick={() => onButtonClick(id)}
      >
        <div>
          <div className="color-display-box" />
          {Object.hasOwn(data, 'display') && (
            <label>
              <input
                type="checkbox"
                checked={data.display === 'true'}
                onChange={(e) => onChangeCheckBox(id, e.target.checked)}
              />
              <div>
                <CheckOutlined />
              </div>
            </label>
          )}
        </div>
        <div>
          <p title={id}>{id}</p>
          <p className="sub">{data.color}</p>
        </div>
      </ColorContentItem>
    );
  },
  (prev, next) => {
    return (
      prev.isSelected === next.isSelected &&
      JSON.stringify(prev.data) === JSON.stringify(next.data)
    );
  },
);
ColorItem.propTypes = {
  isSelected: PropTypes.bool,
  id: PropTypes.string,
  data: PropTypes.object,
  onButtonClick: PropTypes.func,
  onChangeCheckBox: PropTypes.func,
};
ColorItem.displayName = 'ColorItem';

export default GraphColorDisplaySettingModal;
