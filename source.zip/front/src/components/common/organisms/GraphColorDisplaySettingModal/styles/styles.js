import styled from '@emotion/styled';
import { mixinList } from '@components/Focus/Common/styles/CommonStyles';

export const AlertWrapper = styled.div`
  padding: 0.5rem 1.5rem;
  background-color: #e6f7ff;
  ${mixinList.flex({ align: 'center' })}
  column-gap: 0.5rem;
  margin-bottom: 0.5rem;
  & > span {
    &:first-of-type {
      font-size: 18px;
      color: var(--ckr-blue-6);
    }
    &:last-of-type {
      color: #0050b3;
    }
  }
`;

export const ColorFooterWrapper = styled.div`
  display: flex;
  column-gap: 4px;
  & > button {
    position: relative;
    width: 100%;
    outline: none;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    transition: all 0.2s;
    &.cancel {
      border: 1px solid #efefef;
      background-color: white;
      color: #262626;
      &::before {
        box-shadow: 0px 2px 2px 0px rgba(0, 0, 0, 0.15);
      }
    }
    &.apply {
      border: 1px solid #1890ff;
      background-color: #1890ff;
      color: white;
      &::before {
        box-shadow: 0px 2px 2px 0px #91d5ff;
      }
    }
    &::before {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      content: '';
      border-radius: 4px;
      transition: all 0.2s;
    }
    &:active:not(:disabled) {
      transform: translateY(2px);
      &::before {
        opacity: 0;
      }
    }
  }
`;

export const ColorContentWrapper = styled.div`
  display: flex;
  padding: 0 1rem;
  & > div {
    width: 100%;
    &:first-of-type {
      max-height: calc(46.84px * 5 + 2rem + 1px);
      overflow: auto;
      padding-right: 6px;
      ${mixinList.customScroll({
        width: '6px',
        height: '6px',
        radius: '0px',
        bgColor: '#91d5ff',
      })}
    }
    &:last-of-type {
      ${mixinList.flex({ align: 'center', justify: 'flex-end' })}
    }
  }
`;

export const ColorContentItem = styled.button`
  ${mixinList.flex({ align: 'center' })}
  column-gap: 8px;
  border-radius: 12px;
  background-color: transparent;
  transition: all 0.2s;
  outline: none;
  border: 2px dashed transparent;
  ${(props) => props.isSelected && 'border-color: var(--ckr-blue-6);'}
  padding: 0.5rem;
  width: 100%;
  text-align: left;
  cursor: pointer;
  & + button {
    margin-top: 0.5rem;
  }
  & > div {
    position: relative;
    &:first-of-type {
      & > .color-display-box {
        border: 1px solid ${(props) => props.buttonBgColor};
        height: 40px;
        width: 40px;
        background-color: ${(props) => props.buttonBgColor};
        border-radius: 10px;
      }
      & > label {
        cursor: pointer;
        & > input {
          display: none;
          &:checked + div {
            border-color: var(--ckr-blue-6);
            background-color: var(--ckr-blue-6);
            & path {
              stroke: white;
            }
          }
        }
        & > div {
          position: absolute;
          ${mixinList.flex({ align: 'center', justify: 'center' })}
          font-size: 10px;
          color: transparent;
          top: 0;
          left: 0;
          width: 16px;
          height: 16px;
          background-color: #f5f5f5;
          border: 1px solid #d9d9d9;
          border-radius: 2px;
          transition: all 0.2s;
          & path {
            transition: all 0.2s;
            stroke: transparent;
            stroke-width: 80px;
          }
        }
      }
    }
    & > p {
      max-width: 172px;
      white-space: pre;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-bottom: 0;
      font-weight: bold;
      user-select: none;
      &.sub {
        color: #262626;
        font-weight: normal;
        font-size: 12px;
      }
    }
  }
`;
