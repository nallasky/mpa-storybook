import React from 'react';
import PropTypes from 'prop-types';
import dayjs from 'dayjs';
import Plotly from 'plotly.js-dist';
import { GraphDateRegex, GraphRangeRegex } from '../../../../libs/util/regExp';
import { compareErrorCheck } from '../GraphAddEdit/functionGroup';

const disableY = (id, data) => {
  let isDisable = true,
    i = 0;

  while (i < data.length) {
    if (!isNaN(parseInt(data[i][id])) && !GraphDateRegex.test(data[i][id])) {
      isDisable = false;
      break;
    }
    i++;
  }
  return isDisable;
};

export const renderGraph = (axisInfo, layoutInfo) => {
  const axisResult = [];
  let commonLayout = {
    font: {
      family: "Saira, 'Nunito Sans'",
    },
    title: 'Quick View Graph',
    xaxis: {
      range: [
        typeof layoutInfo.rangeX.min !== 'string' &&
        typeof layoutInfo.rangeX.min !== 'number'
          ? dayjs(layoutInfo.rangeX.min).format('YYYY-MM-DD HH:mm:ss')
          : layoutInfo.rangeX.min,
        typeof layoutInfo.rangeX.max !== 'string' &&
        typeof layoutInfo.rangeX.max !== 'number'
          ? dayjs(layoutInfo.rangeX.max).format('YYYY-MM-DD HH:mm:ss')
          : layoutInfo.rangeX.max,
      ],
    },
    yaxis: {
      range: [layoutInfo.rangeY.min, layoutInfo.rangeY.max],
    },
    height: 600,
  };

  layoutInfo.type.forEach((v) => {
    axisInfo
      .filter((v) => typeof v === 'object')
      .forEach((x) => {
        let dataObj = {};
        if (v === 'scatter' || v === 'bar') {
          dataObj = {
            ...x,
            type: v,
          };
        } else if (v === 'dot-plot') {
          dataObj = {
            x: x.y,
            y: x.x,
            mode: 'markers',
            name: x.name,
            marker: {
              size: 8,
            },
          };
        } else if (v === 'box') {
          dataObj = {
            y: x.y,
            name: x.name,
            type: v,
          };
        } else {
          dataObj = {
            ...x,
            mode: 'markers',
            type: 'scatter',
          };
        }
        axisResult.push(dataObj);

        if (v === 'density') {
          axisResult.push({
            ...x,
            ncontours: 20,
            colorscale: 'Blues',
            reversescale: true,
            showscale: false,
            type: 'histogram2dcontour',
          });
        }
      });

    if (v === 'bar' || v === 'line') {
      commonLayout = {
        ...commonLayout,
        xaxis: {
          ...commonLayout.xaxis,
          title: axisInfo[0],
        },
      };
    } else if (v === 'dot-plot') {
      commonLayout = {
        ...commonLayout,
        xaxis: {
          ...commonLayout.xaxis,
          showgrid: false,
          showline: true,
          autotick: true,
          ticks: 'outside',
        },
        yaxis: {
          ...commonLayout.yaxis,
          title: axisInfo[0],
        },
        hovermode: 'closest',
        margin: {
          l: 140,
          r: 40,
        },
      };
    } else if (v === 'density') {
      commonLayout = {
        ...commonLayout,
        xaxis: {
          ...commonLayout.xaxis,
          showgrid: false,
          zeroline: false,
        },
        yaxis: {
          ...commonLayout.yaxis,
          showgrid: false,
          zeroline: false,
        },
        hovermode: 'closest',
        bargap: 0,
      };
    }
  });

  const elements = document.getElementById('quick-view-graph');
  elements.childNodes[0]?.remove();
  Plotly.newPlot(elements, axisResult, commonLayout);
};

export const QuickViewTableColumn = ({
  changeFunc,
  columnData,
  errorList,
  rowData,
  disableX,
  ...rest
}) => {
  const changeCheck = (key) => {
    changeFunc(
      columnData.map((column) => ({
        ...column,
        selected: {
          x:
            key === 'y'
              ? column.selected.x
              : column.id === rest.id && key === 'x' && !rest.selected.x,
          y:
            column.id === rest.id && key === 'y'
              ? !rest.selected.y
              : column.selected.y,
        },
      })),
      key === 'x' ? rest.id : undefined,
    );
  };

  const changeTitle = (v) => {
    changeFunc(
      columnData.map((column) =>
        column.id !== rest.id ? column : { ...column, name: v },
      ),
    );
  };

  return (
    <th
      className={
        errorList.find((v) => v === rest.id)
          ? 'column-error'
          : disableX && disableY(rest.id, rowData)
          ? ' disable'
          : ''
      }
    >
      <div className="custom-column">
        <div className="dropdown-wrapper">
          <div
            className={
              'dropdown-trigger' +
              (disableX && disableY(rest.id, rowData) ? ' disable' : '')
            }
          >
            {rest.selected.x ? <div className="option-x">X</div> : ''}
            {rest.selected.y && !disableY(rest.id, rowData) ? (
              <div className="option-y">Y</div>
            ) : (
              ''
            )}
            {(!rest.selected.x || disableX) && !rest.selected.y ? (
              <div className="option-none">-</div>
            ) : (
              ''
            )}
          </div>
          <div className="custom-dropdown">
            <label htmlFor={`option-x-${rest.id}`}>
              <input
                type="checkbox"
                id={`option-x-${rest.id}`}
                checked={rest.selected.x}
                onChange={() => changeCheck('x')}
                disabled={disableX}
              />
              <div className="check-x">X</div>
            </label>
            <label htmlFor={`option-y-${rest.id}`}>
              <input
                type="checkbox"
                id={`option-y-${rest.id}`}
                checked={rest.selected.y}
                onChange={() => changeCheck('y')}
                disabled={disableY(rest.id, rowData)}
              />
              <div className="check-y">Y</div>
            </label>
          </div>
        </div>
        <input
          type="text"
          value={rest.name}
          onChange={(e) => changeTitle(e.target.value)}
          disabled={disableX && disableY(rest.id, rowData)}
        />
      </div>
    </th>
  );
};
QuickViewTableColumn.propTypes = {
  changeFunc: PropTypes.func.isRequired,
  columnData: PropTypes.array.isRequired,
  errorList: PropTypes.array.isRequired,
  rowData: PropTypes.array.isRequired,
  disableX: PropTypes.bool.isRequired,
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  name: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  selected: PropTypes.object.isRequired,
};

export const errorCheck = (columns, graphOptions, startLine, rowData) => {
  const result = [];
  const onlyBox = graphOptions.type[0] === 'box';

  const disableColumnCheck = (id, key) => {
    return key === 'all'
      ? onlyBox && disableY(id, rowData)
      : disableY(id, rowData);
  };

  if (graphOptions.type.length === 0) result.push('type');

  if (!onlyBox) {
    if (
      typeof graphOptions.rangeX.min !== 'object' &&
      (!GraphRangeRegex.test(graphOptions.rangeX.min) ||
        compareErrorCheck(graphOptions.rangeX.min, graphOptions.rangeX.max))
    )
      result.push('minX');

    if (
      typeof graphOptions.rangeX.max !== 'object' &&
      (!GraphRangeRegex.test(graphOptions.rangeX.max) ||
        compareErrorCheck(graphOptions.rangeX.min, graphOptions.rangeX.max))
    )
      result.push('maxX');
  }

  if (
    !GraphRangeRegex.test(graphOptions.rangeY.min) ||
    compareErrorCheck(graphOptions.rangeY.min, graphOptions.rangeY.max)
  )
    result.push('minY');

  if (
    !GraphRangeRegex.test(graphOptions.rangeY.max) ||
    compareErrorCheck(graphOptions.rangeY.min, graphOptions.rangeY.max)
  )
    result.push('maxY');

  if (startLine === '') result.push('radio');

  const selectedX = columns.filter((v) => v.selected.x).length;
  columns.forEach((v) => {
    if (
      !disableColumnCheck(v.id, 'all') &&
      (v.name.length === 0 ||
        columns.find(
          (x) =>
            x.id !== v.id &&
            x.name === v.name &&
            !disableColumnCheck(x.id, 'all'),
        ))
    ) {
      result.push(v.id);
    } else {
      if (selectedX > 0) {
        if (
          columns.filter((y) => y.selected.y).length === 0 &&
          !v.selected.x &&
          !disableColumnCheck(v.id, 'y')
        )
          result.push(v.id);
      } else {
        if (
          !onlyBox ||
          (onlyBox &&
            columns.filter((y) => y.selected.y).length === 0 &&
            !disableColumnCheck(v.id, 'y'))
        )
          result.push(v.id);
      }
    }
  });

  return result;
};

export const isDateType = (key, rowData) => {
  if (key) {
    let isAllDate = true,
      i = 0;

    while (i < rowData.length) {
      if (!GraphDateRegex.test(rowData[i][key])) {
        isAllDate = false;
        break;
      }
      i++;
    }

    return isAllDate;
  } else {
    return false;
  }
};

export const createGraphData = (xaxis, yaxis, rows) => {
  return yaxis.reduce(
    (acc, v) => {
      acc.push({
        name: v.name,
        x: xaxis ? rows.map((x) => x[xaxis.id]) : [],
        y: rows.map((x) => x[v.id]),
      });
      return acc;
    },
    [xaxis ? xaxis.name : ''],
  );
};

export const createColumns = (sampleRow) => {
  return Object.keys(sampleRow).reduce((acc, v) => {
    acc.push({
      id: v,
      name: v,
      selected: {
        x: false,
        y: false,
      },
    });
    return acc;
  }, []);
};

export const createRows = (rows) => {
  return Object.values(rows).reduce((acc, v, i) => {
    acc.push({
      ...v,
      uniqueId: `${i}`,
    });
    return acc;
  }, []);
};
