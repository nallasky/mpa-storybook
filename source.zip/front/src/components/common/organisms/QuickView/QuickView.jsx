import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { Upload, InputNumber, Input, Select, Empty, DatePicker } from 'antd';
import {
  InboxOutlined,
  DoubleLeftOutlined,
  LeftOutlined,
  RightOutlined,
  DoubleRightOutlined,
  CloseOutlined,
} from '@ant-design/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTable, faSearch } from '@fortawesome/free-solid-svg-icons';
import CustomAccordion from '../../molecules/CustomAccordion/CustomAccodion';
import { postRequestFormData } from '../../../../libs/axios/requests';
import { URL_PREVIEW_SAMPLELOG } from '../../../../constants/URL';
import { displayNotification } from '../../../JobAnalysis/functionGroup';
import {
  renderGraph,
  QuickViewTableColumn,
  errorCheck,
  isDateType,
  createGraphData,
  createColumns,
  createRows,
} from './functionGroup';
import * as SG from './styleGroup';
import {
  Contents,
  Spinner,
} from '../../../Overlay/Fragments/ProcessingModal/styleGroup';

const QuickView = ({ closer }) => {
  const [logFile, setLogFile] = useState(undefined);
  const [graphOptions, setGraphOptions] = useState({
    type: ['bar'],
    rangeX: {
      min: '',
      max: '',
    },
    rangeY: {
      min: '',
      max: '',
    },
  });
  const [tableOptions, setTableOptions] = useState({
    currentPage: 1,
    startLine: '',
    searchText: '',
  });
  const [errorList, setErrorList] = useState([]);
  const [originRowData, setOriginRowData] = useState([]);
  const [columnData, setColumnData] = useState([]);
  const [rowData, setRowData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const timeout = useRef(null);

  const changeRange = (v, pKey, cKey) => {
    if (Array.isArray(v)) {
      setGraphOptions({
        ...graphOptions,
        rangeX: {
          min: v[0],
          max: v[1],
        },
      });
    } else {
      setGraphOptions({
        ...graphOptions,
        [pKey]: {
          ...graphOptions[pKey],
          [cKey]: v,
        },
      });
    }
    clearTimeout(timeout.current);
  };

  const changeType = (v) => {
    const newType =
      v[v.length - 1] === 'box' ? ['box'] : v.filter((x) => x !== 'box');
    setGraphOptions({
      ...graphOptions,
      type: newType,
      rangeX:
        newType[0] === 'box' && typeof graphOptions.rangeX.min === 'object'
          ? {
              min: '',
              max: '',
            }
          : graphOptions.rangeX,
    });
    if (newType[0] === 'box') {
      setColumnData(
        columnData.map((x) => ({
          ...x,
          selected: { ...x.selected, x: false },
        })),
      );
    }
    clearTimeout(timeout.current);
  };

  const changeColumn = (data, id) => {
    if (
      id &&
      isDateType(
        columnData.find((v) => v.selected.x)?.id,
        tableOptions.startLine === ''
          ? originRowData
          : originRowData.filter((v) => v.uniqueId >= tableOptions.startLine),
      ) !==
        isDateType(
          id,
          tableOptions.startLine === ''
            ? originRowData
            : originRowData.filter((v) => v.uniqueId >= tableOptions.startLine),
        )
    ) {
      setGraphOptions({
        ...graphOptions,
        rangeX: {
          min: '',
          max: '',
        },
      });
    }
    setColumnData(data);
    clearTimeout(timeout.current);
  };

  const changeStartLine = (v) => {
    setTableOptions({
      ...tableOptions,
      startLine: v,
    });
    clearTimeout(timeout.current);
  };

  const searchData = () => {
    const newRowData =
      tableOptions.searchText.length > 0
        ? originRowData.filter(
            (row) =>
              Object.values(row).filter(
                (v) =>
                  v !== null && v.toString().includes(tableOptions.searchText),
              ).length > 0,
          )
        : originRowData;

    setRowData(newRowData);
    setTableOptions({
      ...tableOptions,
      currentPage: newRowData.length > 0 ? 1 : null,
    });
  };

  useEffect(() => {
    let timer;
    if (logFile) {
      const postLogParse = async () => {
        const formData = new FormData();
        formData.append('files', logFile);
        formData.append('source', 'local');
        const { status, info } = await postRequestFormData(
          URL_PREVIEW_SAMPLELOG,
          formData,
        );
        return {
          status: status,
          info: info,
        };
      };
      let errorMsg = undefined;
      setIsLoading(true);
      postLogParse()
        .then((data) => {
          const newRows = createRows(data.info.data.row);
          setOriginRowData(newRows);
          setColumnData(createColumns(Object.values(data.info.data.row)[0]));
          setRowData(newRows);
        })
        .catch((e) => (errorMsg = e.response.data.msg))
        .finally(
          () =>
            (timer = setTimeout(() => {
              setIsLoading(false);
              displayNotification({
                message: errorMsg ? 'Error occurred' : 'Analysis Success',
                description: errorMsg ?? 'The analysis was successful.',
                duration: 3,
                style: errorMsg
                  ? { borderLeft: '5px solid red' }
                  : { borderLeft: '5px solid green' },
              });
            }, 3000)),
        );
    }

    return () => {
      clearTimeout(timer);
      return null;
    };
  }, [logFile]);

  useEffect(() => {
    if (originRowData.length > 0 && columnData.length > 0) {
      setErrorList([]);
      timeout.current = setTimeout(() => {
        const eList = errorCheck(
          columnData,
          graphOptions,
          tableOptions.startLine,
          tableOptions.startLine === ''
            ? originRowData
            : originRowData.filter((v) => v.uniqueId >= tableOptions.startLine),
        );

        if (eList.length > 0) {
          setErrorList(eList);
        } else {
          renderGraph(
            createGraphData(
              columnData.find((v) => v.selected.x),
              columnData.filter((v) => v.selected.y),
              originRowData.filter((v) => v.uniqueId >= tableOptions.startLine),
            ),
            graphOptions,
          );
        }
      }, 3000);
    }
    return () => {
      clearTimeout(timeout.current);
      return null;
    };
  }, [graphOptions, tableOptions.startLine, columnData, originRowData]);

  return (
    <>
      <div css={SG.backgroundStyle} />
      <div css={SG.containerStyle}>
        <div className="quick-view-wrapper">
          <div className="quick-view-header">
            <span>Quick Viewer</span>
            <button onClick={closer} disabled={isLoading}>
              <CloseOutlined />
            </button>
          </div>
          <div
            className={'quick-view-contents' + (isLoading ? ' loading' : '')}
          >
            {isLoading ? (
              <Contents>
                <Spinner>
                  <div className="spinner-item" />
                  <div className="spinner-item" />
                  <div className="spinner-item" />
                  <div className="spinner-item" />
                  <div className="spinner-item" />
                </Spinner>
                <div className="message">
                  Analysing data
                  <span>.</span>
                  <span>.</span>
                  <span>.</span>
                </div>
              </Contents>
            ) : (
              <>
                <CustomAccordion
                  title="Select Source File"
                  defaultValue={false}
                  quickView
                >
                  <>
                    <div className="upload-wrapper">
                      <Upload.Dragger
                        onChange={(e) => {
                          setLogFile(
                            e.fileList.length > 0
                              ? e.fileList[0].originFileObj
                              : undefined,
                          );
                        }}
                        beforeUpload={() => false}
                        maxCount={1}
                      >
                        <p className="ant-upload-drag-icon">
                          <InboxOutlined />
                        </p>
                        <p className="ant-upload-text">
                          Click or drag file to this area to upload
                        </p>
                      </Upload.Dragger>
                    </div>
                    <div className="table-component">
                      {columnData.length > 0 ? (
                        <>
                          <div className="table-component-header">
                            <div className="page-count">
                              {rowData.length > 0 ? (
                                <>
                                  <FontAwesomeIcon icon={faTable} size="lg" />
                                  {tableOptions.currentPage !== null
                                    ? `Page ${
                                        tableOptions.currentPage
                                      } of ${Math.ceil(rowData.length / 5)}`
                                    : 'Setting up the page...'}
                                </>
                              ) : (
                                ''
                              )}
                            </div>
                            <div className="table-option">
                              <div className="change-page">
                                <span>Go to Page:</span>
                                <InputNumber
                                  min={1}
                                  max={Math.ceil(rowData.length / 5)}
                                  value={tableOptions.currentPage}
                                  onChange={(v) =>
                                    setTableOptions({
                                      ...tableOptions,
                                      currentPage: v,
                                    })
                                  }
                                />
                              </div>
                              <div className="search-table">
                                <Input
                                  type="text"
                                  value={tableOptions.searchText}
                                  onChange={(e) =>
                                    setTableOptions({
                                      ...tableOptions,
                                      searchText: e.target.value,
                                    })
                                  }
                                />
                                <button onClick={searchData}>
                                  <FontAwesomeIcon icon={faSearch} />
                                </button>
                              </div>
                            </div>
                          </div>
                          <div className="table-component-contents">
                            {rowData.length > 0 ? (
                              <>
                                <div className="table-wrapper">
                                  <table>
                                    <thead>
                                      <tr>
                                        <th
                                          className={
                                            errorList.find((v) => v === 'radio')
                                              ? 'column-error'
                                              : ''
                                          }
                                        >
                                          Start Line
                                        </th>
                                        {columnData.map((col) => (
                                          <QuickViewTableColumn
                                            key={col.id}
                                            changeFunc={changeColumn}
                                            columnData={columnData}
                                            errorList={errorList}
                                            rowData={
                                              tableOptions.startLine === ''
                                                ? originRowData
                                                : originRowData.filter(
                                                    (v) =>
                                                      v.uniqueId >=
                                                      tableOptions.startLine,
                                                  )
                                            }
                                            disableX={
                                              graphOptions.type[0] === 'box'
                                            }
                                            {...col}
                                          />
                                        ))}
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {rowData
                                        .filter(
                                          (v, i) =>
                                            i >=
                                            tableOptions.currentPage * 5 - 5,
                                        )
                                        .map((row, i) => {
                                          return i < 5 ? (
                                            <tr key={i}>
                                              <td>
                                                <label
                                                  className="radio-wrapper"
                                                  htmlFor={`radio-${row.uniqueId}`}
                                                >
                                                  <input
                                                    type="radio"
                                                    name="start-line"
                                                    id={`radio-${row.uniqueId}`}
                                                    value={row.uniqueId}
                                                    onChange={(e) =>
                                                      changeStartLine(
                                                        e.target.value,
                                                      )
                                                    }
                                                    checked={
                                                      tableOptions.startLine ===
                                                      row.uniqueId
                                                    }
                                                  />
                                                </label>
                                              </td>
                                              {Object.values(
                                                row,
                                              ).map((value, j) =>
                                                value !== row.uniqueId ? (
                                                  <td key={j}>{value}</td>
                                                ) : (
                                                  <React.Fragment key={j} />
                                                ),
                                              )}
                                            </tr>
                                          ) : (
                                            <React.Fragment key={i} />
                                          );
                                        })}
                                    </tbody>
                                  </table>
                                </div>
                                {rowData.length > 5 ? (
                                  <div className="pagination">
                                    <button
                                      onClick={() =>
                                        setTableOptions({
                                          ...tableOptions,
                                          currentPage: 1,
                                        })
                                      }
                                      disabled={tableOptions.currentPage === 1}
                                    >
                                      <DoubleLeftOutlined />
                                    </button>
                                    <button
                                      onClick={() =>
                                        setTableOptions({
                                          ...tableOptions,
                                          currentPage:
                                            tableOptions.currentPage - 1,
                                        })
                                      }
                                      disabled={tableOptions.currentPage === 1}
                                    >
                                      <LeftOutlined />
                                    </button>
                                    <button
                                      onClick={() =>
                                        setTableOptions({
                                          ...tableOptions,
                                          currentPage:
                                            tableOptions.currentPage + 1,
                                        })
                                      }
                                      disabled={
                                        tableOptions.currentPage * 5 >
                                        rowData.length - 1
                                      }
                                    >
                                      <RightOutlined />
                                    </button>
                                    <button
                                      onClick={() =>
                                        setTableOptions({
                                          ...tableOptions,
                                          currentPage: Math.ceil(
                                            rowData.length / 5,
                                          ),
                                        })
                                      }
                                      disabled={
                                        tableOptions.currentPage * 5 >
                                        rowData.length - 1
                                      }
                                    >
                                      <DoubleRightOutlined />
                                    </button>
                                  </div>
                                ) : (
                                  <></>
                                )}
                              </>
                            ) : (
                              <Empty />
                            )}
                          </div>
                        </>
                      ) : (
                        <Empty />
                      )}
                    </div>
                  </>
                </CustomAccordion>
                <div className="graph-component">
                  <div className="graph-component-header">Graph</div>
                  <div className="graph-component-contents">
                    <div className="graph-setting">
                      <div className="graph-setting-header">Setting</div>
                      <div className="graph-setting-contents">
                        <div className="graph-setting-contents-wrapper">
                          <div>
                            <span>Graph Type:</span>
                            <Select
                              mode="multiple"
                              maxTagCount="responsive"
                              value={graphOptions.type}
                              onChange={(v) => changeType(v)}
                              style={{ width: '400px' }}
                              className={
                                errorList.find((v) => v === 'type')
                                  ? 'input-error'
                                  : ''
                              }
                            >
                              <Select.Option value="bar">Bar</Select.Option>
                              <Select.Option value="scatter">
                                Line
                              </Select.Option>
                              <Select.Option value="dot-plot">
                                Dot Plot
                              </Select.Option>
                              <Select.Option value="box">
                                Box Plot
                              </Select.Option>
                              <Select.Option value="density">
                                Density Plot
                              </Select.Option>
                            </Select>
                          </div>
                          <div>
                            <span>X Range:</span>
                            <div className="input-range">
                              {isDateType(
                                columnData.find((v) => v.selected.x)?.id,
                                tableOptions.startLine === ''
                                  ? originRowData
                                  : originRowData.filter(
                                      (v) =>
                                        v.uniqueId >= tableOptions.startLine,
                                    ),
                              ) && graphOptions.type[0] !== 'box' ? (
                                <DatePicker.RangePicker
                                  showTime
                                  inputReadOnly
                                  allowClear={false}
                                  style={{ width: '507.99px' }}
                                  value={
                                    graphOptions.rangeX.min === ''
                                      ? []
                                      : [
                                          graphOptions.rangeX.min,
                                          graphOptions.rangeX.max,
                                        ]
                                  }
                                  onChange={(v) => changeRange(v)}
                                />
                              ) : (
                                <>
                                  <Input
                                    type="text"
                                    style={{ width: '250px' }}
                                    value={graphOptions.rangeX.min}
                                    onChange={(e) =>
                                      changeRange(
                                        e.target.value,
                                        'rangeX',
                                        'min',
                                      )
                                    }
                                    className={
                                      errorList.find((v) => v === 'minX')
                                        ? 'input-error'
                                        : ''
                                    }
                                  />
                                  <Input
                                    type="text"
                                    style={{ width: '250px' }}
                                    value={graphOptions.rangeX.max}
                                    onChange={(e) =>
                                      changeRange(
                                        e.target.value,
                                        'rangeX',
                                        'max',
                                      )
                                    }
                                    className={
                                      errorList.find((v) => v === 'maxX')
                                        ? 'input-error'
                                        : ''
                                    }
                                  />
                                </>
                              )}
                            </div>
                          </div>
                          <div>
                            <span>Y Range:</span>
                            <div className="input-range">
                              <Input
                                type="text"
                                style={{ width: '250px' }}
                                value={graphOptions.rangeY.min}
                                onChange={(e) =>
                                  changeRange(e.target.value, 'rangeY', 'min')
                                }
                                className={
                                  errorList.find((v) => v === 'minY')
                                    ? 'input-error'
                                    : ''
                                }
                              />
                              <Input
                                type="text"
                                style={{ width: '250px' }}
                                value={graphOptions.rangeY.max}
                                onChange={(e) =>
                                  changeRange(e.target.value, 'rangeY', 'max')
                                }
                                className={
                                  errorList.find((v) => v === 'maxY')
                                    ? 'input-error'
                                    : ''
                                }
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="graph-render" id="quick-view-graph">
                      {originRowData.length === 0 && columnData.length === 0 ? (
                        <Empty />
                      ) : (
                        ''
                      )}
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
          <div className="quick-view-footer">
            <button onClick={closer} disabled={isLoading}>
              Close
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

QuickView.propTypes = {
  closer: PropTypes.func.isRequired,
};

export default QuickView;
