import PropTypes from 'prop-types';
import { Upload } from '@components/common/atoms/Upload';
import useLogSetting from '@components/common/organisms/LogSetting/hooks/useLogSetting';
import { LogStyle } from '@components/common/organisms/LogSetting/styles/LogSettingStyles';

const LogSetting = ({ LogInfo, action }) => {
  const { log_name, func_id, preprocess, convert } = LogInfo;
  const { scriptUploadProps } = useLogSetting();

  return (
    <div css={LogStyle}>
      <div className="header" />
      <div className="title-wrapper">
        <div className="label">Log name: </div>
        <div className="title">{log_name}</div>
        <div className="label">Script file:</div>
        <div className="button-box">
          <Upload
            btnMsg={'Preprocess'}
            uploadProps={scriptUploadProps({
              type: 'preprocess',
              func_id: func_id,
              files: preprocess.file_name,
              action,
            })}
          />
          <Upload
            btnMsg={'Convert'}
            uploadProps={scriptUploadProps({
              type: 'convert',
              func_id: func_id,
              files: convert.file_name,
              action,
            })}
          />
        </div>
      </div>
    </div>
  );
};
LogSetting.propTypes = {
  LogInfo: PropTypes.object,
  action: PropTypes.object,
};
export default LogSetting;
