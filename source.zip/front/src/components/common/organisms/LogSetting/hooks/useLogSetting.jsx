import { RequestOnError } from '@libs/util/common/common';

const useLogSetting = () => {
  const scriptUploadProps = ({ type, func_id, files, action }) => ({
    name: 'files',
    action: '', //backend server
    fileList:
      files ?? false
        ? [
            {
              uid: '-1',
              name: files,
              status: 'done',
            },
          ]
        : [],
    beforeUpload: (f) => {
      action.add.mutate(
        {
          script_type: type,
          func_id,
          file: f,
        },
        {
          onSuccess: () => {
            action.refresh();
          },
          onError: RequestOnError,
        },
      );
      console.log('beforeUpload file name', f?.name);
      return false;
    },
    onRemove: (file) => {
      console.log('onRemove file name', file);
      action.delete.mutate(
        {
          script_type: type,
          func_id,
        },
        {
          onSuccess: () => {
            action.refresh();
          },
          onError: RequestOnError,
        },
      );
    },
  });

  return {
    scriptUploadProps,
  };
};
export default useLogSetting;
