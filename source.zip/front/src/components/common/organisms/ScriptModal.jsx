import React, { useState, useEffect } from 'react';
import styled from '@emotion/styled';
import PropTypes from 'prop-types';
import AceEditor from 'react-ace';
import 'ace-builds/src-min-noconflict/ext-language_tools';
import 'ace-builds/src-noconflict/mode-python';
import 'ace-builds/src-noconflict/snippets/python';
import 'ace-builds/src-noconflict/theme-tomorrow';
import pythonLogo from '@assets/python_icon.svg';
import DraggableModal from './DraggableModal/DraggableModal';

const StyledEditor = styled.div`
  margin-top: 10px;
  * {
    line-height: 1;
  }
`;

export const ScriptEdit = ({
  title,
  target,
  script,
  onChangeScript,
  editInfo,
  onClose,
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [code, setCode] = useState(script ?? '');

  const onChange = (value) => {
    setCode(value);
  };

  const onOk = () => {
    onChangeScript(
      { [target]: code || null },
      editInfo.target,
      editInfo.record,
    );
    setIsVisible(false);
  };

  useEffect(() => {
    if (!isVisible) {
      onClose();
    }
  }, [isVisible]);

  return (
    <DraggableModal
      visible={isVisible}
      title={
        <>
          <img src={pythonLogo} alt="Python Code" /> {title}
        </>
      }
      titleStyle={{ fontWeight: 'bold' }}
      okHandler={onOk}
      cancelHandler={() => {
        setCode('');
        setIsVisible(false);
      }}
      width={600}
      footer="default"
    >
      <StyledEditor>
        <AceEditor
          placeholder="Input Python Code Here!"
          mode="python"
          theme="tomorrow"
          width={'552px'}
          onChange={onChange}
          fontSize={14}
          showPrintMargin={true}
          showGutter={true}
          highlightActiveLine={true}
          value={code ?? undefined}
          setOptions={{
            enableLiveAutocompletion: true,
            enableSnippets: false,
            showLineNumbers: true,
            tabSize: 4,
          }}
          enableSnippets={true}
        />
      </StyledEditor>
    </DraggableModal>
  );
};

ScriptEdit.propTypes = {
  title: PropTypes.string,
  target: PropTypes.string,
  script: PropTypes.string,
  onChangeScript: PropTypes.func,
  editInfo: PropTypes.object,
  onClose: PropTypes.func,
};
