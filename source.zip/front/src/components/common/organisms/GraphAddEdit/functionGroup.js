import { getParseData } from '../../../../libs/util/util';
import { GraphDateRegex } from '../../../../libs/util/regExp';

export const createSampleData = (type, data, isSingle) => {
  let tmpData;
  if (type === 'step') {
    if (data?.row ?? false) {
      tmpData = Array.isArray(data.row)
        ? data.row.map((o) => getParseData(o).value?.[0] ?? {})
        : Object.values(data.row)[0];
    }
  } else {
    if (type !== 'analysis' || isSingle) {
      tmpData = Object.values(data)[0];
    } else {
      const mergeObj = {};

      Object.keys(data).forEach((v) => {
        mergeObj[v] = data[v][0] ? data[v][0] : {};
      });

      tmpData = mergeObj;
    }
  }
  return tmpData;
};

export const boxPlotExceptionCheck = (type, sampleData, key) => {
  if (type === 'step') {
    const checkData = Array.isArray(sampleData)
      ? sampleData[0][key]
      : sampleData[key];
    return GraphDateRegex.test(checkData);
  } else {
    if (type !== 'analysis' || Array.isArray(sampleData)) {
      return GraphDateRegex.test(sampleData[key]);
    } else {
      let isValid = true,
        i = 0;

      while (i < Object.keys(sampleData).length) {
        if (!GraphDateRegex.test(Object.values(sampleData)[i][key])) {
          isValid = false;
          break;
        }
        i++;
      }
      return isValid;
    }
  }
};
