import { useGetJobResource } from '@hooks/query/jobSetting';
import useJobSettingInfo from '@hooks/common/useJobSettingInfo';

export const useJobSetting = () => {
  const { setJobSettingResource } = useJobSettingInfo();
  const getJobResource = ({ func_id, enabled, source, onSettled }) =>
    useGetJobResource({
      func_id,
      enabled,
      onSuccess: ({ info }) => {
        console.log('info', info, func_id, source);
        setJobSettingResource(info, func_id, source);
      },
      onSettled,
    });

  return {
    getJobResource,
  };
};
