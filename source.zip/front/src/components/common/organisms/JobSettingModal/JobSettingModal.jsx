import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FormCard } from '../../atoms/Modal';
import PropTypes from 'prop-types';
import Button2 from '../../atoms/Button';
import { css } from '@emotion/react';
import InputForm from '../../atoms/Input/InputForm';
import { getParseData } from '@libs/util/util';
import {
  Popconfirm,
  Select,
  Spin,
  Button,
  Tabs,
  Collapse,
  Skeleton,
} from 'antd';
import { DeleteOutlined, LoadingOutlined } from '@ant-design/icons';
import DAYJS from 'dayjs';
import {
  MSG_LOCAL,
  MSG_REMOTE,
  MSG_SQL,
  MESSAGE,
  MSG_MULTI,
} from '@constants/Message';
import { E_MULTI_TYPE, R_OK } from '@constants/etc';
import { useMutation, useQuery } from 'react-query';
import { QUERY_KEY } from '@constants/QueryKey';
import {
  deleteHistoryJob,
  getResource_HistorySetting,
} from '@libs/axios/jobSettingRequest';
import DraggableModal from '../DraggableModal/DraggableModal';
import ProgressModal from '../ProgressModal';
import useJobSettingInfo from '@hooks/common/useJobSettingInfo';
import { getEquipmentList, getEquipmentValidDate } from '@libs/axios/requests';
import useModal from '@libs/util/modalControl/useModal';
import { goAnalysisPage } from '@libs/util/common/functionGroup';
import { useJobSetting } from '@components/common/organisms/JobSettingModal/hooks/useJobSetting';
import { RequestOnError } from '@libs/util/common/common';

const directoryStyle = css`
  & .ant-upload-list {
    max-height: 150px;
    overflow-y: auto;
  }
`;
const historyStyle = css`
  max-height: 750px;
  overflow: auto;
  & .ant-spin-spinning {
    display: flex;
    height: 300px;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    row-gap: 0.5rem;
    margin-top: 1rem;
  }
  & .ant-collapse {
    margin-top: 1rem;
  }
`;

const start_analysis_style = css`
  & .ant-form-item-label {
    text-align: left;
  }
  & .ant-form-item {
    margin-bottom: 10px;
  }
  & .ant-upload.ant-upload-drag {
    width: 324px;
  }
`;
const Contents = ({ options, target, defaultV, actionFunc }) => {
  const [deleteLoading, setDeleteLoading] = useState(false);
  const onClickEvent = (value, type) => {
    actionFunc({ [type]: value });
    if (type === 'DELETE_HISTORY') {
      setDeleteLoading(true);
    }
  };
  useEffect(() => {
    if (deleteLoading) setDeleteLoading(false);
  }, [options]);
  if (options.length === 0) return <></>;
  return (
    <>
      <Spin
        tip="Deleting..."
        indicator={<LoadingOutlined style={{ fontSize: 24 }} spin />}
        spinning={deleteLoading}
      >
        <Select
          value={defaultV ?? '0'}
          onChange={(e) => onClickEvent(e, target)}
        >
          {options.map((item, idx) => {
            return (
              <Select.Option key={idx} value={item}>
                {
                  <>
                    {''}
                    {item}
                    {item === MSG_REMOTE ||
                    item === MSG_LOCAL ||
                    item === MSG_SQL ? (
                      <></>
                    ) : (
                      <Popconfirm
                        title={`Are you sure to delete [${item}]?`}
                        onConfirm={(e) => {
                          e.stopPropagation();
                          onClickEvent(item, 'DELETE_HISTORY');
                        }}
                      >
                        <Button
                          type="text"
                          icon={<DeleteOutlined />}
                          style={{ float: 'right' }}
                          onClick={(e) => e.stopPropagation()}
                        />
                      </Popconfirm>
                    )}
                  </>
                }
              </Select.Option>
            );
          })}
        </Select>
      </Spin>
    </>
  );
};
Contents.propTypes = {
  options: PropTypes.array,
  defaultV: PropTypes.string,
  actionFunc: PropTypes.func,
  target: PropTypes.string,
};
export const JobSettingInputForm = ({ item, changefunc, info }) => {
  const { title, type, mode, options } = item;
  const period = { start: '', end: '' };
  const selected = { start: '', end: '' };
  if (type.toLowerCase() === 'datepicker') {
    selected.start =
      info.job_type === MESSAGE.HISTORY
        ? item?.selected?.start ?? options?.[0].start ?? 0
        : info?.selected?.start ??
          item?.selected?.start ??
          options?.[0].start ??
          0;
    selected.end =
      info.job_type === MESSAGE.HISTORY
        ? item?.selected?.end ?? options?.[0].end ?? 0
        : info?.selected?.end ?? item?.selected?.end ?? options?.[0].end ?? 0;
    period.start =
      info.job_type === MESSAGE.HISTORY
        ? item?.selected?.start ?? options?.[0].start ?? 0
        : info?.period?.start ?? item?.period?.start ?? options?.[0].start ?? 0;
    period.end =
      info.job_type === MESSAGE.HISTORY
        ? item?.selected?.end ?? options?.[0].end ?? 0
        : info?.period?.end ?? item?.period?.end ?? options?.[0].end ?? 0;
  }
  const changeEvent = (e) => {
    const update = changefunc(e);
    if (update !== undefined) {
      console.log(update);
    }
  };

  return (
    <div css={start_analysis_style}>
      {type === 'select' ? (
        mode === 'singular' ? (
          item.target === 'source' ? (
            <InputForm.select
              formLabel={title}
              formName={item.target}
              options={item.options}
              optionNode={
                <Contents
                  options={item.options}
                  defaultV={info?.[item.target] ?? ''}
                  actionFunc={changeEvent}
                  target={item.target}
                />
              }
              changeFunc={changeEvent}
              defaultV={info?.[item.target] ?? ''}
            />
          ) : (
            <InputForm.select
              formLabel={title}
              formName={item.target}
              options={item.options}
              changeFunc={changeEvent}
              defaultV={info?.[item.target] ?? ''}
            />
          )
        ) : mode === 'subItem' ? (
          <>
            <InputForm.subItem
              formLabel={title}
              formName={item.target}
              options={info?.info?.[item.target] ?? item.options}
              subItem={{
                ...item.subItem,
                options:
                  info?.info?.[item.subItem.target] ?? item.subItem.options,
                selected:
                  info?.[item.subItem.target] ?? item?.subItem.selected ?? '',
              }}
              defaultV={info?.[item.target] ?? item?.selected ?? ''}
              changeFunc={changeEvent}
            />
          </>
        ) : (
          <></>
        )
      ) : type.toLowerCase() === 'datepicker' ? (
        <InputForm.datePicker
          formLabel={title}
          formName={item.target}
          start={
            selected.start === ''
              ? selected.start
              : DAYJS(selected.start).format('YYYY-MM-DD')
          }
          end={
            selected.end === ''
              ? selected.end
              : DAYJS(selected.end).format('YYYY-MM-DD')
          }
          period={{
            start:
              period.start === ''
                ? period.start
                : DAYJS(period.start).format('YYYY-MM-DD'),
            end:
              period.end === ''
                ? period.end
                : DAYJS(period.end).format('YYYY-MM-DD'),
          }}
          changeFunc={changeEvent}
          disabled={item?.enable === false ?? false}
        />
      ) : type === 'directory' ? (
        <InputForm.directory
          formLabel={title}
          formName={item.target}
          changeFunc={changeEvent}
        />
      ) : type === 'files' ? (
        <InputForm.files
          formLabel={title}
          formName={item.target}
          changeFunc={changefunc}
          files={
            info?.file_name !== undefined
              ? info?.file_name?.getAll('files').map((o) => o) ?? undefined
              : item?.file_name?.length > 0 ?? false
              ? item.file_name.map((obj, i) => {
                  return {
                    uid: i + 1,
                    name: obj,
                    status: 'done',
                  };
                })
              : undefined
          }
          defaultFiles={
            item?.file_name?.length > 0 ?? false
              ? item.file_name.map((obj, i) => {
                  return {
                    uid: i + 1,
                    name: obj,
                    status: 'done',
                  };
                })
              : undefined
          }
          enable={item.enable}
        />
      ) : type === 'file' ? (
        <InputForm.file
          formLabel={title}
          formName={item.target}
          changeFunc={changefunc}
        />
      ) : type === 'text' ? (
        <InputForm.text
          formLabel={title}
          formName={item.target}
          changeFunc={changefunc}
          value={item?.content ?? info?.[item.target]}
        />
      ) : type === 'textarea' ? (
        <InputForm.textarea
          formName={item.target}
          changeFunc={changeEvent}
          value={info?.[item.target] ?? item?.content ?? ''}
          disabled={(item?.enable ?? true) === false}
        />
      ) : (
        <div>{title}</div>
      )}
    </div>
  );
};

JobSettingInputForm.propTypes = {
  item: PropTypes.object.isRequired,
  changefunc: PropTypes.func.isRequired,
  info: PropTypes.object,
};

const title_style = css`
  font-weight: 400;
`;
const ModalContents = ({ form, changeFunc, info }) => {
  const [source, setSource] = useState(info?.source ?? undefined);

  useEffect(() => {
    if (source !== info?.source) {
      setSource(info?.source);
    }
  }, [info?.source]);

  if (form === null || info === null) return <></>;

  return (
    form?.[source]?.map((item, idx) => (
      <div key={idx}>
        <FormCard title={item.title} titleStyle={title_style}>
          {item.items.map((idx2, i) => (
            <JobSettingInputForm
              key={i}
              item={item.items[i]}
              changefunc={changeFunc}
              info={info}
            />
          ))}
        </FormCard>
      </div>
    )) ?? <></>
  );
};

ModalContents.propTypes = {
  form: PropTypes.object,
  changeFunc: PropTypes.func,
  info: PropTypes.object,
};

const { TabPane } = Tabs;
const { Panel } = Collapse;

const MultiJobModalContents = ({
  info,
  changeFunc,
  resource,
  select,
  history,
}) => {
  const [source, setSource] = useState(select ?? undefined);
  const [jobList, setjobList] = useState({ function: [], history: [] });
  const { info: multiHistory, setfunc: setMultiHistory } = history;
  const HistoryInfo = multiHistory.resource.find(
    (o) => o.id === multiHistory.id,
  )?.info;

  useQuery(
    [QUERY_KEY.JOBSETTING_INIT, multiHistory?.id],
    () => getResource_HistorySetting({ history_id: multiHistory.id }),
    {
      enabled: !!multiHistory?.id && HistoryInfo === undefined,
      onError: RequestOnError,
      onSuccess: ({ id, info }) => {
        console.log('id', id);
        console.log('info', info);
        const isExist = multiHistory.resource
          .filter((o) => !!o?.info)
          .map((o) => o.id)
          .includes(multiHistory.id);
        console.log('isExist', isExist);
        if (isExist === false) {
          setMultiHistory((prevState) => ({
            ...prevState,
            resource: [...prevState.resource, { id: prevState.id, info: info }],
          }));
        }
      },
    },
  );

  const TabChange = (event) => {
    const item = getParseData(event);
    if (item.id === 'source' && source !== item.value) {
      setSource(item.value);
    }
    changeFunc({ MULTI_TAB: item.value });
  };
  const ListChange = ({ target, type }) => {
    if (type === MESSAGE.FUNCTION) {
      changeFunc({ source: target });
      if (target !== source) {
        setSource(target);
      }
    } else if (type === MESSAGE.HISTORY) {
      setMultiHistory((prevState) => ({ ...prevState, id: target }));
      changeFunc({ HISTORY: target });
    }
  };
  useEffect(() => {
    const funcList = resource.formList.filter(
      (o) => (o?.source_type ?? o?.type) !== 'history',
    );
    setjobList({
      function: funcList,
      history: resource.formList.filter(
        (o) => (o?.source_type ?? o?.type) === 'history',
      ),
    });
    const target = funcList?.[0]?.key ?? undefined;
    setSource(target);
    changeFunc({ source: target });
  }, [resource]);
  return (
    <>
      <Tabs
        defaultActiveKey="function"
        size={'small'}
        type={'card'}
        onChange={(key) => TabChange({ tab: key })}
      >
        <>
          <TabPane tab="Function" key="function">
            <div>
              <Select
                onChange={(e) => ListChange({ target: e, type: 'function' })}
                style={{ minWidth: '100%' }}
                value={source ?? ''}
              >
                {jobList.function.map((item, idx) => {
                  return (
                    <Select.Option key={idx} value={item?.key ?? item}>
                      {item?.key ?? item}
                    </Select.Option>
                  );
                })}
              </Select>
            </div>
            <ModalContents
              form={resource?.form}
              changeFunc={changeFunc}
              info={info?.find((o) => o.source === source) ?? null}
            />
          </TabPane>
          <TabPane tab="History" key="history">
            <div>
              <Select
                onChange={(e) =>
                  ListChange({ target: e, type: MESSAGE.HISTORY })
                }
                style={{ minWidth: '100%' }}
                value={multiHistory?.id ?? ''}
              >
                {jobList.history.map((item, idx) => {
                  return (
                    <Select.Option key={idx} value={item?.history_id ?? item}>
                      {item?.title ?? item}
                    </Select.Option>
                  );
                })}
              </Select>
            </div>
            <div css={historyStyle}>
              {HistoryInfo !== undefined ? (
                <Collapse>
                  {Object.keys(HistoryInfo.form).map((historyForm, index) => {
                    return (
                      <>
                        <Panel header={historyForm} key={`history_${index}`}>
                          <ModalContents
                            form={HistoryInfo.form}
                            info={{ source: historyForm }}
                          />
                        </Panel>
                      </>
                    );
                  })}
                </Collapse>
              ) : multiHistory?.id ?? false ? (
                <Spin tip=" Data Loading..." spinning={true} />
              ) : (
                <></>
              )}
            </div>
          </TabPane>
        </>
      </Tabs>
    </>
  );
};

MultiJobModalContents.propTypes = {
  info: PropTypes.array,
  changeFunc: PropTypes.func.isRequired,
  resource: PropTypes.object,
  select: PropTypes.string,
  history: PropTypes.object,
};

const JobSettingModal = ({ onClose, func_id, source }) => {
  const {
    jobSettingInfo,
    jobResource,
    setJobSettingInfo,
    multiHistory,
    urlList,
    currentPath,
    setCurrentPath,
    setMultiHistory,
    initialJobSetting,
  } = useJobSettingInfo();
  const { getJobResource } = useJobSetting();
  const { openModal } = useModal();
  const navigate = useNavigate();
  const [resourceLoad, setResourceLoad] = useState(true);
  const [isVisible, setIsVisible] = useState(true);
  const [reloadEquipment, setReloadEquipment] = useState(false);
  const [reloadPeriod, setReloadPeriod] = useState(false);
  const modalClose = () => {
    setIsVisible(false);
    onClose();
  };
  const { isLoading, isFetching } = getJobResource({
    func_id,
    source,
    enabled: resourceLoad && !!func_id,
    onSettled: () => setResourceLoad(false),
  });
  useQuery(
    [
      QUERY_KEY.JOBSETTING_USER_FAB_EQUIPMENT_LIST,
      jobSettingInfo?.db_id,
      jobSettingInfo?.table_name,
    ],
    () =>
      getEquipmentList({
        db_id:
          jobSettingInfo?.source_type === E_MULTI_TYPE
            ? jobSettingInfo.list.find(
                (o) => o.source === jobSettingInfo.source,
              )?.db_id
            : jobSettingInfo?.db_id,
        table_name:
          jobSettingInfo?.source_type === E_MULTI_TYPE
            ? jobSettingInfo.list.find(
                (o) => o.source === jobSettingInfo.source,
              )?.table_name
            : jobSettingInfo?.table_name,
      }),
    {
      enabled: reloadEquipment && jobSettingInfo?.job_type === MSG_REMOTE,
      onError: RequestOnError,
      onSuccess: ({ info }) => {
        setJobSettingInfo(
          jobSettingInfo?.source_type === E_MULTI_TYPE
            ? {
                ...jobSettingInfo,
                list: jobSettingInfo?.list.map((o) =>
                  o.source === jobSettingInfo.source ? { ...o, info: info } : o,
                ),
              }
            : { ...jobSettingInfo, info: info },
        );
      },
      onSettled: () => {
        setReloadEquipment(false);
      },
    },
  );

  useQuery(
    [
      QUERY_KEY.JOBSETTING_EQUIPMENT_VALID_DATE,
      jobSettingInfo?.db_id,
      jobSettingInfo?.table_name,
      jobSettingInfo?.info?.equipment_name,
      jobSettingInfo?.info?.time_column,
    ],
    () =>
      getEquipmentValidDate({
        db_id:
          jobSettingInfo?.source_type === E_MULTI_TYPE
            ? jobSettingInfo.list.find(
                (o) => o.source === jobSettingInfo.source,
              )?.db_id
            : jobSettingInfo?.db_id,
        table_name:
          jobSettingInfo?.source_type === E_MULTI_TYPE
            ? jobSettingInfo.list.find(
                (o) => o.source === jobSettingInfo.source,
              )?.table_name
            : jobSettingInfo?.table_name,
        equipment_name:
          jobSettingInfo?.source_type === E_MULTI_TYPE
            ? jobSettingInfo.list.find(
                (o) => o.source === jobSettingInfo.source,
              )?.equipment_name
            : jobSettingInfo?.equipment_name,
        time_column:
          jobSettingInfo?.source_type === E_MULTI_TYPE
            ? jobSettingInfo.list.find(
                (o) => o.source === jobSettingInfo.source,
              )?.time_column
            : jobSettingInfo?.time_column,
      }),
    {
      enabled: reloadPeriod && jobSettingInfo?.job_type === MSG_REMOTE,
      onError: RequestOnError,
      onSuccess: ({ info }) => {
        const obj = {
          period: { start: info.start, end: info.end },
          selected: { start: info.start, end: info.end },
        };
        setJobSettingInfo(
          jobSettingInfo?.source_type === E_MULTI_TYPE
            ? {
                ...jobSettingInfo,
                list: jobSettingInfo?.list.map((o) =>
                  o.source === jobSettingInfo.source ? { ...o, ...obj } : o,
                ),
              }
            : { ...jobSettingInfo, ...obj },
        );
      },
      onSettled: () => {
        setReloadPeriod(false);
      },
    },
  );

  const deleteHistory = useMutation(
    [QUERY_KEY.JOBSETTING_DELETE_HISTORY],
    (historyId) => deleteHistoryJob({ HistoryId: historyId }),
    {
      onError: RequestOnError,
      onSuccess: (status) => {
        if (status === R_OK) {
          setResourceLoad(true);
        }
      },
    },
  );

  const startEnableCheck = () => {
    const source = jobSettingInfo?.source ?? MSG_MULTI;
    const job =
      jobSettingInfo?.source_type === E_MULTI_TYPE
        ? jobSettingInfo?.MULTI_TAB === MESSAGE.HISTORY
          ? multiHistory.resource.find(
              (o) => o.id === jobSettingInfo.history_id,
            )?.info
          : {}
        : jobSettingInfo;
    if (source === MSG_LOCAL) {
      return Boolean(
        !!job?.file_name &&
          !!job?.log_name &&
          deleteHistory.isLoading === false,
      );
    } else if (source === MSG_REMOTE) {
      return Boolean(
        !!job?.db_id &&
          !!job?.equipment_name &&
          deleteHistory.isLoading === false,
      );
    } else if (source === MSG_SQL) {
      return Boolean(
        !!job?.db_id && !!job?.sql && deleteHistory.isLoading === false,
      );
    } else if (job === undefined) {
      return false;
    } else {
      console.log('jobSetting source(job_type): ', jobSettingInfo?.job_type);
      return Boolean(deleteHistory.isLoading === false);
    }
  };

  const contentChange = (event) => {
    const item = getParseData(event);
    console.log('contentChange', item);
    if (item.id === 'source') {
      const { formList } = jobResource;
      const JobInfo = formList.find((obj) => obj.key === item.value);
      console.log('JobInfo', JobInfo);
      setJobSettingInfo(
        JobInfo?.type ?? JobInfo?.job_type === 'history'
          ? {
              ...jobSettingInfo,
              [item.id]: item.value,
              ['history_id']: JobInfo.history_id,
              ['job_type']: JobInfo?.type ?? JobInfo?.source_type,
            }
          : {
              ...jobSettingInfo,
              [item.id]: item.value,
              ['job_type']: JobInfo?.type ?? JobInfo?.source_type,
            },
      );
    } else if (item.id === 'HISTORY') {
      setJobSettingInfo({
        ...jobSettingInfo,
        ['history_id']: item.value,
        ['job_type']: 'history',
      });
    } else if (item.id === 'DELETE_HISTORY') {
      const { formList } = jobResource;
      const JobInfo = formList.find((obj) => obj.key === item.value) ?? {};
      deleteHistory.mutate(JobInfo.history_id);
    } else if (item.id === 'db_id') {
      const obj = {
        db_id: item.value,
        equipment_name: '',
        user_fab: '',
        selected: { start: '', end: '' },
        period: { start: '', end: '' },
      };
      setJobSettingInfo(
        jobSettingInfo?.source_type === E_MULTI_TYPE
          ? {
              ...jobSettingInfo,
              list: jobSettingInfo?.list.map((o) =>
                o.source === jobSettingInfo.source
                  ? { ...o, ...obj, rid: undefined }
                  : o,
              ),
            }
          : { ...jobSettingInfo, ...obj },
      );
      setReloadEquipment(true);
    } else if (item.id === 'user_fab') {
      const obj = {
        equipment_name: '',
        user_fab: item.value,
        selected: { start: '', end: '' },
        period: { start: '', end: '' },
      };
      setJobSettingInfo(
        jobSettingInfo?.source_type === E_MULTI_TYPE
          ? {
              ...jobSettingInfo,
              list: jobSettingInfo?.list.map((o) =>
                o.source === jobSettingInfo.source
                  ? { ...o, ...obj, rid: undefined }
                  : o,
              ),
            }
          : { ...jobSettingInfo, ...obj },
      );
    } else if (item.id === 'equipment_name') {
      const obj = {
        equipment_name: item.value,
        selected: { start: '', end: '' },
        period: { start: '', end: '' },
      };
      setJobSettingInfo(
        jobSettingInfo?.source_type === E_MULTI_TYPE
          ? {
              ...jobSettingInfo,
              list: jobSettingInfo?.list.map((o) =>
                o.source === jobSettingInfo.source
                  ? { ...o, ...obj, rid: undefined }
                  : o,
              ),
            }
          : { ...jobSettingInfo, ...obj },
      );
      setReloadPeriod(true);
    } else if (item.id === 'period') {
      setJobSettingInfo(
        jobSettingInfo?.source_type === E_MULTI_TYPE
          ? {
              ...jobSettingInfo,
              list: jobSettingInfo?.list.map((o) =>
                o.source === jobSettingInfo.source
                  ? { ...o, selected: item.value, rid: undefined }
                  : o,
              ),
            }
          : { ...jobSettingInfo, selected: item.value },
      );
    } else if (item.id === 'src_file') {
      setJobSettingInfo(
        jobSettingInfo?.source_type === E_MULTI_TYPE
          ? {
              ...jobSettingInfo,
              list: jobSettingInfo?.list.map((o) =>
                o.source === jobSettingInfo.source
                  ? {
                      ...o,
                      file_name: item.value,
                      rid: undefined,
                      fid: undefined,
                    }
                  : o,
              ),
            }
          : {
              ...jobSettingInfo,
              file_name: item.value,
            },
      );
    } else {
      setJobSettingInfo({
        ...jobSettingInfo,
        [item.id]: item.value,
      });
    }
  };

  const startAnalysis = async () => {
    if (jobSettingInfo?.source_type === MSG_LOCAL) {
      closeJobModal(true);
    } else if (jobSettingInfo?.source_type === MSG_MULTI) {
      if (jobSettingInfo?.job_type !== MESSAGE.HISTORY) {
        closeJobModal(true);
      } else {
        closeJobModal(false);
        goAnalysisPage(
          E_MULTI_TYPE,
          urlList.find((obj) => obj.func === jobSettingInfo.func_id) ?? {
            func: '',
            path: [],
          },
          undefined,
          setCurrentPath,
          {
            currentPath,
            jobSettingInfo,
            multiHistory,
            resource: undefined,
          },
          navigate,
        );
      }
    } else {
      closeJobModal(true);
    }
  };

  const closeJobModal = (isProgressOpen) => {
    if (isProgressOpen) {
      console.log('openModal- ProgressModal');
      openModal(ProgressModal, {
        info: {
          currentPath: undefined,
          jobSettingInfo,
          multiHistory,
          resource: jobResource.form[jobSettingInfo.source],
        },
      });
      setIsVisible(false);
    } else {
      modalClose();
    }
  };

  useEffect(() => {
    initialJobSetting();
  }, []);

  return (
    <DraggableModal
      visible={isVisible}
      width={550}
      title={jobResource?.title ?? 'loading.....'}
      footer={[
        <Button2
          theme={'white'}
          onClick={startAnalysis}
          style={{ marginLeft: '8px', fontWeight: 400 }}
          disabled={startEnableCheck() === false}
          key="start"
        >
          Start Analysis
        </Button2>,
        <Button2
          theme={'blue'}
          onClick={() => closeJobModal(false)}
          style={{ marginLeft: '8px', fontWeight: 400 }}
          key="cancel"
        >
          Cancel
        </Button2>,
      ]}
      closable={false}
      centered
    >
      <Skeleton
        loading={isLoading || isFetching}
        active
        paragraph={{ rows: 5 }}
      >
        <div css={directoryStyle}>
          {jobSettingInfo.source_type === E_MULTI_TYPE ? (
            <MultiJobModalContents
              form={jobResource?.form ?? null}
              changeFunc={contentChange}
              resource={jobResource}
              select={jobSettingInfo?.source ?? undefined}
              info={jobSettingInfo?.list ?? []}
              history={{
                info: multiHistory,
                setfunc: setMultiHistory,
              }}
            />
          ) : (
            <ModalContents
              form={jobResource?.form ?? null}
              changeFunc={contentChange}
              info={jobSettingInfo}
            />
          )}
        </div>
      </Skeleton>
    </DraggableModal>
  );
};

JobSettingModal.propTypes = {
  onClose: PropTypes.func,
  func_id: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  source: PropTypes.string,
};

export default JobSettingModal;
