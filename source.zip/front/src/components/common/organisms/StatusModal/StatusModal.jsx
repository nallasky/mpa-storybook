import React, { useEffect, useState, useRef } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import styled from '@emotion/styled';
import { Button, Progress } from 'antd';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import ProcessingModal from '@components/common/organisms/ProcessingModal/ProcessingModal';
import useModal from '@libs/util/modalControl/useModal';
import {
  displayError,
  displayNotification,
} from '@libs/util/common/functionGroup';

const Contents = styled.div`
  display: flex;
  justify-content: space-around;
  align-items: center;
  & > div {
    &:first-of-type {
      display: flex;
      flex-direction: column;
      row-gap: 1rem;
    }
  }
`;

const StatusModal = ({ onClose, startCallback, intervalCallback }) => {
  const { openModal, closeModal } = useModal();
  const [isVisible, setIsVisible] = useState(true);
  const [statusInfo, setStatusInfo] = useState({
    status: 'running',
    percent: 0,
    detail: {
      error_files: 0,
      success_files: 0,
      total_files: 0,
      converted: 0,
    },
  });

  const cancelTokenSource = useRef();
  const intervalRef = useRef();

  const closeFunc = () => {
    setIsVisible(false);
    onClose();
  };

  useEffect(() => {
    return () => clearInterval(intervalRef.current);
  }, []);

  useEffect(() => {
    const { status } = statusInfo;
    if (status === 'running') {
      intervalRef.current = setInterval(() => {
        intervalCallback()
          .then((data) => {
            setStatusInfo(
              data ?? {
                ...statusInfo,
                status: 'error',
              },
            );
          })
          .catch((e) => {
            displayError(e?.message ?? e);
            closeFunc();
          });
      }, 1500);
    } else if (status === 'cancel' || statusInfo.detail.error_files) {
      displayError('Analysis failed. Please check the registered file.');
      closeFunc();
    } else if (status === 'success' && !statusInfo.detail.error_files) {
      closeFunc();
      setTimeout(async () => {
        let isError = undefined;
        try {
          cancelTokenSource.current = new AbortController();
          openModal(ProcessingModal, {
            title: 'Analysing',
            message: 'Analysing data',
            useCancel: true,
            onCancel: () => cancelTokenSource.current.abort(),
          });
          await startCallback();
        } catch (e) {
          isError = axios.isCancel(e)
            ? 'cancel'
            : e.response?.data?.msg ?? e?.message ?? e;
        } finally {
          closeModal(ProcessingModal);
          if (isError !== 'cancel') {
            displayNotification({
              message: isError ? 'Error occurred' : 'Analysis complete',
              description: isError ?? 'Analysis has been successfully completed.',
              duration: 3,
              style: {
                borderLeft: isError ? '8px solid red' : '8px solid green',
              },
            });
          }
        }
      }, 220);
    }
    return () => clearInterval(intervalRef.current);
  }, [statusInfo]);

  return (
    <DraggableModal
      visible={isVisible}
      centered
      title={
        statusInfo.status === 'running'
          ? 'PROCESS'
          : statusInfo.status === 'success'
          ? 'COMPLETE'
          : 'ERROR'
      }
      width={400}
      footer={[
        <Button
          key="button"
          type="primary"
          onClick={() => setStatusInfo({ ...statusInfo, status: 'cancel' })}
        >
          {statusInfo.status === 'running' ? 'Cancel' : 'Close'}
        </Button>,
      ]}
      closable={false}
    >
      <Contents>
        <div>
          <div>{`Success files: ${statusInfo.detail.success_files}`}</div>
          <div>{`Error files: ${statusInfo.detail.error_files}`}</div>
          <div>{`Total files: ${statusInfo.detail.total_files}`}</div>
          <div>{`Converted rows: ${statusInfo.detail.converted}`}</div>
        </div>
        <div>
          <Progress
            type="circle"
            percent={statusInfo.percent}
            status={
              statusInfo.status === 'running'
                ? 'normal'
                : statusInfo.status === 'success'
                ? 'success'
                : 'exception'
            }
          />
        </div>
      </Contents>
    </DraggableModal>
  );
};
StatusModal.propTypes = {
  onClose: PropTypes.func,
  startCallback: PropTypes.func,
  intervalCallback: PropTypes.func,
};

export default StatusModal;
