import React from 'react';
import PropTypes from 'prop-types';
import DraggableModal from '../DraggableModal/DraggableModal';
import { Contents, Spinner } from './styleGroup';

const ProcessingModal = ({ title, message, useCancel, onCancel }) => {
  return (
    <DraggableModal
      centered
      title={title}
      width={400}
      footer={null}
      closable={false}
    >
      <Contents>
        <Spinner>
          <div className="spinner-item" />
          <div className="spinner-item" />
          <div className="spinner-item" />
          <div className="spinner-item" />
          <div className="spinner-item" />
        </Spinner>
        <div className="message">
          {message}
          <span>.</span>
          <span>.</span>
          <span>.</span>
        </div>
        {useCancel && (
          <button className="button-request-cancel" onClick={onCancel}>Cancel</button>
        )}
      </Contents>
    </DraggableModal>
  );
};

export default ProcessingModal;

ProcessingModal.propTypes = {
  title: PropTypes.string.isRequired,
  message: PropTypes.string.isRequired,
  useCancel: PropTypes.bool,
  onCancel: PropTypes.func,
};
