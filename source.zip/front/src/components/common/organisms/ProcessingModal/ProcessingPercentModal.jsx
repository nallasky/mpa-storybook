import { Button, Progress } from 'antd';
import React, { useState } from 'react';
import { PercentContents as Contents } from './styleGroup';
import PropTypes from 'prop-types';
import { RequestOnError } from '../../../../libs/util/common/common';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
const initial_data = {
  status: 'running',
  percent: 0,
  detail: {
    error_files: 0,
    success_files: 0,
    total_files: 0,
    converted: 0,
  },
};
const ProcessingPercentModal = ({
  statusFunc,
  rid,
  onClose,
  onCancel,
  completeFunc,
}) => {
  const [statusInfo, setStatusInfo] = useState(initial_data);
  const [isVisible, setIsVisible] = useState(true);
  statusFunc({
    rid: rid ?? null,
    options: {
      enabled: !!(rid ?? false) && isVisible && statusInfo.status === 'running',
      refetchInterval: (rid ?? false) && isVisible ? 1000 : 0,
      onError: (err) => {
        RequestOnError(err);
        onCancel();
      },
      onSuccess: (data) => {
        if (data.status === 'success') {
          completeFunc(rid);
          modalClose();
        } else if (statusInfo.status === 'running') {
          setStatusInfo(
            data
              ? data
              : {
                  ...statusInfo,
                  status: 'error',
                },
          );
        }
      },
    },
  });
  console.log('statusInfo', statusInfo, isVisible);
  const modalClose = () => {
    setIsVisible(false);
    onClose();
  };

  return (
    isVisible && (
      <DraggableModal
        visible={isVisible}
        centered
        title={
          statusInfo.status === 'running'
            ? 'PROCESS'
            : statusInfo.status === 'success'
            ? 'COMPLETE'
            : 'ERROR'
        }
        width={400}
        footer={[
          <Button key="button" type="primary" onClick={modalClose}>
            {statusInfo.status === 'running' ? 'Cancel' : 'Close'}
          </Button>,
        ]}
        closable={false}
      >
        <Contents>
          <div>
            <div>{`Success files: ${statusInfo.detail.success_files}`}</div>
            <div>{`Error files: ${statusInfo.detail.error_files}`}</div>
            <div>{`Total files: ${statusInfo.detail.total_files}`}</div>
            <div>{`Converted rows: ${statusInfo.detail.converted}`}</div>
          </div>
          <div>
            <Progress
              type="circle"
              percent={statusInfo.percent}
              status={
                statusInfo.status === 'running'
                  ? 'normal'
                  : statusInfo.status === 'success'
                  ? 'success'
                  : 'exception'
              }
            />
          </div>
        </Contents>
      </DraggableModal>
    )
  );
};
ProcessingPercentModal.propTypes = {
  statusFunc: PropTypes.func,
  onClose: PropTypes.func,
  onCancel: PropTypes.func,
  completeFunc: PropTypes.func,
  rid: PropTypes.string,
};

export default ProcessingPercentModal;
