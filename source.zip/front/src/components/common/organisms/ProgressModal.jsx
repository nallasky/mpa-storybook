import React, { useEffect, useState, useRef } from 'react';
import PropTypes from 'prop-types';
import Button from '../atoms/Button';
import { css } from '@emotion/react';
import { Spin, Progress, List, Avatar } from 'antd';
import {
  ClockCircleOutlined,
  LoadingOutlined,
  PaperClipOutlined,
} from '@ant-design/icons';
import { E_MULTI_TYPE } from '@constants/etc';
import StatusTag from '../atoms/StatusTag/StatusTag';
import useCustomInterval from '../../../libs/util/common/useCustomInterval';
import DraggableModal from './DraggableModal/DraggableModal';
import { URL_JOB_ANALYSIS } from '@constants/URL';
import { MSG_LOCAL, MSG_MULTI, MSG_REMOTE, MSG_SQL } from '@constants/Message';
import useJobSettingInfo from '../../../hooks/common/useJobSettingInfo';
import { getListData, goAnalysisPage } from '@libs/util/common/functionGroup';
import { useMutation, useQuery } from 'react-query';
import { QUERY_KEY } from '@constants/QueryKey';
import {
  getConvertJobStatus,
  getRequestIdFromJobSetting,
  update_multiJobInfo,
  uploadFiles_JobSetting,
} from '@libs/axios/jobSettingRequest';
import { useNavigate } from 'react-router-dom';
import { RequestOnError } from '@libs/util/common/common';

const contentStyle = css`
  display: block;
`;

const gridContentWrapper = css`
  display: grid;
  grid-template-columns: 1fr 1fr;
  justify-items: center;
  & > div > div:last-of-type > p {
    margin-bottom: 0;
  }
  margin: 1rem 0;
`;

const ProcessIconStyle = css`
  display: flex;
  align-items: center;
  justify-contents: center;
`;

/*****************************************************************************
 *              Main Modal
 *****************************************************************************/

const ProgressModal = ({ info, onClose }) => {
  const {
    jobSettingInfo,
    jobResource,
    setJobSettingInfo,
    urlList,
    currentPath,
    setCurrentPath,
  } = useJobSettingInfo();
  const navigate = useNavigate();
  const JobCancel = useRef(null);
  const [isVisible, setIsVisible] = useState(true);
  const [status, setStatus] = useState('idle');
  const [percent, setPercent] = useState(0);
  const [contents, setContents] = useState(null);
  const [current, setCurrent] = useState(undefined);
  const [reFetchInterval, setReFetchInterval] = useState({ time: 0, count: 0 });

  const total = jobSettingInfo?.source_type
    ? jobSettingInfo?.source_type === E_MULTI_TYPE
      ? jobSettingInfo?.list.length
      : contents?.total_files ?? 0
    : info.jobSettingInfo.source_type === E_MULTI_TYPE
    ? info.jobSettingInfo?.list.length
    : contents?.total_files ?? 0;
  const completed = contents?.error_files ?? 0 + contents?.success_files ?? 0;
  const status_msg =
    status === 'error' ||
    ((jobSettingInfo?.source_type ?? info.jobSettingInfo.source_type) !==
      E_MULTI_TYPE &&
      total > 0 &&
      completed === total &&
      contents?.converted === 0)
      ? 'ERROR'
      : status === 'success'
      ? 'COMPLETE'
      : 'PROCESS';

  useCustomInterval(
    () => {
      // Your custom logic here
      jobSettingInfo?.source_type === E_MULTI_TYPE
        ? checkMultiAnalysisStatus(setStatus, setCurrent, current)
        : checkAnalysisStatus(setStatus, setPercent, setContents);
    },
    status_msg === 'PROCESS' ? 1000 : null,
  );

  const convertJobStatus = useQuery(
    [
      QUERY_KEY.JOBSETTING_CONVERT_JOB_STATUS,
      jobSettingInfo?.job_id ?? info.jobSettingInfo.job_id,
    ],
    () =>
      getConvertJobStatus({
        jobId: jobSettingInfo?.job_id ?? info.jobSettingInfo.job_id,
        count: ++reFetchInterval.count,
      }),
    {
      enabled:
        (jobSettingInfo?.job_type ?? info.jobSettingInfo.job_type) ===
          MSG_LOCAL &&
        !!(jobSettingInfo?.job_id ?? info.jobSettingInfo.job_id ?? false),
      refetchInterval: reFetchInterval.time,
      onSuccess: (data) => {
        if (data.percent === '100' && data.status !== 'running') {
          setReFetchInterval({ time: 0, count: 0 });
        }
      },
      onError: (error) => {
        setReFetchInterval({ time: 0, count: 0 });
        RequestOnError(error);
      },
    },
  );

  const updateMultiJobInfo = useMutation(
    [QUERY_KEY.JOBSETTING_MULTIJOB_UPDATE],
    ({ id, obj, rid }) =>
      update_multiJobInfo({ func_id: id, object: obj, rid }),
  );

  const localJobConvert = useMutation(
    [QUERY_KEY.JOBSETTING_LOCAL_JOB],
    ({ upload_id, jobInfo }) => {
      JobCancel.current = new AbortController();
      return getRequestIdFromJobSetting({
        source:
          jobSettingInfo?.source_type === E_MULTI_TYPE
            ? jobInfo?.job_type
            : jobInfo?.source,
        object: { ...jobInfo, signal: JobCancel.current.signal },
        files: upload_id,
      });
    },
    {
      onError: RequestOnError,
      onSuccess: ({ rid, jobInfo, upload_id }) => {
        console.log('[jobConvert]JobId', rid);
        console.log('[jobConvert]jobInfo', jobInfo);
        console.log('[jobConvert]upload_id', upload_id);
        /*const currentInfo = jobSettingInfo?.source_type
          ? jobSettingInfo
          : info.jobSettingInfo;*/
        if (jobSettingInfo?.source_type === E_MULTI_TYPE) {
          setJobSettingInfo({
            ...jobSettingInfo,
            list: jobSettingInfo?.list.map((o) =>
              o.multi_info_id === jobInfo.multi_info_id
                ? { ...o, fid: upload_id }
                : o,
            ),
            job_type: MSG_LOCAL,
            job_id: rid,
          });
        } else {
          setJobSettingInfo({
            ...jobSettingInfo,
            job_type: MSG_LOCAL,
            job_id: rid,
          });
        }
        setReFetchInterval((prevState) => ({ ...prevState, time: 1000 }));
      },
    },
  );

  const jobFileUpload = useMutation(
    [QUERY_KEY.JOBSETTING_FILE_UPLOAD],
    (jobInfo) => {
      JobCancel.current = new AbortController();
      return uploadFiles_JobSetting(
        jobInfo?.file_name ?? undefined,
        jobInfo,
        JobCancel.current.signal,
      );
    },
    {
      onError: RequestOnError,
      onSuccess: ({ upload_id, jobInfo }) => {
        localJobConvert.mutate({ upload_id: upload_id, jobInfo });
      },
    },
  );

  const remoteJob = useMutation(
    [QUERY_KEY.JOBSETTING_REMOTE_JOB],
    ({ source, jobInfo }) => {
      JobCancel.current = new AbortController();
      return getRequestIdFromJobSetting({
        source: source,
        object: { ...jobInfo, signal: JobCancel.current.signal },
      });
    },
    {
      onError: RequestOnError,
      onSuccess: ({ rid }) => {
        if (jobSettingInfo?.source_type !== E_MULTI_TYPE) {
          goAnalysisPage(
            jobSettingInfo.job_type,
            urlList.find((obj) => obj.func === jobSettingInfo.func_id) ?? {
              func: '',
              path: [],
            },
            rid,
            setCurrentPath,
            {
              currentPath: undefined,
              jobSettingInfo: jobSettingInfo,
              multiHistory: info.multiHistory,
              resource: jobResource,
            },
            navigate,
          );
          closeFunc();
        }
      },
    },
  );

  const endProcessModal = (status, converted) => {
    if (status === 'COMPLETE' && converted > 0) {
      navigate(URL_JOB_ANALYSIS, {
        state: {
          job_type: `${
            jobSettingInfo?.source_type ?? jobSettingInfo?.type ?? 'local'
          }`,
          func_id: `${jobSettingInfo?.func_id ?? undefined}`,
          job_id: `${jobSettingInfo.job_id}`,
          path: [],
          list:
            jobSettingInfo?.source_type === MSG_MULTI
              ? getListData(jobSettingInfo.list)
              : undefined,
        },
      });
      setJobSettingInfo(undefined);
      closeFunc();
    } else if (converted === -1) {
      JobCancel.current?.abort();
      closeFunc();
    }
  };

  const checkAnalysisStatus = async (
    setStatusFunc,
    setPercentFunc,
    contentsFunc,
  ) => {
    contentsFunc(convertJobStatus?.data?.detail ?? undefined);
    setStatusFunc(convertJobStatus?.data?.status ?? undefined);
    setPercentFunc(convertJobStatus?.data?.percent ?? 0);
  };

  const checkMultiAnalysisStatus = async (
    setStatusFunc,
    setCurrentFunc,
    currentJob,
  ) => {
    let nextJob = jobSettingInfo.list.find((o) => o.rid === undefined);
    if (currentJob === undefined) {
      if (nextJob === undefined) {
        goAnalysisPage(
          E_MULTI_TYPE,
          urlList.find((obj) => obj.func === jobSettingInfo.func_id) ?? {
            func: '',
            path: [],
          },
          undefined,
          setCurrentPath,
          {
            currentPath,
            jobSettingInfo: jobSettingInfo,
            multiHistory: info.multiHistory,
            resource: undefined,
          },
          navigate,
        );
        setReFetchInterval({ time: 0, count: 0 });
        await endProcessModal(status_msg, -1);
      } else {
        if (nextJob.job_type === MSG_LOCAL) {
          jobFileUpload.mutate(nextJob);
          setCurrentFunc(nextJob.source);
        } else if ([MSG_REMOTE, MSG_SQL].includes(nextJob.job_type)) {
          remoteJob.mutate({ source: nextJob.job_type, jobInfo: nextJob });
          setCurrentFunc(nextJob.source);
        }
      }
    } else {
      const Job = jobSettingInfo.list.find((o) => o.source === currentJob);
      if (Job.job_type === MSG_LOCAL) {
        const statusData = convertJobStatus?.data ?? {
          percent: 0,
          status: 'running',
        };
        if (
          statusData.percent === '100' &&
          statusData.status === 'success' &&
          (nextJob?.source ?? undefined) === currentJob
        ) {
          try {
            if (updateMultiJobInfo.isIdle) {
              await updateMultiJobInfo.mutate({
                id: jobSettingInfo.func_id,
                obj: Job,
                rid: jobSettingInfo.job_id,
              });
            } else if (updateMultiJobInfo.isSuccess) {
              setJobSettingInfo({
                ...jobSettingInfo,
                list: jobSettingInfo?.list.map((o) =>
                  o.source === currentJob
                    ? { ...o, rid: jobSettingInfo?.job_id ?? undefined }
                    : o,
                ),
                job_id: undefined,
              });
              setCurrentFunc(undefined);
            }
          } catch (e) {
            console.log(e);
          }
        } else if (statusData.status === 'error') {
          setStatusFunc(statusData.status);
        }
      } else if (
        [MSG_REMOTE, MSG_SQL].includes(Job.job_type) &&
        (remoteJob.data?.rid ?? false)
      ) {
        if (updateMultiJobInfo.isIdle) {
          await updateMultiJobInfo.mutate({
            id: jobSettingInfo.func_id,
            obj: Job,
            rid: remoteJob.data?.rid,
          });
        } else if (updateMultiJobInfo.isSuccess) {
          setJobSettingInfo({
            ...jobSettingInfo,
            list: jobSettingInfo?.list.map((o) =>
              o.source === currentJob ? { ...o, rid: remoteJob.data?.rid } : o,
            ),
            job_id: undefined,
          });
          setCurrentFunc(undefined);
        }
      }
    }
  };
  const closeFunc = () => {
    setIsVisible(false);
    onClose();
  };
  const Request = async () => {
    if (
      jobSettingInfo?.source_type === MSG_LOCAL &&
      jobSettingInfo?.job_type !== 'history'
    ) {
      await jobFileUpload.mutate(jobSettingInfo);
    } else if (jobSettingInfo?.source_type !== MSG_MULTI) {
      await remoteJob.mutate({
        source: jobSettingInfo.job_type,
        jobInfo: jobSettingInfo,
      });
    }
  };

  useEffect(() => {
    console.log('jobSettingInfo1', jobSettingInfo);
    if (jobSettingInfo?.source_type ?? jobSettingInfo?.job_type) {
      Request().then((_) => _);
    }
  }, []);

  useEffect(() => {
    console.log('=======useEffect========');
    if (status === 'success') {
      endProcessModal(status_msg, contents.converted);
    }
  }, [status]);

  return (
    <DraggableModal
      visible={isVisible}
      title={status_msg}
      closable={false}
      footer={[
        <Button
          key="cancel"
          theme="blue"
          onClick={() => endProcessModal(status_msg, -1)}
          style={{ marginLeft: '8px', fontWeight: 400 }}
        >
          {status === 'success' || completed === total ? 'Close' : 'Cancel'}
        </Button>,
      ]}
      centered
    >
      {jobSettingInfo?.source_type === E_MULTI_TYPE ? (
        <MultiJobContents
          list={jobSettingInfo?.list ?? []}
          currentJob={current}
        />
      ) : (
        <Contents type={status_msg} percent={percent} contents={contents} />
      )}
    </DraggableModal>
  );
};

ProgressModal.propTypes = {
  onClose: PropTypes.func,
  info: PropTypes.object.isRequired,
};

/*****************************************************************************
 *              Modal Contents
 *****************************************************************************/
const ErrorContents = css`
  flex: none;
  order: 0;
  flex-grow: 1;
  margin: 0px 10px;
`;

const ItemDiv = css`
  color: rgba(0, 0, 0, 0.65);
  font-size: 14px;
  & > p {
    margin-right: 0.5rem;
  }
`;

const ItemLabel = css`
  display: inline-block;
  color: rgba(0, 0, 0, 0.85);
  margin-left: 1rem;
`;

const Contents = ({ type, percent, contents }) => {
  if (!!contents === false) {
    const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;
    return (
      <div css={contentStyle}>
        <div css={ErrorContents}>
          <div css={ItemDiv}>
            <Spin indicator={antIcon} />
            <div css={ItemLabel}>File uploading</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div css={gridContentWrapper}>
      <div>
        <div css={ItemDiv}>
          <p css={ItemLabel}>Error Files:</p>
          {contents.error_files}
        </div>
        <div css={ItemDiv}>
          <p css={ItemLabel}>Success Files:</p>
          {contents.success_files}
        </div>
        <div css={ItemDiv}>
          <p css={ItemLabel}>Total Files:</p>
          {contents.total_files}
        </div>
        <div css={ItemDiv}>
          <p css={ItemLabel}>Converted rows:</p>
          {contents.converted}
        </div>
      </div>
      {type === 'COMPLETE' ? (
        <Progress type="circle" percent={100} css={ProcessIconStyle} />
      ) : type === 'PROCESS' ? (
        <Progress type="circle" percent={percent} css={ProcessIconStyle} />
      ) : (
        <Progress
          type="circle"
          percent={percent}
          status="exception"
          css={ProcessIconStyle}
        />
      )}
    </div>
  );
};
Contents.propTypes = {
  type: PropTypes.string,
  percent: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  contents: PropTypes.object,
};

const MultiJobContents = ({ list, currentJob }) => {
  console.log('list', list);
  console.log('currentJob', currentJob);
  return (
    <div style={{ minWidth: '350px' }}>
      <List
        itemLayout="horizontal"
        dataSource={list ?? []}
        css={{ maxHeight: '300px' }}
        renderItem={(item) => (
          <List.Item>
            <List.Item.Meta
              avatar={<Avatar icon={<PaperClipOutlined />} />}
              title={`${item?.source}`}
              description={
                <div>
                  <span css={{ padding: '0px 4px' }}>
                    {item?.source_type ?? ''
                      ? `Source: ${item.source_type}`
                      : ''}
                  </span>
                </div>
              }
            />
            <div style={{ width: '80px' }}>
              {item?.rid ?? false ? (
                <StatusTag status={'success'} />
              ) : item.source === currentJob ? (
                <StatusTag status={'processing'} />
              ) : (
                <StatusTag
                  status={'waiting'}
                  color={'warning'}
                  icon={<ClockCircleOutlined />}
                />
              )}
            </div>
          </List.Item>
        )}
      />
    </div>
  );
};
MultiJobContents.propTypes = {
  list: PropTypes.array,
  currentJob: PropTypes.string,
};

export default ProgressModal;
