import { css } from '@emotion/react';
export const PatternStyle = css`
  display: flex;
  flex-wrap: wrap;
  row-gap: 0.4rem;
  overflow: auto;
  max-height: 85px;
  & .pattern-add {
    background: var(--ckr-gray-1);
    border-style: dashed;
  }
  & .pattern-edit {
    user-select: none;
  }
  & .pattern-input {
    width: 78px;
    margin-right: 8px;
    vertical-align: top;
  }
  & .ant-tag {
    border-radius: 10px;
    &:hover {
      color: var(--ckr-blue-6);
      border: 1px dashed var(--ckr-blue-6);
    }
    & span.anticon {
      & svg {
        vertical-align: inherit;
        width: 10px;
        height: 12px;
      }
    }
  }
`;
