import { useState } from 'react';

const usePatternForm = () => {
  const [editInputIndex, setEditInputIndex] = useState(-1);
  const [editInputValue, setEditInputValue] = useState('');
  const [inputValue, setInputValue] = useState('');
  const [inputVisible, setInputVisible] = useState(false);

  const showInput = () => {
    setInputVisible(true);
  };

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleInputConfirm = (pattern, updatePattern) => {
    if (inputValue && pattern.indexOf(inputValue) === -1) {
      updatePattern([...pattern, inputValue]);
    }

    setInputVisible(false);
    setInputValue('');
  };

  const handleEditInputChange = (e) => {
    setEditInputValue(e.target.value);
  };

  const handleEditInputConfirm = (pattern, updatePattern) => {
    const newTags = [...pattern];
    newTags[editInputIndex] = editInputValue;
    updatePattern(newTags);
    setEditInputIndex(-1);
    setInputValue('');
  };
  const handleClose = (removedTag, pattern, updatePattern) => {
    const newTags = pattern.filter((tag) => tag !== removedTag);
    console.log(newTags);
    updatePattern(newTags);
  };
  return {
    showInput,
    handleInputChange,
    handleInputConfirm,
    handleEditInputChange,
    handleEditInputConfirm,
    handleClose,
    setEditInputIndex,
    setEditInputValue,
    inputVisible,
    inputValue,
    editInputIndex,
    editInputValue,
  };
};
export default usePatternForm;
