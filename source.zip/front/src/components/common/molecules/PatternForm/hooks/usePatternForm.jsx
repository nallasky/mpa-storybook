import { useState } from 'react';

const usePatternForm = () => {
  const [editInputIndex, setEditInputIndex] = useState(-1);
  const [editInputValue, setEditInputValue] = useState('');
  const [inputValue, setInputValue] = useState('');
  const [inputVisible, setInputVisible] = useState(false);
  const [errMsg, setErrMsg] = useState(undefined);

  const showInput = () => {
    setInputVisible(true);
  };

  const handleInputChange = (pattern, e) => {
    if (
      pattern
        .map((v) => v.toLowerCase())
        .indexOf(e.target.value.toLowerCase()) !== -1
    ) {
      setErrMsg(`[${e.target.value}] is duplicated.`);
    } else if (errMsg) {
      setErrMsg(undefined);
    }
    setInputValue(e.target.value);
  };

  const handleInputConfirm = (pattern, updatePattern) => {
    if (
      inputValue &&
      pattern.map((v) => v.toLowerCase()).indexOf(inputValue.toLowerCase()) ===
        -1
    ) {
      updatePattern([...pattern, inputValue]);
    }
    if (errMsg) {
      setErrMsg(undefined);
    }

    setInputVisible(false);
    setInputValue('');
  };

  const handleEditInputChange = (pattern, e) => {
    setEditInputValue(e.target.value);
    if (
      ![-1, editInputValue].includes(
        pattern
          .map((v) => v.toLowerCase())
          .indexOf(e.target.value.toLowerCase()),
      )
    ) {
      setErrMsg(`[${e.target.value}] is duplicated.`);
    } else if (errMsg) {
      setErrMsg(undefined);
    }
  };

  const handleEditInputConfirm = (pattern, updatePattern) => {
    const newTags = [...pattern];
    const duplicatesIndex = pattern
      .map((v) => v.toLowerCase())
      .indexOf(editInputValue.toLowerCase());
    if (duplicatesIndex === -1) {
      newTags[editInputIndex] = editInputValue;
      updatePattern(newTags);
    } else if (errMsg) {
      setErrMsg(undefined);
    }
    setEditInputIndex(-1);
    setInputValue('');
  };
  const handleClose = (removedTag, pattern, updatePattern) => {
    const newTags = pattern.filter((tag) => tag !== removedTag);
    console.log(newTags);
    updatePattern(newTags);
  };
  return {
    showInput,
    handleInputChange,
    handleInputConfirm,
    handleEditInputChange,
    handleEditInputConfirm,
    handleClose,
    setEditInputIndex,
    setEditInputValue,
    inputVisible,
    inputValue,
    editInputIndex,
    editInputValue,
    errMsg,
  };
};
export default usePatternForm;
