import { useEffect, useRef } from 'react';
import { PlusOutlined } from '@ant-design/icons';
import { Input, Tag, Tooltip } from 'antd';
import PropTypes from 'prop-types';
import { PatternStyle } from './styles/PatternFormStyle';
import usePatternForm from '@components/common/molecules/PatternForm/hooks/usePatternForm';

const PatternForm = ({ pattern, title, updatePattern }) => {
  const inputRef = useRef(null);
  const editInputRef = useRef(null);
  const {
    handleInputConfirm,
    handleInputChange,
    inputVisible,
    inputValue,
    editInputIndex,
    editInputValue,
    setEditInputIndex,
    setEditInputValue,
    handleEditInputChange,
    showInput,
    handleEditInputConfirm,
    handleClose,
  } = usePatternForm();

  useEffect(() => {
    if (inputVisible) {
      inputRef.current?.focus();
    }
  }, [inputVisible]);
  useEffect(() => {
    editInputRef.current?.focus();
  }, [inputValue]);

  return (
    <div css={PatternStyle}>
      {pattern.map((tag, index) => {
        if (editInputIndex === index) {
          return (
            <Input
              ref={editInputRef}
              key={tag}
              size="small"
              className="pattern-input"
              value={editInputValue}
              onChange={handleEditInputChange}
              onBlur={() => handleEditInputConfirm(pattern, updatePattern)}
              onPressEnter={() =>
                handleEditInputConfirm(pattern, updatePattern)
              }
            />
          );
        }

        const isLongTag = tag.length > 20;
        const tagElem = (
          <Tag
            className="pattern-edit"
            key={tag}
            closable={true}
            onClose={() => handleClose(tag, pattern, updatePattern)}
          >
            <span
              onDoubleClick={(e) => {
                setEditInputIndex(index);
                setEditInputValue(tag);
                e.preventDefault();
              }}
            >
              {isLongTag ? `${tag.slice(0, 20)}...` : tag}
            </span>
          </Tag>
        );
        return isLongTag ? (
          <Tooltip title={tag} key={tag}>
            {tagElem}
          </Tooltip>
        ) : (
          tagElem
        );
      })}
      {inputVisible && (
        <Input
          ref={inputRef}
          type="text"
          size="small"
          className="pattern-input"
          value={inputValue}
          onChange={handleInputChange}
          onBlur={() => handleInputConfirm(pattern, updatePattern)}
          onPressEnter={() => handleInputConfirm(pattern, updatePattern)}
        />
      )}
      {!inputVisible && (
        <Tag className="pattern-add" onClick={showInput}>
          <PlusOutlined /> {title}
        </Tag>
      )}
    </div>
  );
};
PatternForm.propTypes = {
  updatePattern: PropTypes.func,
  pattern: PropTypes.list,
  title: PropTypes.string,
};
export default PatternForm;
