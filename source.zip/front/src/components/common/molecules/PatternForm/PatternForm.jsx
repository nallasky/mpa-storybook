import { useEffect, useRef } from 'react';
import { PlusOutlined } from '@ant-design/icons';
import { Input, Tag, Tooltip } from 'antd';
import PropTypes from 'prop-types';
import { PatternStyle } from './styles/PatternFormStyle';
import usePatternForm from '@components/common/molecules/PatternForm/hooks/usePatternForm';

const PatternForm = ({ pattern, title, updatePattern }) => {
  const inputRef = useRef(null);
  const editInputRef = useRef(null);
  const {
    handleInputConfirm,
    handleInputChange,
    inputVisible,
    inputValue,
    editInputIndex,
    editInputValue,
    setEditInputIndex,
    setEditInputValue,
    handleEditInputChange,
    showInput,
    handleEditInputConfirm,
    handleClose,
    errMsg,
  } = usePatternForm();

  useEffect(() => {
    if (inputVisible) {
      inputRef.current?.focus();
    }
  }, [inputVisible]);
  useEffect(() => {
    editInputRef.current?.focus();
  }, [inputValue]);

  return (
    <div css={PatternStyle}>
      {pattern.map((tag, index) => {
        if (editInputIndex === index) {
          return (
            <Tooltip title={errMsg} visible={!!errMsg} trigger="hover">
              <Input
                ref={editInputRef}
                key={tag}
                size="small"
                className="pattern-input"
                value={editInputValue}
                onChange={(e) => handleEditInputChange(pattern, e)}
                onBlur={() => handleEditInputConfirm(pattern, updatePattern)}
                onPressEnter={() =>
                  handleEditInputConfirm(pattern, updatePattern)
                }
              />
            </Tooltip>
          );
        }

        const isLongTag = tag.length > 20;
        const tagElem = (
          <Tag
            className="pattern-edit"
            key={tag}
            closable={true}
            onClose={() => handleClose(tag, pattern, updatePattern)}
          >
            <span
              onDoubleClick={(e) => {
                setEditInputIndex(index);
                setEditInputValue(tag);
                e.preventDefault();
              }}
            >
              {isLongTag ? `${tag.slice(0, 20)}...` : tag}
            </span>
          </Tag>
        );
        return isLongTag ? (
          <Tooltip title={tag} key={tag}>
            {tagElem}
          </Tooltip>
        ) : (
          tagElem
        );
      })}
      {inputVisible && (
        <Tooltip title={errMsg} visible={!!errMsg} trigger="hover">
          <Input
            ref={inputRef}
            type="text"
            size="small"
            className="pattern-input"
            value={inputValue}
            onChange={(e) => handleInputChange(pattern, e)}
            onBlur={() => handleInputConfirm(pattern, updatePattern)}
            onPressEnter={() => handleInputConfirm(pattern, updatePattern)}
          />
        </Tooltip>
      )}
      {!inputVisible && (
        <Tag className="pattern-add" onClick={showInput}>
          <PlusOutlined /> {title}
        </Tag>
      )}
    </div>
  );
};
PatternForm.propTypes = {
  updatePattern: PropTypes.func,
  pattern: PropTypes.list,
  title: PropTypes.string,
};
export default PatternForm;
