import { useEffect, useRef } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import { newWindowStyles } from './styles/newWindowStyle';

const NewWindowForm = (props) => {
  const { title, closeWindowPortal, div_id, enable, children } = props;
  const externalWindow = useRef(null);
  const element = document.getElementById(div_id);
  const containerEl = document.createElement('div');

  useEffect(() => {
    if (enable && element) {
      containerEl.append(element.cloneNode(true));
      externalWindow.current = window.open(
        '',
        '',
        'width=600,height=400,left=200,top=200',
      );
      externalWindow.current.document.title = title;
      externalWindow.current.document.body.appendChild(containerEl);
      newWindowStyles(document, externalWindow.current.document);

      externalWindow.current.addEventListener('beforeunload', () => {
        closeWindowPortal();
      });
    }

    return () => externalWindow?.current?.close();
  }, [enable]);

  return enable ? ReactDOM.createPortal(children, containerEl) : null;
};
NewWindowForm.propTypes = {
  title: PropTypes.string,
  element: PropTypes.any,
  closeWindowPortal: PropTypes.func,
  div_id: PropTypes.string,
  enable: PropTypes.bool,
  children: PropTypes.node,
};
export default NewWindowForm;
