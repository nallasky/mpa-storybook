import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faSearch,
  faTable,
  faRedoAlt,
} from '@fortawesome/free-solid-svg-icons';
import { Input, InputNumber, Select, Tag } from 'antd';

const Component = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  &.only-option {
    justify-content: flex-end;
  }
  & > .table-info {
    display: flex;
    align-items: center;
    & > .page-count {
      & > svg {
        margin-right: 0.5rem;
      }
    }
    & > .search-tag {
      & > .ant-tag {
        margin-right: 0;
        margin-left: 0.5rem;
      }
    }
  }
  & > .table-option {
    display: flex;
    align-items: center;
    column-gap: 0.5rem;
    & > .change-page {
      & > span {
        margin-right: 0.25rem;
      }
      & > .ant-input-number {
        height: 32px;
      }
    }
    & > .change-row-size {
      & > .ant-select {
        width: 120px;
      }
    }
    & > .search-table {
      display: flex;
      column-gap: 0.5rem;
      & > button {
        position: relative;
        border: none;
        background-color: var(--ckr-blue-6);
        color: var(--ckr-gray-1);
        border-radius: 2px;
        cursor: pointer;
        padding: 0 0.75rem;
        outline: none;
        &:disabled {
          cursor: not-allowed;
          background-color: var(--ckr-gray-5);
          &::after {
            display: none;
          }
        }
        &:active {
          transform: translateY(3px);
          &::after {
            box-shadow: none;
          }
        }
        &::after {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          content: '';
          border-radius: 2px;
          box-shadow: 0px 3px 4px 0px rgba(0, 0, 0, 0.25);
        }
      }
    }
  }
`;

const TableHeader = ({
  currentPage,
  dataLength,
  setPage,
  onSearch,
  rowSize,
  setRowSize,
  rowSizeOptions,
  isSearched,
  uniqueKey,
  searchValue,
  disablePageInfo,
  disableSetPage,
  disableSearch,
  disableSetRowSize,
}) => {
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    if (uniqueKey) {
      setSearchText('');
    } else {
      setSearchText(searchValue ?? '');
    }
  }, [uniqueKey, searchValue]);

  return (
    <Component
      className={
        disablePageInfo &&
        (!disableSetPage || !disableSearch || !disableSetRowSize)
          ? 'only-option'
          : ''
      }
    >
      <div className="table-info">
        {!disablePageInfo && (
          <div className="page-count">
            <FontAwesomeIcon icon={faTable} size="lg" />
            <span>
              {currentPage !== null
                ? `Page ${currentPage} of ${
                    dataLength > 0 ? Math.ceil(dataLength / rowSize) : 1
                  }`
                : 'Setting up the page...'}
            </span>
          </div>
        )}
        {!disableSearch && isSearched && (
          <div className="search-tag">
            <Tag color="#87d068">Searched Data</Tag>
          </div>
        )}
      </div>
      {(!disableSearch || !disableSetPage || !disableSetRowSize) && (
        <div className="table-option">
          {!disableSetPage && (
            <div className="change-page">
              <span>Go to Page:</span>
              <InputNumber
                min={1}
                max={dataLength > 0 ? Math.ceil(dataLength / rowSize) : 1}
                value={currentPage}
                onChange={setPage}
              />
            </div>
          )}
          {!disableSetRowSize && (
            <div className="change-row-size">
              <Select value={rowSize} onChange={setRowSize}>
                {rowSizeOptions.map((v) => (
                  <Select.Option key={v} value={v}>
                    Show {v}
                  </Select.Option>
                ))}
              </Select>
            </div>
          )}
          {!disableSearch && (
            <div className="search-table">
              <Input
                type="text"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
              />
              <button
                onClick={() => {
                  onSearch(searchText);
                }}
                title="Search"
                disabled={searchText.length === 0}
              >
                <FontAwesomeIcon icon={faSearch} />
              </button>
              <button
                onClick={() => {
                  setSearchText('');
                  onSearch('');
                }}
                title="Initialization"
              >
                <FontAwesomeIcon icon={faRedoAlt} />
              </button>
            </div>
          )}
        </div>
      )}
    </Component>
  );
};
TableHeader.propTypes = {
  currentPage: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  dataLength: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  setPage: PropTypes.func,
  onSearch: PropTypes.func,
  rowSize: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  setRowSize: PropTypes.func,
  rowSizeOptions: PropTypes.array,
  isSearched: PropTypes.bool,
  searchValue: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  uniqueKey: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  disablePageInfo: PropTypes.bool,
  disableSetPage: PropTypes.bool,
  disableSearch: PropTypes.bool,
  disableSetRowSize: PropTypes.bool,
};
TableHeader.defaultProps = {
  disablePageInfo: false,
  disableSetPage: false,
  disableSearch: false,
  disableSetRowSize: false,
  rowSizeOptions: [10, 20, 30, 40, 50],
  rowSize: 10,
};

export default TableHeader;
