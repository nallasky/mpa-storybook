import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';

const Wrapper = styled.div`
  & > label {
    display: inline-block;
    & + label {
      margin-left: 1rem;
    }
    & > input[type='radio'] {
      display: none;
      &:checked,
      &:hover:not(:disabled) {
        & + .button {
          background-color: var(--ckr-gray-3);
          color: #262626;
          &::after {
            opacity: 1;
          }
        }
      }
      &:disabled {
        & + .button {
          color: #dddddd;
          cursor: default;
        }
      }
    }
    & > .button {
      position: relative;
      z-index: 1;
      padding: 0.5rem 1rem;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      ${(props) => props.useTransition && 'transition: all 0.3s;'}
      color: var(--ckr-gray-7);
      &::after {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        content: '';
        opacity: 0;
        border-radius: 8px;
        box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
        ${(props) => props.useTransition && 'transition: opacity 0.3s;'}
      }
      & svg {
        margin-right: 0.3rem;
      }
    }
  }
`;

const CustomRadioGroup = ({
  options,
  className,
  changeFunc,
  initialValue,
  useTransition,
}) => {
  const [currentChecked, setCurrentChecked] = useState(
    initialValue ?? options[0].id,
  );

  const changeRadio = (id) => {
    setCurrentChecked(id);
    if (changeFunc) {
      changeFunc(id);
    }
  };

  return (
    <Wrapper useTransition={useTransition}>
      {options?.map((v, i) => {
        return (
          <label key={i} className={className}>
            <input
              type="radio"
              checked={v.id === currentChecked}
              onChange={() => changeRadio(v.id)}
              disabled={v.disabled}
            />
            <div className={`button ${className}`}>
              {v.icon ?? ''}
              {v.title}
            </div>
          </label>
        );
      })}
    </Wrapper>
  );
};
CustomRadioGroup.propTypes = {
  options: PropTypes.array.isRequired,
  className: PropTypes.string,
  changeFunc: PropTypes.func.isRequired,
  initialValue: PropTypes.string,
  useTransition: PropTypes.bool,
};
CustomRadioGroup.defaultProps = {
  useTransition: true,
};

export default CustomRadioGroup;
