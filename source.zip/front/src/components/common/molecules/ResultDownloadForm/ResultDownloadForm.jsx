import React from 'react';
import { CloudDownloadOutlined } from '@ant-design/icons';
import { MSG_DOWNLOAD } from '../../../../constants/Message';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: var(--ckr-gray-1);
    border: 1px dashed var(--ckr-gray-5);
    &:disabled {
      background-color: var(--ckr-gray-5);
      color: transparent;
      &::before {
        position: absolute;
        width: 100%;
        top: 5px;
        left: 0;
        content: 'X';
        color: var(--ckr-gray-1);
        font-weight: bold;
        font-size: 20px;
      }
    }
  }
  &.blue {
    color: var(--ckr-gray-1);
    background-color: var(--ckr-blue-6);
    border: 1px solid var(--ckr-blue-6);
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;

const ResultDownloadForm = ({ disabled, downloadFunc }) => {
  const DownloadOnClick = () => {
    downloadFunc();
  };
  return (
    <>
      <button
        css={antdButtonStyle}
        className="white"
        disabled={disabled ?? false}
        style={{ marginLeft: '8px', fontWeight: 400 }}
        onClick={DownloadOnClick}
      >
        <CloudDownloadOutlined />
        <span> {MSG_DOWNLOAD} </span>
      </button>
    </>
  );
};
ResultDownloadForm.propTypes = {
  disabled: PropTypes.bool,
  downloadFunc: PropTypes.func,
};
export default ResultDownloadForm;
