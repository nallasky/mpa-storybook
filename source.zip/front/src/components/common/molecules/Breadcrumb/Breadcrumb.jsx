import React, { useMemo } from 'react';
import { css } from '@emotion/react';
import { useLocation, Link } from 'react-router-dom';
import { Breadcrumb } from 'antd';
import { MESSAGE, MSG_ANALYSIS, MSG_HOME } from '@constants/Message';
import {
  ADC_MEASUREMENT,
  ANALYSIS,
  COMMON_LOG,
  CORRECTION,
  EDIT,
  MAIN,
  MEMORY_DUMP,
  NEW,
  OVERLAY,
  SETTINGS,
  SLICE,
  STATUS_MONITOR,
  TACT,
  URL_MAIN,
  LOG,
} from '@constants/URL';
import { HomeOutlined } from '@ant-design/icons';
import { Main, Common } from '@assets/locale/en';

const breadcrumbWrapper = css`
  font-weight: 600;
  padding: 1rem 0.5rem;
  & > div > span {
    color: var(--ckr-blue-9);
    &:last-of-type {
      color: var(--ckr-blue-6);
    }
  }
  & > nav > ol > li {
    &:last-of-type {
      color: var(--ckr-blue-6);
    }
  }
`;
const BreadcrumbSubMenuTable = {
  [MAIN]: MSG_HOME,
  [ANALYSIS]: MSG_ANALYSIS,
  [COMMON_LOG]: Main.service.log.title,
  [NEW]: 'New Analysis Function',
  [EDIT]: 'Edit Analysis Function',
  [LOG]: Common.LOG_SETTING,

  //Tact SubMenu
  [TACT]: MESSAGE.TACT,
  [SETTINGS]: MESSAGE.TACT_SETTING,
  [STATUS_MONITOR]: MESSAGE.STATUS_MONITOR,
  [MEMORY_DUMP]: MESSAGE.MEMORY_DUMP,
  //overlay
  [OVERLAY]: MESSAGE.OVERLAY_,
  [ADC_MEASUREMENT]: MESSAGE.OVERLAY_ADC,
  [CORRECTION]: MESSAGE.OVERLAY_CORRECTION,
};
const BreadcrumbMenuUrl = {
  [MSG_HOME]: URL_MAIN,
};

const BreadcrumbIconTable = {
  [MSG_HOME]: <HomeOutlined />,
};

const CustomBreadcrumb = () => {
  const location = useLocation();
  const List = useMemo(() => {
    const pathList = location.pathname.split(SLICE);
    const sList = [];
    console.log('pathList', pathList);
    pathList.forEach((item) => {
      if (item.length > 0 && (BreadcrumbSubMenuTable?.[item] ?? false)) {
        sList.push(BreadcrumbSubMenuTable[item]);
      }
    });
    console.log('List', sList);
    return sList;
  }, [location.pathname]);

  const getBreadcrumbString = (item) => {
    return (
      <>
        {BreadcrumbIconTable[item] ?? ''} {item}
      </>
    );
  };

  return (
    <div css={breadcrumbWrapper}>
      <Breadcrumb>
        {List?.map((item, i) => (
          <Breadcrumb.Item key={i}>
            {BreadcrumbMenuUrl[item] ?? false ? (
              <Link to={BreadcrumbMenuUrl[item]}>
                {getBreadcrumbString(item)}
              </Link>
            ) : (
              getBreadcrumbString(item)
            )}
          </Breadcrumb.Item>
        )) ?? <></>}
      </Breadcrumb>
    </div>
  );
};
export default CustomBreadcrumb;
