import React, { useMemo } from 'react';
import { css } from '@emotion/react';
import { useLocation, Link } from 'react-router-dom';
import { Breadcrumb } from 'antd';
import { MESSAGE, MSG_ANALYSIS, MSG_HOME } from '@constants/Message';
import {
  ADC_MEASUREMENT,
  ANALYSIS,
  COMMON_LOG,
  CORRECTION,
  EDIT,
  MAIN,
  MEMORY_DUMP,
  NEW,
  OVERLAY,
  SETTINGS,
  SLICE,
  STATUS_MONITOR,
  TACT,
  URL_MAIN,
  LOG,
  CONFIGURATION,
  LOG_DEFINE,
  NEW_LOG,
  NEW_RULE,
  EDIT_RULE,
  OAS_BASELINE,
  FOCUS,
  FOCUS_ANALYSIS,
  PRESCAN_COE,
} from '@constants/URL';
import { HomeOutlined } from '@ant-design/icons';
import { Main, Common, Config } from '@assets/locale/en';

const breadcrumbWrapper = css`
  font-weight: 600;
  padding: 1rem 0.5rem;
  & > div > span {
    color: var(--ckr-blue-9);
    &:last-of-type {
      color: var(--ckr-blue-6);
    }
  }
  & > nav > ol > li {
    &:last-of-type {
      color: var(--ckr-blue-6);
    }
  }
`;
const BreadcrumbSubMenuTable = {
  [MAIN]: MSG_HOME,
  [ANALYSIS]: MSG_ANALYSIS,
  [COMMON_LOG]: Main.service.log.title,
  [NEW]: 'New Analysis Function',
  [EDIT]: 'Edit Analysis Function',
  [LOG]: Common.LOG_SETTING,
  [CONFIGURATION]: Config.main.title,

  //log-define SubMenu
  [LOG_DEFINE]: Config.logDefine.title,
  [NEW_LOG]: Config.logDefine.breadcrumb.new_log,
  [NEW_RULE]: Config.logDefine.breadcrumb.new_rule,
  [EDIT_RULE]: Config.logDefine.breadcrumb.edit_rule,

  //Tact SubMenu
  [TACT]: MESSAGE.TACT,
  [SETTINGS]: MESSAGE.TACT_SETTING,
  [STATUS_MONITOR]: MESSAGE.STATUS_MONITOR,
  [MEMORY_DUMP]: MESSAGE.MEMORY_DUMP,
  //overlay
  [OVERLAY]: MESSAGE.OVERLAY_,
  [ADC_MEASUREMENT]: MESSAGE.OVERLAY_ADC,
  [CORRECTION]: MESSAGE.OVERLAY_CORRECTION,
  [OAS_BASELINE]: MESSAGE.OVERLAY_OASBASELINE,
  //focus
  [FOCUS]: MESSAGE.FOCUS,
  [FOCUS_ANALYSIS]: MESSAGE.ANALYSIS,
  [PRESCAN_COE]: MESSAGE.FOCUS_PRESCAN_COE,
};
const BreadcrumbMenuUrl = {
  [MSG_HOME]: URL_MAIN,
};

const BreadcrumbIconTable = {
  [MSG_HOME]: <HomeOutlined />,
};

const CustomBreadcrumb = () => {
  const location = useLocation();
  const List = useMemo(() => {
    const pathList = location.pathname.split(SLICE);
    const sList = [];
    console.log('pathList', pathList);
    pathList.forEach((item) => {
      if (item.length > 0 && (BreadcrumbSubMenuTable?.[item] ?? false)) {
        sList.push(BreadcrumbSubMenuTable[item]);
      }
    });
    console.log('List', sList);
    return sList;
  }, [location.pathname]);

  const getBreadcrumbString = (item) => {
    return (
      <>
        {BreadcrumbIconTable[item] ?? ''} {item}
      </>
    );
  };

  return (
    <div css={breadcrumbWrapper}>
      <Breadcrumb>
        {List?.map((item, i) => (
          <Breadcrumb.Item key={i}>
            {BreadcrumbMenuUrl[item] ?? false ? (
              <Link to={BreadcrumbMenuUrl[item]}>
                {getBreadcrumbString(item)}
              </Link>
            ) : (
              getBreadcrumbString(item)
            )}
          </Breadcrumb.Item>
        )) ?? <></>}
      </Breadcrumb>
    </div>
  );
};
export default CustomBreadcrumb;
