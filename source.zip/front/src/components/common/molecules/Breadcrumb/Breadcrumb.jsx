import React, { useMemo } from 'react';
import { css } from '@emotion/react';
import { matchPath, useLocation } from 'react-router';
import { Breadcrumb } from 'antd';
import {
  MSG_ANALYSIS,
  MSG_HOME,
  MSG_MEMORY_DUMP,
  MSG_OVERLAY,
  MSG_STATUS_MONITOR,
  MSG_TACT,
  MSG_TACT_SETTING,
} from '../../../../constants/Message';
import {
  ANALYSIS,
  MEMORY_DUMP,
  OVERLAY,
  SETTINGS,
  SLICE,
  STATUS_MONITOR,
  TACT,
} from '../../../../constants/URL';
import { HomeOutlined } from '@ant-design/icons';

const breadcrumbWrapper = css`
  margin-bottom: 1rem;
  padding: 1rem 0.5rem;
  border-radius: 8px;
  background: aliceblue;
  box-shadow: 0 2px 4px 2px #d7e4ef;
  & > div > span {
    color: #003a8c;
    &:last-of-type {
      color: #1890ff;
    }
  }
`;
const BreadcrumbSubMenuTable = {
  //Tact SubMenu
  [SETTINGS]: MSG_TACT_SETTING,
  [STATUS_MONITOR]: MSG_STATUS_MONITOR,
  [MEMORY_DUMP]: MSG_MEMORY_DUMP,
};
const BreadcrumbIconTable = {
  [MSG_HOME]: <HomeOutlined />,
};

const customBreadcrumb = () => {
  const location = useLocation();
  const List = useMemo(() => {
    const pathList = location.pathname.split(SLICE);
    const List = [MSG_HOME];
    console.log('pathList', pathList);
    pathList.forEach((item) => {
      switch (SLICE.concat(item)) {
        case ANALYSIS:
          List.push(MSG_ANALYSIS);
          break;
        case OVERLAY:
          List.push(MSG_OVERLAY);
          break;
        case TACT:
          {
            const submenu = matchPath(location.pathname, {
              path: `${TACT}/:sub`,
              extra: true,
            });
            List.push(MSG_TACT);
            List.push(BreadcrumbSubMenuTable[SLICE.concat(submenu.params.sub)]);
          }
          break;
      }
    });
    return List;
  }, [location.pathname]);

  return (
    <>
      <div css={breadcrumbWrapper}>
        <Breadcrumb>
          {List?.map((item) => (
            <>
              <Breadcrumb.Item>
                {BreadcrumbIconTable[item] ?? ''} {item}
              </Breadcrumb.Item>
            </>
          )) ?? <></>}
        </Breadcrumb>
      </div>
    </>
  );
};
export default customBreadcrumb;
