import React, { useState, useRef, useEffect } from 'react';
import { UpOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';

const accordionStyle = ({ height, titleBgColor, titleBdBottomColor }) => css`
  position: relative;
  width: 100%;
  & > div {
    width: 100%;
    &:first-of-type {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem;
      background-color: ${titleBgColor};
      cursor: pointer;
      border-radius: 4px 4px 0 0;
      & > .title-wrapper {
        display: flex;
        column-gap: 1rem;
        align-items: center;
        & > .title {
          font-size: 16px;
        }
      }
      & svg {
        transition: all 0.5s;
      }
    }
    &:last-of-type {
      height: ${height};
      transition: all 0.5s ease-in-out;
      overflow: hidden;
      border-radius: 0 0 4px 4px;
      & > .contents {
        padding: 1rem;
        border-radius: 0 0 4px 4px;
      }
    }
  }
  &.collapsed {
    &.quick-view {
      border: 1px solid var(--ckr-gray-5);
      border-radius: 4px;
      & > div:first-of-type {
        border-radius: 0 0 4px 4px;
        border-bottom: 1px solid ${titleBdBottomColor};
      }
    }
    & > div {
      &:first-of-type {
        & > .anticon {
          & svg {
            transform: rotate(180deg);
          }
        }
      }
      &:last-of-type {
        height: 0px;
        & > .contents {
          background-color: #fbfbfb;
        }
      }
    }
  }
  &.quick-view:not(.collapsed) {
    border: 1px solid var(--ckr-gray-5);
    border-radius: 4px;
    & > div {
      &:first-of-type {
        border-bottom: 1px solid ${titleBdBottomColor};
      }
      &:last-of-type {
        & > .contents {
          background-color: #fbfbfb;
          border-radius: 0 0 4px 4px;
        }
      }
    }
  }
`;

const CustomAccordion = ({
  title,
  children,
  defaultValue,
  quickView,
  icon,
  titleBgColor,
  titleBorder,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(defaultValue);
  const [contentsHeight, setContentsHeight] = useState('fit-content');
  const contentsRef = useRef(null);

  const createClassName = () => {
    let newClassName = '';
    if (isCollapsed) {
      newClassName = 'collapsed';
    }
    if (quickView) {
      newClassName += ' quick-view';
    }
    return newClassName;
  };

  useEffect(() => {
    if (contentsRef.current !== null) {
      setContentsHeight(`${contentsRef.current.offsetHeight}px`);
    }
  }, [contentsRef]);

  return (
    <div
      css={accordionStyle({
        height: contentsHeight,
        titleBgColor,
        titleBdBottomColor: titleBorder ? 'var(--ckr-gray-5)' : 'transparent',
      })}
      className={createClassName()}
    >
      <div
        onClick={() => setIsCollapsed(!isCollapsed)}
        onKeyDown={undefined}
        role="button"
        tabIndex="-1"
      >
        <div className="title-wrapper">
          {icon}
          <span className="title">{title}</span>
        </div>
        <UpOutlined />
      </div>
      <div>
        <div className="contents" ref={contentsRef}>
          {children}
        </div>
      </div>
    </div>
  );
};
CustomAccordion.displayName = 'CustomAccordion';
CustomAccordion.propTypes = {
  title: PropTypes.string,
  children: PropTypes.node.isRequired,
  defaultValue: PropTypes.bool,
  quickView: PropTypes.bool,
  icon: PropTypes.node,
  titleBgColor: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  titleBorder: PropTypes.bool,
};
CustomAccordion.defaultProps = {
  defaultValue: false,
  quickView: false,
  icon: undefined,
  titleBgColor: 'var(--ckr-gray-3)',
  titleBorder: true,
};

export default CustomAccordion;
