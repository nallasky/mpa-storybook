import React, { useState } from 'react';
import { DownOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';

const accordionStyle = css`
  position: relative;
  width: 100%;
  & > div {
    width: 100%;
    &:first-of-type {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem;
      background-color: #f5f5f5;
      cursor: pointer;
      & > .title {
        font-size: 18px;
      }
      & svg {
        transition: all 0.5s;
      }
    }
    &:last-of-type {
      max-height: 800px;
      transition: all 0.7s;
      overflow: hidden;
      & > .contents {
        padding: 1rem;
      }
    }
  }
  &.collapsed {
    &.quick-view {
      border: 1px solid #dadada;
      border-radius: 4px;
      & > div:first-of-type {
        border-bottom: 1px solid #dadada;
        border-radius: 4px;
      }
    }
    & > div {
      &:first-of-type {
        & svg {
          transform: rotate(180deg);
        }
      }
      &:last-of-type {
        max-height: 0;
      }
    }
  }
  &.quick-view:not(.collapsed) {
    border: 1px solid #dadada;
    border-radius: 4px;
    & > div {
      &:first-of-type {
        border-radius: 4px 4px 0 0;
        border-bottom: 1px solid #dadada;
      }
      &:last-of-type {
        max-height: 1000px;
        & > .content {
          background-color: #fbfbfb;
          border-radius: 0 0 4px 4px;
        }
      }
    }
  }
`;

const CustomAccordion = ({ title, children, defaultValue, quickView }) => {
  const [isCollapsed, setIsCollapsed] = useState(defaultValue);

  return (
    <div
      css={accordionStyle}
      className={
        (isCollapsed ? 'collapsed' : '') + (quickView ? ' quick-view' : '')
      }
    >
      <div
        onClick={() => setIsCollapsed(!isCollapsed)}
        onKeyDown={undefined}
        role="button"
        tabIndex="-1"
      >
        <span className="title">{title}</span>
        <DownOutlined />
      </div>
      <div>
        <div className="contents">{children}</div>
      </div>
    </div>
  );
};
CustomAccordion.displayName = 'OverlaySettingAccordion';
CustomAccordion.propTypes = {
  title: PropTypes.string,
  children: PropTypes.node.isRequired,
  defaultValue: PropTypes.bool,
  quickView: PropTypes.bool,
};
CustomAccordion.defaultProps = {
  defaultValue: true,
  quickView: false,
};

export default CustomAccordion;
