import React, { useState } from 'react';
import { css } from '@emotion/react';
import { Button, Popconfirm } from 'antd';
import PropTypes from 'prop-types';
import { DeleteOutlined } from '@ant-design/icons';
import { MSG_CONFIRM_DELETE } from '../../../../constants/Message';

const buttonStyle = css`
  transition: all 0.3s;
  background-color: transparent;
  border-radius: 50%;
  border-style: dashed;
  &:hover {
    border: 1px dashed var(--ckr-blue-6) !important;
    & > .anticon {
      color: var(--ckr-blue-6);
      & > svg {
        filter: drop-shadow(0px 2px 3px rgba(0, 0, 0, 0.6));
      }
    }
  }
  &.filter-off:hover svg {
    filter: none;
  }
  &:not(.filter-off) {
    border-color: transparent;
  }
  & > .anticon {
    transition: all 0.3s;
  }
`;

const DeleteButton = ({
  deleteHandler,
  title,
  icon,
  disabled,
  type,
  onMouseHandler,
  mouseHandlerIndex,
}) => {
  const [isSelected, setIsSelected] = useState(false);

  return (
    <Popconfirm
      title={title}
      onConfirm={deleteHandler}
      onCancel={(e) => e.stopPropagation()}
      disabled={disabled ?? false}
      onVisibleChange={(v) => setIsSelected(v)}
    >
      <Button
        css={[
          buttonStyle,
          isSelected
            ? { border: '1px dashed var(--ckr-blue-6) !important' }
            : '',
          type === 'dashed' ? { borderRadius: '2px' } : '',
        ]}
        className={type === 'dashed' ? 'filter-off' : ''}
        type="dashed"
        icon={icon}
        disabled={disabled ?? false}
        onClick={(e) => e.stopPropagation()}
        onMouseOver={() =>
          onMouseHandler ? onMouseHandler(mouseHandlerIndex, true) : undefined
        }
        onMouseOut={() =>
          onMouseHandler ? onMouseHandler(mouseHandlerIndex, false) : undefined
        }
      />
    </Popconfirm>
  );
};

DeleteButton.propTypes = {
  type: PropTypes.string,
  title: PropTypes.string,
  deleteHandler: PropTypes.func,
  icon: PropTypes.node,
  disabled: PropTypes.bool,
  onMouseHandler: PropTypes.func,
  mouseHandlerIndex: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
};

DeleteButton.defaultProps = {
  type: 'dashed',
  title: MSG_CONFIRM_DELETE,
  icon: <DeleteOutlined />,
  disabled: false,
};

export default DeleteButton;
