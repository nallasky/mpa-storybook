import React, { useState } from 'react';
import styled from '@emotion/styled';
import PropTypes from 'prop-types';
import { PlusCircleOutlined } from '@ant-design/icons';
import { Input, Divider } from 'antd';

const MainWrapper = styled.div`
  display: flex;
  align-items: center;
  column-gap: 8px;
  padding: 0 8px;

  @keyframes shadow {
    50% {
      box-shadow: none;
      border-color: var(--ckr-gray-5);
    }
  }

  & > .input-error {
    animation: shadow 1s ease-in-out infinite;
    box-shadow: 0px 0px 3px 1px red;
    border-color: red;
  }

  & > button {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-size: 16px;
    padding: 2px;
    outline: none;
    border-color: transparent;
    background-color: transparent;
    & > span {
      transition: all 0.5s;
      & > svg {
        stroke: var(--ckr-gray-13);
        stroke-width: 30px;
      }
    }
    &.error {
      cursor: not-allowed;
      & > span {
        transform: rotate(45deg);
        opacity: 0.5;
      }
    }
  }
`;

const CustomOptionListHeader = ({
  inputMaxLength,
  saveCallback,
  invalidCheckFunc,
}) => {
  const [inputVal, setInputVal] = useState('');
  const [inputError, setInputError] = useState(false);

  const onSave = () => {
    if (inputError) return;

    if (invalidCheckFunc(inputVal)) {
      setInputError(true);
    } else {
      saveCallback(inputVal);
      setInputVal('');
    }
  };

  return (
    <>
      <MainWrapper>
        <Input
          type="text"
          style={{ width: '100%' }}
          value={inputVal}
          onChange={(e) => {
            if (inputError) setInputError(false);
            setInputVal(e.target.value);
          }}
          maxLength={inputMaxLength}
          className={inputError ? 'input-error' : ''}
        />
        <button
          className={'button' + (inputError ? ' error' : '')}
          onClick={onSave}
        >
          <PlusCircleOutlined />
        </button>
      </MainWrapper>
      <Divider style={{ margin: '4px 0' }} />
    </>
  );
};
CustomOptionListHeader.propTypes = {
  inputMaxLength: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  saveCallback: PropTypes.func,
  invalidCheckFunc: PropTypes.func,
};
CustomOptionListHeader.defaultProps = {
  inputMaxLength: 30,
};

export default CustomOptionListHeader;
