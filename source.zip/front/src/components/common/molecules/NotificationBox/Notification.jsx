import React from 'react';
import { notification } from 'antd';
import PropTypes from 'prop-types';
import { WarningOutlined, CheckCircleOutlined } from '@ant-design/icons';

const NotificationBox = ({ title, message, time, style, isError }) => {
  notification.open({
    message: title,
    description: message,
    duration: time,
    icon: (
      <React.Fragment>
        {isError ?? true ? (
          <WarningOutlined style={{ color: 'red' }} />
        ) : (
          <CheckCircleOutlined style={{ color: 'green' }} />
        )}
      </React.Fragment>
    ),
    style:
      style ?? isError ?? true
        ? { borderLeft: '5px solid red' }
        : { borderLeft: '5px solid green' },
  });
};

NotificationBox.propTypes = {
  type: PropTypes.string,
  title: PropTypes.oneOfType([PropTypes.node, PropTypes.string]),
  message: PropTypes.oneOfType([PropTypes.node, PropTypes.string]),
  time: PropTypes.number,
  style: PropTypes.object,
  isError: PropTypes.bool,
};

NotificationBox.defaultProps = {
  type: 'info',
  title: 'title',
  message: 'message',
  time: 4.5,
  isError: true,
};

export default NotificationBox;
