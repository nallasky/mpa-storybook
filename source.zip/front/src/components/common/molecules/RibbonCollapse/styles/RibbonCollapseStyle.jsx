import { css } from '@emotion/react';
import styled from '@emotion/styled';

export const CollapseStyle = styled.div`
  position: relative;
  padding: 2rem 1rem;
  border: 1px solid var(--ckr-blue-3);
  margin: 0 2.5rem;
  margin-right: 1rem;
  border-radius: 0 4px 4px 4px;
  padding-bottom: 13px;
  margin-bottom: 40px;
  margin-top: 2rem;
  & .title-button {
    justify-content: space-between;
    padding: 1rem;
    white-space: pre;
    width: auto;
    min-width: 200px;
    & > span {
      margin-left: 10px;
    }
  }
  & > .contents {
    width: 100%;
    max-height: 0;
    overflow: hidden;
    &.expand {
      display: grid;
      ${(props) => props.useGrid && 'grid-template-columns: 1.2fr 8.8fr;'};
      max-height: 1000px;
      overflow: unset;
      & .svg-box {
        display: flex;
        align-items: center;
        justify-content: center;
        & span > svg {
          width: 70px;
          height: 70px;
          left: 50px;
          top: 30px;
          color: var(--ckr-blue-9);
        }
      }
    }
  }
`;

export const RibbonStyle = css`
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  width: 200px;
  height: 41px;
  left: -26px;
  top: -22px;
  background: var(--ckr-blue-5);
  border-radius: 6px 6px 6px 0;
  cursor: pointer;
  color: white;
  transition: all 0.5s;
  &::after {
    position: absolute;
    left: 0;
    top: 41px;
    border: 13px solid var(--ckr-blue-9);
    z-index: 5;
    border-left-color: transparent;
    border-bottom-color: transparent;
    content: '';
  }
  & > div {
    display: none;
  }
  &:hover {
    background-color: var(--ckr-blue-4);
  }
`;
