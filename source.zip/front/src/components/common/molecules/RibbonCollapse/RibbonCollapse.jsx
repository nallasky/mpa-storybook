import React, { useState } from 'react';
import * as SS from './styles/RibbonCollapseStyle';
import PropTypes from 'prop-types';
import { DownOutlined, UpOutlined } from '@ant-design/icons';

export const RibbonCollapse = ({ title, children, useGrid }) => {
  const [isCollapsed, setIsCollapsed] = useState(true);

  return (
    <SS.CollapseStyle useGrid={useGrid}>
      <div
        css={SS.RibbonStyle}
        role="button"
        tabIndex="-1"
        onClick={() => setIsCollapsed(!isCollapsed)}
        onKeyDown={undefined}
        className="title-button"
      >
        {title}
        {isCollapsed === true ? <DownOutlined /> : <UpOutlined />}
      </div>
      <div className={'contents' + (isCollapsed ? '' : ' expand')}>
        {children}
      </div>
    </SS.CollapseStyle>
  );
};
RibbonCollapse.propTypes = {
  title: PropTypes.string,
  children: PropTypes.node.isRequired,
  defaultValue: PropTypes.bool,
  icon: PropTypes.node,
  useGrid: PropTypes.bool,
};
RibbonCollapse.defaultProps = {
  defaultValue: false,
  icon: undefined,
  useGrid: true,
};
