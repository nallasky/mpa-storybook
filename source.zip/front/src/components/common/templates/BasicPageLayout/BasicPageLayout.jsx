import React from 'react';
import { css } from '@emotion/react';
import PropTypes from 'prop-types';

const sectionStyle = css`
  position: relative;
  width: 1440px;
  animation: fadeIn 1s;
  margin: 1rem 0;
`;

const BasicPageLayout = ({ children }) => {
  return <section css={sectionStyle}>{children}</section>;
};

BasicPageLayout.propTypes = {
  children: PropTypes.node,
};

export default BasicPageLayout;
