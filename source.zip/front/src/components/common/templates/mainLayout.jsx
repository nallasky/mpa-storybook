import React from 'react';
import { css } from '@emotion/react';
import PropTypes from 'prop-types';
import { Layout as AntdLayout } from 'antd';

const {
  Header: AntdHeader,
  Content: AntdContent,
  Footer: AntdFooter,
} = AntdLayout;

/*****************************************************************************
 *               Main Layout
 *****************************************************************************/

const style = css`
  position: relative;
  width: 100%;
  min-height: 100vh;
  background-color: transparent;
`;

const AppLayout = ({ children }) => {
  return <AntdLayout css={style}>{children}</AntdLayout>;
};

AppLayout.propTypes = {
  children: PropTypes.node,
};

/*****************************************************************************
 *               Header
 *****************************************************************************/

const headerStyle = css`
  min-width: 1536px;
  position: sticky;
  z-index: 300;
  background-color: var(--ckr-gray-13);
  left: 0;
  top: 0;
  display: flex;
  justify-content: center;
  padding: 0;
`;

const Header = ({ children }) => {
  return <AntdHeader css={headerStyle}>{children}</AntdHeader>;
};

Header.propTypes = {
  children: PropTypes.node,
};

/*****************************************************************************
 *               Contents
 *****************************************************************************/

const contentStyle = css`
  min-width: 1536px;
  position: relative;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  & .category-wrapper + .category-wrapper {
    margin-top: 3rem;
  }
`;

const Contents = ({ children }) => {
  return <AntdContent css={contentStyle}>{children}</AntdContent>;
};

Contents.propTypes = {
  children: PropTypes.node,
};

/*****************************************************************************
 *               Footer
 *****************************************************************************/

const footerStyle = css`
  min-width: 1536px;
  position: relative;
  bottom: 0;
  left: 0;
  text-align: center;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 300;
  height: 64px;
  background-color: var(--ckr-gray-13);
  & button {
    color: var(--ckr-blue-6);
  }
`;
const Footer = ({ children }) => {
  return <AntdFooter css={footerStyle}>{children}</AntdFooter>;
};

Footer.propTypes = {
  children: PropTypes.node,
};

AppLayout.Header = Header;
AppLayout.Content = Contents;
AppLayout.Footer = Footer;

export default AppLayout;
