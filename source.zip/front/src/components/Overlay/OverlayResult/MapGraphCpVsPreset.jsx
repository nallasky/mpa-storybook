import React from 'react';
import { Button, Popconfirm, Select, Spin, Tooltip } from 'antd';
import * as SG from './styles/OverlayResultStyle';
import {
  MESSAGE,
  MSG_DEFAULT,
  MSG_NEW_PRESET,
  MSG_PRESET,
  MSG_SAVE_PRESET,
  MSG_UPDATE_PRESET,
} from '../../../constants/Message';
import { DeleteOutlined } from '@ant-design/icons';
import InputForm from '../../common/atoms/Input/InputForm';
import { CommonRegex } from '../../../libs/util/regExp';
import { css } from '@emotion/react';
import QuestionCircleOutlined from '@ant-design/icons/lib/icons/QuestionCircleOutlined';
import { useMapGraphCpvs } from './hooks/useMapGraphCpvs';
import { E_Default, E_New } from '@constants/etc';
import { useMapGraphCpvsPreset } from './hooks/useMapGraphCpvsPreset';

const { Option } = Select;

const contentsStyle = css`
  & .ant-form-item {
    margin-bottom: 0px;
  }
`;
const MapGraphCpVsPreset = () => {
  const { cpvs_setting } = useMapGraphCpvs();
  const { savePreset, loading, preset, selectPreset, deletePreset, setPreset } =
    useMapGraphCpvsPreset();

  console.log('MapGraphCpVsOption');
  return (
    <>
      <Spin tip="Loading..." spinning={loading.status}>
        <div
          css={SG.contentItemStyle}
          className="column-3"
          style={{ paddingBottom: '10px' }}
        >
          <Tooltip
            placement="topLeft"
            title={MESSAGE.TABLE_NAME_REGEXP}
            arrowPointAtCenter
          >
            <span className="label">{MSG_PRESET}</span>
            <QuestionCircleOutlined
              style={{ marginLeft: '4px', color: 'rgb(24 144 255)' }}
            />
          </Tooltip>
          <Select
            style={{ width: '100%' }}
            onChange={(v) => selectPreset(v)}
            value={preset.id}
          >
            <Option value={E_Default} key={`option_default`}>
              {MSG_DEFAULT}
            </Option>
            ;
            {Object.entries(cpvs_setting?.preset ?? {}).map(([id, title]) => (
              <Option value={+id} key={`option_${id}`}>
                {' '}
                {title}
                <Popconfirm
                  title={`Are you sure to delete Preset [${title}] ? `}
                  onConfirm={(e) => {
                    e.stopPropagation();
                    deletePreset(id);
                  }}
                >
                  <Button
                    type="text"
                    icon={<DeleteOutlined />}
                    style={{ float: 'right' }}
                    onClick={(e) => e.stopPropagation()}
                  />
                </Popconfirm>
              </Option>
            ))}
            <Option value={E_New} key={`option_new`}>
              {MSG_NEW_PRESET}
            </Option>
            ;
          </Select>
          <div className="preset-setting" css={contentsStyle}>
            <InputForm.input
              formName={'Title'}
              placeholder="Enter preset name."
              value={preset.title}
              disabled={preset.id === E_Default}
              required={false}
              changeFunc={(e) =>
                setPreset({ ...preset, title: e?.Title ?? '' })
              }
              regExp={[
                {
                  pattern: CommonRegex,
                  message: '',
                },
              ]}
            />
            <button
              css={SG.antdButtonStyle}
              className="white"
              onClick={savePreset}
              disabled={
                preset.id === E_Default || !CommonRegex.test(preset.title)
              }
            >
              {[E_Default, E_New].includes(preset.id)
                ? MSG_SAVE_PRESET
                : MSG_UPDATE_PRESET}
            </button>
          </div>
        </div>
      </Spin>
    </>
  );
};
export default MapGraphCpVsPreset;
