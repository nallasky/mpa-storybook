import { Fragment } from 'react';
import { Divider, Tag, Tooltip } from 'antd';
import { EditOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import * as SG from './styles/OverlayResultStyle';
import MapGraphEtcScaleModal from './MapGraphEtcScaleModal';
import useModal from '@libs/util/modalControl/useModal';
import { Overlay, Common } from '@assets/locale/en';
import { useMapGraphEtc } from './hooks/useMapGraphEtc';
import { E_OVERLAY_MAP } from '@constants/etc';

const {
  graph_setting: {
    map: {
      etc: { scale: message },
    },
  },
} = Overlay;

const MapGraphEtcScale = () => {
  const { openModal } = useModal();
  const { updateScaleSetting, div, plate_size, OverlayResultType } =
    useMapGraphEtc();
  const onClickEvent = () => {
    openModal(MapGraphEtcScaleModal, {
      origin: { div, plate_size },
      onSave: updateScaleSetting,
      type: OverlayResultType.id,
    });
  };
  console.log('OverlayResultType', OverlayResultType);
  return (
    <Fragment>
      <div className="content-box scale-button">
        <Divider className="divider-line" orientation="left">
          {message.label}
          <Tooltip className="title-tooltip" title={message.tooltip}>
            <QuestionCircleOutlined />
          </Tooltip>
        </Divider>
        <div className="content-button">
          <div>
            <button
              css={SG.antdButtonStyle}
              className="white edit"
              onClick={onClickEvent}
            >
              <EditOutlined />
              {Common.Btn_Edit}
            </button>
          </div>
        </div>
      </div>
      {/* -------------------div----------------------------------- */}
      <div css={SG.contentItemStyle} className="limit-box">
        <div className="limit-title">
          <Tag color="blue">{message.div.label}</Tag>
        </div>
        <div className="limit-box-scale">
          <div
            className={
              OverlayResultType.id !== E_OVERLAY_MAP
                ? 'flex-between limit-scale'
                : 'limit-right limit-scale'
            }
          >
            {OverlayResultType.id !== E_OVERLAY_MAP && (
              <div css={SG.contentItemStyle} className="flex-between">
                <Tag>{message.div.div_lower}</Tag> {div.div_lower}
              </div>
            )}
            <div css={SG.contentItemStyle} className="flex-between limit">
              <Tag>{message.div.div_upper}</Tag> {div.div_upper}{' '}
            </div>
          </div>
        </div>
      </div>
      {/* -------------------plate size----------------------------------- */}
      <div css={SG.contentItemStyle} className="limit-box">
        <div className="limit-title">
          <Tag color="blue">{message.plate_size.label}</Tag>
        </div>
        <div className="limit-box-scale">
          <div className="flex-between limit-scale ">
            <div css={SG.contentItemStyle} className="flex-between">
              <Tag>{message.plate_size.size_x}</Tag> {plate_size.size_x}
            </div>
            <div css={SG.contentItemStyle} className="flex-between limit">
              <Tag>{message.plate_size.size_y}</Tag> {plate_size.size_y}
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default MapGraphEtcScale;
