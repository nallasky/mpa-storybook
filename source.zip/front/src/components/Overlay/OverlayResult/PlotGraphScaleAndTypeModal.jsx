import { Fragment, useState } from 'react';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import { Segmented, InputNumber, Select, Divider } from 'antd';
import * as SG from './styles/OverlayResultStyle';
import PropTypes from 'prop-types';
import { Common, Overlay } from '@assets/locale/en';
import { BulbOutlined } from '@ant-design/icons';

const {
  graph_setting: {
    plot: {
      setting: { scale_type: message },
    },
  },
} = Overlay;
const scaleInitialValue = {
  scale: {
    type: '',
    upper_limit: '0',
    lower_limit: '0',
  },
  graph_type: 'line',
};
const MIN_SCALE = -999;
const MAX_SCALE = 999;
const PlotGraphScaleAndTypeModal = ({ origin, min, max, onSave, onClose }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [scaleAndType, setScaleAndType] = useState(origin ?? scaleInitialValue);
  const modalClose = () => {
    setIsVisible(false);
    onClose();
  };
  const modalOk = () => {
    onSave(scaleAndType);
    modalClose();
  };
  const ChangeGraphScale = (key, value) => {
    setScaleAndType((prev) => ({
      ...prev,
      scale: { ...prev.scale, [key]: value },
    }));
  };
  const ChangeGraphType = (v) => {
    setScaleAndType((prev) => ({
      ...prev,
      graph_type: v,
    }));
  };
  console.log('scaleAndType', scaleAndType);
  return (
    <Fragment>
      <DraggableModal
        visible={isVisible}
        title={message.label}
        width={500}
        footer={
          <div className="model-button">
            <button css={SG.antdButtonStyle} className="blue" onClick={modalOk}>
              {Common.Btn_Apply}
            </button>
          </div>
        }
        centered
        maskClosable={false}
        cancelHandler={modalClose}
        css={SG.SegmentedStyle}
      >
        <div className="message-box">
          <BulbOutlined />
          <span>{message.msssage}</span>
        </div>

        <div className="segmented-content">
          <div className="segmented-style">
            <div className="segmented-box">
              <div style={{ width: '100%' }}>
                <Divider className="divider-line" orientation="left">
                  {message.graph_type.label}
                </Divider>
                <div className="content-right">
                  <Select
                    style={{ width: '13rem' }}
                    value={scaleAndType.graph_type}
                    onChange={ChangeGraphType}
                  >
                    <Select.Option value="line">
                      {message.graph_type.options.line}
                    </Select.Option>
                    <Select.Option value="scatter">
                      {message.graph_type.options.scatter}
                    </Select.Option>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="segmented-content">
          <div className="segmented-style">
            <Divider className="divider-line" orientation="left">
              {message.left_scale.label}
            </Divider>
            <div className="segmented-box" style={{}}>
              <Segmented
                onChange={(v) => ChangeGraphScale('type', v)}
                value={scaleAndType.scale?.type ?? ''}
                options={[
                  {
                    label: `${message.left_scale.type.options.auto}`,
                    value: 'auto',
                  },
                  {
                    label: `${message.left_scale.type.options.manual}`,
                    value: 'manual',
                  },
                ]}
              />
            </div>
            <div css={SG.contentItemStyle}>
              <div className="tx-center">
                <span className="margin-r">
                  {message.left_scale.lower_limit}
                </span>
                <InputNumber
                  min={min ?? MIN_SCALE}
                  max={max ?? MAX_SCALE}
                  disabled={scaleAndType.scale.type === 'auto'}
                  value={scaleAndType.scale.lower_limit}
                  onChange={(v) => ChangeGraphScale('lower_limit', v)}
                />
                <span className="margin-lr">
                  {message.left_scale.upper_limit}
                </span>
                <InputNumber
                  min={min ?? MIN_SCALE}
                  max={max ?? MAX_SCALE}
                  disabled={scaleAndType.scale.type === 'auto'}
                  value={scaleAndType.scale.upper_limit}
                  onChange={(v) => ChangeGraphScale('upper_limit', v)}
                />
              </div>
            </div>
          </div>
        </div>
      </DraggableModal>
    </Fragment>
  );
};
PlotGraphScaleAndTypeModal.propTypes = {
  origin: PropTypes.object.isRequired,
  onSave: PropTypes.func,
  onClose: PropTypes.func,
  min: PropTypes.number,
  max: PropTypes.number,
};

export default PlotGraphScaleAndTypeModal;
