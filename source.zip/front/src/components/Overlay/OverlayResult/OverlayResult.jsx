import React, { useEffect, useState } from 'react';
import * as SG from './styles/OverlayResultStyle';
import OverlayResultDownload from './OverlayResultDownload';
import { E_OVERLAY_ANOVA } from '@constants/etc';
import CustomRadioGroup from '../../common/molecules/CustomRadioGroup/CustomRadioGroup';
import OverlayResultGraph from './OverlayResultGraph';
import OverlayResultSetting from './OverlayResultSetting';
import { useOverlayResult } from '@components/Overlay/hooks/useOverlayResult';
import useCommonOverlay, {
  OverlayResultInfo,
} from '@components/Overlay/hooks/useCommonOverlay';

export const OverlayResult = () => {
  const [updateDisplay, setUpdateDisplay] = useState(undefined);

  const {
    OverlayResultType,
    OverlayResultTypeList,
    setOverlayResultType,
    updateResultType,
    getResultTypeList,
  } = useOverlayResult();
  const {
    mode,
    currentData: { info },
  } = useCommonOverlay();
  const { origin } = info;

  useEffect(() => {
    console.log('updateResultType', mode, origin);
    if (mode && origin) {
      const list = getResultTypeList(origin, mode).map((graph) => graph?.id);
      if (
        !list.includes(OverlayResultType?.id) ||
        OverlayResultTypeList.length !== list.length
      )
        updateResultType(mode);
    } else if (!origin) {
      updateResultType(mode);
    }
  }, [origin]);

  if (!origin || !OverlayResultTypeList.length) return <></>;

  return (
    <OverlayResultInfo.Provider
      value={{
        OverlayResultType,
        OverlayResultTypeList,
        updateDisplay,
        setUpdateDisplay,
        origin_data: origin,
      }}
    >
      <div css={SG.componentStyle} className="span">
        <div css={SG.controlStyle}>
          <CustomRadioGroup
            changeFunc={(e) => setOverlayResultType(e)}
            currentChecked={OverlayResultType.id}
            options={OverlayResultTypeList}
            name="result-type"
          />
          <div css={SG.customButtonStyle}>
            <OverlayResultDownload />
          </div>
        </div>
        {OverlayResultType?.id ? (
          <>
            {OverlayResultType.id !== E_OVERLAY_ANOVA && (
              <div css={SG.settingStyle}>
                <OverlayResultSetting />
              </div>
            )}
            <div css={SG.resultStyle}>
              <OverlayResultGraph />
            </div>
          </>
        ) : (
          <></>
        )}
      </div>
    </OverlayResultInfo.Provider>
  );
};

export default OverlayResult;
