import { useEffect, useState, Fragment } from 'react';
import * as SG from './styles/OverlayResultStyle';
import { MSG_RE_START } from '@constants/Message';
import {
  E_OVERLAY_COMPONENT,
  E_OVERLAY_GRAPH_ALL,
  E_OVERLAY_IMAGE,
  E_OVERLAY_MAP,
  E_OVERLAY_PLOT,
  E_OVERLAY_REPRODUCIBILITY,
  E_OVERLAY_VARIATION,
  OVERLAY_CORRECTION_CATEGORY,
} from '@constants/etc';
import useOverlaySettingInfo from '../../../hooks/common/useOverlaySettingInfo';
import useModal from '../../../libs/util/modalControl/useModal';
import { PlayCircleOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import useOverlayResultInfo from '../../../hooks/common/useOverlayResultInfo';
import ProcessingModal from '../../common/organisms/ProcessingModal/ProcessingModal';
import Coordinate from '@assets/arrows_icon.svg';
import { Button, Popover } from 'antd';
import { css } from '@emotion/react';
import GraphColorSetting from './GraphColor/GraphColorSetting';
import MapGraphCpvs from './MapGraph/MapGraphCpvs';
import ReproducibilityGraphSetting from './ReproducibilityGraph/ReproducibilityGraphSetting';
import { useOverlayGraph } from '../hooks/useOverlayGraph';
import PlotGraphSetting from './PlotGraph/PlotGraphSetting';
import VariationGraphSetting from './VariationGraph/VariationGraphSetting';
import MapGraphOffset from './MapGraph/MapGraphOffset';
import MapGraphEtcSetting from './MapGraph/MapGraphEtcSetting';
import useCommonOverlay from '../hooks/useCommonOverlay';
import { useGraphReAnalysis } from './hooks/useGraphReAnalysis';
const coordinate_style = css`
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 75%;
`;

const coordinateImgStyle = css`
  font-weight: 700;
  & img {
    transform: rotate(135deg);
    padding: 3rem;
  }
`;
const ResultGraphSetting = () => {
  const { getReAnalysisParameter } = useOverlaySettingInfo();
  const { mode, currentData } = useCommonOverlay();
  const {
    updateDisplay,
    setUpdateDisplay,
    OverlayResultType: type,
  } = useOverlayGraph();
  const {
    info: { origin },
  } = currentData;
  const { reAnalysisStartFunc, reAnalysisCancel, cancelRef } =
    useGraphReAnalysis();
  const { gCorrectionMap, gMap, gOasBaseLineMap } = useOverlayResultInfo();
  const { openModal, closeModal } = useModal();
  const [reStart, setRestart] = useState(false);
  const [isReAnalysis, setReAnalysis] = useState(false);

  const reAnalysis = () => {
    const displayMode =
      mode === OVERLAY_CORRECTION_CATEGORY ? E_OVERLAY_GRAPH_ALL : type.id;
    if (isReAnalysis === false) {
      openModal(ProcessingModal, {
        title: 'Graph drawing',
        message: 'just moment please',
      });
      setTimeout(() => setUpdateDisplay(displayMode), 1000);
    } else {
      reAnalysisStartFunc({
        param: getReAnalysisParameter(mode, currentData),
      });
      console.log({ cancelRef });
      openModal(ProcessingModal, {
        title: 'Analysing',
        message: 'Analysing data',
        useCancel: true,
        onCancel: reAnalysisCancel,
      });
    }
  };
  useEffect(() => {
    if (reStart === false) {
      console.log('enable re-start');
      setRestart(true);
    }
  }, [gMap, gCorrectionMap, gOasBaseLineMap]);

  useEffect(() => {
    if (origin) {
      setReAnalysis(true);
      console.log('need Analysis process!!!');
    }
  }, [gMap.cp_vs, gCorrectionMap.cp_vs, gOasBaseLineMap.cp_vs]);

  useEffect(() => {
    console.log('[ResultGraphSetting] updateDisplay', updateDisplay);
    if (!updateDisplay) {
      setReAnalysis(false);
      setRestart(false);
      closeModal(ProcessingModal);
      console.log('Analysis process!!! completed');
    }
  }, [updateDisplay]);

  const CoordinateContent = (
    <div css={coordinateImgStyle}>
      <img src={Coordinate} alt={'Coordinate'} />
    </div>
  );

  return (
    <Fragment>
      <div className="header">
        <div className="coordinate_test">
          {[E_OVERLAY_IMAGE, E_OVERLAY_COMPONENT, E_OVERLAY_MAP].includes(
            type.id,
          ) ? (
            <span css={coordinate_style}>
              <Popover
                content={CoordinateContent}
                title="Coordinate"
                trigger="hover"
              >
                <Button
                  shape="circle"
                  type="text"
                  icon={<QuestionCircleOutlined />}
                />
              </Popover>
            </span>
          ) : (
            <Fragment />
          )}
        </div>
        {[E_OVERLAY_IMAGE, E_OVERLAY_COMPONENT, E_OVERLAY_MAP].includes(
          type.id,
        ) ? (
          <button
            css={SG.customButtonStyle}
            className="blue"
            onClick={reAnalysis}
            disabled={reStart === false}
          >
            <PlayCircleOutlined />
            <span>{MSG_RE_START}</span>
          </button>
        ) : (
          <Fragment />
        )}
      </div>
      <div className="main">
        {[E_OVERLAY_COMPONENT, E_OVERLAY_IMAGE, E_OVERLAY_MAP].includes(
          type.id,
        ) ? (
          <Fragment>
            <MapGraphOffset />
            <MapGraphCpvs />
            <MapGraphEtcSetting />
          </Fragment>
        ) : type.id === E_OVERLAY_VARIATION ? (
          <VariationGraphSetting />
        ) : type.id === E_OVERLAY_REPRODUCIBILITY ? (
          <ReproducibilityGraphSetting />
        ) : type.id === E_OVERLAY_PLOT ? (
          <Fragment>
            <PlotGraphSetting />
            <GraphColorSetting />
          </Fragment>
        ) : (
          <Fragment />
        )}
      </div>
    </Fragment>
  );
};
export default ResultGraphSetting;
