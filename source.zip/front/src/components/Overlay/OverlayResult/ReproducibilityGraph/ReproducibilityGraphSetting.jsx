import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
import { SettingOutlined } from '@ant-design/icons';
import * as SG from '../styles/OverlayResultStyle';
import { Overlay } from '@assets/locale/en';
import ReproductibilityGraphRangeSetting from './ReproductibilityGraphRangeSetting';
const {
  graph_setting: {
    reproducibility: { setting: message },
  },
} = Overlay;
const ReproducibilityGraphSetting = () => {
  return (
    <RibbonCollapse title={message.label} defaultValue={true}>
      <div className="svg-box">
        <SettingOutlined />
      </div>
      <div css={SG.settingContentStyle}>
        <div className="content">
          <div css={SG.contentItemStyle}>
            <ReproductibilityGraphRangeSetting />
          </div>
        </div>
      </div>
    </RibbonCollapse>
  );
};
export default ReproducibilityGraphSetting;
