import { Fragment } from 'react';
import { Divider, InputNumber, Tooltip, Tag } from 'antd';
import { Overlay } from '@assets/locale/en';
import * as SG from '../styles/OverlayResultStyle';
import { QuestionCircleOutlined } from '@ant-design/icons';
import { useReproducibilityGraphRangeSetting } from '../hooks/useReproducibilityGraphRangeSetting';
const {
  graph_setting: {
    reproducibility: {
      setting: { range: message },
    },
  },
} = Overlay;
const ReproductibilityGraphRangeSetting = () => {
  const { changeRange, range } = useReproducibilityGraphRangeSetting();
  return (
    <Fragment>
      <div className="content-box scale-button">
        <Divider className="divider-line" orientation="left">
          {message.label}
          <Tooltip className="title-tooltip" title={message.tooltip}>
            <QuestionCircleOutlined />
          </Tooltip>
        </Divider>
      </div>
      <div css={SG.contentItemStyle} className="limit-box">
        <div className="limit-title">
          <Tag color="blue">{message.x.label}</Tag>
        </div>
        <div className="limit-box-scale">
          <div>
            <Tag className="range-tag-margin">{message.x.upper_limit}</Tag>
            <InputNumber
              value={range?.three_sigma_x ?? 0}
              onChange={(e) => changeRange({ three_sigma_x: e })}
            />
          </div>
        </div>
      </div>
      <div css={SG.contentItemStyle} className="limit-box">
        <div className="limit-title">
          <Tag color="blue">{message.y.label}</Tag>
        </div>
        <div className="limit-box-scale">
          <div>
            <Tag className="range-tag-margin">{message.y.upper_limit}</Tag>
            <InputNumber
              value={range?.three_sigma_y ?? 0}
              onChange={(e) => changeRange({ three_sigma_y: e })}
            />
          </div>
        </div>
      </div>
    </Fragment>
  );
};
export default ReproductibilityGraphRangeSetting;
