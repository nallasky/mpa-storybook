import { Divider, InputNumber, Tooltip } from 'antd';
import { Overlay } from '@assets/locale/en';
import { useMapGraphEtc } from './hooks/useMapGraphEtc';
import { QuestionCircleOutlined } from '@ant-design/icons';
const {
  graph_setting: {
    map: {
      etc: { column_num: message },
    },
  },
} = Overlay;
const MapGraphEtcDisplayColumnNum = () => {
  const { column_num: value, updateDisplayColumnSetting } = useMapGraphEtc();
  return (
    <div className="content-box">
      <Divider className="divider-line" orientation="left">
        {message.label}
        <Tooltip className="title-tooltip" title={message.tooltip}>
          <QuestionCircleOutlined />
        </Tooltip>
      </Divider>
      <div>
        <InputNumber
          min={1}
          max={5}
          value={value}
          onChange={updateDisplayColumnSetting}
        />
      </div>
    </div>
  );
};
export default MapGraphEtcDisplayColumnNum;
