import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import { E_OVERLAY_VARIATION } from '@constants/etc';

export const useVariationGraphRangeSetting = () => {
  const { currentData, updateOverlayVariationSetting } = useCommonOverlay();
  const { setUpdateDisplay } = useOverlayGraph();
  const {
    graph: { variation },
    info: {
      origin: { variation: variation_origin },
    },
  } = currentData;

  const changeRangeSetting = (obj) => {
    console.log('obj', obj);
    if (obj) {
      updateOverlayVariationSetting(obj);
      setUpdateDisplay(E_OVERLAY_VARIATION);
    }
  };

  return {
    range: variation,
    origin: variation_origin,
    changeRange: changeRangeSetting,
  };
};
