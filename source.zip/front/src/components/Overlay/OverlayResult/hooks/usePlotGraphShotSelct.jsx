import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import useOverlayResultInfo from '@hooks/common/useOverlayResultInfo';
export const usePlotGraphShotSelct = () => {
  const { currentData } = useCommonOverlay();
  const { updateOasBaseLinePlotGraphSetting } = useOverlayResultInfo();
  const { setUpdateDisplay } = useOverlayGraph();

  const {
    graph: {
      plot: { shot },
    },
  } = currentData;
  const ChangeShot = (v) => {
    console.log('ChangeShot: ', v);
    if (v) {
      const ShotObj = {
        ...currentData.graph.plot,
        shot: {
          ...currentData.graph.plot.shot,
          selected: v,
        },
        highlight_glass: {
          ...currentData.graph.plot.highlight_glass,
          selected: '',
        },
      };
      updateOasBaseLinePlotGraphSetting(ShotObj);
      setUpdateDisplay(true);
    }
  };
  return {
    ShotList: shot.list,
    selectedShot: shot.selected,
    ChangeShot,
  };
};
