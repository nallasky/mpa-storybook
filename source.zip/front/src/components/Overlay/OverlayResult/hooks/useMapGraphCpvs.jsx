import { useContext } from 'react';
import useCommonOverlay, {
  OverlayCpVsInfo,
} from '@components/Overlay/hooks/useCommonOverlay';
import { E_CPVS_CORRECTION } from '@constants/etc';

export const useMapGraphCpvs = () => {
  const { currentData, mode, updateOverlayMapGraphSetting } =
    useCommonOverlay();
  const { cpvs_mode, cpvs_setting, cpvs_origin } = useContext(OverlayCpVsInfo);

  const { graph } = currentData;
  const origin_map = graph?.map ?? graph;

  const BasicCPVSChangeFunc = (info, tab) => {
    console.log('BasicCPVSChangeFunc', info, tab, origin_map);
    const obj = {
      ...origin_map,
      cp_vs: {
        ...origin_map.cp_vs,
        [tab]: {
          ...origin_map.cp_vs[tab],
          mode: info?.mode ?? origin_map.cp_vs[tab].mode,
          shots: info?.shots ?? origin_map.cp_vs[tab].shots,
          preset: info?.preset ?? origin_map.cp_vs[tab].preset,
        },
      },
    };
    updateOverlayMapGraphSetting(obj);
  };
  const cpvsModeChangeFunc = (e, tab) => {
    BasicCPVSChangeFunc({ mode: e.target.value }, tab);
  };
  const cpvsAdcShotChangeFunc = (e, tab) => {
    BasicCPVSChangeFunc(
      {
        shots: {
          ...origin_map.cp_vs[tab].shots,
          [e.shot]: e.info,
        },
      },
      tab,
    );
  };
  const cpvsCorrectionShotChangeFunc = (e, keys) => {
    BasicCPVSChangeFunc(
      {
        shots: {
          ...origin_map.cp_vs[E_CPVS_CORRECTION].shots,
          [keys]: Array.isArray(e)
            ? e
            : origin_map.cp_vs[E_CPVS_CORRECTION].shots[keys].map((o) =>
                o.shot.id === e.shot.id ? e : o,
              ),
        },
      },
      E_CPVS_CORRECTION,
    );
  };
  return {
    mode,
    cpvs_mode,
    cpvs_setting,
    cpvs_origin,
    cp_vs: origin_map.cp_vs,

    cpvsCorrectionShotChangeFunc,
    cpvsAdcShotChangeFunc,
    cpvsModeChangeFunc,
    BasicCPVSChangeFunc,
  };
};
