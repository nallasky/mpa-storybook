import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import { E_OVERLAY_VARIATION } from '@constants/etc';
export const useVariationGraphShotSelect = () => {
  const { currentData, updateOverlayVariationSetting } = useCommonOverlay();
  const { setUpdateDisplay } = useOverlayGraph();

  const {
    graph: { variation },
    info: { shot: ShotList },
  } = currentData;
  const ChangeShot = (v) => {
    console.log('ChangeShot: ', v);
    if (v) {
      updateOverlayVariationSetting({ select_shot: v });
      setUpdateDisplay(E_OVERLAY_VARIATION);
    }
  };
  return {
    ShotList,
    selectedShot: variation.select_shot,
    ChangeShot,
  };
};
