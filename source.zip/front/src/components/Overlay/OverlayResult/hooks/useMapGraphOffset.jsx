import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { OVERLAY_OFFSET_RESET } from '@constants/OverlayDefault';
import { getParseData } from '@libs/util/util';

export const useMapGraphOffset = () => {
  const { currentData, updateOverlayMapGraphSetting } = useCommonOverlay();

  const { graph, info } = currentData;

  const updatOffsetSetting = (obj) => {
    const uOffset = {
      ...(graph?.map ?? graph),
      offset: obj,
    };
    updateOverlayMapGraphSetting(uOffset);
  };
  const resetOffset = () => {
    const offset = (graph?.map ?? graph).offset;
    const reset = info.shot.reduce(
      (acc, o) => ({ ...acc, [o]: OVERLAY_OFFSET_RESET }),
      {},
    );
    updatOffsetSetting({
      ...offset,
      info: reset,
    });
  };
  const changeOffset = (v) => {
    const data = getParseData(v);
    const offset = (graph?.map ?? graph).offset;
    let obj = {};
    if (data.id === 'mode') {
      obj =
        data.value === 'auto'
          ? {
              ...offset,
              ...v,
              info: offset.default,
            }
          : {
              ...offset,
              ...v,
            };
    } else {
      obj = {
        ...offset,
        info: {
          ...offset.info,
          [data.id]: { ...offset.info[data.id], ...data.value },
        },
      };
    }
    updatOffsetSetting(obj);
  };

  return {
    offset: (graph?.map ?? graph).offset,
    resetOffset,
    changeOffset,
  };
};
