import { useRef } from 'react';
import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';
import { usePostOverlayAnalysis } from '@hooks/query/overlay/overlayCommonSetting';
import { RequestOnError, RequestOnSuccess } from '@libs/util/common/common';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import {
  E_OVERLAY_GRAPH_ALL,
  OVERLAY_CORRECTION_CATEGORY,
} from '@constants/etc';

export const useGraphReAnalysis = () => {
  const cancelRef = useRef(null);
  const { mode, currentData } = useCommonOverlay();
  const { updateOriginDataSetting } = useOverlayInfo();
  const { setUpdateDisplay, OverlayResultType: type } = useOverlayGraph();

  const reAnalysisFunc = usePostOverlayAnalysis(cancelRef);

  const reAnalysisStartFunc = ({ param }) => {
    reAnalysisFunc.mutate(
      {
        data: param,
      },
      {
        onSuccess: ({ info }) => {
          RequestOnSuccess('Analysis Success', 'The analysis was successful.');
          if (info) {
            updateOriginDataSetting(info, mode, currentData);
          }
          setUpdateDisplay(
            mode === OVERLAY_CORRECTION_CATEGORY
              ? E_OVERLAY_GRAPH_ALL
              : type.id,
          );
        },
        onError: RequestOnError,
      },
    );
  };
  return {
    reAnalysisStartFunc,
    reAnalysisCancel: reAnalysisFunc.cancel,
    cancelRef,
  };
};
