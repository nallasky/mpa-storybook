import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import { E_OVERLAY_PLOT } from '@constants/etc';
import useOverlayResultInfo from '@hooks/common/useOverlayResultInfo';
import { usePutOverlayGraphInfo } from '@hooks/query/overlay/overlayCommonSetting';
import { RequestOnError } from '@libs/util/common/common';
import { useState } from 'react';
export const usePlotGraphColorSetting = () => {
  const [colorMenu, setColorMenu] = useState(false);
  const { currentData, mode } = useCommonOverlay();
  const { updateOasBaseLinePlotGraphSetting } = useOverlayResultInfo();
  const { setUpdateDisplay } = useOverlayGraph();
  const updateGraphInfo = usePutOverlayGraphInfo();
  const {
    graph: {
      plot: { color },
    },
    targetInfo: { fab_name },
  } = currentData;

  const updateColorSetting = (colors) => {
    console.log('colors', colors);
    const graphObj = {
      ...currentData.graph.plot,
      color: colors,
    };

    updateGraphInfo.mutate(
      {
        category: mode,
        obj: { graph_setting: { color: colors } },
        fab_name,
      },
      {
        onSuccess: () => {
          updateOasBaseLinePlotGraphSetting(graphObj);
          setUpdateDisplay(E_OVERLAY_PLOT);
        },
        onError: RequestOnError,
      },
    );
  };
  return { colorMenu, setColorMenu, color, updateColorSetting };
};
