import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import { E_OVERLAY_PLOT } from '@constants/etc';
import useOverlayResultInfo from '@hooks/common/useOverlayResultInfo';
import { usePutOverlayGraphInfo } from '@hooks/query/overlay/overlayCommonSetting';
import { RequestOnError } from '@libs/util/common/common';

export const usePlotGraphScaleAndType = () => {
  const { currentData, mode } = useCommonOverlay();
  const { updateOasBaseLinePlotGraphSetting } = useOverlayResultInfo();
  const { setUpdateDisplay } = useOverlayGraph();
  const updateGraphInfo = usePutOverlayGraphInfo();
  const {
    graph: {
      plot: { scale, graph_type },
    },
    targetInfo: { fab_name },
  } = currentData;

  const ApplyScaleAndType = (v) => {
    console.log('ApplyScaleAndType', v);
    if (v) {
      updateGraphInfo.mutate(
        {
          category: mode,
          obj: { ...v },
          fab_name,
        },
        {
          onSuccess: () => {
            const scaleObj = {
              ...currentData.graph.plot,
              ...v,
            };
            updateOasBaseLinePlotGraphSetting(scaleObj);
            setUpdateDisplay(E_OVERLAY_PLOT);
          },
          onError: RequestOnError,
        },
      );
    }
  };

  return {
    graphType: graph_type,
    graphScale: scale.left,
    periodScale: scale.period,
    ApplyScaleAndType,
  };
};
