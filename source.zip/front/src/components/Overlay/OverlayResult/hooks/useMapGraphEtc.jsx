import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import {
  E_OVERLAY_GRAPH_ALL,
  E_OVERLAY_MAP,
  OVERLAY_CORRECTION_CATEGORY,
} from '@constants/etc';
import { usePutOverlayGraphInfo } from '@hooks/query/overlay/overlayCommonSetting';
import { RequestOnError } from '@libs/util/common/common';

export const useMapGraphEtc = () => {
  const { currentData, updateOverlayMapGraphSetting, mode } =
    useCommonOverlay();
  const { OverlayResultType, setUpdateDisplay } = useOverlayGraph();

  const updateGraphInfo = usePutOverlayGraphInfo();

  const {
    graph,
    info: {
      origin: { etc },
    },
    targetInfo: { fab_name },
  } = currentData;
  const { display_map, column_num, div, show_extra_info, plate_size } =
    graph?.map ?? graph;

  const updateEtcSetting = (obj) => {
    console.log('obj', obj);
    const updateEtcSet = {
      ...(graph?.map ?? graph),
      ...obj,
    };
    updateOverlayMapGraphSetting(updateEtcSet);
  };

  const updateDisplayMapSetting = (v) => {
    console.log('obj', v);
    updateEtcSetting({
      display_map: {
        max: v?.max ?? display_map.max,
        min: v?.min ?? display_map.min,
      },
    });
  };
  const updateDisplayColumnSetting = (v) => {
    console.log('obj', v);
    updateEtcSetting({
      column_num: v,
    });
  };
  const updateDisplayShowExtraInfoSetting = (v) => {
    console.log('obj', v);
    updateEtcSetting({
      show_extra_info: v,
    });
  };
  const updateScaleSetting = (v) => {
    console.log('[updateScaleSetting]obj', v);
    updateGraphInfo.mutate(
      {
        category: mode,
        obj: { etc: v },
        fab_name,
      },
      {
        onSuccess: () => {
          updateEtcSetting({
            div: v?.div ?? display_map.div,
            plate_size: v?.plate_size ?? display_map.plate_size,
          });
          setUpdateDisplay(
            mode === OVERLAY_CORRECTION_CATEGORY
              ? E_OVERLAY_GRAPH_ALL
              : E_OVERLAY_MAP,
          );
        },
        onError: RequestOnError,
      },
    );
  };

  return {
    updateScaleSetting,
    updateDisplayMapSetting,
    updateDisplayColumnSetting,
    updateDisplayShowExtraInfoSetting,
    display_map,
    div,
    show_extra_info,
    plate_size,
    column_num,
    origin: etc,
    OverlayResultType,
  };
};
