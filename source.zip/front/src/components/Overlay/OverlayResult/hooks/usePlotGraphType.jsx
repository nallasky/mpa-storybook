import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import useOverlayResultInfo from '@hooks/common/useOverlayResultInfo';
export const usePlotGraphType = () => {
  const { currentData } = useCommonOverlay();
  const { updateOasBaseLinePlotGraphSetting } = useOverlayResultInfo();
  const { setUpdateDisplay } = useOverlayGraph();

  const {
    graph: {
      plot: { type },
    },
  } = currentData;
  const ChangeGraphType = (v) => {
    console.log('ChangeHighLightGlass: ', v);
    if (v) {
      const graphTypeObj = {
        ...currentData.graph.plot,
        type: v,
      };
      updateOasBaseLinePlotGraphSetting(graphTypeObj);
      setUpdateDisplay(true);
    }
  };
  return {
    graphType: type,
    ChangeGraphType,
  };
};
