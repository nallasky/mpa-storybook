import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import useOverlayResultInfo from '../../../../hooks/common/useOverlayResultInfo';
import { ANOVA_LIST } from '@constants/OverlayDefault';

export const useAnovaGraphTable = () => {
  const { currentData, updateOverlayAnovaSetting } = useCommonOverlay();
  const { getAnovaTableFuc } = useOverlayResultInfo();
  const {
    graph: { anova },
    info: {
      origin: { anova: anova_origin },
    },
  } = currentData;

  const selectAnovaAxios = (v) => {
    console.log(v);
    updateOverlayAnovaSetting({ ...anova, selected: v });
  };

  return {
    list: ANOVA_LIST,
    selected: anova.selected,
    selectAnovaAxios,
    origin: anova_origin,
    getAnovaTableData: getAnovaTableFuc,
  };
};
