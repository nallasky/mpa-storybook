import { useMapGraphCpvs } from './useMapGraphCpvs';

export const useMapGraphCpVsCorrectionTable = () => {
  const { cpvsCorrectionShotChangeFunc, cpvs_setting, cpvs_mode } =
    useMapGraphCpvs();

  console.log('cpvs_setting', cpvs_setting);
  const { shots } = cpvs_setting;

  const changeShotFunc = (name, shotN, properties, value) => {
    let shotInfo;
    console.log('[changeShotFunc]properties', properties);
    console.log('[changeShotFunc]name', name);
    console.log('[changeShotFunc]value', value);
    console.log('[changeShotFunc]shotN', shotN);
    if (shotN === undefined) {
      shotInfo = shots[name].map((o) => ({
        ...o,
        [properties]: { ...o[properties], checked: value.mode === 'on' },
      }));
    } else {
      const clone = shots[name].find((o) => o.shot.id === shotN);
      shotInfo = {
        ...clone,
        [properties]: {
          ...clone[properties],
          ...value,
        },
      };
    }
    console.log(shotInfo);
    cpvsCorrectionShotChangeFunc(shotInfo, name);
  };

  return { cpvs_mode, changeShotFunc, cpvs_setting, shots };
};
