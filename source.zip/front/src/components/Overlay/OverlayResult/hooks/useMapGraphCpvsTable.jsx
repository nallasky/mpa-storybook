import { useMapGraphCpvs } from './useMapGraphCpvs';

export const useMapGraphCpvsTable = () => {
  const { cpvsAdcShotChangeFunc, cpvs_mode } = useMapGraphCpvs();
  const changeCpvsColumnData = (e) => {
    cpvsAdcShotChangeFunc(e, cpvs_mode);
  };
  return { changeCpvsColumnData };
};
