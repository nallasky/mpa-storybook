import { NotificationBox } from '@components/common/molecules/NotificationBox';
import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import {
  E_CPVS_ADC_MEASUREMENT,
  E_CPVS_CORRECTION,
  E_Default,
  E_New,
  OVERLAY_ADC_CATEGORY,
} from '@constants/etc';
import { CPVS_MODE } from '@constants/OverlayDefault';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';
import {
  useGetOverlayCpvs,
  usePostOverlayCpvsAdd,
  usePostOverlayCpvsDelete,
  usePostOverlayCpvsUpdate,
} from '@hooks/query/overlay/overlayCommonSetting';
import { useState } from 'react';
import { useMapGraphCpvs } from './useMapGraphCpvs';
export const useMapGraphCpvsPreset = () => {
  const [loading, setLoading] = useState({ mode: undefined, status: false });
  const [preset, setPreset] = useState({});
  const addMutation = usePostOverlayCpvsAdd();
  const updateMutation = usePostOverlayCpvsUpdate();
  const deleteMutation = usePostOverlayCpvsDelete();
  const {
    currentData: {
      targetInfo: { fab_name },
    },
    mode,
  } = useCommonOverlay();
  const { cpvs_mode, cpvs_setting, cpvs_origin, BasicCPVSChangeFunc } =
    useMapGraphCpvs();
  const { getCorrectionCpVsDefault, getCorrectionCpVsSetting } =
    useOverlayInfo();
  const defaultShotInfo =
    cpvs_mode !== E_CPVS_CORRECTION
      ? (cpvs_origin?.[cpvs_mode] ?? cpvs_origin)?.shot?.reduce(
          (acc, o) =>
            Object.assign(acc, {
              [o]: (cpvs_origin?.[cpvs_mode] ?? cpvs_origin)?.default,
            }),
          {},
        )
      : getCorrectionCpVsDefault(
          cpvs_origin[cpvs_mode]?.default,
          cpvs_origin[cpvs_mode].shot,
        );
  const RequestOnError = (err) => {
    console.log(err);
    NotificationBox({ title: 'ERROR', message: err.message, time: 0 });
  };
  const RequestOnSettled = () => {
    setLoading({ mode: undefined, status: false });
  };
  const updateShotAndPresetInfo = (info) => {
    BasicCPVSChangeFunc(info, cpvs_mode);
  };
  const updatePresetInfo = ({ preset }) => {
    updateShotAndPresetInfo({ preset });
  };
  const updateShotInfo = ({ mode, shots }) => {
    updateShotAndPresetInfo({ mode, shots });
  };

  const getPresetList = useGetOverlayCpvs({
    category:
      cpvs_mode === E_CPVS_ADC_MEASUREMENT ? OVERLAY_ADC_CATEGORY : mode,
    id: preset?.[cpvs_mode]?.id,
    enabled:
      ![E_Default, E_New].includes(preset?.[cpvs_mode]?.id) &&
      loading.mode === 'get' &&
      loading.status,
    onSettled: RequestOnSettled,
    onSuccess: (info) => {
      console.log('info', info);
      updateShotInfo({
        mode: info.mode,
        shots:
          cpvs_mode === E_CPVS_CORRECTION
            ? getCorrectionCpVsSetting(
                undefined,
                info?.step ?? info.shots,
                cpvs_origin[cpvs_mode]?.shot,
              )
            : info?.step ?? info.shots,
      });
    },
  });

  const savePreset = () => {
    setLoading({ mode: 'add/update', status: true });
    if (preset?.[cpvs_mode]?.id === E_New) {
      addMutation.mutate(
        {
          preset: {
            name: preset?.[cpvs_mode]?.title,
            fab_nm: fab_name,
            mode: cpvs_setting.mode,
          },
          shots: cpvs_setting.shots,
          mode: cpvs_mode,
          category:
            cpvs_mode === E_CPVS_ADC_MEASUREMENT ? OVERLAY_ADC_CATEGORY : mode,
        },
        {
          onSuccess: (info) => {
            updatePresetInfo({
              preset: {
                ...cpvs_setting.preset,
                [+info]: preset?.[cpvs_mode]?.title,
              },
            });
            setPreset((prev) => ({
              ...prev,
              [cpvs_mode]: {
                ...prev[cpvs_mode],
                id: +info,
              },
            }));
          },
          onError: RequestOnError,
          onSettled: RequestOnSettled,
        },
      );
    } else {
      updateMutation.mutate(
        {
          preset: { name: preset?.[cpvs_mode]?.title, mode: cpvs_setting.mode },
          shots: cpvs_setting.shots,
          mode: cpvs_mode,
          preset_id: preset?.[cpvs_mode]?.id,
          category:
            cpvs_mode === E_CPVS_ADC_MEASUREMENT ? OVERLAY_ADC_CATEGORY : mode,
        },
        {
          onSuccess: () => {
            updatePresetInfo({
              preset: {
                ...cpvs_setting.preset,
                [preset?.[cpvs_mode]?.id]: preset?.[cpvs_mode]?.title,
              },
            });
          },
          onError: RequestOnError,
          onSettled: RequestOnSettled,
        },
      );
    }
  };
  const deletePreset = (id) => {
    setLoading({ mode: 'delete', status: true });
    deleteMutation.mutate(
      {
        id,
        tab: cpvs_mode,
        cateory:
          cpvs_mode === E_CPVS_ADC_MEASUREMENT ? OVERLAY_ADC_CATEGORY : mode,
      },
      {
        onSuccess: ({ id }) => {
          const clone = { ...cpvs_setting.preset };
          delete clone[id];
          updatePresetInfo({ preset: clone });
          updateShotAndPresetInfo({
            preset: clone,
            mode:
              cpvs_mode !== E_CPVS_CORRECTION
                ? CPVS_MODE.FROM_LOG
                : CPVS_MODE.EACH,
            shot: defaultShotInfo,
          });
          setPreset((prev) => ({
            ...prev,
            [cpvs_mode]: {
              title: E_Default,
              id: E_Default,
            },
          }));
        },
        onError: RequestOnError,
        onSettled: RequestOnSettled,
      },
    );
  };
  const selectPreset = (id) => {
    if ([E_Default, E_New].includes(id)) {
      setPreset((prev) => ({
        ...prev,
        [cpvs_mode]: {
          id: id,
          title: id === E_Default ? E_Default : '',
        },
      }));
      if (id === E_Default) {
        updateShotInfo({
          mode:
            cpvs_mode !== E_CPVS_CORRECTION
              ? CPVS_MODE.FROM_LOG
              : CPVS_MODE.EACH,
          shots: defaultShotInfo,
        });
      }
    } else {
      setPreset((prev) => ({
        ...prev,
        [cpvs_mode]: {
          id: id,
          title: cpvs_setting.preset[id],
        },
      }));
      setLoading({ mode: 'get', status: true });
    }
  };
  return {
    loading,
    preset,
    setPreset,
    updatePresetInfo,
    getPresetList,
    savePreset,
    selectPreset,
    deletePreset,
    cpvs_mode,
  };
};
