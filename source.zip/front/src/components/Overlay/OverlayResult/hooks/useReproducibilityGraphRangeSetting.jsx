import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import { E_OVERLAY_REPRODUCIBILITY } from '@constants/etc';

export const useReproducibilityGraphRangeSetting = () => {
  const { currentData, updateOverlayReproducibilitySetting } =
    useCommonOverlay();
  const { setUpdateDisplay } = useOverlayGraph();
  const {
    graph: { reproducibility },
    info: {
      origin: { reproducibility: reproducibility_origin },
    },
  } = currentData;

  const changeRangeSetting = (obj) => {
    console.log('obj', obj);
    if (obj) {
      updateOverlayReproducibilitySetting({ ...reproducibility, ...obj });
      setUpdateDisplay(E_OVERLAY_REPRODUCIBILITY);
    }
  };

  return {
    range: reproducibility,
    origin: reproducibility_origin,
    changeRange: changeRangeSetting,
  };
};
