import { useState } from 'react';
import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { usePostOverlayCpVsUploadLogFiles } from '@hooks/query/overlay/overlayCommonSetting';
import { RequestOnError } from '@libs/util/common/common';
import { useMapGraphCpvs } from './useMapGraphCpvs';
import { E_CPVS_ADC_MEASUREMENT, OVERLAY_ADC_CATEGORY } from '@constants/etc';

export const useMapGraphCpvsJobFile = () => {
  const { mode, currentData, updateOverlayMapGraphSetting } =
    useCommonOverlay();
  const { cpvs_mode } = useMapGraphCpvs();
  const map = currentData.graph?.map ?? currentData.graph;
  const [uploading, setUploading] = useState(false);
  const uploadJobFile = usePostOverlayCpVsUploadLogFiles();

  console.log('map', map, mode);
  const jobFileSuccess = (cp_vs) => {
    console.log('cpvs_mode', cpvs_mode);
    const shot_list = Object.keys(map.cp_vs[cpvs_mode].shots);
    const obj = {
      ...map,
      cp_vs: {
        ...map.cp_vs,
        [cpvs_mode]: {
          ...map.cp_vs[cpvs_mode],
          shots: shot_list.reduce(
            (acc, o) =>
              Object.assign(acc, {
                [o]: {
                  ...map.cp_vs[cpvs_mode].shots[o],
                  ...cp_vs,
                },
              }),
            {},
          ),
        },
      },
    };
    updateOverlayMapGraphSetting(obj);
  };
  const jobFileUploadProp = {
    multiple: false,
    maxCount: 1,
    action: '',
    customRequest: ({ file, onProgress, onError, onSuccess }) => {
      const formData = new FormData();
      formData.append('file', file);
      setUploading(true);
      //const shot_list = []; //Object.keys(obj.shots);
      onProgress({ percent: 50 }, file);
      uploadJobFile.mutate(
        {
          category:
            cpvs_mode === E_CPVS_ADC_MEASUREMENT ? OVERLAY_ADC_CATEGORY : mode,
          form: formData,
        },
        {
          onError: (err) => {
            RequestOnError(err);
            onError(file);
          },
          onSuccess: ({ cp_vs }) => {
            console.log('cp_vs', cp_vs);
            jobFileSuccess(cp_vs);
            onSuccess(file);
          },
          onSettled: () => {
            setUploading(false);
          },
        },
      );
    },
    onChange: ({ file }) => {
      console.log(file);
    },
  };

  return {
    jobFileUploadProp,
    uploadJobFile,
    uploading,
    cpVsMode: map.cp_vs?.[cpvs_mode].mode,
  };
};
