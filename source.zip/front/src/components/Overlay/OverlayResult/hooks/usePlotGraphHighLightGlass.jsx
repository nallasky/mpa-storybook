import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import { E_OVERLAY_PLOT } from '@constants/etc';
import useOverlayResultInfo from '@hooks/common/useOverlayResultInfo';

export const usePlotGraphHighLightGlass = () => {
  const { currentData } = useCommonOverlay();
  const { updateOasBaseLinePlotGraphSetting } = useOverlayResultInfo();
  const { setUpdateDisplay } = useOverlayGraph();
  const {
    graph: {
      plot: { highlight_glass, shot },
    },
  } = currentData;
  const ChangeHighLightGlass = (v) => {
    console.log('ChangeHighLightGlass: ', v);
    const highListObj = {
      ...currentData.graph.plot,
      highlight_glass: {
        ...currentData.graph.plot.highlight_glass,
        selected: v ?? '',
      },
    };
    updateOasBaseLinePlotGraphSetting(highListObj);
    setUpdateDisplay(E_OVERLAY_PLOT);
  };
  return {
    highlight_glass,
    ChangeHighLightGlass,
    selectedShot: shot?.selected,
  };
};
