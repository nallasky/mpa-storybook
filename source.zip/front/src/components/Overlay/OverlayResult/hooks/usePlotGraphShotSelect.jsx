import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import { E_OVERLAY_PLOT } from '@constants/etc';
import useOverlayResultInfo from '@hooks/common/useOverlayResultInfo';
export const usePlotGraphShotSelect = () => {
  const { currentData } = useCommonOverlay();
  const { updateOasBaseLinePlotGraphSetting } = useOverlayResultInfo();
  const { setUpdateDisplay } = useOverlayGraph();

  const {
    graph: {
      plot: { shot },
    },
  } = currentData;
  const ChangeShot = (v) => {
    console.log('ChangeShot: ', v);
    if (v) {
      const ShotObj = {
        ...currentData.graph.plot,
        shot: {
          ...currentData.graph.plot.shot,
          selected: v,
        },
        highlight_glass: {
          ...currentData.graph.plot.highlight_glass,
          selected: '',
        },
      };
      updateOasBaseLinePlotGraphSetting(ShotObj);
      setUpdateDisplay(E_OVERLAY_PLOT);
    }
  };
  return {
    ShotList: shot.list,
    selectedShot: shot.selected,
    ChangeShot,
  };
};
