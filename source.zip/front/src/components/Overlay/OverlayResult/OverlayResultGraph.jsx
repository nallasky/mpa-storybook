import React, { useCallback, useEffect, useMemo } from 'react';
import Plotly from 'plotly.js-dist';
import {
  PlotDefaultScript,
  MapDefaultScript,
  ReproducibilityDefaultScript,
  VariationDefaultScript,
  AnovaDefaultScript,
  BaraDefaultScript,
  CorrectionCompScript,
  CorrectImageScript,
} from '../../../libs/graph';
import {
  E_OVERLAY_ANOVA,
  E_OVERLAY_COMPONENT,
  E_OVERLAY_GRAPH_ALL,
  E_OVERLAY_IMAGE,
  E_OVERLAY_MAP,
  E_OVERLAY_PLOT,
  E_OVERLAY_REPRODUCIBILITY,
  E_OVERLAY_VARIATION,
  OVERLAY_ADC_CATEGORY,
} from '@constants/etc';
import useOverlayResultInfo from '../../../hooks/common/useOverlayResultInfo';
import { MESSAGE } from '@constants/Message';
import { Divider } from 'antd';
import useOverlaySettingInfo from '../../../hooks/common/useOverlaySettingInfo';
import useCommonOverlay from '../hooks/useCommonOverlay';
import { useOverlayGraph } from '../hooks/useOverlayGraph';
import AnovaTableAndGraph from './AnovaGraph/AnovaTableAndGraph';
import { ANOVA_LIST } from '@constants/OverlayDefault';
import MapGraphExtraInfoTable from './MapGraph/MapGraphExtraInfoTable';

const gScript = [
  { id: E_OVERLAY_MAP, func: [MapDefaultScript] },
  { id: E_OVERLAY_PLOT, func: [PlotDefaultScript] },
  {
    id: E_OVERLAY_VARIATION,
    func: [BaraDefaultScript, VariationDefaultScript],
  },
  {
    id: E_OVERLAY_REPRODUCIBILITY,
    func: [ReproducibilityDefaultScript, ReproducibilityDefaultScript],
  },
  {
    id: E_OVERLAY_ANOVA,
    func: [AnovaDefaultScript, AnovaDefaultScript],
  },
  {
    id: E_OVERLAY_IMAGE,
    func: [CorrectImageScript],
  },
  {
    id: E_OVERLAY_COMPONENT,
    func: [CorrectionCompScript],
  },
];
const common = { screen_width: 1350, screen_height: 500 };
const DISP_NAME = (msg) => ({ disp_name: msg });
const Reproducibility_X = {
  ...common,
  title: MESSAGE.SIGMA_X,
  ...DISP_NAME('x'),
};
const Reproducibility_Y = {
  ...common,
  title: MESSAGE.SIGMA_Y,
  ...DISP_NAME('y'),
};

const OverlayResultGraph = () => {
  const { adcCommonInfo: adcCommon } = useOverlaySettingInfo();
  const { mode, currentData } = useCommonOverlay();
  const {
    updateDisplay,
    setUpdateDisplay,
    OverlayResultType: { id: type },
    OverlayResultTypeList,
    disp_option_map,
    disp_option_correction,
  } = useOverlayGraph();
  const {
    info: { origin: origin_data },
    graph: graph_data,
  } = currentData;
  const { adc_correction_tooltip, stage_correction_tooltip } =
    useOverlayResultInfo();
  const getScriptObject = useCallback((id) => {
    return gScript.find((o) => o.id === id);
  }, []);
  const RenderGraph = useCallback(
    ({ renderFunc, element, object }) => {
      renderFunc(Plotly, element, origin_data ?? {}, object);
    },
    [origin_data],
  );
  const LotIdList = useMemo(
    () =>
      Object.keys(
        mode === OVERLAY_ADC_CATEGORY
          ? origin_data.data
          : origin_data?.map ?? origin_data?.data?.map ?? {},
      ),
    [mode, origin_data],
  );

  const drawRenderObject = {
    [E_OVERLAY_ANOVA]: [
      { ...common, ...DISP_NAME('X'), selected: graph_data?.anova?.selected },
      { ...common, ...DISP_NAME('Y'), selected: graph_data?.anova?.selected },
    ],
    [E_OVERLAY_MAP]: [
      {
        ...graph_data.map,
        disp_option: disp_option_map(mode),
      },
    ],
    [E_OVERLAY_PLOT]: [
      {
        ...common,
        ...origin_data,
        ...currentData.graph.plot,
      },
    ],
    [E_OVERLAY_VARIATION]: [
      {
        ...graph_data.variation,
        ...common,
        select_shot:
          graph_data?.variation?.select_shot === 'all'
            ? adcCommon?.shot
            : graph_data?.variation?.select_shot ?? undefined,
      },
      {},
    ],
    [E_OVERLAY_REPRODUCIBILITY]: [
      {
        ...Reproducibility_X,
        upper_limit: graph_data?.reproducibility?.three_sigma_x ?? 0,
      },
      {
        ...Reproducibility_Y,
        upper_limit: graph_data?.reproducibility?.three_sigma_y ?? 0,
      },
    ],
    [E_OVERLAY_IMAGE]: [
      {
        ...graph_data,
        disp_option_correction: disp_option_correction(),
        disp_option_map: disp_option_map(mode),
      },
    ],
    [E_OVERLAY_COMPONENT]: [
      {
        ...graph_data,
        adc_correction_tooltip: adc_correction_tooltip,
        stage_correction_tooltip: stage_correction_tooltip,
        disp_option_correction: disp_option_correction(),
      },
    ],
  };
  const drawGraph = (graphObject, forceDisplay) => {
    if ((forceDisplay ?? false) && graphObject?.id !== undefined) {
      if (
        [E_OVERLAY_MAP, E_OVERLAY_IMAGE, E_OVERLAY_COMPONENT].includes(
          graphObject.id,
        )
      ) {
        LotIdList.map((lot) => {
          graphObject?.func?.map((_, i) => {
            RenderGraph({
              renderFunc: graphObject?.func[i] ?? null,
              object: {
                ...drawRenderObject[graphObject.id][i],
                lot_name: lot,
                mode: mode,
              },
              element: `${graphObject.id}_${lot}_${i}`,
            });
          });
        });
      } else {
        graphObject?.func?.map((_, i) => {
          RenderGraph({
            renderFunc: graphObject?.func[i] ?? null,
            object: drawRenderObject[graphObject.id][i],
            element: `${graphObject.id}_${
              graphObject.id === E_OVERLAY_ANOVA ? ANOVA_LIST[i] : i
            }`,
          });
        });
      }
    }
  };

  useEffect(() => {
    console.log('updateDisplay', updateDisplay);
    if (updateDisplay) {
      if (updateDisplay !== E_OVERLAY_GRAPH_ALL) {
        drawGraph(getScriptObject(updateDisplay), 1);
      } else {
        OverlayResultTypeList.map((graph) =>
          drawGraph(getScriptObject(graph.id), 1),
        );
      }
      setUpdateDisplay(undefined);
    }
  }, [updateDisplay]);
  useEffect(() => {
    console.log('origin_data update!!!');
    setUpdateDisplay(E_OVERLAY_GRAPH_ALL);
  }, [origin_data]);

  return OverlayResultTypeList.map((graph, i) => (
    <div key={i} style={type === graph.id ? {} : { display: 'none' }}>
      {graph.id === E_OVERLAY_ANOVA ? (
        <AnovaTableAndGraph />
      ) : [E_OVERLAY_MAP, E_OVERLAY_COMPONENT, E_OVERLAY_IMAGE].includes(
          graph.id,
        ) ? (
        <>
          {LotIdList.map((lot, index) => {
            return (
              <React.Fragment key={index}>
                {graph.id === E_OVERLAY_MAP &&
                graph_data.map.show_extra_info ? (
                  <MapGraphExtraInfoTable lot_id={lot} lot_idx={index + 1} />
                ) : (
                  <></>
                )}
                {gScript
                  .find((o) => o.id === graph.id)
                  ?.func.map((_, i) => (
                    <React.Fragment key={i}>
                      {' '}
                      <div id={`${graph.id}_${lot}_${i}`} />
                    </React.Fragment>
                  ))}
                <Divider />
              </React.Fragment>
            );
          })}
        </>
      ) : (
        gScript
          .find((o) => o.id === graph.id)
          ?.func.map((_, i) => (
            <React.Fragment key={i}>
              {' '}
              <div id={`${graph.id}_${i}`} />
            </React.Fragment>
          ))
      )}
    </div>
  ));
};
export default OverlayResultGraph;
