import { Divider, Select, Tooltip } from 'antd';
import { Overlay } from '@assets/locale/en';
import { QuestionCircleOutlined } from '@ant-design/icons';
import { useVariationGraphShotSelect } from '../hooks/useVariationGraphShotSelect';
const {
  graph_setting: {
    variation: {
      setting: { shot: message },
    },
  },
} = Overlay;
const VariationGraphShotSelect = () => {
  const { selectedShot, ShotList, ChangeShot } = useVariationGraphShotSelect();
  return (
    <div className="content-box">
      <Divider className="divider-line" orientation="left">
        {message.label}
        <Tooltip className="title-tooltip" title={message.tooltip}>
          <QuestionCircleOutlined />
        </Tooltip>
      </Divider>
      <Select
        style={{ width: '100%' }}
        value={selectedShot ?? 'all'}
        onChange={ChangeShot}
      >
        <Select.Option value={'all'} key={`shot_all`}>
          {message.all}
        </Select.Option>
        {ShotList.map((shot, idx) => (
          <Select.Option value={shot} key={idx}>
            {shot}
          </Select.Option>
        ))}
      </Select>
    </div>
  );
};
export default VariationGraphShotSelect;
