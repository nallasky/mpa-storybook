import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
import { SettingOutlined } from '@ant-design/icons';
import * as SG from '../styles/OverlayResultStyle';
import VariationGraphRangeSetting from './VariationGraphRangeSetting';
import VariationGraphShotSelect from './VariationGraphShotSelect';
import { Overlay } from '@assets/locale/en';
const {
  graph_setting: {
    variation: { setting: message },
  },
} = Overlay;
const VariationGraphSetting = () => {
  return (
    <RibbonCollapse title={message.label} defaultValue={true}>
      <div className="svg-box">
        <SettingOutlined />
      </div>
      <div css={SG.settingContentStyle}>
        <div className="content">
          <div css={SG.contentItemStyle}>
            <VariationGraphRangeSetting />
            <VariationGraphShotSelect />
          </div>
        </div>
      </div>
    </RibbonCollapse>
  );
};
export default VariationGraphSetting;
