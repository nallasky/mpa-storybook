import { Fragment } from 'react';
import { Divider, InputNumber, Tooltip, Tag } from 'antd';
import { Overlay } from '@assets/locale/en';
import * as SG from '../styles/OverlayResultStyle';

import { QuestionCircleOutlined } from '@ant-design/icons';
import { useVariationGraphRangeSetting } from '../hooks/useVariationGraphRangeSetting';
const {
  graph_setting: {
    variation: {
      setting: { range: message },
    },
  },
} = Overlay;
const VariationGraphRangeSetting = () => {
  const { changeRange, range } = useVariationGraphRangeSetting();
  return (
    <Fragment>
      <div className="content-box scale-button">
        <Divider className="divider-line" orientation="left">
          {message.label}
          <Tooltip className="title-tooltip" title={message.tooltip}>
            <QuestionCircleOutlined />
          </Tooltip>
        </Divider>
      </div>
      <div css={SG.contentItemStyle} className="limit-box">
        <div className="limit-title">
          <Tag color="blue">{message.x.label}</Tag>
        </div>
        <div className="limit-box-scale">
          <div className="flex-between range-limit-scale">
            <div>
              <Tag className="range-tag-margin">{message.x.lower_limit}</Tag>
              <InputNumber
                max={range?.x_range_max ?? 0}
                value={range?.x_range_min ?? 0}
                onChange={(e) => changeRange({ x_range_min: e })}
              />
            </div>
            <div>
              <Tag className="range-tag-margin">{message.x.upper_limit}</Tag>
              <InputNumber
                min={range?.x_range_min ?? 0}
                value={range?.x_range_max ?? 0}
                onChange={(e) => changeRange({ x_range_max: e })}
              />
            </div>
          </div>
        </div>
      </div>
      <div css={SG.contentItemStyle} className="limit-box">
        <div className="limit-title">
          <Tag color="blue">{message.y.label}</Tag>
        </div>
        <div className="limit-box-scale">
          <div className="flex-between range-limit-scale">
            <div>
              <Tag className="range-tag-margin">{message.y.lower_limit}</Tag>
              <InputNumber
                max={range?.y_range_max ?? 0}
                value={range?.y_range_min ?? 0}
                onChange={(e) => changeRange({ y_range_min: e })}
              />
            </div>
            <div>
              <Tag className="range-tag-margin">{message.y.upper_limit}</Tag>
              <InputNumber
                min={range?.y_range_min ?? 0}
                value={range?.y_range_max ?? 0}
                onChange={(e) => changeRange({ y_range_max: e })}
              />
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
};
export default VariationGraphRangeSetting;
