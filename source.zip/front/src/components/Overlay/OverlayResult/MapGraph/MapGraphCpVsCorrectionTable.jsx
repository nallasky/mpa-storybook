import { OVERLAY_CPVS_MIN_MAX } from '@constants/OverlayDefault';
import PropTypes from 'prop-types';
import { useMapGraphCpVsCorrectionTable } from '../hooks/useMapGraphCpVsCorrectionTable';
import * as tStyle from '../styles/OverlayCpVsStyle';
import MapGraphCpVsCorrectionCheck from './MapGraphCpVsCorrectionCheck';
const MapGraphCpVsCorrectionTable = ({ mode }) => {
  const { changeShotFunc, shots } = useMapGraphCpVsCorrectionTable();
  const rows = shots[mode];
  const columns = rows[0];

  return (
    <div className="table-wrapper">
      <table css={tStyle.correctionTableStyle}>
        <thead>
          <tr>
            {Object.keys(columns).map((v, i) => {
              const list = rows.filter((o) => o[v]?.checked === false);
              return (
                <th key={i}>
                  {v === 'shot' ? (
                    v
                  ) : (
                    <MapGraphCpVsCorrectionCheck
                      id={`${v}_chk`}
                      label={v}
                      isChecked={list.length === 0}
                      changeFunc={(e) => changeShotFunc(mode, undefined, v, e)}
                    />
                  )}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {rows.map((v, idx) => {
            return (
              <tr key={`${mode}_${idx}`}>
                {Object.keys(v).map((x, i) => {
                  const shot_mode = v.shot.mode;
                  return (
                    <td key={`${mode}_${idx}_${i}`}>
                      <MapGraphCpVsCorrectionCheck
                        id={`${mode}_${idx}_${i}`}
                        isChecked={
                          x === 'shot' ? shot_mode === 'auto' : v[x].checked
                        }
                        disabled={shot_mode === 'auto'}
                        label={x === 'shot' ? v.shot.id : undefined}
                        useText={x !== 'shot'}
                        value={x !== 'shot' ? v[x].value : undefined}
                        onText="auto"
                        offText="manual"
                        changeFunc={(e) =>
                          changeShotFunc(mode, v.shot.id, x, e)
                        }
                        min={OVERLAY_CPVS_MIN_MAX?.[x]?.min}
                        max={OVERLAY_CPVS_MIN_MAX?.[x]?.max}
                      />
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
MapGraphCpVsCorrectionTable.propTypes = {
  mode: PropTypes.string,
};
export default MapGraphCpVsCorrectionTable;
