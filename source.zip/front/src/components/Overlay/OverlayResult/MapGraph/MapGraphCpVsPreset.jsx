import { Fragment, useEffect } from 'react';
import { Button, Popconfirm, Select, Spin, Tooltip } from 'antd';
import * as SG from '../styles/OverlayResultStyle';
import { DeleteOutlined } from '@ant-design/icons';
import { css } from '@emotion/react';
import QuestionCircleOutlined from '@ant-design/icons/lib/icons/QuestionCircleOutlined';
import { E_Default, E_New } from '@constants/etc';
import { useMapGraphCpvs } from '../hooks/useMapGraphCpvs';
import { useMapGraphCpvsPreset } from '../hooks/useMapGraphCpvsPreset';
import { CommonRegex } from '@libs/util/regExp';
import {
  MESSAGE,
  MSG_DEFAULT,
  MSG_NEW_PRESET,
  MSG_PRESET,
  MSG_SAVE_PRESET,
  MSG_UPDATE_PRESET,
} from '@constants/Message';
import InputForm from '@components/common/atoms/Input/InputForm';

const { Option } = Select;

const contentsStyle = css`
  & .ant-form-item {
    margin-bottom: 0px;
  }
`;
const MapGraphCpVsPreset = () => {
  const { cpvs_setting, cpvs_mode } = useMapGraphCpvs();
  const { savePreset, loading, preset, selectPreset, deletePreset, setPreset } =
    useMapGraphCpvsPreset();

  useEffect(() => {
    if (!preset?.[cpvs_mode]) {
      setPreset((prev) => ({
        ...prev,
        [cpvs_mode]: {
          id: E_Default,
          title: E_Default,
        },
      }));
    }
  }, [cpvs_mode]);

  return (
    <Fragment>
      <Spin tip="Loading..." spinning={loading.status}>
        <div
          css={SG.contentItemStyle}
          className="column-3"
          style={{ paddingBottom: '10px' }}
        >
          <Tooltip
            placement="topLeft"
            title={MESSAGE.TABLE_NAME_REGEXP}
            arrowPointAtCenter
          >
            <span className="label">{MSG_PRESET}</span>
            <QuestionCircleOutlined
              style={{ marginLeft: '4px', color: 'rgb(24 144 255)' }}
            />
          </Tooltip>
          <Select
            style={{ width: '100%' }}
            onChange={(v) => selectPreset(v)}
            value={preset?.[cpvs_mode]?.id ?? ''}
          >
            <Option value={E_Default} key={`option_default`}>
              {MSG_DEFAULT}
            </Option>
            ;
            {Object.entries(cpvs_setting?.preset ?? {}).map(([id, title]) => (
              <Option value={+id} key={`option_${id}`}>
                {' '}
                {title}
                <Popconfirm
                  title={`Are you sure to delete Preset [${title}] ? `}
                  onConfirm={(e) => {
                    e.stopPropagation();
                    deletePreset(id);
                  }}
                >
                  <Button
                    type="text"
                    icon={<DeleteOutlined />}
                    style={{ float: 'right' }}
                    onClick={(e) => e.stopPropagation()}
                  />
                </Popconfirm>
              </Option>
            ))}
            <Option value={E_New} key={`option_new`}>
              {MSG_NEW_PRESET}
            </Option>
            ;
          </Select>
          <div className="preset-setting" css={contentsStyle}>
            <InputForm.input
              formName={'Title'}
              placeholder="Enter preset name."
              value={preset?.[cpvs_mode]?.title ?? ''}
              disabled={preset?.[cpvs_mode]?.id === E_Default}
              required={false}
              changeFunc={(e) =>
                setPreset((prev) => ({
                  ...prev,
                  [cpvs_mode]: {
                    ...prev[cpvs_mode],
                    title: e?.Title ?? '',
                  },
                }))
              }
              regExp={[
                {
                  pattern: CommonRegex,
                  message: '',
                },
              ]}
            />
            <button
              css={SG.antdButtonStyle}
              className="white"
              onClick={savePreset}
              disabled={
                preset?.[cpvs_mode]?.id === E_Default ||
                !CommonRegex.test(preset?.[cpvs_mode]?.title)
              }
            >
              {[E_Default, E_New].includes(preset?.[cpvs_mode]?.id)
                ? MSG_SAVE_PRESET
                : MSG_UPDATE_PRESET}
            </button>
          </div>
        </div>
      </Spin>
    </Fragment>
  );
};
export default MapGraphCpVsPreset;
