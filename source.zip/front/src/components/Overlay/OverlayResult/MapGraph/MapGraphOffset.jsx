import React from 'react';
import { Button, InputNumber, Switch } from 'antd';
import * as SG from '../styles/OverlayResultStyle';
import { MESSAGE } from '@constants/Message';
import { SettingOutlined } from '@ant-design/icons';
import { useOverlayGraph } from '@components/Overlay/hooks/useOverlayGraph';
import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
import { useMapGraphOffset } from '../hooks/useMapGraphOffset';

const MapGraphOffset = () => {
  const { OverlayResultType: type } = useOverlayGraph();
  const {
    offset: { mode, info },
    resetOffset,
    changeOffset,
  } = useMapGraphOffset();

  return (
    <RibbonCollapse title={MESSAGE.OFFSET_XY} defaultValue={true}>
      <div className="svg-box">
        <SettingOutlined />
      </div>
      <div css={SG.settingContentStyle}>
        <div className="content">
          <div css={SG.contentItemStyle} className="column-3">
            <div
              className="switch-wrapper"
              style={{
                display: 'inline-flex',
                flexDirection: 'column',
                width: '80px',
              }}
            >
              <Switch
                checkedChildren={'auto'}
                unCheckedChildren={'Manual'}
                checked={mode === 'auto'}
                onChange={(e) =>
                  changeOffset({ mode: e === true ? 'auto' : 'manual' }, type)
                }
                style={{ marginBottom: '5px' }}
              />
              <Button
                type="dashed"
                size="small"
                shape="round"
                disabled={mode === 'auto'}
                style={{ height: '21px', fontWeight: '600' }}
                onClick={() => resetOffset(type)}
              >
                {'RESET'}
              </Button>
            </div>
            <span className="title">{MESSAGE.OFFSET_X}</span>
            <span className="title">{MESSAGE.OFFSET_Y}</span>
          </div>
          {Object.keys(info).map((shotN, i) => (
            <div
              css={SG.contentItemStyle}
              className="column-3"
              key={`${shotN}_${i}`}
            >
              <span className="label-2">{`Shot ${shotN}`}</span>
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset X"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
                value={info?.[shotN]?.x ?? ''}
                onChange={(e) => changeOffset({ [shotN]: { x: e } }, type)}
                disabled={mode === 'auto'}
              />
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset Y"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
                value={info?.[shotN]?.y ?? ''}
                onChange={(e) => changeOffset({ [shotN]: { y: e } }, type)}
                disabled={mode === 'auto'}
              />
            </div>
          ))}
        </div>
      </div>
    </RibbonCollapse>
  );
};

export default MapGraphOffset;
