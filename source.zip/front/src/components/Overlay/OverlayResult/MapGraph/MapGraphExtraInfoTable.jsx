import React, { useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { Table } from 'antd';
import { css } from '@emotion/react';
import { OVERLAY_OAS_BASELINE_CATEGORY } from '@constants/etc';
import { MSG_MAX, MSG_MIN } from '@constants/Message';
import { getTableForm } from '@libs/util/util';
import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
const tableWrapper = css`
  display: contents;
`;

const MapGraphExtraInfoTable = ({ lot_id, lot_idx }) => {
  const { currentData, mode } = useCommonOverlay();
  const {
    info: { origin },
  } = currentData;
  const data =
    mode === OVERLAY_OAS_BASELINE_CATEGORY ? origin.map : origin.data;
  const lot_title = `LOT ${lot_idx}`;
  const getTableFuc = useCallback((data) => {
    const range = data.extra_info.range;
    const data_value = Object.values(range);
    const disp_order = Object.keys(range ?? {});
    const row = [MSG_MIN, MSG_MAX].map((key, i) => {
      return data_value.reduce(
        (acc, o, j) => ({ ...acc, [disp_order[j]]: o[i] }),
        {
          [lot_title]: key,
        },
      );
    });
    return getTableForm({
      info: { disp_order: [lot_title].concat(disp_order), row: row } ?? {},
    });
  }, []);
  const tableData = useMemo(
    () => getTableFuc(data?.[lot_id]),
    [[lot_id, data, getTableFuc]],
  );

  return (
    <>
      <div css={tableWrapper}>
        <Table
          bordered
          pagination={false}
          columns={tableData.columns ?? []}
          dataSource={tableData.dataSource ?? []}
          size="middle"
          rowKey="key"
          scroll={{ x: 'max-content' }}
        />
      </div>
    </>
  );
};
MapGraphExtraInfoTable.propTypes = {
  lot_id: PropTypes.string,
  lot_idx: PropTypes.number,
};

export default MapGraphExtraInfoTable;
