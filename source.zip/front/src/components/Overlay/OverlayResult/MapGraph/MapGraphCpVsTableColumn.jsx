import { Select, InputNumber } from 'antd';
import PropTypes from 'prop-types';
import { useMapGraphCpvsTable } from '../hooks/useMapGraphCpvsTable';
import { useMapGraphCpvs } from '../hooks/useMapGraphCpvs';
import { E_CPVS_ADC_MEASUREMENT, E_CPVS_BASELINE } from '@constants/etc';
import {
  CP_VS_DISPLAY_LIST,
  CPVS_MODE as Mode,
  CP_VS_BASELINE_DISPLAY_LIST,
  OVERLAY_CPVS_MIN_MAX,
} from '@constants/OverlayDefault';

const MapGraphCpVsTableColumn = ({ shotN, shotInfo }) => {
  const { changeCpvsColumnData: changeEvent } = useMapGraphCpvsTable();
  const {
    cpvs_origin: origin,
    cpvs_setting: { mode },
    cpvs_mode,
  } = useMapGraphCpvs();

  const { shot, expo_mode } = origin?.[cpvs_mode] ?? origin;

  const ChangeFunc = (key, value) => {
    changeEvent({
      shot: shotN,
      info: {
        ...shotInfo,
        [key]: value,
      },
    });
  };
  if (!shotInfo ?? true) return <></>;
  return (
    <tr>
      <td style={{ minWidth: '70px' }}>Shot {shotN}:</td>
      {Object.keys(shotInfo ?? {})
        .filter((o) => o !== 'display')
        .map((o, idx) => (
          <td key={idx}>
            <InputNumber
              style={{ minWidth: '130px' }}
              min={OVERLAY_CPVS_MIN_MAX[o]?.min}
              max={OVERLAY_CPVS_MIN_MAX[o]?.max}
              value={mode === Mode.FROM_LOG ? '' : shotInfo[o]}
              onChange={(v) => ChangeFunc(o, v)}
              disabled={
                mode === Mode.FROM_LOG ||
                (mode === Mode.SAME && parseInt(shotN) !== shot[0])
              }
            />
          </td>
        ))}
      <td>
        {!!shotInfo.display && (
          <Select
            style={{ minWidth: '100px' }}
            disabled={expo_mode !== 30}
            value={shotInfo.display}
            onChange={(v) => ChangeFunc('display', v)}
          >
            {(cpvs_mode === E_CPVS_ADC_MEASUREMENT
              ? CP_VS_DISPLAY_LIST
              : cpvs_mode === E_CPVS_BASELINE
              ? CP_VS_BASELINE_DISPLAY_LIST
              : []
            ).map((item, j) => (
              <Select.Option value={item} key={j}>
                {item}
              </Select.Option>
            ))}
          </Select>
        )}
      </td>
    </tr>
  );
};
MapGraphCpVsTableColumn.propTypes = {
  shotN: PropTypes.string,
  shotInfo: PropTypes.object,
};
export default MapGraphCpVsTableColumn;
