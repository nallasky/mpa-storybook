import { Fragment, useState } from 'react';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import { InputNumber, Divider } from 'antd';
import * as SG from '../styles/OverlayResultStyle';
import PropTypes from 'prop-types';
import { Common, Overlay } from '@assets/locale/en';
import { E_OVERLAY_MAP } from '@constants/etc';
import { BulbOutlined } from '@ant-design/icons';
const {
  graph_setting: {
    map: {
      etc: { scale: message },
    },
  },
} = Overlay;
const scaleInitialValue = {
  div: {},
  plate_size: {},
};
const MapGraphEtcScaleModal = ({ origin, type, onSave, onClose }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [scale, setScale] = useState(origin ?? scaleInitialValue);
  const modalClose = () => {
    setIsVisible(false);
    onClose();
  };
  const modalOk = () => {
    onSave(scale);
    modalClose();
  };
  const divScaleChange = (key, value) => {
    setScale((prev) => ({
      ...prev,
      div: {
        ...prev.div,
        [key]: value,
      },
    }));
  };
  const plateSizeChange = (key, value) => {
    setScale((prev) => ({
      ...prev,
      plate_size: { ...prev.plate_size, [key]: value },
    }));
  };

  return (
    <Fragment>
      <DraggableModal
        visible={isVisible}
        title={'Graph Scale Setting'}
        width={500}
        footer={null}
        centered
        maskClosable={false}
        cancelHandler={modalClose}
        css={SG.SegmentedStyle}
      >
        <div className="message-box">
          <BulbOutlined />
          <span>{message.message}</span>
        </div>
        <div className="segmented-content">
          <div className="segmented-style">
            <div css={SG.contentItemStyle}>
              <div>
                <Divider className="divider-line" orientation="left">
                  {message.div.label}
                </Divider>
                <div
                  className={
                    type !== E_OVERLAY_MAP ? 'flex-between' : 'limit-right'
                  }
                >
                  {type !== E_OVERLAY_MAP && (
                    <Fragment>
                      <div className="column">
                        <span className="margin-r">
                          {message.div.div_lower}
                        </span>
                        <InputNumber
                          min={0.1}
                          max={10.0}
                          step={0.1}
                          style={{ width: '22%' }}
                          value={scale.div?.div_lower ?? ''}
                          onChange={(v) => divScaleChange('div_lower', v)}
                        />
                      </div>
                    </Fragment>
                  )}
                  <div className="column">
                    <span className="margin-r">{message.div.div_upper}</span>
                    <InputNumber
                      min={0.1}
                      max={10.0}
                      step={0.1}
                      value={scale.div?.div_upper ?? ''}
                      onChange={(v) => divScaleChange('div_upper', v)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="segmented-style">
            <div css={SG.contentItemStyle}>
              <div>
                <Divider className="divider-line" orientation="left">
                  {message.plate_size.label}
                </Divider>
                <div className="flex-between">
                  <div className="column">
                    <span>{message.plate_size.size_x}</span>
                    <InputNumber
                      min={1000}
                      max={9999}
                      style={{ width: '30%' }}
                      value={scale.plate_size.size_x}
                      onChange={(e) => plateSizeChange('size_x', e)}
                    />
                  </div>
                  <div className="column">
                    <span>{message.plate_size.size_y}</span>
                    <InputNumber
                      min={1000}
                      max={9999}
                      style={{ width: '30%' }}
                      value={scale.plate_size.size_y}
                      onChange={(e) => plateSizeChange('size_y', e)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="model-button">
            <button css={SG.antdButtonStyle} className="blue" onClick={modalOk}>
              {Common.Btn_Apply}
            </button>
          </div>
        </div>
      </DraggableModal>
    </Fragment>
  );
};
MapGraphEtcScaleModal.propTypes = {
  origin: PropTypes.object.isRequired,
  onSave: PropTypes.func,
  onClose: PropTypes.func,
  type: PropTypes.string,
};

export default MapGraphEtcScaleModal;
