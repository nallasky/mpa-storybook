import { Fragment, useEffect, useState } from 'react';
import * as SG from '../styles/OverlayResultStyle';
import { RibbonCollapse } from '../../../common/molecules/RibbonCollapse/RibbonCollapse';
import CustomRadioGroup from '../../../common/molecules/CustomRadioGroup/CustomRadioGroup';
import {
  E_CPVS_ADC_MEASUREMENT,
  E_CPVS_BASELINE,
  E_CPVS_CORRECTION,
  OVERLAY_CORRECTION_CATEGORY,
  OVERLAY_OAS_BASELINE_CATEGORY,
} from '@constants/etc';
import { MESSAGE } from '@constants/Message';
import { OVERLAY_CORRECTION_CPVS_LIST } from '@constants/OverlayDefault';
import MapGraphCpvsJobFile from './MapGraphCpvsJobFile';
import useCommonOverlay, {
  OverlayCpVsInfo,
} from '../../hooks/useCommonOverlay';
import MapGraphCpVsTable from './MapGraphCpVsTable';
import MapGraphCpVsMode from './MapGraphCpvsMode';
import MapGraphCpVsPreset from './MapGraphCpVsPreset';
import MapGraphCpVsCorrectionTable from './MapGraphCpVsCorrectionTable';

const MapGraphCpvs = () => {
  const { mode, currentData } = useCommonOverlay();
  const [current, setCurrent] = useState(E_CPVS_ADC_MEASUREMENT);
  const {
    graph,
    info: { origin },
  } = currentData;
  const { cp_vs } = graph?.map ?? graph;
  useEffect(() => {
    setCurrent(
      mode === OVERLAY_OAS_BASELINE_CATEGORY
        ? E_CPVS_BASELINE
        : E_CPVS_ADC_MEASUREMENT,
    );
  }, [mode]);

  if (!cp_vs) return <Fragment></Fragment>;
  return (
    <RibbonCollapse title={MESSAGE.CP_VS} defaultValue={true} useGrid={false}>
      <OverlayCpVsInfo.Provider
        value={{
          cpvs_mode: current,
          cpvs_setting: cp_vs[current],
          cpvs_origin: origin.cp_vs,
        }}
      >
        <div
          css={SG.settingContentStyle}
          className={current === E_CPVS_CORRECTION ? 'full-width' : ''}
        >
          <div className="content">
            {mode === OVERLAY_CORRECTION_CATEGORY &&
              !!origin.cp_vs?.[E_CPVS_CORRECTION] && (
                <div className="radio-wrapper">
                  <CustomRadioGroup
                    changeFunc={setCurrent}
                    currentChecked={current}
                    options={OVERLAY_CORRECTION_CPVS_LIST}
                    name="cp-vs-option"
                    className="cp-vs"
                  />
                </div>
              )}
            <div
              className={
                'tab ' +
                (current !== E_CPVS_CORRECTION ? '' : 'correction-cp-vs')
              }
            >
              {current !== E_CPVS_CORRECTION ? (
                <Fragment>
                  <MapGraphCpVsPreset />
                  <MapGraphCpVsMode />
                  <MapGraphCpVsTable />
                  <MapGraphCpvsJobFile />
                </Fragment>
              ) : (
                <Fragment>
                  <MapGraphCpVsPreset />
                  <MapGraphCpVsMode />
                  <div className="table-wrapper">
                    <MapGraphCpVsCorrectionTable mode={'cp'} />
                    <MapGraphCpVsCorrectionTable mode={'vs'} />
                  </div>
                </Fragment>
              )}
            </div>
          </div>
        </div>
      </OverlayCpVsInfo.Provider>
    </RibbonCollapse>
  );
};

export default MapGraphCpvs;
