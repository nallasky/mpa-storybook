import React from 'react';
import { Button, Upload } from 'antd';
import * as SG from '../styles/OverlayResultStyle';
import { UploadOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';
import { useMapGraphCpvsJobFile } from '../hooks/useMapGraphCpvsJobFile';
import { MESSAGE } from '@constants/Message';
import { CPVS_MODE } from '@constants/OverlayDefault';

const MapGraphCpvsJobFile = () => {
  const { jobFileUploadProp, uploading, cpVsMode } = useMapGraphCpvsJobFile();

  return (
    <div css={SG.contentItemStyle} className="column-3">
      <span className="label-2 margin-off">{MESSAGE.JOB_FILE_UPLOAD}</span>
      <Upload {...jobFileUploadProp}>
        <Button
          icon={<UploadOutlined />}
          loading={uploading}
          disabled={cpVsMode === CPVS_MODE.FROM_LOG}
        >
          {uploading ? 'uploading' : 'Start Upload'}
        </Button>
      </Upload>
    </div>
  );
};
MapGraphCpvsJobFile.propTypes = {
  mode: PropTypes.string,
  obj: PropTypes.object,
};

export default MapGraphCpvsJobFile;
