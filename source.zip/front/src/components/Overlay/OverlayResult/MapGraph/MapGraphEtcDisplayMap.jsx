import { Divider, InputNumber, Tooltip } from 'antd';
import { Overlay } from '@assets/locale/en';
import { QuestionCircleOutlined } from '@ant-design/icons';
import { useMapGraphEtc } from '../hooks/useMapGraphEtc';
const {
  graph_setting: {
    map: {
      etc: { display_map: message },
    },
  },
} = Overlay;
const MapGraphEtcDisplayMap = () => {
  const {
    display_map: value,
    updateDisplayMapSetting,
    origin: { display_map },
  } = useMapGraphEtc();
  return (
    <div className="content-box">
      <Divider className="divider-line" orientation="left">
        {message.label}
        <Tooltip className="title-tooltip" title={message.tooltip}>
          <QuestionCircleOutlined />
        </Tooltip>
      </Divider>
      <div className="flex-between">
        <InputNumber
          min={display_map?.min ?? 1}
          max={value?.max ?? 30}
          value={value?.min ?? 1}
          onChange={(e) => updateDisplayMapSetting({ min: e })}
        />
        <span style={{ margin: '0px 10px' }}> ~ </span>
        <InputNumber
          min={value?.min ?? 1}
          max={display_map?.max}
          value={value?.max ?? 30}
          onChange={(e) => updateDisplayMapSetting({ max: e })}
        />
      </div>
    </div>
  );
};
export default MapGraphEtcDisplayMap;
