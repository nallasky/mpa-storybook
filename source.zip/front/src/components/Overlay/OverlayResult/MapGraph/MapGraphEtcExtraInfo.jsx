import { Divider, Switch, Tooltip } from 'antd';
import { Overlay } from '@assets/locale/en';
import { useMapGraphEtc } from '../hooks/useMapGraphEtc';
import { QuestionCircleOutlined } from '@ant-design/icons';
const {
  graph_setting: {
    map: {
      etc: { show_extra_info: message },
    },
  },
} = Overlay;
const MapGraphEtcExtraInfo = () => {
  const { show_extra_info: value, updateDisplayShowExtraInfoSetting } =
    useMapGraphEtc();
  return (
    <div className="content-box scale-button">
      <Divider className="divider-line" orientation="left">
        {message.label}
        <Tooltip className="title-tooltip" title={message.tooltip}>
          <QuestionCircleOutlined />
        </Tooltip>
      </Divider>
      <div className="content-button">
        <div>
          <Switch
            checked={value ?? false}
            onChange={updateDisplayShowExtraInfoSetting}
          />
        </div>
      </div>
    </div>
  );
};
export default MapGraphEtcExtraInfo;
