import React from 'react';
import { useMapGraphCpvs } from '../hooks/useMapGraphCpvs';
import * as SG from '../styles/OverlayResultStyle';
import MapGraphCpVsTableColumn from './MapGraphCpVsTableColumn';

const MapGraphCpVsTable = () => {
  const { cpvs_origin, cpvs_setting, cpvs_mode } = useMapGraphCpvs();

  const { default: def } = cpvs_origin?.[cpvs_mode] ?? cpvs_origin;

  return (
    <div className="table-wrapper">
      <table css={SG.tableStyle}>
        <thead>
          <tr>
            <th>{'SHOT'}</th>
            {Object.keys(def ?? {})?.map((o, i) => (
              <th key={`h_${i}`}>{o.toUpperCase()}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Object.entries(cpvs_setting?.shots ?? {})?.map((shot, i) => {
            return (
              <MapGraphCpVsTableColumn
                shotInfo={shot[1]}
                key={`shot_${i}`}
                shotN={shot[0]}
              />
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default MapGraphCpVsTable;
