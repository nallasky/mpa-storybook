import { Fragment } from 'react';
import { useMapGraphCpvs } from '../hooks/useMapGraphCpvs';
import { Radio } from 'antd';
import { E_CPVS_CORRECTION } from '@constants/etc';
import { MESSAGE } from '@constants/Message';
import { CPVS_MODE } from '@constants/OverlayDefault';
import * as SG from '../styles/OverlayResultStyle';

const MapGraphCpVsMode = () => {
  const {
    cpvsModeChangeFunc,
    cpvs_mode,
    cpvs_setting: { mode },
    cpvs_origin,
  } = useMapGraphCpvs();
  const { included } = cpvs_origin?.[cpvs_mode] ?? cpvs_origin;
  return (
    <div css={SG.contentItemStyle} className="column-3">
      <span className="label-2 margin-off">{MESSAGE.CP_VS}</span>
      <Radio.Group
        value={mode ?? CPVS_MODE.FROM_LOG}
        className="radio-cp-vs"
        onChange={(e) => cpvsModeChangeFunc(e, cpvs_mode)}
      >
        {cpvs_mode !== E_CPVS_CORRECTION ? (
          <Radio value={CPVS_MODE.FROM_LOG} disabled={!included}>
            {MESSAGE.CP_VS_FROM_LOG}
          </Radio>
        ) : (
          <Fragment></Fragment>
        )}
        <Radio value={CPVS_MODE.EACH}>{MESSAGE.CP_VS_EACH_SHOT}</Radio>
        <Radio className="radio-title" value={CPVS_MODE.SAME}>
          {MESSAGE.CP_VS_SHOT1_SAME}
        </Radio>
      </Radio.Group>
    </div>
  );
};

export default MapGraphCpVsMode;
