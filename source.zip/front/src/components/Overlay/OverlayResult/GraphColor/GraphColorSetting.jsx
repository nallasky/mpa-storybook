import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
import { Fragment } from 'react';
import * as SG from '../styles/OverlayResultStyle';
import { FormatPainterOutlined, DownCircleFilled } from '@ant-design/icons';
import { Button } from 'antd';
import { usePlotGraphColorSetting } from '../hooks/usePlotGraphColorSetting';
import { Overlay } from '@assets/locale/en';
import useModal from '@libs/util/modalControl/useModal';
import GraphColorDisplaySettingModal from '@components/common/organisms/GraphColorDisplaySettingModal/GraphColorDisplaySettingModal';

const {
  graph_setting: { color: message },
} = Overlay;

const GraphColorSetting = () => {
  const { colorMenu, color, updateColorSetting } = usePlotGraphColorSetting();
  const { openModal } = useModal();

  const openColorModal = () => {
    openModal(GraphColorDisplaySettingModal, {
      data: color,
      saveCallback: updateColorSetting,
    });
  };

  console.log('color test -------', colorMenu);
  return (
    <Fragment>
      <RibbonCollapse title={message.label} defaultValue={true}>
        <div className="svg-box">
          <FormatPainterOutlined />
        </div>
        <div>
          <div className="content">
            <div css={SG.contentItemStyle}>
              <div css={SG.GraphColorSettingStyle}>
                <div css={SG.testDropDown}>
                  <span className="dropdown">
                    <Button
                      css={SG.GraphColorButtonStyle}
                      className="dropBtn"
                      onClick={openColorModal}
                    >
                      {message.change.label}
                      <DownCircleFilled />
                    </Button>
                  </span>
                </div>
                <div css={SG.divSubColorStyle}>
                  <div css={SG.subColorStyle}>
                    {Object.keys(color ?? {})
                      .filter((o) =>
                        ['true', '1', 1, true].includes(color[o].display),
                      )
                      .map((job, i) => (
                        <Fragment key={`enable_${i}`}>
                          <button
                            className="rc-color-picker-trigger"
                            style={{ backgroundColor: `${color[job].color}` }}
                          />
                          <span>{job}</span>
                        </Fragment>
                      ))}
                    {Object.keys(color ?? {})
                      .filter((o) =>
                        ['false', '0', 0, false].includes(color[o].display),
                      )
                      .map((job, i) => (
                        <Fragment key={`disable_${i}`}>
                          <button
                            className="rc-color-picker-trigger"
                            style={{ backgroundColor: `var(--ckr-gray-6)` }}
                          />
                          <span style={{ color: ` var(--ckr-gray-6)` }}>
                            {job}
                          </span>
                        </Fragment>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </RibbonCollapse>
    </Fragment>
  );
};
export default GraphColorSetting;
