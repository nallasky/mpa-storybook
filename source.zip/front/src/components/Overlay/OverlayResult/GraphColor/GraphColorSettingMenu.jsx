import * as SG from './styles/GraphColorSettingMenuStyle';
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Panel from 'rc-color-picker/lib/Panel';
import { Checkbox } from 'antd';
import { CloseOutlined } from '@ant-design/icons';

export const GraphColorSettingMenu = ({ closer, colorList, changeFunc }) => {
  const [currentColor, setCurrentColor] = useState({
    selected: null,
    color: null,
  });
  const [innerColorList, setInnerColorList] = useState(colorList);
  const selectColor = (item) => {
    setCurrentColor({
      selected: item,
      color: innerColorList[item].color,
    });
  };
  const changeColor = (colors) => {
    const { color } = colors;
    setCurrentColor((prev) => ({
      ...prev,
      color: color,
    }));
    setInnerColorList((prev) => ({
      ...prev,
      [currentColor.selected]: {
        ...prev[currentColor.selected],
        color: color,
      },
    }));
  };

  const changeDisplay = (key, checked) => {
    console.log('key', key);
    console.log('checked', checked);
    setInnerColorList((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        display: checked,
      },
    }));
  };

  const onApply = () => {
    changeFunc(innerColorList);
    closer();
  };
  const onCloser = () => {
    closer();
  };

  useEffect(() => {
    const list = Object.keys(colorList);
    if (list.length > 0) {
      selectColor(list[0]);
    }
  }, []);
  console.log('innerColorList', innerColorList);
  return (
    <>
      <div css={SG.colorSettingStyle}>
        <div>
          <span>Color Change</span>
          <span>Display: Check on/off</span>
        </div>
        <button onClick={onCloser}>
          <CloseOutlined />
        </button>
      </div>
      <div css={SG.ColorBoxStyle}>
        <div>
          {Object.keys(innerColorList).map((item, i) => (
            <div
              css={SG.SelectColorStyle}
              key={i}
              onClick={() => selectColor(item)}
              tabIndex="-1"
              onKeyDown={undefined}
              role="button"
              className={currentColor.selected === item ? 'selected' : ''}
            >
              <div className="display-check-box">
                <button
                  className="rc-color-picker-trigger"
                  style={{ backgroundColor: `${innerColorList[item].color}` }}
                />
                <Checkbox
                  checked={['true', '1', 1, true].includes(
                    innerColorList[item].display,
                  )}
                  onChange={({ target: { checked } }) =>
                    changeDisplay(item, checked)
                  }
                />
              </div>
              <div style={{ display: 'block', fontWeight: 'bold' }}>
                <div>{item}</div>
                <div>{innerColorList[item].color}</div>
              </div>
            </div>
          ))}
        </div>
        <div>
          <Panel
            enableAlpha={false}
            color={currentColor.color}
            onChange={changeColor}
          />
        </div>
        <div css={SG.customButtonStyle} className="color-picker">
          <button
            css={SG.antdButtonStyle}
            className="blue color-picker"
            onClick={onApply}
          >
            Apply
          </button>
        </div>
      </div>
    </>
  );
};

GraphColorSettingMenu.propTypes = {
  closer: PropTypes.func.isRequired,
  colorList: PropTypes.object,
  changeFunc: PropTypes.func.isRequired,
};
