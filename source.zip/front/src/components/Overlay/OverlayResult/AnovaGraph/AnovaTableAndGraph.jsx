import { Fragment, useMemo } from 'react';
import { useAnovaGraphTable } from '../hooks/useAnovaGraphTable';
import { Tabs, Table } from 'antd';
import { css } from '@emotion/react';
import Divider from '@components/common/atoms/Divider';

const { TabPane } = Tabs;
const tableWrapper = css`
  display: contents;
`;
const AnovaTableAndGraph = () => {
  const { list, selected, selectAnovaAxios, origin, getAnovaTableData } =
    useAnovaGraphTable();
  const dataSource = useMemo(
    () =>
      list.reduce(
        (acc, o) =>
          Object.assign(acc, { [o]: getAnovaTableData(origin?.[o] ?? {}) }),
        {},
      ),
    [origin],
  );

  return (
    <Fragment>
      <div>
        <Tabs onChange={selectAnovaAxios} type="card" activeKey={selected}>
          {list.map((tab) => (
            <TabPane tab={`Axis : ${tab}`} key={tab}>
              <div css={tableWrapper}>
                <Table
                  bordered
                  pagination={false}
                  columns={dataSource[selected].columns ?? []}
                  dataSource={dataSource[selected].dataSource ?? []}
                  size="middle"
                  rowKey="key"
                  scroll={{ x: 'max-content' }}
                />
              </div>
              <Divider />
            </TabPane>
          ))}
        </Tabs>
        {list.map((o) => (
          <div
            key={`anova_${o}`}
            id={`anova_${o}`}
            style={
              selected === o ? { display: 'contents' } : { display: 'none' }
            }
          />
        ))}
      </div>
    </Fragment>
  );
};
export default AnovaTableAndGraph;
