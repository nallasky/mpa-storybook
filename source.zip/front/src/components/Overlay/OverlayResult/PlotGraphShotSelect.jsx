import { Divider, Select, Tooltip } from 'antd';
import { Overlay } from '@assets/locale/en';
import { usePlotGraphShotSelct } from './hooks/usePlotGraphShotSelct';
import { QuestionCircleOutlined } from '@ant-design/icons';
const {
  graph_setting: {
    plot: {
      setting: { shot: message },
    },
  },
} = Overlay;
const PlotGraphShotSelect = () => {
  const { selectedShot, ShotList, ChangeShot } = usePlotGraphShotSelct();
  return (
    <div className="content-box">
      <Divider className="divider-line" orientation="left">
        {message.label}
        <Tooltip className="title-tooltip" title={message.tooltip}>
          <QuestionCircleOutlined />
        </Tooltip>
      </Divider>
      <Select
        style={{ width: '100%' }}
        value={selectedShot}
        onChange={ChangeShot}
      >
        {ShotList.map((shot, idx) => (
          <Select.Option value={shot} key={idx}>
            {shot}
          </Select.Option>
        ))}
      </Select>
    </div>
  );
};
export default PlotGraphShotSelect;
