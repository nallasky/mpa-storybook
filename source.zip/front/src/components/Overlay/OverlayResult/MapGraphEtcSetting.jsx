import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
import { SettingOutlined } from '@ant-design/icons';
import * as SG from './styles/OverlayResultStyle';
import MapGraphEtcDisplayMap from './MapGraphEtcDisplayMap';
import MapGraphEtcDisplayColumnNum from './MapGraphEtcDisplayColumnNum';
import MapGraphEtcExtraInfo from './MapGraphEtcExtraInfo';
import MapGraphEtcScale from './MapGraphEtcScale';
import { useMapGraphEtc } from './hooks/useMapGraphEtc';
import { E_OVERLAY_MAP } from '@constants/etc';

const MapGraphEtcSetting = () => {
  const {
    OverlayResultType: { id: type },
  } = useMapGraphEtc();
  return (
    <RibbonCollapse title={'Etc Setting'} defaultValue={true}>
      <div className="svg-box">
        <SettingOutlined />
      </div>
      <div css={SG.settingContentStyle}>
        <div className="content">
          <div css={SG.contentItemStyle}>
            <MapGraphEtcDisplayMap />
            <MapGraphEtcDisplayColumnNum />
            {type === E_OVERLAY_MAP && <MapGraphEtcExtraInfo />}
            <MapGraphEtcScale />
          </div>
        </div>
      </div>
    </RibbonCollapse>
  );
};
export default MapGraphEtcSetting;
