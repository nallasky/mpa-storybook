import React from 'react';
import { postFormdataRequestExport } from '@libs/axios/requests';
import { URL_EXPORT_OVERLAY } from '@constants/URL';
import useOverlaySettingInfo from '../../../hooks/common/useOverlaySettingInfo';
import {
  E_OVERLAY_ANOVA,
  E_OVERLAY_COMPONENT,
  E_OVERLAY_IMAGE,
  E_OVERLAY_REPRODUCIBILITY,
  E_OVERLAY_VARIATION,
  OVERLAY_ADC_CATEGORY,
  OVERLAY_CORRECTION_CATEGORY,
} from '@constants/etc';
import { getGraphImage2 } from '@libs/util/plotly-test';
import useOverlayResultInfo from '../../../hooks/common/useOverlayResultInfo';
import ResultDownloadForm from '../../common/molecules/ResultDownloadForm/ResultDownloadForm';
import { getTableCsv } from '@libs/util/util';
import useCommonOverlay from '../hooks/useCommonOverlay';

const ResultDownload = () => {
  const { getReAnalysisParameter } = useOverlaySettingInfo();
  const { mode, currentData: originInfo } = useCommonOverlay();
  const { getAnovaTableFuc } = useOverlayResultInfo();
  const { graph } = originInfo;

  const makeProperties = () => {
    let postData = getReAnalysisParameter(mode, originInfo);
    console.log('postData', postData);
    let obj = { ...postData };
    if (mode === OVERLAY_CORRECTION_CATEGORY) {
      Object.assign(obj, { correction: graph });
    } else {
      for (let type in graph) {
        Object.assign(obj, { [type]: graph[type] });
      }
    }
    console.log('obj', obj);
    return JSON.stringify(obj);
  };
  const makeFileName = (v) => {
    const fileList = {
      [E_OVERLAY_VARIATION]: ['shot', 'rot_mag'],
      [E_OVERLAY_REPRODUCIBILITY]: ['x', 'y'],
    };
    const FolderList = {
      [E_OVERLAY_IMAGE]: 'Correction_Image_Map',
      [E_OVERLAY_COMPONENT]: 'Correction_Component_Map',
    };

    const filename = v.split('.');
    if (Object.keys(fileList).includes(filename[0])) {
      return `${filename[0]}.${fileList[filename[0]][+filename[1]]}.png`;
    } else if (Object.keys(FolderList).includes(filename[0])) {
      return `${FolderList[filename[0]]}.${filename[1]}.png`;
    }
    return v;
  };

  const downloadFunc = async () => {
    const FormObj = new FormData();
    console.log('==============settings.json======================');
    FormObj.append(
      'setting',
      new Blob([makeProperties()], {
        type: 'application/json',
      }),
    );
    console.log('==============getGraphImage======================');
    const imgData = await getGraphImage2('_');
    imgData.forEach((v) => {
      FormObj.append('files', new File([v.url], makeFileName(v.filename)));
    });
    console.log('==============anova csv file======================');
    if (mode === OVERLAY_ADC_CATEGORY) {
      const {
        info: {
          origin: { anova },
        },
      } = originInfo;
      if (anova?.X) {
        const anovaTable_X = getAnovaTableFuc(anova?.X ?? {});
        FormObj.append(
          'files',
          new File([getTableCsv(anovaTable_X)], `${E_OVERLAY_ANOVA}.X.csv`),
        );
      }
      if (anova?.Y) {
        const anovaTable_Y = getAnovaTableFuc(anova?.Y ?? {});
        FormObj.append(
          'files',
          new File([getTableCsv(anovaTable_Y)], `${E_OVERLAY_ANOVA}.Y.csv`),
        );
      }
    }

    const { status } = await postFormdataRequestExport(
      `${URL_EXPORT_OVERLAY}/${mode}/${originInfo.source_info.files_rid}`,
      FormObj,
    );
    console.log('status', status);
  };
  return <ResultDownloadForm downloadFunc={downloadFunc} />;
};
export default ResultDownload;
