import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
import { SettingOutlined } from '@ant-design/icons';
import * as SG from '../styles/OverlayResultStyle';
import PlotGraphShotSelect from './PlotGraphShotSelect';
import PlotGraphHighlightGlass from './PlotGraphHighlightGlass';
import PlotGraphScaleAndType from './PlotGraphScaleAndType';

const PlotGraphSetting = () => {
  return (
    <RibbonCollapse title={'Graph Setting'} defaultValue={true}>
      <div className="svg-box">
        <SettingOutlined />
      </div>
      <div css={SG.settingContentStyle}>
        <div className="content">
          <div css={SG.contentItemStyle}>
            <PlotGraphShotSelect />
            <PlotGraphHighlightGlass />
            <PlotGraphScaleAndType />
          </div>
        </div>
      </div>
    </RibbonCollapse>
  );
};
export default PlotGraphSetting;
