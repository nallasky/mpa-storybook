import { Fragment, useState } from 'react';
import dayjs from 'dayjs';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import { Segmented, InputNumber, Select, Divider, DatePicker, Tag } from 'antd';
import * as SG from '../styles/OverlayResultStyle';
import PropTypes from 'prop-types';
import { Common, Overlay } from '@assets/locale/en';
import { BulbOutlined } from '@ant-design/icons';
import { DATE_FORMAT } from '@constants/etc';

const {
  graph_setting: {
    plot: {
      setting: { scale_type: message },
    },
  },
} = Overlay;
const scaleInitialValue = {
  scale: {
    left: { type: '', upper_limit: '0', lower_limit: '0' },
    period: { type: '', upper_limit: '0', lower_limit: '0' },
  },
  graph_type: 'line',
};
const PlotGraphScaleAndTypeModal = ({ origin, onSave, onClose }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [scaleAndType, setScaleAndType] = useState(origin ?? scaleInitialValue);
  const modalClose = () => {
    setIsVisible(false);
    onClose();
  };
  const modalOk = () => {
    onSave(scaleAndType);
    modalClose();
  };
  const ChangeGraphLeftScale = (key, value) => {
    setScaleAndType((prev) => ({
      ...prev,
      scale: {
        ...prev.scale,
        left: {
          ...prev.scale.left,
          [key]: value,
        },
      },
    }));
  };

  const ChangeGraphPeriodScale = (key, value) => {
    setScaleAndType((prev) => ({
      ...prev,
      scale: {
        ...prev.scale,
        period:
          key === 'selected'
            ? {
                ...prev.scale.period,
                lower_limit: value[0],
                upper_limit: value[1],
              }
            : {
                ...prev.scale.period,
                [key]: value,
              },
      },
    }));
  };
  const ChangeGraphType = (v) => {
    setScaleAndType((prev) => ({
      ...prev,
      graph_type: v,
    }));
  };
  console.log('scaleAndType', scaleAndType);
  return (
    <Fragment>
      <DraggableModal
        visible={isVisible}
        title={message.label}
        width={500}
        footer={
          <div className="model-button">
            <button css={SG.antdButtonStyle} className="blue" onClick={modalOk}>
              {Common.Btn_Apply}
            </button>
          </div>
        }
        centered
        maskClosable={false}
        cancelHandler={modalClose}
        css={SG.SegmentedStyle}
      >
        <div className="message-box">
          <BulbOutlined />
          <span>{message.modal_msssage}</span>
        </div>

        <div className="segmented-content">
          <div className="segmented-style">
            <div className="segmented-box">
              <div style={{ width: '100%' }}>
                <Divider className="divider-line" orientation="left">
                  {message.graph_type.label}
                </Divider>
                <div className="content-right">
                  <Select
                    style={{ width: '13rem' }}
                    value={scaleAndType.graph_type}
                    onChange={ChangeGraphType}
                  >
                    <Select.Option value="line">
                      {message.graph_type.options.line}
                    </Select.Option>
                    <Select.Option value="scatter">
                      {message.graph_type.options.scatter}
                    </Select.Option>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="segmented-content">
          <div className="segmented-style">
            <Divider className="divider-line" orientation="left">
              {message.left_scale.label}
            </Divider>
            <div className="segmented-box" style={{}}>
              <Segmented
                onChange={(v) => ChangeGraphLeftScale('type', v)}
                value={scaleAndType.scale?.left.type ?? ''}
                options={[
                  {
                    label: `${message.left_scale.type.options.auto}`,
                    value: 'auto',
                  },
                  {
                    label: `${message.left_scale.type.options.manual}`,
                    value: 'manual',
                  },
                ]}
              />
            </div>
            <div css={SG.contentItemStyle}>
              <div className="div-margin-top">
                <div css={SG.scaleNumberStyle}>
                  <span className="margin-r">
                    <Tag color="magenta">{message.left_scale.lower_limit}</Tag>
                  </span>
                  <InputNumber
                    max={scaleAndType.scale.left.upper_limit}
                    disabled={scaleAndType.scale.left.type === 'auto'}
                    value={scaleAndType.scale.left.lower_limit}
                    onChange={(v) => ChangeGraphLeftScale('lower_limit', v)}
                  />
                </div>
                <div css={SG.scaleNumberStyle}>
                  <span className="margin-r">
                    <Tag color="magenta">{message.left_scale.upper_limit}</Tag>
                  </span>
                  <InputNumber
                    min={scaleAndType.scale.left.lower_limit}
                    disabled={scaleAndType.scale.left.type === 'auto'}
                    value={scaleAndType.scale.left.upper_limit}
                    onChange={(v) => ChangeGraphLeftScale('upper_limit', v)}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="segmented-content">
          <div className="segmented-style">
            <Divider className="divider-line" orientation="left">
              {message.period_scale.label}
            </Divider>
            <div className="segmented-box" style={{}}>
              <Segmented
                onChange={(v) => ChangeGraphPeriodScale('type', v)}
                value={scaleAndType.scale?.period.type ?? ''}
                options={[
                  {
                    label: `${message.period_scale.type.options.auto}`,
                    value: 'auto',
                  },
                  {
                    label: `${message.period_scale.type.options.manual}`,
                    value: 'manual',
                  },
                ]}
              />
            </div>
            <div css={SG.contentItemStyle}>
              <div className="tx-center">
                <DatePicker.RangePicker
                  value={[
                    dayjs(scaleAndType.scale.period.lower_limit),
                    dayjs(scaleAndType.scale.period.upper_limit),
                  ]}
                  placeholder={[
                    dayjs(scaleAndType.scale.period.lower_limit),
                    dayjs(scaleAndType.scale.period.upper_limit),
                  ]}
                  onChange={(v) =>
                    ChangeGraphPeriodScale('selected', [
                      dayjs(v[0]).format(DATE_FORMAT),
                      dayjs(v[1]).format(DATE_FORMAT),
                    ])
                  }
                  disabled={scaleAndType.scale.period.type === 'auto'}
                  style={{ width: '100%' }}
                  inputReadOnly
                  allowClear={false}
                  showTime
                />
              </div>
            </div>
          </div>
        </div>
      </DraggableModal>
    </Fragment>
  );
};
PlotGraphScaleAndTypeModal.propTypes = {
  origin: PropTypes.object.isRequired,
  onSave: PropTypes.func,
  onClose: PropTypes.func,
};

export default PlotGraphScaleAndTypeModal;
