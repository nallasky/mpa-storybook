import { Fragment } from 'react';
import dayjs from 'dayjs';
import { Divider, Tag, Tooltip } from 'antd';
import { EditOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import * as SG from '../styles/OverlayResultStyle';
import PlotGraphScaleAndTypeModal from './PlotGraphScaleAndTypeModal';
import useModal from '@libs/util/modalControl/useModal';
import { usePlotGraphScaleAndType } from '../hooks/usePlotGraphScaleAndType';
import { Overlay, Common } from '@assets/locale/en';
import { DATE_FORMAT } from '@constants/etc';
const {
  graph_setting: {
    plot: {
      setting: { scale_type: message },
    },
  },
} = Overlay;

const PlotGraphScaleAndType = () => {
  const { openModal } = useModal();
  const { ApplyScaleAndType, graphScale, periodScale, graphType } =
    usePlotGraphScaleAndType();
  const onClickEvent = () => {
    openModal(PlotGraphScaleAndTypeModal, {
      origin: {
        scale: { left: graphScale, period: periodScale },
        graph_type: graphType,
      },
      onSave: ApplyScaleAndType,
      min: -999,
      max: 999,
    });
  };
  return (
    <Fragment>
      <div className="content-box scale-button">
        <Divider className="divider-line" orientation="left">
          {message.label}
          <Tooltip className="title-tooltip" title={message.tooltip}>
            <QuestionCircleOutlined />
          </Tooltip>
        </Divider>
        <div className="content-button">
          <div>
            <button
              css={SG.antdButtonStyle}
              className="white edit"
              onClick={onClickEvent}
            >
              <EditOutlined />
              {Common.Btn_Edit}
            </button>
          </div>
        </div>
      </div>
      <div css={SG.contentItemStyle} className="limit-box">
        <span className="limit-title">{message.graph_type.label}</span>
        <div className="limit-box-scale">
          <Tag color={'blue'}>{message.graph_type.options[graphType]}</Tag>
        </div>
      </div>
      <div css={SG.contentItemStyle} className="limit-box">
        <span className="limit-title">{message.left_scale.label}</span>
        <div className="limit-box-scale">
          {graphScale.type === 'auto' ? (
            <Tag color="blue">
              {message.left_scale.type.options[graphScale.type]}
            </Tag>
          ) : (
            <Fragment>
              <Tag color="magenta">
                {message.left_scale.type.options[graphScale.type]}
              </Tag>
              <div className="flex-between limit-scale">
                <div className="limit-center">{graphScale.lower_limit}</div>
                <span> ~ </span>
                <div className="limit limit-center">
                  {graphScale.upper_limit}
                </div>
              </div>
            </Fragment>
          )}
        </div>
      </div>
      <div css={SG.contentItemStyle} className="limit-box">
        <span className="limit-title">{message.period_scale.label}</span>
        <div className="limit-box-scale">
          {periodScale.type === 'auto' ? (
            <Tag color="blue">
              {message.period_scale.type.options[periodScale.type]}
            </Tag>
          ) : (
            <Fragment>
              <Tag color="magenta">
                {message.period_scale.type.options[periodScale.type]}
              </Tag>
              <div className="flex-between limit-scale ">
                <div css={SG.contentItemStyle} className="limit-center">
                  {dayjs(periodScale.lower_limit).format(DATE_FORMAT)}
                </div>
                <span> ~ </span>
                <div css={SG.contentItemStyle} className="limit-center limit">
                  {dayjs(periodScale.upper_limit).format(DATE_FORMAT)}
                </div>
              </div>
            </Fragment>
          )}
        </div>
      </div>
    </Fragment>
  );
};

export default PlotGraphScaleAndType;
