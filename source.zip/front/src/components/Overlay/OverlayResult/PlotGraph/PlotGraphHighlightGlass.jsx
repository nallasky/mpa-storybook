import React from 'react';
import { Divider, Select, Tooltip } from 'antd';
import { Overlay } from '@assets/locale/en';
import { QuestionCircleOutlined } from '@ant-design/icons';
import { usePlotGraphHighLightGlass } from '../hooks/usePlotGraphHighLightGlass';
const {
  graph_setting: {
    plot: {
      setting: { highlighting: message },
    },
  },
} = Overlay;
const PlotGraphHighlightGlass = () => {
  const { highlight_glass, ChangeHighLightGlass, selectedShot } =
    usePlotGraphHighLightGlass();

  return (
    <div className="content-box">
      <Divider className="divider-line" orientation="left">
        {message.label}
        <Tooltip className="title-tooltip" title={message.tooltip}>
          <QuestionCircleOutlined />
        </Tooltip>
      </Divider>
      <Select
        style={{ width: '100%' }}
        value={highlight_glass.selected}
        onChange={ChangeHighLightGlass}
        allowClear
      >
        {(highlight_glass.list?.[selectedShot] ?? []).map((glassId, idx) => (
          <Select.Option value={glassId} key={idx}>
            {glassId}
          </Select.Option>
        ))}
      </Select>
    </div>
  );
};
export default PlotGraphHighlightGlass;
