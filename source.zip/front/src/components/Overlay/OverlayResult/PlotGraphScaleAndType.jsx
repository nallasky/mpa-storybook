import { Fragment } from 'react';
import { Divider, Tag, Tooltip } from 'antd';
import { EditOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import * as SG from './styles/OverlayResultStyle';
import PlotGraphScaleAndTypeModal from './PlotGraphScaleAndTypeModal';
import useModal from '@libs/util/modalControl/useModal';
import { usePlotGraphScaleAndType } from './hooks/usePlotGraphScaleAndType';
import { Overlay, Common } from '@assets/locale/en';
const {
  graph_setting: {
    plot: {
      setting: { scale_type: message },
    },
  },
} = Overlay;

const PlotGraphScaleAndType = () => {
  const { openModal } = useModal();
  const { ApplyScaleAndType, graphScale, graphType } =
    usePlotGraphScaleAndType();
  const onClickEvent = () => {
    openModal(PlotGraphScaleAndTypeModal, {
      origin: { scale: graphScale, graph_type: graphType },
      onSave: ApplyScaleAndType,
      min: -999,
      max: 999,
    });
  };
  return (
    <Fragment>
      <div className="content-box scale-button">
        <Divider className="divider-line" orientation="left">
          {message.label}
          <Tooltip className="title-tooltip" title={message.tooltip}>
            <QuestionCircleOutlined />
          </Tooltip>
        </Divider>
        <div className="content-button">
          <div>
            <button
              css={SG.antdButtonStyle}
              className="white edit"
              onClick={onClickEvent}
            >
              <EditOutlined />
              {Common.Btn_Edit}
            </button>
          </div>
        </div>
      </div>
      <div css={SG.contentItemStyle} className="limit-box">
        <span className="limit-title">{message.graph_type.label}</span>
        <div className="limit-box-scale">
          <Tag color={'blue'}>{message.graph_type.options[graphType]}</Tag>
        </div>
      </div>
      <div css={SG.contentItemStyle} className="limit-box">
        <span className="limit-title">{message.left_scale.label}</span>
        <div className="limit-box-scale">
          {graphScale.type === 'auto' ? (
            <Tag color="blue">
              {message.left_scale.type.options[graphScale.type]}
            </Tag>
          ) : (
            <Fragment>
              <Tag color="magenta">
                {message.left_scale.type.options[graphScale.type]}
              </Tag>
              <div className="flex-between limit-scale ">
                <div css={SG.contentItemStyle} className="flex-between">
                  <span className="label-2">
                    {message.left_scale.lower_limit}
                  </span>
                  {graphScale.lower_limit}
                </div>
                <div css={SG.contentItemStyle} className="flex-between limit">
                  <span className="label-2">
                    {message.left_scale.upper_limit}
                  </span>
                  {graphScale.upper_limit}
                </div>
              </div>
            </Fragment>
          )}
        </div>
      </div>
    </Fragment>
  );
};

export default PlotGraphScaleAndType;
