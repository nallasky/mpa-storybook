import { css } from '@emotion/react';

export const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 400px;
  background-color: var(--ckr-gray-1);
  border-radius: 4px;
  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3),
    0 2px 6px 2px rgba(60, 64, 67, 0.15);
  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 2rem;
    grid-column: 1 / span 2;
  }
`;

export const controlStyle = css`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  & .box-flex {
    display: flex;
  }
`;

export const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-color: var(--ckr-gray-1);
  border: none;
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: var(--ckr-blue-6);
      transition: transform 0.3s ease-in-out;
      will-change: transform;
      &:hover {
        transform: scale(1.4);
      }
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: -5px;
    right: 0;
    & > span:first-of-type {
      color: var(--ckr-green-6);
    }
  }
  &.scroll-button {
    background-color: transparent;
    &:disabled {
      display: none;
    }
    & > span {
      &:first-of-type {
        font-size: 50px;
      }
      &:last-of-type {
        font-size: 16px;
      }
    }
  }
  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
    & > span:first-of-type {
      color: var(--ckr-gray-6);
    }
  }
`;

export const settingStyle = css`
  position: relative;
  & > .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    & > span {
      font-size: 18px;
    }
    & > div > button + button {
      margin-left: 1rem;
    }
  }
  & > .main {
    & > div + div {
      margin-top: 2rem;
    }
  }
`;

export const resultStyle = css`
  position: relative;
  min-height: 300px;
  background-color: var(--ckr-gray-1);
  border-radius: 4px;
  box-shadow: 0 0 8px 2px rgba(0, 0, 0, 0.15);
  padding: 1rem;
  & .plot-container {
    overflow-x: scroll;
    touch-action: auto;
    & .modebar-container {
      right: -113px !important;
    }
  }
  & .modebar {
    display: contents;
    float: left;
  }
`;

export const settingContentStyle = css`
  position: relative;
  margin: 0 auto;
  width: 100%;
  padding: 1rem;
  &.full-width {
    width: 100%;
  }
  &.correction-cp-vs {
    width: 100%;
  }
  & .content > .radio-wrapper ~ .tab {
    margin-top: 1rem;
    width: 100%;
  }
  & .table-wrapper ~ div,
  & .content > .radio-wrapper ~ .tab {
    margin-top: 1rem;
    width: 100%;
  }
`;

export const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column-3 {
    grid-template-columns: 0.4fr 1fr 1fr;
  }
  & .title {
    text-align: center;
  }
  & .content-box {
    display: grid;
    grid-template-columns: 0.7fr 0.3fr;
    align-items: center;
    gap: 10px;
    & .title-tooltip {
      margin-left: 10px;
      color: var(--ckr-blue-6);
    }
    & .divider-line::before {
      width: 20px;
    }
    & .content-button > div {
      float: right;
    }
    & .ant-input-number {
      width: 100%;
    }
  }
  & .scale-button {
    grid-template-columns: 1fr 0fr;
  }
  & .content-scale {
    width: 70%;
  }
  & > span {
    position: relative;
    font-size: 14px;
    &:first-of-type {
      position: relative;
      &.label {
        &::before {
          display: inline-block;
          color: var(--ckr-red-6);
          font-size: 16px;
          content: '*';
          margin-right: 0.3rem;
        }
        &::after {
          display: inline-block;
          content: ':';
        }
      }
      &.label-2 {
        margin-left: 10px;
        &::after {
          display: inline-block;
          content: ':';
        }
      }
      &.margin-off {
        margin-left: 0;
      }
    }
  }
  & ~ div {
    margin-top: 2rem;
    &.table-wrapper {
      margin-top: 1rem;
    }
  }
  & .limit-box {
    display: flex;
    width: 65%;
    justify-self: center;
    & > .limit-title {
      flex-basis: 40%;
    }
    & > .limit-box-scale {
      display: flex;
      justify-content: space-between;
      flex-basis: 100%;
      & .range-tag-margin {
        margin-right: 20px;
      }
      & .limit-center {
        width: 50%;
        text-align: center;
      }
    }
    & .ant-tag {
      border-radius: 8px;
      font-size: 12px;
    }
    & .limit-scale {
      width: 350px;
    }
    & .range-limit-scale {
      width: 512px;
    }
    & .ant-tag-blue {
      width: 90px;
      text-align: center;
      font-size: 12px;
    }
  }
  & .flex-between {
    display: flex;
    justify-content: space-between;
    align-items: center;
    & > .column {
      display: contents;
      column-gap: 5px;
    }
  }
  & .limit-right {
    display: flex;
    justify-content: right;
  }
  & .limit {
    margin-top: 0;
  }
  & > .title {
    width: 100%;
    text-align: center;
    font-size: 18px;
  }
  & > .preset-setting {
    display: flex;
    column-gap: 1rem;
    justify-content: space-between;
    & > .ant-form {
      align-self: center;
    }
  }
  & .radio-cp-vs {
    display: grid;
    grid-template-columns: repeat(3, 18rem);
    column-gap: 1rem;
    grid-column: span 2;
  }
  & .radio-title > span:last-of-type {
    white-space: pre;
  }
  .ant-form-item {
    width: 289px;
    margin-bottom: 0;
  }
  .ant-form-item-explain-connected {
    min-height: 0;
  }
  .ant-col-16 {
    max-width: 100%;
  }
  & .tx-center {
    display: flex;
    justify-content: space-around;
    align-items: center;
  }
  & .margin-lr {
    margin: 0 1rem;
  }
  & .margin-r {
    margin-right: 1rem;
  }
  & .div-margin-top {
    & > div + div {
      margin-top: 1rem;
    }
  }
`;

export const GraphColorSettingStyle = css`
  margin: 0 auto;
  width: 100%;
  display: flex;
  padding: 1rem;
  align-items: center;
`;

export const testDropDown = css`
  .dropBtn {
    cursor: pointer;
  }
  .dropdown-content {
    display: block;
    position: absolute;
    margin-top: 20px;
    z-index: 1;
    box-shadow: 0 3px 5px 1px rgb(0 0 0 / 15%);
    border-radius: 10px;
    &:after {
      position: absolute;
      left: 50px;
      top: -9px;
      width: 20px;
      height: 20px;
      z-index: 5;
      transform: rotate(225deg);
      box-shadow: 1px 1px 3px -1px rgba(0, 0, 0, 0.1);
      content: '';
      transition: all 0.2s;
      background-color: var(--ckr-gray-1);
    }
  }
`;

export const GraphColorButtonStyle = css`
  display: block;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 8px 16px;
  background: var(--ckr-gray-1);
  border: 1px dashed var(--ckr-gray-5);
  box-sizing: border-box;
  border-radius: 10px;
  margin: 0 30px 0 0;
  &:hover {
    display: block;
    background: var(--ckr-gray-1);
    border: 1px dashed var(--ckr-blue-4);
    box-sizing: border-box;
    border-radius: 10px;
  }
`;

export const divSubColorStyle = css`
  width: 100%;
  display: flex;
  flex-flow: wrap;
  white-space: pre;
`;

export const subColorStyle = css`
  display: flex;
  align-items: center;
  margin-right: 20px;
  & > span {
    cursor: context-menu;
    margin-right: 20px;
  }
  & button {
    border: none;
    height: 15px;
    width: 15px;
    border-radius: 50%;
    margin-right: 5px;
    cursor: unset;
  }
  & button.rc-color-picker-trigger {
    cursor: unset;
  }
`;

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0 2px 4px 1px rgba(0, 0, 0, 0.2);
  transition: all 0.2s;
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: var(--ckr-gray-1);
    border: 1px dashed var(--ckr-gray-5);
    &:disabled {
      color: var(--ckr-gray-6);
      background-color: var(--ckr-gray-3);
    }
  }
  &.blue {
    color: var(--ckr-gray-1);
    background-color: var(--ckr-blue-6);
    border: 1px solid var(--ckr-blue-6);
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
  &.edit {
    & span {
      margin-right: 5px;
    }
  }
`;

export const tableStyle = css`
  margin: 0 auto;
  border: 1px solid var(--ckr-gray-5);
  border-collapse: collapse;
  table-layout: auto;
  text-align: center;
  & th,
  td {
    border: 1px solid var(--ckr-gray-5);
    padding: 0.5rem;
  }
  & th {
    background-color: var(--ckr-gray-2);
  }
`;

export const SegmentedStyle = css`
  .ant-modal-body {
    padding: 0;
  }
  & .message-box {
    display: flex;
    align-items: center;
    height: 50px;
    background-color: var(--ckr-blue-1);
    & > span {
      &:first-of-type {
        font-size: 20px;
        color: var(--ckr-blue-6);
        margin: 0 10px 0 15px;
      }
      &:last-of-type {
        color: var(--ckr-blue-10);
      }
    }
  }
  & .segmented-content {
    padding: 1rem;
    & > div + div {
      margin-top: 1rem;
    }
  }
  & .segmented-style {
    padding: 0 1rem 1rem 1rem;
    border: 1px dashed var(--ckr-gray-5);
    border-radius: 10px;
    & > div + div {
      margin: 1rem 0 0 0;
    }
    & .segmented-box {
      display: flex;
      justify-content: space-between;
      align-items: center;
      & .ant-segmented-item-selected {
        color: var(--ckr-blue-6);
      }
    }
  }
  & .model-button {
    margin-top: 1rem;
    & button {
      display: flex;
      margin-top: 0.5rem;
      margin-left: auto;
    }
  }
  & .content-right {
    float: right;
  }
`;

export const scaleNumberStyle = css`
  display: flex;
  justify-content: flex-end;
  & .ant-tag {
    border-radius: 10px;
    padding: 4px;
  }
`;
