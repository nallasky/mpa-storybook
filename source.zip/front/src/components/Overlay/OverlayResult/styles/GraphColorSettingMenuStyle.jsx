import { css } from '@emotion/react';

export const colorSettingStyle = css`
  display: flex;
  justify-content: space-between;
  padding: 10px 16px;
  border-bottom: 1px solid var(--ckr-gray-4);
  background-color: var(--ckr-gray-1);
  border-radius: 10px 10px 0 0;
  & > div {
    display: grid;
  }
  & > div > span {
    &:first-of-type {
      font-size: 16px;
      font-weight: bold;
      color: var(--ckr-gray-13);
    }
    &:last-of-type {
      font-size: 12px;
    }
  }
  & > button {
    background-color: var(--ckr-gray-1);
    border: unset;
    cursor: pointer;
    & > span {
      color: var(--ckr-gray-6);
    }
  }
  & button:hover {
    & > span {
      color: var(--ckr-gray-13);
    }
  }
`;

export const ColorBoxStyle = css`
  display: grid;
  grid-template-columns: auto 218px;
  padding: 1rem 1rem 0;
  border-radius: 10px;
  background: var(--ckr-gray-1);
  grid-gap: 5px;
  min-height: 240px;
  & > div {
    max-height: 250px;
    overflow: auto;
    & .display-check-box {
      position: relative;
      & > label {
        position: absolute;
        left: 0;
        top: -2.8px;
        & > span {
          border: 1px solid white;
          background-color: white;
          border-radius: 3px;
        }
      }
    }
    &::-webkit-scrollbar {
      width: 8px;
    }
    &::-webkit-scrollbar-track {
      background-color: transparent;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 4px;
      background-color: var(--ckr-blue-3);
    }
    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }
  }
`;

export const SelectColorStyle = css`
  display: flex;
  align-items: center;
  margin-right: 20px;
  padding: 10px 5px;
  cursor: pointer;
  border-radius: 10px;
  border: 1px solid transparent;
  & button {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    border: none;
    margin-right: 5px;
  }
  &:hover {
    border: 1px dashed var(--ckr-blue-6);
    background-color: var(--ckr-gray-1);
    color: var(--ckr-blue-6);
  }
  &.selected {
    background-color: var(--ckr-blue-6);
    color: var(--ckr-gray-1);
  }
  & + div {
    margin-top: 0.5rem;
  }
`;

export const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-color: var(--ckr-gray-1);
  border: none;
  &.color-picker {
    grid-area: 2/1/2/4;
    padding: 0.5rem;
    border-top: 1px solid var(--ckr-gray-4);
  }
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: var(--ckr-blue-6);
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: 15px;
    right: 15px;
    & > span:first-of-type {
      color: var(--ckr-green-6);
      margin: 12px 0 8px;
      font-size: 30px;
      transition: transform 0.3s ease-in-out;
      will-change: transform;
      &:hover {
        color: var(--ckr-green-6);
        background-color: #1890ff00;
        transform: scale(1.4);
      }
    }
  }
  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
    pointer-events: none;
    & > span:first-of-type {
      color: var(--ckr-gray-6);
    }
  }
`;

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: var(--ckr-gray-1);
    border: 1px dashed var(--ckr-gray-5);
    &:disabled {
      background-color: var(--ckr-gray-5);
      color: transparent;
      &::before {
        position: absolute;
        width: 100%;
        top: 5px;
        left: 0;
        content: 'X';
        color: var(--ckr-gray-1);
        font-weight: bold;
        font-size: 20px;
      }
    }
  }
  &.blue {
    color: var(--ckr-gray-1);
    background-color: var(--ckr-blue-6);
    border: 1px solid var(--ckr-blue-6);
  }
  &.color-picker {
    width: 100%;
    border-radius: 10px;
    font-weight: 400;
  }
  &.tact-download {
    margin-left: 8px;
    font-weight: 400;
  }
  &.view-graph {
    width: 136px;
    float: right;
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;
