import React from 'react';
import { Table } from 'antd';
import { css } from '@emotion/react';

const CPVSTableStyle = css`
  & .ant-table-pagination {
    display: none;
  }
`;

const dataSource = [
  {
    key: '1',
    name: 'SHOT 1',
    Back: -520.0,
    Front: 520.0,
    VSBack: 750.0,
    VSFront: 750.0,
    Display: 'Back&Front',
  },
  {
    key: '2',
    name: 'SHOT 2',
    Back: -520.0,
    Front: 520.0,
    VSBack: 750.0,
    VSFront: 750.0,
    Display: 'Back&Front',
  },
  {
    key: '3',
    name: 'SHOT 3',
    Back: -520.0,
    Front: 520.0,
    VSBack: 750.0,
    VSFront: 750.0,
    Display: 'Back&Front',
  },
  {
    key: '4',
    name: 'SHOT 4',
    Back: -520.0,
    Front: 520.0,
    VSBack: 750.0,
    VSFront: 750.0,
    Display: 'Back&Front',
  },
  {
    key: '5',
    name: 'SHOT 5',
    Back: -520.0,
    Front: 520.0,
    VSBack: 750.0,
    VSFront: 750.0,
    Display: 'Back&Front',
  },
  {
    key: '6',
    name: 'SHOT 6',
    Back: -520.0,
    Front: 520.0,
    VSBack: 750.0,
    VSFront: 750.0,
    Display: 'Back&Front',
  },
];

const columns = [
  {
    title: 'SHOT',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Back',
    dataIndex: 'Back',
    key: 'Back',
  },
  {
    title: 'Front',
    dataIndex: 'Front',
    key: 'Front',
  },
  {
    title: 'VS-Back',
    dataIndex: 'VSBack',
    key: 'VSBack',
  },
  {
    title: 'VS-Front',
    dataIndex: 'VSFront',
    key: 'VSFront',
  },
  {
    title: 'Display',
    dataIndex: 'Display',
    key: 'Display',
  },
];

export const CPVSTable = () => {
  return (
    <div css={CPVSTableStyle}>
      <Table dataSource={dataSource} columns={columns} />
    </div>
  );
};
