import React from 'react';
import * as SG from '../OasBaseline/styles/OsaBaselineStyle';
import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
import {
  SettingOutlined,
  QuestionCircleOutlined,
  DeleteOutlined,
  UploadOutlined,
  PullRequestOutlined,
  BorderInnerOutlined,
} from '@ant-design/icons';
import {
  Button,
  InputNumber,
  Switch,
  Tooltip,
  Select,
  Popconfirm,
  Radio,
  Upload,
  Popover,
} from 'antd';
import {
  MESSAGE,
  MSG_DEFAULT,
  MSG_NEW_PRESET,
  MSG_PRESET,
  MSG_SAVE,
} from '@constants/Message';
import { E_Default } from '@constants/etc';
import InputForm from '@components/common/atoms/Input/InputForm';
import { CPVS_MODE as Mode } from '@constants/OverlayDefault';
import Coordinate from '@assets/arrows_icon.svg';
import { CPVSTable } from '@components/Overlay/OasBaseline/fragments/CPVSTable';

const { Option } = Select;

const content = (
  <div css={SG.coordinateImgStyle}>
    <img src={Coordinate} alt={'Coordinate'} />
  </div>
);

export const MapResult = () => {
  return (
    <>
      <div css={SG.MapHeaderStyle}>
        <span>Map Setting</span>
        <Popover content={content} title="Coordinate" trigger="hover">
          <Button
            shape="circle"
            type="text"
            icon={<QuestionCircleOutlined />}
          />
        </Popover>
      </div>
      <RibbonCollapse title={'Offset X/Y'} defaultValue={true}>
        <div className="svg-box">
          <PullRequestOutlined />
        </div>
        <div css={SG.settingContentStyle}>
          <div className="content">
            <div css={SG.contentItemStyle} className="column-3">
              <div
                className="switch-wrapper"
                style={{
                  display: 'inline-flex',
                  flexDirection: 'column',
                  width: '80px',
                }}
              >
                <Switch
                  checkedChildren={'auto'}
                  unCheckedChildren={'Manual'}
                  style={{ marginBottom: '5px' }}
                />
                <Button
                  type="dashed"
                  size="small"
                  shape="round"
                  style={{ height: '21px', fontWeight: '600' }}
                >
                  {'RESET'}
                </Button>
              </div>
              <span className="title">{MESSAGE.OFFSET_X}</span>
              <span className="title">{MESSAGE.OFFSET_Y}</span>
            </div>
            <div css={SG.contentItemStyle} className="column-3 shot-div">
              <span className="label">Shot 1</span>
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset X"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset Y"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
            </div>
            <div css={SG.contentItemStyle} className="column-3 shot-div">
              <span className="label">Shot 2</span>
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset X"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset Y"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
            </div>
            <div css={SG.contentItemStyle} className="column-3 shot-div">
              <span className="label">Shot 3</span>
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset X"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset Y"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
            </div>
            <div css={SG.contentItemStyle} className="column-3 shot-div">
              <span className="label">Shot 4</span>
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset X"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset Y"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
            </div>
            <div css={SG.contentItemStyle} className="column-3 shot-div">
              <span className="label">Shot 5</span>
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset X"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset Y"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
            </div>
            <div css={SG.contentItemStyle} className="column-3 shot-div">
              <span className="label">Shot 6</span>
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset X"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
              <InputNumber
                style={{ width: '100%' }}
                placeholder="Offset Y"
                min={'-999.0'}
                max={'999.0'}
                step={'0.1'}
              />
            </div>
          </div>
        </div>
      </RibbonCollapse>
      <RibbonCollapse title={'CP / VS'} defaultValue={true}>
        <div className="svg-box">
          <BorderInnerOutlined />
        </div>
        <div css={SG.settingContentStyle}>
          <div className="content">
            <div css={SG.contentItemStyle} className="column-3">
              <div
                css={SG.contentItemStyle}
                style={{ paddingBottom: '10px' }}
                className="cpvs-content"
              >
                <Tooltip
                  placement="topLeft"
                  title={MESSAGE.TABLE_NAME_REGEXP}
                  arrowPointAtCenter
                >
                  <span className="label">{MSG_PRESET}</span>
                  <QuestionCircleOutlined
                    style={{ marginLeft: '4px', color: 'rgb(24 144 255)' }}
                  />
                </Tooltip>
              </div>
              <div className="cpvs-content">
                <Select style={{ width: '100%' }}>
                  <Option value={E_Default} key={`option_default`}>
                    {MSG_DEFAULT}
                  </Option>
                  <Option>
                    {' '}
                    123
                    <Popconfirm title={`Are you sure to delete Preset ? `}>
                      <Button
                        type="text"
                        icon={<DeleteOutlined />}
                        style={{ float: 'right' }}
                        onClick={(e) => e.stopPropagation()}
                      />
                    </Popconfirm>
                  </Option>
                  <Option>{MSG_NEW_PRESET}</Option>
                </Select>
              </div>
              <div css={SG.CPVSContentsStyle} className="cpvs-content">
                <InputForm.input
                  formName={'Title'}
                  placeholder="Enter preset name."
                  required={false}
                />
                <button css={SG.antdButtonStyle} className="white">
                  Save Preset
                </button>
              </div>
            </div>
            <div css={SG.contentItemStyle} className="column-4">
              <span className="label">{MESSAGE.CP_VS}</span>
              <Radio.Group className="radio-cp-vs">
                <Radio value={Mode.FROM_LOG}>{MESSAGE.CP_VS_FROM_LOG}</Radio>
                <Radio value={Mode.EACH}>{MESSAGE.CP_VS_EACH_SHOT}</Radio>
                <Radio className="radio-title">
                  {MESSAGE.CP_VS_SHOT1_SAME}
                </Radio>
              </Radio.Group>
            </div>
            <div>
              <CPVSTable />
            </div>
            <div>
              <div css={SG.contentItemStyle} className="column-3">
                <span className="label-2 margin-off">
                  {MESSAGE.JOB_FILE_UPLOAD}
                </span>
                <Upload>
                  <Button icon={<UploadOutlined />}>{'Start Upload'}</Button>
                </Upload>
              </div>
            </div>
          </div>
        </div>
      </RibbonCollapse>
      <RibbonCollapse title={'Etc.'} defaultValue={true}>
        <div className="svg-box">
          <SettingOutlined />
        </div>
        <div css={SG.settingContentStyle}>
          <div className="content">
            <div css={SG.contentItemStyle}>
              <div css={SG.settingContentStyle} className="etc">
                <div className="content" css={SG.contentsWrapper}>
                  <div css={SG.BlockWrapper}>
                    {' '}
                    {/*Left*/}
                    <div css={SG.contentItemStyle} className="etc flex">
                      <span className="label">{MESSAGE.DISPLAY_MAP}</span>
                      <div>
                        <InputNumber />
                        <span className="margin-lr">{MESSAGE.STILDE}</span>
                        <InputNumber />
                      </div>
                    </div>
                    <div css={SG.contentItemStyle} className="etc flex">
                      <span className="label">{MESSAGE.NUMBER_OF_COLUMNS}</span>
                      <InputNumber min={1} max={5} />
                    </div>
                    <div css={SG.contentItemStyle} className="etc flex">
                      <span className="label">{MESSAGE.SHOW_EXTRA_INFO}</span>
                      <Switch />
                    </div>
                  </div>
                  <div css={[SG.BlockWrapper, { marginLeft: '10px' }]}>
                    {' '}
                    <div css={SG.contentItemStyle} className="etc flex">
                      <span className="label">{MESSAGE.DIV}</span>
                      <div className="tx-right">
                        <span className="margin-r">{MESSAGE.UPPER_ROW}</span>
                        <InputNumber
                          min={0.1}
                          max={10.0}
                          step={0.1}
                          style={{ width: '22%' }}
                        />{' '}
                      </div>
                    </div>
                    <div css={SG.contentItemStyle} className="etc flex">
                      <span className="label">{MESSAGE.PLATE_SIZE}</span>
                      <div className="tx-right">
                        <span className="margin-r">{MESSAGE.SIZE_X}</span>
                        <InputNumber
                          min={1000}
                          max={9999}
                          style={{ width: '30%' }}
                        />
                        <span className="margin-lr">{MESSAGE.SIZE_Y}</span>
                        <InputNumber
                          min={1000}
                          max={9999}
                          style={{ width: '30%' }}
                        />
                      </div>
                    </div>
                    <div css={SG.contentItemStyle} className="etc flex">
                      <Button
                        style={{ marginLeft: 'auto' }}
                        type="dashed"
                        shape="round"
                      >
                        {''} {MSG_SAVE}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </RibbonCollapse>
    </>
  );
};
