import React, { useState, useRef, useEffect } from 'react';
import * as SG from '../OasBaseline/styles/OsaBaselineStyle';
import {
  SettingOutlined,
  FormatPainterOutlined,
  DownCircleFilled,
  EditOutlined,
} from '@ant-design/icons';
import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
import { Divider, Select, Button, Tag, Segmented, InputNumber } from 'antd';
import { GraphColorMenu } from '@components/Tact/Status/GraphColorMenu';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
const { Option } = Select;

export const PlotResult = () => {
  const [colorMenu, setColorMenu] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [scale, setScale] = useState('auto');
  const el = useRef();

  const handleCloseModal = (e) => {
    if (colorMenu && (!el.current || !el.current.contains(e.target)))
      setColorMenu(false);
  };

  useEffect(() => {
    window.addEventListener('click', handleCloseModal);
    return () => {
      window.removeEventListener('click', handleCloseModal);
    };
  }, []);

  return (
    <>
      <div>
        <RibbonCollapse title={'Graph Setting'} defaultValue={true}>
          <div className="svg-box">
            <SettingOutlined />
          </div>
          <div css={SG.settingContentStyle}>
            <div className="content">
              <div css={SG.contentItemStyle}>
                <div className="content-box">
                  <Divider className="divider-line" orientation="left">
                    Shot Select
                  </Divider>
                  <Select style={{ width: '100%' }} defaultValue="1">
                    <Option value="1">1</Option>
                    <Option value="2">2</Option>
                  </Select>
                </div>
                <div className="content-box">
                  <Divider className="divider-line" orientation="left">
                    Graph Type
                  </Divider>
                  <Select style={{ width: '100%' }} defaultValue="1">
                    <Option value="1">Line Graph</Option>
                    <Option value="2">Scatter Plot</Option>
                  </Select>
                </div>
                <div className="content-box">
                  <Divider className="divider-line" orientation="left">
                    Glass ID Highlighting
                  </Divider>
                  <Select style={{ width: '100%' }} defaultValue="1">
                    <Option value="1">A00000000000001</Option>
                    <Option value="2">A00000000000002</Option>
                  </Select>
                </div>
                <div className="content-box scale-button">
                  <Divider className="divider-line" orientation="left">
                    Graph Scale
                  </Divider>
                  <div className="content-button">
                    <div>
                      <button
                        css={SG.antdButtonStyle}
                        className="white edit"
                        onClick={() => setIsVisible(true)}
                      >
                        <EditOutlined />
                        Edit
                      </button>
                    </div>
                  </div>
                </div>
                <DraggableModal
                  visible={isVisible}
                  title={'Graph Scale'}
                  width={500}
                  footer={null}
                  centered
                  maskClosable={false}
                  cancelHandler={() => setIsVisible(false)}
                  css={SG.SegmentedStyle}
                >
                  <div className="segmented-style">
                    <Segmented
                      onChange={(v) => setScale(v)}
                      options={[
                        {
                          label: 'Auto Scale',
                          value: 'auto',
                        },
                        {
                          label: 'Manual Scale',
                          value: 'manual',
                        },
                      ]}
                    />
                  </div>
                  <div css={SG.contentItemStyle}>
                    <div className="tx-right">
                      <span className="margin-r">Y (Lower Limit)</span>
                      <InputNumber
                        min={-9999}
                        max={9999}
                        disabled={scale !== 'manual'}
                      />
                      <span className="margin-lr">Y (Upper Limit)</span>
                      <InputNumber
                        min={-9999}
                        max={9999}
                        disabled={scale !== 'manual'}
                      />
                    </div>
                  </div>
                  <div className="model-button-divider">
                    <button css={SG.antdButtonStyle} className="blue">
                      Apple
                    </button>
                  </div>
                </DraggableModal>
                <div css={SG.contentItemStyle} className="limit-box">
                  <span className="label-2 ">{"Graph's Left Scale"}</span>
                  <Tag color="magenta">Manual Scale</Tag>
                  <div className="flex-between limit-scale ">
                    <div css={SG.contentItemStyle} className="flex-between">
                      <span className="label-2">Y (Lower Limit)</span>
                      {'-10'}
                    </div>
                    <div
                      css={SG.contentItemStyle}
                      className="flex-between limit"
                    >
                      <span className="label-2">Y (Upper Limit)</span>
                      {'10'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </RibbonCollapse>
      </div>
      <div>
        <RibbonCollapse title={'Graph Color Setting'} defaultValue={true}>
          <div className="svg-box">
            <FormatPainterOutlined />
          </div>
          <div>
            <div className="content">
              <div css={SG.contentItemStyle} className="column-3">
                <div css={SG.GraphColorSettingStyle}>
                  <div css={SG.testDropDown}>
                    <span className="dropdown">
                      <Button
                        css={SG.GraphColorButtonStyle}
                        className="dropBtn"
                        onClick={() => setColorMenu(!colorMenu)}
                      >
                        Plot Color Change
                        <DownCircleFilled />
                      </Button>
                      {colorMenu === true ? (
                        <div className="dropdown-content">
                          <GraphColorMenu
                            closer={() => setColorMenu(false)}
                            ref={el}
                          />
                        </div>
                      ) : (
                        ''
                      )}
                    </span>
                  </div>
                  <div css={SG.divSubColorStyle}>
                    <div css={SG.subColorStyle}>
                      <button className="rc-color-picker-trigger" />
                      <span>Color</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </RibbonCollapse>
      </div>
    </>
  );
};
