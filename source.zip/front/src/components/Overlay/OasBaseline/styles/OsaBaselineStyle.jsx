import { css } from '@emotion/react';

export const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 0.4fr 0.6fr;
  gap: 1rem;
  width: 100%;
  padding: 1rem;
`;

export const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 400px;
  background-color: var(--ckr-gray-1);
  border-radius: 4px;
  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3),
    0 2px 6px 2px rgba(60, 64, 67, 0.15);
  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 2rem;
    grid-column: 1 / span 2;
  }
`;

export const controlStyle = css`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  & .box-flex {
    display: flex;
  }
`;

export const componentTitleStyle = css`
  font-size: 24px;
  color: var(--ckr-blue-6);
`;

export const contentWrapperStyle = css`
  position: relative;
  margin-top: 3rem;
  &.mg-bottom {
    margin-bottom: 13px;
  }
  & .start-button {
    margin-top: 10px;
    float: right;
  }
`;

export const contentStyle = css`
  margin: 0 auto;
  width: 83%;
  &.full-width {
    width: 100%;
  }
  & > div + div {
    margin-top: 2rem;
  }
`;

export const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column-2 {
    grid-template-columns: 0.4fr 1fr;
  }
  &.column-3 {
    grid-template-columns: 0.4fr 1fr 1fr;
  }
  &.column-4 {
    grid-template-columns: 0.2fr 1fr;
  }
  & .fab-manual {
    display: flex;
  }
  &.shot-div {
    margin-top: 1rem;
  }
  & .title {
    justify-self: center;
    font-size: 14px !important;
  }
  & .content-box {
    display: grid;
    grid-template-columns: 0.7fr 0.3fr;
    align-items: center;
    gap: 10px;
    & .divider-line::before {
      width: 20px;
    }
    & .content-button > div {
      float: right;
    }
  }
  & .scale-button {
    grid-template-columns: 1fr 0;
  }
  & .content-scale {
    width: 70%;
  }
  & .upload-span {
    display: grid;
    align-self: start;
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      font-size: 14px !important;
      &.label {
        &::before {
          display: inline-block;
          color: red;
          font-size: 16px;
          content: '*';
          margin-right: 0.3rem;
        }
        &::after {
          display: inline-block;
          content: ':';
        }
      }
      &.label-2 {
        margin-left: 10px;
        &::after {
          display: inline-block;
          content: ':';
        }
      }
      &.margin-off {
        margin-left: 0;
      }
    }
    &:last-of-type {
      font-size: 12px;
    }
  }
  &.upload {
    & .adc-log-files,
    & .ant-upload-text-icon,
    & .ant-upload-list-item-name,
    & .ant-upload-list-item-card-actions {
      &.warning {
        color: var(--ckr-gold-6);
        & .anticon {
          color: var(--ckr-gold-6);
        }
      }
      &.unknown {
        color: var(--ckr-red-5);
        & .anticon {
          color: var(--ckr-red-5);
        }
      }
      &.success {
        color: var(--ckr-blue-6);
        & .anticon {
          color: var(--ckr-blue-6);
        }
      }
    }
    & .ant-upload-list-item {
      max-width: 372px;
      color: var(--ckr-blue-6);
    }
    & > span {
      &:first-of-type {
        align-self: start;
      }
      &:last-of-type {
        display: block;
        & .ant-upload-list-text {
          margin-top: 0.5rem;
          overflow: auto;
          max-height: 30px;
          min-height: 10px;
          max-width: 372px;
          &::-webkit-scrollbar {
            width: 8px;
          }
          &::-webkit-scrollbar-track {
            background-color: transparent;
          }
          &::-webkit-scrollbar-thumb {
            border-radius: 4px;
            background-color: rgba(0, 0, 0, 0.2);
          }
          &::-webkit-scrollbar-button {
            width: 0;
            height: 0;
          }
        }
        & .adc-log-files {
          max-width: 334px;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: pre;
        }
      }
    }
  }
  & .upload-title {
    align-self: start;
    & > span {
      position: relative;
      &:first-of-type {
        position: relative;
        font-size: 14px !important;
        &.label {
          &::before {
            display: inline-block;
            color: red;
            font-size: 16px;
            content: '*';
            margin-right: 0.3rem;
          }
          &::after {
            display: inline-block;
            content: ':';
          }
        }
        &.label-2 {
          margin-left: 10px;
          &::after {
            display: inline-block;
            content: ':';
          }
        }
        &.margin-off {
          margin-left: 0;
        }
      }
      &:last-of-type {
        display: block;
        font-size: 12px;
      }
    }
  }
  & .margin-lr {
    margin: 0 1rem;
  }
  & .margin-r {
    margin-right: 1rem;
  }
  & .tx-right {
    text-align: right;
  }
  & ~ div {
    margin-top: 2rem;
    &.table-wrapper {
      margin-top: 1rem;
    }
  }
  & .cpvs-content {
    margin-top: 0;
  }
  & .radio-cp-vs {
    display: flex;
    justify-content: space-between;
  }
  & .limit-box {
    display: flex;
    width: 65%;
    justify-self: center;
    & > .limit-box-scale {
      display: flex;
      justify-content: space-between;
      margin-left: 130px;
    }
    & .ant-tag {
      border-radius: 10px;
    }
    & .limit-scale {
      width: 350px;
    }
  }
  & .flex-between {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  & .limit {
    margin-top: 0;
  }
`;

export const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-color: var(--ckr-gray-1);
  border: none;
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: var(--ckr-blue-6);
      transition: transform 0.3s ease-in-out;
      will-change: transform;
      &:hover {
        transform: scale(1.4);
      }
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: -5px;
    right: 0;
    & > span:first-of-type {
      color: var(--ckr-green-6);
    }
  }
  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
    & > span:first-of-type {
      color: var(--ckr-gray-6);
    }
  }
`;

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0 2px 4px 1px rgba(0, 0, 0, 0.2);
  transition: all 0.2s;
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: var(--ckr-gray-1);
    border: 1px dashed var(--ckr-gray-5);
    &:disabled {
      color: var(--ckr-gray-6);
      background-color: var(--ckr-gray-3);
    }
  }
  &.blue {
    color: var(--ckr-gray-1);
    background-color: var(--ckr-blue-6);
    border: 1px solid var(--ckr-blue-6);
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
  &.edit {
    & span {
      margin-right: 5px;
    }
  }
`;

export const settingContentStyle = css`
  position: relative;
  margin: 0 auto;
  width: 100%;
  padding: 1rem;
  &.etc {
    width: 100%;
    padding: 0;
  }
  & .flex {
    display: flex;
    justify-content: space-between;
    & > span {
      white-space: pre;
    }
  }
  &.full-width {
    width: 100%;
  }
  & .table-wrapper ~ div,
  & .content > .radio-wrapper ~ .tab {
    margin-top: 1rem;
    width: 100%;
  }
`;
