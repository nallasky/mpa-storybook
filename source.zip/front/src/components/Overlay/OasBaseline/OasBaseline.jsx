import React from 'react';

import { OVERLAY_OAS_BASELINE_CATEGORY } from '../../../constants/etc';
import { SelectSource } from '../SelectSource';
import { SelectTarget } from '../SelectTarget';
import { css } from '@emotion/react';
import { OverlayInfo } from '../hooks/useCommonOverlay';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';
import OverlayResult from '../OverlayResult/OverlayResult';

const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 0.5fr 0.5fr;
  gap: 1rem;
  width: 100%;
  margin-top: 0.5rem;
`;
const OasBaseline = () => {
  const { oasBaseLineSet } = useOverlayInfo();
  return (
    <OverlayInfo.Provider
      value={{
        mode: OVERLAY_OAS_BASELINE_CATEGORY,
        currentData: oasBaseLineSet,
      }}
    >
      <section css={sectionStyle}>
        <SelectSource />
        <SelectTarget />
        <OverlayResult />
      </section>
    </OverlayInfo.Provider>
  );
};
export default OasBaseline;
