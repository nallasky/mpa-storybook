import React, { useState } from 'react';
import * as SG from '../OasBaseline/styles/OsaBaselineStyle';
import {
  CloudDownloadOutlined,
  PlayCircleOutlined,
  StockOutlined,
  TableOutlined,
} from '@ant-design/icons';
import { PlotResult } from '@components/Overlay/OasBaseline/PlotResult';
import { MapResult } from './MapResult';
import { LineGraph } from './fragments/GraphResult';
import CustomRadioGroup from '@components/common/molecules/CustomRadioGroup/CustomRadioGroup';

const format = [
  {
    id: 'plot',
    icon: <StockOutlined />,
    title: 'Plot',
  },
  {
    id: 'map',
    icon: <TableOutlined />,
    title: 'Map',
  },
];

export const OverlayResult = () => {
  const [source, setSource] = useState('plot');

  return (
    <>
      <div css={SG.componentStyle} className="span">
        <div css={SG.controlStyle}>
          <CustomRadioGroup
            name="result-type"
            changeFunc={(e) => setSource(e)}
            options={format}
            currentChecked={source}
          />
          {source === 'map' ? (
            <div className="box-flex">
              <button css={SG.customButtonStyle}>
                <PlayCircleOutlined />
                <span>Re-Start</span>
              </button>
              <button css={SG.customButtonStyle}>
                <CloudDownloadOutlined />
                <span>Download</span>
              </button>
            </div>
          ) : (
            <div className="box-flex">
              <button css={SG.customButtonStyle}>
                <CloudDownloadOutlined />
                <span>Download</span>
              </button>
            </div>
          )}
        </div>
        {source === 'plot' ? (
          <>
            <div css={SG.settingStyle}>
              <PlotResult />
            </div>
            <div css={SG.settingStyle}>
              <LineGraph />
            </div>
          </>
        ) : (
          <div css={SG.settingStyle}>
            <MapResult />
          </div>
        )}
      </div>
    </>
  );
};
