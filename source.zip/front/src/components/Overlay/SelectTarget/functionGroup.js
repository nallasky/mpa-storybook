export const createTreeSelectData = (data, key, type) => {
  if (!Object.keys(data).length || !key) return [];

  const findOrgData = key === 'all' ? data : data[key];
  let tmpData = [
    {
      title: 'ALL',
      value: '0',
      key: '0',
      children: [],
    },
  ];

  const createArrayType = (obj) => {
    return Object.keys(obj).filter(
      (v) => (Array.isArray(obj[v]) && obj[v].length) || !Array.isArray(obj[v]),
    );
  };

  Object.keys(findOrgData).forEach((v) => {
    if (
      (type === 'adc' && v !== 'selected') ||
      (type === 'lot' && findOrgData[v].length) ||
      type === 'stage'
    ) {
      tmpData[0].children.push(
        type === 'lot'
          ? {
              title: v,
              value: `0-${v}`,
              key: `0-${v}`,
              children: findOrgData[v].map((x) => {
                return {
                  title: x,
                  value: `0-${v}-${x}`,
                  key: `0-${v}-${x}`,
                };
              }),
            }
          : type === 'adc'
          ? {
              title: v,
              value: `0-${v}`,
              key: `0-${v}`,
            }
          : {
              title: v,
              value: `0-${v}`,
              key: `0-${v}`,
              children: createArrayType(findOrgData[v]).length
                ? createArrayType(findOrgData[v]).map((x) => {
                    return {
                      title: x,
                      value: `0-${v}-${x}`,
                      key: `0-${v}-${x}`,
                      children: createArrayType(findOrgData[v][x]).length
                        ? createArrayType(findOrgData[v][x]).map((y) => {
                            return {
                              title: y,
                              value: `0-${v}-${x}-${y}`,
                              key: `0-${v}-${x}-${y}`,
                            };
                          })
                        : [],
                    };
                  })
                : [],
            },
      );
    }
  });

  return tmpData;
};

export const createInitTreeValues = (data, type, key) => {
  const selectValues = [];

  Object.keys(data).forEach((v) => {
    let initValue = '0';
    if (type !== 'adc_correction') {
      Object.keys(data[v]).forEach((x) => {
        if (data[v][x]) {
          selectValues.push(`${initValue}-${v}-${x}`);
        }
      });
    } else {
      if (key === v) {
        Object.keys(data[v]).forEach((z) => {
          const isSelected = Object.keys(data[v]).find((w) => data[v][w]);
          if (isSelected && data[v][z] && z !== 'selected') {
            selectValues.push(`${initValue}-${z}`);
          }
        });
      }
    }
  });

  return selectValues;
};

export const initStageAdcInfo = (adc, stage) => {
  let findKey = undefined;

  if (Object.keys(adc).length) {
    for (const v of Object.keys(adc)) {
      if (Object.keys(adc[v]).find((x) => x === 'selected' && adc[v][x])) {
        findKey = v;
        break;
      }
    }
  }

  return {
    radio: findKey,
    adc: createInitTreeValues(adc, 'adc_correction', findKey),
    stage: createInitTreeValues(stage, 'stage_correction', undefined),
  };
};

export const startDisableCheck = (data) => {
  if (!data.fab_name) {
    return true;
  }

  if (!data.selected[0]) {
    return true;
  }

  if (!data.job) {
    return true;
  }

  return !data.lot_id.length;
};
