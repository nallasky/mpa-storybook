import { Fragment } from 'react';
import { contentItemStyle } from './styles/SelcetTargetStyle';
import { Overlay } from '@assets/locale/en';
import { Divider, Input, Select } from 'antd';
import { CustomSelect } from './styles/styleGroup';
import { MSG_LOCAL } from '@constants/Message';
import { PlusCircleOutlined } from '@ant-design/icons';
import { useTargetFab } from './hooks/useTargetFab';
import { useOverlaySelectTarget } from '../hooks/useOverlaySelectTarget';

const {
  select_target: { fab: message },
} = Overlay;
const SelectTargetFab = () => {
  const { currentData } = useOverlaySelectTarget();
  const { fabName, inputError, checkFabName, changeFabName, changeFab } =
    useTargetFab();
  return (
    <div css={contentItemStyle} className="column-2">
      <span className="label required">{message.label}</span>
      <Select
        style={{ width: '100%' }}
        value={currentData.targetInfo.fab_name}
        onChange={(v) => changeFab(v)}
        dropdownRender={(menu) =>
          currentData.source === MSG_LOCAL ? (
            <Fragment>
              <CustomSelect>
                <Input
                  type="text"
                  style={{ width: '100%' }}
                  value={fabName}
                  onChange={(e) => changeFabName(e.target.value)}
                  maxLength="30"
                  className={inputError ? 'input-error' : ''}
                />
                <div
                  className={'button' + (inputError ? ' error' : '')}
                  role="button"
                  onKeyDown={undefined}
                  tabIndex="-1"
                  onClick={checkFabName}
                >
                  <PlusCircleOutlined />
                </div>
              </CustomSelect>
              <Divider style={{ margin: '4px 0' }} />
              {menu}
            </Fragment>
          ) : (
            menu
          )
        }
      >
        {currentData.targetInfo.fab_list.map((v) => (
          <Select.Option value={v} key={v}>
            {v}
          </Select.Option>
        ))}
      </Select>
    </div>
  );
};
export default SelectTargetFab;
