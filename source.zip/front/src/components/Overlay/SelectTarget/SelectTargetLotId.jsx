import { contentItemStyle } from './styles/SelcetTargetStyle';
import { useOverlaySelectTarget } from '../hooks/useOverlaySelectTarget';
import { TreeSelect } from 'antd';
import { useTargetLotId } from './hooks/useTargetLotId';
import { Overlay } from '@assets/locale/en';
const {
  select_target: { lot_id: message },
} = Overlay;

const SelectTargetLodId = () => {
  const {
    currentData: { targetInfo },
  } = useOverlaySelectTarget();
  const { changeLotId, lotIdOptions } = useTargetLotId();

  return (
    <div css={contentItemStyle} className="column-2">
      <span className="label required">{message.label}</span>
      <TreeSelect
        treeData={lotIdOptions}
        value={targetInfo.lot_id}
        onChange={changeLotId}
        showCheckedStrategy={TreeSelect.SHOW_CHILD}
        style={{ width: '100%' }}
        maxTagCount="responsive"
        treeCheckable
        treeDefaultExpandAll
      />
    </div>
  );
};
export default SelectTargetLodId;
