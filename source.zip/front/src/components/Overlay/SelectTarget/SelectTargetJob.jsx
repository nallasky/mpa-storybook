import { contentItemStyle } from './styles/SelcetTargetStyle';
import { Select } from 'antd';
import { useOverlaySelectTarget } from '../hooks/useOverlaySelectTarget';
import { useTargetJob } from './hooks/useTargetJob';
import { Overlay } from '@assets/locale/en';
const {
  select_target: { job: message },
} = Overlay;

const SelectTargetJob = () => {
  const {
    currentData: { targetInfo },
  } = useOverlaySelectTarget();
  const { changeJob } = useTargetJob();
  return (
    <div css={contentItemStyle} className="column-2">
      <span className="label required">{message.label}</span>
      <Select
        style={{ width: '100%' }}
        value={targetInfo.job}
        onChange={changeJob}
      >
        {targetInfo.job_list.map((v) => (
          <Select.Option value={v} key={v}>
            {v}
          </Select.Option>
        ))}
      </Select>
    </div>
  );
};
export default SelectTargetJob;
