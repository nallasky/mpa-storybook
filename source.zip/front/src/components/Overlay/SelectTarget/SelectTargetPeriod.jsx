import { contentItemStyle } from './styles/SelcetTargetStyle';
import { useOverlaySelectTarget } from '../hooks/useOverlaySelectTarget';
import { Overlay } from '@assets/locale/en';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';
import { DATE_FORMAT } from '@constants/etc';
const {
  select_target: { period: message },
} = Overlay;

const SelectTargetPeriod = () => {
  const {
    currentData: { targetInfo },
    changeRedux,
    disabledDate,
  } = useOverlaySelectTarget();
  return (
    <div css={contentItemStyle} className="column-2">
      <span className="label required">{message.label}</span>
      <DatePicker.RangePicker
        value={
          targetInfo.selected[0]
            ? [dayjs(targetInfo.selected[0]), dayjs(targetInfo.selected[1])]
            : targetInfo.period
        }
        placeholder={
          targetInfo.period[0]
            ? [
                dayjs(targetInfo.period[0]).format(DATE_FORMAT),
                dayjs(targetInfo.period[1]).format(DATE_FORMAT),
              ]
            : targetInfo.period
        }
        onChange={(v) =>
          changeRedux(
            [dayjs(v[0]).format(DATE_FORMAT), dayjs(v[1]).format(DATE_FORMAT)],
            'selected',
          )
        }
        style={{ width: '100%' }}
        disabledDate={(v) => disabledDate(targetInfo.period, v)}
        inputReadOnly
        allowClear={false}
        showTime
      />
    </div>
  );
};

export default SelectTargetPeriod;
