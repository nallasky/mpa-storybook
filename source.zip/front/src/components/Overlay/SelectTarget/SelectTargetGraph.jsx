import { Fragment } from 'react';
import { contentItemStyle } from './styles/SelcetTargetStyle';
import { Select } from 'antd';
import { Overlay } from '@assets/locale/en';
import { useOverlaySelectTarget } from '../hooks/useOverlaySelectTarget';
import { useTargetGraph } from './hooks/useTargetGraph';
const {
  select_target: { graph: message },
} = Overlay;

const SelectTargetGraph = () => {
  const {
    currentData: {
      targetInfo: { graph_select, job, lot_id },
    },
  } = useOverlaySelectTarget();
  const { changeGraph } = useTargetGraph();
  return !!job && lot_id.length && graph_select ? (
    <div css={contentItemStyle} className="column-2">
      <span className="label required">{message.label}</span>
      <Select
        style={{ width: '100%' }}
        value={graph_select.selected}
        onChange={changeGraph}
      >
        {graph_select.list.map((v) => (
          <Select.Option value={v} key={v}>
            {v}
          </Select.Option>
        ))}
      </Select>
    </div>
  ) : (
    <Fragment></Fragment>
  );
};

export default SelectTargetGraph;
