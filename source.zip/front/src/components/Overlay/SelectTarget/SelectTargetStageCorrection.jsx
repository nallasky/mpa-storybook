import { useMemo } from 'react';
import { contentItemStyle } from './styles/SelcetTargetStyle';
import { TreeSelect } from 'antd';
import { Overlay } from '@assets/locale/en';
import { useOverlaySelectTarget } from '../hooks/useOverlaySelectTarget';
import { createTreeSelectData } from './functionGroup';
const {
  select_target: { stage_correction: message },
} = Overlay;
const SelectTargetStageCorrection = () => {
  const {
    currentData: { targetInfo },
    changeRedux,
  } = useOverlaySelectTarget();
  const stageCorrectionOptions = useMemo(() => {
    return createTreeSelectData(
      targetInfo.stage_correction_list,
      'all',
      'stage',
    );
  }, [targetInfo.stage_correction_list]);
  return (
    <div css={contentItemStyle} className="column-2">
      <span className="label-2">{message.label}</span>
      <TreeSelect
        treeData={stageCorrectionOptions}
        value={targetInfo.stage_correction}
        onChange={(v) => changeRedux(v, 'stage_correction')}
        showCheckedStrategy={TreeSelect.SHOW_CHILD}
        style={{ width: '100%' }}
        maxTagCount="responsive"
        treeCheckable
        treeDefaultExpandAll
      />
    </div>
  );
};

export default SelectTargetStageCorrection;
