import { useMemo, useEffect, Fragment } from 'react';
import { contentItemStyle } from './styles/SelcetTargetStyle';
import { TreeSelect, Radio, Space } from 'antd';
import { useOverlaySelectTarget } from '../hooks/useOverlaySelectTarget';
import { createTreeSelectData, initStageAdcInfo } from './functionGroup';
import { useTargetAdcCorrection } from './hooks/useTargetAdcCorrection';
import { Overlay } from '@assets/locale/en';
import { OVERLAY_CORRECTION_CATEGORY } from '@constants/etc';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';
const {
  select_target: { adc_correction: message },
} = Overlay;

const SelectTargetAdcCorrection = () => {
  const { changeAdcCorrection, radioAdc, changeRadio, setRadioAdc } =
    useTargetAdcCorrection();
  const { mode, currentData } = useOverlaySelectTarget();
  const { targetInfo } = currentData;
  const { updateCorrectionSetting } = useOverlayInfo();

  const adcCorrectionOptions = useMemo(() => {
    return createTreeSelectData(
      targetInfo.adc_correction_list,
      radioAdc,
      'adc',
    );
  }, [targetInfo.adc_correction_list, radioAdc]);
  useEffect(() => {
    if (mode === OVERLAY_CORRECTION_CATEGORY) {
      if (!radioAdc) {
        const { radio, adc, stage } = initStageAdcInfo(
          targetInfo.adc_correction_list,
          targetInfo.stage_correction_list,
        );

        if (radio) {
          setRadioAdc(radio);
        }

        updateCorrectionSetting({
          ...currentData,
          targetInfo: {
            ...currentData.targetInfo,
            stage_correction: stage,
            adc_correction: adc,
          },
        });
      } else if (
        !Object.keys(targetInfo.adc_correction_list).length &&
        !Object.keys(targetInfo.stage_correction_list).length
      ) {
        setRadioAdc('');
      }
    }
  }, [targetInfo.adc_correction_list, targetInfo.stage_correction_list]);
  return (
    <div css={contentItemStyle} className="column-2">
      <span className="label-2">{message.label}</span>
      <TreeSelect
        treeData={adcCorrectionOptions}
        value={targetInfo.adc_correction}
        onChange={(v) => changeAdcCorrection(v, 'select')}
        showCheckedStrategy={TreeSelect.SHOW_CHILD}
        style={{ width: '100%' }}
        maxTagCount="responsive"
        treeCheckable
        treeDefaultExpandAll
        dropdownRender={(menu) =>
          adcCorrectionOptions.length ? (
            <Fragment>
              <div style={{ padding: '8px' }}>
                <Radio.Group
                  value={radioAdc}
                  onChange={(e) => changeRadio(e.target.value)}
                >
                  <Space direction="vertical">
                    <Radio value="ADC Measurement">{message.options.adc}</Radio>
                    <Radio value="ADC Offset">
                      {message.options.adc_offset}
                    </Radio>
                    <Radio value="ADC Measurement + Offset">
                      {message.options.adc_plus_offset}
                    </Radio>
                  </Space>
                </Radio.Group>
              </div>
              {menu}
            </Fragment>
          ) : (
            menu
          )
        }
      />
    </div>
  );
};
export default SelectTargetAdcCorrection;
