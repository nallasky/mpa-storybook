import { Fragment } from 'react';
import { contentItemStyle } from './styles/SelcetTargetStyle';
import { Select } from 'antd';
import { useOverlaySelectTarget } from '../hooks/useOverlaySelectTarget';
import { MeanAll } from './styles/styleGroup';
import { useTargetMeanDeviation } from './hooks/useTargetMeanDeviation';
import { Overlay } from '@assets/locale/en';
const {
  select_target: { mean_dev_diff: message },
} = Overlay;
const SelectTargetMeanDeviation = () => {
  const { changeRedux } = useOverlaySelectTarget();
  const { changeMeanAll, optionList, job, lot_id, mean_dev_diff } =
    useTargetMeanDeviation();

  return (
    <Fragment>
      {!!job && lot_id.length ? (
        <div css={contentItemStyle} className="column-2">
          <span className="label-2">{message.label}</span>
          <Select
            style={{ width: '100%' }}
            mode="multiple"
            maxTagCount="responsive"
            value={mean_dev_diff}
            disabled={!optionList}
            onChange={(v) => changeRedux(v, 'mean_dev_diff')}
            dropdownRender={(menu) =>
              (optionList ?? []).length ? (
                <Fragment>
                  <MeanAll>
                    <label htmlFor="mean-all">
                      <input
                        type="checkbox"
                        id="mean-all"
                        onChange={(e) =>
                          changeMeanAll(e.target.checked, optionList)
                        }
                      />
                      <div className="button">{message.btn_all.label}</div>
                    </label>
                  </MeanAll>
                  {menu}
                </Fragment>
              ) : (
                menu
              )
            }
          >
            {(optionList ?? []).map((v) => (
              <Select.Option value={v} key={v}>
                {v}
              </Select.Option>
            ))}
          </Select>
        </div>
      ) : (
        ''
      )}
    </Fragment>
  );
};

export default SelectTargetMeanDeviation;
