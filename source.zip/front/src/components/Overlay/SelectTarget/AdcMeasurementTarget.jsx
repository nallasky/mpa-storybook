import { Fragment } from 'react';
import { Overlay } from '@assets/locale/en';
import * as SG from './styles/SelcetTargetStyle';
const { select_target: message } = Overlay;
import SelectTargetFab from './SelectTargetFab';
import SelectTargetEquipment from './SelectTargetEquipment';
import SelectTargetPeriod from './SelectTargetPeriod';
import SelectTargetJob from './SelectTargetJob';
import SelectTargetLodId from './SelectTargetLotId';
import SelectTargetAECorrection from './SelectTargetAECorrection';
import SelectTargetMeanDeviation from './SelectTargetMeanDeviation';

const AdcMeasurementTarget = () => {
  return (
    <Fragment>
      <div css={SG.componentTitleStyle}>{message.label}</div>
      <div css={SG.contentWrapperStyle} className="mg-bottom">
        <div css={SG.contentStyle} className={'mt-3'}>
          <SelectTargetFab />
          <SelectTargetEquipment />
          <SelectTargetPeriod />
          <SelectTargetJob />
          <SelectTargetLodId />
          <SelectTargetMeanDeviation />
          <SelectTargetAECorrection />
        </div>
      </div>
    </Fragment>
  );
};
export default AdcMeasurementTarget;
