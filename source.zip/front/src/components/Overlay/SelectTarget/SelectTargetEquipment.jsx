import { contentItemStyle } from './styles/SelcetTargetStyle';
import { Overlay } from '@assets/locale/en';
import { useOverlaySelectTarget } from '../hooks/useOverlaySelectTarget';
import { Select } from 'antd';
import { MSG_LOCAL } from '@constants/Message';
import { useTargetEquipment } from './hooks/useTargetEquipment';

const {
  select_target: { equipment: message },
} = Overlay;

const SelectTargetEquipment = () => {
  const { currentData } = useOverlaySelectTarget();
  const { changeEquipment } = useTargetEquipment();

  return (
    <div css={contentItemStyle} className="column-2">
      <span className="label required">{message.label}</span>
      <Select
        style={{ width: '100%' }}
        value={currentData.targetInfo.equipment_name}
        onChange={changeEquipment}
        disabled={currentData.source === MSG_LOCAL}
      >
        {currentData.targetInfo.equipment_name_list[
          currentData.targetInfo.fab_name
        ]?.map((v) => (
          <Select.Option value={v} key={v}>
            {v}
          </Select.Option>
        ))}
      </Select>
    </div>
  );
};
export default SelectTargetEquipment;
