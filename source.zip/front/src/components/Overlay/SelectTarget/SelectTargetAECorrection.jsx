import { useOverlaySelectTarget } from '../hooks/useOverlaySelectTarget';
import { contentItemStyle } from './styles/SelcetTargetStyle';
import { Select } from 'antd';
import { OVERLAY_TARGET_AE_CORRECTION } from '@constants/OverlayDefault';
import { Overlay } from '@assets/locale/en';
const {
  select_target: { ae_correction: message },
} = Overlay;
const SelectTargetAECorrection = () => {
  const {
    currentData: { targetInfo },
    changeRedux,
  } = useOverlaySelectTarget();
  return (
    <div css={contentItemStyle} className="column-2">
      <span className="label-2">{message.label}</span>
      <Select
        style={{ width: '100%' }}
        value={targetInfo.ae_correction}
        onChange={(v) => changeRedux(v, 'ae_correction')}
        options={OVERLAY_TARGET_AE_CORRECTION}
      />
    </div>
  );
};
export default SelectTargetAECorrection;
