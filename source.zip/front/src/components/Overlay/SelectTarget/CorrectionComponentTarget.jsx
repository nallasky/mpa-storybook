import { Fragment } from 'react';
import { Overlay } from '@assets/locale/en';
import * as SG from './styles/SelcetTargetStyle';
const { select_target: message } = Overlay;
import SelectTargetFab from './SelectTargetFab';
import SelectTargetEquipment from './SelectTargetEquipment';
import SelectTargetPeriod from './SelectTargetPeriod';
import SelectTargetJob from './SelectTargetJob';
import SelectTargetLodId from './SelectTargetLotId';
import SelectTargetAECorrection from './SelectTargetAECorrection';
import SelectTargetMeanDeviation from './SelectTargetMeanDeviation';
import SelectTargetStageCorrection from './SelectTargetStageCorrection';
import SelectTargetAdcCorrection from './SelectTargetAdcCorrection';

const CorrectionComponentTarget = () => {
  return (
    <Fragment>
      <div css={SG.componentTitleStyle}>{message.label}</div>
      <div css={SG.contentWrapperStyle} className="mg-bottom">
        <div css={SG.contentStyle} className={'mt-3'}>
          <SelectTargetFab />
          <SelectTargetEquipment />
          <SelectTargetPeriod />
          <SelectTargetJob />
          <SelectTargetLodId />
          <SelectTargetAECorrection />
          <SelectTargetMeanDeviation />
          <SelectTargetStageCorrection />
          <SelectTargetAdcCorrection />
        </div>
      </div>
    </Fragment>
  );
};
export default CorrectionComponentTarget;
