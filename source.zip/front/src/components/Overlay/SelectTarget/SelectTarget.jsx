import React, { useState, useEffect, Fragment } from 'react';
import { Spin } from 'antd';
import { PlayCircleOutlined } from '@ant-design/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import useModal from '../../../libs/util/modalControl/useModal';
import { post_Overlay_Plate_Info } from '@libs/axios/overlayRequest';
import {
  OVERLAY_ADC_CATEGORY,
  OVERLAY_CORRECTION_CATEGORY,
  OVERLAY_OAS_BASELINE_CATEGORY,
} from '@constants/etc';
import { createPostData, displayError } from '@libs/util/common/functionGroup';
import { startDisableCheck } from './functionGroup';
import * as SG from './styles/SelcetTargetStyle';
import { MSG_LOCAL, MSG_REMOTE } from '@constants/Message';
import useCommonOverlay, { OverlayTargetInfo } from '../hooks/useCommonOverlay';
import AdcMeasurementTarget from './AdcMeasurementTarget';
import CorrectionComponentTarget from './CorrectionComponentTarget';
import OasBaseLineTarget from './OasBaseLineTarget';
import { ProcessingModal } from '@components/common/organisms/ProcessingModal';
import { useTargetAnalysis } from './hooks/useTargetAnalysis';
const SelectTarget = () => {
  const { openModal, closeModal } = useModal();
  const { updateOverlaySetting, mode, currentData } = useCommonOverlay();
  const { analysisStartFunc, uploadStartFunc, analysisCancel } =
    useTargetAnalysis();

  const [loadState, setLoadState] = useState(false);
  const { targetInfo, source_info, source } = currentData;

  const processStart = () => {
    const postData = createPostData(currentData, mode);
    //-------origin data initialize----------------------
    updateOverlaySetting({
      ...currentData,
      info: { plate: [], shot: [], origin: undefined },
    });
    //-------request start-------------------------------

    if (mode === OVERLAY_ADC_CATEGORY && targetInfo?.machine?.originFileObj) {
      const formData = new FormData();
      formData.append('file', targetInfo?.machine?.originFileObj);
      formData.append('rid', source_info?.files_rid);
      uploadStartFunc({
        form: formData,
        param: postData,
        onSettled: () => closeModal(ProcessingModal),
      });
    } else {
      analysisStartFunc({
        param: postData,
        onSettled: () => closeModal(ProcessingModal),
      });
    }
    openModal(ProcessingModal, {
      title: 'Analysing',
      message: 'Analysing data',
      useCancel: true,
      onCancel: analysisCancel,
    });
  };

  useEffect(() => {
    const fetch = (cat, id, data) => {
      setLoadState(true);
      post_Overlay_Plate_Info(cat, id, data)
        .then((res) => {
          const obj = {
            ...currentData,
            targetInfo:
              res?.graph_select === undefined
                ? {
                    ...targetInfo,
                    mean_dev_diff: [],
                    mean_dev_diff_list: res.plate,
                  }
                : {
                    ...targetInfo,
                    mean_dev_diff: [],
                    mean_dev_diff_list: res.plate,
                    graph_select: res.graph_select ?? {
                      selected: '',
                      list: [],
                    },
                  },
          };
          updateOverlaySetting(obj);
        })
        .catch((e) => {
          displayError(e.response.data.msg);
        })
        .finally(() => {
          setLoadState(false);
        });
    };

    const rid = source_info.files_rid;

    if (
      !!targetInfo.job &&
      targetInfo.lot_id.length &&
      !!rid &&
      !!targetInfo.selected[0]
    ) {
      fetch(mode, rid, {
        period: targetInfo.selected.join('~'),
        job: targetInfo.job,
        lot_id: targetInfo.lot_id.map((v) => {
          if (v.match(/LOTID/)) {
            return v.substr(v.indexOf('LOTID'));
          } else {
            const splitStr = v.split('-');
            return splitStr[splitStr.length - 1];
          }
        }),
      });
    }
  }, [targetInfo.job, targetInfo.lot_id]);

  return (
    <OverlayTargetInfo.Provider value={{ loadState, setLoadState }}>
      <div
        css={SG.componentStyle}
        className={
          mode === OVERLAY_CORRECTION_CATEGORY ? 'correction-target' : 'stretch'
        }
      >
        <div
          className={
            'foreground' +
            (mode !== OVERLAY_CORRECTION_CATEGORY &&
            ((source === MSG_LOCAL && !source_info.files_rid) ||
              (source === MSG_REMOTE && !source_info.db_id))
              ? ' active'
              : '')
          }
        >
          <div>
            <FontAwesomeIcon icon={faArrowLeft} size="10x" />
            <p>Please first set the left.</p>
          </div>
        </div>
        <Fragment>
          <Spin size="large" tip="Loading..." spinning={loadState} />
          {mode === OVERLAY_ADC_CATEGORY ? (
            <AdcMeasurementTarget />
          ) : mode === OVERLAY_OAS_BASELINE_CATEGORY ? (
            <OasBaseLineTarget />
          ) : mode === OVERLAY_CORRECTION_CATEGORY ? (
            <CorrectionComponentTarget />
          ) : (
            <Fragment></Fragment>
          )}
          <button
            css={SG.customButtonStyle}
            className="absolute"
            onClick={processStart}
            disabled={startDisableCheck(targetInfo)}
          >
            <PlayCircleOutlined />
            <span>Start</span>
          </button>
        </Fragment>
      </div>
    </OverlayTargetInfo.Provider>
  );
};

export default SelectTarget;
