import { useRef } from 'react';
import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';
import {
  usePostOverlayAnalysis,
  usePostOverlayAnalysisUpload,
} from '@hooks/query/overlay/overlayCommonSetting';
import { RequestOnError, RequestOnSuccess } from '@libs/util/common/common';

export const useTargetAnalysis = () => {
  const cancelRef = useRef(null);
  const { mode, currentData } = useCommonOverlay();
  const { updateOriginDataSetting } = useOverlayInfo();
  const analysisFunc = usePostOverlayAnalysis(cancelRef);
  const uploadMachineFunc = usePostOverlayAnalysisUpload();

  const analysisStartFunc = ({ param, onSettled }) => {
    analysisFunc.mutate(
      {
        data: param,
      },
      {
        onSuccess: ({ info }) => {
          RequestOnSuccess('Analysis Success', 'The analysis was successful.');
          if (info) {
            updateOriginDataSetting(info, mode, currentData);
          }
        },
        onError: RequestOnError,
        onSettled: onSettled,
      },
    );
  };
  const uploadStartFunc = ({ form, param, onSettled }) => {
    uploadMachineFunc.mutate(
      {
        form,
      },
      {
        onSuccess: () => {
          analysisStartFunc({ param, onSettled });
        },
        onError: (e) => {
          RequestOnError(e);
          onSettled();
        },
      },
    );
  };
  return {
    uploadStartFunc,
    analysisStartFunc,
    analysisCancel: analysisFunc.cancel,
    cancelRef,
  };
};
