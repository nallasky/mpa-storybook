import { useState } from 'react';
import { useOverlaySelectTarget } from '@components/Overlay/hooks/useOverlaySelectTarget';
import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';

export const useTargetEquipment = () => {
  const [seletedEquipment, setSelectedEquipment] = useState('');
  const { currentData, setLoadState } = useOverlaySelectTarget();
  const { getOverlayRemoteEquipmentInfo, updateOverlaySetting } =
    useCommonOverlay();
  getOverlayRemoteEquipmentInfo({
    equipment_name: seletedEquipment,
    enabled: !!seletedEquipment,
    onSuccess: (data) => {
      const obj = {
        ...currentData,
        source_info: {
          ...currentData.source_info,
          files_rid: data?.rid,
        },
        targetInfo: {
          ...currentData.targetInfo,
          equipment_name: seletedEquipment,
          period: data.period ?? ['', ''],
          selected: data.period ?? ['', ''],
          job: '',
          job_list: data.job ?? [],
          lot_id: [],
          lot_id_list: data.lot_id ?? {},
          mean_dev_diff: [],
          mean_dev_diff_list: data.plate ?? [],
          stage_correction: [],
          stage_correction_list: data?.stage_correction ?? {},
          adc_correction: [],
          adc_correction_list: data?.adc_correction ?? {},
        },
      };
      updateOverlaySetting(obj);
      setSelectedEquipment('');
    },
    onSettled: () => {
      setLoadState(false);
    },
  });
  const changeEquipment = (v) => {
    setLoadState(true);
    setSelectedEquipment(v);
  };
  return { changeEquipment };
};
