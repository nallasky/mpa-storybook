import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';

export const useTargetGraph = () => {
  const { currentData } = useCommonOverlay();
  const { updateOverlaySetting } = useCommonOverlay();

  const changeGraph = (v) => {
    const obj = {
      ...currentData,
      targetInfo: {
        ...currentData.targetInfo,
        graph_select: {
          ...currentData.targetInfo.graph_select,
          selected: v,
        },
      },
    };
    updateOverlaySetting(obj);
  };
  return { changeGraph };
};
