import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlaySelectTarget } from '@components/Overlay/hooks/useOverlaySelectTarget';

export const useTargetJob = () => {
  const { currentData } = useOverlaySelectTarget();
  const { updateOverlaySetting } = useCommonOverlay();

  const changeJob = (v) => {
    const obj = {
      ...currentData,
      targetInfo: {
        ...currentData.targetInfo,
        job: v,
        lot_id: [],
        mean_dev_diff: [],
      },
    };
    updateOverlaySetting(obj);
  };
  return {
    changeJob,
  };
};
