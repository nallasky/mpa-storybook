import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';

export const useTargetMeanDeviation = () => {
  const { currentData } = useCommonOverlay();
  const { updateOverlaySetting } = useCommonOverlay();
  const { targetInfo } = currentData;
  const { mean_dev_diff, mean_dev_diff_list, graph_select, job, lot_id } =
    targetInfo;
  const optionList = Array.isArray(mean_dev_diff_list)
    ? mean_dev_diff_list
    : mean_dev_diff_list?.[graph_select?.selected ?? ''];

  const changeMeanAll = (v, list) => {
    const obj = {
      ...currentData,
      targetInfo: {
        ...currentData.targetInfo,
        mean_dev_diff: v ? list ?? [] : [],
      },
    };
    updateOverlaySetting(obj);
  };
  return {
    optionList,
    changeMeanAll,
    mean_dev_diff,
    job,
    lot_id,
  };
};
