import { useState } from 'react';
import { CommonRegex } from '@libs/util/regExp';
import { useOverlaySelectTarget } from '@components/Overlay/hooks/useOverlaySelectTarget';
import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { OVERLAY_CORRECTION_CATEGORY } from '@constants/etc';

export const useTargetFab = () => {
  const [loadFabSetting, setLoadFabSetting] = useState(undefined);
  const [fabName, setFabName] = useState('');
  const [inputError, setInputError] = useState(false);
  const { updateOverlaySetting, getOverlayCorrectionSettingInfo, mode } =
    useCommonOverlay();
  const { currentData, changeRedux, setLoadState } = useOverlaySelectTarget();
  getOverlayCorrectionSettingInfo({
    fab_name: loadFabSetting,
    enabled: !!loadFabSetting,
    onSuccess: (data) => {
      console.log({ data });
      const { targetInfo } = currentData;
      const obj = {
        ...currentData,
        targetInfo: {
          ...targetInfo,
          stage_correction_list:
            data?.stage_correction ?? targetInfo?.stage_correction_list ?? {},
          adc_correction_list:
            data?.adc_correction ?? targetInfo?.adc_correction_list ?? {},
        },
      };
      updateOverlaySetting(obj);
      setLoadFabSetting(undefined);
    },
    onSettled: () => {
      setLoadState(false);
    },
  });
  const checkFabName = () => {
    if (inputError) return;

    if (
      currentData.targetInfo.fab_list.includes(fabName) ||
      !CommonRegex.test(fabName)
    ) {
      setInputError(true);
    } else {
      changeRedux([...currentData.targetInfo.fab_list, fabName], 'fab_list');
    }
  };
  const changeFabName = (v) => {
    if (inputError) setInputError(false);
    setFabName(v);
  };
  const changeFab = (v) => {
    const { targetInfo } = currentData;
    const obj = {
      ...currentData,
      targetInfo: {
        ...targetInfo,
        fab_name: v,
        equipment_name: '',
        selected: targetInfo.period,
        job: '',
        lot_id: [],
        mean_dev_diff: [],
      },
    };
    updateOverlaySetting(obj);
    if (mode === OVERLAY_CORRECTION_CATEGORY) {
      setLoadState(true);
      setLoadFabSetting(v);
    }
    setFabName(v);
    if (inputError) setInputError(false);
  };

  return {
    fabName,
    inputError,
    checkFabName,
    changeFabName,
    changeFab,
  };
};
