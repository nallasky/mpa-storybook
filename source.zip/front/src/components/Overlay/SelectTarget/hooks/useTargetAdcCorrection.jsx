import { useState } from 'react';
import { createInitTreeValues } from '../functionGroup';
import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';

export const useTargetAdcCorrection = () => {
  const [radioAdc, setRadioAdc] = useState('');
  const { currentData, updateOverlaySetting } = useCommonOverlay();
  const { targetInfo } = currentData;
  const changeAdcCorrection = (v, key) => {
    console.log({ v, key });
    let tmpData = { ...targetInfo };

    if (key === 'radio') {
      const newTreeValues = createInitTreeValues(
        tmpData.adc_correction_list,
        'adc_correction',
        v,
      );

      Object.keys(tmpData.adc_correction_list).forEach((x) => {
        let curOptionList = { ...tmpData.adc_correction_list[x] };
        curOptionList.selected = x === v;

        tmpData = {
          ...tmpData,
          adc_correction_list: {
            ...tmpData.adc_correction_list,
            [x]: curOptionList,
          },
          adc_correction: newTreeValues,
        };
      });
    } else {
      let curOptionList = { ...tmpData.adc_correction_list[radioAdc] };
      Object.keys(curOptionList).forEach((x) => {
        if (x !== 'selected') {
          curOptionList[x] = v.find((y) => y.split('-')[1] === x) !== undefined;
        }
      });

      tmpData = {
        ...tmpData,
        adc_correction_list: {
          ...tmpData.adc_correction_list,
          [radioAdc]: curOptionList,
        },
        adc_correction: v,
      };
    }

    updateOverlaySetting({
      ...currentData,
      targetInfo: tmpData,
    });
  };
  const changeRadio = (v) => {
    setRadioAdc(v);
    changeAdcCorrection(v, 'radio');
  };
  return {
    radioAdc,
    setRadioAdc,
    changeAdcCorrection,
    changeRadio,
  };
};
