import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlaySelectTarget } from '@components/Overlay/hooks/useOverlaySelectTarget';
import { useMemo } from 'react';
export const useTargetLotId = () => {
  const { currentData } = useOverlaySelectTarget();
  const { updateOverlaySetting } = useCommonOverlay();
  const { targetInfo } = currentData;

  const createTreeSelectData = (data, key, type) => {
    if (!Object.keys(data).length || !key) return [];

    const findOrgData = key === 'all' ? data : data[key];
    let tmpData = [
      {
        title: 'ALL',
        value: '0',
        key: '0',
        children: [],
      },
    ];

    const createArrayType = (obj) => {
      return Object.keys(obj).filter(
        (v) =>
          (Array.isArray(obj[v]) && obj[v].length) || !Array.isArray(obj[v]),
      );
    };

    Object.keys(findOrgData).forEach((v) => {
      if (
        (type === 'adc' && v !== 'selected') ||
        (type === 'lot' && findOrgData[v].length) ||
        type === 'stage'
      ) {
        tmpData[0].children.push(
          type === 'lot'
            ? {
                title: v,
                value: `0-${v}`,
                key: `0-${v}`,
                children: findOrgData[v].map((x) => {
                  return {
                    title: x,
                    value: `0-${v}-${x}`,
                    key: `0-${v}-${x}`,
                  };
                }),
              }
            : type === 'adc'
            ? {
                title: v,
                value: `0-${v}`,
                key: `0-${v}`,
              }
            : {
                title: v,
                value: `0-${v}`,
                key: `0-${v}`,
                children: createArrayType(findOrgData[v]).length
                  ? createArrayType(findOrgData[v]).map((x) => {
                      return {
                        title: x,
                        value: `0-${v}-${x}`,
                        key: `0-${v}-${x}`,
                        children: createArrayType(findOrgData[v][x]).length
                          ? createArrayType(findOrgData[v][x]).map((y) => {
                              return {
                                title: y,
                                value: `0-${v}-${x}-${y}`,
                                key: `0-${v}-${x}-${y}`,
                              };
                            })
                          : [],
                      };
                    })
                  : [],
              },
        );
      }
    });

    return tmpData;
  };
  const lotIdOptions = useMemo(() => {
    return createTreeSelectData(targetInfo.lot_id_list, targetInfo.job, 'lot');
  }, [targetInfo.job]);
  const changeLotId = (v) => {
    const obj = {
      ...currentData,
      targetInfo: {
        ...currentData.targetInfo,
        lot_id: v,
        mean_dev_diff: [],
      },
    };
    updateOverlaySetting(obj);
  };

  return {
    changeLotId,
    lotIdOptions,
  };
};
