import styled from '@emotion/styled';

export const CustomSelect = styled.div`
  display: flex;
  align-items: center;
  column-gap: 8px;
  padding: 0 8px;

  @keyframes shadow {
    50% {
      box-shadow: none;
      border-color: var(--ckr-gray-5);
    }
  }

  & > .input-error {
    animation: shadow 1s ease-in-out infinite;
    box-shadow: 0 0 3px 1px red;
    border-color: var(--ckr-red-6);
  }

  & > .button {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-size: 16px;
    padding: 2px;
    & > span {
      transition: all 0.5s;
      & > svg {
        stroke: var(--ckr-gray-13);
        stroke-width: 30px;
      }
    }
    &.error {
      cursor: not-allowed;
      & > span {
        transform: rotate(45deg);
        opacity: 0.5;
      }
    }
  }
`;

export const MeanAll = styled.div`
  padding: 8px;
  & input {
    display: none;
    &:checked + .button {
      background-color: var(--ckr-blue-6);
      color: var(--ckr-gray-1);
    }
  }
  & .button {
    width: 100%;
    padding: 0.2rem 0;
    cursor: pointer;
    text-align: center;
    border-radius: 4px;
    border: 1px solid var(--ckr-blue-6);
    color: var(--ckr-blue-6);
    background-color: var(--ckr-gray-1);
    transition: all 0.2s ease-in-out;
  }
`;
