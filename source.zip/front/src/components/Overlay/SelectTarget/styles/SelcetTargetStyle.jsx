import { css, keyframes } from '@emotion/react';

const moveLeft = keyframes`
  25% {
    transform: translateX(-25px);
  }
  50% {
    transform: translateX(0);
  }
`;

export const componentTitleStyle = css`
  font-size: 24px;
  color: var(--ckr-blue-6);
`;

export const contentWrapperStyle = css`
  position: relative;
  margin-top: 3rem;
  &.mg-bottom {
    margin-bottom: 13px;
  }
`;

export const contentStyle = css`
  margin: 0 auto;
  width: 83%;
  &.full-width {
    width: 100%;
  }
  & > div + div {
    margin-top: 2rem;
  }
  &.mt-3 {
    & > div + div {
      margin-top: 2.8rem;
    }
  }
`;

export const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 400px;
  background-color: var(--ckr-gray-1);
  border-radius: 4px;
  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3),
    0 2px 6px 2px rgba(60, 64, 67, 0.15);
  & > button {
    &.start {
      position: absolute;
      bottom: 29px;
      right: 16px;
    }
    &.accordion-trigger {
      position: absolute;
      top: -4px;
      right: 0;
      border: 1px solid transparent;
      height: calc(100% + 8px);
      background-color: transparent;
      font-size: 18px;
      cursor: pointer;
      outline: none;
      transition: all 0.2s;
      &:hover:not(:disabled) {
        color: var(--ckr-blue-6);
        border-right: 4px solid var(--ckr-blue-6);
      }
      &:disabled {
        cursor: not-allowed;
        color: var(--ckr-gray-5);
      }
      &.expand {
        & svg {
          transform: rotate(180deg);
        }
      }
    }
  }
  &.correction-target {
    flex-shrink: 0;
    width: calc(50% - 0.5rem);
  }

  &.stretch {
    align-self: stretch;
    width: 100%;
    position: relative;
  }

  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 2rem;
    grid-column: 1 / span 2;
  }
  & > .ant-spin {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    row-gap: 0.5rem;
    background-color: var(--ckr-gray-1);
    border-radius: 4px;
    &.ant-spin-spinning {
      z-index: 1200;
    }
  }
  & .foreground {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 4px;
    display: none;
    justify-content: center;
    align-items: center;
    background-color: var(--ckr-gray-1);
    &.active {
      display: flex;
      z-index: 5;
      & > div {
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        row-gap: 1rem;
        & > svg {
          position: relative;
          animation: ${moveLeft} 1.5s ease-in-out infinite;
        }
        & > p {
          font-size: 20px;
          font-weight: bold;
        }
      }
    }
  }
  .ant-select {
    font-size: 16px;
  }
`;

export const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column-2 {
    grid-template-columns: 0.4fr 1fr;
    span {
      font-size: smaller;
    }
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      font-size: 14px !important;
      &.label {
        &.required {
          &::before {
            display: inline-block;
            color: var(--ckr-red-6);
            font-size: 14px;
            content: '*';
            margin-right: 0.3rem;
          }
        }
        &::after {
          display: inline-block;
          content: ':';
        }
      }
      &.label-2 {
        margin-left: 10px;
        &::after {
          display: inline-block;
          content: ':';
        }
      }
      &.margin-off {
        margin-left: 0;
      }
    }
    &:last-of-type {
      font-size: 12px;
    }
  }
  & ~ div {
    margin-top: 2rem;
    &.table-wrapper {
      margin-top: 1rem;
    }
  }
  .ant-form-item {
    width: 289px;
    margin-bottom: 0;
  }
  .ant-form-item-explain-connected {
    min-height: 0;
  }
  .ant-col-16 {
    max-width: 100%;
  }
`;
export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0 2px 4px 1px rgba(0, 0, 0, 0.2);
  transition: all 0.2s;
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: var(--ckr-gray-1);
    border: 1px dashed var(--ckr-gray-5);
    &:disabled {
      color: var(--ckr-gray-6);
      background-color: var(--ckr-gray-3);
    }
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;

export const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-color: var(--ckr-gray-1);
  border: none;
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: var(--ckr-blue-6);
      transition: transform 0.3s ease-in-out;
      will-change: transform;
      &:hover {
        transform: scale(1.4);
      }
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: 25px;
    right: 16px;
    & > span:first-of-type {
      color: var(--ckr-green-6);
    }
  }
  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
    & > span:first-of-type {
      color: var(--ckr-gray-6);
    }
  }
`;
