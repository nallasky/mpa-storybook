import { OVERLAY_ADC_CATEGORY } from '../../../constants/etc';
import { SelectSource } from '../SelectSource';
import { SelectTarget } from '../SelectTarget';
import OverlayResult from '../OverlayResult/OverlayResult';
import { css } from '@emotion/react';
import { OverlayInfo } from '../hooks/useCommonOverlay';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';

const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 0.5fr 0.5fr;
  gap: 1rem;
  width: 100%;
  margin-top: 0.5rem;
`;
const Measurement = () => {
  const { adcMeasurementSet } = useOverlayInfo();
  return (
    <OverlayInfo.Provider
      value={{
        mode: OVERLAY_ADC_CATEGORY,
        currentData: adcMeasurementSet,
      }}
    >
      <section css={sectionStyle}>
        <SelectSource />
        <SelectTarget />
        <OverlayResult />
      </section>
    </OverlayInfo.Provider>
  );
};
export default Measurement;
