import { Fragment, useState, useEffect } from 'react';
import { Upload } from '@components/common/atoms/Upload';
import { PaperClipOutlined, DeleteOutlined } from '@ant-design/icons';
import { MSG_LOCAL } from '@constants/Message';
import PropTypes from 'prop-types';
import { useOverlaySelectSource } from '../hooks/useOverlaySelectSource';
import * as SG from './styles/SelectSourceStyle';
import { Overlay } from '@assets/locale/en';
import {
  OVERLAY_OAS_BASELINE_CATEGORY,
  OVERLAY_ADC_CATEGORY,
} from '@constants/etc';
import SelectSourceFrom from './SelectSourceFrom';
import SelectRemoteSource from './SelectRemoteSource';

const { select_source: message } = Overlay;
const OasBaseLineSource = ({ startFunc }) => {
  const [isEnableStart, setIsEnableStart] = useState(false);
  const [logFileList, setLogFileList] = useState({
    [OVERLAY_OAS_BASELINE_CATEGORY]: [],
    [OVERLAY_ADC_CATEGORY]: [],
  });
  const { source, addedFiles, checkOasUploadFile } = useOverlaySelectSource();
  const UploadRender = (_, file, __, actions) => {
    return (
      <div className="ant-upload-list-text-container">
        <div className="ant-upload-list-item ant-upload-list-item ant-upload-list-item-list-type-text">
          <span className="ant-upload-span">
            <div className={`ant-upload-text-icon ${file.status}`}>
              <PaperClipOutlined />
            </div>
            <span className={`adc-log-files ${file.status}`} title={file.name}>
              {file.name}
            </span>
            <span
              className={`ant-upload-list-item-card-actions ${file.status}`}
            >
              <button
                title="Remove file"
                type="button"
                className="ant-btn ant-btn-text ant-btn-sm ant-btn-icon-only ant-upload-list-item-card-actions-btn"
                onClick={actions.remove}
              >
                <DeleteOutlined />
              </button>
            </span>
          </span>
        </div>
      </div>
    );
  };
  const OasLogUploadProps = {
    onChange: (e) => {
      checkOasUploadFile({
        ...logFileList,
        [OVERLAY_OAS_BASELINE_CATEGORY]: e.fileList,
      });
    },
    fileList: logFileList[OVERLAY_OAS_BASELINE_CATEGORY],
    beforeUpload: () => false,
    itemRender: UploadRender,
    multiple: true,
  };
  const uploadProps = {
    onChange: (e) => {
      checkOasUploadFile({
        ...logFileList,
        [OVERLAY_ADC_CATEGORY]: e.fileList,
      });
    },
    fileList: logFileList[OVERLAY_ADC_CATEGORY],
    beforeUpload: () => false,
    itemRender: UploadRender,
    multiple: true,
  };

  useEffect(() => {
    const oasFileList = addedFiles.filter(
      (v) => v.log_name === OVERLAY_OAS_BASELINE_CATEGORY,
    );
    const adcFileList = addedFiles.filter(
      (v) => v.log_name === OVERLAY_ADC_CATEGORY,
    );
    if (
      oasFileList.length !== logFileList[OVERLAY_OAS_BASELINE_CATEGORY].length
    ) {
      setIsEnableStart(
        oasFileList.length &&
          !oasFileList.filter((o) => o.status === 'unknown').length,
      );
      setLogFileList((prev) => ({
        ...prev,
        [OVERLAY_OAS_BASELINE_CATEGORY]: oasFileList,
      }));
    } else {
      setLogFileList((prev) => ({
        ...prev,
        [OVERLAY_ADC_CATEGORY]: adcFileList,
      }));
    }
  }, [addedFiles]);

  return (
    <Fragment>
      <div className="setting-area">
        <div css={SG.componentTitleStyle}>{message.label}</div>
        <div css={SG.contentWrapperStyle}>
          <div css={SG.contentStyle} className="full-width">
            <SelectSourceFrom />
            {source === MSG_LOCAL ? (
              <Fragment>
                <div
                  css={SG.contentItemStyle}
                  className="upload column-2 white-space"
                >
                  <Upload
                    type={'Drag'}
                    label={
                      <Fragment>
                        {`${message.from.local.label}\r\n`}
                        <span className="sub-title">
                          {message.from.local.sub.oasbaseline}
                        </span>
                      </Fragment>
                    }
                    uploadProps={OasLogUploadProps}
                  />
                </div>
                <div
                  css={SG.contentItemStyle}
                  className="upload column-2 white-space"
                >
                  <Upload
                    type={'Drag'}
                    required={false}
                    label={
                      <Fragment>
                        {`${message.from.local.label}\r\n`}
                        <span className="sub-title">
                          {message.from.local.sub.adcmeasurement}
                        </span>
                      </Fragment>
                    }
                    uploadProps={uploadProps}
                  />
                </div>
              </Fragment>
            ) : (
              <SelectRemoteSource />
            )}
          </div>
        </div>
      </div>
      <div className="start-button">
        {source === MSG_LOCAL && (
          <button
            css={SG.antdButtonStyle}
            className="white start"
            disabled={!isEnableStart}
            onClick={startFunc}
          >
            {message.start.label}
          </button>
        )}
      </div>
    </Fragment>
  );
};
OasBaseLineSource.propTypes = {
  startFunc: PropTypes.func,
};
export default OasBaseLineSource;
