import { css, keyframes } from '@emotion/react';

const moveLeft = keyframes`
  25% {
    transform: translateX(-25px);
  }
  50% {
    transform: translateX(0);
  }
`;

export const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 400px;
  background-color: var(--ckr-gray-1);
  border-radius: 4px;
  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3),
    0 2px 6px 2px rgba(60, 64, 67, 0.15);
  & > button {
    &.start {
      position: absolute;
      bottom: 29px;
      right: 16px;
    }
    &.accordion-trigger {
      position: absolute;
      top: -4px;
      right: 0;
      border: 1px solid transparent;
      height: calc(100% + 8px);
      background-color: transparent;
      font-size: 18px;
      cursor: pointer;
      outline: none;
      transition: all 0.2s;
      &:hover:not(:disabled) {
        color: var(--ckr-blue-6);
        border-right: 4px solid var(--ckr-blue-6);
      }
      &:disabled {
        cursor: not-allowed;
        color: var(--ckr-gray-5);
      }
      &.expand {
        & svg {
          transform: rotate(180deg);
        }
      }
    }
  }
  & > .setting-area {
    & > p {
      margin-bottom: 0;
      margin-top: 0.25rem;
      opacity: 0;
      &.unknown {
        color: var(--ckr-red-5);
      }
      &.warning {
        color: var(--ckr-gold-6);
      }
      &.show {
        opacity: 1;
      }
    }
  }
  & > .start-button {
    float: right;
  }
  &.correction-target {
    flex-shrink: 0;
    width: calc(50% - 0.5rem);
  }
  &.correction-source {
    display: flex;
    column-gap: 3rem;
    flex-shrink: 0;
    transition: all 0.5s ease-in-out;
    width: calc(50% - 8px);
    padding-right: 2rem;
    overflow: hidden;
    & > button.start {
      padding: 8px 16px;
      font-size: 14px;
      bottom: 12px;
      right: 32px;
    }
    &.expand {
      width: calc(100% + 0.5rem);
      & > .ant-spin {
        width: calc(50% - 1.5rem);
      }
    }
    & > .setting-area {
      width: 648px;
      flex-shrink: 0;
    }
    & > .info-area {
      position: relative;
      width: 672px;
      flex-shrink: 0;
      & > .guard {
        position: absolute;
        display: none;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 100;
        &.show {
          display: block;
        }
      }
      & > div:nth-of-type(2) + div {
        margin-top: 1rem;
      }
    }
  }
  &.stretch {
    align-self: stretch;
    width: 100%;
    position: relative;
  }

  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 2rem;
    grid-column: 1 / span 2;
  }
  & > .ant-spin {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    row-gap: 0.5rem;
    background-color: var(--ckr-gray-1);
    border-radius: 4px;
    &.ant-spin-spinning {
      z-index: 1200;
    }
  }
  & .foreground {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 4px;
    display: none;
    justify-content: center;
    align-items: center;
    background-color: var(--ckr-gray-1);
    &.active {
      display: flex;
      z-index: 5;
      & > div {
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        row-gap: 1rem;
        & > svg {
          position: relative;
          animation: ${moveLeft} 1.5s ease-in-out infinite;
        }
        & > p {
          font-size: 20px;
          font-weight: bold;
        }
      }
    }
  }
`;

export const componentTitleStyle = css`
  font-size: 24px;
  color: var(--ckr-blue-6);
`;

export const contentWrapperStyle = css`
  position: relative;
  margin-top: 3rem;
  &.mg-bottom {
    margin-bottom: 13px;
  }
`;

export const contentStyle = css`
  margin: 0 auto;
  width: 83%;
  &.full-width {
    width: 100%;
  }
  & > div + div {
    margin-top: 2rem;
  }
  &.mt-3 {
    & > div + div {
      margin-top: 2.8rem;
    }
  }
`;

export const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column-2 {
    grid-template-columns: 0.4fr 1fr;
  }
  & .upload-span {
    display: grid;
    align-self: start;
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      font-size: 14px !important;
      &.label {
        &.required {
          &::before {
            display: inline-block;
            color: var(--ckr-red-6);
            font-size: 14px;
            content: '*';
            margin-right: 0.3rem;
          }
        }
        &::after {
          display: inline-block;
          content: ':';
        }
      }
      &.label-2 {
        margin-left: 10px;
        &::after {
          display: inline-block;
          content: ':';
        }
      }
      &.margin-off {
        margin-left: 0;
      }
    }
    &:last-of-type {
      font-size: 12px;
    }
  }
  & .sub-title {
    font-size: 12px;
    color: var(--ckr-blue-6);
  }
  &.upload {
    & .adc-log-files,
    & .ant-upload-text-icon,
    & .ant-upload-list-item-name,
    & .ant-upload-list-item-card-actions {
      &.warning {
        color: var(--ckr-gold-6);
        & .anticon {
          color: var(--ckr-gold-6);
        }
      }
      &.unknown {
        color: var(--ckr-red-5);
        & .anticon {
          color: var(--ckr-red-5);
        }
      }
      &.success {
        color: var(--ckr-blue-6);
        & .anticon {
          color: var(--ckr-blue-6);
        }
      }
    }
    & .ant-upload-list-item {
      max-width: 473px;
    }
    & > span {
      &:first-of-type {
        align-self: start;
      }
      &:last-of-type {
        display: block;
        & .ant-upload-list-text {
          margin-top: 0.5rem;
          overflow: auto;
          min-height: 100px;
          max-width: 451px;
          max-height: 100px;
          &::-webkit-scrollbar {
            width: 8px;
          }
          &::-webkit-scrollbar-track {
            background-color: transparent;
          }
          &::-webkit-scrollbar-thumb {
            border-radius: 4px;
            background-color: rgba(0, 0, 0, 0.2);
          }
          &::-webkit-scrollbar-button {
            width: 0;
            height: 0;
          }
        }
        & .adc-log-files {
          max-width: 435px;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: pre;
          flex: auto;
			    margin: 0;
			    padding: 0 8px;
        }
      }
    }
  &.white-space > span {
    white-space: pre;
  }
`;

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0 2px 4px 1px rgba(0, 0, 0, 0.2);
  transition: all 0.2s;
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: var(--ckr-gray-1);
    border: 1px dashed var(--ckr-gray-5);
    &:disabled {
      color: var(--ckr-gray-6);
      background-color: var(--ckr-gray-3);
    }
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;
