import { Fragment, useEffect } from 'react';
import * as SG from './styles/SelectSourceStyle';
import { MSG_LOCAL } from '@constants/Message';
import { Upload } from '@components/common/atoms/Upload';
import { CorrectionFileInfo } from '@components/Overlay/fragments/CorrectionFileInfo';
import { CaretRightOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';
import { useOverlaySelectSource } from '../hooks/useOverlaySelectSource';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';
import { Overlay } from '@assets/locale/en';
import SelectSourceFrom from './SelectSourceFrom';

const { select_source: message } = Overlay;

const CorrectionComponentSource = ({ isAnalysisComplete, startFunc }) => {
  const {
    currentData,
    addedFiles,
    setAddedFiles,
    loadState,
    setLoadState,
    isExpand,
    setIsExpand,
    updateCorrectionFileInfo,
  } = useOverlaySelectSource();
  const { correctionFiles, correctionUnknownFilesDelete } = useOverlayInfo();

  const uploadProps = {
    onChange: (e) => {
      setAddedFiles(!e.fileList.length ? [] : e.fileList);
      setLoadState(true);
    },
    fileList: addedFiles,
    multiple: true,
    beforeUpload: () => false,
  };

  const startDisableCheck = () => {
    if (!addedFiles.length) return true;

    return !correctionFiles['ADCMEASUREMENT'].flat(2).filter((v) => v.fileObj)
      .length;
  };

  useEffect(() => {
    if (isAnalysisComplete && !isExpand) {
      setIsExpand(true);
      setTimeout(() => updateCorrectionFileInfo(), 1000);
    } else {
      updateCorrectionFileInfo();
    }
  }, [addedFiles]);

  useEffect(() => {
    if (correctionUnknownFilesDelete) {
      setLoadState(true);
      setAddedFiles(
        addedFiles.filter(
          ({ originFileObj }) =>
            !correctionFiles['unknown'].find(
              ({ fileObj }) => originFileObj.uid === fileObj.uid,
            ),
        ),
      );
    }
  }, [correctionUnknownFilesDelete]);

  return (
    <Fragment>
      <div className="setting-area">
        <div css={SG.componentTitleStyle}>{message.label}</div>
        <div css={SG.contentWrapperStyle}>
          <div css={SG.contentStyle} className="full-width">
            <SelectSourceFrom />
            <div css={SG.contentItemStyle} className="upload column-2">
              <Upload
                type={'Drag'}
                label={message.from.local.label}
                uploadProps={uploadProps}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="info-area">
        <div className={'guard' + (loadState ? ' show' : '')} />
        <CorrectionFileInfo />
      </div>
      {currentData.source === MSG_LOCAL && (
        <button
          css={SG.antdButtonStyle}
          className="white start"
          disabled={startDisableCheck()}
          onClick={startFunc}
        >
          {message.start.label}
        </button>
      )}
      <button
        className={'accordion-trigger' + (isExpand ? ' expand' : '')}
        disabled={!isAnalysisComplete}
        onClick={() => setIsExpand(!isExpand)}
      >
        <CaretRightOutlined />
      </button>
    </Fragment>
  );
};
CorrectionComponentSource.propTypes = {
  isAnalysisComplete: PropTypes.bool,
  startFunc: PropTypes.func,
};
export default CorrectionComponentSource;
