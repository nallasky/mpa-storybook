import React, { useState, useRef } from 'react';
import axios from 'axios';
import { Spin } from 'antd';
import useModal from '../../../libs/util/modalControl/useModal';
import useOverlayInfo from '../../../hooks/common/useOverlaySettingInfo';
import { post_Overlay_Local_FilesUpload } from '@libs/axios/overlayRequest';
import {
  OVERLAY_ADC_CATEGORY,
  OVERLAY_ADC_MEASUREMENT_LOG,
  OVERLAY_CORRECTION_CATEGORY,
  OVERLAY_OAS_BASELINE_CATEGORY,
} from '@constants/etc';
import { MSG_REMOTE } from '@constants/Message';
import { displayError } from '@libs/util/common/functionGroup';
import StatusModal from '../fragments/StatusModal/StatusModal';
import ProcessingModal from '../../common/organisms/ProcessingModal/ProcessingModal';
import * as SG from './styles/SelectSourceStyle';
import CorrectionComponentSource from './CorrectionComponentSource';
import AdcMeasurementSource from './AdcMeasurementSource';
import useCommonOverlay, { OverlaySourceInfo } from '../hooks/useCommonOverlay';
import OasBaseLineSource from './OasBaseLineSource';
import { useConfiguration } from '@components/Configuration/hooks';
import { initialOverlayValue } from '@reducers/slices/OverlayInfo';

const SelectSource = () => {
  const { openModal, closeModal } = useModal();
  const [patternInfo, setPatternInfo] = useState(undefined);
  const [loadState, setLoadState] = useState(false);
  const [addedFiles, setAddedFiles] = useState([]);
  const { correctionFiles } = useOverlayInfo();
  const { getDatabaseResource } = useConfiguration();
  const {
    mode,
    getOverlayInfo,
    currentData,
    updateOverlaySetting,
    updateOverlayGraphInfo,
  } = useCommonOverlay();

  const [isExpand, setIsExpand] = useState(true);
  const [isAnalysisComplete, setIsAnalysisComplete] = useState(false);
  const [reLoad, setReload] = useState({ info: true, db: true });

  const getInfo = getOverlayInfo({
    enabled: reLoad.info,
    onSettled: () => setReload((prev) => ({ ...prev, info: false })),
    onSuccess: ({ info }) => {
      setPatternInfo(info?.log_pattern ?? info ?? {});
      updateOverlayGraphInfo(info);
    },
  });
  const getDbList = getDatabaseResource({
    enabled: reLoad.db,
    onSettled: () => setReload((prev) => ({ ...prev, db: false })),
  });
  const cancelTokenSource = useRef();

  const processStart = async () => {
    const formData = new FormData();

    formData.append('category', mode);

    if (mode === OVERLAY_ADC_CATEGORY) {
      addedFiles
        .filter(({ log_name }) => log_name === OVERLAY_ADC_MEASUREMENT_LOG)
        .forEach(({ originFileObj }) => {
          formData.append('files', originFileObj);
        });
    } else if (mode === OVERLAY_OAS_BASELINE_CATEGORY) {
      addedFiles.forEach(({ originFileObj, log_name }) =>
        formData.append(log_name, originFileObj),
      );
    } else {
      setIsAnalysisComplete(false);
      for (const [key, files] of Object.entries(correctionFiles)) {
        files.flat().forEach(({ fileObj }) => {
          if (fileObj) {
            formData.append(key, fileObj);
          }
        });
      }
    }

    try {
      cancelTokenSource.current = new AbortController();

      openModal(ProcessingModal, {
        title: 'Converting',
        message: 'Converting files',
        useCancel: true,
        onCancel: () => cancelTokenSource.current.abort(),
      });

      const response = await post_Overlay_Local_FilesUpload(
        formData,
        cancelTokenSource.current.signal,
      );

      if (response.upload_id && response.upload_id.toString() !== '0') {
        const obj = {
          ...currentData,
          ...initialOverlayValue,
          source: currentData.source,
          source_info: {
            ...currentData.source_info,
            files_rid:
              currentData.source !== MSG_REMOTE
                ? response.upload_id
                : currentData.source_info.files_rid,
          },
          targetInfo: {
            ...initialOverlayValue.targetInfo,
            machine: currentData.targetInfo.machine,
          },
        };
        updateOverlaySetting(obj);

        closeModal(ProcessingModal);
        setTimeout(() => {
          openModal(StatusModal, {
            id: response.upload_id,
            category: mode,
            currentData: obj,
            callback:
              mode === OVERLAY_CORRECTION_CATEGORY
                ? () => {
                    setIsExpand(false);
                    setIsAnalysisComplete(true);
                  }
                : undefined,
          });
        }, 220);
      }
    } catch (e) {
      closeModal(ProcessingModal);
      if (!axios.isCancel(e)) displayError(e.response.data.msg);
    }
  };

  const createMainClassName = () => {
    if (mode !== OVERLAY_CORRECTION_CATEGORY) return 'stretch';
    let newClassName = 'correction-source';
    if (isExpand) {
      newClassName += ' expand';
    }
    return newClassName;
  };

  return (
    <OverlaySourceInfo.Provider
      value={{
        patternInfo,
        loadState,
        addedFiles,
        isExpand,
        setLoadState,
        setAddedFiles,
        setIsExpand,
      }}
    >
      <div css={SG.componentStyle} className={createMainClassName()}>
        <Spin
          size="large"
          tip="Loading..."
          spinning={
            loadState ||
            getInfo.isLoading ||
            getInfo.isFetching ||
            getDbList.isLoading ||
            getDbList.isFetching
          }
        />
        {mode === OVERLAY_CORRECTION_CATEGORY ? (
          <CorrectionComponentSource
            isAnalysisComplete={isAnalysisComplete}
            startFunc={processStart}
          />
        ) : mode === OVERLAY_ADC_CATEGORY ? (
          <AdcMeasurementSource startFunc={processStart} />
        ) : mode === OVERLAY_OAS_BASELINE_CATEGORY ? (
          <OasBaseLineSource startFunc={processStart} />
        ) : (
          <></>
        )}
      </div>
    </OverlaySourceInfo.Provider>
  );
};

export default SelectSource;
