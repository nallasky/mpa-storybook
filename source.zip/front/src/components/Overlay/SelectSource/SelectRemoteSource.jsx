import { Fragment } from 'react';
import { Select, Skeleton } from 'antd';
import * as SG from './styles/SelectSourceStyle';
import { Overlay } from '@assets/locale/en';
import { useSelectRemoteSource } from './hooks/useSelectRemoteSource';

const { select_source: message } = Overlay;
const { Option } = Select;
const SelectRemoteSource = () => {
  const { changeRemote, dbList, selected, isLoading } = useSelectRemoteSource();
  return (
    <Fragment>
      <div css={SG.contentItemStyle} className="column-2">
        <span className="label required">{message.from.remote.label}</span>
        <Skeleton loading={isLoading}>
          <Select
            style={{ width: '100%' }}
            value={selected}
            onChange={changeRemote}
          >
            {dbList.map((db, i) => (
              <Option value={db.id} key={i}>
                {db.host}@{db.name}
              </Option>
            ))}
          </Select>
        </Skeleton>
      </div>
    </Fragment>
  );
};
export default SelectRemoteSource;
