import { useState } from 'react';
import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { useOverlaySelectSource } from '@components/Overlay/hooks/useOverlaySelectSource';
import { initialOverlayState } from '@reducers/slices/OverlayInfo';
import { MSG_REMOTE } from '@constants/Message';
import {
  OVERLAY_ADC_CATEGORY,
  OVERLAY_CORRECTION_CATEGORY,
} from '@constants/etc';

export const useSelectRemoteSource = () => {
  const [selectedRemote, setSelectedRemote] = useState(undefined);
  const { setLoadState, isLoadingRemoteList } = useOverlaySelectSource();
  const { mode, currentData, getOverlayRemoteInfo, updateOverlaySetting } =
    useCommonOverlay();
  const {
    dbList,
    source_info: { db_id: selected },
  } = useOverlaySelectSource();

  getOverlayRemoteInfo({
    db_id: selectedRemote,
    enabled: !!selectedRemote,
    onSuccess: ({ fab, equipments }) => {
      const type =
        mode === OVERLAY_ADC_CATEGORY
          ? 'adcMeasurement'
          : mode === OVERLAY_CORRECTION_CATEGORY
          ? 'correction'
          : 'oasBaseLine';
      const init = initialOverlayState[type];
      const obj = {
        ...currentData,
        source: MSG_REMOTE,
        source_info: {
          ...init.source_info,
          db_id: selectedRemote,
        },
        targetInfo: {
          ...init.targetInfo,
          fab_list: fab ?? [],
          equipment_name_list: equipments ?? [],
          machine: currentData?.targetInfo?.machine ?? {},
        },
        info: init.info,
      };
      updateOverlaySetting(obj);
      setSelectedRemote('');
    },
    onSettled: () => {
      setLoadState(false);
    },
  });

  const changeRemote = async (v) => {
    setLoadState(true);
    setSelectedRemote(v);
  };

  return {
    dbList,
    isLoading: isLoadingRemoteList,
    changeRemote,
    selected: selected ?? '',
  };
};
