import useCommonOverlay from '@components/Overlay/hooks/useCommonOverlay';
import { OVERLAY_CORRECTION_CATEGORY } from '@constants/etc';

export const useSelectSourceFrom = () => {
  const { currentData, updateOverlaySetting, mode } = useCommonOverlay();
  const { source } = currentData;
  const changeFrom = (v) => {
    const obj = {
      ...currentData,
      source: v,
      source_info: {
        files_rid: '',
        db_id: '',
      },
    };
    updateOverlaySetting(obj);
  };
  return {
    changeFrom,
    source,
    isDisable: mode === OVERLAY_CORRECTION_CATEGORY,
  };
};
