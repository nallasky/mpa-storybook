import { Fragment, useState, useEffect } from 'react';
import * as SG from './styles/SelectSourceStyle';
import { MSG_LOCAL } from '@constants/Message';
import PropTypes from 'prop-types';
import { PaperClipOutlined, DeleteOutlined } from '@ant-design/icons';
import { useOverlaySelectSource } from '../hooks/useOverlaySelectSource';
import { Upload } from '@components/common/atoms/Upload';
import { Overlay } from '@assets/locale/en';
import SelectSourceFrom from './SelectSourceFrom';
import SelectRemoteSource from './SelectRemoteSource';
import {
  OVERLAY_MACHINE_LOG,
  OVERLAY_ADC_MEASUREMENT_LOG,
} from '@constants/etc';
const { select_source: message } = Overlay;
const AdcMeasurementSource = ({ startFunc }) => {
  const { source, addedFiles, checkAdcUploadFile, updateTargetMachineInfo } =
    useOverlaySelectSource();
  const [isEnableStart, setIsEnableStart] = useState(false);
  const [logFileList, setLogFileList] = useState({
    [OVERLAY_ADC_MEASUREMENT_LOG]: [],
    [OVERLAY_MACHINE_LOG]: [],
  });
  const UploadRender = (_, file, __, actions) => {
    return (
      <div className="ant-upload-list-text-container">
        <div className="ant-upload-list-item ant-upload-list-item ant-upload-list-item-list-type-text">
          <span className="ant-upload-span">
            <div className={`ant-upload-text-icon ${file.status}`}>
              <PaperClipOutlined />
            </div>
            <span className={`adc-log-files ${file.status}`} title={file.name}>
              {file.name}
            </span>
            <span
              className={`ant-upload-list-item-card-actions ${file.status}`}
            >
              <button
                title="Remove file"
                type="button"
                className="ant-btn ant-btn-text ant-btn-sm ant-btn-icon-only ant-upload-list-item-card-actions-btn"
                onClick={actions.remove}
              >
                <DeleteOutlined />
              </button>
            </span>
          </span>
        </div>
      </div>
    );
  };
  const uploadProps = {
    onChange: (e) => {
      checkAdcUploadFile({
        ...logFileList,
        [OVERLAY_ADC_MEASUREMENT_LOG]: e.fileList,
      });
    },
    fileList: logFileList[OVERLAY_ADC_MEASUREMENT_LOG],
    beforeUpload: () => false,
    itemRender: UploadRender,
    multiple: true,
  };
  const machineLogUploadProps = {
    onChange: (e) => {
      checkAdcUploadFile({
        ...logFileList,
        [OVERLAY_MACHINE_LOG]: e.fileList,
      });
    },
    fileList: logFileList[OVERLAY_MACHINE_LOG],
    beforeUpload: () => false,
    itemRender: UploadRender,
    maxCount: 1,
  };
  useEffect(() => {
    const machineFileList = addedFiles.filter(
      (v) => v.log_name === OVERLAY_MACHINE_LOG,
    );
    const adcFileList = addedFiles.filter(
      (v) => v.log_name === OVERLAY_ADC_MEASUREMENT_LOG,
    );
    if (
      adcFileList.length !== logFileList[OVERLAY_ADC_MEASUREMENT_LOG].length
    ) {
      setIsEnableStart(
        adcFileList.length &&
          !adcFileList.filter((o) => o.status === 'unknown').length,
      );
      setLogFileList((prev) => ({
        ...prev,
        [OVERLAY_ADC_MEASUREMENT_LOG]: adcFileList,
      }));
    } else {
      setLogFileList((prev) => ({
        ...prev,
        [OVERLAY_MACHINE_LOG]: machineFileList,
      }));
      updateTargetMachineInfo(machineFileList);
    }
  }, [addedFiles]);
  console.log('addedFiles', addedFiles);
  return (
    <Fragment>
      <div className="setting-area">
        <div css={SG.componentTitleStyle}>{message.label}</div>
        <div css={SG.contentWrapperStyle}>
          <div css={SG.contentStyle} className="full-width">
            <SelectSourceFrom />
            {source === MSG_LOCAL ? (
              <div css={SG.contentItemStyle} className="upload column-2">
                <Upload
                  type={'Drag'}
                  label={
                    <Fragment>
                      {`${message.from.local.label}\r\n`}
                      <span className="sub-title">
                        {message.from.local.sub.adcmeasurement}
                      </span>
                    </Fragment>
                  }
                  uploadProps={uploadProps}
                />
              </div>
            ) : (
              <SelectRemoteSource />
            )}
            <div
              css={SG.contentItemStyle}
              className="upload column-2 white-space"
            >
              <Upload
                type={'Drag'}
                required={false}
                label={
                  <Fragment>
                    {`${message.from.local.label}\r\n`}
                    <span className="sub-title">
                      {message.from.local.sub.machine}
                    </span>
                  </Fragment>
                }
                uploadProps={machineLogUploadProps}
              />
            </div>
          </div>
        </div>
        {source === MSG_LOCAL && (
          <Fragment>
            <p
              className={
                'warning' +
                (addedFiles.find(
                  ({ status, log_name }) =>
                    log_name === OVERLAY_ADC_MEASUREMENT_LOG &&
                    status === 'warning',
                )
                  ? ' show'
                  : '')
              }
            >
              {message.err.adc.warning}
            </p>
            <p
              className={
                'unknown' +
                (addedFiles.find(
                  ({ status, log_name }) =>
                    log_name === OVERLAY_ADC_MEASUREMENT_LOG &&
                    status === 'unknown',
                )
                  ? ' show'
                  : '')
              }
            >
              {message.err.adc.unknown}
            </p>
          </Fragment>
        )}
      </div>
      {source === MSG_LOCAL && (
        <button
          css={SG.antdButtonStyle}
          className="white start"
          disabled={!isEnableStart}
          onClick={startFunc}
        >
          {message.start.label}
        </button>
      )}
    </Fragment>
  );
};
AdcMeasurementSource.propTypes = {
  startFunc: PropTypes.func,
};

export default AdcMeasurementSource;
