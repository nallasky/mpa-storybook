import { Fragment } from 'react';
import * as SG from './styles/SelectSourceStyle';
import { Overlay } from '@assets/locale/en';
import { OVERLAY_SOURCE } from '@constants/OverlayDefault';
const { select_source: message } = Overlay;
import { Select } from 'antd';
import { useSelectSourceFrom } from './hooks/useSelectSourceFrom';

const SelectSourceFrom = () => {
  const { changeFrom, source, isDisable } = useSelectSourceFrom();
  return (
    <Fragment>
      <div css={SG.contentItemStyle} className="column-2">
        <span className="label required">{message.from.label}</span>
        <Select
          value={source}
          style={{ width: '100%' }}
          disabled={isDisable}
          options={OVERLAY_SOURCE}
          onChange={changeFrom}
        />
      </div>
    </Fragment>
  );
};
export default SelectSourceFrom;
