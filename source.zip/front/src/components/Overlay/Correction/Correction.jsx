import React from 'react';
import { OVERLAY_CORRECTION_CATEGORY } from '@constants/etc';
import SelectSource from '../fragments/SelectSource/SelectSource';
import SelectTarget from '../fragments/SelectTarget/SelectTarget';
import OverlayResult from '../fragments/OverlayResult/OverlayResult';
import styled from '@emotion/styled';

const CorrectionSection = styled.section`
  position: relative;
  width: 100%;
  & > div + div {
    margin-top: 1rem;
  }
  & > .setting-wrapper {
    position: relative;
    display: flex;
    column-gap: 1rem;
    overflow: hidden;
    padding: 1rem;
  }
`;

const Correction = () => {
  return (
    <CorrectionSection>
      <div className="setting-wrapper">
        <SelectSource mode={OVERLAY_CORRECTION_CATEGORY} />
        <SelectTarget mode={OVERLAY_CORRECTION_CATEGORY} />
      </div>
      <OverlayResult mode={OVERLAY_CORRECTION_CATEGORY} />
    </CorrectionSection>
  );
};

export default Correction;
