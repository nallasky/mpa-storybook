import { OVERLAY_CORRECTION_CATEGORY } from '@constants/etc';
import { SelectSource } from '../SelectSource';
import { SelectTarget } from '../SelectTarget';
import OverlayResult from '../OverlayResult/OverlayResult';
import styled from '@emotion/styled';
import { OverlayInfo } from '../hooks/useCommonOverlay';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';

const CorrectionSection = styled.div`
  position: relative;
  width: 100%;
  & > .setting-wrapper {
    position: relative;
    display: flex;
    column-gap: 1rem;
    overflow: hidden;
    padding: 1rem;
  }
  & .result-wrapper {
    padding: 0 1rem;
  }
`;

const Correction = () => {
  const { correctionSet } = useOverlayInfo();
  return (
    <OverlayInfo.Provider
      value={{
        mode: OVERLAY_CORRECTION_CATEGORY,
        currentData: correctionSet,
      }}
    >
      <CorrectionSection>
        <div className="setting-wrapper">
          <SelectSource />
          <SelectTarget />
        </div>
        <div className="result-wrapper">
          <OverlayResult />
        </div>
      </CorrectionSection>
    </OverlayInfo.Provider>
  );
};

export default Correction;
