import { useContext } from 'react';
import useOverlayInfo from '../../../hooks/common/useOverlaySettingInfo';
import useCommonOverlay, { OverlaySourceInfo } from './useCommonOverlay';
import {
  OVERLAY_ADC_MEASUREMENT_LOG,
  OVERLAY_CORRECTION_CATEGORY,
  OVERLAY_MACHINE_LOG,
  OVERLAY_OASBASELINE_LOG,
} from '@constants/etc';
import { initialCorrectionUploadedFiles } from '@reducers/slices/OverlayInfo';
import { usePrevious } from '@libs/util/common/functionGroup';
import { useConfiguration } from '@components/Configuration/hooks';

const correctionPatterns = {
  OffsetTable: 'OFSTB',
  CASPHeader: 'CASPHD',
  CASPTable: 'CASPTB',
  //DRHeader: "DRHD",
  DRTable: 'DRTB',
  //MYHeader: "MYHD",
  MYTable: 'MYTB',
  //YawHeader: "YAWHD",
  YawTable: 'YAWTB',
};

const regex = /^\d+$/;

const checkItemName = (patternItem, fileName, log_name, mode) => {
  if (mode !== OVERLAY_CORRECTION_CATEGORY && !patternItem) {
    return { log: mode, status: 'warning' };
  } else if (
    !patternItem.ignore_pattern.find(
      (pattern) => fileName.indexOf(pattern) !== -1,
    )
  ) {
    if (
      patternItem.pattern.find((pattern) => fileName.indexOf(pattern) !== -1)
    ) {
      return { log: log_name, status: 'success' };
    }
  }
  return { log: undefined, status: undefined };
};
const checkName = (patterns, fileName, mode) => {
  let result = { log: undefined, status: undefined };
  for (const key of Object.keys(patterns)) {
    result = checkItemName(patterns[key], fileName, key, mode);
    if (['success', 'warning'].includes(result.status)) {
      return result;
    }
  }
  return mode !== OVERLAY_CORRECTION_CATEGORY
    ? { log: undefined, status: 'unknown' }
    : result;
};

export const useOverlaySelectSource = () => {
  const { gDatabaseList: dbList } = useConfiguration();
  const { mode, currentData, updateOverlaySetting } = useCommonOverlay();
  const { source, source_info } = currentData;
  const {
    addedFiles,
    setAddedFiles,
    loadState,
    setLoadState,
    patternInfo,
    isExpand,
    setIsExpand,
  } = useContext(OverlaySourceInfo);
  const {
    updateCorrectionFiles,
    updateCorrectionUnknownFilesDelete,
    correctionFiles,
    correctionUnknownFilesDelete,
  } = useOverlayInfo();
  const beforeAddedFiles = usePrevious(addedFiles);

  const updateCorrectionFileInfo = () => {
    if (!addedFiles.length) {
      updateCorrectionFiles(initialCorrectionUploadedFiles);
      updateCorrectionUnknownFilesDelete(false);
      setTimeout(() => setLoadState(false), 2000);
    } else {
      checkCorrectionUploadFile();
    }
  };

  const checkCorrectionUploadFile = async () => {
    if (correctionUnknownFilesDelete) {
      updateCorrectionFiles({
        ...correctionFiles,
        unknown: [],
      });
      updateCorrectionUnknownFilesDelete(false);
      setTimeout(() => setLoadState(false), 2000);
      return;
    }

    const tmpCorrectionFiles = { ...correctionFiles };

    if (addedFiles.length > beforeAddedFiles.length) {
      const newAddedFiles = addedFiles.slice(beforeAddedFiles.length);

      const readFile = (file) => {
        return new Promise((Resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => {
            const contents = e.target.result;
            const lineSplit = contents.split(/\r\n|\n/);
            let result = undefined;
            for (const key of Object.keys(correctionPatterns)) {
              if (lineSplit[0].indexOf(correctionPatterns[key]) !== -1) {
                result = key;
                break;
              }
            }
            Resolve(result);
          };
          reader.onerror = () => Resolve(undefined);
          reader.readAsText(file);
        });
      };

      for (const { originFileObj } of newAddedFiles) {
        console.log('originFileObj', originFileObj);
        let logType = checkName(patternInfo, originFileObj.name, mode).log;

        if (!logType) {
          logType = await readFile(originFileObj);
        }

        if (!logType) {
          logType = regex.test(originFileObj.name) ? 'warning' : 'unknown';
        }

        if (logType !== 'unknown') {
          if (!Object.keys(tmpCorrectionFiles).find((v) => v === logType)) {
            logType = 'unknown';
          }
        }

        if (logType === 'unknown') {
          tmpCorrectionFiles.unknown = [
            ...tmpCorrectionFiles.unknown,
            {
              status: 'unknown',
              type: logType,
              fileObj: originFileObj,
            },
          ];
        } else {
          const typeKey = logType === 'warning' ? 'ADCMEASUREMENT' : logType;
          const newFileObj = {
            status: logType === 'warning' ? 'warning' : 'normal',
            type: logType === 'warning' ? 'ADCMEASUREMENT' : logType,
            fileObj: originFileObj,
          };
          let findFile = false;

          tmpCorrectionFiles[typeKey] = tmpCorrectionFiles[typeKey].map(
            (file, i) => {
              if (!findFile) {
                if (i === tmpCorrectionFiles[typeKey].length - 1) {
                  return [...file, newFileObj];
                }
                if (!file.status) {
                  findFile = true;
                  return newFileObj;
                }
              }
              return file;
            },
          );
        }
      }
    } else if (addedFiles.length < beforeAddedFiles.length) {
      const { originFileObj } = beforeAddedFiles.find(
        (file) =>
          !addedFiles.find(
            (v) => file.originFileObj.uid === v.originFileObj.uid,
          ),
      );
      const { type } = Object.values(tmpCorrectionFiles)
        .flat(2)
        .find((file) => file.fileObj?.uid === originFileObj.uid);
      let findFile = false;
      let emptyIndex = undefined;
      let tmpFileList =
        type === 'unknown'
          ? tmpCorrectionFiles[type].filter(
              (v) => v.fileObj?.uid !== originFileObj.uid,
            )
          : tmpCorrectionFiles[type].map((file, i) => {
              if (!findFile) {
                if (i === tmpCorrectionFiles[type].length - 1) {
                  return file.filter(
                    (v) => v.fileObj?.uid !== originFileObj.uid,
                  );
                }
                if (file.fileObj?.uid === originFileObj.uid) {
                  findFile = true;
                  emptyIndex = i;
                  return {
                    status: undefined,
                    type: undefined,
                    fileObj: undefined,
                  };
                }
              }
              return file;
            });

      if (findFile && tmpFileList[4].length && emptyIndex !== undefined) {
        tmpFileList[emptyIndex] = tmpFileList[4].shift();
      }

      tmpCorrectionFiles[type] = tmpFileList;
    }
    updateCorrectionFiles(tmpCorrectionFiles);
    setTimeout(() => setLoadState(false), 2000);
  };
  const checkUploadFileName = (parrenList, file_name, log_name) => {
    for (let key in parrenList) {
      const tmp = checkItemName(parrenList[key], file_name, key, mode);
      if (['success', 'warning'].includes(tmp.status)) {
        return {
          log: log_name,
          status: tmp.log === log_name ? 'success' : 'unknown',
        };
      }
    }
    return { log: log_name, status: 'warning' };
  };
  const checkAdcUploadFile = async (fileList) => {
    let objList = {};
    for (let key in fileList) {
      Object.assign(objList, {
        [key]: fileList[key].map((v) => {
          console.log('key', key);
          const tmp = checkUploadFileName(
            patternInfo,
            v.originFileObj.name,
            key,
          );
          return v.status !== undefined
            ? v
            : {
                ...v,
                log_name: tmp?.log ?? key,
                status: tmp?.status ?? 'unknown',
              };
        }),
      });
    }
    setAddedFiles([
      ...objList[OVERLAY_ADC_MEASUREMENT_LOG],
      ...objList[OVERLAY_MACHINE_LOG],
    ]);
  };
  const checkOasUploadFile = async (fileList) => {
    let objList = {};
    for (let key in fileList) {
      Object.assign(objList, {
        [key]: fileList[key].map((v) => {
          const tmp = checkUploadFileName(
            patternInfo,
            v.originFileObj.name,
            key,
          );
          return v.status !== undefined
            ? v
            : {
                ...v,
                log_name: tmp?.log ?? key,
                status: tmp?.status ?? 'unknown',
              };
        }),
      });
    }
    setAddedFiles([
      ...objList[OVERLAY_ADC_MEASUREMENT_LOG],
      ...objList[OVERLAY_OASBASELINE_LOG],
    ]);
  };
  const updateTargetMachineInfo = (fileList) => {
    console.log({ fileList });
    const obj = {
      ...currentData,
      targetInfo: {
        ...currentData.targetInfo,
        machine: fileList[0],
      },
    };
    updateOverlaySetting(obj);
  };

  return {
    loadState,
    setLoadState,

    mode,
    currentData,
    addedFiles,
    setAddedFiles,
    beforeAddedFiles,
    isExpand,
    setIsExpand,

    dbList,

    updateCorrectionFileInfo,
    checkAdcUploadFile,
    checkOasUploadFile,
    checkName,

    source,
    source_info,
    updateTargetMachineInfo,
  };
};
