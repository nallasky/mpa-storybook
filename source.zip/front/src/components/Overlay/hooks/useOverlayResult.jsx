import { useState } from 'react';
import {
  OVERLAY_ADC_CATEGORY,
  OVERLAY_CORRECTION_CATEGORY,
  OVERLAY_OAS_BASELINE_CATEGORY,
} from '@constants/etc';
import {
  OVERLAY_ADC_TYPE_LIST,
  OVERLAY_CORRECTION_TYPE_LIST,
  OVERLAY_OAS_BASELINE_TYPE_LIST,
} from '@constants/OverlayDefault';
import useCommonOverlay from './useCommonOverlay';

export const useOverlayResult = () => {
  const [type, setType] = useState({ selected: undefined, list: [] });
  const { currentData } = useCommonOverlay();

  const getResultTypeList = (origin, category) => {
    if (category === OVERLAY_ADC_CATEGORY) {
      return origin
        ? OVERLAY_ADC_TYPE_LIST.filter((obj) => obj.enable(origin))
        : OVERLAY_ADC_TYPE_LIST;
    } else if (category === OVERLAY_CORRECTION_CATEGORY) {
      return origin
        ? OVERLAY_CORRECTION_TYPE_LIST.filter((obj) => obj.enable(origin))
        : OVERLAY_CORRECTION_TYPE_LIST;
    } else if (category === OVERLAY_OAS_BASELINE_CATEGORY) {
      return origin
        ? OVERLAY_OAS_BASELINE_TYPE_LIST.filter((obj) => obj.enable(origin))
        : OVERLAY_OAS_BASELINE_TYPE_LIST;
    }
    return [];
  };

  const updateResultType = (e) => {
    const {
      info: { origin },
    } = currentData;
    let list = getResultTypeList(origin, e);
    setType({ list: list, selected: list?.[0] });
  };

  const changeGraphType = (e) => {
    setType((prev) => ({
      ...prev,
      selected: prev.list.find((o) => o.id === e),
    }));
  };

  return {
    OverlayResultType: type.selected,
    setOverlayResultType: changeGraphType,
    OverlayResultTypeList: type.list,
    updateResultType,
    getResultTypeList,
  };
};
export default useOverlayResult;
