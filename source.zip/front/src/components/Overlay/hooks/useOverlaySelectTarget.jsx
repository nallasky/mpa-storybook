import { useContext } from 'react';
import useCommonOverlay, { OverlayTargetInfo } from './useCommonOverlay';
import dayjs from 'dayjs';

export const useOverlaySelectTarget = () => {
  const { setLoadState } = useContext(OverlayTargetInfo);

  const { mode, currentData, updateOverlaySetting } = useCommonOverlay();

  const changeRedux = (v, key) => {
    const obj = {
      ...currentData,
      targetInfo: {
        ...currentData.targetInfo,
        [key]: v,
      },
    };
    updateOverlaySetting(obj);
  };

  const disabledDate = (date, v) => {
    return !date[0]
      ? false
      : v &&
          (dayjs(v).isBefore(dayjs(date[0]), 'd') ||
            dayjs(v).isAfter(dayjs(date[1]), 'd'));
  };

  return {
    mode,
    currentData,
    setLoadState,
    changeRedux,
    disabledDate,
  };
};
