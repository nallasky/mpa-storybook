import { createContext, useContext } from 'react';
import {
  useGetOverlayInfo,
  useGetOverlayRemoteInfo,
  useGetOverlayRemoteEquipmentInfo,
  useGetOverlayCorrectionSettingInfo,
} from '@hooks/query/overlay/overlayCommonSetting';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';
import useOverlayResult from '@hooks/common/useOverlayResultInfo';
import {
  OVERLAY_ADC_CATEGORY,
  OVERLAY_CORRECTION_CATEGORY,
  OVERLAY_OAS_BASELINE_CATEGORY,
} from '@constants/etc';

const useCommonOverlay = () => {
  const { mode, currentData } = useContext(OverlayInfo);
  const {
    updateCorrectionSetting,
    updateAdcMeasurementSetting,
    updateOasBaseLineSetting,
  } = useOverlayInfo();
  const {
    updateMapSetting,
    updateReproducibilitySetting,
    updateVariationSetting,
    updateAnovaSetting,
    updateCorrectionMapSetting,
    updateOasBaseLineMapGraphSetting,
  } = useOverlayResult();

  const updateOverlaySetting = (obj) => {
    console.log('update: ', obj, mode);
    if (mode === OVERLAY_ADC_CATEGORY) {
      updateAdcMeasurementSetting(obj);
    } else if (mode === OVERLAY_CORRECTION_CATEGORY) {
      updateCorrectionSetting(obj);
    } else if (mode === OVERLAY_OAS_BASELINE_CATEGORY) {
      updateOasBaseLineSetting(obj);
    } else {
      console.log('not matching category : ', mode);
    }
  };

  const updateOverlayMapGraphSetting = (obj) => {
    if (mode === OVERLAY_ADC_CATEGORY) {
      updateMapSetting(obj);
    } else if (mode === OVERLAY_CORRECTION_CATEGORY) {
      updateCorrectionMapSetting(obj);
    } else if (mode === OVERLAY_OAS_BASELINE_CATEGORY) {
      updateOasBaseLineMapGraphSetting(obj);
    } else {
      console.log('not matching category : ', mode);
    }
  };

  const getOverlayInfo = ({ enabled, onSettled, onSuccess }) =>
    useGetOverlayInfo({
      category: mode,
      enabled,
      onSuccess,
      onSettled,
    });
  const getOverlayRemoteInfo = ({ db_id, enabled, onSettled, onSuccess }) =>
    useGetOverlayRemoteInfo({
      obj: { db_id, category: mode },
      enabled,
      onSuccess,
      onSettled,
    });
  const getOverlayRemoteEquipmentInfo = ({
    equipment_name,
    enabled,
    onSettled,
    onSuccess,
  }) =>
    useGetOverlayRemoteEquipmentInfo({
      obj: {
        equipment_name,
        category: mode,
        db_id: currentData.source_info.db_id,
        fab: currentData.targetInfo.fab_name,
      },
      enabled,
      onSuccess,
      onSettled,
    });
  const getOverlayCorrectionSettingInfo = ({
    fab_name,
    enabled,
    onSettled,
    onSuccess,
  }) =>
    useGetOverlayCorrectionSettingInfo({
      fab_name,
      enabled,
      onSuccess,
      onSettled,
    });
  const updateOverlayGraphInfo = (info) => {
    if (Object.keys(info.settings).length) {
      const {
        settings: { graph_setting, graph_type, scale },
      } = info;
      const obj = {
        ...currentData,
        graph: {
          ...currentData.graph,
          plot: {
            ...currentData.graph.plot,
            color: graph_setting?.color ?? graph_setting,
            graph_type: graph_type,
            scale: {
              left: scale ?? {
                type: 'auto',
                upper_limit: '0',
                lower_limit: '0',
              },
              period: {
                type: 'auto',
                upper_limit: '0',
                lower_limit: '0',
              },
            },
          },
        },
      };
      updateOverlaySetting(obj);
    } else {
      console.log('not exist graph setting');
    }
  };
  return {
    mode,
    currentData,

    getOverlayInfo,
    getOverlayRemoteInfo,
    getOverlayRemoteEquipmentInfo,
    getOverlayCorrectionSettingInfo,
    updateOverlaySetting,
    updateOverlayGraphInfo,
    updateOverlayMapGraphSetting,
    updateReproducibilitySetting,
    updateOverlayReproducibilitySetting: updateReproducibilitySetting,
    updateOverlayVariationSetting: updateVariationSetting,
    updateOverlayAnovaSetting: updateAnovaSetting,
  };
};
export default useCommonOverlay;

export const OverlayInfo = createContext(undefined);
export const OverlaySourceInfo = createContext(undefined);
export const OverlayTargetInfo = createContext(undefined);
export const OverlayResultInfo = createContext(undefined);
export const OverlayCpVsInfo = createContext(undefined);
