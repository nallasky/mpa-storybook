import { useCallback } from 'react';
import {
  getOverlayLogSetting,
  UpdateLogSettingInfoReducer,
} from '@reducers/slices/OverlayInfo';
import { useSelector, useDispatch } from 'react-redux';

export const useCommonOverlayLog = () => {
  const gOverlayLogList = useSelector(getOverlayLogSetting);

  const dispatch = useDispatch();

  const updateOverlayLogSetting = useCallback(
    (value) => {
      dispatch(UpdateLogSettingInfoReducer(value));
    },
    [dispatch],
  );

  return { gOverlayLogList, updateOverlayLogSetting };
};
