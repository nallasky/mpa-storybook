import {
  E_CPVS_ADC_MEASUREMENT,
  E_CPVS_BASELINE,
  OVERLAY_OAS_BASELINE_CATEGORY,
} from '@constants/etc';
import { CP_VS_DISPLAY_OPTION } from '@constants/OverlayDefault';
import { useContext } from 'react';
import useCommonOverlay, { OverlayResultInfo } from './useCommonOverlay';
export const useOverlayGraph = () => {
  const {
    updateDisplay,
    setUpdateDisplay,
    OverlayResultType,
    OverlayResultTypeList,
  } = useContext(OverlayResultInfo);
  const { currentData } = useCommonOverlay();

  const disp_option_map = (tab) => {
    const { graph } = currentData;
    const mode =
      tab === OVERLAY_OAS_BASELINE_CATEGORY
        ? E_CPVS_BASELINE
        : E_CPVS_ADC_MEASUREMENT;
    const { cp_vs } = graph.map ?? graph;
    return Object.keys(cp_vs?.[mode]?.shots ?? {}).reduce(
      (acc, shotN) =>
        Object.assign(acc, {
          [shotN]:
            CP_VS_DISPLAY_OPTION[cp_vs?.[mode]?.shots?.[shotN]?.display ?? ''],
        }),
      {},
    );
  };

  const disp_option_correction = () => {
    const { graph } = currentData;
    const {
      info: { shot },
    } = currentData;
    const { cp_vs } = graph.map ?? graph;
    const getItems = (shots, keys, shot_num) => {
      if (shots ?? false) {
        const obj = shots?.[keys].find((o) => o.shot.id === shot_num);
        return Object.keys(obj ?? {})
          .filter((o) => o !== 'shot')
          .reduce((acc2, o) => ({ ...acc2, [o]: obj[o].checked }), {});
      }
      return {};
    };
    return cp_vs?.correction?.shots ?? false
      ? shot?.reduce((acc, shotN) => {
          const cpShot = getItems(cp_vs.correction.shots, 'cp', shotN);
          const vsShot = getItems(cp_vs.correction.shots, 'vs', shotN);
          return { ...acc, [shotN]: { CP: cpShot, VS: vsShot } };
        }, {}) ?? {}
      : {};
  };
  return {
    updateDisplay,
    setUpdateDisplay,
    OverlayResultType,
    OverlayResultTypeList,
    disp_option_map,
    disp_option_correction,
  };
};
