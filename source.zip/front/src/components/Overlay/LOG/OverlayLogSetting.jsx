import { useState } from 'react';
import * as SS from '@components/Overlay/styles/OverlayLogStyle';
import useOverlayLogSetting from '@components/Overlay/LOG/hooks/useOverlayLogSetting';
import { Skeleton } from 'antd';
import LogSetting from '@components/common/organisms/LogSetting';

export const OverlayLogSetting = () => {
  const [reLoad, setReLoad] = useState(true);
  const {
    getOverlayLogListInfo,
    gOverlayLogList,
    updateScriptFile,
    deleteScriptFile,
  } = useOverlayLogSetting();
  const { isLoading, error, isFetching } = getOverlayLogListInfo({
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });

  return (
    <div css={SS.OverlayLogStyle}>
      {error ?? false ? (
        <div className="remote-setting">
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <Skeleton
          loading={isLoading || isFetching}
          active
          paragraph={{ rows: 5 }}
        >
          <div className="box-group">
            {gOverlayLogList.map((logObj, i) => {
              return (
                <div className="box-group-box" key={i}>
                  <LogSetting
                    LogInfo={logObj}
                    action={{
                      delete: deleteScriptFile,
                      refresh: () => setReLoad(true),
                      add: updateScriptFile,
                    }}
                  />
                </div>
              );
            })}
          </div>
        </Skeleton>
      )}
    </div>
  );
};
