import {
  useDeleteOverlayLogScriptFile,
  useGetOverlayLogInfo,
  usePostOverlayLogScriptFile,
} from '@hooks/query/overlay/overlayLogSetting';
import { useCommonOverlayLog } from '@components/Overlay/hooks/useCommonOverlayLog';

const useOverlayLogSetting = () => {
  const { updateOverlayLogSetting, gOverlayLogList } = useCommonOverlayLog();
  const updateScriptFile = usePostOverlayLogScriptFile();
  const deleteScriptFile = useDeleteOverlayLogScriptFile();

  const getOverlayLogListInfo = ({ enabled, onSettled }) =>
    useGetOverlayLogInfo({
      enabled,
      onSuccess: ({ data }) => {
        updateOverlayLogSetting(data);
      },
      onSettled,
    });
  return {
    gOverlayLogList,
    getOverlayLogListInfo,
    deleteScriptFile,
    updateScriptFile,
  };
};
export default useOverlayLogSetting;
