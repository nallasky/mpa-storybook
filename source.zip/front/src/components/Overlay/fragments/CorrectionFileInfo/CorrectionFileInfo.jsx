import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import {
  FileFilled,
  QuestionOutlined,
  CloseOutlined,
  DeleteFilled,
} from '@ant-design/icons';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';
import { usePrevious } from '@libs/util/common/functionGroup';

const HeaderComponent = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  @keyframes show-button {
    60% {
      transform: scale(1.2);
    }
    70% {
      transform: scale(0.8);
    }
    80% {
      transform: scale(1.1);
    }
    90% {
      transform: scale(0.9);
    }
    100% {
      transform: scale(1);
    }
  }
  @keyframes hide-button {
    from {
      transform: scale(1);
    }
    to {
      transform: scale(0);
    }
  }
  & > .title {
    font-size: 24px;
    color: var(--ckr-blue-6);
  }
  & > .buttons {
    display: flex;
    width: 120px;
    & > .button-wrapper {
      position: relative;
      width: 50%;
      text-align: right;
      & > .background {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 400;
        background-color: transparent;
      }
      & > .message {
        position: absolute;
        top: calc(100% + 8px);
        left: -552px;
        background-color: var(--ckr-gold-1);
        border: 2px solid var(--ckr-gold-6);
        width: 672px;
        border-radius: 4px;
        z-index: 2;
        text-align: left;
        padding: 0.5rem;
        transition: all 0.5s;
        transform: scale(0);
        & > p {
          user-select: none;
        }
        & > .title {
          color: var(--ckr-gold-7);
          font-weight: 500;
          margin-bottom: 0.5rem;
        }
        & > .description {
          color: var(--ckr-gold-6);
          font-size: 12px;
          margin-bottom: 0;
        }
        &::before {
          position: absolute;
          top: -8px;
          left: -1px;
          width: calc(100% + 2px);
          height: 8px;
          content: '';
        }
        &:hover {
          transform: scale(1);
        }
        &.show {
          transform: scale(1);
        }
      }
      & > button {
        outline: none;
        border-radius: 50%;
        border-color: transparent;
        box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3),
          0 2px 6px 2px rgba(60, 64, 67, 0.15);
        cursor: pointer;
        transform: scale(0);
        animation: none;
        &.description {
          color: var(--ckr-gold-6);
          background-color: var(--ckr-gold-2);
          &:hover {
            & + .message {
              transform: scale(1);
            }
          }
        }
        &.unknown-list {
          color: var(--ckr-red-5);
          background-color: var(--ckr-red-2);
        }
        &.display {
          animation: none;
          transform: scale(1);
        }
        &.show {
          animation: show-button 1s ease-in-out both;
        }
        &.hide {
          animation: hide-button 0.5s ease-in-out both;
        }
        &:disabled {
          cursor: not-allowed;
          color: var(--ckr-gray-7);
          background-color: var(--ckr-gray-4);
        }
      }
    }
  }
`;

const ContentsComponent = styled.div`
  @keyframes add-log {
    0% {
      opacity: 0;
      right: -100%;
    }
    40% {
      opacity: 1;
      right: 0;
    }
    100% {
      opacity: 0;
      right: 0;
    }
  }
  @keyframes delete-log {
    0% {
      opacity: 0;
      left: 0;
    }
    40% {
      opacity: 1;
      left: 0;
    }
    100% {
      opacity: 0;
      left: -100%;
    }
  }
  @keyframes file-animation {
    0% {
      width: 0;
      opacity: 0;
    }
    40% {
      width: 20%;
      opacity: 0;
    }
    60% {
      width: 20%;
      opacity: 1;
    }
    80% {
      width: 20%;
      opacity: 0;
    }
    100% {
      width: 20%;
      opacity: 1;
    }
  }
  @keyframes tag-wrapper-animate {
    0% {
      top: -8px;
      opacity: 0;
    }
    50% {
      top: -16px;
      opacity: 1;
    }
    100% {
      top: -16px;
      opacity: 0;
    }
  }
  & > .status-table {
    table-layout: fixed;
    font-size: 12px;
    width: 100%;
    border-top: 1px solid var(--ckr-gray-5);
    border-bottom: 1px solid var(--ckr-gray-5);
    & .border-bottom {
      border-bottom: 1px solid var(--ckr-gray-5);
    }
    & .border-top {
      border-top: 1px solid var(--ckr-gray-5);
    }
    & th,
    td {
      position: relative;
      padding: 0.25rem 0;
      cursor: default;
    }
    & > thead {
      & th {
        border-bottom: 1px solid var(--ckr-gray-5);
        &:first-of-type {
          width: 22%;
        }
        &:nth-of-type(2) {
          width: 18%;
        }
      }
    }
    & > tbody {
      & td {
        &.log-name {
          overflow: hidden;
        }
        & > .tag-wrapper {
          position: relative;
          display: flex;
          align-items: center;
          width: 100%;
          &.add {
            &::before {
              line-height: 1.2;
              content: '+';
              animation: tag-wrapper-animate 1s;
            }
          }
          &.delete {
            &::before {
              line-height: 1.4;
              content: '-';
              animation: tag-wrapper-animate 1s;
            }
          }
          &::before {
            position: absolute;
            top: -8px;
            right: 0;
            color: white;
            opacity: 0;
            background-color: black;
            width: 1rem;
            height: 1rem;
            text-align: center;
            border-radius: 50%;
            animation: none;
          }
          & > .file-tag {
            position: relative;
            border-radius: 4px;
            width: 0;
            text-align: center;
            text-overflow: ellipsis;
            white-space: pre;
            overflow: hidden;
            animation: none;
            &.normal {
              color: var(--ckr-blue-6);
            }
            &.warning {
              color: var(--ckr-gold-6);
            }
            &.more {
              cursor: help;
              &:hover {
                & + .file-list {
                  opacity: 1;
                  transform: scale(1);
                }
              }
            }
            &.add {
              animation: file-animation 1.5s both;
            }
            &.show {
              opacity: 1;
              width: 20%;
            }
            &.delete {
              animation: file-animation 1.5s both reverse;
            }
          }
        }
        & > .message {
          position: absolute;
          padding: 0.25rem 0;
          top: 0;
          width: 100%;
          text-align: center;
          color: white;
          animation: none;
        }
        & > .add-log {
          right: -100%;
          background-color: var(--ckr-blue-4);
          &.animate {
            animation: add-log 1.2s cubic-bezier(0.42, 0, 0, 1);
          }
        }
        & > .delete-log {
          opacity: 0;
          left: 0;
          background-color: var(--ckr-red-4);
          &.animate {
            animation: delete-log 1.2s cubic-bezier(0.42, 0, 0, 1);
          }
        }
      }
    }
  }
`;

const FileListComponent = styled.div`
  position: absolute;
  left: 0;
  transition: all 0.5s;
  transform: scale(0);
  z-index: 401;
  border-radius: 4px;
  border: 1px solid var(--ckr-gray-5);
  background-color: white;
  padding: 1rem;
  height: 330px;
  &::before {
    position: absolute;
    content: '';
  }
  &.unknown-list {
    top: 36px;
    left: -354px;
    width: 414px;
    text-align: left;
    &::before {
      top: -8px;
      left: 0;
      width: 100%;
      height: 8px;
    }
    &.open {
      transform: scale(1);
    }
    & > .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      & > button {
        outline: none;
        border: 1px solid var(--ckr-blue-6);
        background-color: white;
        border-radius: 4px;
        color: var(--ckr-blue-6);
        cursor: pointer;
      }
    }
    & > .item-wrapper {
      & > .item {
        & > .icon-wrapper {
          background-color: var(--ckr-red-5);
        }
      }
    }
    & > .confirm-popup {
      position: absolute;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      row-gap: 1rem;
      width: 100%;
      height: 0;
      overflow: hidden;
      top: calc(2rem + 25px);
      left: 0;
      height: 0;
      transition: all 0.5s;
      border-radius: 4px;
      background-color: white;
      z-index: 3;
      &.expand {
        height: calc(250px + 1rem + 5px);
      }
      & > span {
        font-size: 80px;
      }
      & > p {
        margin-bottom: 0;
      }
      & > .button-wrapper {
        & > button {
          outline: none;
          padding: 0.25rem 0.75rem;
          border-radius: 4px;
          cursor: pointer;
          &.delete {
            background-color: var(--ckr-blue-6);
            border: 1px solid var(--ckr-blue-6);
            color: white;
          }
          &.cancel {
            background-color: white;
            border: 1px solid var(--ckr-blue-6);
            color: var(--ckr-blue-6);
          }
          & + button {
            margin-left: 1rem;
          }
        }
      }
    }
  }
  &:not(.unknown-list) {
    width: 100%;
    &.bottom {
      top: 24px;
      &::before {
        left: 0;
        width: 100%;
        top: -5px;
        height: 5px;
      }
    }
    &.left {
      top: -150px;
      left: -80px;
      &::before {
        top: 0;
        right: -7px;
        width: 7px;
        height: 100%;
      }
    }
    &.top {
      top: -333px;
      &::before {
        left: 0;
        bottom: -5px;
        width: 100%;
        height: 5px;
      }
    }
    &:hover {
      transform: scale(1);
    }
  }
  & > .header {
    margin-bottom: 1rem;
    & > .title {
      font-size: 16px;
      font-weight: bold;
      margin-bottom: 0;
    }
  }
  & > .item-wrapper {
    position: relative;
    display: flex;
    flex-direction: column;
    row-gap: 0.5rem;
    max-height: 250px;
    overflow: auto;
    &::-webkit-scrollbar {
      width: 8px;
      height: 8px;
    }
    &::-webkit-scrollbar-track {
      background-color: transparent;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 4px;
      background-color: rgba(0, 0, 0, 0.2);
    }
    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }
    & > .item {
      display: flex;
      align-items: center;
      column-gap: 1rem;
      & > .icon-wrapper {
        background-color: var(--ckr-blue-6);
        font-size: 22px;
        text-align: center;
        padding: 0.25rem 0.75rem;
        border-radius: 4px;
        color: white;
      }
      & > .info-wrapper {
        width: 100%;
        & > p {
          width: 295px;
          white-space: pre;
          text-overflow: ellipsis;
          overflow: hidden;
          margin-bottom: 0;
        }
        & > .file-name {
          font-size: 14px;
          font-weight: 500;
        }
        & > .log-name {
          font-size: 12px;
          color: var(--ckr-gray-7);
        }
      }
    }
  }
`;

const CorrectionFileInfo = () => {
  const [isUnknownOpen, setIsUnknownOpen] = useState(false);
  const { correctionFiles } = useOverlayInfo();
  const beforeCorrectionFiles = usePrevious(correctionFiles);
  const warningRef = useRef(null);
  const unknownRef = useRef(null);

  useEffect(() => {
    const alreadyWarning = beforeCorrectionFiles
      ? Object.values(beforeCorrectionFiles)
          .flat(2)
          .find((v) => v.status === 'warning')
      : undefined;
    const newWarning = Object.values(correctionFiles)
      .flat(2)
      .find((v) => v.status === 'warning');

    if (alreadyWarning) {
      if (newWarning === undefined) {
        warningRef.current.classList.add('hide');
        setTimeout(
          () => warningRef.current.classList.remove('hide', 'display'),
          500,
        );
      }
    } else {
      if (newWarning) {
        warningRef.current.classList.add('show');
        setTimeout(() => {
          warningRef.current.classList.add('display');
          warningRef.current.classList.remove('show');
        }, 1000);
      }
    }

    const alreadyUnknown = beforeCorrectionFiles
      ? beforeCorrectionFiles['unknown'].length
      : 0;
    const newUnknown = correctionFiles['unknown'].length;

    if (alreadyUnknown) {
      if (!newUnknown) {
        unknownRef.current.classList.add('hide');
        setTimeout(
          () => unknownRef.current.classList.remove('hide', 'display'),
          500,
        );
      }
    } else {
      if (newUnknown) {
        unknownRef.current.classList.add('show');
        setTimeout(() => {
          unknownRef.current.classList.add('display');
          unknownRef.current.classList.remove('show');
        }, 1000);
      }
    }
  }, [correctionFiles]);

  return (
    <>
      <HeaderComponent>
        <span className="title">Analysis Data Status</span>
        <div className="buttons">
          <div className="button-wrapper">
            <button className="description" ref={warningRef}>
              <QuestionOutlined />
            </button>
            <div className="message">
              <p className="title">Warning</p>
              <p className="description">
                {
                  "The character 'adcmeasurement' is not included in the file name."
                }
              </p>
            </div>
          </div>
          <div className="button-wrapper">
            <button
              className="unknown-list"
              ref={unknownRef}
              onClick={() => setIsUnknownOpen(!isUnknownOpen)}
            >
              <CloseOutlined />
            </button>
            <FileList
              type="header"
              fileInfo={correctionFiles['unknown']}
              open={isUnknownOpen}
              closer={() => setIsUnknownOpen(false)}
            />
          </div>
        </div>
      </HeaderComponent>
      <ContentsComponent>
        <table className="status-table">
          <thead>
            <tr>
              <th />
              <th>Log Name</th>
              <th>File</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-bottom">
              <td>ADC Measurement MAP</td>
              <LogAndFileInfo
                logName="ADCMeasurement"
                fileInfo={correctionFiles['ADCMEASUREMENT']}
              />
            </tr>
            <tr>
              <td className="border-bottom border-top" rowSpan="4">
                Correction Image MAP
              </td>
              <LogAndFileInfo
                logName="ADCMeasurement"
                fileInfo={correctionFiles['ADCMEASUREMENT']}
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="OffsetTable"
                fileInfo={correctionFiles['OffsetTable']}
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="CASPHeader"
                fileInfo={correctionFiles['CASPHeader']}
              />
            </tr>
            <tr className="border-bottom">
              <LogAndFileInfo
                logName="CASPTable"
                fileInfo={correctionFiles['CASPTable']}
              />
            </tr>
            <tr>
              <td className="border-bottom border-top" rowSpan="4">
                ADC Correction MAP
              </td>
              <LogAndFileInfo
                logName="ADCMeasurement"
                fileInfo={correctionFiles['ADCMEASUREMENT']}
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="OffsetTable"
                fileInfo={correctionFiles['OffsetTable']}
                listPosition="left"
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="CASPHeader"
                fileInfo={correctionFiles['CASPHeader']}
                listPosition="left"
              />
            </tr>
            <tr className="border-bottom">
              <LogAndFileInfo
                logName="CASPTable"
                fileInfo={correctionFiles['CASPTable']}
                listPosition="left"
              />
            </tr>
            <tr>
              <td className="border-bottom border-top" rowSpan="8">
                Stage Correction MAP
              </td>
              <LogAndFileInfo
                logName="ADCMeasurement"
                fileInfo={correctionFiles['ADCMEASUREMENT']}
                listPosition="left"
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="CASPHeader"
                fileInfo={correctionFiles['CASPHeader']}
                listPosition="top"
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="CASPTable"
                fileInfo={correctionFiles['CASPTable']}
                listPosition="top"
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="DRTable"
                fileInfo={correctionFiles['DRTable']}
                listPosition="top"
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="MYTable"
                fileInfo={correctionFiles['MYTable']}
                listPosition="top"
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="YawTable"
                fileInfo={correctionFiles['YawTable']}
                listPosition="top"
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="OffsetTable"
                fileInfo={correctionFiles['OffsetTable']}
                listPosition="top"
              />
            </tr>
            <tr>
              <LogAndFileInfo
                logName="Machine(cons.data)"
                fileInfo={correctionFiles['machine']}
                listPosition="top"
              />
            </tr>
          </tbody>
        </table>
      </ContentsComponent>
    </>
  );
};

const FileList = ({ type, fileInfo, logName, open, closer, position }) => {
  const { updateCorrectionUnknownFilesDelete } = useOverlayInfo();
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);

  const applyDelete = () => {
    setIsConfirmOpen(false);
    setTimeout(() => {
      closer();
      updateCorrectionUnknownFilesDelete(true);
    }, 510);
  };

  const createClassName = () => {
    let newClassName = `file-list ${position}`;

    if (type === 'header') {
      newClassName += ' unknown-list';
    }

    if (open) {
      newClassName += ' open';
    }

    return newClassName;
  };

  return (
    <>
      {open && <div className="background" onClick={closer} />}
      <FileListComponent className={createClassName()}>
        <div className="header">
          <span className="title">
            {type === 'header' ? 'Unknown files' : 'Uploaded files'}
          </span>
          {type === 'header' && (
            <button onClick={() => setIsConfirmOpen(!isConfirmOpen)}>
              <DeleteFilled />
            </button>
          )}
        </div>
        {type === 'header' && (
          <div className={'confirm-popup' + (isConfirmOpen ? ' expand' : '')}>
            <DeleteFilled />
            <p>Are you sure you want to delete all unknown files?</p>
            <div className="button-wrapper">
              <button className="delete" onClick={applyDelete}>
                Delete
              </button>
              <button
                className="cancel"
                onClick={() => setIsConfirmOpen(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        )}
        <div className="item-wrapper">
          {fileInfo.map(({ fileObj }, i) => (
            <div className="item" key={i}>
              <div className="icon-wrapper">
                <FileFilled />
              </div>
              <div className="info-wrapper" title={fileObj.name}>
                <p className="file-name">{fileObj.name}</p>
                <p className="log-name">{logName ?? 'Unknown'}</p>
              </div>
            </div>
          ))}
        </div>
      </FileListComponent>
    </>
  );
};
FileList.propTypes = {
  type: PropTypes.string,
  fileInfo: PropTypes.array,
  logName: PropTypes.string,
  open: PropTypes.bool,
  closer: PropTypes.func,
  position: PropTypes.string,
};
FileList.defaultProps = {
  position: 'bottom',
};

const LogAndFileInfo = ({ logName, fileInfo, listPosition }) => {
  const beforeFileInfo = usePrevious(fileInfo);
  const logNameRef = useRef(null);
  const fileTagRef = useRef(null);

  useEffect(() => {
    if (beforeFileInfo !== undefined) {
      const logNameChildren = logNameRef.current.children;
      const fileTagChildren = fileTagRef.current.children;

      for (let i = 0; i < 5; i++) {
        if (i === 4) {
          if (beforeFileInfo[i].length < fileInfo[i].length) {
            logNameChildren[0].classList.add('animate');
            if (beforeFileInfo[i].length) {
              fileTagRef.current.classList.add('add');
              setTimeout(() => {
                logNameChildren[0].classList.remove('animate');
                fileTagRef.current.classList.remove('add');
              }, 1500);
            } else {
              fileTagChildren[i].classList.add('add');
              setTimeout(() => {
                logNameChildren[0].classList.remove('animate');
                fileTagChildren[i].classList.remove('add');
                fileTagChildren[i].classList.add('show');
              }, 1500);
            }
          } else if (beforeFileInfo[i].length > fileInfo[i].length) {
            logNameChildren[1].classList.add('animate');
            if (fileInfo[i].length) {
              fileTagRef.current.classList.add('delete');
              setTimeout(() => {
                logNameChildren[1].classList.remove('animate');
                fileTagRef.current.classList.remove('delete');
              }, 1500);
            } else {
              fileTagChildren[i].classList.add('delete');
              setTimeout(() => {
                logNameChildren[1].classList.remove('animate');
                fileTagChildren[i].classList.remove('delete', 'show');
              }, 1500);
            }
          }
        } else {
          if (fileInfo[i].fileObj) {
            if (beforeFileInfo[i].fileObj === undefined) {
              logNameChildren[0].classList.add('animate');
              fileTagChildren[i].classList.add('add', fileInfo[i].status);
              setTimeout(() => {
                logNameChildren[0].classList.remove('animate');
                fileTagChildren[i].classList.remove('add');
                fileTagChildren[i].classList.add('show');
              }, 1500);
            }
          } else {
            if (beforeFileInfo[i].fileObj) {
              logNameChildren[1].classList.add('animate');
              fileTagChildren[i].classList.add('delete');
              setTimeout(() => {
                logNameChildren[1].classList.remove('animate');
                fileTagChildren[i].classList.remove(
                  'delete',
                  'show',
                  beforeFileInfo[i].status,
                );
              }, 1500);
            }
          }
        }
      }
    }
  }, [fileInfo]);

  return (
    <>
      <td className="log-name" ref={logNameRef}>
        {logName}
        <div className="message add-log">File added!</div>
        <div className="message delete-log">File deleted!</div>
      </td>
      <td>
        <div className="tag-wrapper" ref={fileTagRef}>
          {fileInfo.map((v, i) => {
            const name = v.fileObj?.name
              ? v.fileObj.name
              : Array.isArray(beforeFileInfo)
              ? beforeFileInfo[i].fileObj?.name
              : '';
            return i !== 4 ? (
              <div className="file-tag" title={name} key={i}>
                {name}
              </div>
            ) : (
              <div className="file-tag more" key={i}>
                ...more files
              </div>
            );
          })}
          <FileList
            fileInfo={fileInfo[4]}
            logName={logName}
            position={listPosition}
          />
        </div>
      </td>
    </>
  );
};
LogAndFileInfo.propTypes = {
  logName: PropTypes.string,
  fileInfo: PropTypes.array,
  listPosition: PropTypes.string,
};

export default CorrectionFileInfo;
