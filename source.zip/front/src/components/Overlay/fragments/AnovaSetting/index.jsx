export { default as AnovaTable } from './AnovaTable';
export { default as AnovaTab } from './SelectTab';
