import { css, keyframes } from '@emotion/react';

export const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 0.4fr 0.6fr;
  gap: 1rem;
  width: 100%;
  padding: 1rem;
`;

const moveLeft = keyframes`
  25% {
    transform: translateX(-25px);
  }
  50% {
    transform: translateX(0);
  }
`;

export const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 400px;
  background-color: var(--ckr-gray-1);
  border-radius: 4px;
  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.3), 0 2px 6px 2px rgba(60, 64, 67, 0.15);
  @keyframes add-file {
    0% {
      opacity: 0;
      right: -100%;
    }
    40% {
      opacity: 1;
      right: 0;
    }
    100% {
      opacity: 0;
      right: 0;
    }
  }
  @keyframes delete-file {
    0% {
      opacity: 0;
      left: 0;
    }
    60% {
      opacity: 1;
      left: 0;
    }
    100% {
      opacity: 0;
      left: -100%;
    }
  }
  & > button {
    &.start {
      position: absolute;
      bottom: 29px;
      right: 32px;
    }
    &.accordion-trigger {
      position: absolute;
      top: -4px;
      right: 0;
      border: 1px solid transparent;
      height: calc(100% + 8px);
      background-color: transparent;
      font-size: 18px;
      cursor: pointer;
      outline: none;
      transition: all 0.2s;
      &:hover:not(:disabled) {
        color: var(--ckr-blue-6);
        border-right: 4px solid var(--ckr-blue-6);
      }
      &:disabled {
        cursor: not-allowed;
        color: var(--ckr-gray-5);
      }
      &.expand {
        & svg {
          transform: rotate(180deg);
        }
      }
    }
  }
  &.correction-target {
    flex-shrink: 0;
    width: calc(50% - 0.5rem);
  }
  &.correction-source {
    display: flex;
    column-gap: 3rem;
    flex-shrink: 0;
    transition: all 0.5s ease-in-out;
    width: calc(50% - 8px);
    padding-right: 2rem;
    overflow: hidden;
    &.expand {
      width: calc(100% + 0.5rem);
    }
    & > .setting-area {
      width: 648px;
      flex-shrink: 0;
    }
    & > .info-area {
      width: 672px;
      flex-shrink: 0;
      & > .title {
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 1rem;
      }
      & > .contents {
        & > .status-table {
          table-layout: fixed;
          font-size: 12px;
          width: 100%;
          border-top: 1px solid #dadada;
          border-bottom: 1px solid #dadada;
          & .border-bottom {
            border-bottom: 1px solid #dadada;
          }
          & .border-top {
            border-top: 1px solid #dadada;
          }
          & th, td {
            position: relative;
            padding: 0.25rem 0;
            cursor: default;
          }
          & > thead {
            & th {
              border-bottom: 1px solid #dadada;
              &:first-of-type {
                width: 21%;
              }
              &:nth-of-type(2) {
                width: 17%;
              }
            }
          }
          & > tbody {
            & td {
              &.log-name {
                overflow: hidden;
              }
              & > .tag-wrapper {
                position: relative;
                display: flex;
                align-items: center;
                column-gap: 0.25rem;
                & > .file-tag {
                  padding: 0 0.25rem;
                  border-radius: 4px;
                  display: inline-block;
                  width: calc(100% / 5 - 0.2rem);
                  text-align: center;
                  text-overflow: ellipsis;
                  white-space: pre;
                  overflow: hidden;
                  &.normal {
                    color: var(--ckr-blue-6);
                  }
                  &.warning {
                    color: var(--ckr-gold-6);                
                  }
                  &.more {
                    cursor: help;
                    &:hover {
                      & + .file-list {
                        opacity: 1;
                        transform: scale(1);
                      }
                    }
                  }
                }
                & > .file-list {
                  position: absolute;
                  top: 24px;
                  left: 0;
                  width: 100%;
                  transition: all 0.5s;
                  transform: scale(0);
                  opacity: 0;
                  z-index: 2;
                  border-radius: 4px;
                  border: 1px solid #dadada;
                  background-color: white;
                  padding: 1rem;
                  &:before {
                    position: absolute;
                    top: -5px;
                    left: 0;
                    width: 100%;
                    content: '';
                    height: 5px;
                  }
                  &:hover {
                    opacity: 1;
                    transform: scale(1);
                  }
                  & > .title {
                    font-size: 16px;
                    font-weight: bold;
                    margin-bottom: 1rem;
                  }
                  & > .item-wrapper {
                    display: flex;
                    flex-direction: column;
                    row-gap: 0.5rem;
                    max-height: 250px;
                    overflow: auto;
                    &::-webkit-scrollbar {
                      width: 8px;
                    }
                    &::-webkit-scrollbar-track {
                      background-color: transparent;
                    }
                    &::-webkit-scrollbar-thumb {
                      border-radius: 4px;
                      background-color: rgba(0, 0, 0, 0.2);
                    }
                    &::-webkit-scrollbar-button {
                      width: 0;
                      height: 0;
                    }
                    & > .item {
                      display: flex;
                      align-items: center;
                      column-gap: 1rem;
                      & > .icon-wrapper {
                        background-color: var(--ckr-blue-6);
                        font-size: 22px;
                        text-align: center;
                        padding: 0.25rem 0.75rem;
                        border-radius: 4px;
                        color: white;
                      }
                      & > .info-wrapper {
                        width: 100%;
                        & > p {
                          width: 313px;
                          white-space: pre;
                          text-overflow: ellipsis;
                          overflow: hidden;
                          margin-bottom: 0;
                        }
                        & > .log-name {
                          font-size: 14px;
                          font-weight: 500;
                        }
                        & > .file-name {
                          font-size: 12px;
                          color: var(--ckr-gray-7);
                        }
                      }
                    }
                  }
                }
              }
              & > .message {
                position: absolute;
                padding: 0.25rem 0;
                top: 0;
                width: 100%;
                text-align: center;
                color: white;
                animation: none;   
              }
              & > .add {
                right: -100%;
                background-color: var(--ckr-blue-4);
                &.animate {
                  animation: add-file 1.2s cubic-bezier(0.42, 0, 0, 1);
                }
              }
              & > .delete {
                left: -100%;
                background-color: var(--ckr-red-4);
                &.animate {
                  animation: delete-file 1.2s cubic-bezier(0.42, 0, 0, 1);
                }
              }
            }
          }
        }
      }
    }
  }
  &.stretch {
    align-self: stretch;
    width: 100%;
  }
  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 2rem;
    grid-column: 1 / span 2;
  }
  & > .ant-spin {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    row-gap: 0.5rem;
    background-color: var(--ckr-gray-1);
    border-radius: 4px;
    &.ant-spin-spinning {
      z-index: 1200;
    }
  }
  & .foreground {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 4px;
    display: none;
    justify-content: center;
    align-items: center;
    background-color: var(--ckr-gray-1);
    &.active {
      display: flex;
      z-index: 5;
      & > div {
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        row-gap: 1rem;
        & > svg {
          position: relative;
          animation: ${moveLeft} 1.5s ease-in-out infinite;
        }
        & > p {
          font-size: 20px;
          font-weight: bold;
        }
      }
    }
  }
`;

export const componentTitleStyle = css`
  font-size: 24px;
  color: var(--ckr-blue-6);
`;

export const contentWrapperStyle = css`
  position: relative;
  margin-top: 3rem;
  &.mg-bottom {
    margin-bottom: 13px;
  }
`;

export const contentStyle = css`
  margin: 0 auto;
  width: 80%;
  &.full-width {
    width: 100%;
  }
  & > div + div {
    margin-top: 2rem;
  }
`;

export const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column-2 {
    grid-template-columns: 0.4fr 1fr;
  }
  &.column-3 {
    grid-template-columns: 0.4fr 1fr 1fr;
  }
  &.etc {
    display: flex;
    justify-content: space-between;
    & > .ant-descriptions-bordered table {
      table-layout: fixed !important;
      & .ant-descriptions-row:nth-of-type(3) {
        display: none;
      }
    }
    & > .label {
      white-space: pre;
    }
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      &.label {
        &::before {
          display: inline-block;
          color: red;
          font-size: 16px;
          content: '*';
          margin-right: 0.3rem;
        }
        &::after {
          display: inline-block;
          content: ':';
        }
      }
    }
  }
  &.upload {
    & > span {
      &:first-of-type {
        align-self: start;
      }
      &:last-of-type {
        width: 100%;
        & .ant-upload-list-text {
          margin-top: 0.5rem;
          overflow: auto;
          height: 120px;
          &::-webkit-scrollbar {
            width: 8px;
          }
          &::-webkit-scrollbar-track {
            background-color: transparent;
          }
          &::-webkit-scrollbar-thumb {
            border-radius: 4px;
            background-color: rgba(0, 0, 0, 0.2);
          }
          &::-webkit-scrollbar-button {
            width: 0;
            height: 0;
          }
        }
      }
    }
    & .full-width {
      & > .ant-upload-select-text,
      & button {
        width: 100%;
      }
    }
  }
  & > .title {
    width: 100%;
    text-align: center;
    font-size: 20px;
  }
  & > .preset-setting {
    display: flex;
    column-gap: 1rem;
    justify-content: space-between;
    & > .ant-form {
      align-self: center;
    }
  }
  & .radio-cp-vs {
    display: grid;
    grid-template-columns: repeat(3, 18rem);
    column-gap: 1rem;
    grid-column: span 2;
  }
  & .margin-lr {
    margin: 0 1rem;
  }
  & .margin-r {
    margin-right: 1rem;
  }
  & .tx-right {
    text-align: right;
  }
  & ~ div {
    margin-top: 2rem;
    &.table-wrapper {
      margin-top: 1rem;
    }
  }
  .ant-form-item {
    width: 289px;
    margin-bottom: 0px;
  }
  .ant-form-item-explain-connected {
    min-height: 0px;
  }
  .ant-col-16 {
    max-width: 100%;
  }
`;

export const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-color: var(--ckr-gray-1);
  border: none;
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: var(--ckr-blue-6);
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: -5px;
    right: 10px;
    & > span:first-of-type {
      color: var(--ckr-green-6);
    }
  }
  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
    & > span:first-of-type {
      color: var(--ckr-gray-6);
    }
  }
`;

export const tableStyle = css`
  margin: 0 auto;
  border: 1px solid var(--ckr-gray-5);
  border-collapse: collapse;
  table-layout: auto;
  text-align: center;
  & th,
  td {
    border: 1px solid var(--ckr-gray-5);
    padding: 0.5rem;
  }
  & th {
    background-color: var(--ckr-gray-2);
  }
`;

export const settingContentStyle = css`
  position: relative;
  margin: 0 auto;
  width: 80%;
  &.etc {
    width: 80%;
  }
  &.full-width {
    width: 100%;
  }
  &.correction-cp-vs {
    width: 70%;
  }
  & .table-wrapper ~ div,
  & .content > .radio-wrapper ~ .tab {
    margin-top: 1rem;
    width: 87%;
  }
`;

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  transition: all 0.2s;
  outline: none;
  &.white {
    background-color: var(--ckr-gray-1);
    border: 1px dashed var(--ckr-gray-5);
    &:disabled {
      color: var(--ckr-gray-6);
      background-color: var(--ckr-gray-3);
    }
  }
  &.blue {
    color: var(--ckr-gray-1);
    background-color: var(--ckr-blue-6);
    border: 1px solid var(--ckr-blue-6);
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;

export const controlStyle = css`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
`;

export const settingStyle = css`
  position: relative;
  background-color: var(--ckr-gray-1);
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  & > .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1rem;
    & > span {
      font-size: 18px;
    }
    & > div > button + button {
      margin-left: 1rem;
    }
  }
  & > .main {
    & > div + div {
      margin-top: 0.1rem;
    }
  }
`;

export const resultStyle = css`
  position: relative;
  min-height: 300px;
  background-color: var(--ckr-gray-1);
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  padding: 1rem;
  & .plot-container  {
    overflow-x: scroll;
    touch-action: auto;  
    & .modebar-container {
      right: -113px !important;
    }
  }

  & .modebar {
    display: contents;
    float: left;
  }
`;
