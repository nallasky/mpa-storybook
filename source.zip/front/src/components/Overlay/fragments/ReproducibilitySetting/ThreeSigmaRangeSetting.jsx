import React from 'react';
import { Descriptions, InputNumber } from 'antd';
import * as SG from '../../styles/OverlayStyle';
import { MESSAGE } from '../../../../constants/Message';
import useOverlayResultInfo from '../../../../hooks/common/useOverlayResultInfo';
import { RibbonCollapse } from '../../../common/molecules/RibbonCollapse/RibbonCollapse';
import { SettingOutlined } from '@ant-design/icons';

const ThreeSigmaRangeSetting = () => {
  const { updateReproducibilitySetting: updateRange, gReproducibility: range } =
    useOverlayResultInfo();
  return (
    <RibbonCollapse title={MESSAGE.SIGMA_RANGE} defaultValue={false}>
      <div className="svg-box">
        <SettingOutlined />
      </div>
      <div css={SG.settingContentStyle} className="etc">
        <div className="content">
          <div css={SG.contentItemStyle} className="etc">
            <Descriptions layout="vertical" bordered>
              <Descriptions.Item label={MESSAGE.SETTING}>
                {MESSAGE.Y_UPPER_LIMIT}
              </Descriptions.Item>
              <Descriptions.Item label={MESSAGE.SIGMA_X}>
                <InputNumber
                  controls={false}
                  style={{ width: '100%', alignItems: 'center' }}
                  defaultValue={range?.three_sigma_x ?? ''}
                  onChange={(e) => updateRange({ ...range, three_sigma_x: e })}
                />
              </Descriptions.Item>
              <Descriptions.Item label={MESSAGE.SIGMA_Y}>
                <InputNumber
                  controls={false}
                  style={{ width: '100%', alignItems: 'center' }}
                  defaultValue={range?.three_sigma_y ?? ''}
                  onChange={(e) => updateRange({ ...range, three_sigma_y: e })}
                />
              </Descriptions.Item>
            </Descriptions>
          </div>
        </div>
      </div>
    </RibbonCollapse>
  );
};

export default ThreeSigmaRangeSetting;
