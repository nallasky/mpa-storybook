import React from 'react';
import { MESSAGE, MSG_ALL } from '@constants/Message';
import * as SG from '../../styles/OverlayStyle';
import { Descriptions, InputNumber, Select } from 'antd';
import useOverlayResultInfo from '../../../../hooks/common/useOverlayResultInfo';
import useOverlaySettingInfo from '../../../../hooks/common/useOverlaySettingInfo';
import { RibbonCollapse } from '../../../common/molecules/RibbonCollapse/RibbonCollapse';
import { SettingOutlined } from '@ant-design/icons';

const RangeAndShotSetting = () => {
  const { updateVariationSetting: updateSetting, gVariation: variation } =
    useOverlayResultInfo();
  const { adcCommonInfo: common } = useOverlaySettingInfo();

  return (
    <RibbonCollapse title={MESSAGE.RANGE_SHOT_CHANGE} defaultValue={false}>
      <div className="svg-box">
        <SettingOutlined />
      </div>
      <div css={SG.settingContentStyle} className="etc">
        <div className="content">
          <div css={SG.contentItemStyle} className="etc">
            <Descriptions layout="vertical" bordered column={5}>
              <Descriptions.Item label={MESSAGE.SETTING}>
                <div>{MESSAGE.RANGE_CHANGE}</div>
              </Descriptions.Item>
              <Descriptions.Item label={MESSAGE.X_LOWER_LIMIT}>
                <InputNumber
                  style={{ width: '100%', alignItems: 'center' }}
                  defaultValue={variation?.x_range_min ?? ''}
                  controls={false}
                  max={variation?.x_range_max}
                  onChange={(e) => updateSetting({ x_range_min: e })}
                />
              </Descriptions.Item>
              <Descriptions.Item label={MESSAGE.X_UPPER_LIMIT}>
                <InputNumber
                  style={{ width: '100%', alignItems: 'center' }}
                  defaultValue={variation?.x_range_max ?? ''}
                  min={variation?.x_range_min ?? 0}
                  controls={false}
                  onChange={(e) => updateSetting({ x_range_max: e })}
                />
              </Descriptions.Item>
              <Descriptions.Item label={MESSAGE.Y_LOWER_LIMIT}>
                <InputNumber
                  style={{ width: '100%', alignItems: 'center' }}
                  defaultValue={variation?.y_range_min ?? ''}
                  controls={false}
                  max={variation?.y_range_max ?? 0}
                  onChange={(e) => updateSetting({ y_range_min: e })}
                />
              </Descriptions.Item>
              <Descriptions.Item label={MESSAGE.Y_UPPER_LIMIT}>
                <InputNumber
                  style={{ width: '100%', alignItems: 'center' }}
                  defaultValue={variation?.y_range_max ?? ''}
                  min={variation?.y_range_min ?? 0}
                  controls={false}
                  onChange={(e) => updateSetting({ y_range_max: e })}
                />
              </Descriptions.Item>
              <Descriptions.Item>{MESSAGE.SHOT_CHANGE}</Descriptions.Item>
              <Descriptions.Item span={4}>
                <Select
                  defaultValue={variation?.select_shot ?? 'all'}
                  onChange={(e) => updateSetting({ select_shot: e })}
                  style={{ minWidth: '176px' }}
                >
                  <Select.Option value={'all'} key={`shot_all`}>
                    {MSG_ALL}
                  </Select.Option>
                  {common.shot.map((shot, i) => {
                    return (
                      <Select.Option value={shot} key={`shot_${i}`}>
                        {shot}{' '}
                      </Select.Option>
                    );
                  })}
                </Select>
              </Descriptions.Item>
            </Descriptions>
          </div>
        </div>
      </div>
    </RibbonCollapse>
  );
};
export default RangeAndShotSetting;
