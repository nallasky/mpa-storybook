import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import styled from '@emotion/styled';
import PropTypes from 'prop-types';
import { Button, Progress } from 'antd';
import { getStatus, getAnalysisInfo } from './functionGroup';
import useModal from '../../../../libs/util/modalControl/useModal';
import ProcessingModal from '../../../common/organisms/ProcessingModal/ProcessingModal';
import DraggableModal from '../../../common/organisms/DraggableModal/DraggableModal';
import { displayNotification } from '@libs/util/common/functionGroup';
import { MSG_LOCAL } from '@constants/Message';
import {
  OVERLAY_ADC_CATEGORY,
  OVERLAY_CORRECTION_CATEGORY,
  OVERLAY_OAS_BASELINE_CATEGORY,
} from '@constants/etc';
import useOverlayInfo from '@hooks/common/useOverlaySettingInfo';

const Contents = styled.div`
  display: flex;
  justify-content: space-around;
  align-items: center;
  & > div {
    &:first-of-type {
      display: flex;
      flex-direction: column;
      row-gap: 1rem;
    }
  }
`;

const StatusModal = ({ id, category, currentData, onClose, callback }) => {
  const { openModal, closeModal } = useModal();
  const [isVisible, setIsVisible] = useState(true);
  const [statusInfo, setStatusInfo] = useState({
    status: 'running',
    percent: 0,
    detail: {
      error_files: 0,
      success_files: 0,
      total_files: 0,
      converted: 0,
    },
  });
  const {
    updateCorrectionSetting,
    updateAdcMeasurementSetting,
    updateOasBaseLineSetting,
  } = useOverlayInfo();
  const cancelTokenSource = useRef();

  const requestAnalysis = () => {
    let isError = undefined;
    setIsVisible(false);
    onClose();

    setTimeout(async () => {
      try {
        cancelTokenSource.current = new AbortController();

        openModal(ProcessingModal, {
          title: 'Analysing',
          message: 'Analysing data',
          useCancel: true,
          onCancel: () => cancelTokenSource.current.abort(),
        });

        const { info } = await getAnalysisInfo(
          id,
          category,
          cancelTokenSource.current.signal,
        );
        console.log('info', info);
        let obj = {};
        if (info) {
          const newTargetData = {
            fab_name: '',
            fab_list: info.fab ?? [],
            equipment_name: '',
            equipment_name_list: {},
            period: info.period ?? ['', ''],
            selected: info.period ?? ['', ''],
            job: '',
            job_list: info.job ?? [],
            lot_id: [],
            lot_id_list: info.lot_id ?? [],
            mean_dev_diff: [],
            mean_dev_diff_list: info.plate ?? [],
            stage_correction_list: info.stage_correction ?? {},
            adc_correction_list: info.adc_correction ?? {},
          };
          console.log('newTargetData', newTargetData);

          obj = {
            ...currentData,
            targetInfo: {
              ...currentData.targetInfo,
              ...newTargetData,
            },
          };
        } else {
          obj = {
            ...currentData,
            source_info: {
              files_rid:
                currentData.source === MSG_LOCAL
                  ? ''
                  : currentData.source_info.files_rid,
              db_id:
                currentData.source !== MSG_LOCAL
                  ? ''
                  : currentData.source_info.db_id,
            },
          };
        }
        if (category === OVERLAY_ADC_CATEGORY) {
          updateAdcMeasurementSetting(obj);
        } else if (category === OVERLAY_CORRECTION_CATEGORY) {
          updateCorrectionSetting(obj);
        } else if (category === OVERLAY_OAS_BASELINE_CATEGORY) {
          updateOasBaseLineSetting(obj);
        } else {
          console.log('not matching category : ', category);
        }
      } catch (e) {
        isError = axios.isCancel(e) ? 'cancel' : e.response.data.msg;
      } finally {
        closeModal(ProcessingModal);
        if (isError !== 'cancel') {
          displayNotification({
            message: isError ? 'Error occurred' : 'Analysis Success',
            description: isError ?? 'The analysis was successful.',
            duration: 3,
            style: isError
              ? { borderLeft: '5px solid red' }
              : { borderLeft: '5px solid green' },
          });
          if (isError === undefined && callback !== undefined) {
            callback();
          }
        }
      }
    }, 220);
  };

  useEffect(() => {
    if (statusInfo.status === 'running') {
      const interval = setInterval(() => {
        getStatus(id, category, setStatusInfo)
          .then((data) => {
            setStatusInfo(
              data ?? {
                ...statusInfo,
                status: 'error',
              },
            );
          })
          .catch((e) => console.log(e));
      }, 1500);
      return () => clearInterval(interval);
    } else if (statusInfo.status === 'cancel') {
      setIsVisible(false);
    } else if (statusInfo.status === 'success') {
      requestAnalysis();
    }
  }, [statusInfo.status]);

  return (
    <DraggableModal
      visible={isVisible}
      centered
      title={
        statusInfo.status === 'running'
          ? 'PROCESS'
          : statusInfo.status === 'success'
          ? 'COMPLETE'
          : 'ERROR'
      }
      width={400}
      footer={[
        <Button
          key="button"
          type="primary"
          onClick={() => setStatusInfo({ ...statusInfo, status: 'cancel' })}
        >
          {statusInfo.status === 'running' ? 'Cancel' : 'Close'}
        </Button>,
      ]}
      closable={false}
    >
      <Contents>
        <div>
          <div>{`Success files: ${statusInfo.detail.success_files}`}</div>
          <div>{`Error files: ${statusInfo.detail.error_files}`}</div>
          <div>{`Total files: ${statusInfo.detail.total_files}`}</div>
          <div>{`Converted rows: ${statusInfo.detail.converted}`}</div>
        </div>
        <div>
          <Progress
            type="circle"
            percent={statusInfo.percent}
            status={
              statusInfo.status === 'running'
                ? 'normal'
                : statusInfo.status === 'success'
                ? 'success'
                : 'exception'
            }
          />
        </div>
      </Contents>
    </DraggableModal>
  );
};
StatusModal.propTypes = {
  id: PropTypes.string.isRequired,
  category: PropTypes.string.isRequired,
  currentData: PropTypes.object.isRequired,
  onClose: PropTypes.func.isRequired,
  callback: PropTypes.func,
};

export default StatusModal;
