import {
  get_Overlay_Local_ConvertStatus,
  get_Overlay_Analysis_Info,
} from '@libs/axios/overlayRequest';

export const getStatus = async (id, cat) => {
  return await get_Overlay_Local_ConvertStatus({ jobId: id, category: cat });
};

export const getAnalysisInfo = async (id, cat, signal) => {
  return await get_Overlay_Analysis_Info(cat, id, signal);
};
