import React, { useMemo } from 'react';
import { postFormdataRequestExport } from '../../../../libs/axios/requests';
import { URL_EXPORT_OVERLAY } from '../../../../constants/URL';
import useOverlaySettingInfo from '../../../../hooks/common/useOverlaySettingInfo';
import PropTypes from 'prop-types';
import {
  E_OVERLAY_ANOVA,
  E_OVERLAY_COMPONENT,
  E_OVERLAY_IMAGE,
  E_OVERLAY_REPRODUCIBILITY,
  E_OVERLAY_VARIATION,
  OVERLAY_ADC_CATEGORY,
} from '../../../../constants/etc';
import { getGraphImage2 } from '../../../../libs/util/plotly-test';
import useOverlayResultInfo from '../../../../hooks/common/useOverlayResultInfo';
import ResultDownloadForm from '../../../common/molecules/ResultDownloadForm/ResultDownloadForm';
import { getTableCsv } from '../../../../libs/util/util';

const ResultDownload = ({ mode, Update }) => {
  const { correctionSet, adcMeasurementSet, getReAnalysisParameter } =
    useOverlaySettingInfo();
  const {
    gCorrectionData,
    gAdcMeasurementData,
    gCorrectionMap,
    gMap,
    gVariation,
    gAnova,
    gReproducibility,
    getAnovaTableFuc,
  } = useOverlayResultInfo();
  const originInfo = useMemo(() => {
    return mode === OVERLAY_ADC_CATEGORY ? adcMeasurementSet : correctionSet;
  }, [gAdcMeasurementData, gCorrectionData]);
  const MapSetting = useMemo(() => {
    return mode === OVERLAY_ADC_CATEGORY ? gMap : gCorrectionMap;
  }, [Update]);
  const makeProperties = () => {
    let postData = getReAnalysisParameter(mode, originInfo);
    console.log('postData', postData);
    const obj =
      mode === OVERLAY_ADC_CATEGORY
        ? {
            ...postData,
            map: MapSetting,
            variation: gVariation,
            reproducibility: gReproducibility,
            anova: gAnova,
          }
        : {
            ...postData,
            correction: MapSetting,
          };
    console.log('obj', obj);
    return JSON.stringify(obj);
  };
  const makeFileName = (v) => {
    const fileList = {
      [E_OVERLAY_VARIATION]: ['shot', 'rot_mag'],
      [E_OVERLAY_REPRODUCIBILITY]: ['x', 'y'],
    };
    const FolderList = {
      [E_OVERLAY_IMAGE]: 'Correction_Image_Map',
      [E_OVERLAY_COMPONENT]: 'Correction_Component_Map',
    };

    const filename = v.split('.');
    if (Object.keys(fileList).includes(filename[0])) {
      const obj = fileList;
      return `${filename[0]}.${obj[filename[0]][+filename[1]]}.png`;
    } else if (Object.keys(FolderList).includes(filename[0])) {
      const obj = FolderList;
      return `${obj[filename[0]]}.${filename[1]}.png`;
    }
    return v;
  };

  const downloadFunc = async () => {
    const FormObj = new FormData();
    console.log('==============settings.json======================');
    FormObj.append(
      'setting',
      new Blob([makeProperties()], {
        type: 'application/json',
      }),
    );
    console.log('==============getGraphImage======================');
    const imgData = await getGraphImage2('_');
    imgData.forEach((v) => {
      FormObj.append('files', new File([v.url], makeFileName(v.filename)));
    });
    console.log('==============anova csv file======================');
    if (mode === OVERLAY_ADC_CATEGORY) {
      const anovaTable_X = getAnovaTableFuc(gAdcMeasurementData.anova?.X ?? {});
      const anovaTable_Y = getAnovaTableFuc(gAdcMeasurementData.anova?.Y ?? {});
      FormObj.append(
        'files',
        new File([getTableCsv(anovaTable_Y)], `${E_OVERLAY_ANOVA}.Y.csv`),
      );
      FormObj.append(
        'files',
        new File([getTableCsv(anovaTable_X)], `${E_OVERLAY_ANOVA}.X.csv`),
      );
    }

    const { status } = await postFormdataRequestExport(
      `${URL_EXPORT_OVERLAY}/${mode}/${originInfo.source_info.files_rid}`,
      FormObj,
    );
    console.log('status', status);
  };
  return <ResultDownloadForm downloadFunc={downloadFunc} />;
};
ResultDownload.propTypes = {
  mode: PropTypes.string,
  Update: PropTypes.bool,
};
export default ResultDownload;
