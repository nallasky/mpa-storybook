import { useState, Fragment } from 'react';
import PropTypes from 'prop-types';
import { ModalFooterButton } from '@components/CommonLog/styles/CommonLogStyles';
import { Common } from '@assets/locale/en';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import {
  allAllowValidator,
  inputCommonValidator,
  ConvertInfoListTable,
} from '@constants/StepDefault';
import { Table } from 'antd';
import useRuleSettingInfo from '@hooks/common/useRuleSettingInfo';
import TableComponent from '@components/JobStep/TableComponents';
import { AnyRegex } from '@libs/util/regExp';
import { css } from '@emotion/react';

const TableStyle = css`
  overflow-x: auto;
  & table > tbody > tr {
    & td {
      white-space: pre;
    }
    & td:last-of-type {
      display: flex;
      align-items: center;
      gap: 5px;
      min-height: 49px;
    }
  }
`;

const SelectInfoModal = ({ onClose, dataSource, config }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [infoList, setInfoList] = useState(dataSource);
  const { updateConvertInfo, convertStepInfo } = useRuleSettingInfo();
  const { info: defineList, selectRows } = config;
  const infoOptions = ['custom', ...Object.keys(defineList ?? {})];

  const closeFunc = () => {
    setIsVisible(false);
    onClose();
  };
  const saveFunc = () => {
    updateConvertInfo({
      ...convertStepInfo,
      log_define: {
        ...convertStepInfo.log_define,
        rule_name: `INFO_${infoList.length}_HEADER_${convertStepInfo.header.length}`,
      },
      info: infoList,
      selectRows: selectRows,
    });
    closeFunc();
  };
  const changeFunc = (e, key) => {
    const { target, value } = e;
    setInfoList((prevState) =>
      prevState.map((item) =>
        item.key === key
          ? target === 'column_define' && value !== 'custom'
            ? {
                ...item,
                name: defineList[value].output_column,
                output_column: defineList[value].output_column,
                output_column_val: defineList[value].output_column,
                data_type: defineList[value].data_type,
                def_val: defineList[value].def_val,
                def_type: defineList[value].def_type,
                column_define: value,
              }
            : target === 'output_column_val'
            ? { ...item, [e.target]: e.value, ['output_column']: e.value }
            : e.target === 'def_type'
            ? {
                ...item,
                [e.target]: e.value,
                ['def_val']: ['text', 'lambda'].includes(e.value)
                  ? ''
                  : e.value,
              }
            : { ...item, [e.target]: e.value }
          : item,
      ),
    );
  };
  return (
    <DraggableModal
      visible={isVisible}
      width={860}
      title="Select Info Setting"
      footer={[
        <ModalFooterButton
          className="white"
          onClick={closeFunc}
          key={'footer_left'}
        >
          {Common.Btn_Cancel}
        </ModalFooterButton>,
        <ModalFooterButton
          key={'footer_right'}
          disabled={false}
          onClick={saveFunc}
        >
          {Common.Btn_Apply}
        </ModalFooterButton>,
      ]}
      cancelHandler={closeFunc}
      maskClosable
      centered
    >
      <Table
        dataSource={infoList}
        bordered
        size="small"
        width={860}
        css={TableStyle}
      >
        <Table.Column
          key={'column_define'}
          title={'info List'}
          dataIndex={'column_define'}
          render={(_, record) => (
            <TableComponent.select
              target={'column_define'}
              record={record}
              options={infoOptions}
              onChange={(e) => changeFunc(e, record.key)}
              validator={allAllowValidator}
            />
          )}
        />
        {ConvertInfoListTable.map((column) => {
          return (
            [
              'data',
              'name',
              'output_column_val',
              'data_type',
              'def_type',
            ].includes(column.dataIndex) && (
              <Table.Column
                key={column.dataIndex}
                title={column.title}
                dataIndex={column.dataIndex}
                render={(_, record) =>
                  record.column_define === 'custom' ? (
                    column.dataIndex === 'data' ? (
                      record[column.dataIndex]
                    ) : column.dataIndex === 'data_type' ? (
                      <TableComponent.select
                        target={column.dataIndex}
                        record={record}
                        options={config[column.dataIndex]}
                        onChange={(e) => changeFunc(e, record.key)}
                        regEx={{ pattern: AnyRegex, message: '' }}
                        validator={allAllowValidator}
                      />
                    ) : column.dataIndex === 'def_type' ? (
                      <Fragment>
                        <TableComponent.select
                          target={column.dataIndex}
                          record={record}
                          options={config[column.dataIndex]}
                          onChange={(e) => changeFunc(e, record.key)}
                          validator={allAllowValidator}
                        />
                        <TableComponent.input
                          target={'def_val'}
                          record={record}
                          disabled={
                            !['text', 'lambda'].includes(record.def_type)
                          }
                          onChange={(e) => changeFunc(e, record.key)}
                          validator={allAllowValidator}
                        />
                      </Fragment>
                    ) : (
                      <TableComponent.input
                        target={column.dataIndex}
                        record={record}
                        onChange={(e) => changeFunc(e, record.key)}
                        validator={inputCommonValidator}
                        regEx={{ pattern: AnyRegex, message: '' }}
                      />
                    )
                  ) : (
                    record[column.dataIndex]
                  )
                }
              />
            )
          );
        })}
      </Table>
    </DraggableModal>
  );
};
SelectInfoModal.propTypes = {
  dataSource: PropTypes.array,
  onClose: PropTypes.func,
  config: PropTypes.object,
};
export default SelectInfoModal;
