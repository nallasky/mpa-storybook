import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import useRuleSettingInfo from '../../hooks/common/useRuleSettingInfo';
import { css } from '@emotion/react';
import { useParams } from 'react-router-dom';
import {
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_LOG_DEFINE_SETTING,
  LOCAL_INFO,
  R_OK,
} from '@constants/etc';
import {
  getFileName,
  getFormdataFiles,
  getParseData,
  getTableForm,
} from '@libs/util/util';
import { Table } from 'antd';
import { NotificationBox } from '../common/molecules/NotificationBox';
import { FormCard } from '../common/atoms/Modal';
import { StepInputForm } from '../common/organisms/StepInputForm';
import { inputCommonValidator, StepConfigure } from '@constants/StepDefault';
import { getRequestParam } from '@libs/axios/requests';
import { postLogStepSampleLog } from '@libs/axios/LogStepRequest';
import { CommonRegex } from '@libs/util/regExp';
const tableWrapper = css`
  display: contents;
`;
const titleStyle = css`
  font-weight: 400;
`;

const PreviewRequest = async ({
  convertStepInfo,
  rule_id,
  log_name,
  data,
  setData,
}) => {
  const originLogData = data?.src_file ?? null;
  console.log('rule_id', rule_id);
  if (!!originLogData === false) {
    console.log('file is empty');
    return { data: undefined, step: undefined };
  } else {
    try {
      const { info, status } = await postLogStepSampleLog({
        src_file: getFormdataFiles(data?.src_file ?? null),
        log_name,
        duplicated: convertStepInfo.mode === STEP2_MSG_ADD,
      });
      if (status === R_OK) {
        if (info.result) {
          const tableData = getTableForm({ info: info.data, max_row: 5 });
          setData((prevState) => ({
            ...prevState,
            ['log_header']: tableData.columns,
            ['log_data']: tableData.dataSource,
            ['log_error']: undefined,
          }));
          return { data: info, step: E_STEP_LOG_DEFINE_SETTING };
        } else {
          NotificationBox({ title: 'ERROR', message: info.err });
          return { data: undefined, step: undefined };
        }
      }
    } catch (e) {
      if (e.response) {
        const {
          data: { msg },
        } = e.response;
        console.log(e.response);
        NotificationBox({ title: 'ERROR', message: msg });
      }
      return { data: undefined, step: undefined };
    }
  }
};

const NextRequest = async ({
  rule_id,
  log_name,
  convertStepInfo,
  data,
  preview,
}) => {
  const isEditMode = !!(rule_id ?? false);
  const { log_define } = convertStepInfo;
  console.log('log_define', log_define);
  console.log('data', data);
  console.log('rule_id', rule_id, log_name);
  const { info, status } = await getRequestParam(
    isEditMode
      ? `${StepConfigure[E_STEP_LOG_DEFINE_SETTING].edit}/${log_name}/${rule_id}`
      : log_name
      ? `${StepConfigure[E_STEP_LOG_DEFINE_SETTING].new}/${log_name}`
      : `${StepConfigure[E_STEP_LOG_DEFINE_SETTING].new}`,
    undefined,
  );
  if (status === R_OK) {
    return {
      info: { config: info },
      next: E_STEP_LOG_CONVERT_SETTING,
      preview: preview,
    };
  }
};

const NextButtonEvent = async ({
  setLoading,
  funcStepInfo,
  convertStepInfo,
  rule_id,
  log_name,
  data,
}) => {
  setLoading(true);

  if (funcStepInfo?.src_file ?? false) {
    const result = await PreviewRequest({
      convertStepInfo,
      rule_id,
      log_name,
      data: data.data,
      setData: data.func,
    }).then((_) => _);
    console.log('PreviewResult', result);
    if (result.step === E_STEP_LOG_DEFINE_SETTING) {
      return NextRequest({
        rule_id,
        log_name,
        data,
        convertStepInfo,
        preview: { current: E_STEP_LOG_DEFINE_SETTING, info: result.data },
      }).then((_) => _);
    } else {
      setLoading(false);
    }
  } else {
    return NextRequest({
      log_name,
      rule_id,
      data,
      convertStepInfo,
      preview: undefined,
    }).then((_) => _);
  }
};
const PreviewButtonEvent = ({
  convertStepInfo,
  rule_id,
  data,
  log_name,
  setData,
}) => {
  return PreviewRequest({
    convertStepInfo,
    rule_id,
    log_name,
    data,
    setData,
  }).then((_) => _);
};
const PreviousButtonEvent = () => {};
const PreviewEnableCheck = (funcStepInfo) => {
  return !!funcStepInfo?.src_file;
};

const NextEnableCheck = (convertStepInfo) => {
  return CommonRegex.test(convertStepInfo?.log_define?.log_name ?? '');
};
/*============================================================================
==                         STEP 2 CONTENTS                                  ==
============================================================================*/
const STEP2_MSG_ADD = 'add';
const STEP2_MSG_NEW = 'new';
const STEP2_MSG_EDIT = 'edit';
const INPUT_TYPE_CSV = 'csv';

const ContentsForm = ({ data, onChange }) => {
  const {
    ruleStepConfig,
    updateConvertInfo,
    updateFuncInfo,
    funcStepInfo,
    convertStepInfo,
  } = useRuleSettingInfo();
  const { log_name, rule_id } = useParams();
  const [config, setConfig] = useState(null);
  const updateLogName = (log) => {
    updateConvertInfo({
      ...convertStepInfo,
      mode:
        log_name ?? false
          ? rule_id ?? false
            ? STEP2_MSG_EDIT
            : STEP2_MSG_ADD
          : STEP2_MSG_NEW,
      log_define: {
        ...convertStepInfo.log_define,
        log_name: log,
        table_name: log,
        input_type: INPUT_TYPE_CSV,
      },
    });
  };
  const LocalConfigChange = (event) => {
    const item = getParseData(event);
    switch (item.id) {
      case 'log_name':
        onChange(event);
        updateLogName(item.value);
        break;
      case 'src_file':
        {
          const fileName = getFileName(item.value);
          updateFuncInfo({
            ...funcStepInfo,
            src_file: fileName,
          });
          if (fileName && config?.extra) {
            const { log_pattern } = config.extra;
            const log_name = Object.keys(log_pattern).find(
              (log) =>
                log_pattern[log].pattern.find(
                  (str) =>
                    fileName.toLowerCase().indexOf(str.toLowerCase()) !== -1,
                ) &&
                !log_pattern[log].ignore_pattern.find(
                  (str) =>
                    fileName.toLowerCase().indexOf(str.toLowerCase()) !== -1,
                ),
            );
            console.log('log_name', log_name);
            updateLogName(
              log_name ?? convertStepInfo.log_define?.log_name ?? '',
            );
            onChange(
              log_name
                ? { src_file: item.value, log_name: log_name }
                : { src_file: item.value },
            );
          } else {
            onChange({ src_file: item.value });
          }
        }
        break;
    }
  };

  const change = (event) => {
    const item = getParseData(event);
    switch (item.id) {
      case 'file_name':
        {
          const fileName = getFileName(item.value);
          updateFuncInfo({
            ...funcStepInfo,
            script: {
              file_name: fileName,
              use_script: item.value !== null,
            },
          });
          onChange({ step2_script: item.value });
        }
        break;
      case 'use_script':
        updateFuncInfo({
          ...funcStepInfo,
          script: {
            ...funcStepInfo.script,
            use_script: item.value,
          },
        });
        break;
      case 'src_file':
      case 'log_name':
        LocalConfigChange(event);
        break;
      case 'pattern':
      case 'ignore_pattern':
        updateConvertInfo({
          ...convertStepInfo,
          log_define: {
            ...convertStepInfo.log_define,
            [item.id]: item.value,
          },
        });
        break;
      default:
        onChange(event);
        break;
    }
  };
  //============================================================================
  useEffect(() => {
    console.log('contents components mount', rule_id, log_name, ruleStepConfig);
    const step2 = ruleStepConfig.find(
      (step) => step.step === E_STEP_LOG_DEFINE_SETTING,
    );
    console.log('step2', step2);
    const log_pattern = step2?.config?.extra?.log_pattern;
    if (log_pattern) {
      setConfig({
        ...step2?.config,
        log_list: Object.keys(log_pattern).map((o) => o.toLowerCase()),
      });
    } else {
      setConfig(step2?.config ?? []);
    }
    //Edit 화면으로 들어왔을때. step2 데이터에서 정보를 가져와서 REDUX 에 저장해줘야한다.
    if (rule_id) {
      const obj = {};
      const script = {};
      updateFuncInfo({
        ...funcStepInfo,
        source_type: LOCAL_INFO,
        info: obj,
        script: script,
      });
    }
    updateConvertInfo({
      ...convertStepInfo,
      mode:
        log_name ?? false
          ? rule_id === undefined
            ? STEP2_MSG_ADD
            : STEP2_MSG_EDIT
          : STEP2_MSG_NEW,
      rule_list: [],
      log_define:
        rule_id || log_name
          ? {
              ...convertStepInfo.log_define,
              rule_name: '',
              rule_id: rule_id,
              log_name: log_name,
              table_name: log_name,
            }
          : convertStepInfo?.log_define ?? {},
    });
    return () => {
      console.log('contents components unmount');
    };
  }, []);

  //============================================================================
  if (config === null) return <></>;

  return (
    <div css={{ width: '500px' }}>
      {(config?.form ?? []).map((item, idx) => (
        <div key={idx}>
          <FormCard title={item.title} titleStyle={titleStyle}>
            <div>
              {item.items.map((obj, i) => {
                const { target, type } = obj;
                return (
                  <StepInputForm
                    key={i}
                    data={data}
                    item={
                      target === 'log_name' && type === 'input'
                        ? {
                            ...obj,
                            checkFunc: (v) => {
                              const info = inputCommonValidator(v);
                              const duplicated = config?.log_list?.includes(
                                v.toLowerCase(),
                              );
                              if (duplicated || info.status === 'error') {
                                return Promise.reject(
                                  new Error(
                                    info.errMsg ?? ` ${v}is duplicated!!}`,
                                  ),
                                );
                              }
                              return Promise.resolve();
                            },
                            regExp: [
                              {
                                validator: async (_, v) => {
                                  if (
                                    config?.log_list?.includes(v.toLowerCase())
                                  ) {
                                    return Promise.reject(
                                      new Error(`${v} is duplicated!!`),
                                    );
                                  }
                                },
                              },
                            ],
                          }
                        : obj
                    }
                    changeFunc={change}
                  />
                );
              })}
            </div>
          </FormCard>
        </div>
      ))}
    </div>
  );
};
ContentsForm.propTypes = {
  data: PropTypes.object,
  onChange: PropTypes.func,
};

const PreviewForm = ({ data }) => {
  if (data == null) return <></>;
  const { log_header, log_data } = data;

  if (log_header === undefined || log_data === undefined) return <></>;

  return (
    <div css={tableWrapper}>
      <Table
        bordered
        pagination={false}
        columns={log_header}
        dataSource={log_data}
        size="middle"
        rowKey="key"
        scroll={{ x: 'max-content' }}
      />
    </div>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const LogDefineStep = ({ children }) => {
  return <div>{children}</div>;
};

LogDefineStep.propTypes = {
  children: PropTypes.node,
};

LogDefineStep.btn_next = NextButtonEvent;
LogDefineStep.btn_previous = PreviousButtonEvent;
LogDefineStep.btn_preview = PreviewButtonEvent;
LogDefineStep.check_next = NextEnableCheck;
LogDefineStep.check_preview = PreviewEnableCheck;
LogDefineStep.view_contents = ContentsForm;
LogDefineStep.view_preview = PreviewForm;

export default LogDefineStep;
