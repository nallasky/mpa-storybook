import { css } from '@emotion/react';
export const PreviewFrameStyle = css`
  background: var(--ckr-gray-2);
  display: flex;
  flex-direction: column;

  flex: none;
  order: 3;
  align-self: stretch;
  flex-grow: 0;

  border: 1px solid var(--ckr-gray-5);
  box-sizing: border-box;
  border-radius: 8px;

  min-height: 300px;
`;
export const PreviewTitleStyle = css`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-height: 32px;
  align-items: center;
  margin: 10px 10px 0px 10px;
  padding: 0px 10px 0px 10px;
`;
export const graphFrameStyle = css`
  background-color: var(--ckr-gray-1);
  margin: 0;
  padding: 1rem;
  border-radius: 8px;
  min-height: 300px;
`;

export const ContentsFrameStyle = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 0px 4px 4px;

  flex: none;
  order: 2;
  align-self: stretch;
  flex-grow: 0;
  margin: 12px 0px;
  & .ant-form-item-label {
    text-align: left;
    max-width: 130px;
  }
`;
