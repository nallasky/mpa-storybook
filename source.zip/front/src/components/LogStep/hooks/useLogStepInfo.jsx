import { useState, createContext } from 'react';
import {
  useGetRuleStepResource,
  usePostLogStepSampleLog,
} from '@hooks/query/StepSetting';
import { RequestOnError } from '@libs/util/common/common';
import useRuleSettingInfo from '@hooks/common/useRuleSettingInfo';
import {
  E_LOG_STEP_END,
  E_STEP_LOG_DEFINE_SETTING,
  RESPONSE_OK,
} from '@constants/etc';
import { getArray } from '@libs/util/util';
import { StepConfigure } from '@constants/StepDefault';
import { postRequestJsonData } from '@libs/axios/requests';
import { NotificationBox } from '@components/common/molecules/NotificationBox';

const useLogStepInfo = () => {
  const [loading, setLoading] = useState(false);
  const [stepInfo, setStepInfo] = useState({
    current: 0,
    list: [],
    type: undefined,
  });
  const [data, setData] = useState(null);
  const sampleLogPreview = usePostLogStepSampleLog();
  const { setRuleStepConfig, convertStepInfo, filterStepInfo } =
    useRuleSettingInfo();

  const getRuleStep1Resource = ({ isEdit, log_name, enabled, onSettled }) =>
    useGetRuleStepResource({
      isEdit,
      log_name,
      enabled,
      onSuccess: ({ info }) => {
        console.log(info);
        setRuleStepConfig([{ step: E_STEP_LOG_DEFINE_SETTING, config: info }]);
      },
      onSettled,
      onError: RequestOnError,
    });

  const saveSetting = (navigate) => {
    console.log('saveSetting start');
    const postRequest = async () => {
      const convertTmp = { ...convertStepInfo };
      const filterTmp = [...filterStepInfo];

      const obj = Object.assign(
        {},
        {
          convert: {
            mode: convertStepInfo.mode,
            log_define: convertStepInfo?.log_define,
            info: getArray(convertTmp?.info ?? [], true, false),
            header: getArray(convertTmp?.header ?? [], true, false),
            custom: getArray(convertTmp?.custom ?? [], false, false),
            script: {
              file_name: convertTmp?.script?.file_name ?? null,
              use_script: convertTmp?.script?.use_script ?? false,
            },
          },
          filter: {
            items: getArray(filterTmp, false),
          },
        },
      );
      try {
        const url =
          StepConfigure[E_LOG_STEP_END]?.[stepInfo.rule_id ? 'edit' : 'new'];
        const { status } = await postRequestJsonData(
          url,
          undefined,
          JSON.stringify(obj),
        );
        if (status.toString() === RESPONSE_OK) {
          navigate(-1);
          setLoading(false);
        }
      } catch (e) {
        if (e.response) {
          const {
            data: { msg, err },
          } = e.response;
          console.log(e.response);
          NotificationBox({ title: 'ERROR', message: msg ?? err });
        }
        setLoading(false);
      }
    };
    setLoading(true);
    postRequest().then((_) => _);
  };

  return {
    getRuleStep1Resource,
    stepInfo,
    data,
    setData,
    setStepInfo,
    setLoading,
    loading,
    saveSetting,
    sampleLogPreview,
  };
};

export default useLogStepInfo;

export const LogStepInfo = createContext(null);
