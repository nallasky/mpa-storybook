import { useContext } from 'react';
import {
  E_STEP_FILTER_SETTING,
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_LOG_DEFINE_SETTING,
} from '@constants/etc';
import LogDefineStep from '@components/LogStep/LogDefineStep';
import Step3_Setting from '@components/JobStep/Step3_Setting';
import Step4_Setting from '@components/JobStep/Step4_Setting';
import useRuleSettingInfo from '@hooks/common/useRuleSettingInfo';
import useStepSettingInfo from '@hooks/common/useStepSettingInfo';
import { LogStepInfo } from '@components/LogStep/hooks/useLogStepInfo';
import { CommonRegex } from '@libs/util/regExp';

const useLogStepContent = () => {
  const { stepInfo, data, setData, setLoading, setStepInfo } =
    useContext(LogStepInfo);
  const { ruleStepConfig, funcStepInfo, convertStepInfo, filterStepInfo } =
    useRuleSettingInfo();
  const {
    addNextStepConfig,
    addStepPreviewAndNext,
    addCurrentStepPreview,
    updateStepSetting,
  } = useStepSettingInfo();

  const nextButton = async () => {
    console.log('nextButton', stepInfo);
    let result = { next: undefined, info: undefined, preview: undefined };

    switch (stepInfo.current) {
      case E_STEP_LOG_DEFINE_SETTING:
        result = await LogDefineStep.btn_next({
          setLoading,
          rule_id: stepInfo.rule_id,
          log_name: stepInfo.log_name,
          convertStepInfo,
          funcStepInfo,
          data: { data: data, func: setData },
        });
        if (result?.info ?? false) {
          updateStepSetting({ info: result.info.config });
        }
        setLoading(false);
        break;
      case E_STEP_LOG_CONVERT_SETTING:
        result = await Step3_Setting.btn_next({
          setLoading,
          convertStepInfo,
          data: { data: data, func: setData },
          func_id: stepInfo.func_id,
          originLog:
            ruleStepConfig.find((obj) => obj.step === E_STEP_LOG_DEFINE_SETTING)
              ?.data ?? [],
        });
        setLoading(false);
        break;
      case E_STEP_FILTER_SETTING:
        result = await Step4_Setting.btn_next({
          setLoading,
          filterStepInfo,
          data: { data: data, func: setData },
          originLog:
            ruleStepConfig.find(
              (obj) => obj.step === E_STEP_LOG_CONVERT_SETTING,
            )?.data ?? [],
        });
        setLoading(false);
        break;
      default:
        break;
    }
    console.log('result:::::::', result);
    if ((result?.preview ?? false) && (result?.next ?? false)) {
      const { preview } = result;
      const { current, list } = stepInfo;
      const cIdx = list.indexOf(current);
      console.log('preview', preview);

      addStepPreviewAndNext({
        next: result?.next ?? list[cIdx + 1],
        preview: preview,
        info: result?.info ?? {},
      });
      console.log(
        'stepInfo.list.includes(result?.next)',
        stepInfo.list.includes(result?.next),
      );
      setStepInfo((prev) => ({
        ...prev,
        current: list.includes(result?.next) ? result?.next : list[cIdx + 1],
      }));
    } else if (result?.next ?? false) {
      const { current, list } = stepInfo;
      console.log(
        'stepInfo.list.includes(result?.next)',
        list.includes(result?.next),
      );
      const cIdx = list.indexOf(current);
      const nextStep = list.includes(result?.next)
        ? result?.next
        : list[cIdx + 1];
      addNextStepConfig({
        next: nextStep,
        info: result?.info ?? {},
        setCurrent: () =>
          setStepInfo((prev) => ({ ...prev, current: nextStep })),
      });
    } else if (result?.preview ?? false) {
      const { preview } = result;
      console.log('preview', preview);
      addCurrentStepPreview({
        current: preview.current,
        info: preview.info,
      });
    } else {
      console.log('');
    }
  };

  const nextStepValid = () => {
    let ret = true;
    switch (stepInfo.current) {
      case E_STEP_LOG_DEFINE_SETTING:
        ret = CommonRegex.test(convertStepInfo?.log_define?.log_name ?? '');
        break;
      case E_STEP_LOG_CONVERT_SETTING:
        ret = Step3_Setting.check_next(convertStepInfo);
        break;
      case E_STEP_FILTER_SETTING:
        ret = Step4_Setting.check_next(filterStepInfo);
        break;
      default:
        break;
    }
    console.log('ret', ret);
    return ret;
  };
  const onChange = (e) => {
    console.log('[jobStep ]', e);
    setData((prev) => {
      return { ...prev, ...e };
    });
  };

  const PreviousOnClick = () => {
    let result = { status: '', step: 0 };
    console.log('steps[current].Previous');
    if (result.status === 'pass') {
      setStepInfo((prev) => ({ ...prev, current: result.step }));
    } else {
      const { current, list } = stepInfo;
      const cIdx = list.indexOf(current);
      if (cIdx > 0) {
        setStepInfo((prev) => ({ ...prev, current: list[cIdx - 1] }));
      }
    }
  };

  return {
    PreviousOnClick,
    onChange,
    nextStepValid,
    nextButton,
  };
};
export default useLogStepContent;
