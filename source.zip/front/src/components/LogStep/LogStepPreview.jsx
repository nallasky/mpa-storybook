import { useContext } from 'react';
import { JobStep as Message } from '@assets/locale/en';
import { Button } from 'antd';
import Divider from '@components/common/atoms/Divider';
import * as PStyle from '@components/JobStep/styles/stepPreviewStyle';
import { ReadFilled } from '@ant-design/icons';
import {
  E_STEP_FILTER_SETTING,
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_LOG_DEFINE_SETTING,
} from '@constants/etc';
import useRuleSettingInfo from '@hooks/common/useRuleSettingInfo';
import Step3_Setting from '@components/JobStep/Step3_Setting';
import Step4_Setting from '@components/JobStep/Step4_Setting';
import { StepConfigure } from '@constants/StepDefault';
import useStepSettingInfo from '@hooks/common/useStepSettingInfo';
import { LogStepInfo } from '@components/LogStep/hooks/useLogStepInfo';
import LogDefineStep from '@components/LogStep/LogDefineStep';

const LogStepPreview = () => {
  const { ruleStepConfig, funcStepInfo, convertStepInfo, filterStepInfo } =
    useRuleSettingInfo();
  const { addCurrentStepPreview } = useStepSettingInfo();

  const { stepInfo, data, setData } = useContext(LogStepInfo);
  const { log_name, rule_id, func_id, current, list } = stepInfo;
  console.log('log_name', log_name, 'rule_id: ', rule_id, ' list:', list);
  const Enable_Preview = () => {
    let ret = true;
    switch (current) {
      case E_STEP_LOG_DEFINE_SETTING:
        ret = !!funcStepInfo?.src_file;
        break;
      case E_STEP_LOG_CONVERT_SETTING:
        ret = Step3_Setting.check_preview(convertStepInfo);
        break;
      case E_STEP_FILTER_SETTING:
        ret = Step4_Setting.check_preview(filterStepInfo);
        break;
      default:
        if (StepConfigure[current].preview === undefined) {
          ret = false;
        }
        break;
    }
    return ret;
  };
  const previewOnClick = () => {
    console.log('steps[current].preview', StepConfigure[current].preview);
    const previewRequest = async () => {
      switch (current) {
        case E_STEP_LOG_DEFINE_SETTING:
          {
            const result = await LogDefineStep.btn_preview({
              rule_id,
              log_name,
              convertStepInfo,
              data,
              setData,
            });
            console.log('preview result', result);
            if (result?.data ?? false) {
              addCurrentStepPreview({
                current: result?.step ?? E_STEP_LOG_DEFINE_SETTING,
                info: result.data,
              });
            }
          }
          break;
        case E_STEP_LOG_CONVERT_SETTING:
          {
            const result = await Step3_Setting.btn_preview({
              data,
              setData,
              convertStepInfo,
              func_id,
              originLog:
                ruleStepConfig.find(
                  (obj) => obj.step === E_STEP_LOG_DEFINE_SETTING,
                )?.data ?? [],
            });
            console.log('preview result', result);
            if (result?.data ?? false) {
              addCurrentStepPreview({
                current: result?.step ?? E_STEP_LOG_CONVERT_SETTING,
                info: result.data,
              });
            }
          }
          break;
        case E_STEP_FILTER_SETTING:
          {
            const result = await Step4_Setting.btn_preview({
              setData,
              filterStepInfo,
              originLog:
                ruleStepConfig.find(
                  (obj) => obj.step === E_STEP_LOG_CONVERT_SETTING,
                )?.data ?? [],
            });
            console.log('preview result', result);
            if (result?.data ?? false) {
              addCurrentStepPreview({
                current: result?.step ?? E_STEP_FILTER_SETTING,
                info: result.data,
              });
            }
          }
          break;
        default:
          break;
      }
    };
    previewRequest().then((_) => _);
  };
  return (
    <div css={PStyle.PreviewFrameStyle}>
      <div css={PStyle.graphFrameStyle}>
        <div
          css={PStyle.PreviewTitleStyle}
          style={{ fontWeight: '500', textTransform: 'uppercase' }}
        >
          {Message.button.preview}
          <Button
            type="dashed"
            icon={<ReadFilled />}
            disabled={Enable_Preview() === false}
            onClick={previewOnClick}
          >
            {Message.button.preview}
          </Button>
        </div>
        <Divider height={'1'} type={'solid'} style={{ marginBottom: '0' }} />
        <div css={PStyle.ContentsFrameStyle}>
          {current === E_STEP_LOG_DEFINE_SETTING ? (
            <LogDefineStep.view_preview data={data} />
          ) : current === E_STEP_LOG_CONVERT_SETTING ? (
            <Step3_Setting.view_preview data={data} />
          ) : current === E_STEP_FILTER_SETTING ? (
            <Step4_Setting.view_preview data={data} />
          ) : (
            <div />
          )}
        </div>
      </div>
    </div>
  );
};

export default LogStepPreview;
