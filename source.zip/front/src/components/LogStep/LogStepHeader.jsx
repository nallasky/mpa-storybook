import { Fragment, useContext } from 'react';
import Divider from '@components/common/atoms/Divider';
import { JobStep as Message } from '@assets/locale/en';
import { Steps } from 'antd';
const { Step } = Steps;

import * as HStyle from './styles/stepHeaderStyle';
import { StepConfigure } from '@constants/StepDefault';
import { LogStepInfo } from '@components/LogStep/hooks/useLogStepInfo';

const LogStepHeader = () => {
  const { stepInfo } = useContext(LogStepInfo);
  const { current, list } = stepInfo;

  console.log('current', current, ' list:', list);

  return (
    <Fragment>
      <Divider style={HStyle.dividerStyle} />
      <div css={HStyle.StepFrameStyle}>
        <Steps current={list.indexOf(current)} css={{ marginTop: '10px' }}>
          {list.map((item, idx) => {
            return (
              <Step
                key={`STEP_${idx + 1}`}
                title={
                  current === item
                    ? Message.status.progress
                    : current > item
                    ? Message.status.finished
                    : Message.status.waiting
                }
                description={StepConfigure[item].description}
              />
            );
          })}
        </Steps>
      </div>
      <Divider style={HStyle.dividerStyle} />
    </Fragment>
  );
};
export default LogStepHeader;
