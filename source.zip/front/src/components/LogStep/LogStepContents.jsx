import { Fragment, useContext } from 'react';
import { LeftCircleFilled, RightCircleFilled } from '@ant-design/icons';
import { JobStep as Message } from '@assets/locale/en';
import { StepConfigure } from '@constants/StepDefault';
import * as CStyle from './styles/stepContentStyle';
import { Button } from 'antd';
import { LogStepInfo } from '@components/LogStep/hooks/useLogStepInfo';
import useLogStepContent from '@components/LogStep/hooks/useLogStepContent';
import {
  E_STEP_FILTER_SETTING,
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_LOG_DEFINE_SETTING,
} from '@constants/etc';
import Step3_Setting from '@components/JobStep/Step3_Setting';
import Step4_Setting from '@components/JobStep/Step4_Setting';
import LogDefineStep from '@components/LogStep/LogDefineStep';
const LogStepContents = () => {
  const { stepInfo, loading, data } = useContext(LogStepInfo);
  const { PreviousOnClick, nextButton, nextStepValid, onChange } =
    useLogStepContent();
  return (
    <Fragment>
      <div css={CStyle.TitleFrameStyle}>
        <Button
          type="dashed"
          css={CStyle.directionButton}
          onClick={PreviousOnClick}
          disabled={stepInfo.current === E_STEP_LOG_DEFINE_SETTING}
        >
          <LeftCircleFilled /> {Message.button.previous}
        </Button>
        <div
          css={{
            textAlign: 'center',
            fontSize: '24px',
            lineHeight: '32px',
          }}
        >
          {StepConfigure[stepInfo?.current ?? 0].description}
        </div>
        <Button
          type="dashed"
          css={CStyle.directionButton}
          onClick={nextButton}
          loading={
            loading &&
            stepInfo.current !== stepInfo.list[stepInfo.list.length - 1]
          }
          disabled={
            !nextStepValid() ||
            stepInfo.current === stepInfo.list[stepInfo.list.length - 1]
          }
        >
          {Message.button.next} <RightCircleFilled />
        </Button>
      </div>
      <div css={CStyle.ContentsFrameStyle}>
        <div css={CStyle.ContentsFrameStyle}>
          {stepInfo.current === E_STEP_LOG_DEFINE_SETTING ? (
            <LogDefineStep.view_contents data={data} onChange={onChange} />
          ) : stepInfo.current === E_STEP_LOG_CONVERT_SETTING ? (
            <Step3_Setting.view_contents data={data} onChange={onChange} />
          ) : stepInfo.current === E_STEP_FILTER_SETTING ? (
            <Step4_Setting.view_contents data={data} />
          ) : (
            <div>{''}</div>
          )}
        </div>
      </div>
    </Fragment>
  );
};
export default LogStepContents;
