export { default } from './NaviBar';
