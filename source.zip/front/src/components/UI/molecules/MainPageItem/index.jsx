export { default } from './MainPageItem';
