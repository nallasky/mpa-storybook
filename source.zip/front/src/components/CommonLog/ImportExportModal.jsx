import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Common } from '@assets/locale/en';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import { Segmented, TreeSelect, Spin } from 'antd';
import { CloudDownloadOutlined, CloudUploadOutlined } from '@ant-design/icons';
import useCommonLogImportExport from '@components/CommonLog/hooks/useCommonLogImportExport';
import { css } from '@emotion/react';
import { Upload } from '@components/common/atoms/Upload';
import { ModalFooterButton } from '@components/CommonLog/styles/CommonLogStyles';
const { ALL } = TreeSelect;
const ImportStyle = css`
  padding: 1rem 0;

  & > span:last-child {
    & > div:first-child {
      width: 100%;
      & button {
        width: 100%;
        border-radius: 8px;
        border: 1px dashed var(--ckr-gray-7);
        &:hover {
          border: 1px dashed var(--ckr-blue-6);
        }
        &:disabled {
          pointer-events: none;
        }
      }
    }
  }
`;
const ButtonStyle = css`
  display: flex;
  justify-content: flex-end;
`;

const ImportExportModal = ({ onClose, onSave }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [mode, setMode] = useState('import');
  const {
    TreeListUpdate,
    exportProps,
    importFilesProps,
    isExporting,
    isImporting,
    onExportFunc,
    onImportFunc,
    isEnableImport,
    isEnableExport,
  } = useCommonLogImportExport();
  const closeFunc = () => {
    setIsVisible(false);
    onClose();
  };
  const importSaveFunc = () => {
    onSave();
    closeFunc();
  };
  useEffect(() => {
    TreeListUpdate();
  }, []);
  return (
    <DraggableModal
      visible={isVisible}
      footer={null}
      title="Common Log Import/Export "
      cancelHandler={closeFunc}
      maskClosable
      centered
    >
      <Segmented
        block
        size="large"
        onChange={setMode}
        options={[
          {
            label: Common.Btn_Import,
            icon: <CloudUploadOutlined />,
            value: 'import',
          },
          {
            label: Common.Btn_Export,
            icon: <CloudDownloadOutlined />,
            value: 'export',
          },
        ]}
      />
      {mode === 'import' ? (
        <Spin tip={'Function Uploading...'} spinning={isImporting}>
          <div css={ImportStyle}>
            <Upload
              required={true}
              btnMsg={Common.Btn_FileUpload}
              uploadProps={importFilesProps}
              type={'button'}
            />
          </div>
          <div css={ButtonStyle}>
            <ModalFooterButton
              onClick={() => onImportFunc(importSaveFunc)}
              key={'footer_right'}
              disabled={isImporting || !isEnableImport}
            >
              {Common.Btn_Apply}
            </ModalFooterButton>
          </div>
        </Spin>
      ) : (
        <Spin tip={'Function DownLoading...'} spinning={isExporting}>
          <div css={ImportStyle}>
            <TreeSelect {...exportProps} showCheckedStrategy={ALL} />
          </div>
          <div css={ButtonStyle}>
            <ModalFooterButton
              onClick={() => onExportFunc(closeFunc)}
              key={'footer_right'}
              disabled={isExporting || !isEnableExport}
            >
              {Common.Btn_Download}
            </ModalFooterButton>
          </div>
        </Spin>
      )}
    </DraggableModal>
  );
};
ImportExportModal.propTypes = {
  onClose: PropTypes.func.isRequired,
  onSave: PropTypes.func,
};
export default ImportExportModal;
