import { useState } from 'react';
import PropTypes from 'prop-types';
import { ModalFooterButton } from '@components/CommonLog/styles/CommonLogStyles';
import { Common } from '@assets/locale/en';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';

const ImportExportModal = ({ onClose }) => {
  const [isVisible, setIsVisible] = useState(true);
  const closeFunc = () => {
    setIsVisible(false);
    onClose();
  };
  const saveFunc = () => {
    console.log('saveFunc');
  };
  return (
    <DraggableModal
      visible={isVisible}
      title="Common Log Import/Export "
      footer={[
        <ModalFooterButton
          className="white"
          onClick={closeFunc}
          key={'footer_left'}
        >
          {Common.Btn_Cancel}
        </ModalFooterButton>,
        <ModalFooterButton
          key={'footer_right'}
          disabled={false}
          onClick={saveFunc}
        >
          {Common.Btn_Save}
        </ModalFooterButton>,
      ]}
      cancelHandler={closeFunc}
      maskClosable
      centered
    ></DraggableModal>
  );
};
ImportExportModal.propTypes = {
  onClose: PropTypes.func.isRequired,
};
export default ImportExportModal;
