import { useContext } from 'react';
import {
  DatabaseOutlined,
  EditFilled,
  DeleteFilled,
  ConsoleSqlOutlined,
  FileOutlined,
  CopyOutlined,
} from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import {
  E_MULTI_TYPE,
  E_SINGLE_TYPE,
  LOCAL_INFO,
  REMOTE_INFO,
  SQL_INFO,
} from '@constants/etc';
import useModal from '@libs/util/modalControl/useModal';
import { JobSetting } from '../common/organisms/JobSettingModal';
import useCommonLogList from '@components/CommonLog/hooks/useCommonLogList';
import { MSG_MULTI } from '@constants/Message';
import { EDIT } from '@constants/URL';
import { logViewMode } from '@components/CommonLog/hooks/useCommonLog';

const CommonLogItem = ({ obj, onClick }) => {
  const { openModal } = useModal();
  const { deleteLogFunc } = useCommonLogList();
  const { isViewMode } = useContext(logViewMode);
  const navigate = useNavigate();
  const onClickEvent = () => {
    if (onClick !== undefined) {
      onClick();
    } else if (isViewMode) {
      openModal(JobSetting, {
        func_id: obj.func_id,
        source: obj.info.Source,
      });
    }
  };
  const onEditEvent = () => {
    const type = obj.info.Source === MSG_MULTI ? E_MULTI_TYPE : E_SINGLE_TYPE;
    console.log(type);
    navigate(`${EDIT}/${type}/${obj.func_id}`);
  };
  const onDeleteEvent = (e) => {
    e.stopPropagation();
    deleteLogFunc(obj.func_id);
  };
  return (
    <div className="item" onClick={onClickEvent}>
      <div className="icon">
        {obj.info.Source === LOCAL_INFO ? (
          <FileOutlined />
        ) : obj.info.Source === REMOTE_INFO ? (
          <DatabaseOutlined />
        ) : obj.info.Source === SQL_INFO ? (
          <ConsoleSqlOutlined />
        ) : (
          <CopyOutlined />
        )}
      </div>
      <div className="titles-and-buttons">
        <div className="titles">
          <p className="main">{obj.title}</p>
          {obj.info.Source !== E_MULTI_TYPE && (
            <p className="sub">LogName: {obj.info['Log Name']}</p>
          )}
        </div>
        <div className="buttons">
          <button onClick={onEditEvent}>
            <EditFilled />
          </button>
          <button onClick={onDeleteEvent}>
            <DeleteFilled />
          </button>
        </div>
      </div>
    </div>
  );
};

CommonLogItem.propTypes = {
  obj: PropTypes.object.isRequired,
  onClick: PropTypes.func,
};
export default CommonLogItem;
