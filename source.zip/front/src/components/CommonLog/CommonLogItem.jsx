import {
  DatabaseOutlined,
  EditFilled,
  DeleteFilled,
  ConsoleSqlOutlined,
  FileOutlined,
} from '@ant-design/icons';
import PropTypes from 'prop-types';
import { LOCAL_INFO, REMOTE_INFO } from '@constants/etc';
import useModal from '@libs/util/modalControl/useModal';
import { JobSetting } from '../common/organisms/JobSettingModal';

const CommonLogItem = ({ obj }) => {
  const { openModal } = useModal();
  const onClickEvent = () => {
    openModal(JobSetting, {
      func_id: obj.func_id,
      source: obj.info.Source,
    });
  };
  return (
    <div className="item">
      <div className="icon">
        {obj.info.Source === LOCAL_INFO ? (
          <FileOutlined />
        ) : obj.info.Source === REMOTE_INFO ? (
          <DatabaseOutlined />
        ) : (
          <ConsoleSqlOutlined />
        )}
      </div>
      <div className="titles-and-buttons">
        <div className="titles" onClick={onClickEvent}>
          <p className="main">{obj.title}</p>
          <p className="sub">LogName: {obj.info['Log Name']}</p>
        </div>
        <div className="buttons">
          <button>
            <EditFilled />
          </button>
          <button>
            <DeleteFilled />
          </button>
        </div>
      </div>
    </div>
  );
};

CommonLogItem.propTypes = {
  obj: PropTypes.object.isRequired,
};
export default CommonLogItem;
