import React, { useContext } from 'react';
import {
  DatabaseOutlined,
  ConsoleSqlOutlined,
  FileOutlined,
  CopyOutlined,
} from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import {
  E_MULTI_TYPE,
  E_SINGLE_TYPE,
  LOCAL_INFO,
  REMOTE_INFO,
  SQL_INFO,
} from '@constants/etc';
import useModal from '@libs/util/modalControl/useModal';
import { JobSetting } from '../common/organisms/JobSettingModal';
import useCommonLogList from '@components/CommonLog/hooks/useCommonLogList';
import { MSG_MULTI } from '@constants/Message';
import { EDIT } from '@constants/URL';
import { logViewMode } from '@components/CommonLog/hooks/useCommonLog';
import ItemCard from '@components/common/atoms/ItemCard';

const CommonLogItem = ({ obj, onClick }) => {
  const { openModal } = useModal();
  const { deleteLogFunc } = useCommonLogList();
  const { isViewMode } = useContext(logViewMode);
  const navigate = useNavigate();
  const onClickEvent = () => {
    if (onClick !== undefined) {
      onClick();
    } else if (isViewMode) {
      openModal(JobSetting, {
        func_id: obj.func_id,
        source: obj.info.Source,
      });
    }
  };
  const onEditEvent = () => {
    const type = obj.info.Source === MSG_MULTI ? E_MULTI_TYPE : E_SINGLE_TYPE;
    console.log(type);
    navigate(`${EDIT}/${type}/${obj.func_id}`);
  };
  const onDeleteEvent = (e) => {
    e.stopPropagation();
    deleteLogFunc(obj.func_id);
  };

  const selectIcon = () => {
    if (obj.info.Source === LOCAL_INFO) return <FileOutlined />;

    if (obj.info.Source === REMOTE_INFO) return <DatabaseOutlined />;

    if (obj.info.Source === SQL_INFO) return <ConsoleSqlOutlined />;

    return <CopyOutlined />;
  };

  return (
    <ItemCard
      icon={selectIcon()}
      title={obj.title}
      subTitle={
        obj.info.Source !== E_MULTI_TYPE ? obj.info['Log Name'] : undefined
      }
      onContent={onClickEvent}
      onEdit={onEditEvent}
      onDelete={onDeleteEvent}
      viewMode={isViewMode}
    />
  );
};

CommonLogItem.propTypes = {
  obj: PropTypes.object.isRequired,
  onClick: PropTypes.func,
};
export default CommonLogItem;
