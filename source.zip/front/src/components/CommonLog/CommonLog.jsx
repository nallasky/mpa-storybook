import { useState } from 'react';
import { CommonLogWrapper } from '@components/CommonLog/styles/CommonLogStyles';
import CommonLogHeader from '@components/CommonLog/CommonLogHeader';
import { logViewMode } from '@components/CommonLog/hooks/useCommonLog';
import CommonLogContent from '@components/CommonLog/CommonLogContent';

const CommonLog = () => {
  const [isViewMode, setViewMode] = useState(true);

  return (
    <logViewMode.Provider value={{ isViewMode, setViewMode }}>
      <CommonLogWrapper className={isViewMode ? 'view-mode' : ''}>
        <CommonLogHeader />
        <CommonLogContent />
      </CommonLogWrapper>
    </logViewMode.Provider>
  );
};

export default CommonLog;
