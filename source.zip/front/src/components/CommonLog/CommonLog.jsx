import { useState } from 'react';
import { CommonLogWrapper } from '@components/CommonLog/styles/CommonLogStyles';
import CommonLogHeader from '@components/CommonLog/CommonLogHeader';
import {
  commonLogInfo,
  useCommonLog,
} from '@components/CommonLog/hooks/useCommonLog';
import CommonLogContent from '@components/CommonLog/CommonLogContent';

const CommonLog = () => {
  const [isViewMode, setViewMode] = useState(true);
  const [reLoad, setReLoad] = useState(true);
  const { getCommonLogResource } = useCommonLog();
  const { isLoading, error, isFetching } = getCommonLogResource({
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });

  return (
    <commonLogInfo.Provider
      value={{
        isViewMode,
        setViewMode,
        reLoad,
        setReLoad,
        isLoading,
        error,
        isFetching,
      }}
    >
      <CommonLogWrapper className={isViewMode ? 'view-mode' : ''}>
        <CommonLogHeader />
        <CommonLogContent />
      </CommonLogWrapper>
    </commonLogInfo.Provider>
  );
};

export default CommonLog;
