import { useState } from 'react';
import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import { ModalFooterButton } from '@components/CommonLog/styles/CommonLogStyles';
import { Common, Log as message } from '@assets/locale/en';
import PropTypes from 'prop-types';
import { E_MULTI_TYPE, E_SINGLE_TYPE } from '@constants/etc';
import { Space, Radio, Card, Tag, Select } from 'antd';
import { useCommonLog } from '@components/CommonLog/hooks/useCommonLog';
import { NEW } from '@constants/URL';

const FunctionModal = ({ onClose, onApply }) => {
  const [info, setInfo] = useState({
    isVisible: true,
    type: undefined,
    category: undefined,
  });
  const closeFunc = () => {
    setInfo({
      isVisible: false,
      type: undefined,
      category: undefined,
    });
    onClose();
  };
  const applyFunc = () => {
    console.log('url: ', `${NEW}/${info.type}/${info.category}`);
    onApply(info.type, info.category);
    onClose();
  };
  const { gCategories } = useCommonLog();
  return (
    <DraggableModal
      visible={info.isVisible}
      title="New Analysis Function"
      footer={[
        <ModalFooterButton
          className="white"
          onClick={closeFunc}
          key={'footer_left'}
        >
          {Common.Btn_Cancel}
        </ModalFooterButton>,
        <ModalFooterButton
          key={'footer_right'}
          onClick={applyFunc}
          disabled={info.type === undefined || info.category === undefined}
        >
          {Common.Btn_Save}
        </ModalFooterButton>,
      ]}
      cancelHandler={closeFunc}
      maskClosable
      centered
    >
      <Space direction="vertical" size="middle" style={{ display: 'flex' }}>
        <Card
          type="inner"
          title={message.analysis.modal.setting1.title}
          size="small"
          extra={
            info.type === undefined ? (
              <Tag>{message.analysis.modal.status.ing}</Tag>
            ) : (
              <Tag color="success">
                {message.analysis.modal.status.completed}
              </Tag>
            )
          }
        >
          <Radio.Group
            onChange={({ target: { value } }) =>
              setInfo((prevState) => ({
                ...prevState,
                type: value,
              }))
            }
            value={info.type}
          >
            <Space direction="horizontal">
              <Radio value={E_SINGLE_TYPE}>
                {message.analysis.modal.setting1.single}
              </Radio>
              <Radio value={E_MULTI_TYPE}>
                {message.analysis.modal.setting1.multi}
              </Radio>{' '}
            </Space>
          </Radio.Group>
        </Card>
        <Card
          type="inner"
          title={message.analysis.modal.setting2.title}
          size="small"
          extra={
            info.category === undefined ? (
              <Tag>{message.analysis.modal.status.ing}</Tag>
            ) : (
              <Tag color="success">
                {message.analysis.modal.status.completed}
              </Tag>
            )
          }
        >
          <Select
            showSearch
            style={{ width: '270px' }}
            value={info.category}
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.children.toLowerCase().includes(input)
            }
            onChange={(v) =>
              setInfo((prevState) => ({
                ...prevState,
                category: v,
              }))
            }
          >
            {gCategories.map((name, i) => (
              <Select.Option value={name.category_id} key={i}>
                {name.title}
              </Select.Option>
            ))}
          </Select>
        </Card>
      </Space>
    </DraggableModal>
  );
};

FunctionModal.propTypes = {
  onClose: PropTypes.func.isRequired,
  onApply: PropTypes.func,
};
export default FunctionModal;
