import styled from '@emotion/styled';

export const mixinLists = {
  buttonDefault: () => `
    padding: 0.5rem 1rem;
    border-radius: 8px;
    border: 1px solid transparent;
    color: var(--ckr-gray-1);
    background-color: var(--ckr-blue-7);
    cursor: pointer;
    outline: none;
    &.light-blue {
      color: #1967d2;
      background-color: var(--ckr-geekblue-2);
    }
    &.white {
      color: black;
      background-color: var(--ckr-gray-1);
      border-color: var(--ckr-gray-5);
    }
    &.small {
      padding: 0.25rem 0.5rem;
      font-size: 12px;
    }
    &:disabled {
      color: var(--ckr-gray-5);
      background-color: var(--ckr-gray-3);
      border: 1px solid var(--ckr-gray-5);
    }
  `,
  buttonDashSquare: () => `
    padding: 0.25rem 0.5rem;
    background-color: var(--ckr-gray-1);
    border-radius: 2px;
    border: 1px dashed var(--ckr-gray-5);
    cursor: pointer;
    transition: all 0.2s;
    outline: none;
    & + button {
      margin-left: 0.2rem;
    }
    &:disabled {
      color: var(--ckr-gray-5);
      background-color: var(--ckr-gray-3);
    }
    &:hover:not(:disabled) {
      color: var(--ckr-blue-7);
      border-color: var(--ckr-blue-7);
    }
  `,
  buttonDashRound: () => `
    padding: 0rem 0.7rem;
    border-radius: 19px;
    border: 1px dashed var(--ckr-gray-5);
    font-size: 16px;
    cursor: pointer;
    transition: all 0.2s;
    filter: drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25));
    outline: none;
    &:hover:not(:disabled) {
      color: var(--ckr-blue-6);
      border-color: var(--ckr-blue-6);
    }
  `,
  textInput: ({ size = '16px' }) => `
    font-size: ${size};
    outline: none;
    padding: 0.25rem 1rem;
    border-radius: 2px;
    border: 1px solid var(--ckr-gray-5);
    &:hover:not(:read-only),
    &:active:not(:read-only) {
      border-color: var(--ckr-blue-6);
    }
  `,
  flex: ({ direction = 'row', align = 'center', justify = 'center' }) => `
    display: flex;
    flex-direction: ${direction};
    align-items: ${align};
    justify-content: ${justify};
  `,
  radio: () => `
    @keyframes bling {
      50% {
        opacity: 0.15;
        transform: translate(-50%, -50%) scale(2.8);
      }
      100% {
        opacity: 0;
      }
    }
    position: relative;
    z-index: 1;
    text-indent: 20px;
    cursor: pointer;
    & > input[type=radio] {
      display: none;
      &:checked {
        & + .button {
          border-color: var(--ckr-blue-6);
          &::before {
            animation: bling 0.5s linear;
          }
          &::after {
            transform: translate(-50%, -50%) scale(1);
          }
        }
      }
    }
    & > .button {
      position: absolute;
      content: '';
      width: 16px;
      height: 16px;
      top: 3px;
      left: 0;
      border: 1px solid var(--ckr-gray-5);
      border-radius: 50%;
      background-color: var(--ckr-gray-1);
      transition: all 0.25s;
      &::before {
        position: absolute;
        transition: all 0.25s;
        content: '';
        top: 50%;
        left: 50%;
        width: 8px;
        height: 8px;
        background-color: var(--ckr-blue-6);
        border-radius: 50%;
        transform: translate(-50%, -50%);
        z-index: -1;
      }
      &::after {
        position: absolute;
        transition: all 0.2s;
        content: '';
        top: 50%;
        left: 50%;
        width: 8px;
        height: 8px;
        background-color: var(--ckr-blue-6);
        border-radius: 50%;
        transform: translate(-50%, -50%) scale(0);
      }
    }
  `,
};

export const CommonLogWrapper = styled.div`
  position: relative;
  width: 1440px;
  margin: 2rem 0;
  ${mixinLists.flex({
    direction: 'column',
    justify: 'center',
    align: 'initial',
  })}
  &.view-mode {
    & > .header {
      & > .wrapper {
        & > .buttons {
          justify-content: right;
          & > .left {
            display: none;
          }
        }
      }
    }
    & > .content {
      & > .category-list {
        & > .category {
          & > .title {
            & > input[type='text'] {
              pointer-events: none;
              cursor: initial;
              border-color: transparent;
              background-color: transparent;
            }
            & > button {
              display: none;
            }
          }
          & > .items {
            & > .item {
              & > .titles-and-buttons {
                & > .titles {
                  width: 100%;
                  max-width: 307px;
                }
                & > .buttons {
                  display: none;
                }
              }
            }
          }
        }
      }
    }
  }
  & > .header {
    padding-bottom: 1rem;
    border-bottom: 1px solid #ecedf2;
    & > .wrapper {
      & > h1 {
        font-size: 30px;
        margin-bottom: 0.5rem;
      }
      & > p {
        color: #696969;
        margin-bottom: 2rem;
      }
      & > .buttons {
        ${mixinLists.flex({ justify: 'space-between' })}
        & button {
          ${mixinLists.buttonDefault()}
          & + button {
            margin-left: 0.5rem;
          }
          & > span {
            margin-right: 0.5rem;
          }
        }
        & > .left {
          & > .popup-wrapper {
            position: relative;
            display: inline-block;
            margin-left: 0.5rem;
            z-index: 1;
            & > .log-rule-popup {
              &.view {
                display: block;
              }
              & > div + div {
                margin-top: 1rem;
              }
              position: absolute;
              display: none;
              top: 50px;
              left: 0;
              width: 350px;
              border-radius: 2px;
              padding: 1rem;
              background-color: var(--ckr-gray-1);
              &::before {
                position: absolute;
                background-color: var(--ckr-gray-1);
                top: -5px;
                left: 50px;
                content: '';
                width: 10px;
                height: 10px;
                transform: rotate(45deg);
                z-index: -1;
              }
              & > .header {
                & > span {
                  color: var(--ckr-gold-6);
                  margin-right: 0.5rem;
                }
              }
              & > .content {
                ${mixinLists.flex({ justify: 'space-between' })}
              }
              & > .footer {
                text-align: right;
              }
            }
          }
        }
      }
    }
  }
  & > .content {
    padding: 1rem;
    & > .category-list {
      ${mixinLists.flex({ direction: 'column', align: 'initial' })}
      row-gap: 2rem;
      & > .category {
        & > .title {
          ${mixinLists.flex({ justify: 'initial', align: 'initial' })}
          column-gap: 1rem;
          margin-bottom: 1rem;
          & > input[type='text'] {
            font-size: 20px;
            border: 1px solid transparent;
            background-color: transparent;
            &:hover:not(:read-only),
            &:active:not(:read-only) {
              outline: none;
              border-radius: 2px;
              border: 1px solid var(--ckr-gray-5);
              border-color: var(--ckr-blue-6);
              background-color: var(--ckr-white-5);
            }
          }
          & > button {
            ${mixinLists.buttonDashRound()}
          }
        }
        & > .items {
          ${mixinLists.flex({ justify: 'initial' })}
          gap: 1rem;
          width: 100%;
          flex-wrap: wrap;
          & > .item {
            ${mixinLists.flex({ justify: 'initial' })}
            column-gap: 1rem;
            padding: 1rem;
            background-color: var(--ckr-gray-1);
            flex-basis: 32%;
            border-radius: 4px;
            & > .icon {
              color: var(--ckr-blue-8);
              padding: 0.5rem 1rem;
              background-color: #ecedf2;
              border-radius: 4px;
              font-size: 32px;
            }
            & > .titles-and-buttons {
              ${mixinLists.flex({ justify: 'space-between' })}
              column-gap: 1rem;
              width: 100%;
              & > .titles {
                width: 200px;
                & > p {
                  pointer-events: none;
                  margin-bottom: 0;
                  overflow: hidden;
                  white-space: nowrap;
                  text-overflow: ellipsis;
                  &.main {
                    color: #202124;
                    font-size: 15px;
                  }
                  &.sub {
                    color: #696969;
                    font-size: 12px;
                  }
                }
              }
              & > .buttons {
                & > button {
                  ${mixinLists.buttonDashSquare()};
                }
              }
            }
          }
        }
      }
    }
  }
`;

export const ModalFooterButton = styled.button`
  ${mixinLists.buttonDefault()}
  & + button {
    margin-left: 0.5rem;
  }
`;

export const ModalInputWrapper = styled.div`
  width: 100%;
  ${mixinLists.flex({ justify: 'space-between', align: 'initial' })}
  column-gap: 1rem;
  & > label {
    position: relative;
    flex: 0 0 10%;
    max-width: 10%;
    line-height: 2.5;
    &::after {
      position: absolute;
      content: ':';
      top: 0;
      right: 0;
      width: 8px;
    }
  }
  & > .input-wrapper {
    position: relative;
    flex: 0 0 400px;
    max-width: 400px;
    &.error {
      & > input[type='text'] {
        border-color: var(--ckr-red-5);
        &:hover,
        &:active {
          border-color: var(--ckr-red-5) !important;
        }
      }
      & > p {
        display: block;
      }
      & > .error-icon {
        display: block;
      }
    }
    & > input[type='text'] {
      ${mixinLists.textInput({})}
      width: 100%;
    }
    & > p {
      display: none;
      color: var(--ckr-red-5);
      margin-top: 0.25rem;
      margin-bottom: 0;
    }
    & > .error-icon {
      position: absolute;
      display: none;
      top: 8px;
      right: 8px;
      color: var(--ckr-red-5);
    }
  }
`;
