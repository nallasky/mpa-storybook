import { useContext } from 'react';
import { Skeleton } from 'antd';
import CategoryItem from '@components/CommonLog/CategoryItem';
import {
  commonLogInfo,
  useCommonLog,
} from '@components/CommonLog/hooks/useCommonLog';

const CommonLogContent = () => {
  const { isLoading, error, isFetching } = useContext(commonLogInfo);
  const { gLogLists, gCategories } = useCommonLog();

  return (
    <div className="content">
      {error ?? false ? (
        <div className="remote-setting">
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <Skeleton
          loading={isLoading || isFetching}
          active
          paragraph={{ rows: 5 }}
        >
          <div className="category-list">
            {gCategories.map((category, idx) => {
              const items = gLogLists.filter(
                (log) => log.category_id === category.category_id,
              );
              return (
                <CategoryItem category={category} logList={items} key={idx} />
              );
            })}
          </div>
        </Skeleton>
      )}
    </div>
  );
};

export default CommonLogContent;
