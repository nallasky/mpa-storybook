import { useState } from 'react';
import { Skeleton } from 'antd';
import CategoryItem from '@components/CommonLog/CategoryItem';
import { useCommonLog } from '@components/CommonLog/hooks/useCommonLog';

const CommonLogContent = () => {
  const { gLogLists, gCategories, getCommonLogResource } = useCommonLog();
  const [reLoad, setReLoad] = useState(true);
  const { isLoading, error, isFetching } = getCommonLogResource({
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });

  return (
    <div className="content">
      {error ?? false ? (
        <div className="remote-setting">
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <Skeleton
          loading={isLoading || isFetching}
          active
          paragraph={{ rows: 5 }}
        >
          <div className="category-list">
            {gCategories.map((category, idx) => {
              const items = gLogLists.filter(
                (log) => log.category_id === category.category_id,
              );
              return (
                <CategoryItem category={category} logList={items} key={idx} />
              );
            })}
          </div>
        </Skeleton>
      )}
    </div>
  );
};

export default CommonLogContent;
