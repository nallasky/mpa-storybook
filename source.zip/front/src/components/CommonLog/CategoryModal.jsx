import { useState } from 'react';
import PropTypes from 'prop-types';

import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import { ModalFooterButton } from '@components/CommonLog/styles/CommonLogStyles';
import InputForm from '@components/common/atoms/Input/InputForm';
import { useCommonLog } from '@components/CommonLog/hooks/useCommonLog';
import { Common } from '@assets/locale/en';
import { getParseData } from '@libs/util/util';

const CategoryModal = ({ onClose }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [name, setName] = useState(undefined);
  const { categoriesName, addCategory } = useCommonLog();

  const closeFunc = () => {
    setIsVisible(false);
    onClose();
  };
  const saveFunc = () => {
    addCategory(name);
    setIsVisible(false);
    onClose();
  };
  const nameDuplicateCheck = (v) => {
    return !categoriesName.includes(v)
      ? Promise.resolve()
      : Promise.reject(new Error(`${v} is duplicated.`));
  };
  const onChangeFunc = (v) => {
    setName(getParseData(v).value);
  };

  return (
    <DraggableModal
      visible={isVisible}
      title="New Category"
      footer={[
        <ModalFooterButton
          className="white"
          onClick={closeFunc}
          key={'footer_left'}
        >
          {Common.Btn_Cancel}
        </ModalFooterButton>,
        <ModalFooterButton
          key={'footer_right'}
          disabled={
            (name ?? '').length === 0 || categoriesName.includes(name ?? '')
          }
          onClick={saveFunc}
        >
          {Common.Btn_Save}
        </ModalFooterButton>,
      ]}
      cancelHandler={closeFunc}
      maskClosable
      centered
    >
      <InputForm.input
        formStyle={{ labelCol: { span: 5 }, wrapperCol: { span: 35 } }}
        formName={'name'}
        formLabel={'Name'}
        changeFunc={onChangeFunc}
        required={true}
        value={name ?? ''}
        checkFunc={nameDuplicateCheck}
      />
    </DraggableModal>
  );
};

CategoryModal.propTypes = {
  onClose: PropTypes.func.isRequired,
};
export default CategoryModal;
