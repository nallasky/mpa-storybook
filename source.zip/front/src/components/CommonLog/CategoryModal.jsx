import { useState } from 'react';
import PropTypes from 'prop-types';

import DraggableModal from '@components/common/organisms/DraggableModal/DraggableModal';
import { ModalFooterButton } from '@components/CommonLog/styles/CommonLogStyles';
import InputForm from '@components/common/atoms/Input/InputForm';
import { useCommonLog } from '@components/CommonLog/hooks/useCommonLog';
import { Common } from '@assets/locale/en';
import { getParseData } from '@libs/util/util';
import { AllMax30Validator } from '@constants/StepDefault';

const CategoryModal = ({ onClose, onSave }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [name, setName] = useState(undefined);
  const { categoriesName, addCategory, isAddLoading } = useCommonLog();
  const [current, setCurrent] = useState({ status: '', errMsg: undefined });

  const closeFunc = () => {
    setIsVisible(false);
    onClose();
  };
  const saveFunc = () => {
    addCategory(name, () => {
      onSave();
      closeFunc();
    });
  };
  const nameDuplicateCheck = (v) => {
    const isValid = AllMax30Validator(v);
    const duplicated = categoriesName.includes(v.toLowerCase());
    if (isValid.status === 'error' || duplicated) {
      setCurrent({
        status: 'error',
        errMsg: isValid?.errMsg ?? `${v} is duplicated.`,
      });
      return Promise.reject(
        new Error(isValid?.errMsg ?? `${v} is duplicated.`),
      );
    }
    setCurrent({ status: '', errMsg: undefined });
    return Promise.resolve();
  };
  const onChangeFunc = (v) => {
    setName(getParseData(v).value);
  };

  return (
    <DraggableModal
      visible={isVisible}
      title="New Category"
      footer={[
        <ModalFooterButton
          className="white"
          onClick={closeFunc}
          key={'footer_left'}
        >
          {Common.Btn_Cancel}
        </ModalFooterButton>,
        <ModalFooterButton
          key={'footer_right'}
          disabled={(name ?? '').length === 0 || current.status === 'error'}
          loading={isAddLoading}
          onClick={saveFunc}
        >
          {Common.Btn_Save}
        </ModalFooterButton>,
      ]}
      cancelHandler={closeFunc}
      maskClosable
      centered
    >
      <InputForm.input
        formStyle={{ labelCol: { span: 5 }, wrapperCol: { span: 35 } }}
        formName={'name'}
        formLabel={'Name'}
        changeFunc={onChangeFunc}
        value={name ?? ''}
        checkFunc={nameDuplicateCheck}
      />
    </DraggableModal>
  );
};

CategoryModal.propTypes = {
  onClose: PropTypes.func.isRequired,
  onSave: PropTypes.func,
};
export default CategoryModal;
