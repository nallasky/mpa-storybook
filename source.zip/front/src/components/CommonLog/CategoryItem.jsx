import { useState, useEffect } from 'react';
import { DeleteFilled, LoadingOutlined } from '@ant-design/icons';
import { Popconfirm, Spin } from 'antd';
import { Log as message } from '@assets/locale/en';
import CommonLogItem from '@components/CommonLog/CommonLogItem';
import PropTypes from 'prop-types';
import { useCommonLog } from '@components/CommonLog/hooks/useCommonLog';

const CategoryItem = ({ category, logList }) => {
  const [categoryName, setCategoryName] = useState({
    title: category.title,
    status: 'normal',
  });

  const { deleteCategory, updateCategory, Loading, uCategory, gCategories } =
    useCommonLog();

  const onSave = () => {
    if (
      categoryName.status !== 'error' &&
      category.title !== categoryName.title
    ) {
      updateCategory({ ...category, title: categoryName.title });
    } else if (categoryName.status === 'error') {
      setCategoryName({ title: category.title, status: 'normal' });
    }
  };
  const onChange = ({ target: { value } }) => {
    const list = gCategories
      .filter((v) => v.category_id !== category.category_id)
      .map((o) => o.title.toLowerCase());
    const status = !list.includes(value.toLowerCase()) ? 'normal' : 'error';
    setCategoryName({ status: status, title: value });
  };

  useEffect(() => {
    setCategoryName({
      title: category.title,
      status: 'normal',
    });
  }, [category]);
  return (
    <div className="category">
      <div className="title">
        <input
          type="text"
          tabIndex="-1"
          value={categoryName.title}
          onChange={onChange}
          onBlur={onSave}
        />
        <Popconfirm
          title={message.category.delete.title}
          onConfirm={(e) => {
            e.stopPropagation();
            deleteCategory(category);
          }}
        >
          {Loading &&
          (uCategory.delete === category.category_id ||
            uCategory.update === category.category_id) ? (
            <Spin
              indicator={<LoadingOutlined style={{ fontSize: 24 }} spin />}
            />
          ) : (
            <button>
              <DeleteFilled />
            </button>
          )}
        </Popconfirm>
      </div>
      <div className="items">
        {logList.map((logName, j) => (
          <CommonLogItem obj={logName} key={j} />
        ))}
      </div>
    </div>
  );
};
CategoryItem.propTypes = {
  category: PropTypes.object.isRequired,
  logList: PropTypes.array.isRequired,
};
export default CategoryItem;
