import { useState, useEffect } from 'react';
import { DeleteFilled, LoadingOutlined } from '@ant-design/icons';
import { Popconfirm, Spin, Tooltip } from 'antd';
import { Log as message } from '@assets/locale/en';
import CommonLogItem from '@components/CommonLog/CommonLogItem';
import PropTypes from 'prop-types';
import { useCommonLog } from '@components/CommonLog/hooks/useCommonLog';
import { AllMax30Validator } from '@constants/StepDefault';

const CategoryItem = ({ category, logList }) => {
  const [open, setOpen] = useState(false);
  const [categoryName, setCategoryName] = useState({
    title: category.title,
    status: '',
    errMsg: undefined,
  });
  const { deleteCategory, updateCategory, Loading, uCategory, categoriesName } =
    useCommonLog();

  const onSave = () => {
    if (
      categoryName.status !== 'error' &&
      category.title !== categoryName.title
    ) {
      updateCategory({ ...category, title: categoryName.title });
    } else if (categoryName.status === 'error') {
      setCategoryName({ title: category.title, status: '', errMsg: undefined });
    }
  };
  const onChange = ({ target: { value } }) => {
    const list = categoriesName.filter(
      (v) => v !== category.title.toLowerCase(),
    );
    const duplicated = list.includes(value.toLowerCase());
    setCategoryName({ status: status, title: value });
    const error = AllMax30Validator(value);
    if (error.status === 'error') {
      setCategoryName((prevState) => ({ ...prevState, ...error }));
    } else if (duplicated) {
      setCategoryName((prevState) => ({
        ...prevState,
        status: 'error',
        errMsg: `[${value}] is duplicated`,
      }));
    } else {
      setCategoryName((prevState) => ({
        ...prevState,
        status: '',
        errMsg: undefined,
      }));
    }
  };

  useEffect(() => {
    setCategoryName((prevState) => ({
      ...prevState,
      title: category.title,
    }));
  }, [category]);

  return (
    <div className="category">
      <div className={'title' + ` ${categoryName.status}`}>
        <Tooltip
          overlayClassName={categoryName.status}
          title={categoryName.errMsg}
          visible={!!categoryName.errMsg}
          trigger="hover"
          color={'var(--ckr-red-5)'}
        >
          <input
            type="text"
            tabIndex="-1"
            value={categoryName.title}
            onChange={onChange}
            onBlur={onSave}
            disabled={!category.editable}
          />
        </Tooltip>
        <span className="sub-title">Items: {logList.length}</span>
        <Popconfirm
          title={message.category.delete.title}
          onConfirm={(e) => {
            e.stopPropagation();
            deleteCategory(category.category_id);
          }}
        >
          {Loading &&
          (uCategory.delete === category.category_id ||
            uCategory.update === category.category_id) ? (
            <Spin
              indicator={<LoadingOutlined style={{ fontSize: 24 }} spin />}
            />
          ) : (
            category?.editable && (
              <button>
                <DeleteFilled />
              </button>
            )
          )}
        </Popconfirm>
      </div>
      <div className="items">
        {logList
          .filter((_, i) => (open ? true : i < 3))
          .map((logName, j) => (
            <CommonLogItem obj={logName} key={j} />
          ))}
      </div>
      {logList.length > 3 && (
        <div className="view-box">
          <button className="view-button" onClick={() => setOpen(!open)}>
            {open ? 'Close' : 'VIEW ALL'}
          </button>
        </div>
      )}
    </div>
  );
};
CategoryItem.propTypes = {
  category: PropTypes.object.isRequired,
  logList: PropTypes.array.isRequired,
};
export default CategoryItem;
