import { useState, useEffect } from 'react';
import { DeleteFilled, LoadingOutlined } from '@ant-design/icons';
import { Popconfirm, Spin } from 'antd';
import { Log as message } from '@assets/locale/en';
import CommonLogItem from '@components/CommonLog/CommonLogItem';
import PropTypes from 'prop-types';
import { useCommonLog } from '@components/CommonLog/hooks/useCommonLog';

const CategoryItem = ({ category, logList }) => {
  const [open, setOpen] = useState(false);
  const [categoryName, setCategoryName] = useState({
    title: category.title,
    status: 'normal',
  });

  const { deleteCategory, updateCategory, Loading, uCategory, categoriesName } =
    useCommonLog();

  const onSave = () => {
    if (
      categoryName.status !== 'error' &&
      category.title !== categoryName.title
    ) {
      updateCategory({ ...category, title: categoryName.title });
    } else if (categoryName.status === 'error') {
      setCategoryName({ title: category.title, status: 'normal' });
    }
  };
  const onChange = ({ target: { value } }) => {
    const list = categoriesName.filter(
      (v) => v !== category.title.toLowerCase(),
    );
    const status = !list.includes(value.toLowerCase()) ? 'normal' : 'error';
    setCategoryName({ status: status, title: value });
  };

  useEffect(() => {
    setCategoryName({
      title: category.title,
      status: 'normal',
    });
  }, [category]);

  return (
    <div className="category">
      <div
        className={'title' + (categoryName.status === 'error' ? ' error' : '')}
      >
        <input
          type="text"
          tabIndex="-1"
          value={categoryName.title}
          onChange={onChange}
          onBlur={onSave}
        />
        <span className="sub-title">Category Items.</span>
        <Popconfirm
          title={message.category.delete.title}
          onConfirm={(e) => {
            e.stopPropagation();
            deleteCategory(category.category_id);
          }}
        >
          {Loading &&
          (uCategory.delete === category.category_id ||
            uCategory.update === category.category_id) ? (
            <Spin
              indicator={<LoadingOutlined style={{ fontSize: 24 }} spin />}
            />
          ) : (
            <button>
              <DeleteFilled />
            </button>
          )}
        </Popconfirm>
      </div>
      <div className="items">
        {logList
          .filter((_, i) => (open ? true : i < 3))
          .map((logName, j) => (
            <CommonLogItem obj={logName} key={j} />
          ))}
      </div>
      {logList.length > 3 && (
        <div className="view-box">
          <button className="view-button" onClick={() => setOpen(!open)}>
            {open ? 'Close' : 'VIEW ALL'}
          </button>
        </div>
      )}
    </div>
  );
};
CategoryItem.propTypes = {
  category: PropTypes.object.isRequired,
  logList: PropTypes.array.isRequired,
};
export default CategoryItem;
