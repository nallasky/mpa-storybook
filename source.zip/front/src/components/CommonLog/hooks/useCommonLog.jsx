import { createContext, useState } from 'react';
import {
  useGetCommonLogInfo,
  usePostUpdateCategory,
} from '@hooks/query/commonLog';
import { RequestOnError } from '@libs/util/common/common';
import useCommonLogInfo from '@hooks/common/useCommonLogInfo';

export const useCommonLog = () => {
  const [uCategory, setUCategory] = useState({
    update: undefined,
    delete: undefined,
  });
  const { gLogLists, gCategories, setCategories, setAllCommonSetting } =
    useCommonLogInfo();
  const updateCategories = usePostUpdateCategory();
  const categoriesName = gCategories.map((o) => o.title.toLowerCase());

  const getCommonLogResource = ({ enabled, onSettled }) =>
    useGetCommonLogInfo({
      enabled,
      onSuccess: ({ data }) => {
        setAllCommonSetting({
          category: data.map((item) => ({
            category_id: item.category_id,
            title: item.title,
            editable: item.editable,
          })),
          log: data.reduce((acc, obj) => {
            const subList = obj.func.map((sFunc) => ({
              ...sFunc,
              category_id: obj.category_id,
            }));
            acc.push(...subList);
            return acc;
          }, []),
        });
      },
      onSettled,
    });

  const addCategory = (value) => {
    const obj = { category_id: null, title: value };
    updateCategories.mutate(
      {
        categories: [...gCategories, obj],
        type: 'add',
      },
      {
        onSuccess: ({ type, data }) => {
          console.log('type, data', type, data);
          setCategories(
            data.map((item) => ({
              category_id: item.category_id,
              title: item.title,
            })),
          );
          setUCategory((prevState) => ({ ...prevState, [type]: undefined }));
        },
        onError: RequestOnError,
      },
    );
  };
  const deleteCategory = (id) => {
    console.log('deleteCategory', id);
    updateCategories.mutate(
      {
        categories: gCategories.filter((obj) => obj.category_id !== id),
        type: 'delete',
      },
      {
        onSuccess: ({ type, data }) => {
          console.log('type, data', type, data);
          setCategories(
            data.map((item) => ({
              category_id: item.category_id,
              title: item.title,
            })),
          );
          setUCategory((prevState) => ({
            ...prevState,
            [type]: id,
          }));
        },
        onError: RequestOnError,
      },
    );
  };
  const updateCategory = (object) => {
    updateCategories.mutate(
      {
        categories: gCategories.map((obj) =>
          obj.category_id !== object.category_id ? obj : object,
        ),
        type: 'update',
      },
      {
        onSuccess: ({ type, data }) => {
          console.log('type, data', type, data);
          setCategories(
            data.map((item) => ({
              category_id: item.category_id,
              title: item.title,
            })),
          );
          setUCategory((prevState) => ({
            ...prevState,
            [type]: object.category_id,
          }));
        },
        onError: RequestOnError,
      },
    );
  };

  return {
    categoriesName,
    addCategory,
    deleteCategory,
    gLogLists,
    gCategories,
    Loading: updateCategories.isLoading,
    uCategory,
    updateCategory,
    getCommonLogResource,
  };
};
export const logViewMode = createContext(null);
