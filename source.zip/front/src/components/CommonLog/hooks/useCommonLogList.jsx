import { RequestOnError } from '@libs/util/common/common';
import { useDeleteCommonLogItem } from '@hooks/query/commonLog';

const useCommonLogList = () => {
  const deleteLogItem = useDeleteCommonLogItem();
  const deleteLogFunc = (id) => {
    deleteLogItem.mutate(
      { id },
      {
        onSuccess: () => {},
        onError: RequestOnError,
      },
    );
  };
  return {
    deleteLogFunc,
  };
};

export default useCommonLogList;
