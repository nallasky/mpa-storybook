import { RequestOnError } from '@libs/util/common/common';
import { useDeleteCommonLogItem } from '@hooks/query/commonLog';
import useCommonLogInfo from '@hooks/common/useCommonLogInfo';

const useCommonLogList = () => {
  const deleteLogItem = useDeleteCommonLogItem();
  const { gLogLists, setLogList } = useCommonLogInfo();

  const deleteLogFunc = (id) => {
    deleteLogItem.mutate(
      { id },
      {
        onSuccess: () => {
          setLogList(gLogLists.filter((o) => o.func_id !== id));
        },
        onError: RequestOnError,
      },
    );
  };
  return {
    deleteLogFunc,
  };
};

export default useCommonLogList;
