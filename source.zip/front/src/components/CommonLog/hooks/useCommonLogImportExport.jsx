import { useState } from 'react';
import { useCommonLog } from '@components/CommonLog/hooks/useCommonLog';
import {
  defaultUploadProps as defaultProps,
  RequestOnError,
} from '@libs/util/common/common';
import {
  usePostCommonLogExport,
  usePostCommonLogImport,
} from '@hooks/query/commonLog';

const useCommonLogImportExport = () => {
  const [data, setData] = useState([]);
  const [selectValue, setSelectValue] = useState([]);
  const [importLog, setImportLog] = useState([]);
  const { gLogLists, gCategories } = useCommonLog();
  const exportCommonLog = usePostCommonLogExport();
  const importCommonLog = usePostCommonLogImport();
  const TreeListUpdate = () => {
    const list = gCategories
      .filter(
        (category) =>
          gLogLists.filter(
            (log) =>
              log.category_id === category.category_id &&
              log.info.Source !== 'multi',
          ).length > 0,
      )
      .map((category) => {
        const items = gLogLists.filter(
          (log) => log.category_id === category.category_id,
        );
        return {
          title: category.title,
          value: `category_${category.category_id}`,
          key: `category_${category.category_id}`,
          children: items
            .filter((o) => o.info.Source !== 'multi')
            .map((func) => {
              return {
                title: func.title,
                value: func.func_id,
                key: func.func_id,
              };
            }),
        };
      });
    setData(list);
  };
  const exportProps = {
    treeData: data,
    value: selectValue,
    onChange: setSelectValue,
    treeCheckable: true,
    placeholder: 'Please select',
    style: {
      width: '100%',
    },
  };
  const importFilesProps = {
    ...defaultProps(1, importLog, setImportLog),
    accept: '.json',
  };
  const onExportFunc = (onClose) => {
    exportCommonLog.mutate(
      selectValue.map((obj) => `func_id=${obj}`),
      {
        onSuccess: () => {
          console.log('=====success=====');
          onClose();
        },
        onError: RequestOnError,
      },
    );
  };
  const onImportFunc = (onClose) => {
    console.log('importLog', importLog);
    const formData = new FormData();
    importLog.map((file) => formData.append('files', file));
    importCommonLog.mutate(formData, {
      onSuccess: () => {
        console.log('=====success=====');
        onClose();
      },
      onError: RequestOnError,
    });
  };

  return {
    TreeListUpdate,
    exportProps,
    importFilesProps,
    onExportFunc,
    onImportFunc,
    isExporting: exportCommonLog.isLoading,
    isImporting: importCommonLog.isLoading,
    isEnableImport: importLog.length,
    isEnableExport: selectValue.length,
  };
};

export default useCommonLogImportExport;
