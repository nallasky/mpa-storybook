import { useContext } from 'react';
import { CategoryAddModal, FunctionAddModal } from '@components/CommonLog';
import { PlusCircleOutlined } from '@ant-design/icons';
import useModal from '@libs/util/modalControl/useModal';
import { Log as message, Common } from '@assets/locale/en';
import { logViewMode } from '@components/CommonLog/hooks/useCommonLog';

const CommonLogHeader = () => {
  const { openModal } = useModal();
  const { isViewMode, setViewMode } = useContext(logViewMode);

  const onApply = () => {
    setViewMode(true);
  };
  const onImportExport = () => {
    console.log('======onImportExport=======');
  };
  return (
    <div className="header">
      <div className="wrapper">
        <h1>{message.title}</h1>
        <p>
          {message.explain.map((o, idx) => (
            <li key={idx}>{o}</li>
          ))}
        </p>
        <div className="buttons">
          <div className="left">
            <button onClick={() => openModal(CategoryAddModal, {})}>
              <PlusCircleOutlined />
              {message.category.title}
            </button>
            <button onClick={() => openModal(FunctionAddModal, {})}>
              <PlusCircleOutlined />
              {message.analysis.title}
            </button>
          </div>
          {isViewMode ? (
            <div className="right">
              <button className="light-blue" onClick={onImportExport}>
                {message.import.title}
              </button>
              <button onClick={() => setViewMode(false)}>
                {Common.Btn_Edit}
              </button>
            </div>
          ) : (
            <div className="right">
              <button className="light-blue" onClick={() => setViewMode(true)}>
                {Common.Btn_Cancel}
              </button>
              <button onClick={onApply}>{Common.Btn_Apply}</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
export default CommonLogHeader;
