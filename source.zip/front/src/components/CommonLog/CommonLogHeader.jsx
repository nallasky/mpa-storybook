import { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { CategoryAddModal, FunctionAddModal } from '@components/CommonLog';
import { ArrowLeftOutlined, PlusCircleOutlined } from '@ant-design/icons';
import useModal from '@libs/util/modalControl/useModal';
import { Log as message, Common } from '@assets/locale/en';
import { commonLogInfo } from '@components/CommonLog/hooks/useCommonLog';
import ImportExportModal from '@components/CommonLog/ImportExportModal';
import { NEW } from '@constants/URL';

const CommonLogHeader = () => {
  const { openModal } = useModal();
  const { isViewMode, setViewMode, setReLoad } = useContext(commonLogInfo);
  const navigate = useNavigate();

  return (
    <div className="header">
      <div className="wrapper">
        <h1>{message.title}</h1>
        <p>
          {message.explain.map((o, idx) => (
            <li key={idx}>{o}</li>
          ))}
        </p>
        <div className="buttons">
          <div className="left">
            <button
              onClick={() =>
                openModal(CategoryAddModal, {
                  onSave: () => setReLoad(true),
                })
              }
            >
              <PlusCircleOutlined />
              {message.category.title}
            </button>
            <button
              onClick={() =>
                openModal(FunctionAddModal, {
                  onApply: (type, category) =>
                    navigate(`${NEW}/${type}/${category}`),
                })
              }
            >
              <PlusCircleOutlined />
              {message.analysis.title}
            </button>
          </div>
          {isViewMode ? (
            <div className="right">
              <button
                className="light-blue"
                onClick={() =>
                  openModal(ImportExportModal, {
                    onSave: () => setReLoad(true),
                  })
                }
              >
                {message.import.title}
              </button>
              <button onClick={() => setViewMode(false)}>
                {Common.Btn_Edit}
              </button>
            </div>
          ) : (
            <div className="right">
              <button className="light-blue" onClick={() => setViewMode(true)}>
                <ArrowLeftOutlined />
                {Common.Btn_Back}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
export default CommonLogHeader;
