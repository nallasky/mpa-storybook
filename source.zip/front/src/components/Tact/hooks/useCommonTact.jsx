import { useCallback } from 'react';
import {
  getLogSetting,
  UpdateTactLogSettingReducer,
} from '@reducers/slices/TactInfo';
import { useDispatch, useSelector } from 'react-redux';

const useCommonTact = () => {
  const dispatch = useDispatch();
  const gTactLogList = useSelector(getLogSetting);

  const updateTactLogSetting = useCallback(
    (value) => {
      dispatch(UpdateTactLogSettingReducer(value));
    },
    [dispatch],
  );

  return {
    updateTactLogSetting,
    gTactLogList,
  };
};
export default useCommonTact;
