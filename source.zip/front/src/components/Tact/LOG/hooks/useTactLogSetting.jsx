import {
  useDeleteTactLogScriptFile,
  useGetTactLogInfo,
  usePostTactLogScriptFile,
} from '@hooks/query/tactLogSetting';
import useCommonTact from '@components/Tact/hooks/useCommonTact';

const useTactLogSetting = () => {
  const { updateTactLogSetting, gTactLogList } = useCommonTact();
  const updateScriptFile = usePostTactLogScriptFile();
  const deleteScriptFile = useDeleteTactLogScriptFile();

  const getTactLogListInfo = ({ enabled, onSettled }) =>
    useGetTactLogInfo({
      enabled,
      onSuccess: ({ data }) => {
        updateTactLogSetting(data);
      },
      onSettled,
    });
  return {
    gTactLogList,
    getTactLogListInfo,
    deleteScriptFile,
    updateScriptFile,
  };
};
export default useTactLogSetting;
