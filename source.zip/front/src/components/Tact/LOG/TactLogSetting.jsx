import { useState } from 'react';
import * as SS from '@components/Tact/LOG/styles/TactLogStyle';
import { Skeleton } from 'antd';

import useTactLogSetting from '@components/Tact/LOG/hooks/useTactLogSetting';
import LogSetting from '@components/common/organisms/LogSetting';

export const TactLogSetting = () => {
  const [reLoad, setReLoad] = useState(true);
  const {
    getTactLogListInfo,
    gTactLogList,
    updateScriptFile,
    deleteScriptFile,
  } = useTactLogSetting();
  const { isLoading, error, isFetching } = getTactLogListInfo({
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });

  return (
    <div css={SS.TactLogStyle}>
      {error ?? false ? (
        <div className="remote-setting">
          <div style={{ display: 'flex', gap: '4px' }}>
            <span className="label">{error}</span>
          </div>
        </div>
      ) : (
        <Skeleton
          loading={isLoading || isFetching}
          active
          paragraph={{ rows: 5 }}
        >
          <div className="box-group">
            {gTactLogList.map((logObj, i) => {
              return (
                <div className="box-group-box" key={i}>
                  <LogSetting
                    LogInfo={logObj}
                    action={{
                      delete: deleteScriptFile,
                      refresh: () => setReLoad(true),
                      add: updateScriptFile,
                    }}
                  />
                </div>
              );
            })}
          </div>
        </Skeleton>
      )}
    </div>
  );
};
