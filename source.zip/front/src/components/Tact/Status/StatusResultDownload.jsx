import React from 'react';
import * as SS from './styles/statusStyles';
import { CloudDownloadOutlined } from '@ant-design/icons';
import { MSG_DOWNLOAD } from '@constants/Message';
import PropTypes from 'prop-types';
import useTactStatusDownload from './hooks/useTactStatusDownload';

const StatusResultDownload = ({ mode }) => {
  const { downloadFunc } = useTactStatusDownload();

  return (
    <>
      <div css={SS.customButtonStyle}>
        <button
          css={SS.antdButtonStyle}
          className="white tact-download"
          onClick={() => downloadFunc(mode)}
        >
          <CloudDownloadOutlined />
          <span style={{ marginLeft: '5px' }}>{MSG_DOWNLOAD}</span>
        </button>
      </div>
    </>
  );
};
StatusResultDownload.propTypes = {
  mode: PropTypes.object,
};

export default StatusResultDownload;
