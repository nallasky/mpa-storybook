import React, { useEffect } from 'react';
import SelectLog from './SelectLog';
import { SourceTarget } from './SourceTarget';
import useTactStatusMonitor from './hooks/useTactStatusMonitor';
import StatusSetting from './StatusSetting';
import StatusGraph from './StatusGraph';
import * as SS from './styles/statusStyles';

const StatusMonitor = () => {
  const { setStatusMode, statusMode, initialized } = useTactStatusMonitor();
  useEffect(() => {
    console.log('Tact StatusMonitor component mounted !');
    return () => {
      console.log('Tact StatusMonitor component unmounted !');
      initialized();
    };
  }, []);
  console.log('statusMode', statusMode);
  return (
    <section css={SS.sectionStyle}>
      <SelectLog />
      <div css={SS.componentStyle}>
        <SourceTarget updateModeFunc={setStatusMode} />
      </div>
      <StatusSetting mode={statusMode} updateModeFunc={setStatusMode} />
      <StatusGraph mode={statusMode} updateModeFunc={setStatusMode} />
    </section>
  );
};

export default StatusMonitor;
