import { useCallback, useState } from 'react';
import {
  getTactStatus,
  initialStatusReducer,
  UpdateTactStatusSourceReducer,
  UpdateTactStatusTargetReducer,
} from '@reducers/slices/TactInfo';
import { useDispatch, useSelector } from 'react-redux';

const useTactStatusMonitor = () => {
  const dispatch = useDispatch();
  const gTactStatus = useSelector(getTactStatus);
  const [statusMode, setStatusMode] = useState({
    current: undefined,
    options: [],
    dataList: {},
    setting: {},
  });

  const initialized = useCallback(() => {
    dispatch(initialStatusReducer());
  }, [dispatch]);
  const updateTactStatusSources = useCallback(
    (value) => {
      dispatch(UpdateTactStatusSourceReducer(value));
    },
    [dispatch],
  );
  const updateTactStatusTarget = useCallback(
    (value) => {
      dispatch(UpdateTactStatusTargetReducer(value));
    },
    [dispatch],
  );

  return {
    gTactStatus,
    initialized,
    updateTactStatusSources,
    updateTactStatusTarget,
    statusMode,
    setStatusMode,
  };
};

export default useTactStatusMonitor;
