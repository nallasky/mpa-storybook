import ProcessingModal from '../../../common/organisms/ProcessingModal/ProcessingModal';
import {
  RequestOnError,
  RequestOnSuccess,
  uniqueArray,
} from '@libs/util/common/common';
import {
  DATE_FORMAT,
  E_TACT_GRAPH_COLOR_DIFFERENCE,
  E_TACT_GRAPH_COLOR_PLATE,
  E_TACT_GRAPH_COLOR_PREDICT,
  E_TACT_GRAPH_TYPE_THROUGHPUT,
  E_TACT_STATUS_PLATE_DETAIL_TACT,
  E_TACT_STATUS_PLATE_DETAIL_TACT_DIFF,
  E_TACT_STATUS_PLATE_TACT,
  E_TACT_STATUS_PLATE_TACT_DIFF,
  E_TACT_STATUS_PREDICT_TACT,
} from '@constants/etc';
import {
  TACT_STATUS_JOB,
  TACT_STATUS_PLATE,
  TACT_STATUS_PLATE_DETAIL,
} from '@constants/TactDefault';
import useModal from '../../../../libs/util/modalControl/useModal';
import {
  usePostTactStatusPlateDetailTact,
  usePostTactStatusPlateTact,
} from '@hooks/query/tactStatusMonitor';
import useTactStatusMonitor from './useTactStatusMonitor';
import dayjs from 'dayjs';
import { useCallback } from 'react';
import { getTableForm } from '@libs/util/util';
import {
  status_plate_tact_initial,
  status_plate_detail_tact_initial,
} from '@reducers/slices/TactInfo';
import { ListOfColor } from '@libs/util/common/colorPalette';

const useTactStatusGraphSetting = () => {
  const { openModal, closeModal } = useModal();
  const processPlateTact = usePostTactStatusPlateTact();
  const processPlateDetailTact = usePostTactStatusPlateDetailTact();
  const { gTactStatus: gStatus, updateTactStatusTarget } =
    useTactStatusMonitor();

  const startPlateTact = ({ updateFunc, sPeriod, job, setting, isCompare }) => {
    console.log('startPlateTact[isCompare]', isCompare);
    openModal(ProcessingModal, {
      title: 'Analysing',
      message: 'Analysing data',
    });
    console.log('setting', setting);
    processPlateTact.mutate(
      {
        rid: gStatus.target?.rid,
        period: sPeriod ?? gStatus.target.sPeriod,
        job: job ?? setting?.job ?? undefined,
        type: setting?.type ?? E_TACT_GRAPH_TYPE_THROUGHPUT,
        adc_fdc: setting.adc_fdc,
      },
      {
        onError: (err) => {
          RequestOnError(err);
          console.log(' err ');
        },
        onSuccess: (info) => {
          console.log('[', job, ']', info);
          const lot_data = info.lot_id_block;
          const fist_lot_data = lot_data[Object.keys(lot_data)[0]];
          const plate_tact_data = fist_lot_data[E_TACT_STATUS_PLATE_TACT];
          const categoryList = Object.keys(
            plate_tact_data[info.type] ?? [],
          ).filter((o) => o !== 'sum');
          const isPredict =
            Object.keys(lot_data).find(
              (lot_dat_id) =>
                !!lot_data[lot_dat_id][E_TACT_STATUS_PREDICT_TACT],
            ) !== undefined;
          if (isCompare) {
            updateTactStatusTarget({
              comparePeriod: sPeriod,
              compareJob: job,
            });
          }
          updateFunc((prev) =>
            isCompare
              ? {
                  ...prev,
                  dataList: {
                    ...prev.dataList,
                    [E_TACT_STATUS_PLATE_TACT_DIFF]: info,
                  },
                  setting: {
                    ...prev.setting,
                    [E_TACT_STATUS_PLATE_TACT]: {
                      ...prev.setting[E_TACT_STATUS_PLATE_TACT],
                      compareJob: job ?? setting.compareJob,
                      comparePeriod: sPeriod ?? setting.comparePeriod,
                      comparison: {
                        period_from: dayjs(
                          (sPeriod ?? setting.comparePeriod)[0],
                        ).format(DATE_FORMAT),
                        period_to: dayjs(
                          (sPeriod ?? setting.comparePeriod)[1],
                        ).format(DATE_FORMAT),
                        job: job ?? setting.compareJob,
                      },
                    },
                  },
                }
              : {
                  ...prev,
                  options: [TACT_STATUS_JOB, TACT_STATUS_PLATE],
                  dataList: {
                    ...prev.dataList,
                    [E_TACT_STATUS_PLATE_TACT]: info,
                  },
                  setting: {
                    ...prev.setting,
                    [E_TACT_STATUS_PLATE_TACT]: {
                      ...status_plate_tact_initial,
                      job: job ?? setting.job,
                      type: setting?.type ?? E_TACT_GRAPH_TYPE_THROUGHPUT,
                      adc_fdc: setting.adc_fdc,
                      category: categoryList,
                      isPredict: isPredict,
                      predictive_value: isPredict,
                      org: {
                        period_from: dayjs(
                          (sPeriod ?? gStatus.target.sPeriod)[0],
                        ).format(DATE_FORMAT),
                        period_to: dayjs(
                          (sPeriod ?? gStatus.target.sPeriod)[1],
                        ).format(DATE_FORMAT),
                        job: job ?? setting.job,
                      },
                      color: (isPredict
                        ? [
                            E_TACT_GRAPH_COLOR_PLATE,
                            E_TACT_GRAPH_COLOR_PREDICT,
                            E_TACT_GRAPH_COLOR_DIFFERENCE,
                          ]
                        : [E_TACT_GRAPH_COLOR_PLATE]
                      ).reduce(
                        (acc, obj) => ({
                          ...acc,
                          [obj]: categoryList.reduce(
                            (acc2, obj2, idx) => ({
                              ...acc2,
                              [obj2]: ListOfColor[idx],
                            }),
                            {},
                          ),
                        }),
                        {},
                      ),
                    },
                    [E_TACT_STATUS_PLATE_DETAIL_TACT]: undefined,
                  },
                  current: E_TACT_STATUS_PLATE_TACT,
                },
          );
        },
        onSettled: () => {
          closeModal(ProcessingModal);
        },
      },
    );
  };

  const startPlateDetailTact = (
    updateFunc,
    lot_id_block,
    plate,
    setting,
    isCompare,
  ) => {
    console.log('lot_id_block', lot_id_block);
    console.log('plate', plate);
    console.log('setting', setting);
    console.log('isCompare', isCompare);
    const period = isCompare
      ? gStatus.target.comparePeriod
      : gStatus.target.sPeriod;
    const job = isCompare ? gStatus.target.compareJob : setting.job;
    openModal(ProcessingModal, {
      title: 'Analysing',
      message: 'Analysing data',
    });
    processPlateDetailTact.mutate(
      {
        rid: gStatus.target?.rid,
        job,
        period,
        setting: setting,
        lot_id_block,
        plate,
      },
      {
        onError: (err) => {
          RequestOnError(err);
          console.log(' err ');
        },
        onSuccess: ({ data }) => {
          console.log(data);
          updateFunc((prev) => ({
            ...prev,
            options: prev.options.includes(TACT_STATUS_PLATE_DETAIL)
              ? prev.options
              : [...prev.options, TACT_STATUS_PLATE_DETAIL],
            dataList: {
              ...prev.dataList,
              [isCompare
                ? E_TACT_STATUS_PLATE_DETAIL_TACT_DIFF
                : E_TACT_STATUS_PLATE_DETAIL_TACT]: data,
            },
            setting: {
              ...prev.setting,
              [E_TACT_STATUS_PLATE_DETAIL_TACT]: {
                ...status_plate_detail_tact_initial,
                job: setting.job,
                adc_fdc: setting.adc_fdc,
                comparison: isCompare
                  ? {
                      period_from: dayjs(period[0]).format(DATE_FORMAT),
                      period_to: dayjs(period[1]).format(DATE_FORMAT),
                      job: job,
                      lot_id_block: lot_id_block,
                      plate: plate,
                    }
                  : prev.setting[E_TACT_STATUS_PLATE_DETAIL_TACT]?.comparison ??
                    {},
                org:
                  isCompare === false
                    ? {
                        period_from: dayjs(period[0]).format(DATE_FORMAT),
                        period_to: dayjs(period[1]).format(DATE_FORMAT),
                        job: job,
                        lot_id_block: lot_id_block,
                        plate: plate,
                      }
                    : prev.setting[E_TACT_STATUS_PLATE_DETAIL_TACT]?.org ?? {},
                color: uniqueArray(data.map((o) => o.event)).reduce(
                  (acc2, obj2, idx) => ({
                    ...acc2,
                    [obj2]: ListOfColor[idx],
                  }),
                  {},
                ),
              },
            },
            current: E_TACT_STATUS_PLATE_DETAIL_TACT,
          }));
          RequestOnSuccess('Analysis Success', 'The analysis was successful.');
        },
        onSettled: () => {
          closeModal(ProcessingModal);
        },
      },
    );
  };

  const getTactTableFunc = useCallback(
    (data, categories) => {
      const LotIdBlockData = data?.lot_id_block ?? {};
      const LotIdBlockKeyList = Object.keys(LotIdBlockData);
      // display_order
      const LotIdBlockFirstData = LotIdBlockData[LotIdBlockKeyList[0]];
      const LotIdBLockTypeList = Object.keys(
        LotIdBlockData[LotIdBlockKeyList[0]][E_TACT_STATUS_PLATE_TACT],
      );

      //---------displayOrder-------------------------------------------------------------
      let displayOrder = ['Job']
        .concat(
          Object.keys(LotIdBlockFirstData),
          'Lot_ID_Block',
          categories,
          LotIdBLockTypeList,
        )
        .filter(
          (o) =>
            ![E_TACT_STATUS_PLATE_TACT, E_TACT_STATUS_PREDICT_TACT].includes(o),
        );

      //---------displayRowData-------------------------------------------------------------

      const displayRowData = LotIdBlockKeyList.reduce((acc, blockId) => {
        LotIdBLockTypeList.forEach((type) => {
          LotIdBlockData[blockId].plate.forEach((_, i) => {
            const rowData = displayOrder.reduce((acc2, order) => {
              return {
                ...acc2,
                [order]:
                  order === 'Lot_ID_Block'
                    ? blockId
                    : data?.[order === 'Job' ? 'job_name' : order] ??
                      LotIdBlockData[blockId]?.[order]?.[i] ??
                      LotIdBlockData[blockId][E_TACT_STATUS_PLATE_TACT]?.[
                        type
                      ]?.[order]?.[i] ??
                      '',
              };
            }, {});
            Object.assign(rowData, {
              [type]:
                LotIdBlockData[blockId][E_TACT_STATUS_PLATE_TACT]?.[type]
                  ?.sum?.[i],
            });
            //console.log('[', blockId, '][', type, '][', i, ']:', rowData);
            acc.push(rowData);
          });
        });
        return acc;
      }, []);
      return getTableForm({
        info: { disp_order: displayOrder, row: displayRowData } ?? {},
      });
    },
    [getTableForm],
  );

  return {
    startPlateTact,
    startPlateDetailTact,
    plateTactSelectPeriod: [
      dayjs(gStatus.target.sPeriod[0]).format(DATE_FORMAT),
      dayjs(gStatus.target.sPeriod[1]).format(DATE_FORMAT),
    ].join('~'),
    getTactTableFunc,
    gTactStatusCompareJob: gStatus.target.compareJob,
    gTactStatusComparePeriod: [
      dayjs(gStatus.target?.comparePeriod?.[0] ?? '').format(DATE_FORMAT),
      dayjs(gStatus.target?.comparePeriod?.[1] ?? '').format(DATE_FORMAT),
    ].join('~'),
  };
};
export default useTactStatusGraphSetting;
