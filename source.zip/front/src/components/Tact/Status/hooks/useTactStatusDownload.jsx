import useModal from '../../../../libs/util/modalControl/useModal';
import useTactStatusMonitor from './useTactStatusMonitor';
import ProcessingModal from '../../../common/organisms/ProcessingModal/ProcessingModal';
import { tactExportForm } from '@constants/TactDefault';
import { getGraphImage2 } from '@libs/util/plotly-test';
import { postTactStatusMonitorExport } from '@libs/axios/tactStatusRequest';
import {
  E_TACT_STATUS_PLATE_DETAIL_TACT,
  E_TACT_STATUS_PLATE_TACT,
} from '@constants/etc';
import { getTableCsv } from '@libs/util/util';
import useTactStatusGraphSetting from './useTactStatusGraphSetting';
const useTactStatusDownload = () => {
  const { openModal, closeModal } = useModal();
  const { gTactStatus } = useTactStatusMonitor();
  const { getTactTableFunc } = useTactStatusGraphSetting();
  const makeProperties = (form, data) => {
    console.log('makeProperties 1:', form);
    console.log('makeProperties 2:', data);
    const obj = Object.keys(form).reduce((acc, o) => {
      const value = data?.[typeof form[o] === 'string' ? form[o] : o] ?? '';
      if (
        value !== undefined &&
        (typeof form[o] === 'string' ? value.length : Object.keys(value).length)
      ) {
        Object.assign(acc, { [o]: value });
      }
      return acc;
    }, {});
    console.log('makeProperties 3:', obj);
    return JSON.stringify(obj);
  };
  const makeImageFileName = (v, settingList) => {
    console.log('settingList', settingList);
    console.log(v);
    let file_name = '';
    Object.keys(tactExportForm).forEach((tact) => {
      if (v.includes(tact)) {
        const setting = settingList[tact];
        console.log('tact', tact);
        console.log('setting', setting);
        const isComparisonImage = v.includes('_diff_');
        if (tact === E_TACT_STATUS_PLATE_TACT) {
          file_name = ''.concat(
            tactExportForm[tact].file_name,
            isComparisonImage
              ? `.${setting?.comparison?.job ?? setting.compareJob}_comparison`
              : `.${setting?.org?.job ?? setting.job}`,
          );
        } else if (tact === E_TACT_STATUS_PLATE_DETAIL_TACT) {
          file_name = ''.concat(
            tactExportForm[tact].file_name,
            isComparisonImage
              ? `.${setting.comparison.job}.${setting.comparison.lot_id_block}.${setting.comparison.plate}_comparison`
              : `.${setting.org.job}.${setting.org.lot_id_block}.${setting.org.plate}`,
          );
        } else {
          file_name = tactExportForm[tact].file_name;
        }
      }
    });
    console.log(`file_name:`, file_name);
    return v.includes('_1')
      ? `${file_name}_difference.png`
      : `${file_name}.png`;
  };

  const downloadFunc = async (mode) => {
    openModal(ProcessingModal, {
      title: 'Export',
      message: 'Compressing data',
    });

    const FormObj = new FormData();
    const settingObj = {};
    console.log('==============settings.json======================');
    mode.options.forEach((tact) => {
      const obj = tactExportForm[tact.id];
      Object.assign(settingObj, mode.setting[tact.id]);
      FormObj.append(
        'setting',
        new Blob(
          [
            makeProperties(obj.setting, {
              ...gTactStatus.target,
              ...settingObj,
            }),
          ],
          {
            type: 'application/json',
          },
        ),
        `${obj.file_name}.json`,
      );
      console.log('==============table csv file======================');
      if (tact.id === E_TACT_STATUS_PLATE_TACT && settingObj.show_data_table) {
        const tableData = getTactTableFunc(
          mode.dataList[tact.id],
          mode.setting[tact.id].category,
        );
        FormObj.append(
          'data',
          new File([getTableCsv(tableData)], `${obj.file_name}.csv`),
        );
      }
    });
    console.log('==============getGraphImage======================');
    const imgData = await getGraphImage2('.');
    imgData.forEach((v) => {
      FormObj.append(
        'graph',
        new File([v.url], makeImageFileName(v.filename, mode.setting)),
      );
    });

    await postTactStatusMonitorExport({ obj: FormObj }).then((_) => _);
    closeModal(ProcessingModal);
  };

  return { gTactStatus, downloadFunc };
};

export default useTactStatusDownload;
