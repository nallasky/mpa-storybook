import { useCallback, useState } from 'react';
import {
  useGetTactStatusJobList,
  usePostTactStatusJobTact,
} from '../../../../hooks/query/tactStatusMonitor';
import dayjs from 'dayjs';
import {
  defaultRangePickerProps,
  RequestOnError,
  RequestOnSuccess,
} from '../../../../libs/util/common/common';
import useTactStatusMonitor from './useTactStatusMonitor';
import { DATE_FORMAT, E_TACT_STATUS_JOB_TACT } from '../../../../constants/etc';
import useModal from '../../../../libs/util/modalControl/useModal';
import ProcessingModal from '../../../common/organisms/ProcessingModal/ProcessingModal';
import { TACT_STATUS_JOB } from '../../../../constants/TactDefault';
import { status_job_tact_initial } from '../../../../reducers/slices/TactInfo';
import { ListOfColor } from '../../../../libs/util/common/colorPalette';
import useTactStatusGraphSetting from './useTactStatusGraphSetting';

const useTactStatusTarget = () => {
  const [TargetSet, setTargetSetting] = useState({
    period: [],
    sPeriod: [],
    jobList: [],
    sJobList: undefined,
  });
  const [isUpdate, setUpdate] = useState(false);
  const { openModal, closeModal } = useModal();
  const { updateTactStatusTarget, gTactStatus: gStatus } =
    useTactStatusMonitor();
  const { startPlateTact } = useTactStatusGraphSetting();
  const processGetJobTact = usePostTactStatusJobTact();

  const getJobList = (period) =>
    useGetTactStatusJobList({
      rid: gStatus.target?.rid ?? null,
      period: period,
      options: {
        enabled: isUpdate,
        onError: RequestOnError,
        onSuccess: ({ job }) => {
          //tmp
          console.log('[getJobList]', job);
          setTargetSetting((prevState) => ({
            ...prevState,
            jobList: job ?? [],
            sJobList: undefined,
          }));
        },
        onSettled: () => setUpdate(false),
      },
    });
  const disabledDate = useCallback(
    (current) => {
      return Object.keys(TargetSet.period).length === 0
        ? false
        : dayjs(current).isBefore(dayjs(TargetSet.period[0]), 'd') ||
            dayjs(current).isAfter(dayjs(TargetSet.period[1]), 'd');
    },
    [TargetSet.period],
  );
  const selectJobsProps = {
    style: {
      width: '100%',
    },
    value: TargetSet.sJobList,
    onChange: (newValue) => {
      console.log('newValue', newValue);
      setTargetSetting((prevState) => ({
        ...prevState,
        sJobList: newValue,
      }));
    },
    placeholder: 'Select Item...',
    maxTagCount: 'responsive',
  };

  const selectPeriodProps = defaultRangePickerProps(
    TargetSet.period,
    TargetSet.sPeriod,
    (newValue) => {
      setTargetSetting((prevState) => ({
        ...prevState,
        sPeriod: newValue,
      }));
    },
    (open) => {
      if (open === false) {
        setUpdate(true);
      }
    },
  );
  const startComparePlateTact = (updateFunc, setting) => {
    Array.isArray(TargetSet.sJobList)
      ? console.log('[startComparePlateTact]', TargetSet.sJobList)
      : startPlateTact({
          updateFunc,
          job: TargetSet.sJobList,
          setting: setting,
          isCompare: true,
          sPeriod: TargetSet.sPeriod,
        });
  };
  const startJobTact = (updateFunc) => {
    openModal(ProcessingModal, {
      title: 'Analysing',
      message: 'Analysing data',
      useCancel: true,
      onCancel: processGetJobTact.cancel,
    });
    processGetJobTact.mutate(
      {
        rid: gStatus.target?.rid,
        period: TargetSet.sPeriod,
        job: TargetSet.sJobList,
      },
      {
        onError: (err) => {
          RequestOnError(err);
          console.log(' err ');
        },
        onSuccess: (info) => {
          updateTactStatusTarget({
            sPeriod: [
              dayjs(TargetSet.sPeriod[0], DATE_FORMAT),
              dayjs(TargetSet.sPeriod[1], DATE_FORMAT),
            ],
            sJobList: TargetSet.sJobList,
          });
          console.log(info);
          updateFunc({
            options: [TACT_STATUS_JOB],
            dataList: { [E_TACT_STATUS_JOB_TACT]: info },
            comparison: {
              period: [
                dayjs(TargetSet.sPeriod[0], DATE_FORMAT),
                dayjs(TargetSet.sPeriod[1], DATE_FORMAT),
              ],
              sPeriod: ['', ''],
              jobList: TargetSet.jobList,
              selectJob: undefined,
            },
            setting: {
              [E_TACT_STATUS_JOB_TACT]: {
                ...status_job_tact_initial,
                color: Object.keys(info).reduce(
                  (acc, obj, idx) => ({
                    ...acc,
                    [obj]: ListOfColor[idx],
                  }),
                  {},
                ),
              },
            },
            current: E_TACT_STATUS_JOB_TACT,
          });
          RequestOnSuccess('Analysis Success', 'The analysis was successful.');
        },
        onSettled: () => {
          closeModal(ProcessingModal);
        },
      },
    );
  };
  return {
    gLogFiles: gStatus.files,
    gPredictFiles: gStatus.predict_files,
    gTargetSettings: gStatus.target,
    getTargetPeriod: TargetSet.period,
    getSelectedPeriod: TargetSet?.sPeriod ?? [],
    getTargetJobList: TargetSet.jobList,
    getSelectedJobList: TargetSet.sJobList,
    setTargetSetting,
    TargetSet,
    disabledDate,
    selectJobsProps,
    selectPeriodProps,
    getJobList,
    startJobTact,
    startComparePlateTact,
  };
};

export default useTactStatusTarget;
