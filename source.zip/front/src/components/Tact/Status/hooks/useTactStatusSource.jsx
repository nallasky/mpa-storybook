import { useState } from 'react';
import {
  useGetTactStatusConvertedFilesInfo,
  useGetTactStatusConvertedStatus,
  usePostTactStatusUploadLogFiles,
} from '@hooks/query/tactStatusMonitor';
import {
  defaultUploadProps as defaultProps,
  RequestOnError,
} from '../../../../libs/util/common/common';
import useTactStatusMonitor from './useTactStatusMonitor';
import {
  ProcessingModal,
  PercentProcessingModal,
} from '../../../common/organisms/ProcessingModal';
import useModal from '../../../../libs/util/modalControl/useModal';
import dayjs from 'dayjs';
import { DATE_FORMAT } from '@constants/etc';
const MAX_FILES_CNT = 100;

const useTactStatusSource = () => {
  const [LogFiles, setLogFiles] = useState([]);
  const [PredictFiles, setPredictFiles] = useState([]);
  const [isUpdate, setUpdate] = useState({ rid: undefined, isUpdate: false });
  const { updateTactStatusSources, updateTactStatusTarget } =
    useTactStatusMonitor();
  const { openModal, closeModal } = useModal();

  const uploadFiles = usePostTactStatusUploadLogFiles();
  useGetTactStatusConvertedFilesInfo({
    rid: isUpdate.rid,
    options: {
      enabled: isUpdate.isUpdate,
      onSuccess: (info) => RequestOnSuccess(info.period, info.job),
      onError: RequestOnError,
      onSettled: () =>
        setUpdate((prevState) => ({ ...prevState, isUpdate: false })),
    },
  });

  //----------------------------------------------------------------
  const getLogFilesProps = defaultProps(MAX_FILES_CNT, LogFiles, setLogFiles);
  const getPredictFilesProps = defaultProps(
    MAX_FILES_CNT,
    PredictFiles,
    setPredictFiles,
  );
  const RequestOnSuccess = (period, job) => {
    updateTactStatusTarget({
      rid: isUpdate.rid,
      period: [dayjs(period[0], DATE_FORMAT), dayjs(period[1], DATE_FORMAT)],
      jobList: job,
    });
  };
  const uploadCompletedFunc = (rid) => {
    console.log('uploadCompleted', rid);
    updateTactStatusSources({
      files: LogFiles.map((o) => o.name),
      predict_files: PredictFiles.map((o) => o.name),
    });
    setUpdate({ rid: rid, isUpdate: true });
  };

  const startUploadLogFiles = () => {
    openModal(ProcessingModal, {
      title: 'Converting',
      message: 'Converting files',
      useCancel: true,
      onCancel: uploadFiles.cancel,
    });
    const formData = new FormData();
    if (LogFiles.length > 0) {
      LogFiles.map((o) => formData.append('files', o));
    }
    if (PredictFiles.length > 0) {
      PredictFiles.map((o) => formData.append('prediction', o));
    }
    uploadFiles.mutate(formData, {
      onError: RequestOnError,
      onSuccess: (info) => {
        openModal(PercentProcessingModal, {
          statusFunc: useGetTactStatusConvertedStatus,
          rid: info?.rid ?? null,
          onCancel: () => closeModal(PercentProcessingModal),
          onClose: () => closeModal(PercentProcessingModal),
          completeFunc: uploadCompletedFunc,
        });
      },
      onSettled: () => {
        closeModal(ProcessingModal);
      },
    });
  };
  //----------------------------------------------------------------

  return {
    LogFiles,
    getLogFilesProps,
    getPredictFilesProps,
    startUploadLogFiles,
  };
};

export default useTactStatusSource;
