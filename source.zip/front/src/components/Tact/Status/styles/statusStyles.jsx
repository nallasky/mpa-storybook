import { css, keyframes } from '@emotion/react';

export const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  width: 100%;
  animation: fadeIn 1s;
`;

const moveLeft = keyframes`
  25% {
    transform: translateX(-25px);
  }
  50% {
    transform: translateX(0);
  }
`;

export const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 300px;
  background-color: var(--ckr-gray-1);
  border-radius: 4px;
  box-shadow: 0 0 8px 2px rgba(0, 0, 0, 0.15);
  &.stretch {
    align-self: stretch;
  }
  &.span {
    display: flex;
    flex-direction: column;
    grid-column: 1 / span 2;
  }
  &.gridColumn {
    grid-column: 1 / span 2;
  }
  & .source-button-wrapper {
    float: right;
    margin-top: 10px;
  }
  &.diffGraph {
    display: grid;
    grid-template-columns: 700px 700px;
    column-gap: 8px;
  }
  & > .ant-spin {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    row-gap: 0.5rem;
    background-color: var(--ckr-gray-1);
    border-radius: 4px;
    &.ant-spin-spinning {
      z-index: 1200;
    }
  }
  & .foreground {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 4px;
    display: none;
    justify-content: center;
    align-items: center;
    background-color: var(--ckr-gray-1);
    &.active {
      display: flex;
      z-index: 5;
      & > div {
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        row-gap: 1rem;
        & > svg {
          position: relative;
          animation: ${moveLeft} 1.5s ease-in-out infinite;
        }
        & > p {
          font-size: 20px;
          font-weight: bold;
        }
      }
    }
  }
  & .Plate-Period {
    min-height: 30px;
    margin-top: 15px;
    & span {
      color: var(--ckr-gray-1);
      background: var(--ckr-blue-6);
      border-radius: 10px 10px 0 0;
      padding: 8px 16px;
    }
  }
  & .dashed {
    border: 1px dashed var(--ckr-blue-6);
    padding: 1rem;
  }
  & .modebar {
    top: -2px !important;
    left: 114px;
  }
  & .diffPlate {
    padding: unset;
    box-shadow: unset;
  }
  & .ant-table-header > table > thead > tr {
    white-space: pre;
  }
  & .ant-table-body > table {
    min-width: 1755px !important;
  }
`;

export const componentTitleStyle = css`
  font-size: 24px;
  color: var(--ckr-blue-6);
  margin-bottom: 10px;
`;

export const contentWrapperStyle = css`
  position: relative;
  &.mg-bottom {
    margin-bottom: 13px;
  }
  &.ts-source-button-wrapper {
    position: relative;
    text-align-last: center;
    right: -477px;
  }
`;

export const contentStyle = css`
  margin: 0 auto;
  &.target-mode {
    width: 80%;
  }
  &.full-width {
    width: 100%;
  }
  & > div + div {
    margin-top: 2rem;
  }
`;

export const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.fileText {
    align-items: flex-start;
  }
  &.column-2 {
    grid-template-columns: 0.4fr 1fr;
  }
  &.column-3 {
    grid-template-columns: 0.4fr 1fr 1fr;
  }
  &.column-4 {
    grid-template-columns: 0.5fr 1fr;
  }
  &.flex-between {
    display: flex;
    justify-content: space-between;
  }
  &.etc {
    display: flex;
    justify-content: space-between;
  }
  & > span {
    position: relative;
    &:first-of-type {
      position: relative;
      &.label {
        &.required {
          &::before {
            display: inline-block;
            color: var(--ckr-red-6);
            font-size: 16px;
            content: '*';
            margin-right: 0.3rem;
          }
          &::after {
            display: inline-block;
            content: ':';
          }
        }
      }
    }
    &:last-of-type {
      width: 100%;
      & .ant-upload-list-text {
        margin-top: 0.5rem;
        overflow: auto;
        max-height: 70px;
        &::-webkit-scrollbar {
          width: 8px;
        }
        &::-webkit-scrollbar-track {
          background-color: transparent;
        }
        &::-webkit-scrollbar-thumb {
          border-radius: 4px;
          background-color: rgba(0, 0, 0, 0.2);
        }
        &::-webkit-scrollbar-button {
          width: 0;
          height: 0;
        }
      }
    }
  }
  & .full-width {
    & > .ant-upload-select-text,
    & button {
      width: 100%;
    }
  }
  & > .title {
    width: 100%;
    text-align: center;
    font-size: 20px;
  }
  & > .preset-setting {
    display: flex;
    column-gap: 1rem;
  }
  & .radio-cp-vs {
    display: grid;
    grid-template-columns: repeat(3, 18rem);
    column-gap: 1rem;
    grid-column: span 2;
  }
  & .margin-lr {
    margin: 0 1rem;
  }
  & .margin-r {
    margin-right: 1rem;
  }
  & .tx-right {
    text-align: right;
  }
  & ~ div {
    margin-top: 2rem;
    &.table-wrapper {
      margin-top: 1rem;
    }
  }
  .ant-form-item {
    width: 289px;
    margin-bottom: 0;
  }
  .ant-form-item-explain-connected {
    min-height: 0;
  }
  .ant-col-16 {
    max-width: 100%;
  }
`;

export const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-color: var(--ckr-gray-1);
  border: none;
  &.color-picker {
    grid-area: 2/1/2/4;
    padding: 0.5rem;
    border-top: 1px solid var(--ckr-gray-4);
  }
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: var(--ckr-blue-6);
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: 15px;
    right: 15px;
    & > span:first-of-type {
      color: var(--ckr-green-6);
      margin: 12px 0 8px;
      font-size: 30px;
      transition: transform 0.3s ease-in-out;
      will-change: transform;
      &:hover {
        color: var(--ckr-green-6);
        background-color: #1890ff00;
        transform: scale(1.4);
      }
    }
  }
  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
    pointer-events: none;
    & > span:first-of-type {
      color: var(--ckr-gray-6);
    }
  }
`;

export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: var(--ckr-gray-1);
    border: 1px dashed var(--ckr-gray-5);
    &:disabled {
      background-color: var(--ckr-gray-5);
      color: transparent;
      &::before {
        position: absolute;
        width: 100%;
        top: 5px;
        left: 0;
        content: 'X';
        color: var(--ckr-gray-1);
        font-weight: bold;
        font-size: 20px;
      }
    }
  }
  &.blue {
    color: var(--ckr-gray-1);
    background-color: var(--ckr-blue-6);
    border: 1px solid var(--ckr-blue-6);
  }
  &.color-picker {
    width: 100%;
    border-radius: 10px;
    font-weight: 400;
  }
  &.tact-download {
    margin-left: 8px;
    font-weight: 400;
  }
  &.view-graph {
    width: 136px;
    float: right;
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;

export const controlStyle = css`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  &.tact {
    padding-bottom: 1rem;
  }
`;

export const ColorBox = css`
  align-self: center;
  & > div + div {
    margin-top: 10px;
  }
`;

export const tactGraphColorButtonStyle = css`
  display: block;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 8px 16px;
  background: var(--ckr-gray-1);
  border: 1px dashed var(--ckr-gray-5);
  box-sizing: border-box;
  border-radius: 10px;
  margin: 0 30px 0 0;
  &:hover {
    display: block;
    background: var(--ckr-gray-1);
    border: 1px dashed var(--ckr-blue-4);
    box-sizing: border-box;
    border-radius: 10px;
  }
`;
export const tactGraphSettingStyle = css`
  margin: 0 auto;
  width: 100%;
  padding: 0 1rem;
  align-self: center;
  &.full-width {
    width: 100%;
  }
  & > div + div {
    margin-top: 2rem;
  }
`;

export const tactGraphColorSettingStyle = css`
  margin: 0 auto;
  width: 100%;
  padding: 0 1rem;
  display: flex;
  align-items: center;
`;

export const tactMainRibbon = css`
  & .ant-card-body {
    min-height: 125px;
    border: 1px solid var(--ckr-blue-3) !important;
    & > .mg-bottom > div {
      width: 70%;
    }
  }
`;

export const jobTactScaleStyle = css`
  display: flex;
  justify-content: space-between;
  align-items: center;
  & > div {
    display: flex;
    align-items: center;
    & > span {
      white-space: nowrap;
    }
  }
`;

export const PlateTactScaleStyle = css`
  display: flex;
  align-items: center;
  margin-left: auto;
  & > div {
    display: flex;
    align-items: center;
    & > span {
      white-space: nowrap;
    }
  }
`;

export const divSubColorStyle = css`
  width: 100%;
  display: flex;
  flex-flow: wrap;
  white-space: pre;
`;
export const subColorStyle = css`
  display: flex;
  align-items: center;
  margin-right: 20px;
  & > div {
    display: flex;
  }
  & > span {
    cursor: context-menu;
  }
  & button {
    border: none;
    height: 15px;
    width: 15px;
    border-radius: 50%;
    margin-right: 5px;
    cursor: unset;
  }
  & button.rc-color-picker-trigger {
    cursor: unset;
  }
`;

export const testDropDown = css`
  .dropBtn {
    cursor: pointer;
  }
  .dropdown-content {
    display: block;
    position: absolute;
    margin-top: 20px;
    z-index: 1;
    box-shadow: 0 3px 5px 1px rgb(0 0 0 / 15%);
    border-radius: 10px;
    &:after {
      position: absolute;
      left: 50px;
      top: -9px;
      width: 20px;
      height: 20px;
      z-index: 5;
      transform: rotate(225deg);
      box-shadow: 1px 1px 3px -1px rgba(0, 0, 0, 0.1);
      content: '';
      transition: all 0.2s;
      background-color: var(--ckr-gray-1);
    }
  }
`;

export const PlateGraphStyle = css`
  padding: 1rem;
`;

export const SelectColorStyle = css`
  display: flex;
  align-items: center;
  margin-right: 20px;
  padding: 10px 5px;
  cursor: pointer;
  border-radius: 10px;
  border: 1px solid transparent;
  & > div {
    display: flex;
  }
  & button {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    border: none;
    margin-right: 5px;
  }
  &:hover {
    border: 1px dashed var(--ckr-blue-6);
    background-color: var(--ckr-gray-1);
    color: var(--ckr-blue-6);
  }
  &.selected {
    background-color: var(--ckr-blue-6);
    color: var(--ckr-gray-1);
  }
  & + div {
    margin-top: 0.5rem;
  }
`;

export const tactColorBoxStyle = css`
  display: grid;
  grid-template-columns: auto 218px;
  padding: 1rem 1rem 0;
  border-radius: 10px;
  background: var(--ckr-gray-1);
  grid-gap: 5px;
  min-height: 240px;
  & > div {
    max-height: 250px;
    overflow: auto;
    &::-webkit-scrollbar {
      width: 8px;
    }
    &::-webkit-scrollbar-track {
      background-color: transparent;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 4px;
      background-color: var(--ckr-blue-3);
    }
    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }
  }
`;
export const colorSettingStyle = css`
  display: flex;
  justify-content: space-between;
  padding: 10px 16px;
  border-bottom: 1px solid var(--ckr-gray-4);
  background-color: var(--ckr-gray-1);
  border-radius: 10px 10px 0 0;
  & > span {
    font-size: 20px;
    font-weight: bold;
    color: var(--ckr-gray-13);
  }
  & > button {
    background-color: var(--ckr-gray-1);
    border: unset;
    cursor: pointer;
    & > span {
      color: var(--ckr-gray-6);
    }
  }
  & button:hover {
    & > span {
      color: var(--ckr-gray-13);
    }
  }
`;

export const settingContentStyle = css`
  position: relative;
  margin: 0 auto;
  width: 100%;
  padding: 1rem;
  &.etc {
    width: 100%;
    padding: 0;
  }
  & .flex {
    display: flex;
    justify-content: space-between;
    & > span {
      white-space: pre;
    }
  }
  &.full-width {
    width: 100%;
  }
  & .table-wrapper ~ div,
  & .content > .radio-wrapper ~ .tab {
    margin-top: 1rem;
    width: 100%;
  }
`;
