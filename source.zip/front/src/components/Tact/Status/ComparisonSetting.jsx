import React from 'react';
import PropTypes from 'prop-types';
import * as SS from './styles/statusStyles';
import { ShrinkOutlined } from '@ant-design/icons';
import { E_TACT_STATUS_PLATE_TACT } from '@constants/etc';
import { SourceTarget } from './SourceTarget';
import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
const ComparisonSetting = ({ mode, setting, updateModeFunc }) => {
  if (mode !== E_TACT_STATUS_PLATE_TACT) return <></>;
  return (
    <>
      <div css={SS.tactMainRibbon}>
        <RibbonCollapse
          title={'Comparison Setting'}
          css={SS.settingContentStyle}
        >
          <div className="svg-box">
            <ShrinkOutlined />
          </div>
          <div css={SS.settingContentStyle}>
            <SourceTarget
              isMultiJob={false}
              title={''}
              isCompareMode={true}
              updateModeFunc={updateModeFunc}
              setting={setting}
            />
          </div>
        </RibbonCollapse>
      </div>
    </>
  );
};
ComparisonSetting.propTypes = {
  mode: PropTypes.string,
  setting: PropTypes.object,
  updateModeFunc: PropTypes.func,
};
export default ComparisonSetting;
