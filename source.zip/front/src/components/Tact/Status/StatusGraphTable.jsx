import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import useTactStatusGraphSetting from './hooks/useTactStatusGraphSetting';
import { Table } from 'antd';

const StatusGraphTable = ({ data, setting, isVisible }) => {
  if (!isVisible || data === undefined) return <></>;
  const { getTactTableFunc } = useTactStatusGraphSetting();
  const tableData = useMemo(() => {
    console.log('tableData', data);
    return setting?.category ?? false
      ? getTactTableFunc(data, setting.category)
      : undefined;
  }, [data, setting?.category]);

  return (
    <>
      <Table
        bordered
        pagination={false}
        columns={tableData.columns}
        dataSource={tableData.dataSource}
        size="middle"
        rowKey="key"
        scroll={{ x: 'max-content', y: '400px' }}
      />
    </>
  );
};
StatusGraphTable.propTypes = {
  isVisible: PropTypes.bool,
  setting: PropTypes.object,
  data: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
};

export default StatusGraphTable;
