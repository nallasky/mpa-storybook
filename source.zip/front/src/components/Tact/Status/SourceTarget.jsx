import React, { useEffect } from 'react';
import * as SS from './styles/statusStyles';
import { DatePicker, Select, Spin } from 'antd';
import { PlayCircleOutlined } from '@ant-design/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import useTactStatusTarget from './hooks/useTactStatusTarget';
import PropTypes from 'prop-types';
import { MESSAGE } from '@constants/Message';

const { Option } = Select;

export const SourceTarget = ({
  updateModeFunc,
  isCompareMode,
  isMultiJob,
  title,
  setting,
}) => {
  const {
    gLogFiles,
    gTargetSettings,
    getSelectedPeriod,
    getSelectedJobList,
    getTargetJobList,
    getJobList,
    TargetSet,
    setTargetSetting,
    selectJobsProps,
    selectPeriodProps,
    startJobTact,
    startComparePlateTact,
  } = useTactStatusTarget();
  const reqJobList = getJobList(getSelectedPeriod, isCompareMode);

  useEffect(() => {
    console.log('[useEffect] period', gTargetSettings.period);

    setTargetSetting((prev) => ({
      ...prev,
      sPeriod: isCompareMode
        ? gTargetSettings?.comparePeriod ?? gTargetSettings.period
        : gTargetSettings.period,
      period: gTargetSettings.period,
      jobList: gTargetSettings.jobList,
      sJobList: isCompareMode ? gTargetSettings?.compareJob ?? undefined : [],
    }));
  }, [gTargetSettings.period, gTargetSettings.jobList]);

  useEffect(() => {
    if (isCompareMode && (TargetSet?.sJobList ?? false)) {
      if (gTargetSettings?.compareJob !== TargetSet?.sJobList) {
        startComparePlateTact(updateModeFunc, setting);
      }
    }
  }, [TargetSet.sJobList]);

  return (
    <>
      <div className={'foreground' + (gLogFiles.length === 0 ? ' active' : '')}>
        <div>
          <FontAwesomeIcon icon={faArrowLeft} size="10x" />
          <p>Please first set the left.</p>
        </div>
      </div>
      <div css={SS.componentTitleStyle}>{title ?? MESSAGE.SELECT_TARGET}</div>
      <div css={SS.contentWrapperStyle} className="mg-bottom">
        <div
          css={SS.contentStyle}
          className={isCompareMode ? 'full-width' : 'target-mode'}
        >
          <div css={SS.contentItemStyle} className="column-2">
            <span className={`label ${isCompareMode ? '' : 'required '}`}>
              {MESSAGE.PERIOD}
            </span>
            <DatePicker.RangePicker {...selectPeriodProps} />
          </div>
          <Spin
            size="large"
            tip="Loading..."
            spinning={reqJobList?.isLoading ?? false}
          >
            <div css={SS.contentItemStyle} className="column-2">
              <span className={`label ${isCompareMode ? '' : 'required'}`}>
                {MESSAGE.JOB}
              </span>
              <Select
                {...selectJobsProps}
                mode={isMultiJob ? 'multiple' : undefined}
              >
                {getTargetJobList?.map((o) => (
                  <Option key={`JobList_${o}`} value={o}>
                    {o}
                  </Option>
                ))}
              </Select>
            </div>
          </Spin>
        </div>
      </div>
      {isCompareMode ? (
        <></>
      ) : (
        <button
          css={SS.customButtonStyle}
          className="absolute"
          disabled={
            Object.keys(getSelectedPeriod).length === 0 ||
            (getSelectedJobList ?? []).length === 0
          }
          onClick={() => startJobTact(updateModeFunc)}
        >
          <PlayCircleOutlined />
          <span>Start</span>
        </button>
      )}
    </>
  );
};
SourceTarget.propTypes = {
  updateModeFunc: PropTypes.func,
  isCompareMode: PropTypes.bool,
  isMultiJob: PropTypes.bool,
  title: PropTypes.string,
  setting: PropTypes.object,
};
SourceTarget.defaultProps = {
  isCompareMode: false,
  isMultiJob: true,
  title: MESSAGE.SELECT_TARGET,
};
