import React from 'react';
import PropTypes from 'prop-types';
import * as SS from './styles/statusStyles';
import {
  E_TACT_GRAPH_UNIT_LOT,
  E_TACT_STATUS_JOB_TACT,
  E_TACT_STATUS_PLATE_DETAIL_TACT,
  E_TACT_STATUS_PLATE_TACT,
} from '@constants/etc';
import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
import { InputNumber, Select, Switch } from 'antd';
import { SettingOutlined } from '@ant-design/icons';
import { MESSAGE } from '@constants/Message';
import {
  TACT_GRAPH_ADC_FDC_LIST,
  TACT_GRAPH_TYPE_LIST,
  TACT_GRAPH_UNIT_LIST,
} from '@constants/TactDefault';

const { Option } = Select;

const GraphSetting = ({ mode, setting, updateSetting }) => {
  console.log('[GraphSetting]setting[', mode, ']', setting);
  const ChangeFunc = (key, v) => {
    updateSetting({ ...setting, [key]: v });
  };
  return (
    <>
      <div css={SS.tactMainRibbon}>
        <RibbonCollapse
          title={'Graph Setting'}
          defaultValue={true}
          css={SS.settingContentStyle}
        >
          <div className="svg-box">
            <SettingOutlined />
          </div>
          <div css={SS.tactGraphSettingStyle}>
            <div css={SS.contentItemStyle} className="column-2">
              {mode === E_TACT_STATUS_JOB_TACT ? (
                <>
                  <span className="label-2">{MESSAGE.TACT_GRAPH_UNIT}</span>
                  <Select
                    value={setting?.unit}
                    style={{ width: '100%' }}
                    onChange={(v) => ChangeFunc('unit', v)}
                  >
                    {TACT_GRAPH_UNIT_LIST.map((item, i) => (
                      <Option value={item.id} key={i}>
                        {' '}
                        {item.title}
                      </Option>
                    ))}
                  </Select>
                </>
              ) : mode === E_TACT_STATUS_PLATE_TACT ? (
                <>
                  <span className="label-2">{MESSAGE.TACT_GRAPH_TYPE}</span>
                  <Select
                    value={setting.type}
                    style={{ width: '100%' }}
                    onChange={(v) =>
                      updateSetting({
                        ...setting,
                        type: v,
                        adc_fdc: undefined,
                      })
                    }
                  >
                    {TACT_GRAPH_TYPE_LIST.map((item, i) => (
                      <Option value={item.id} key={i}>
                        {' '}
                        {item.title}
                      </Option>
                    ))}
                  </Select>
                </>
              ) : (
                <div css={SS.contentItemStyle} className="column-4">
                  <span className="label-2">
                    {MESSAGE.TACT_GRAPH_SCALE_UNIT}
                  </span>
                  <div css={SS.jobTactScaleStyle}>
                    <InputNumber
                      min={0}
                      controls={false}
                      value={setting?.scale_unit ?? 0}
                      style={{ width: '100%', marginRight: '5px' }}
                      onChange={(v) => ChangeFunc('scale_unit', v)}
                    />
                    {MESSAGE.TACT_GRAPH_UNIT_MSEC}
                  </div>
                </div>
              )}
            </div>
            <div
              css={SS.contentItemStyle}
              className="column-2"
              style={
                mode !== E_TACT_STATUS_PLATE_DETAIL_TACT
                  ? {}
                  : { display: 'none' }
              }
            >
              <span className="label-2">{MESSAGE.TACT_GRAPH_ADC_FDC}</span>
              <Select
                value={setting?.adc_fdc}
                style={{ width: '100%' }}
                disabled={setting?.unit === E_TACT_GRAPH_UNIT_LOT}
                onChange={(v) => ChangeFunc('adc_fdc', v)}
              >
                {TACT_GRAPH_ADC_FDC_LIST.map((item, i) => (
                  <Option value={item.id} key={i}>
                    {item.title}
                  </Option>
                ))}
              </Select>
            </div>
            <div
              css={SS.contentItemStyle}
              className="flex-between"
              style={mode === E_TACT_STATUS_JOB_TACT ? {} : { display: 'none' }}
            >
              <span className="label-2">
                {MESSAGE.TACT_GRAPH_DISPLAY_OUTLIER}
              </span>
              <Switch
                checkedChildren="ON"
                unCheckedChildren="OFF"
                checked={setting?.display_outlier}
                onChange={(v) => ChangeFunc('display_outlier', v)}
              />
            </div>
            {[E_TACT_STATUS_JOB_TACT, E_TACT_STATUS_PLATE_TACT].includes(
              mode,
            ) ? (
              <div css={SS.contentItemStyle} className="column-2">
                <span className="label-2">
                  {mode === E_TACT_STATUS_JOB_TACT
                    ? MESSAGE.TACT_GRAPH_JOB_SCALE
                    : MESSAGE.TACT_GRAPH_PLATE_SCALE}
                </span>
                <div
                  css={
                    mode === E_TACT_STATUS_JOB_TACT
                      ? SS.jobTactScaleStyle
                      : SS.PlateTactScaleStyle
                  }
                >
                  <div
                    style={
                      mode === E_TACT_STATUS_JOB_TACT ? {} : { display: 'none' }
                    }
                  >
                    <span>{MESSAGE.Y_LOWER_LIMIT}</span>
                    <InputNumber
                      max={setting.y_upper_limit ?? 10000}
                      controls={false}
                      value={setting.y_lower_limit}
                      style={{ width: '100%', marginLeft: '5px' }}
                      onChange={(v) => ChangeFunc('y_lower_limit', v)}
                    />
                  </div>
                  <div>
                    <span>{MESSAGE.Y_UPPER_LIMIT}</span>
                    <InputNumber
                      min={setting.y_lower_limit ?? 0}
                      controls={false}
                      value={setting.y_upper_limit}
                      style={{ width: '190px', marginLeft: '5px' }}
                      onChange={(v) => ChangeFunc('y_upper_limit', v)}
                    />
                  </div>
                </div>
              </div>
            ) : (
              <></>
            )}
            {mode === E_TACT_STATUS_PLATE_TACT ? (
              <>
                <div css={SS.contentItemStyle} className="flex-between">
                  <span className="label-2">
                    {MESSAGE.TACT_GRAPH_SHOW_PREDICTIVE_VALUE}
                  </span>
                  <Switch
                    checkedChildren="ON"
                    unCheckedChildren="OFF"
                    checked={setting?.predictive_value}
                    disabled={setting?.isPredict === false}
                    onChange={(v) => ChangeFunc('predictive_value', v)}
                  />
                </div>
                <div css={SS.contentItemStyle} className="flex-between">
                  <span className="label-2">
                    {MESSAGE.TACT_GRAPH_SHOW_DATA_TABLE}
                  </span>
                  <Switch
                    checkedChildren="ON"
                    unCheckedChildren="OFF"
                    checked={setting?.show_data_table}
                    onChange={(v) => ChangeFunc('show_data_table', v)}
                  />
                </div>
              </>
            ) : (
              <></>
            )}
          </div>
        </RibbonCollapse>
      </div>
    </>
  );
};
GraphSetting.propTypes = {
  mode: PropTypes.string,
  setting: PropTypes.object,
  updateSetting: PropTypes.func,
};
export default GraphSetting;
