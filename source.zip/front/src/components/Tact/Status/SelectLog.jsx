import React from 'react';
import * as SS from './styles/statusStyles';
import { Upload } from '../../common/atoms/Upload';
import useTactStatusSource from './hooks/useTactStatusSource';

const SelectLog = () => {
  const {
    getLogFilesProps,
    getPredictFilesProps,
    LogFiles,
    startUploadLogFiles,
  } = useTactStatusSource();
  return (
    <div css={SS.componentStyle} className="stretch">
      <div css={SS.componentTitleStyle}>Select Source</div>
      <div css={SS.contentWrapperStyle}>
        <div css={SS.contentStyle} className="full-width">
          <div css={SS.contentItemStyle} className="column-2 fileText">
            <Upload
              label={'Log Files'}
              type={'Drag'}
              uploadProps={getLogFilesProps}
            />
          </div>
          <div css={SS.contentItemStyle} className="column-2 fileText">
            <Upload
              label={'Predict File (Optional)'}
              type={'Drag'}
              required={false}
              uploadProps={getPredictFilesProps}
            />
          </div>
        </div>
      </div>
      <div>
        <div className="source-button-wrapper">
          <button
            css={SS.antdButtonStyle}
            className="white"
            disabled={LogFiles.length === 0}
            onClick={startUploadLogFiles}
          >
            Load Start
          </button>
        </div>
      </div>
    </div>
  );
};
export default SelectLog;
