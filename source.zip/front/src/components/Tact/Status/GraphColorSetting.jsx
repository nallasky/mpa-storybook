import React, { useState } from 'react';
import PropTypes from 'prop-types';
import * as SS from './styles/statusStyles';
import { Button } from 'antd';
import { RibbonCollapse } from '@components/common/molecules/RibbonCollapse/RibbonCollapse';
import { DownCircleFilled, FormatPainterOutlined } from '@ant-design/icons';
import { GraphColorMenu } from './GraphColorMenu';
import { TACT_GRAPH_COLOR_LIST } from '@constants/TactDefault';

const GraphColorSetting = ({ mode, color, updateColor }) => {
  const [colorMenu, setColorMenu] = useState(false);

  const ChangeFunc = (key, v) => {
    updateColor(
      TACT_GRAPH_COLOR_LIST[mode].length > 1 ? { ...color, [key]: v } : v,
    );
  };
  return (
    <div css={SS.tactMainRibbon}>
      <RibbonCollapse
        title={'Graph Color Setting'}
        defaultValue={true}
        css={SS.settingContentStyle}
      >
        <div className="svg-box">
          <FormatPainterOutlined />
        </div>
        <div css={SS.ColorBox}>
          {TACT_GRAPH_COLOR_LIST[mode].map((item, i) => {
            const colorList =
              TACT_GRAPH_COLOR_LIST[mode].length > 1 ? color[item.id] : color;
            return (
              <React.Fragment key={i}>
                {colorList === undefined ? (
                  <></>
                ) : (
                  <div css={SS.tactGraphColorSettingStyle}>
                    <div css={SS.testDropDown}>
                      <span className="dropdown">
                        <Button
                          css={SS.tactGraphColorButtonStyle}
                          className="dropBtn"
                          onClick={() =>
                            setColorMenu((prev) => (prev ? false : i))
                          }
                        >
                          {item.title}
                          <DownCircleFilled />
                        </Button>
                        {colorMenu === i ? (
                          <div className="dropdown-content">
                            <GraphColorMenu
                              closer={() => setColorMenu(false)}
                              changeFunc={(v) => ChangeFunc(item.id, v)}
                              colorList={colorList}
                            />
                          </div>
                        ) : (
                          ''
                        )}
                      </span>
                    </div>
                    <div css={SS.divSubColorStyle}>
                      {Object.keys(colorList ?? {}).map((job, i) => (
                        <div css={SS.subColorStyle} key={i}>
                          <button
                            className="rc-color-picker-trigger"
                            style={{ backgroundColor: `${colorList[job]}` }}
                          />
                          <span>{job}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </RibbonCollapse>
    </div>
  );
};
GraphColorSetting.propTypes = {
  mode: PropTypes.string,
  color: PropTypes.object,
  updateColor: PropTypes.func,
};
export default GraphColorSetting;
