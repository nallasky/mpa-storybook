import * as SS from './styles/statusStyles';
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Panel from 'rc-color-picker/lib/Panel';
import { CloseOutlined } from '@ant-design/icons';

export const GraphColorMenu = ({ closer, colorList, changeFunc }) => {
  const [currentColor, setCurrentColor] = useState({
    selected: null,
    color: null,
  });
  const [innerColorList, setInnerColorList] = useState(colorList);

  const changeColor = (colors) => {
    const { color } = colors;
    setCurrentColor({
      ...currentColor,
      color: color,
    });
    setInnerColorList(
      Object.keys(innerColorList).reduce(
        (acc, item) =>
          item === currentColor.selected
            ? { ...acc, [item]: color }
            : { ...acc, [item]: innerColorList[item] },
        {},
      ),
    );
  };

  const onApply = () => {
    changeFunc(innerColorList);
    closer();
  };
  const onCloser = () => {
    closer();
  };

  useEffect(() => {
    const list = Object.keys(colorList);
    if (list.length > 0) {
      setCurrentColor({
        selected: list[0],
        color: colorList[list[0]],
      });
    }
  }, []);

  return (
    <>
      <div css={SS.colorSettingStyle}>
        <span>Color Setting</span>
        <button onClick={onCloser}>
          <CloseOutlined />
        </button>
      </div>
      <div css={SS.tactColorBoxStyle}>
        <div>
          {Object.keys(innerColorList).map((item, i) => (
            <div
              css={SS.SelectColorStyle}
              key={i}
              onClick={() =>
                setCurrentColor({
                  selected: item,
                  color: innerColorList[item],
                })
              }
              tabIndex="-1"
              onKeyDown={undefined}
              role="button"
              className={currentColor.selected === item ? 'selected' : ''}
            >
              <button
                className="rc-color-picker-trigger"
                style={{ backgroundColor: `${innerColorList[item]}` }}
              />
              <div style={{ display: 'block', fontWeight: 'bold' }}>
                <div>{item}</div>
                <div>{innerColorList[item]}</div>
              </div>
            </div>
          ))}
        </div>
        <div>
          <Panel
            enableAlpha={false}
            color={currentColor.color}
            onChange={changeColor}
          />
        </div>
        <div css={SS.customButtonStyle} className="color-picker">
          <button
            css={SS.antdButtonStyle}
            className="blue color-picker"
            onClick={onApply}
          >
            Apply
          </button>
        </div>
      </div>
    </>
  );
};

GraphColorMenu.defaultProps = {
  colorList: [],
};
GraphColorMenu.propTypes = {
  closer: PropTypes.func.isRequired,
  colorList: PropTypes.object,
  changeFunc: PropTypes.func.isRequired,
};
