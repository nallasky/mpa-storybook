import React, {
  useMemo,
  useCallback,
  useLayoutEffect,
  useState,
  useEffect,
} from 'react';
import * as SS from './styles/statusStyles';
import PropTypes from 'prop-types';
import Plotly from 'plotly.js-dist';
import { tactScriptMap } from '@constants/TactDefault';
import {
  E_TACT_GRAPH_ADC,
  E_TACT_GRAPH_ADC_FDC_ALL,
  E_TACT_GRAPH_FDC,
  E_TACT_GRAPH_PLATE_DETAIL_DIFF_SCRIPT,
  E_TACT_GRAPH_PLATE_DIFF_SCRIPT,
  E_TACT_STATUS_JOB_TACT,
  E_TACT_STATUS_PLATE_DETAIL_TACT,
  E_TACT_STATUS_PLATE_DETAIL_TACT_DIFF,
  E_TACT_STATUS_PLATE_TACT,
  E_TACT_STATUS_PLATE_TACT_DIFF,
} from '@constants/etc';
import useTactStatusGraphSetting from './hooks/useTactStatusGraphSetting';
import { getParseJsonData } from '@libs/util/util';
import StatusGraphTable from './StatusGraphTable';
import { Button } from 'antd';
import { ExpandAltOutlined, ShrinkOutlined } from '@ant-design/icons';
import NewWindowForm from '../../common/molecules/NewWindowForm/NewWindowForm';

const DrawGraph = ({ div_id, isPredict, ScriptId, halfType }) => {
  const [showWindowPortal, setShowWindowPortal] = useState({
    enable: false,
    element: undefined,
  });
  const toggleWindowPortal = (div_id) => {
    setShowWindowPortal((prevState) =>
      prevState.enable
        ? { enable: false, element: undefined }
        : { enable: true, element: document.getElementById(div_id) },
    );
  };
  const graphStyles =
    ![
      E_TACT_GRAPH_PLATE_DIFF_SCRIPT,
      E_TACT_GRAPH_PLATE_DETAIL_DIFF_SCRIPT,
    ].includes(ScriptId) ||
    (isPredict ?? false)
      ? { overflowX: 'auto', maxWidth: halfType ? '890px' : '1755px' }
      : {
          display: 'none',
        };
  const closeWindowPortal = () => {
    setShowWindowPortal({ enable: false, element: undefined });
  };
  useEffect(() => {
    window.addEventListener('beforeunload', () => {
      closeWindowPortal();
    });
    return () => {
      setShowWindowPortal({ enable: false, element: undefined });
    };
  }, []);
  return (
    <>
      {showWindowPortal.enable && (
        <NewWindowForm
          enable={showWindowPortal?.enable ?? false}
          title={ScriptId}
          div_id={div_id}
          closeWindowPortal={closeWindowPortal}
        />
      )}
      <div className={halfType ? 'diffGraph' : ''} style={graphStyles}>
        <Button
          onClick={() => toggleWindowPortal(div_id)}
          icon={
            showWindowPortal?.enable ? (
              <ShrinkOutlined />
            ) : (
              <ExpandAltOutlined />
            )
          }
          type={'dashed'}
          shape={'circle'}
        />
        <div id={div_id} />
      </div>
    </>
  );
};
DrawGraph.propTypes = {
  div_id: PropTypes.string,
  isPredict: PropTypes.bool,
  ScriptId: PropTypes.string,
  halfType: PropTypes.bool,
};

const StatusGraph = ({ mode, updateModeFunc }) => {
  if (mode.current === undefined) return <></>;
  const current = useMemo(() => mode.current, [mode.current]);
  const dataList = useMemo(() => mode.dataList, [mode.dataList]);
  const compare_data = useMemo(
    () => mode?.dataList?.[`${mode.current}_diff`],
    [mode?.dataList?.[`${mode.current}_diff`], mode.current],
  );
  const original_data = useMemo(
    () => mode?.dataList?.[mode.current],
    [mode?.dataList?.[mode.current], mode.current],
  );
  const {
    startPlateTact,
    startPlateDetailTact,
    plateTactSelectPeriod,
    gTactStatusCompareJob,
    gTactStatusComparePeriod,
  } = useTactStatusGraphSetting();
  const currentSetting = useMemo(
    () =>
      mode.current === E_TACT_STATUS_JOB_TACT
        ? {
            ...(mode.setting?.[mode.current] ?? []),
            job: Object.keys(mode.dataList?.[current] ?? {}),
            color: mode.setting?.[current]?.color,
          }
        : {
            ...(mode.setting?.[mode.current] ?? []),
            color: mode.setting?.[current]?.color,
          },
    [mode.current, mode.setting?.[mode.current]],
  );
  const event_handler = (job_name, graph_id, isCompare) => {
    console.log('selected job name', job_name);
    console.log('selected graph_id', graph_id);

    if (current === E_TACT_STATUS_JOB_TACT) {
      startPlateTact({
        updateFunc: updateModeFunc,
        job: job_name,
        setting: currentSetting,
        isCompare: false,
        sPeriod: undefined, //default
      });
    } else if (current === E_TACT_STATUS_PLATE_TACT) {
      startPlateDetailTact(
        updateModeFunc,
        ...job_name,
        currentSetting,
        isCompare,
      );
    }
  };

  const RenderGraph = useCallback(
    ({ renderFunc, element, graph_id, isCompare }) =>
      renderFunc({
        Plotly,
        element,
        isComparison: isCompare,
        org_data: mode.dataList?.[isCompare ? `${current}_diff` : current],
        setting: currentSetting,
        event_handler: ![
          E_TACT_GRAPH_PLATE_DIFF_SCRIPT,
          E_TACT_GRAPH_PLATE_DETAIL_DIFF_SCRIPT,
        ].includes(graph_id)
          ? (e) => event_handler(e, graph_id, isCompare)
          : undefined,
      }),
    [current, event_handler, currentSetting, mode.dataList],
  );

  const DrawJobAndPlateTactGraph = useCallback(
    (type) =>
      getParseJsonData(tactScriptMap[current].script).map((graph, i) => {
        console.log('[DrawJobAndPlateTactGraph] dataList', dataList);
        const drawDiffGraph = (graph, divId) =>
          (dataList?.[`${current}_diff`] ?? false) &&
          RenderGraph({
            renderFunc: graph.value,
            element: divId,
            graph_id: graph.id,
            isCompare: true,
          });
        const drawGraph = (graph, divId) =>
          (dataList?.[current] ?? false) &&
          RenderGraph({
            renderFunc: graph.value,
            element: divId,
            graph_id: graph.id,
            isCompare: false,
          });

        if (
          !graph.id.includes('_diff') ||
          (graph.id.includes('_diff') &&
            (mode.setting?.[E_TACT_STATUS_PLATE_TACT]?.predictive_value ??
              false))
        ) {
          if (type === 'all') {
            drawGraph(graph, `${current}_${i}`);
            drawDiffGraph(graph, `${current}_diff_${i}`);
          } else if (type === 'original') {
            drawGraph(graph, `${current}_${i}`);
          } else {
            drawDiffGraph(graph, `${current}_diff_${i}`);
          }
        }
      }),
    [
      current,
      dataList,
      mode.setting?.[E_TACT_STATUS_PLATE_TACT]?.predictive_value,
      RenderGraph,
    ],
  );
  useLayoutEffect(() => {
    console.log('[useLayoutEffect]change setting', currentSetting);
    DrawJobAndPlateTactGraph('all');
  }, [
    mode.setting?.[E_TACT_STATUS_JOB_TACT]?.unit,
    mode.setting?.[E_TACT_STATUS_JOB_TACT]?.display_outlier,
    mode.setting?.[E_TACT_STATUS_JOB_TACT]?.y_lower_limit,
    mode.setting?.[E_TACT_STATUS_JOB_TACT]?.y_upper_limit,
    mode.setting?.[E_TACT_STATUS_PLATE_TACT]?.y_upper_limit,
    mode.setting?.[E_TACT_STATUS_PLATE_TACT]?.predictive_value,
    mode.setting?.[E_TACT_STATUS_PLATE_DETAIL_TACT]?.scale_unit,
    mode.setting?.[E_TACT_STATUS_JOB_TACT]?.color,
    mode.setting?.[E_TACT_STATUS_PLATE_TACT]?.color,
    mode.setting?.[E_TACT_STATUS_PLATE_DETAIL_TACT]?.color,
  ]);
  useLayoutEffect(() => {
    console.log('[useLayoutEffect] diff', mode?.dataList?.[`${current}_diff`]);
    DrawJobAndPlateTactGraph('diff');
  }, [
    dataList?.[E_TACT_STATUS_PLATE_TACT_DIFF],
    dataList?.[E_TACT_STATUS_PLATE_DETAIL_TACT_DIFF],
  ]);
  useLayoutEffect(() => {
    console.log('[useLayoutEffect] origin', mode?.dataList?.[current]);
    DrawJobAndPlateTactGraph('original');
  }, [
    dataList?.[E_TACT_STATUS_JOB_TACT],
    dataList?.[E_TACT_STATUS_PLATE_TACT],
    dataList?.[E_TACT_STATUS_PLATE_DETAIL_TACT],
  ]);

  useLayoutEffect(() => {
    console.log(
      '[useLayoutEffect]change plate_adc_fdc',
      mode.setting?.[E_TACT_STATUS_PLATE_TACT]?.adc_fdc,
    );
    console.log(
      '[useLayoutEffect]change job_adc_fdc',
      mode.setting?.[E_TACT_STATUS_JOB_TACT]?.adc_fdc,
    );
    if (current === E_TACT_STATUS_JOB_TACT) {
      DrawJobAndPlateTactGraph('original');
    } else {
      if (
        [E_TACT_GRAPH_FDC, E_TACT_GRAPH_ADC, E_TACT_GRAPH_ADC_FDC_ALL].includes(
          currentSetting.adc_fdc,
        )
      ) {
        console.log('startPlateTact  original');
        startPlateTact({
          updateFunc: updateModeFunc,
          setting: currentSetting,
          job: currentSetting.job,
          sPeriod: undefined, //default
          isCompare: false,
        });
        if (compare_data ?? false) {
          console.log('startPlateTact diff');
          startPlateTact({
            updateFunc: updateModeFunc,
            setting: currentSetting,
            job: currentSetting.compareJob,
            sPeriod: currentSetting.comparePeriod,
            isCompare: true,
          });
        }
      }
    }
  }, [
    mode.setting?.[E_TACT_STATUS_PLATE_TACT]?.adc_fdc, // job_tact
    mode.setting?.[E_TACT_STATUS_JOB_TACT]?.adc_fdc, // job_tact
  ]);

  return (
    <>
      <div
        css={SS.componentStyle}
        className={
          (current === E_TACT_STATUS_PLATE_DETAIL_TACT
            ? 'gridColumn'
            : 'span') +
          ((compare_data ?? false) && (original_data ?? false)
            ? ' diffGraph'
            : '')
        }
      >
        {mode?.options.map((tactObj) => (
          <>
            <div
              style={
                tactObj.id === current && (original_data ?? false)
                  ? {}
                  : { display: 'none' }
              }
            >
              <div
                className="Plate-Period"
                style={
                  tactObj.id !== E_TACT_STATUS_JOB_TACT
                    ? {}
                    : { display: 'none' }
                }
              >
                <span>{`[${currentSetting.job}] ${plateTactSelectPeriod}`}</span>
              </div>
              <div
                css={
                  tactObj.id === E_TACT_STATUS_PLATE_TACT
                    ? SS.PlateGraphStyle
                    : {}
                }
                className={
                  tactObj.id === E_TACT_STATUS_JOB_TACT ? '' : 'dashed'
                }
              >
                {getParseJsonData(tactScriptMap[tactObj.id].script).map(
                  (obj, i) => (
                    <>
                      {' '}
                      <DrawGraph
                        isPredict={
                          mode.setting?.[E_TACT_STATUS_PLATE_TACT]
                            ?.predictive_value ?? false
                        }
                        div_id={`${tactObj.id}_${i}`}
                        ScriptId={obj.id}
                        halfType={
                          (compare_data ?? false) && (original_data ?? false)
                        }
                      />
                    </>
                  ),
                )}
                <StatusGraphTable
                  isVisible={
                    tactObj.id === E_TACT_STATUS_PLATE_TACT &&
                    (mode.setting?.[tactObj.id]?.show_data_table ?? false)
                  }
                  setting={mode.setting?.[tactObj.id]}
                  data={mode.dataList?.[tactObj.id]}
                />
              </div>
            </div>
          </>
        ))}
        {[E_TACT_STATUS_PLATE_TACT, E_TACT_STATUS_PLATE_DETAIL_TACT].map(
          (tactDiffObj) => (
            <>
              <div
                css={SS.componentStyle}
                className="diffPlate"
                style={
                  tactDiffObj === current && (compare_data ?? false)
                    ? {}
                    : { display: 'none' }
                }
              >
                <div className="Plate-Period">
                  <span>{`[${gTactStatusCompareJob}] ${gTactStatusComparePeriod}`}</span>
                </div>
                <div className="dashed">
                  {getParseJsonData(tactScriptMap[tactDiffObj].script).map(
                    (scriptObj, i) => (
                      <>
                        {' '}
                        <DrawGraph
                          isPredict={
                            mode.setting?.[E_TACT_STATUS_PLATE_TACT]
                              ?.predictive_value ?? false
                          }
                          div_id={`${tactDiffObj}_diff_${i}`}
                          ScriptId={scriptObj.id}
                          halfType={
                            (compare_data ?? false) && (original_data ?? false)
                          }
                        />
                      </>
                    ),
                  )}
                  <StatusGraphTable
                    isVisible={
                      tactDiffObj === E_TACT_STATUS_PLATE_TACT &&
                      (mode.setting?.[tactDiffObj]?.show_data_table ?? false)
                    }
                    setting={mode.setting?.[tactDiffObj]}
                    data={mode.dataList?.[`${tactDiffObj}_diff`]}
                  />
                </div>
              </div>
            </>
          ),
        )}
      </div>
    </>
  );
};
StatusGraph.propTypes = {
  mode: PropTypes.object,
  updateModeFunc: PropTypes.func,
};
export default StatusGraph;
