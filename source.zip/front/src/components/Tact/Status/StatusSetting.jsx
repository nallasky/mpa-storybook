import React from 'react';
import PropTypes from 'prop-types';
import * as SS from './styles/statusStyles';
import CustomRadioGroup from '../../common/molecules/CustomRadioGroup/CustomRadioGroup';
import GraphSetting from './GraphSetting';
import GraphColorSetting from './GraphColorSetting';
import ComparisonSetting from './ComparisonSetting';
import StatusResultDownload from './StatusResultDownload';

const StatusSetting = ({ mode, updateModeFunc }) => {
  if (mode.current === undefined) return <></>;
  return (
    <>
      <div css={SS.componentStyle} className="span">
        <div css={SS.controlStyle} className="tact">
          <div>
            <CustomRadioGroup
              changeFunc={(v) =>
                updateModeFunc((pre) => ({ ...pre, current: v }))
              }
              initialValue={mode.current}
              options={mode?.options ?? []}
            />
          </div>
          <StatusResultDownload mode={mode} />
        </div>
        <ComparisonSetting
          mode={mode.current}
          setting={mode.setting[mode.current]}
          updateModeFunc={updateModeFunc}
        />
        <GraphSetting
          mode={mode.current}
          setting={mode.setting[mode.current]}
          updateSetting={(e) =>
            updateModeFunc((prev) => ({
              ...prev,
              setting: { ...prev.setting, [mode.current]: e },
            }))
          }
        />
        <GraphColorSetting
          mode={mode.current}
          color={mode.setting[mode.current]?.color ?? {}}
          updateColor={(e) =>
            updateModeFunc((prev) => ({
              ...prev,
              setting: {
                ...prev.setting,
                [mode.current]: { ...prev.setting[mode.current], color: e },
              },
            }))
          }
        />
      </div>
    </>
  );
};
StatusSetting.propTypes = {
  mode: PropTypes.object,
  updateModeFunc: PropTypes.func,
};

export default StatusSetting;
