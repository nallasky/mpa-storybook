import { useState } from 'react';
import {
  usePostImportSetting,
  usePutTactSettingInfo,
} from '../../../../hooks/query/tactSetting';
import { RequestOnError } from '../../../../libs/util/common/common';
import {
  E_TACT_SETTING_PRIMARY_PU_SETTING,
  E_TACT_SETTING_REFERENCE_PU,
} from '../../../../constants/etc';
import { TACT_SET_DATA } from '../../../../constants/TactDefault';
import useTactSetting from './useTactSetting';

const importValueDefault = {
  file_name: undefined,
  file_data: [],
};
const useTactImportSetting = () => {
  const [isVisible, setVisible] = useState(false);
  const [isProcessing, setProcessing] = useState(false);
  const [importFile, setImportFile] = useState(importValueDefault);
  const [puName, setPuName] = useState({ name: null, status: '' });
  const [refPuList, setRefPuList] = useState(null);
  const { gPrimaryPuList } = useTactSetting();

  const updateSetting = usePostImportSetting();
  const updateRefSetting = usePutTactSettingInfo();
  const openImportModal = () => {
    setVisible(true);
  };
  const closeImportModal = () => {
    setVisible(false);
  };

  const startImportFile = (mode, sub_mode, close, success, modeChange) => {
    if (mode === E_TACT_SETTING_REFERENCE_PU) {
      const obj = [];
      refPuList.forEach((o) => {
        const clone = { ...o };
        delete clone.index;
        obj.push(clone);
      });
      updateRefSetting.mutate(
        {
          tab: mode,
          sub_mode: undefined,
          obj,
        },
        {
          onSuccess: () => {
            success({
              mode: mode,
              isUpdate: true,
            });
            close();
          },
          onError: RequestOnError,
        },
      );
    } else {
      const formData = new FormData();
      formData.append('files', importFile.file_data[0]);
      updateSetting.mutate(
        {
          tab: mode,
          pu_name: sub_mode,
          formData,
        },
        {
          onSuccess: () => {
            console.log('startImportFile onSuccess', mode);
            success({ mode, isUpdate: true });
            if (mode === E_TACT_SETTING_PRIMARY_PU_SETTING) {
              modeChange({
                mode: E_TACT_SETTING_PRIMARY_PU_SETTING,
                subMode: sub_mode,
              });
            }
            close();
          },
          //onSettled: close,
          onError: (err) => {
            console.log('startImportFile onError');
            RequestOnError(err);
            close();
          },
        },
      );
    }
  };

  const startPreviewFile = (mode, sub_mode, close) => {
    const formData = new FormData();
    formData.append('files', importFile.file_data[0]);
    updateSetting.mutate(
      {
        tab: mode,
        pu_name: sub_mode,
        formData,
      },
      {
        onSuccess: (data) => {
          const newData = data.map((n, idx) => ({
            ...n,
            [TACT_SET_DATA.TACT_SET_INDEX]: idx,
            [TACT_SET_DATA.TACT_SET_ID]: null,
          }));
          setRefPuList(newData);
          setProcessing(false);
        },
        //onSettled: close,
        onError: (err) => {
          console.log('startImportFile onError');
          RequestOnError(err);
          close();
        },
      },
    );
  };

  const clearImportFile = () => {
    setImportFile(importValueDefault);
    setPuName({ name: null, status: '' });
    setRefPuList(null);
  };
  const getImportProps = () => {
    return {
      name: 'files',
      action: '', //backend server
      fileList: importFile.file_data,
      maxCount: '1',
      beforeUpload: (f) => {
        console.log('valid beforeUpload', f);
        setImportFile((prev) => ({
          ...prev,
          file_name: f?.name,
          file_data: [f],
        }));
        return false;
      },
      onRemove: () => {
        setImportFile(importValueDefault);
      },
    };
  };
  const updatePuName = (pu_name) => {
    setPuName({
      name: pu_name,
      status: gPrimaryPuList.includes(pu_name) ? 'warning' : '',
    });
  };

  return {
    isImportModalVisible: isVisible,
    openImportModal,
    closeImportModal,
    startImportFile,
    startPreviewFile,
    fileName: importFile.file_name,
    fileList: importFile.files,
    clearImportFile,
    getImportProps,
    puName,
    setPuName,
    refPuList,
    setRefPuList,
    updatePuName,
    isProcessing,
    setProcessing,
  };
};

export default useTactImportSetting;
