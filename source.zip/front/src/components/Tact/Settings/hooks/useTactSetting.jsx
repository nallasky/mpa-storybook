import React, { useCallback, useMemo, useState, createContext } from 'react';
import {
  PLATE_TACT,
  TACT_PRIMARY_PU_LIST,
  TACT_SET_DATA,
  TACT_SETTING_LIST,
} from '../../../../constants/TactDefault';
import { useDispatch, useSelector } from 'react-redux';
import {
  getTactSetting,
  initialSettingReducer,
  UpdateTactALLSettingReducer,
  UpdateTactSettingReducer,
} from '../../../../reducers/slices/TactInfo';
import {
  E_TACT_SETTING_ALL,
  E_TACT_SETTING_PLATE,
  E_TACT_SETTING_PLATE_EVENT,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
} from '../../../../constants/etc';
import { Button } from 'antd';
import DeleteOutlined from '@ant-design/icons/lib/icons/DeleteOutlined';
import { SortableHandle } from 'react-sortable-hoc';
import { MenuOutlined } from '@ant-design/icons';
import {
  useDeletePrimaryPuName,
  useGetTactSettingDownload,
  useGetTactSettingInfo,
  usePutPrimaryPuName,
  usePutTactSettingInfo,
} from '../../../../hooks/query/tactSetting';
import { RequestOnError } from '../../../../libs/util/common/common';
import { NotificationBox } from '../../../common/molecules/NotificationBox';

const InitialTactEditMode = {
  isEdit: false,
  mode: undefined,
  data: undefined,
};
const DragHandle = SortableHandle(() => (
  <MenuOutlined style={{ cursor: 'grab', color: '#999' }} />
));
const useTactSetting = () => {
  const [mode, setMode] = useState({ main: PLATE_TACT, sub: undefined });
  const [isUpdate, setUpdate] = useState({ mode: undefined, isUpdate: false });
  const [downloading, setDownloading] = useState(false);
  const [editMode, setEditMode] = useState(InitialTactEditMode);
  const [PrimaryPUSet, updatePrimaryPUSet] = useState({
    isMode: false,
    list: [],
  });
  const [newPrimaryPUName, setNewPrimaryPUName] = useState(null);
  const dispatch = useDispatch();
  const gTactSettings = useSelector(getTactSetting);
  const deletePuName = useDeletePrimaryPuName();
  const addPuName = usePutPrimaryPuName();
  const putTactSetting = usePutTactSettingInfo();
  const reqTactSetting = useGetTactSettingInfo({
    tab: isUpdate.mode,
    options: {
      enabled: isUpdate.isUpdate,
      onError: RequestOnError,
      onSuccess: (data) => RequestOnSuccess(data, isUpdate.mode),
      onSettled: () => setUpdate({ mode: undefined, isUpdate: false }),
    },
  });
  const tactSettingDownload = useGetTactSettingDownload({
    options: {
      enabled: !!downloading,
      onError: RequestOnError,
      onSuccess: () =>
        NotificationBox({
          title: 'Download Success',
          message: 'Tact Settings Downloaded successful.',
          time: 3,
          isError: false,
        }),
      onSettled: () => setDownloading(false),
    },
    key: !!downloading,
  });

  const gPrimaryPuList = useMemo(
    () => Object.keys(gTactSettings[E_TACT_SETTING_PRIMARY_PU_SETTING]),
    [gTactSettings[E_TACT_SETTING_PRIMARY_PU_SETTING]],
  );
  const gEventKindList = useMemo(
    () =>
      gTactSettings[E_TACT_SETTING_PLATE_EVENT].map(
        (o) => o[TACT_SET_DATA.TACT_SET_EVENT_KIND],
      ),
    [gTactSettings[E_TACT_SETTING_PLATE_EVENT]],
  );
  const tactSettingSelectList = useMemo(
    () => ({
      [TACT_SET_DATA.TACT_SET_EVENT_START]: gEventKindList,
      [TACT_SET_DATA.TACT_SET_EVENT_END]: gEventKindList,
      [TACT_SET_DATA.TACT_SET_EVENT_CATEGORY]: gTactSettings[
        E_TACT_SETTING_PLATE
      ].map((o) => o[TACT_SET_DATA.TACT_SET_CATEGORY]),
      [TACT_SET_DATA.TACT_SET_EVENT_DISPLAY]: { true: 'Show', false: 'Hide' },
      [TACT_SET_DATA.TACT_SET_PRIMARY_PU_LEVEL]: [0, 1, 2, 3],
      [TACT_SET_DATA.TACT_SET_REFERENCE_PU_PRIMARY_PU]: gPrimaryPuList,
    }),
    [editMode.isEdit],
  );

  const deleteColumn = (data, setFunc) => ({
    title: 'Delete',
    dataIndex: 'x',
    // eslint-disable-next-line react/display-name
    render: (_, record) => (
      <Button
        type="dashed"
        icon={<DeleteOutlined />}
        onClick={() => {
          setFunc(data.filter((item) => item.index !== record.index));
        }}
      />
    ),
  });
  const sortColumns = {
    title: 'Sort',
    dataIndex: 'sort',
    className: 'drag-visible',
    // eslint-disable-next-line react/display-name
    render: () => <DragHandle />,
  };
  const initialSetting = useCallback(() => {
    dispatch(initialSettingReducer());
  }, [dispatch]);
  //------------------------------------------------------------------------
  const updateTactSetting = useCallback(
    (mode, value) => {
      if (mode === E_TACT_SETTING_ALL) {
        dispatch(UpdateTactALLSettingReducer(value));
      } else {
        dispatch(UpdateTactSettingReducer({ [mode]: value }));
      }
    },
    [dispatch],
  );
  //------------------------------------------------------------------------
  const changeModeFunc = ({ mode, subMode }) => {
    const findType = [...TACT_SETTING_LIST, ...TACT_PRIMARY_PU_LIST].find(
      (o) => o.id === mode,
    );
    if (findType !== undefined) {
      setMode({ main: findType, sub: subMode });
    } else {
      console.log('not support tact setting type : ', mode);
    }
  };

  const selectPrimaryPUSetting = (v) => {
    if (v === true) {
      updatePrimaryPUSet({
        isMode: true,
        list: Object.keys(gTactSettings[E_TACT_SETTING_PRIMARY_PU_SETTING]).map(
          (x) => (typeof x === 'string' ? { name: x, disableHover: false } : x),
        ),
      });
    } else {
      updatePrimaryPUSet({ isMode: false, list: [] });
    }
  };
  const updatePrimaryPuList = (nList) => {
    updatePrimaryPUSet((prev) => ({
      ...prev,
      list: nList.map((v) =>
        typeof v === 'string' ? { name: v, disableHover: false } : v,
      ),
    }));
  };

  const deletePrimaryPUName = (pu_name, success, modeChange) => {
    console.log('deletePrimaryPUName', pu_name);
    deletePuName.mutate(
      {
        tab: E_TACT_SETTING_PRIMARY_PU_SETTING,
        pu_name: pu_name,
      },
      {
        onSuccess: () => {
          success({
            mode: E_TACT_SETTING_PRIMARY_PU_SETTING,
            isUpdate: true,
          });
          modeChange({
            mode: E_TACT_SETTING_PRIMARY_PU_SETTING,
            subMode: undefined,
          });
        },
        //onSettled: close,
        onError: RequestOnError,
      },
    );
  };
  const addPrimaryPUName = (pu_name, clear_pu_name, success, modeChange) => {
    console.log('addPrimaryPUName', pu_name);
    addPuName.mutate(
      {
        tab: E_TACT_SETTING_PRIMARY_PU_SETTING,
        pu_name: pu_name,
      },
      {
        onSuccess: () => {
          success({
            mode: E_TACT_SETTING_PRIMARY_PU_SETTING,
            isUpdate: true,
          });
          modeChange({
            mode: E_TACT_SETTING_PRIMARY_PU_SETTING,
            subMode: pu_name,
          });
          clear_pu_name();
        },
        //onSettled: close,
        onError: RequestOnError,
      },
    );
  };

  const updatePrimaryPUName = (pu_name) => {
    console.log('updatePrimaryPUName', pu_name);
    setNewPrimaryPUName(pu_name);
  };
  const checkPrimaryPUName = (pu_name, pu_list) =>
    (pu_name ?? []).length === 0
      ? 'warning'
      : pu_list.map((v) => v.name).includes(pu_name)
      ? 'error'
      : '';

  //---------------------------------------------

  const AddHandler = (mode, data, setFunc) => {
    console.log('editMode', data);
    const nextIndex = Math.max(...data.map((obj) => obj.index)) + 1;
    setFunc((prev) => ({
      ...prev,
      data: [
        ...data,
        mode === E_TACT_SETTING_PLATE
          ? {
              [TACT_SET_DATA.TACT_SET_ID]: null,
              [TACT_SET_DATA.TACT_SET_INDEX]: nextIndex,
              [TACT_SET_DATA.TACT_SET_DISPLAY_ORDER]:
                Math.max(
                  ...data.map(
                    (obj) => obj[TACT_SET_DATA.TACT_SET_DISPLAY_ORDER],
                  ),
                ) + 1,
            }
          : {
              [TACT_SET_DATA.TACT_SET_ID]: null,
              [TACT_SET_DATA.TACT_SET_INDEX]: nextIndex,
            },
      ],
    }));
  };
  const saveTactSetting = (main, sub, data, success) => {
    console.log('[saveTactSetting] data', data);
    console.log('[saveTactSetting] main', main, '  Sub: ', sub);
    const obj = [];
    data.forEach((o) => {
      const clone = { ...o };
      delete clone.index;
      obj.push(clone);
    });
    putTactSetting.mutate(
      {
        tab: main,
        pu_name: sub,
        obj,
      },
      {
        onSuccess: () => {
          success({
            mode: main,
            isUpdate: true,
          });
        },
        onError: RequestOnError,
      },
    );
  };

  //--------------------------------------------------------------------
  const RequestOnSuccess = (data, mode) => {
    console.log('data', data);
    console.log('mode', mode);
    updateTactSetting(mode, data?.[mode] ?? data);
  };
  return {
    initialSetting,
    mode,
    changeModeFunc,
    reqTactSetting,
    settingUpdate: isUpdate,
    setSettingUpdate: setUpdate,

    //object variable
    deleteColumn,
    sortColumns,
    tactSettingSelectList,

    //EditMode
    editMode,
    setEditMode,
    saveTactSetting,
    AddHandler,

    //Axios Request Result Control
    onSuccess: RequestOnSuccess,
    onError: RequestOnError,

    //redux
    gTactSettings,
    updateTactSetting,
    InitialTactEditMode,

    //primary Pu
    PrimaryPUSet,
    gPrimaryPuList,
    updatePrimaryPuList,
    selectPrimaryPUSetting,
    deletePrimaryPUName,
    addPrimaryPUName,
    newPrimaryPUName,
    updatePrimaryPUName,
    checkPrimaryPUName,
    setDownloading,
    tactSettingDownload,
  };
};
export default useTactSetting;
export const TactSettingInfo = createContext(null);
