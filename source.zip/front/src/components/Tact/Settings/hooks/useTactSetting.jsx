import React, { useCallback, useState } from 'react';
import {
  PLATE_TACT,
  TACT_PRIMARY_PU_LIST,
  TACT_SETTING_LIST,
} from '../../../../constants/TactDefault';
import { NotificationBox } from '../../../common/molecules/NotificationBox';
import { tact_setting } from '../../../../constants/tmpTactSetting';
import { useDispatch, useSelector } from 'react-redux';
import {
  getTactSetting,
  UpdateTactALLSettingReducer,
  UpdateTactSettingReducer,
} from '../../../../reducers/slices/TactInfo';
import {
  E_TACT_SETTING_ALL,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
} from '../../../../constants/etc';
import { Button } from 'antd';
import DeleteOutlined from '@ant-design/icons/lib/icons/DeleteOutlined';
import { SortableHandle } from 'react-sortable-hoc';
import { MenuOutlined } from '@ant-design/icons';

const InitialTactEditMode = {
  isEdit: false,
  mode: undefined,
  data: undefined,
};
const DragHandle = SortableHandle(() => (
  <MenuOutlined style={{ cursor: 'grab', color: '#999' }} />
));
const useTactSetting = () => {
  const [mode, setMode] = useState({ main: PLATE_TACT, sub: undefined });
  const [isVisible, setVisible] = useState(false);
  const [editMode, updateEditMode] = useState(InitialTactEditMode);
  const [PrimaryPUSet, updatePrimaryPUSet] = useState({
    isMode: false,
    list: [],
  });

  const dispatch = useDispatch();
  const gTactSettings = useSelector(getTactSetting);

  const deleteColumn = (data, setFunc) => ({
    title: 'Delete',
    dataIndex: 'x',
    // eslint-disable-next-line react/display-name
    render: (_, record) => (
      <Button
        type="dashed"
        icon={<DeleteOutlined />}
        onClick={() => {
          setFunc(data.filter((item) => item.index !== record.index));
        }}
      />
    ),
  });
  const sortColumns = {
    title: 'Sort',
    dataIndex: 'sort',
    className: 'drag-visible',
    // eslint-disable-next-line react/display-name
    render: () => <DragHandle />,
  };

  const initialSetting = () => {
    console.log('initialSetting');
  };
  //------------------------------------------------------------------------
  const updateTactSetting = useCallback(
    (mode, value) => {
      if (mode === E_TACT_SETTING_ALL) {
        dispatch(UpdateTactALLSettingReducer(value));
      } else {
        dispatch(UpdateTactSettingReducer({ [mode]: value }));
      }
    },
    [dispatch],
  );
  //------------------------------------------------------------------------
  const changeModeFunc = ({ mode, subMode }) => {
    const findType = [...TACT_SETTING_LIST, ...TACT_PRIMARY_PU_LIST].find(
      (o) => o.id === mode,
    );
    if (findType !== undefined) {
      setMode({ main: findType, sub: subMode });
    } else {
      console.log('not support tact setting type : ', mode);
    }
  };
  //E_TACT_SETTING_PLATE,
  const setEditMode = (settingMode) => {
    console.log('setEditMode', settingMode);
    if (settingMode === undefined) {
      updateEditMode(InitialTactEditMode);
    } else {
      updateEditMode({
        isEdit: true,
        mode: settingMode,
        data: gTactSettings[settingMode],
      });
    }
  };
  const selectPrimaryPUSetting = (v) => {
    if (v === true) {
      updatePrimaryPUSet({
        isMode: true,
        list: Object.keys(gTactSettings[E_TACT_SETTING_PRIMARY_PU_SETTING])
      });
    } else {
      updatePrimaryPUSet({ isMode: false, list: [] });
    }
  };

  //---------------------------------------------
  const openImportModal = () => {
    setVisible(true);
  };
  const closeImportModal = () => {
    setVisible(false);
  };
  const AddHandler = (data, setFunc) => {
    console.log('editMode', data);
    const nextIndex = Math.max(...data.map((obj) => obj.index)) + 1;
    setFunc((prev) => ({
      ...prev,
      data: [...data, { id: null, index: nextIndex }],
    }));
  };
  const saveTactSetting = (settingMode, data) => {
    console.log('saveSetting', settingMode);
    console.log('data', data);
  };

  //--------------------------------------------------------------------
  const RequestOnSuccess = (data) => {
    console.log('data', data);
    updateTactSetting(E_TACT_SETTING_ALL, data);
  };
  const RequestOnError = (err) => {
    console.log(err);
    NotificationBox('ERROR', err.message, 0);
    updateTactSetting(E_TACT_SETTING_ALL, tact_setting); //temp
  };
  return {
    initialSetting,
    TactSettingMode: mode.main,
    TactSettingSubMode: mode.sub,
    changeModeFunc,

    //object variable
    deleteColumn,
    sortColumns,

    //EditMode
    editMode,
    setEditMode,
    updateEditMode,
    saveTactSetting,
    AddHandler,

    //Import
    isImportModalVisible: isVisible,
    openImportModal,
    closeImportModal,
    onSuccess: RequestOnSuccess,
    onError: RequestOnError,

    //redux
    gTactSettings,
    updateTactSetting,
    InitialTactEditMode,

    //primary Pu
    PrimaryPUSet,
    selectPrimaryPUSetting,
  };
};
export default useTactSetting;
