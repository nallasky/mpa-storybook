import * as SS from './styles/settingStyles';
import {
  MSG_ADD_NEW,
  MSG_CANCEL,
  MSG_EDIT,
  MSG_IMPORT,
  MSG_SAVE,
} from '../../../constants/Message';
import { UploadOutlined, PlusCircleFilled } from '@ant-design/icons';
import React from 'react';
import PropTypes from 'prop-types';
import useTactSetting from './hooks/useTactSetting';
import {
  E_TACT_SETTING_PRIMARY_PU,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
} from '../../../constants/etc';
import SettingPrimaryPU from './SettingPrimaryPU';

const EditImport = ({
  settingMode,
  subMode,
  editMode,
  setEditMode,
  openImportModal,
  changeModeFunc,
}) => {
  const {
    saveTactSetting,
    InitialTactEditMode: Initial,
    gTactSettings,
    AddHandler,
  } = useTactSetting();

  const saveSetting = () => {
    saveTactSetting(settingMode);
    setEditMode(Initial);
  };

  return (
    <div css={SS.primaryStyle}>
      <SettingPrimaryPU
        settingMode={settingMode}
        changeModeFunc={changeModeFunc}
        isEditMode={editMode.isEdit}
      />
      {settingMode === E_TACT_SETTING_PRIMARY_PU ? (
        <></>
      ) : editMode.isEdit ? (
        <>
          <div css={SS.SettingTactButtonStyle}>
            <div>
              <button
                css={SS.antdButtonStyle}
                className="blue settingButton"
                style={{ borderRadius: '8px' }}
                onClick={() => AddHandler(editMode.data, setEditMode)}
              >
                <PlusCircleFilled /> {MSG_ADD_NEW}
              </button>
            </div>
            <div css={SS.rightButton}>
              <button
                css={SS.antdButtonStyle}
                className="white settingButton"
                style={{ borderRadius: '8px' }}
                onClick={() => setEditMode(Initial)}
              >
                {MSG_CANCEL}
              </button>
              <button
                css={SS.antdButtonStyle}
                className="blue settingButton"
                style={{ borderRadius: '8px' }}
                onClick={saveSetting}
              >
                {MSG_SAVE}
              </button>
            </div>
          </div>
        </>
      ) : (
        <>
          <div css={SS.rightButton}>
            <button
              css={SS.antdButtonStyle}
              className="blue"
              style={{ borderRadius: '8px' }}
              onClick={openImportModal}
            >
              <UploadOutlined /> DATA {MSG_IMPORT.toUpperCase()}
            </button>
            <button
              css={SS.antdButtonStyle}
              className="blue"
              style={{ borderRadius: '8px' }}
              onClick={() =>
                setEditMode({
                  isEdit: true,
                  mode: settingMode,
                  data:
                    settingMode === E_TACT_SETTING_PRIMARY_PU_SETTING
                      ? gTactSettings[settingMode][subMode]
                      : gTactSettings[settingMode],
                })
              }
            >
              {MSG_EDIT}
            </button>
          </div>
        </>
      )}
    </div>
  );
};
EditImport.propTypes = {
  settingMode: PropTypes.string,
  subMode: PropTypes.string,
  editMode: PropTypes.object,
  setEditMode: PropTypes.func,
  openImportModal: PropTypes.func,
  changeModeFunc: PropTypes.func,
};

export default EditImport;
