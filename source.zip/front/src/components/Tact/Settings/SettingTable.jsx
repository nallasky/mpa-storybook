import React, { useState, useCallback, useMemo, useEffect } from 'react';
import PropTypes from 'prop-types';
import { SortableContainer, SortableElement } from 'react-sortable-hoc';
import { arrayMoveImmutable } from 'array-move';
import useTactSetting from './hooks/useTactSetting';
import {
  TACT_SET_DATA,
  TACT_SET_DUPLICATED_CHECK_LIST,
  TACT_SET_NAME_DAT_COLUMNS,
  TACT_SET_PLATE_COLUMNS,
  TACT_SET_PLATE_DETAIL_COLUMNS,
  TACT_SET_PLATE_EVENT_COLUMNS,
  TACT_SET_PRIMARY_PU_COLUMNS,
  TACT_SET_REFERENCE_PU_COLUMNS,
} from '@constants/TactDefault';
import {
  E_TACT_SETTING_NAME_DAT,
  E_TACT_SETTING_PLATE,
  E_TACT_SETTING_PLATE_DETAIL,
  E_TACT_SETTING_PLATE_EVENT,
  E_TACT_SETTING_PRIMARY_PU,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
  E_TACT_SETTING_REFERENCE_PU,
  E_TACT_SETTING_PAGE_INFO,
} from '@constants/etc';
import { Table } from 'antd';
import * as SS from './styles/settingStyles';
import { EditableCell, EditableRow } from '../../common/atoms/EditableTable';
import TableHeader from '../../common/molecules/TableHeader/TableHeader';

const SortableItem = SortableElement((props) => <EditableRow {...props} />);
const SortableBody = SortableContainer((props) => <tbody {...props} />);
const filteringData = (text, data) => {
  return text.length > 0
    ? data.filter((v) => {
        let isFilter = false;
        for (const [key, value] of Object.entries(v)) {
          if (
            key !== 'id' &&
            key !== 'index' &&
            value.toString().toLowerCase().includes(text.toLowerCase())
          ) {
            isFilter = true;
          }
        }
        return isFilter;
      })
    : data;
};

export const column_data = {
  [E_TACT_SETTING_PLATE]: TACT_SET_PLATE_COLUMNS,
  [E_TACT_SETTING_PLATE_DETAIL]: TACT_SET_PLATE_DETAIL_COLUMNS,
  [E_TACT_SETTING_PLATE_EVENT]: TACT_SET_PLATE_EVENT_COLUMNS,
  [E_TACT_SETTING_NAME_DAT]: TACT_SET_NAME_DAT_COLUMNS,
  [E_TACT_SETTING_PRIMARY_PU_SETTING]: TACT_SET_PRIMARY_PU_COLUMNS,
  [E_TACT_SETTING_REFERENCE_PU]: TACT_SET_REFERENCE_PU_COLUMNS,
};

const SettingTable = ({
  settingMode,
  subMode,
  selectList,
  editMode,
  updateDataFunc,
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [isSearched, setIsSearched] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const [currentRows, setCurrentRows] = useState([]);
  const { gTactSettings, deleteColumn, sortColumns, updateTactSetting } =
    useTactSetting();
  const data = useMemo(
    () =>
      editMode.isEdit
        ? editMode.data
        : settingMode === E_TACT_SETTING_PRIMARY_PU
        ? []
        : settingMode === E_TACT_SETTING_PRIMARY_PU_SETTING
        ? gTactSettings[settingMode][subMode]
        : gTactSettings[settingMode],
    [gTactSettings[settingMode], editMode.data, subMode],
  );
  const header = useMemo(() => {
    const header_data = (column_data?.[settingMode] ?? []).slice();
    if (editMode.isEdit) {
      if (settingMode === E_TACT_SETTING_PLATE) {
        header_data.unshift(sortColumns);
      }
      header_data.push(deleteColumn(editMode.data, updateDataFunc));
    }
    return header_data;
  }, [settingMode, editMode.data]);

  const onSortEnd = useCallback(
    ({ oldIndex, newIndex }) => {
      if (oldIndex !== newIndex) {
        const newData = arrayMoveImmutable([].concat(data), oldIndex, newIndex)
          .filter((el) => !!el)
          .map((o, idx) => ({ ...o, display_order: idx + 1 }));
        updateDataFunc(newData);
      }
    },
    [data],
  );
  const DraggableContainer = useCallback(
    (props) => (
      <SortableBody
        useDragHandle
        disableAutoscroll
        helperClass="tact-setting-table-row-dragging"
        onSortEnd={onSortEnd}
        {...props}
      />
    ),
    [data],
  );
  const DraggableBodyRow = useCallback(
    (Props) => {
      const index = data.findIndex((x) => x.index === Props['data-row-key']);
      return <SortableItem index={index} {...Props} />;
    },
    [data],
  );
  const handleSave = (row) => {
    const newData = [...data];
    const index = newData.findIndex((item) => row.index === item.index);
    const item = newData[index];
    newData.splice(index, 1, { ...item, ...row });
    updateDataFunc(newData);
  };

  const onSearch = (text) => {
    setCurrentRows(filteringData(text, data));
    if (
      [E_TACT_SETTING_PRIMARY_PU_SETTING, E_TACT_SETTING_REFERENCE_PU].includes(
        settingMode,
      )
    ) {
      changeCurrentPage(1);
      setIsSearched(text.length > 0);
      setSearchValue(text);
    } else {
      updateTactSetting(E_TACT_SETTING_PAGE_INFO, {
        ...gTactSettings[E_TACT_SETTING_PAGE_INFO],
        [settingMode]: {
          ...gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode],
          searchText: text,
          page: 1,
          isSearched: text.length > 0,
        },
      });
    }
  };

  const changeCurrentPage = (v) => {
    if (
      [E_TACT_SETTING_PRIMARY_PU_SETTING, E_TACT_SETTING_REFERENCE_PU].includes(
        settingMode,
      )
    ) {
      setCurrentPage(v);
    } else {
      updateTactSetting(E_TACT_SETTING_PAGE_INFO, {
        ...gTactSettings[E_TACT_SETTING_PAGE_INFO],
        [settingMode]: {
          ...gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode],
          page: v,
        },
      });
    }
  };

  const changePageSize = (v) => {
    if (
      [E_TACT_SETTING_PRIMARY_PU_SETTING, E_TACT_SETTING_REFERENCE_PU].includes(
        settingMode,
      )
    ) {
      setPageSize(v);
      if (currentPage > 1) {
        changeCurrentPage(Math.ceil((pageSize * (currentPage - 1) + 1) / v));
      }
    } else {
      updateTactSetting(E_TACT_SETTING_PAGE_INFO, {
        ...gTactSettings[E_TACT_SETTING_PAGE_INFO],
        [settingMode]: {
          ...gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode],
          rowSize: v,
          page:
            gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].page > 1
              ? Math.ceil(
                  (gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode]
                    .rowSize *
                    (gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].page -
                      1) +
                    1) /
                    v,
                )
              : gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].page,
        },
      });
    }
  };

  useEffect(() => {
    if (settingMode !== E_TACT_SETTING_PRIMARY_PU) {
      if (
        [
          E_TACT_SETTING_PRIMARY_PU_SETTING,
          E_TACT_SETTING_REFERENCE_PU,
        ].includes(settingMode)
      ) {
        setCurrentRows(data);
        setCurrentPage(1);
      } else {
        if (
          gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].searchText
            .length > 0
        ) {
          setCurrentRows(
            filteringData(
              gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].searchText,
              data,
            ),
          );
        } else {
          setCurrentRows(data);
        }
      }
    }
  }, [data]);

  useEffect(() => {
    if (
      [E_TACT_SETTING_PRIMARY_PU_SETTING, E_TACT_SETTING_REFERENCE_PU].includes(
        settingMode,
      )
    ) {
      setCurrentPage(1);
      setPageSize(10);
      setIsSearched(false);
      setSearchValue('');
    }
  }, [subMode]);

  if (settingMode === E_TACT_SETTING_PRIMARY_PU) return <></>;
  return (
    <div css={SS.tactSettingTableStyle}>
      <TableHeader
        currentPage={
          [
            E_TACT_SETTING_PRIMARY_PU_SETTING,
            E_TACT_SETTING_REFERENCE_PU,
          ].includes(settingMode)
            ? currentPage
            : gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].page
        }
        dataLength={currentRows?.length ?? 0}
        setPage={changeCurrentPage}
        rowSize={
          [
            E_TACT_SETTING_PRIMARY_PU_SETTING,
            E_TACT_SETTING_REFERENCE_PU,
          ].includes(settingMode)
            ? pageSize
            : gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].rowSize
        }
        setRowSize={changePageSize}
        onSearch={onSearch}
        uniqueKey={
          [
            E_TACT_SETTING_PRIMARY_PU_SETTING,
            E_TACT_SETTING_REFERENCE_PU,
          ].includes(settingMode)
            ? subMode
            : undefined
        }
        isSearched={
          [
            E_TACT_SETTING_PRIMARY_PU_SETTING,
            E_TACT_SETTING_REFERENCE_PU,
          ].includes(settingMode)
            ? isSearched
            : gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].isSearched
        }
        searchValue={
          [
            E_TACT_SETTING_PRIMARY_PU_SETTING,
            E_TACT_SETTING_REFERENCE_PU,
          ].includes(settingMode)
            ? searchValue
            : gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].searchText
        }
      />
      {editMode.isEdit ? (
        <Table
          dataSource={currentRows}
          rowClassName={() => 'editable-row'}
          bordered={true}
          rowKey={'index'}
          columns={header.map((col) =>
            !col.editable
              ? col
              : {
                  ...col,
                  ['onCell']: (record) => ({
                    record,
                    ...col,
                    handleSave,
                    validator: {
                      duplicatedCell:
                        TACT_SET_DUPLICATED_CHECK_LIST[settingMode]?.includes(
                          col.dataIndex,
                        ) ?? false
                          ? data
                              .filter((o) => o.index !== record.index)
                              .map((o) =>
                                (o[col.dataIndex] ?? '').toLowerCase(),
                              )
                          : undefined,
                      sameCell:
                        [
                          TACT_SET_DATA.TACT_SET_EVENT_START,
                          TACT_SET_DATA.TACT_SET_EVENT_END,
                        ].includes(col.dataIndex) ?? false
                          ? record[
                              col.dataIndex ===
                              TACT_SET_DATA.TACT_SET_EVENT_START
                                ? TACT_SET_DATA.TACT_SET_EVENT_END
                                : TACT_SET_DATA.TACT_SET_EVENT_START
                            ]
                          : undefined,
                    },
                    selectList:
                      (col?.editType ?? '') === 'select'
                        ? selectList[col.dataIndex]
                        : undefined,
                  }),
                },
          )}
          components={{
            body: {
              wrapper: DraggableContainer,
              cell: EditableCell,
              row: DraggableBodyRow,
            },
          }}
          pagination={{
            position: ['none', 'bottomCenter'],
            hideOnSinglePage: true,
            pageSize: [
              E_TACT_SETTING_PRIMARY_PU_SETTING,
              E_TACT_SETTING_REFERENCE_PU,
            ].includes(settingMode)
              ? pageSize
              : gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].rowSize,
            current: [
              E_TACT_SETTING_PRIMARY_PU_SETTING,
              E_TACT_SETTING_REFERENCE_PU,
            ].includes(settingMode)
              ? currentPage
              : gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].page,
            showSizeChanger: false,
            onChange: (page) => changeCurrentPage(page),
          }}
        />
      ) : (
        <Table
          dataSource={currentRows}
          bordered={true}
          rowKey={'index'}
          columns={header}
          pagination={{
            position: ['none', 'bottomCenter'],
            hideOnSinglePage: true,
            pageSize: [
              E_TACT_SETTING_PRIMARY_PU_SETTING,
              E_TACT_SETTING_REFERENCE_PU,
            ].includes(settingMode)
              ? pageSize
              : gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].rowSize,
            current: [
              E_TACT_SETTING_PRIMARY_PU_SETTING,
              E_TACT_SETTING_REFERENCE_PU,
            ].includes(settingMode)
              ? currentPage
              : gTactSettings[E_TACT_SETTING_PAGE_INFO][settingMode].page,
            showSizeChanger: false,
            onChange: (page) => changeCurrentPage(page),
          }}
        />
      )}
    </div>
  );
};

SettingTable.propTypes = {
  settingMode: PropTypes.string,
  subMode: PropTypes.string,
  editMode: PropTypes.object,
  updateDataFunc: PropTypes.func,
  selectList: PropTypes.object,
};
export default SettingTable;
