import React, { useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { SortableContainer, SortableElement } from 'react-sortable-hoc';
import { arrayMoveImmutable } from 'array-move';
import useTactSetting from './hooks/useTactSetting';
import {
  TACT_SET_NAME_DAT_COLUMNS,
  TACT_SET_PLATE_COLUMNS,
  TACT_SET_PLATE_DETAIL_COLUMNS,
  TACT_SET_PLATE_EVENT_COLUMNS,
  TACT_SET_PRIMARY_PU_COLUMNS,
  TACT_SET_REFERENCE_PU_COLUMNS,
} from '../../../constants/TactDefault';
import {
  E_TACT_SETTING_NAME_DAT,
  E_TACT_SETTING_PLATE,
  E_TACT_SETTING_PLATE_DETAIL,
  E_TACT_SETTING_PLATE_EVENT,
  E_TACT_SETTING_PRIMARY_PU,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
  E_TACT_SETTING_REFERENCE_PU,
} from '../../../constants/etc';
import { Table } from 'antd';
const SortableItem = SortableElement((props) => <tr {...props} />);
const SortableBody = SortableContainer((props) => <tbody {...props} />);

const column_data = {
  [E_TACT_SETTING_PLATE]: TACT_SET_PLATE_COLUMNS,
  [E_TACT_SETTING_PLATE_DETAIL]: TACT_SET_PLATE_DETAIL_COLUMNS,
  [E_TACT_SETTING_PLATE_EVENT]: TACT_SET_PLATE_EVENT_COLUMNS,
  [E_TACT_SETTING_NAME_DAT]: TACT_SET_NAME_DAT_COLUMNS,
  [E_TACT_SETTING_PRIMARY_PU_SETTING]: TACT_SET_PRIMARY_PU_COLUMNS,
  [E_TACT_SETTING_REFERENCE_PU]: TACT_SET_REFERENCE_PU_COLUMNS,
};

const SettingTable = ({ settingMode, subMode, editMode, updateDataFunc }) => {
  const { gTactSettings, deleteColumn, sortColumns } = useTactSetting();
  const data = useMemo(
    () =>
      editMode.isEdit
        ? editMode.data
        : settingMode === E_TACT_SETTING_PRIMARY_PU
        ? []
        : settingMode === E_TACT_SETTING_PRIMARY_PU_SETTING
        ? gTactSettings[settingMode][subMode]
        : gTactSettings[settingMode],
    [settingMode, editMode.data, subMode],
  );
  const header = useMemo(() => {
    console.log('[header] editMode', column_data[settingMode]);
    const header_data = (column_data?.[settingMode] ?? []).slice();
    if (editMode.isEdit) {
      if (settingMode === E_TACT_SETTING_PLATE) {
        header_data.unshift(sortColumns);
      }
      header_data.push(deleteColumn(editMode.data, updateDataFunc));
    }
    return header_data;
  }, [settingMode, editMode.data]);
  const onSortEnd = useCallback(
    ({ oldIndex, newIndex }) => {
      if (oldIndex !== newIndex) {
        const newData = arrayMoveImmutable(
          [].concat(data),
          oldIndex,
          newIndex,
        ).filter((el) => !!el);
        updateDataFunc(newData);
      }
    },
    [data],
  );
  const DraggableContainer = useCallback(
    (props) => (
      <SortableBody
        useDragHandle
        disableAutoscroll
        helperClass="tact-setting-table-row-dragging"
        onSortEnd={onSortEnd}
        {...props}
      />
    ),
    [data],
  );
  const DraggableBodyRow = useCallback(
    ({ ...restProps }) => {
      const index = data.findIndex(
        (x) => x.index === restProps['data-row-key'],
      );
      return <SortableItem index={index} {...restProps} />;
    },
    [data],
  );
  console.log('[settingTable] data', data);
  console.log('[settingTable] header', header);
  console.log('[settingTable] editMode', gTactSettings[settingMode]);

  if (settingMode === E_TACT_SETTING_PRIMARY_PU) return <></>;

  return (
    <div>
      {editMode.isEdit ? (
        <Table
          dataSource={data}
          bordered={true}
          rowKey={'index'}
          columns={header}
          components={{
            body: {
              wrapper: DraggableContainer,
              row: DraggableBodyRow,
            },
          }}
          pagination={{ position: ['none', 'bottomCenter'] }}
        />
      ) : (
        <div>
          <Table
            dataSource={data}
            bordered={true}
            rowKey={'index'}
            columns={header}
            pagination={{ position: ['none', 'bottomCenter'] }}
          />
        </div>
      )}
    </div>
  );
};

SettingTable.propTypes = {
  settingMode: PropTypes.string,
  subMode: PropTypes.string,
  editMode: PropTypes.object,
  updateDataFunc: PropTypes.func,
};
export default SettingTable;
