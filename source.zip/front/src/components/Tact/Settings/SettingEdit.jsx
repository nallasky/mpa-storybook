import React, { useState, useEffect, useMemo, useContext } from 'react';
import {
  UploadOutlined,
  PlusOutlined,
  PlusCircleFilled,
  DeleteFilled,
} from '@ant-design/icons';
import PropTypes from 'prop-types';
import {
  MESSAGE,
  MSG_ADD_NEW,
  MSG_CANCEL,
  MSG_EDIT,
  MSG_SAVE,
} from '@constants/Message';
import useTactSetting, { TactSettingInfo } from './hooks/useTactSetting';
import {
  E_TACT_SETTING_PRIMARY_PU,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
  E_TACT_SETTING_REFERENCE_PU,
} from '@constants/etc';
import { Button, Divider, Input, Select, Space } from 'antd';
import { TACT_PRIMARY_PU_LIST } from '@constants/TactDefault';
import DeleteButton from '../../common/molecules/PopConfirmButton/DeleteButton';
import ImportModal from './ImportModal';
import useModal from '../../../libs/util/modalControl/useModal';
import * as SS from './styles/settingStyles';
import { column_data } from './SettingTable';

const { Option } = Select;

const SettingEdit = ({ updateFunc, changeModeFunc }) => {
  const [isSelectOpen, setIsSelectOpen] = useState(false);
  const { openModal } = useModal();
  const { settingMode, subMode, editMode, setEditMode } =
    useContext(TactSettingInfo);
  const {
    gTactSettings,
    PrimaryPUSet,
    updatePrimaryPuList,
    selectPrimaryPUSetting,
    deletePrimaryPUName,
    addPrimaryPUName,
    updatePrimaryPUName,
    newPrimaryPUName,
    checkPrimaryPUName,
    saveTactSetting,
    InitialTactEditMode: Initial,
    AddHandler,
    gPrimaryPuList,
  } = useTactSetting();
  const newPUNameStatus = useMemo(
    () => checkPrimaryPUName(newPrimaryPUName, PrimaryPUSet.list),
    [newPrimaryPUName, PrimaryPUSet.list],
  );

  const onPuSettingModeChange = (mode) => {
    changeModeFunc({ mode });
    if (mode === E_TACT_SETTING_PRIMARY_PU_SETTING) {
      selectPrimaryPUSetting(true);
    }
  };

  const onClickEvent = (type, e, event) => {
    if (type === 'add') {
      addPrimaryPUName(
        e,
        () => updatePrimaryPUName(null),
        updateFunc,
        changeModeFunc,
      );
    } else if (type === 'delete') {
      event.stopPropagation();
      deletePrimaryPUName(e, updateFunc, changeModeFunc);
    } else if (type === 'update') {
      updatePrimaryPUName(e.target.value);
    }
  };
  const saveSetting = () => {
    saveTactSetting(settingMode, subMode, editMode.data, updateFunc);
    setEditMode(Initial);
  };
  const enableCheckSaveSetting = useMemo(() => {
    if (editMode.isEdit) {
      const checklist = column_data[editMode.mode].map((o) => o.dataIndex);
      return (
        editMode.data.find(
          (o) => checklist.filter((keys) => o[keys] === undefined).length > 0,
        ) === undefined
      );
    } else {
      return false;
    }
  }, [editMode.mode, editMode.data, editMode.isEdit]);

  const changeDisableHover = (index, isDisable) => {
    updatePrimaryPuList(
      PrimaryPUSet.list.map((v, i) => ({
        ...v,
        disableHover: i === index ? isDisable : v.disableHover,
      })),
    );
  };

  useEffect(() => {
    if (
      PrimaryPUSet.isMode &&
      settingMode !== E_TACT_SETTING_PRIMARY_PU_SETTING
    ) {
      selectPrimaryPUSetting(false);
    }
  }, [settingMode, subMode]);
  useEffect(() => {
    if (PrimaryPUSet.list.length !== gPrimaryPuList.length) {
      updatePrimaryPuList(gPrimaryPuList);
    }
  }, [gPrimaryPuList]);

  return (
    <div css={SS.primaryStyle}>
      {[
        E_TACT_SETTING_REFERENCE_PU,
        E_TACT_SETTING_PRIMARY_PU_SETTING,
        E_TACT_SETTING_PRIMARY_PU,
      ].includes(settingMode) ? (
        <>
          <Space>
            <Select
              style={{ width: 320 }}
              onChange={onPuSettingModeChange}
              disabled={editMode.isEdit}
            >
              {TACT_PRIMARY_PU_LIST.map((item, index) => (
                <Option value={item.id} key={`pu_${index}`}>
                  {item.title}
                </Option>
              ))}
            </Select>
            {PrimaryPUSet.isMode ? (
              <Select
                open={isSelectOpen}
                disabled={editMode.isEdit}
                onClick={(e) => {
                  if (
                    e.target.getAttribute('class') ===
                    'ant-select-selection-item'
                  ) {
                    setIsSelectOpen(!isSelectOpen);
                  }
                }}
                onChange={(subMode) => {
                  changeModeFunc({
                    mode: E_TACT_SETTING_PRIMARY_PU_SETTING,
                    subMode,
                  });
                  setIsSelectOpen(false);
                }}
                style={{ width: 320 }}
                value={subMode ?? ''}
                dropdownRender={(menu) => (
                  <>
                    <div
                      tabIndex="0"
                      role="button"
                      onKeyDown={undefined}
                      css={SS.customPopupBackground}
                      onClick={() => setIsSelectOpen(false)}
                    />
                    <div css={SS.primarySelectStyle}>
                      {menu}
                      <Divider style={{ margin: '8px 0' }} />
                      <Space align="center" style={{ padding: '0 8px 4px' }}>
                        <Input
                          placeholder="Enter primary pu name"
                          status={newPUNameStatus}
                          value={newPrimaryPUName}
                          onChange={(e) => onClickEvent('update', e)}
                          allowClear
                        />
                        <Button
                          type={'dashed'}
                          icon={<PlusOutlined />}
                          onClick={() => onClickEvent('add', newPrimaryPUName)}
                          disabled={newPUNameStatus !== ''}
                        >
                          Add
                        </Button>
                      </Space>
                    </div>
                  </>
                )}
              >
                {PrimaryPUSet.list.map((item, index) => (
                  <Option
                    value={item.name}
                    key={`pu_list_${index}`}
                    className={item.disableHover ? 'disable-hover' : ''}
                  >
                    {item.name}{' '}
                    <DeleteButton
                      deleteHandler={(e) =>
                        onClickEvent('delete', item.name, e)
                      }
                      type="text"
                      onMouseHandler={changeDisableHover}
                      mouseHandlerIndex={index}
                      icon={<DeleteFilled />}
                    />{' '}
                  </Option>
                ))}
              </Select>
            ) : (
              <></>
            )}
          </Space>
        </>
      ) : (
        <></>
      )}
      {settingMode === E_TACT_SETTING_PRIMARY_PU &&
      PrimaryPUSet.isMode === false ? (
        <></>
      ) : editMode.isEdit ? (
        <div css={SS.SettingTactButtonStyle}>
          <div>
            <button
              css={SS.antdButtonStyle}
              className="blue settingButton"
              style={{ borderRadius: '8px' }}
              onClick={() =>
                AddHandler(settingMode, editMode.data, setEditMode)
              }
            >
              <PlusCircleFilled /> {MSG_ADD_NEW}
            </button>
          </div>
          <div css={SS.rightButton}>
            <button
              css={SS.antdButtonStyle}
              className="white settingButton"
              style={{ borderRadius: '8px' }}
              onClick={() => setEditMode(Initial)}
            >
              {MSG_CANCEL}
            </button>
            <button
              css={SS.antdButtonStyle}
              className="blue settingButton"
              style={{ borderRadius: '8px' }}
              onClick={saveSetting}
              disabled={enableCheckSaveSetting === false}
            >
              {MSG_SAVE}
            </button>
          </div>
        </div>
      ) : (
        <div css={SS.rightButton}>
          <button
            css={SS.antdButtonStyle}
            className="blue"
            style={{ borderRadius: '8px' }}
            onClick={() =>
              openModal(ImportModal, {
                Mode: {
                  mode: settingMode,
                  sub_mode: subMode,
                },
                updateFunc: updateFunc,
                modeChangeFunc: changeModeFunc,
              })
            }
          >
            <UploadOutlined /> DATA {MESSAGE.IMPORT.toUpperCase()}
          </button>
          <button
            css={SS.antdButtonStyle}
            className="blue"
            style={{ borderRadius: '8px' }}
            disabled={
              settingMode === E_TACT_SETTING_PRIMARY_PU ||
              (settingMode === E_TACT_SETTING_PRIMARY_PU_SETTING &&
                subMode === undefined)
            }
            onClick={() =>
              setEditMode({
                isEdit: true,
                mode: settingMode,
                data:
                  settingMode === E_TACT_SETTING_PRIMARY_PU_SETTING
                    ? gTactSettings[settingMode][subMode]
                    : gTactSettings[settingMode],
              })
            }
          >
            {MSG_EDIT}
          </button>
        </div>
      )}
    </div>
  );
};
SettingEdit.propTypes = {
  updateFunc: PropTypes.func,
  changeModeFunc: PropTypes.func,
};

export default SettingEdit;
