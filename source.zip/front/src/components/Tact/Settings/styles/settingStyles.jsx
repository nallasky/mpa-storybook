import { css, keyframes } from '@emotion/react';
const moveLeft = keyframes`
  25% {
    transform: translateX(-25px);
  }
  50% {
    transform: translateX(0);
  }
`;
export const loadingWrapper = css`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`;
export const componentStyle = css`
  position: relative;
  padding: 1rem;
  min-height: 400px;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0px 0px 8px 2px rgba(0, 0, 0, 0.15);
  &.stretch {
    align-self: stretch;
  }
  &.span {
    display: flex;
    flex-direction: column;
    row-gap: 2rem;
    grid-column: 1 / span 2;
  }
  & .source-button-wrapper {
    position: absolute;
    bottom: 16px;
    right: 16px;
  }
  & > .ant-spin {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    row-gap: 0.5rem;
    background-color: white;
    border-radius: 4px;
    &.ant-spin-spinning {
      z-index: 1200;
    }
  }
  & .foreground {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 4px;
    display: none;
    justify-content: center;
    align-items: center;
    background-color: white;
    &.active {
      display: flex;
      z-index: 5;
      & > div {
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        row-gap: 1rem;
        & > svg {
          position: relative;
          animation: ${moveLeft} 1.5s ease-in-out infinite;
        }
        & > p {
          font-size: 20px;
          font-weight: bold;
        }
      }
    }
  }
`;
export const controlStyle = css`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
`;

export const dividerStyle = css`
  margin: 0px;
`;
export const buttonRadius = css`
  margin-left: 8px;
  font-weight: 400;
`;
export const customButtonStyle = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-color: white;
  border: none;
  & > span {
    &:first-of-type {
      font-size: 26px;
      color: #1890ff;
    }
    &:last-of-type {
      font-size: 8px;
      font-weight: 600;
    }
  }
  &.absolute {
    position: absolute;
    bottom: -5px;
    right: 10px;
    & > span:first-of-type {
      color: #52c41a;
    }
  }
  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
    & > span:first-of-type {
      color: #c9c9c9;
    }
  }
`;
export const antdButtonStyle = css`
  position: relative;
  padding: 0.5rem 1rem;
  border-radius: 14px;
  box-shadow: 0px 2px 4px 1px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  white-space: pre;
  &.white {
    background-color: white;
    border: 1px dashed #d9d9d9;
    &:disabled {
      background-color: #d9d9d9;
      color: transparent;
      &::before {
        position: absolute;
        width: 100%;
        top: 5px;
        left: 0;
        content: 'X';
        color: white;
        font-weight: bold;
        font-size: 20px;
      }
    }
  }
  &.whiteSolid {
    border: 1px solid #d9d9d9;
  }
  &.blue {
    color: white;
    background-color: #1890ff;
    border: 1px solid #1890ff;
  }
  &.color-picker {
    width: 100%;
    border-radius: unset;
    font-weight: 400;
  }
  &.tact-download {
    margin-left: 8px;
    font-weight: 400;
  }
  &.view-graph {
    width: 136px;
    float: right;
  }
  &:disabled {
    cursor: not-allowed;
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
`;

export const SettingTactButtonStyle = css`
  display: flex;
  justify-content: space-between;
  width: 100%;
  & > div > button > span {
    margin-right: 3px;
  }
`;

export const rightButton = css`
  display: flex;
  justify-content: end;
  gap: 10px;
  width: 100%;
`;

export const ImportBoxStyle = css`
  min-height: 130px;
  background-color: #f0f5ff;
  border-radius: 10px;
`;

export const contentItemStyle = css`
  display: grid;
  column-gap: 1rem;
  align-items: center;
  &.column {
    grid-template-columns: 0.4fr 1fr;
    padding: 1rem;
  }
  & > span {
    position: relative;
    color: #1890ff;
    font-size: 16px;
    font-weight: 500;
    align-self: start;
    &:first-of-type {
      position: relative;
    }
     &.label {
        &::after {
          display: inline-block;
          content: ':';
        }
      }
  & .ant-upload.ant-upload-select {
    width: 100%;
    & button {
    width: 100%;
    border-radius: 8px;
    }
  }
`;

export const modalFooterStyle = css`
  margin-top: 30px;
  .modalButton {
    position: absolute;
    bottom: 10px;
    right: 25px;
    display: flex;
    gap: 5px;
  }
`;

export const primaryStyle = css`
  display: flex;
  gap: 10px;
`;
