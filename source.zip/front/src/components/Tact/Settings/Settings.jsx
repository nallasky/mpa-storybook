import React, { useEffect } from 'react';
import useTactSetting, { TactSettingInfo } from './hooks/useTactSetting';
import {
  componentStyle,
  controlStyle,
  customButtonStyle,
  dividerStyle,
} from './styles/settingStyles';
import CustomRadioGroup from '../../common/molecules/CustomRadioGroup/CustomRadioGroup';
import { TACT_SETTING_LIST } from '@constants/TactDefault';
import { DownloadForm } from '../../common/molecules/ResultDownloadForm';
import { Error } from '../../Error';
import { Divider, Skeleton } from 'antd';
import SettingEdit from './SettingEdit';
import SettingTable from './SettingTable';

import {
  E_TACT_SETTING_ALL,
  E_TACT_SETTING_PRIMARY_PU,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
  E_TACT_SETTING_REFERENCE_PU,
} from '@constants/etc';

const Settings = () => {
  const {
    mode,
    initialSetting,
    changeModeFunc,
    setDownloading,
    editMode,
    setEditMode,
    settingUpdate,
    setSettingUpdate,
    reqTactSetting,
    tactSettingSelectList,
  } = useTactSetting();

  const { error: MainError, isLoading } = reqTactSetting;
  const { mode: UpdateMode, isUpdate } = settingUpdate;
  useEffect(() => {
    setSettingUpdate({ mode: E_TACT_SETTING_ALL, isUpdate: true });
    return () => {
      initialSetting();
    };
  }, []);
  if (MainError) {
    return <Error.somthing />;
  }
  return (
    <TactSettingInfo.Provider
      value={{
        settingMode: mode.main.id,
        subMode: mode.sub,
        editMode,
        setEditMode,
      }}
    >
      <div css={componentStyle} className="span">
        <Skeleton
          loading={isUpdate && UpdateMode === E_TACT_SETTING_ALL}
          active
          paragraph={{ rows: 10 }}
        >
          <div css={controlStyle}>
            <CustomRadioGroup
              changeFunc={(mode) => changeModeFunc({ mode })}
              initialValue={
                [
                  E_TACT_SETTING_PRIMARY_PU_SETTING,
                  E_TACT_SETTING_REFERENCE_PU,
                ].includes(mode.main.id)
                  ? E_TACT_SETTING_PRIMARY_PU
                  : mode.main.id
              }
              options={TACT_SETTING_LIST}
              disabled={editMode.isEdit || isLoading}
            />
            <div css={customButtonStyle}>
              <DownloadForm
                downloadFunc={() => setDownloading(true)}
                disabled={editMode.isEdit || isLoading}
              />
            </div>
          </div>
          <Divider css={dividerStyle} />
          {isLoading ? (
            <Skeleton loading={isLoading} active paragraph={{ rows: 5 }} />
          ) : (
            <>
              <SettingEdit
                updateFunc={setSettingUpdate}
                changeModeFunc={changeModeFunc}
              />
              <SettingTable
                settingMode={mode.main.id}
                subMode={mode.sub}
                editMode={editMode}
                updateDataFunc={(data) =>
                  setEditMode((prev) => ({ ...prev, data: data }))
                }
                selectList={editMode.isEdit ? tactSettingSelectList : {}}
              />
            </>
          )}
        </Skeleton>
      </div>
    </TactSettingInfo.Provider>
  );
};
export default Settings;
