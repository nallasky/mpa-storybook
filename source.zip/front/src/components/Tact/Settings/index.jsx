export { default as TactSettingComponent } from './Settings';
