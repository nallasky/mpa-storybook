import React from 'react';
import {
  E_TACT_SETTING_PRIMARY_PU,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
  E_TACT_SETTING_REFERENCE_PU,
} from '../../../constants/etc';
import { Button, Divider, Input, Select, Space } from 'antd';
import { TACT_PRIMARY_PU_LIST } from '../../../constants/TactDefault';
import { PlusOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';
import useTactSetting from './hooks/useTactSetting';
const { Option } = Select;
const SettingPrimaryPU = ({ settingMode, changeModeFunc, isEditMode }) => {
  const { PrimaryPUSet, selectPrimaryPUSetting } = useTactSetting();

  const onModeChange = (mode) => {
    if (mode === E_TACT_SETTING_REFERENCE_PU) {
      changeModeFunc({ mode });
      selectPrimaryPUSetting(false);
    } else {
      selectPrimaryPUSetting(true);
    }
  };

  return (
    <>
      {[
        E_TACT_SETTING_REFERENCE_PU,
        E_TACT_SETTING_PRIMARY_PU_SETTING,
        E_TACT_SETTING_PRIMARY_PU,
      ].includes(settingMode) ? (
        <>
          <Space>
            <Select
              style={{ width: 250 }}
              onChange={(mode) => onModeChange(mode)}
              disabled={isEditMode}
            >
              {TACT_PRIMARY_PU_LIST.map((item) => (
                <>
                  <Option value={item.id}>{item.title}</Option>
                </>
              ))}
            </Select>
            {PrimaryPUSet.isMode ? (
              <Select
                disabled={isEditMode}
                onChange={(subMode) =>
                  changeModeFunc({
                    mode: E_TACT_SETTING_PRIMARY_PU_SETTING,
                    subMode,
                  })
                }
                style={{ width: 250 }}
                dropdownRender={(menu) => (
                  <>
                    {menu}
                    <Divider style={{ margin: '8px 0' }} />
                    <Space align="center" style={{ padding: '0 8px 4px' }}>
                      <Input placeholder="Enter primary pu name" />
                      <Button type={'dashed'} icon={<PlusOutlined />}>
                        Add
                      </Button>
                    </Space>
                  </>
                )}
              >
                {PrimaryPUSet.list.map((item) => (
                  <>
                    <Option value={item}>{item}</Option>
                  </>
                ))}
              </Select>
            ) : (
              <></>
            )}
          </Space>
        </>
      ) : (
        <></>
      )}
    </>
  );
};
SettingPrimaryPU.propTypes = {
  settingMode: PropTypes.string,
  changeModeFunc: PropTypes.func,
  isEditMode: PropTypes.bool,
};
export default SettingPrimaryPU;
