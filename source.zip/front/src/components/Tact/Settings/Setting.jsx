import React, { useEffect } from 'react';
import useTactSetting from './hooks/useTactSetting';
import {
  componentStyle,
  controlStyle,
  customButtonStyle,
  dividerStyle,
  loadingWrapper,
} from './styles/settingStyles';
import CustomRadioGroup from '../../common/molecules/CustomRadioGroup/CustomRadioGroup';
import { TACT_SETTING_LIST } from '../../../constants/TactDefault';
import { DownloadForm } from '../../common/molecules/ResultDownloadForm';
import { Divider, Spin } from 'antd';
import ImportModal from './ImportModal';
import EditImport from './ImportEdit';
import SettingTable from './SettingTable';
//import Error from '../../pages/Error';
import {
  E_TACT_SETTING_ALL,
  E_TACT_SETTING_PRIMARY_PU,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
  E_TACT_SETTING_REFERENCE_PU,
} from '../../../constants/etc';
import { useGetTactSettingInfo } from '../../../hooks/query/tactSetting';
const Settings = () => {
  const {
    initialSetting,
    TactSettingMode,
    TactSettingSubMode,
    changeModeFunc,
    downloadFunc,
    editMode,
    updateEditMode,
    openImportModal,
    closeImportModal,
    isImportModalVisible,
    onSuccess,
    onError,
  } = useTactSetting();

  const {
    /*error: MainError,*/ isLoading: isMainLoading,
  } = useGetTactSettingInfo(E_TACT_SETTING_ALL, onSuccess, onError);

  useEffect(() => {
    initialSetting();
  }, []);
  /*if (MainError) {
    return <Error.somthing />;
  }*/
  if (isMainLoading) {
    return (
      <div css={loadingWrapper}>
        <Spin tip="Loading..." size="large" />
      </div>
    );
  }
  return (
    <>
      <div css={componentStyle} className="span">
        <div css={controlStyle}>
          <CustomRadioGroup
            changeFunc={(mode) => changeModeFunc({ mode })}
            currentChecked={
              [
                E_TACT_SETTING_PRIMARY_PU_SETTING,
                E_TACT_SETTING_REFERENCE_PU,
              ].includes(TactSettingMode.id)
                ? E_TACT_SETTING_PRIMARY_PU
                : TactSettingMode.id
            }
            options={TACT_SETTING_LIST}
            name="result-type"
            disabled={editMode.isEdit}
          />
          <div css={customButtonStyle}>
            <DownloadForm downloadFunc={downloadFunc} />
          </div>
        </div>
        <Divider css={dividerStyle} />
        <EditImport
          settingMode={TactSettingMode.id}
          subMode={TactSettingSubMode}
          editMode={editMode}
          setEditMode={updateEditMode}
          openImportModal={openImportModal}
          changeModeFunc={changeModeFunc}
        />
        <SettingTable
          settingMode={TactSettingMode.id}
          subMode={TactSettingSubMode}
          editMode={editMode}
          updateDataFunc={(data) =>
            updateEditMode((prev) => ({ ...prev, data: data }))
          }
        />
      </div>
      <ImportModal
        visible={isImportModalVisible}
        handleCancel={closeImportModal}
        handleOk={closeImportModal}
      />
    </>
  );
};
export default Settings;
