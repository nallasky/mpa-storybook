import React, { useMemo, useState, useEffect } from 'react';
import { Form, Input, Popconfirm, Spin } from 'antd';
import PropTypes from 'prop-types';
import * as SS from './styles/settingStyles';
import useTactImportSetting from './hooks/useTactImportSetting';
import { Upload } from '../../common/atoms/Upload';
import DraggableModal from '../../common/organisms/DraggableModal/DraggableModal';
import {
  E_TACT_SETTING_PRIMARY_PU,
  E_TACT_SETTING_PRIMARY_PU_SETTING,
  E_TACT_SETTING_REFERENCE_PU,
} from '@constants/etc';
import SettingTable from './SettingTable';
import useTactSetting from './hooks/useTactSetting';

const ImportModal = ({
  Mode: { mode, sub_mode },
  updateFunc,
  modeChangeFunc,
  onClose,
}) => {
  const {
    getImportProps,
    fileName,
    startImportFile,
    startPreviewFile,
    clearImportFile,
    updatePuName,
    puName,
    refPuList,
    setRefPuList,
    isProcessing,
    setProcessing,
  } = useTactImportSetting();
  const { gPrimaryPuList } = useTactSetting();
  const buttonType = useMemo(
    () =>
      mode !== E_TACT_SETTING_REFERENCE_PU || (refPuList ?? false)
        ? 'Apply'
        : 'Preview',
    [mode, refPuList],
  );
  const [isVisible, setIsVisible] = useState(true);

  const handleCancel = () => {
    clearImportFile();
    setProcessing(false);
    setIsVisible(false);
  };
  const handleOk = () => {
    if (buttonType === 'Preview') {
      startPreviewFile(mode, undefined, handleCancel);
    } else {
      startImportFile(
        mode,
        puName.name ?? sub_mode,
        handleCancel,
        updateFunc,
        modeChangeFunc,
      );
    }
    setProcessing(true);
  };

  useEffect(() => {
    if (!isVisible) {
      onClose();
    }
  }, [isVisible]);

  return (
    <DraggableModal
      visible={isVisible}
      className="import-modal"
      title="DATA IMPORT"
      cancelHandler={handleCancel}
      width={mode === E_TACT_SETTING_REFERENCE_PU ? 800 : 620}
      footer={[
        <>
          {puName.status === 'warning' ? (
            <Popconfirm
              title={`When importing, the existing ${puName.name} settings will be overwritten.`}
              onConfirm={handleOk}
            >
              <button
                key="ok"
                css={SS.antdButtonStyle}
                className="white whiteSolid"
                style={{ borderRadius: '8px', marginRight: '10px' }}
                disabled={
                  isProcessing ||
                  fileName === undefined ||
                  ([
                    E_TACT_SETTING_PRIMARY_PU_SETTING,
                    E_TACT_SETTING_PRIMARY_PU,
                  ].includes(mode)
                    ? (puName.name?.length ?? 0) === 0
                    : false)
                }
              >
                {buttonType}
              </button>
            </Popconfirm>
          ) : (
            <button
              key="ok"
              css={SS.antdButtonStyle}
              className="white whiteSolid"
              style={{ borderRadius: '8px', marginRight: '10px' }}
              disabled={
                isProcessing ||
                fileName === undefined ||
                ([
                  E_TACT_SETTING_PRIMARY_PU_SETTING,
                  E_TACT_SETTING_PRIMARY_PU,
                ].includes(mode)
                  ? (puName.name?.length ?? 0) === 0
                  : false)
              }
              onClick={handleOk}
            >
              {buttonType}
            </button>
          )}
          <button
            key="cancel"
            css={SS.antdButtonStyle}
            className="blue"
            style={{ borderRadius: '8px' }}
            onClick={handleCancel}
          >
            Cancel
          </button>
        </>,
      ]}
    >
      <Spin spinning={isProcessing} size={'large'} tip={'Uploading....'}>
        <div css={SS.ImportBoxStyle}>
          {[
            E_TACT_SETTING_PRIMARY_PU_SETTING,
            E_TACT_SETTING_PRIMARY_PU,
          ].includes(mode) ? (
            <div>
              <Form>
                <Form.Item
                  label="PU Name"
                  name="pu_name"
                  hasFeedback
                  validateTrigger={['onChange']}
                  validateStatus={puName.status}
                  rules={[
                    {
                      required: true,
                      message: 'Please input your name',
                    },
                    {
                      validator: async (_, pu_name) => {
                        console.log('value', pu_name);
                        console.log('puName', pu_name);
                        if (puName.status === 'warning') {
                          return Promise.reject(
                            new Error(`${pu_name} is that already exists!!`),
                          );
                        }
                      },
                    },
                  ]}
                >
                  <Input
                    placeholder="Please enter the pu name"
                    value={puName.name}
                    onChange={(e) => updatePuName(e.target.value)}
                  />
                </Form.Item>
              </Form>
            </div>
          ) : (
            <></>
          )}
          <div css={SS.ImportMenuStyle}>
            <Upload
              label={'Import Data'}
              required={true}
              btnMsg={'Upload'}
              uploadProps={getImportProps()}
              type={'button'}
            />
          </div>
        </div>
        {mode === E_TACT_SETTING_REFERENCE_PU && (refPuList ?? false) ? (
          <SettingTable
            editMode={{ isEdit: true, data: refPuList }}
            settingMode={mode}
            updateDataFunc={setRefPuList}
            selectList={{ primary_pu_name: gPrimaryPuList }}
          />
        ) : (
          <></>
        )}
      </Spin>
    </DraggableModal>
  );
};
ImportModal.propTypes = {
  updateFunc: PropTypes.func,
  modeChangeFunc: PropTypes.func,
  Mode: PropTypes.shape({
    mode: PropTypes.string,
    sub_mode: PropTypes.string,
  }),
  onClose: PropTypes.func,
};

export default ImportModal;
