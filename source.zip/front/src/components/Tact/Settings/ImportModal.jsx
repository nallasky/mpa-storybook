import React from 'react';
import { Modal, Upload, Button } from 'antd';
import PropTypes from 'prop-types';
import * as SS from './styles/settingStyles';
import { CloudUploadOutlined } from '@ant-design/icons';
import {modalFooterStyle} from "./styles/settingStyles";

const ImportModal = ({ visible, handleCancel, handleOk }) => {
  return (
    <>
      <Modal
        className="import-modal"
        title="DATA IMPORT"
        visible={visible}
        onCancel={handleCancel}
        footer={null}
      >
        <div css={SS.ImportBoxStyle}>
          <div css={SS.contentItemStyle} className="column">
            <span className="label">Import Data</span>
            <Upload>
              <Button icon={<CloudUploadOutlined />}>Upload</Button>
            </Upload>
          </div>
        </div>
        <div css={modalFooterStyle}>
          <div className="modalButton">
            <button
              css={SS.antdButtonStyle}
              className="white whiteSolid"
              style={{ borderRadius: '8px' }}
              onClick={handleOk}
            >
              Apply
            </button>
            <button
              css={SS.antdButtonStyle}
              className="blue"
              style={{ borderRadius: '8px' }}
              onClick={handleCancel}
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
};
ImportModal.propTypes = {
  visible: PropTypes.bool,
  handleOk: PropTypes.func,
  handleCancel: PropTypes.func,
};

export default ImportModal;
