export { default as MemoryDumpComponent } from './Memory';
