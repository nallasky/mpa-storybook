import React from 'react';
import { CloudDownloadOutlined } from '@ant-design/icons';
import { Empty, Skeleton, Table } from 'antd';
import * as SS from './styles/memoryStyles';
import useTactMemoryDumpTable from './hooks/useTactMemoryTable';
import Divider from '@components/common/atoms/Divider';
import useTactMemoryDownload from './hooks/useTactMemoryDownload';

const MemoryTreeTable = () => {
  const {
    getAnalysisResult,
    data: memoryData,
    files,
    memoryDumpTableColumns,
    expandableFunc,
    rowSelectionFunc,
    onRowEventFunc,
    selectedRows,
    storeSelectedRows,
    filteredDataSource,
    filterRV,
  } = useTactMemoryDumpTable();
  const { downloadFunc } = useTactMemoryDownload();
  if ((files?.length ?? 0) === 0) return <></>;

  return (
    <div>
      {getAnalysisResult.isLoading || (memoryData ?? []).length === 0 ? (
        <Skeleton
          loading={
            getAnalysisResult.isLoading || (memoryData ?? []).length === 0
          }
          active
          paragraph={{ rows: 5 }}
        />
      ) : (
        <>
          <Divider height={'1'} type={'solid'} />
          <div css={SS.controlStyle}>
            <div css={SS.componentTitleStyle}>Log Table</div>
            <div css={SS.customButtonStyle}>
              <button
                css={SS.antdButtonStyle}
                className="white tact-download"
                onClick={downloadFunc}
              >
                <CloudDownloadOutlined />
                Download
              </button>
            </div>
          </div>
          <div>
            <Table
              columns={memoryDumpTableColumns}
              rowKey={'key'}
              expandable={expandableFunc}
              rowSelection={rowSelectionFunc}
              dataSource={
                filteredDataSource !== null
                  ? filteredDataSource ?? []
                  : memoryData ?? []
              }
              scroll={{ x: '100%', y: '750px' }}
              pagination={false}
              onRow={onRowEventFunc}
              locale={{
                emptyText:
                  (filterRV.min !== filterRV.left ||
                    filterRV.max !== filterRV.right) &&
                  filteredDataSource === undefined ? (
                    <Skeleton active={true} />
                  ) : (
                    <Empty />
                  ),
              }}
            />
          </div>
          <div style={{ marginTop: '10px' }}>
            <button
              css={SS.antdButtonStyle}
              className="blue view-graph"
              disabled={(selectedRows ?? []).length === 0}
              onClick={storeSelectedRows}
            >
              View Graph
            </button>
          </div>
        </>
      )}
    </div>
  );
};
export default MemoryTreeTable;
