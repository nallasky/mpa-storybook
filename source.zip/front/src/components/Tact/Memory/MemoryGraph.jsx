import React, { useEffect, useLayoutEffect, useState } from 'react';
import * as SS from './styles/memoryStyles';
import useTactMemoryDump from './hooks/useTactMemoryDump';
import useTactMemoryGraph from './hooks/useTactMemoryGraph';
import Plotly from 'plotly.js-dist';
import { TSMemoryDumpScript } from '@libs/graph';
import { Button, Select, Skeleton } from 'antd';
import useCustomInterval from '../../../libs/util/common/useCustomInterval';
import { ExpandAltOutlined, ShrinkOutlined } from '@ant-design/icons';
import NewWindowForm from '../../common/molecules/NewWindowForm/NewWindowForm';
import PropTypes from 'prop-types';

const DrawGraph = ({ div_id, style, title }) => {
  const [showWindowPortal, setShowWindowPortal] = useState({
    enable: false,
    element: undefined,
  });
  const toggleWindow = (div_id) => {
    setShowWindowPortal((prevState) =>
      prevState.enable
        ? { enable: false, element: undefined }
        : { enable: true, element: document.getElementById(div_id) },
    );
  };
  const closeWindow = () => {
    setShowWindowPortal({ enable: false, element: undefined });
  };
  useEffect(() => {
    window.addEventListener('beforeunload', () => {
      closeWindow();
    });
    return () => {
      setShowWindowPortal({ enable: false, element: undefined });
    };
  }, []);
  return (
    <div css={[SS.newWindow, style]}>
      <Button
        onClick={() => toggleWindow(div_id)}
        icon={
          showWindowPortal?.enable ? <ShrinkOutlined /> : <ExpandAltOutlined />
        }
        type={'dashed'}
        shape={'circle'}
        className="newWindowButton"
      />
      <NewWindowForm
        enable={showWindowPortal?.enable ?? false}
        title={title}
        closeWindowPortal={closeWindow}
        div_id={div_id}
      />
      <div id={div_id} />
    </div>
  );
};
DrawGraph.propTypes = {
  div_id: PropTypes.string,
  title: PropTypes.string,
  style: PropTypes.any,
};

const MemoryGraph = () => {
  const { gTactMemoryRows } = useTactMemoryDump();
  const {
    getPlateDataList,
    graphPlateNoList,
    filterPlate,
    setFilterPlate,
    FilterPlateNoOptions,
  } = useTactMemoryGraph();

  useCustomInterval(
    () => {
      // Your custom logic here
      if (graphPlateNoList?.length > 0 && filterPlate === undefined) {
        console.log('useLayoutEffect filterPlate2', graphPlateNoList);
        graphPlateNoList.map((plate_no) =>
          TSMemoryDumpScript({
            Plotly,
            element: `memory_plate_${plate_no}`,
            org_data: getPlateDataList(plate_no),
          }),
        );
        setFilterPlate(graphPlateNoList);
      }
    },
    filterPlate === undefined ? 1000 : null,
  );

  useLayoutEffect(() => {
    console.log('useLayoutEffect graphPlateNoList', graphPlateNoList);
    if (graphPlateNoList?.length > 0) {
      setFilterPlate(undefined);
    }
  }, [graphPlateNoList]);

  if (Object.keys(gTactMemoryRows).length === 0) return <></>;
  return (
    <>
      <div css={SS.graphBoxStyle} className="Memory-graph">
        <div css={SS.controlStyle} className="tsGraphTitle">
          <div css={SS.componentTitleStyle}>Drawing Graph</div>
          <div style={filterPlate ?? false ? {} : { display: 'none' }}>
            <div css={SS.customButtonStyle}>
              <Select {...FilterPlateNoOptions}>
                {graphPlateNoList.map((menu) => (
                  <>
                    <Select.Option
                      value={menu}
                    >{`Plate No. ${menu}`}</Select.Option>
                  </>
                ))}
              </Select>
            </div>
          </div>
        </div>
        {graphPlateNoList.map((plate_no) => (
          <>
            <div
              css={SS.componentStyle}
              style={
                (filterPlate ?? [plate_no]).includes(plate_no)
                  ? {}
                  : { display: 'none' }
              }
              className="graphBox"
            >
              <Skeleton
                loading={filterPlate === undefined}
                active
                paragraph={{ rows: 5 }}
              >
                <div className="Plate-title">
                  <span>{`Plate No. ${plate_no}`}</span>
                </div>
              </Skeleton>
              <DrawGraph
                div_id={`memory_plate_${plate_no}`}
                title={`Plate No. ${plate_no}`}
                style={
                  filterPlate ?? false
                    ? {
                        overflowX: 'auto',
                        maxWidth: '1788px',
                        border: '1px dashed #1890ff',
                      }
                    : {
                        maxWidth: '1788px',
                      }
                }
              />
            </div>
          </>
        ))}
      </div>
    </>
  );
};
export default MemoryGraph;
