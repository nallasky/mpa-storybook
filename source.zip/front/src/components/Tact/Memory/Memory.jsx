import React, { useEffect } from 'react';
import MemorySource from './MemorySource';
import * as SS from './styles/memoryStyles';
import MemoryTreeTable from './MemoryTreeTable';
import { css } from '@emotion/react';
import useTactMemoryDump from './hooks/useTactMemoryDump';
import MemoryGraph from './MemoryGraph';

const sectionStyle = css`
  position: relative;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  width: 100%;
  animation: fadeIn 1s;
`;

const Memory = () => {
  const { setMemoryDumpMode, memoryDumpMode, initialized } =
    useTactMemoryDump();
  useEffect(() => {
    console.log('Tact memory dump component mounted !');
    return () => {
      console.log('Tact memory dump  component unmounted !');
      initialized();
    };
  }, []);
  return (
    <section css={sectionStyle}>
      <div css={SS.componentStyle} className="stretch">
        <MemorySource mode={memoryDumpMode} updateFunc={setMemoryDumpMode} />
        <MemoryTreeTable />
      </div>
      <div>
        <MemoryGraph />
      </div>
    </section>
  );
};

export default Memory;
