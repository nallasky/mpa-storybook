import React from 'react';
import { Radio, Switch } from 'antd';
import * as SS from './styles/memoryStyles';
import { PlayCircleOutlined } from '@ant-design/icons';
import useTactMemorySource from './hooks/useTactMemorySource';
import { TACT_MEMORY_LIST } from '@constants/TactDefault';
import { E_TACT_MEMORY_DOWNLOADED } from '@constants/etc';
import { Upload } from '../../common/atoms/Upload';
import PropTypes from 'prop-types';

const MemorySource = ({ mode, updateFunc }) => {
  const {
    logFilesProps,
    logType,
    setLogType,
    startAnalysis,
    enableStartButton,
  } = useTactMemorySource();
  return (
    <>
      <div css={SS.componentTitleStyle}>Select Source</div>
      <div css={SS.contentWrapperStyle}>
        <div css={SS.contentStyle} className="full-width">
          <div
            css={SS.tsMemoryDumpContentItemStyle}
            className="upload column-2"
          >
            <span className="label">Log Type</span>
            <Radio.Group
              onChange={(e) => setLogType(e.target.value)}
              value={logType}
              className="radioStyle"
            >
              {TACT_MEMORY_LIST.map((item) => (
                <>
                  <Radio value={item.id} key={item.id}>
                    {item.title}
                  </Radio>
                </>
              ))}
            </Radio.Group>
          </div>
          <div
            css={SS.tsMemoryDumpContentItemStyle}
            className="upload column-2"
          >
            <Upload
              label={'Log Files'}
              type={'Drag'}
              uploadProps={logFilesProps}
            />
          </div>
          <div
            css={SS.tsMemoryDumpContentItemStyle}
            className="upload column-2"
            style={{ display: 'flex', justifyContent: 'space-between' }}
          >
            <span className="label">Auto Adjustment</span>
            <Switch
              style={{ left: '-15px' }}
              checked={mode.auto_adjust}
              onChange={(v) =>
                updateFunc((prev) => ({ ...prev, auto_adjust: v }))
              }
              disabled={logType === E_TACT_MEMORY_DOWNLOADED}
            />
          </div>
        </div>
        <button
          css={SS.customButtonStyle}
          className="tsAbsolute"
          onClick={() => startAnalysis(mode.auto_adjust)}
          disabled={!enableStartButton}
        >
          <PlayCircleOutlined />
          <span>Start</span>
        </button>
      </div>
    </>
  );
};
MemorySource.propTypes = {
  updateFunc: PropTypes.func,
  mode: PropTypes.object,
};
export default MemorySource;
