import useModal from '../../../../libs/util/modalControl/useModal';
import ProcessingModal from '../../../common/organisms/ProcessingModal/ProcessingModal';
import { getGraphImage2 } from '../../../../libs/util/plotly-test';
import useTactMemoryDump from './useTactMemoryDump';
import { postTactMemoryExport } from '../../../../libs/axios/tactMemoryRequest';

const useTactMemoryDownload = () => {
  const { openModal, closeModal } = useModal();
  const { gTactMemoryRows, gTactMemoryOrigin } = useTactMemoryDump();

  const makeImageFileName = (v) => {
    console.log(v);
    return `plate_${v.split('memory_plate_')[1]}`;
  };
  const downloadFunc = async () => {
    openModal(ProcessingModal, {
      title: 'Export',
      message: 'Compressing data',
    });

    const FormObj = new FormData();
    console.log('==============settings.json======================');
    FormObj.append(
      'files',
      new Blob(
        [
          JSON.stringify({
            origin: gTactMemoryOrigin,
            selectedRows: gTactMemoryRows,
          }),
        ],
        {
          type: 'application/json',
        },
      ),
      `data.json`,
    );
    console.log('==============getGraphImage======================');
    const imgData = await getGraphImage2('.');
    imgData.forEach((v) => {
      FormObj.append('files', new File([v.url], makeImageFileName(v.filename)));
    });

    await postTactMemoryExport({ obj: FormObj }).then((_) => _);
    closeModal(ProcessingModal);
  };
  return {
    downloadFunc,
  };
};
export default useTactMemoryDownload;
