import useTactMemoryDump from './useTactMemoryDump';
import { useCallback, useMemo, useState } from 'react';

const useTactMemoryGraph = () => {
  const [filterPlate, setFilterPlate] = useState([]);
  const { gTactMemoryRows, gTactMemoryOrigin } = useTactMemoryDump();

  const graphPlateNoList = useMemo(
    () => Object.keys(gTactMemoryRows ?? {}),
    [gTactMemoryRows],
  );
  const getPlateDataList = useCallback(
    (plate_no) =>
      gTactMemoryRows[plate_no].map((arrKey) => gTactMemoryOrigin[arrKey - 1]),
    [gTactMemoryRows, gTactMemoryOrigin],
  );
  const FilterPlateNoOptions = {
    mode: 'multiple',
    style: {
      width: '400px',
    },
    labelInValue: true,
    showSearch: true,
    value: filterPlate,
    onChange: (newValue) => {
      console.log('newValue', newValue);
      setFilterPlate(newValue.map((o) => o.value));
    },
    filterOption: (input, option) => {
      return option.children.toLowerCase().includes(input.toLowerCase());
    },
    optionFilterProp: 'children',
    placeholder: 'Enter the Plate No.',
    maxTagCount: 'responsive',
  };

  return {
    filterPlate,
    setFilterPlate,
    graphPlateNoList,
    getPlateDataList,
    FilterPlateNoOptions,
  };
};

export default useTactMemoryGraph;
