import { useGetTactMemoryAnalysisResult } from '../../../../hooks/query/tactMemoryDump';
import { RequestOnError } from '../../../../libs/util/common/common';
import useTactMemoryDump from './useTactMemoryDump';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import FilterOutlined from '@ant-design/icons/lib/icons/FilterOutlined';
import { Button, Col, InputNumber, Row, Slider, Tag } from 'antd';
import { filterStyle } from '../styles/memoryStyles';
import { E_TACT_MEMORY_DOWNLOADED } from '../../../../constants/etc';
const TagColor = ['magenta', 'orange', 'green', 'purple', 'gray'];
const useTactMemoryDumpTable = () => {
  const [data, setData] = useState(undefined);
  const [selectedRows, setSelectedRows] = useState([]);
  const {
    gTactMemory,
    updateTactMemorySelectedRows,
    gTactMemoryOrigin,
    gTactMemoryRows,
    updateTactMemoryOriginData,
    removeMemoryGraph,
    updateTactMemorySources,
  } = useTactMemoryDump();
  const [filteredDataSource, setFilteredDataSource] = useState(null);

  const [filterRangeValue, setFilterRangeValue] = useState({
    right: 0,
    left: 0,
    max: 0,
    min: 0,
  });

  const handleReset = (clearFilters, setSelectedKeys) => {
    clearFilters();
    setFilterRangeValue((prev) => ({
      ...prev,
      right: prev.max,
      left: prev.min,
    }));
    setFilteredDataSource(null);
    setSelectedKeys(undefined);
  };
  const filterList = useMemo(
    () =>
      gTactMemoryOrigin
        .filter(
          (o) =>
            o.time <= filterRangeValue.right && filterRangeValue.left <= o.time,
        )
        .map((j) => j.key),
    [gTactMemoryOrigin, filterRangeValue?.right, filterRangeValue?.left],
  );

  const getFilteredChild = (cur, list) => {
    const children = (cur?.children ?? [])
      .map((o) => getFilteredChild(o, list))
      .filter((o) => o ?? false);
    if ((list ?? filterList).includes(cur.key)) {
      return cur.children === undefined
        ? cur
        : { ...cur, children: children.length > 0 ? children : undefined };
    } else {
      return cur.children === undefined
        ? null
        : children.length > 0
        ? [...children]
        : null;
    }
  };
  const updateRange = ({ range }) => {
    const [right, left] = [
      range?.right ?? filterRangeValue.right,
      range?.left ?? filterRangeValue.left,
    ];
    setFilterRangeValue((prev) => ({ ...prev, right: right, left: left }));
  };
  const updateFilter = ({ setSelectedKeys, dataIndex }) => {
    const { right, left, min, max } = filterRangeValue;
    setFilteredDataSource(undefined);
    if (right === max && left === min) {
      setSelectedKeys(undefined);
      setFilteredDataSource(null);
    } else {
      setSelectedKeys((prev) =>
        prev
          .filter((o) => o[dataIndex] <= right && left <= o[dataIndex])
          .filter((j) => filterList.includes(j.key)),
      );
      setTimeout(() => {
        console.log('filterList', filterList);
        const filteredData = data.reduce((acc, cur) => {
          const child_data = getFilteredChild(cur, filterList);
          if (child_data ?? false) {
            if (Array.isArray(child_data)) return [...acc, ...child_data];
            else return [...acc, child_data];
          }
          return acc;
        }, []);
        setSelectedKeys((prev) => prev.filter((o) => filterList.includes(o)));
        setSelectedRows((prev) => prev.filter((o) => filterList.includes(o)));
        setFilteredDataSource(filteredData);
      }, 1000);
    }
  };

  const getColumnRangeFilterProps = (dataIndex) => ({
    // eslint-disable-next-line react/display-name
    filterDropdown: ({
      // eslint-disable-next-line react/prop-types
      setSelectedKeys, // eslint-disable-next-line react/prop-types
      confirm, // eslint-disable-next-line react/prop-types
      clearFilters,
    }) => (
      <div style={{ padding: 8 }} css={filterStyle}>
        <div className="title">
          <span>Filter</span>
        </div>
        <Row
          type="flex"
          gutter={10}
          style={{ marginBottom: 8, alignItems: 'center' }}
        >
          <Col>Range:</Col>
          <Col>
            <InputNumber
              value={filterRangeValue.left}
              min={filterRangeValue.min}
              max={filterRangeValue.max}
              onChange={(e) =>
                updateRange({ setSelectedKeys, range: { left: e }, dataIndex })
              }
            />
          </Col>
          <span className="between"> ~ </span>
          <Col>
            <InputNumber
              value={filterRangeValue.right}
              min={filterRangeValue.min}
              max={filterRangeValue.max}
              onChange={(e) =>
                updateRange({ setSelectedKeys, range: { right: e }, dataIndex })
              }
            />
          </Col>
        </Row>
        <Row>
          <Slider
            range
            style={{ width: '100%' }}
            draggableTrack={true}
            value={[filterRangeValue.left, filterRangeValue.right]}
            onChange={(e) =>
              updateRange({
                setSelectedKeys,
                range: { left: e[0], right: e[1] },
                dataIndex,
              })
            }
          />
        </Row>
        <Row>
          <Button
            type="primary"
            block
            size="small"
            style={{ borderRadius: '10px' }}
            onClick={() => {
              updateFilter({ setSelectedKeys, dataIndex });
              confirm({
                closeDropdown: false,
              });
            }}
          >
            Filter
          </Button>
        </Row>
        <Row>
          <Button
            block
            onClick={() =>
              clearFilters && handleReset(clearFilters, setSelectedKeys)
            }
            size="small"
            style={{
              width: '100%',
              marginTop: '10px',
              borderRadius: '10px',
            }}
          >
            Reset
          </Button>
        </Row>
      </div>
    ),
    // eslint-disable-next-line react/display-name
    filterIcon: (filtered) => (
      <FilterOutlined
        style={{
          color: filtered ? '#1890ff' : undefined,
        }}
      />
    ),
    render: (text) => text,
  });

  const memoryDumpTableColumns = [
    {
      title: 'LEVEL',
      dataIndex: 'level',
      key: 'level',
      width: '15%',
      // eslint-disable-next-line react/display-name
      render: (text) => <Tag color={TagColor[text]}>{`LEVEL ${text}`}</Tag>,
    },
    {
      title: 'Name',
      dataIndex: 'puname',
      key: 'puname',
      // eslint-disable-next-line react/display-name
      render: (text, record) => (
        <>
          <Tag color="#55acee">{`${record?.puid ?? ''}`}</Tag> {text}
        </>
      ),
    },
    {
      title: 'Start',
      dataIndex: 'start',
      key: 'start',
      width: '15%',
    },
    {
      title: 'End',
      dataIndex: 'end',
      key: 'end',
      width: '15%',
    },
    {
      title: 'Elapsed',
      dataIndex: 'time',
      key: 'time',
      width: '15%',
      ...getColumnRangeFilterProps('time'),
    },
  ];
  const childrenList = (src, level, obj) => {
    const subLastIdx = src.length - 1;
    if (subLastIdx === -1 || (src?.[subLastIdx].level ?? 0) >= level) {
      return [...src, obj];
    } else {
      const newObj = {
        ...src[subLastIdx],
        children: [
          ...childrenList(src[subLastIdx]?.children ?? [], level, obj),
        ],
      };
      src.splice(subLastIdx, 1);
      src.push(newObj);
      return src;
    }
  };
  const getTableDataSource = useCallback(
    (data) =>
      (data ?? [])
        .map((o, i) => ({ key: i + 1, ...o }))
        .reduce((acc, cur) => {
          const lastIdx = acc.length - 1;
          if (acc.length > 0 && acc[lastIdx]?.level < cur.level) {
            const newObj = {
              ...acc[lastIdx],
              children: [
                ...childrenList(acc[lastIdx]?.children ?? [], cur.level, cur),
              ],
            };
            acc.splice(acc.length - 1, 1);
            acc.push(newObj);
          } else {
            acc.push(cur);
          }
          return acc;
        }, []),
    [childrenList],
  );

  const getAnalysisResult = useGetTactMemoryAnalysisResult({
    rid: gTactMemory?.target?.rid,
    auto_adjust: gTactMemory.auto_adjust,
    options: {
      enabled:
        gTactMemory?.mode !== E_TACT_MEMORY_DOWNLOADED &&
        !!gTactMemory?.target?.rid,
      onError: (err) => {
        RequestOnError(err);
        updateTactMemorySources({
          files: [],
          rid: undefined,
          mode: undefined,
          auto_adjust: false,
          selectedRows: {},
          origin: [],
        });
      },
      onSuccess: (info) => {
        const data = info.map((o, i) => ({ key: i + 1, ...o }));
        updateTactMemoryOriginData(data);
      },
    },
  });
  const rowChildrenList = useCallback((obj, list) => {
    if (obj?.children ?? false) {
      const children = obj.children;
      children.forEach((o) => {
        list.push(o.key);
        if (o?.children ?? false) {
          rowChildrenList(o, list);
        }
      });
    }
  }, []);
  const rowSelectionFunc = useMemo(
    () => ({
      onSelect: (record, selected) => {
        let list = [record.key];
        rowChildrenList(record, list);
        if (selected) {
          setSelectedRows((prev) => [...prev, ...list]);
        } else {
          setSelectedRows((prev) => prev.filter((o) => !list.includes(o)));
        }
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        if (selected) {
          setSelectedRows((prev) => [...prev, ...changeRows.map((o) => o.key)]);
        } else {
          setSelectedRows([]);
        }
      },
      selectedRowKeys: selectedRows,
      checkStrictly: true,
    }),
    [selectedRows, setSelectedRows],
  );

  const expandableFunc = {
    expandRowByClick: false,
    defaultExpandAllRows: true,
  };

  const storeSelectedRows = () => {
    console.log('storeSelectedRows....');
    updateTactMemorySelectedRows(gTactMemoryOrigin, selectedRows);
    removeMemoryGraph();
  };
  const onRowEventFunc = useCallback(
    (record) => ({
      onClick: () =>
        setSelectedRows((prev) =>
          prev.includes(record.key)
            ? prev.filter((o) => o !== record.key)
            : [...prev, record.key],
        ),
    }),
    [setSelectedRows],
  );

  useEffect(() => {
    const time = (gTactMemoryOrigin ?? []).map((o) => o.time);
    const [min, max] = [
      Math.floor(Math.min(...time)),
      Math.ceil(Math.max(...time)),
    ];
    const data = getTableDataSource(gTactMemoryOrigin);

    if (Object.keys(gTactMemoryRows).length > 0) {
      const selectedRowKeys = Object.keys(gTactMemoryRows).reduce(
        (acc, keys) => {
          return [...acc, ...gTactMemoryRows[keys]];
        },
        [],
      );
      setSelectedRows(selectedRowKeys.map(Number));
      setFilterRangeValue({
        right: max,
        max: max,
        left: min,
        min: min,
      });
      setFilteredDataSource(null);
    } else {
      const filterList = gTactMemoryOrigin
        .filter((o) => o.time <= max && 0.5 <= o.time)
        .map((j) => j.key);
      setSelectedRows([]);
      const filteredData = data.reduce((acc, cur) => {
        const child_data = getFilteredChild(cur, filterList);
        if (child_data ?? false) {
          if (Array.isArray(child_data)) return [...acc, ...child_data];
          else return [...acc, child_data];
        }
        return acc;
      }, []);
      setFilteredDataSource(filteredData);
      setFilterRangeValue({
        right: max,
        max: max,
        left: 0.5,
        min: min,
      });
    }
    setData(data);
  }, [gTactMemoryOrigin]);

  return {
    getAnalysisResult,
    data,
    files: gTactMemory?.files,
    memoryDumpTableColumns,
    selectedRows,
    setSelectedRows,
    rowSelectionFunc,
    expandableFunc,
    onRowEventFunc,
    storeSelectedRows,
    filterRV: filterRangeValue,
    filteredDataSource,
    setFilteredDataSource,
    getFilteredChild,
  };
};

export default useTactMemoryDumpTable;
