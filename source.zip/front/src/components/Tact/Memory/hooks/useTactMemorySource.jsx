import { useMemo, useState } from 'react';
import {
  E_TACT_MEMORY_COPY_FILES,
  E_TACT_MEMORY_DOWNLOADED,
  E_TACT_MEMORY_LOG_SERVER,
} from '@constants/etc';
import ProcessingModal from '../../../common/organisms/ProcessingModal/ProcessingModal';
import {
  defaultUploadProps as defaultProps,
  RequestOnError,
} from '../../../../libs/util/common/common';
import useModal from '../../../../libs/util/modalControl/useModal';
import { PercentProcessingModal } from '../../../common/organisms/ProcessingModal';
import {
  useGetTactMemoryConvertedStatus,
  usePostTactMemoryUploadLogFiles,
} from '@hooks/query/tactMemoryDump';
import useTactMemoryDump from './useTactMemoryDump';
import { NotificationBox } from '../../../common/molecules/NotificationBox';

const MAX_MEMORY_LOG_FILES = 100;
const useTactMemorySource = () => {
  const [copyLogFiles, setCopyLogFiles] = useState([]);
  const [serverLogFiles, setServerLogFiles] = useState([]);
  const [importLog, setImportLog] = useState([]);
  const [logType, setLogType] = useState(E_TACT_MEMORY_COPY_FILES);
  const { openModal, closeModal } = useModal();
  const { updateTactMemorySources, removeMemoryGraph } = useTactMemoryDump();
  const uploadFiles = usePostTactMemoryUploadLogFiles();

  const copyLogFilesProps = defaultProps(
    MAX_MEMORY_LOG_FILES,
    copyLogFiles,
    setCopyLogFiles,
  );
  const serverLogFilesProps = defaultProps(
    MAX_MEMORY_LOG_FILES,
    serverLogFiles,
    setServerLogFiles,
  );
  const downloadedLogFilesProps = {
    ...defaultProps(1, importLog, setImportLog),
    accept: '.json',
  };

  const uploadCompletedFunc = (rid) => {
    console.log('uploadCompleted', rid);
    updateTactMemorySources({
      rid: rid,
    });
  };
  const startAnalysis = (auto_adjust) => {
    removeMemoryGraph();
    updateTactMemorySources({
      files: (logType === E_TACT_MEMORY_COPY_FILES
        ? copyLogFiles
        : logType === E_TACT_MEMORY_LOG_SERVER
        ? serverLogFiles
        : importLog
      ).map((o) => ({ ['uid']: o.uid, ['name']: o.name })),
      rid: undefined,
      mode: logType,
      auto_adjust: auto_adjust ?? false,
      selectedRows: {},
      origin: [],
    });
    if (logType === E_TACT_MEMORY_DOWNLOADED) {
      try {
        const fileReader = new FileReader();
        fileReader.onloadend = () => {
          const { origin, selectedRows } = JSON.parse(fileReader.result);
          updateTactMemorySources({
            files: importLog.map((o) => ({ ['uid']: o.uid, ['name']: o.name })),
            origin: origin ?? [],
            selectedRows: selectedRows ?? {},
          });
        };
        fileReader.onerror = () => {
          console.log('fileReader.onerror');
          NotificationBox({
            title: `Failed to read file!`,
            message: fileReader.error,
            time: 0,
            isError: true,
          });
        };
        if (importLog[0] !== undefined) {
          fileReader.readAsText(importLog[0]);
        }
      } catch (e) {
        RequestOnError(e);
      }
    } else {
      openModal(ProcessingModal, {
        title: 'Converting',
        message: 'Converting files',
        useCancel: true,
        onCancel: uploadFiles.cancel,
      });
      const formData = new FormData();
      const logFiles =
        logType === E_TACT_MEMORY_COPY_FILES
          ? copyLogFiles
          : logType === E_TACT_MEMORY_LOG_SERVER
          ? serverLogFiles
          : importLog;
      if (logFiles.length > 0) {
        logFiles.map((o) => formData.append('files', o));
      }
      formData.append('log_type', logType);
      uploadFiles.mutate(formData, {
        onError: (err) => {
          RequestOnError(err);
          updateTactMemorySources({
            files: [],
            rid: undefined,
          });
        },
        onSuccess: (info) => {
          openModal(PercentProcessingModal, {
            statusFunc: useGetTactMemoryConvertedStatus,
            rid: info?.rid ?? null,
            onCancel: () => closeModal(PercentProcessingModal),
            onClose: () => closeModal(PercentProcessingModal),
            completeFunc: uploadCompletedFunc,
          });
        },
        onSettled: () => {
          closeModal(ProcessingModal);
        },
      });
    }
  };
  const enableStartButton = useMemo(() => {
    return (
      (logType === E_TACT_MEMORY_COPY_FILES
        ? copyLogFiles
        : logType === E_TACT_MEMORY_DOWNLOADED
        ? importLog
        : serverLogFiles
      ).length > 0
    );
  }, [logType, copyLogFiles, importLog, serverLogFiles]);

  return {
    logFilesProps:
      logType === E_TACT_MEMORY_COPY_FILES
        ? copyLogFilesProps
        : logType === E_TACT_MEMORY_DOWNLOADED
        ? downloadedLogFilesProps
        : serverLogFilesProps,
    logType,
    setLogType,
    startAnalysis,
    enableStartButton,
  };
};

export default useTactMemorySource;
