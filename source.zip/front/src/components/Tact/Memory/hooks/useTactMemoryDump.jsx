import { useCallback, useState } from 'react';
import {
  getTactMemory,
  initialMemoryDumpReducer,
  UpdateTactMemoryDumpReducer,
} from '@reducers/slices/TactInfo';
import { useDispatch, useSelector } from 'react-redux';
import { getParseData } from '@libs/util/util';

const useTactMemoryDump = () => {
  const dispatch = useDispatch();
  const gTactMemory = useSelector(getTactMemory);
  const [memoryDumpMode, setMemoryDumpMode] = useState({
    current: undefined,
    auto_adjust: true,
    data: {},
  });

  const initialized = useCallback(() => {
    dispatch(initialMemoryDumpReducer());
  }, [dispatch]);
  const updateTactMemorySources = useCallback(
    (value) => {
      console.log('value', value);
      dispatch(UpdateTactMemoryDumpReducer(value));
    },
    [dispatch],
  );
  const updateTactMemorySelectedRows = useCallback(
    (origin, value) => {
      console.log('origin', origin);
      console.log('value', value);
      const Object = Array.isArray(value)
        ? value
            .map((rowKey) => ({ [rowKey]: origin[rowKey - 1].plate_no }))
            .reduce((acc, obj) => {
              const data = getParseData(obj);
              if (data.value in acc) {
                acc[data.value].push(data.id);
              } else {
                return { ...acc, [data.value]: [data.id] };
              }
              return acc;
            }, {})
        : value;
      console.log('Object', Object);
      dispatch(UpdateTactMemoryDumpReducer({ selectedRows: Object }));
    },
    [dispatch],
  );

  const updateTactMemoryOriginData = useCallback(
    (value) => {
      dispatch(UpdateTactMemoryDumpReducer({ origin: value }));
    },
    [dispatch],
  );
  const updateTactMemoryDownloadData = useCallback(
    (origin, Rows) => {
      console.log('origin', origin);
      console.log('Rows', Rows);
      dispatch(
        UpdateTactMemoryDumpReducer({ origin: origin, selectedRows: Rows }),
      );
    },
    [dispatch],
  );
  const removeMemoryGraph = () => {
    const element = document.querySelector(`.Memory-graph`);
    const graphs = element?.querySelectorAll('.js-plotly-plot');
    (graphs ?? []).forEach((item) => {
      item.classList.remove('js-plotly-plot');
      while (item.hasChildNodes()) item.removeChild(item.firstChild);
    });
  };
  return {
    gTactMemory,
    initialized,
    updateTactMemorySources,
    updateTactMemorySelectedRows,
    updateTactMemoryOriginData,
    updateTactMemoryDownloadData,
    memoryDumpMode,
    setMemoryDumpMode,
    gTactMemoryRows: gTactMemory?.target?.selectedRows,
    gTactMemoryOrigin: gTactMemory?.target?.origin,
    removeMemoryGraph,
  };
};

export default useTactMemoryDump;
