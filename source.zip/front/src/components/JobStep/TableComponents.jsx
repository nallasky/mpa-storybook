import {
  Cascader,
  Checkbox,
  Form,
  Input,
  InputNumber,
  Select,
  Tooltip,
} from 'antd';
import { MSG_CONFIRM_DELETE } from '@constants/Message';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { getParseData } from '@libs/util/util';
import DeleteButton from '../common/molecules/PopConfirmButton/DeleteButton';
const { Option } = Select;

const CheckBoxComponent = ({
  record,
  target,
  checkHandler,
  disabled,
  type,
}) => {
  return (
    <>
      {' '}
      <Checkbox
        /*key,target, value ,type*/
        onChange={(e) =>
          checkHandler(record.key, target, e.target.checked, type)
        }
        checked={record?.[target] ?? false}
        disabled={disabled ?? false}
      />
    </>
  );
};
CheckBoxComponent.propTypes = {
  checkHandler: PropTypes.func,
  record: PropTypes.object,
  target: PropTypes.string,
  type: PropTypes.string,
  disabled: PropTypes.bool,
};

const DeleteComponent = ({ record, type, deleteHandler, disabled }) => {
  return (
    <>
      {' '}
      <DeleteButton
        deleteHandler={() => deleteHandler(record.key, type)}
        disabled={disabled ?? false}
        title={MSG_CONFIRM_DELETE}
      />
    </>
  );
};
DeleteComponent.propTypes = {
  deleteHandler: PropTypes.func,
  record: PropTypes.object,
  type: PropTypes.string,
  disabled: PropTypes.bool,
};

const InputComponent = ({
  record,
  target,
  type,
  onChange,
  onClick,
  disabled,
  size,
  validator,
  errMsg,
}) => {
  const [form] = Form.useForm();
  const [validateStatus, setValidateStatus] = useState({
    status: '',
    errMsg: undefined,
  });

  const onclick = () => {
    if (onClick !== undefined) {
      onClick({ record, target, type });
    }
  };
  const onFormLayoutChange = (e) => {
    const event = getParseData(e);
    onChange({ record, target, type, value: event.value });
  };

  useEffect(() => {
    form.setFieldsValue({ [target]: record[target] });
    if (validator && !disabled) {
      const validator1 = validator(record[target]);
      setValidateStatus(
        validator1.status === 'error'
          ? { status: 'error', errMsg: validator1.errMsg }
          : { status: '', errMsg: undefined },
      );
    } else {
      setValidateStatus({ status: '', errMsg: undefined });
    }
  }, [record[target]]);
  useEffect(() => {
    console.log('errMsg', errMsg);
    const msg = errMsg?.find((o) => o.key === target)?.reason;
    if (msg) {
      setValidateStatus({ status: 'error', errMsg: msg });
    } else if (validator && !disabled) {
      setValidateStatus(validator(record[target]));
    } else {
      setValidateStatus({ status: '', errMsg: undefined });
    }
  }, [errMsg]);
  return (
    <Form
      form={form}
      initialvalues={{ [target]: record[target] }}
      onValuesChange={onFormLayoutChange}
      layout="inline"
    >
      <Tooltip
        overlayClassName={validateStatus.status}
        title={validateStatus.errMsg}
        visible={!!validateStatus.errMsg}
        trigger="hover"
        placement={'right'}
        color={'var(--ckr-red-5)'}
      >
        <Form.Item
          name={target}
          validateTrigger={['onChange']}
          validateStatus={validateStatus.status}
          style={{
            width: (size ?? 'small') === 'small' ? 120 : 200,
            marginRight: '0',
          }}
        >
          <Input disabled={disabled ?? false} onClick={onclick} />
        </Form.Item>
      </Tooltip>
    </Form>
  );
};
InputComponent.propTypes = {
  onChange: PropTypes.func.isRequired,
  onClick: PropTypes.func,
  record: PropTypes.object.isRequired,
  target: PropTypes.string.isRequired,
  type: PropTypes.string,
  disabled: PropTypes.bool,
  size: PropTypes.string,
  regEx: PropTypes.object,
  validator: PropTypes.func,
  errMsg: PropTypes.array,
};

const InputNumberComponent = ({
  record,
  target,
  type,
  onChange,
  disabled,
  size,
  validator,
}) => {
  const [form] = Form.useForm();
  const [validateStatus, setValidateStatus] = useState({
    status: '',
    errMsg: undefined,
  });

  const onNumberChange = (value) => {
    onChange({ record, target, type, value: value });
  };
  useEffect(() => {
    form.setFieldsValue({ [target]: record[target] });
    if (validator && !disabled) {
      console.log('2: ', target, ':', validator(record[target]));
      setValidateStatus(validator(record[target]));
    }
  }, [record[target]]);
  return (
    <Form
      form={form}
      initialvalues={{ [target]: record[target] }}
      layout="inline"
    >
      <Tooltip
        overlayClassName={validateStatus.status}
        title={validateStatus.errMsg}
        visible={!!validateStatus.errMsg}
        trigger="hover"
        placement={'right'}
        color={'var(--ckr-red-5)'}
      >
        <Form.Item
          name={target}
          validateTrigger={['onChange']}
          validateStatus={validateStatus.status}
        >
          <InputNumber
            min={1}
            max={10000}
            onChange={onNumberChange}
            bordered={true}
            required={!disabled ?? true}
            disabled={disabled ?? false}
            size={'small'}
            style={{
              width: (size ?? 'small') === 'small' ? 60 : 80,
            }}
          />
        </Form.Item>
      </Tooltip>
    </Form>
  );
};
InputNumberComponent.propTypes = {
  onChange: PropTypes.func.isRequired,
  record: PropTypes.object.isRequired,
  target: PropTypes.string.isRequired,
  type: PropTypes.string,
  disabled: PropTypes.bool,
  size: PropTypes.string,
  regEx: PropTypes.object,
  validator: PropTypes.func,
  errMsg: PropTypes.array,
};

const SelectComponent = ({
  record,
  target,
  options,
  onChange,
  disabled,
  size,
  type,
  validator,
  errMsg,
}) => {
  const [form] = Form.useForm();
  const onFormLayoutChange = (event) => {
    console.log('event', event);
    onChange({ record, target, value: event[target], type });
  };
  const [validateStatus, setValidateStatus] = useState({
    status: '',
    errMsg: undefined,
  });

  useEffect(() => {
    form.setFieldsValue({ [target]: record[target] });
    if (validator && !disabled) {
      const valid = validator(record[target] ?? '');
      setValidateStatus(
        valid.status === 'error'
          ? { status: 'error', errMsg: valid.errMsg }
          : { status: '', errMsg: undefined },
      );
    } else {
      setValidateStatus({ status: '', errMsg: undefined });
    }
  }, [record[target]]);

  useEffect(() => {
    const msg = errMsg?.find((o) => o.key === target)?.reason;
    if (msg) {
      setValidateStatus({ status: 'error', errMsg: msg });
    } else if (validator && !disabled) {
      setValidateStatus(validator(record[target]));
    } else {
      setValidateStatus({ status: '', errMsg: undefined });
    }
  }, [errMsg]);

  return (
    <Form
      form={form}
      initialvalues={{ [target]: record[target] }}
      onValuesChange={onFormLayoutChange}
      layout="inline"
    >
      <Tooltip
        overlayClassName={validateStatus.status}
        title={validateStatus.errMsg}
        visible={!!validateStatus.errMsg}
        trigger="hover"
        placement={'right'}
        color={'var(--ckr-red-5)'}
      >
        <Form.Item
          name={target}
          validateTrigger={['onChange']}
          validateStatus={validateStatus.status}
          style={{
            width: (size ?? 'small') === 'small' ? 120 : 200,
            marginRight: '0',
          }}
        >
          <Select disabled={disabled ?? false}>
            {options?.map((item, idx) => {
              return (
                <Option key={idx} value={item}>
                  {item}
                </Option>
              );
            }) ?? <></>}
          </Select>
        </Form.Item>
      </Tooltip>
    </Form>
  );
};

SelectComponent.propTypes = {
  onChange: PropTypes.func.isRequired,
  record: PropTypes.object.isRequired,
  options: PropTypes.array,
  target: PropTypes.string.isRequired,
  type: PropTypes.string,
  disabled: PropTypes.bool,
  size: PropTypes.string,
  validator: PropTypes.func,
  errMsg: PropTypes.array,
};

const CascaderComponent = ({
  record,
  target,
  options,
  onChange,
  disabled,
  size,
  type,
  multiple,
  selectV,
  validator,
}) => {
  const [form] = Form.useForm();
  const [validateStatus, setValidateStatus] = useState({
    status: '',
    errMsg: undefined,
  });

  const onFormLayoutChange = (event) => {
    console.log('event', event);
    onChange({ record, target, value: event[target], type });
  };

  useEffect(() => {
    form.setFieldsValue({ [target]: selectV });
    if (validator && !disabled) {
      setValidateStatus(
        !selectV.length
          ? { status: 'error', errMsg: undefined }
          : { status: '', errMsg: undefined },
      );
    } else {
      setValidateStatus({ status: '', errMsg: undefined });
    }
  }, [selectV]);

  return (
    <Form
      form={form}
      initialvalues={{ [target]: selectV }}
      onValuesChange={onFormLayoutChange}
      layout="inline"
    >
      <Tooltip
        overlayClassName={validateStatus.status}
        title={validateStatus.errMsg}
        visible={!!validateStatus.errMsg}
        trigger="hover"
        placement={'right'}
      >
        <Form.Item
          name={target}
          validateTrigger={['onChange']}
          validateStatus={validateStatus.status}
          style={{
            width: (size ?? 'small') === 'small' ? 120 : 200,
            marginRight: '0',
          }}
        >
          <Cascader
            disabled={disabled ?? false}
            options={options}
            value={selectV}
            multiple={multiple}
            maxTagCount="responsive"
          />
        </Form.Item>
      </Tooltip>
    </Form>
  );
};

CascaderComponent.propTypes = {
  onChange: PropTypes.func.isRequired,
  record: PropTypes.object.isRequired,
  options: PropTypes.array,
  target: PropTypes.string.isRequired,
  type: PropTypes.string,
  disabled: PropTypes.bool,
  size: PropTypes.string,
  multiple: PropTypes.bool,
  selectV: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  validator: PropTypes.func,
};

const TableComponent = ({ children }) => {
  return <>{children}</>;
};

TableComponent.propTypes = {
  children: PropTypes.node,
};

TableComponent.cascade = CascaderComponent;
TableComponent.select = SelectComponent;
TableComponent.delete = DeleteComponent;
TableComponent.checkbox = CheckBoxComponent;
TableComponent.input = InputComponent;
TableComponent.inputNumber = InputNumberComponent;
export default TableComponent;
