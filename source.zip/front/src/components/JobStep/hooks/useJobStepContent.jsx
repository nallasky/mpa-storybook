import { useContext } from 'react';
import {
  E_STEP_ANALYSIS_SETTING,
  E_STEP_FILTER_SETTING,
  E_STEP_FUNC_SELECT_SETTING,
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_LOG_SELECT_SETTING,
  E_STEP_MULTI_ANALYSIS_SETTING,
  E_STEP_MULTI_VISUAL_SETTING,
  E_STEP_TITLE_SETTING,
} from '@constants/etc';
import Step1_Setting from '@components/JobStep/Step1_Setting';
import Step2_Setting from '@components/JobStep/Step2_Setting';
import Step2_Multi_Setting from '@components/JobStep/MultiAnalysis/Step2_Setting';
import Step3_Setting from '@components/JobStep/Step3_Setting';
import Step3_Multi_Setting from '@components/JobStep/MultiAnalysis/Step3_Setting';
import Step4_Setting from '@components/JobStep/Step4_Setting';
import Step5_Setting from '@components/JobStep/Step5_Setting';
import Step4_Multi_Setting from '@components/JobStep/MultiAnalysis/Step4_Setting';
import { JobStepInfo } from '@components/JobStep/hooks/useJobStepInfo';
import useRuleSettingInfo from '@hooks/common/useRuleSettingInfo';
import useStepSettingInfo from '@hooks/common/useStepSettingInfo';
import { MSG_REMOTE, MSG_SQL } from '@constants/Message';

const useJobStepContent = () => {
  const { stepInfo, data, setData, setLoading, setStepInfo } =
    useContext(JobStepInfo);
  const {
    ruleStepConfig,
    funcStepInfo,
    updateFuncInfo,
    convertStepInfo,
    analysisStepInfo,
    filterStepInfo,
  } = useRuleSettingInfo();
  const {
    addNextStepConfig,
    addStepPreviewAndNext,
    addCurrentStepPreview,
    updateStepSetting,
  } = useStepSettingInfo();

  const nextButton = async () => {
    console.log('nextButton', stepInfo);
    let result = { next: undefined, info: undefined, preview: undefined };

    switch (stepInfo.current) {
      case E_STEP_TITLE_SETTING:
        result = await Step1_Setting.btn_next({
          setLoading,
          func_id: stepInfo.func_id,
        });
        break;
      case E_STEP_LOG_SELECT_SETTING:
        result = await Step2_Setting.btn_next({
          setLoading,
          func_id: stepInfo.func_id,
          convertStepInfo,
          funcStepInfo,
          data: { data: data, func: setData },
        });
        if (result?.info ?? false) {
          updateStepSetting({ info: result.info.config });
        }
        setLoading(false);
        break;
      case E_STEP_FUNC_SELECT_SETTING:
        result = await Step2_Multi_Setting.btn_next({
          setLoading,
          funcStepInfo,
          updateFuncInfo,
          func_id: stepInfo.func_id,
          data: { data: data, func: setData },
        });
        if (result?.info ?? false) {
          updateStepSetting({ info: result.info.config });
        }
        setLoading(false);
        break;
      case E_STEP_LOG_CONVERT_SETTING:
        result = await Step3_Setting.btn_next({
          setLoading,
          convertStepInfo,
          data: { data: data, func: setData },
          func_id: stepInfo.func_id,
          originLog:
            ruleStepConfig.find((obj) => obj.step === E_STEP_LOG_SELECT_SETTING)
              ?.data ?? [],
        });
        setLoading(false);
        break;
      case E_STEP_MULTI_ANALYSIS_SETTING:
        result = await Step3_Multi_Setting.btn_next({
          setLoading,
          analysisStepInfo,
          funcStepInfo,
          data: { data: data, func: setData },
          func_id: stepInfo.func_id,
          originLog:
            ruleStepConfig.find(
              (obj) => obj.step === E_STEP_FUNC_SELECT_SETTING,
            )?.data ?? [],
        });
        setLoading(false);
        break;
      case E_STEP_FILTER_SETTING:
        result = await Step4_Setting.btn_next({
          setLoading,
          filterStepInfo,
          data: { data: data, func: setData },
          originLog:
            ruleStepConfig.find(
              (obj) => obj.step === E_STEP_LOG_CONVERT_SETTING,
            )?.data ?? [],
        });
        setLoading(false);
        break;
      case E_STEP_ANALYSIS_SETTING:
        result = await Step5_Setting.btn_next({
          setLoading,
          analysisStepInfo,
          data: { data: data, func: setData },
          func_id: stepInfo.func_id,
          originLog: [MSG_REMOTE, MSG_SQL].includes(funcStepInfo.source_type)
            ? ruleStepConfig.find(
                (obj) => obj.step === E_STEP_LOG_SELECT_SETTING,
              )?.data?.data ?? []
            : ruleStepConfig.find(
                (obj) => obj.step === E_STEP_LOG_CONVERT_SETTING,
              )?.data ?? [],
        });
        console.log('E_STEP_5 btn_next', result);

        setLoading(false);
        break;
      default:
        break;
    }
    console.log('result:::::::', result);
    if ((result?.preview ?? false) && (result?.next ?? false)) {
      const { preview } = result;
      const { current, list } = stepInfo;
      const cIdx = list.indexOf(current);
      console.log('preview', preview);

      addStepPreviewAndNext({
        next: result?.next ?? list[cIdx + 1],
        preview: preview,
        info: result?.info ?? {},
      });
      console.log(
        'stepInfo.list.includes(result?.next)',
        stepInfo.list.includes(result?.next),
      );
      setStepInfo((prev) => ({
        ...prev,
        current: list.includes(result?.next) ? result?.next : list[cIdx + 1],
      }));
    } else if (result?.next ?? false) {
      const { current, list } = stepInfo;
      console.log(
        'stepInfo.list.includes(result?.next)',
        list.includes(result?.next),
      );
      const cIdx = list.indexOf(current);
      const nextStep = list.includes(result?.next)
        ? result?.next
        : list[cIdx + 1];
      addNextStepConfig({
        next: nextStep,
        info: result?.info ?? {},
        setCurrent: () =>
          setStepInfo((prev) => ({ ...prev, current: nextStep })),
      });
    } else if (result?.preview ?? false) {
      const { preview } = result;
      console.log('preview', preview);
      addCurrentStepPreview({
        current: preview.current,
        info: preview.info,
      });
    } else {
      console.log('');
    }
  };

  const nextStepValid = () => {
    let ret = true;
    switch (stepInfo.current) {
      case E_STEP_TITLE_SETTING:
        ret = Step1_Setting.check_next(funcStepInfo, stepInfo.func_id);
        break;
      case E_STEP_LOG_SELECT_SETTING:
        ret = Step2_Setting.check_next(
          funcStepInfo,
          convertStepInfo,
          !!stepInfo.func_id,
        );
        break;
      case E_STEP_FUNC_SELECT_SETTING:
        ret = Step2_Multi_Setting.check_next({ funcStepInfo });
        break;
      case E_STEP_LOG_CONVERT_SETTING:
        ret = Step3_Setting.check_next(convertStepInfo);
        break;
      case E_STEP_MULTI_ANALYSIS_SETTING:
        ret = Step3_Multi_Setting.check_next(analysisStepInfo);
        break;
      case E_STEP_FILTER_SETTING:
        ret = Step4_Setting.check_next(filterStepInfo);
        break;
      case E_STEP_MULTI_VISUAL_SETTING:
        ret = Step4_Multi_Setting.check_next();
        break;
      case E_STEP_ANALYSIS_SETTING:
        ret = Step5_Setting.check_next(analysisStepInfo);
        break;
      default:
        break;
    }
    console.log('ret', ret);
    return ret;
  };
  const onChange = (e) => {
    console.log('[jobStep ]', e);
    setData((prev) => {
      return { ...prev, ...e };
    });
  };

  const PreviousOnClick = () => {
    let result = { status: '', step: 0 };
    console.log('steps[current].Previous');
    if (stepInfo.current === E_STEP_ANALYSIS_SETTING) {
      result = Step5_Setting.btn_previous(funcStepInfo);
    } else if (stepInfo.current === E_STEP_MULTI_VISUAL_SETTING) {
      result = Step4_Multi_Setting.btn_previous({ funcStepInfo });
    }
    if (result.status === 'pass') {
      setStepInfo((prev) => ({ ...prev, current: result.step }));
    } else {
      const { current, list } = stepInfo;
      const cIdx = list.indexOf(current);
      if (cIdx > 0) {
        setStepInfo((prev) => ({ ...prev, current: list[cIdx - 1] }));
      }
    }
  };

  return {
    PreviousOnClick,
    onChange,
    nextStepValid,
    nextButton,
  };
};
export default useJobStepContent;
