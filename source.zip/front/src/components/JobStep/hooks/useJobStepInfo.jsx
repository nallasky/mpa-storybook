import { createContext, useState } from 'react';
import { useGetJobStepResource } from '@hooks/query/jobStep';
import { RequestOnError } from '@libs/util/common/common';
import useRuleSettingInfo from '@hooks/common/useRuleSettingInfo';
import { E_STEP_END, E_STEP_TITLE_SETTING, RESPONSE_OK } from '@constants/etc';
import { MSG_LOCAL, MSG_MULTI, MSG_REMOTE, MSG_SQL } from '@constants/Message';
import { getArray, getFormdataFiles, getParseJsonData } from '@libs/util/util';
import { StepConfigure } from '@constants/jobStepDefault';
import { postRequestFormData, postRequestJsonData } from '@libs/axios/requests';
import { URL_RESOURCE_SCRIPT } from '@constants/URL';
import { NotificationBox } from '@components/common/molecules/NotificationBox';

const useJobStepInfo = () => {
  const [loading, setLoading] = useState(false);
  const [stepInfo, setStepInfo] = useState({
    current: 0,
    list: [],
    type: undefined,
  });
  const [data, setData] = useState(null);

  const {
    setRuleStepConfig,
    ruleStepConfig,
    funcStepInfo,
    updateFuncInfo,
    analysisStepInfo,
    convertStepInfo,
    visualStepInfo,
    filterStepInfo,
  } = useRuleSettingInfo();

  const getJobStep1Resource = ({ isEdit, func_id, enabled, onSettled }) =>
    useGetJobStepResource({
      isEdit,
      func_id,
      enabled,
      onSuccess: ({ info }) => {
        console.log('======', info);
        const Obj = {
          category: {
            options: info.category.options,
            selected: info.category?.selected ?? func_id,
          },
          title: info?.title ?? '',
          source_type: funcStepInfo.source_type,
        };
        updateFuncInfo(Obj);
        setRuleStepConfig([
          ...ruleStepConfig,
          { step: E_STEP_TITLE_SETTING, config: Obj },
        ]);
      },
      onSettled,
      onError: RequestOnError,
    });

  const saveSetting = (navigate) => {
    console.log('saveSetting start');
    const postRequest = async () => {
      const convertTmp = { ...convertStepInfo };
      const analysisTmp = { ...analysisStepInfo };
      const filterTmp = [...filterStepInfo];
      const visualTmp = { ...visualStepInfo };
      const funcTemp = { ...funcStepInfo };
      const rule_id =
        stepInfo.func_id !== undefined
          ? convertStepInfo?.log_define?.rule_id ?? undefined
          : undefined;
      console.log('rule_id', rule_id);

      const obj = Object.assign(
        {},
        {
          func:
            funcTemp.source_type === MSG_MULTI
              ? {
                  category_id: funcTemp.category.selected,
                  title: funcTemp.title,
                  source_type: MSG_MULTI,
                  info: funcTemp.list.map((o) => {
                    const formList =
                      stepInfo.func_id !== undefined
                        ? ruleStepConfig[1].config?.data?.formList ?? []
                        : [];
                    const form_id =
                      formList.find(
                        (obj) => obj.multi_info_id === o.multi_info_id,
                      )?.multi_info_id ?? null;
                    return o.source_type === MSG_LOCAL
                      ? {
                          func_id: o.sub_func_id,
                          tab_name: o.tab_name,
                          multi_info_id:
                            stepInfo.func_id ?? false ? form_id : null,
                          fid: o.fid,
                          rid: o.rid,
                        }
                      : o.source_type === MSG_REMOTE
                      ? {
                          func_id: o.sub_func_id,
                          tab_name: o.tab_name,
                          multi_info_id:
                            stepInfo.func_id ?? false ? form_id : null,
                          rid: o.rid,
                          db_id: o.info.db_id,
                          table_name: o.info.table_name,
                          equipment_name: o.info.equipment_name,
                          period_start: o.info.selected.start,
                          period_end: o.info.selected.end,
                          time_column: o.info.time_column,
                        }
                      : o.source_type === MSG_SQL
                      ? {
                          func_id: o.sub_func_id,
                          tab_name: o.tab_name,
                          multi_info_id:
                            stepInfo.func_id ?? false ? form_id : null,
                          rid: o.rid,
                          db_id: o.info.db_id,
                          sql: o.info.sql,
                        }
                      : {};
                  }),
                  use_org_analysis: funcTemp.use_org_analysis,
                }
              : {
                  category_id: funcTemp.category.selected,
                  title: funcTemp.title,
                  source_type: funcTemp.source_type,
                  info:
                    funcTemp.source_type === MSG_REMOTE
                      ? {
                          db_id: funcTemp.info.db_id,
                          table_name: funcTemp.info.table_name,
                          equipment_name: funcTemp.info.equipment_name,
                          period_start: funcTemp.info.selected.start,
                          time_column: funcTemp.info.time_column,
                          period_end: funcTemp.info.selected.end,
                        }
                      : funcTemp.source_type === MSG_SQL
                      ? {
                          db_id: funcTemp.info.db_id,
                          sql: funcTemp.info.sql,
                        }
                      : {},
                  script: {
                    file_name: funcTemp?.script?.file_name ?? null,
                    use_script: funcTemp?.script?.use_script ?? false,
                  },
                },
          convert:
            funcTemp.source_type === MSG_MULTI
              ? {}
              : {
                  mode: convertStepInfo.mode,
                  log_define: convertStepInfo?.log_define,
                  info: getArray(convertTmp?.info ?? [], true, false),
                  header: getArray(convertTmp?.header ?? [], true, false),
                  custom: getArray(convertTmp?.custom ?? [], false, false),
                  script: {
                    file_name: convertTmp?.script?.file_name ?? null,
                    use_script: convertTmp?.script?.use_script ?? false,
                  },
                },
          filter:
            funcTemp.source_type === MSG_MULTI
              ? {}
              : {
                  items: getArray(filterTmp, false),
                },
          analysis: {
            type: analysisTmp?.type ?? 'setting',
            setting: {
              items:
                funcTemp.source_type === MSG_MULTI
                  ? getArray(analysisTmp?.items ?? [], false, true).map(
                      (obj) => ({
                        ...obj,
                        source_col: obj.source_col.map((obj2) =>
                          obj2.join('/'),
                        ),
                      }),
                    )
                  : getArray(analysisTmp.items, false, true) ?? [],
              filter_default: analysisTmp.filter_default ?? [],
              aggregation_default: analysisTmp.aggregation_default ?? {},
            },
            script: {
              db_id: analysisTmp?.script?.db_id ?? null,
              sql: analysisTmp?.script?.sql ?? null,
              file_name: analysisTmp?.script?.file_name ?? null,
              use_script: analysisTmp?.script?.use_script ?? false,
            },
          },
          visualization: {
            function_graph_type: visualTmp.function_graph_type,
            items:
              visualTmp.items.length === 0
                ? []
                : visualTmp.items
                    .filter((v) => v !== '')
                    .map((v) => {
                      return {
                        id: v.id,
                        title: v.title,
                        type: v.type,
                        x_axis: v.x_axis,
                        y_axis: v.y_axis.map((o) =>
                          Array.isArray(o) ? o.join('/') : o,
                        ),
                        z_axis: Array.isArray(v.z_axis)
                          ? v.z_axis.join('/')
                          : v.z_axis,
                        x_range_min: v.x_range_min,
                        x_range_max: v.x_range_max,
                        y_range_min: v.y_range_min,
                        y_range_max: v.y_range_max,
                        z_range_min: v.z_range_min,
                        z_range_max: v.z_range_max,
                      };
                    }),
          },
        },
      );
      try {
        const url =
          StepConfigure[E_STEP_END]?.[
            stepInfo.func_id ?? false ? 'edit' : 'new'
          ];
        const { status, info } = await postRequestJsonData(
          stepInfo.func_id ?? false ? `${url}/${stepInfo.func_id}` : url,
          undefined,
          JSON.stringify(obj),
        );
        if (status.toString() === RESPONSE_OK) {
          console.log('info', info);
          const param = getParseJsonData({
            analysis:
              analysisTmp?.script?.file_name ?? false
                ? getFormdataFiles(data?.step5_script ?? null)
                : null,
            convert:
              convertTmp?.script?.file_name ?? false
                ? getFormdataFiles(data?.step3_script ?? null)
                : null,
            preprocess:
              funcTemp?.script?.file_name ?? false
                ? getFormdataFiles(data?.step2_script ?? null)
                : null,
          }).filter((obj) => obj.value !== null);
          const FormObj = new FormData();
          if (param.length > 0) {
            param.map((obj) => FormObj.append(obj.id, obj.value));
            const { status: status2 } = await postRequestFormData(
              `${URL_RESOURCE_SCRIPT}/${
                stepInfo.func_id ?? false ? stepInfo.func_id : info.func_id
              }`,
              FormObj,
            );
            if (status2.toString() === RESPONSE_OK) {
              navigate(-1);
              setLoading(false);
            }
          } else {
            navigate(-1);
            setLoading(false);
          }
        }
      } catch (e) {
        if (e.response) {
          const {
            data: { msg, err },
          } = e.response;
          console.log(e.response);
          NotificationBox({ title: 'ERROR', message: msg ?? err });
        }
        setLoading(false);
      }
    };
    setLoading(true);
    postRequest().then((_) => _);
  };

  return {
    getJobStep1Resource,
    stepInfo,
    data,
    setData,
    setStepInfo,
    setLoading,
    loading,
    saveSetting,
  };
};
export const JobStepInfo = createContext(null);

export default useJobStepInfo;
