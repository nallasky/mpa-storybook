import { useContext } from 'react';
import { JobStep as Message } from '@assets/locale/en';
import { Button } from 'antd';
import GraphAddEdit from '@components/common/organisms/GraphAddEdit/GraphAddEdit';
import Divider from '@components/common/atoms/Divider';
import useModal from '@libs/util/modalControl/useModal';
import * as PStyle from '@components/JobStep/styles/stepPreviewStyle';
import { LineChartOutlined, ReadFilled } from '@ant-design/icons';
import {
  E_MULTI_TYPE,
  E_SINGLE_TYPE,
  E_STEP_ANALYSIS_SETTING,
  E_STEP_FILTER_SETTING,
  E_STEP_FUNC_SELECT_SETTING,
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_LOG_SELECT_SETTING,
  E_STEP_MULTI_ANALYSIS_SETTING,
  E_STEP_MULTI_VISUAL_SETTING,
  E_STEP_TITLE_SETTING,
  E_STEP_VISUAL_SETTING,
} from '@constants/etc';
import useRuleSettingInfo from '@hooks/common/useRuleSettingInfo';
import Step1_Setting from '@components/JobStep/Step1_Setting';
import Step2_Setting from '@components/JobStep/Step2_Setting';
import Step2_Multi_Setting from '@components/JobStep/MultiAnalysis/Step2_Setting';
import Step3_Setting from '@components/JobStep/Step3_Setting';
import Step3_Multi_Setting from '@components/JobStep/MultiAnalysis/Step3_Setting';
import Step4_Setting from '@components/JobStep/Step4_Setting';
import Step5_Setting from '@components/JobStep/Step5_Setting';
import { StepConfigure } from '@constants/StepDefault';
import { JobStepInfo } from '@components/JobStep/hooks/useJobStepInfo';
import useStepSettingInfo from '@hooks/common/useStepSettingInfo';
import Step4_Multi_Setting from '@components/JobStep/MultiAnalysis/Step4_Setting';
import Step6_Setting from '@components/JobStep/Step6_Setting';

const JobStepPreview = () => {
  const {
    ruleStepConfig,
    funcStepInfo,
    convertStepInfo,
    analysisStepInfo,
    filterStepInfo,
    updateFuncInfo,
  } = useRuleSettingInfo();
  const { addCurrentStepPreview } = useStepSettingInfo();
  const { openModal } = useModal();

  const { stepInfo, data, setData } = useContext(JobStepInfo);
  const { type, func_id, current, list } = stepInfo;
  const addGraphData = () => {
    const PreviousStep =
      type === E_SINGLE_TYPE
        ? E_STEP_ANALYSIS_SETTING
        : E_STEP_MULTI_ANALYSIS_SETTING;
    const step = ruleStepConfig.find((obj) => obj.step === PreviousStep);

    return step.data;
  };
  const Enable_Preview = () => {
    let ret = true;
    switch (current) {
      case E_STEP_TITLE_SETTING:
        ret = false;
        break;
      case E_STEP_LOG_SELECT_SETTING:
        ret = Step2_Setting.check_preview(funcStepInfo);
        break;
      case E_STEP_FUNC_SELECT_SETTING:
        ret = Step2_Multi_Setting.check_preview({ funcStepInfo });
        break;
      case E_STEP_LOG_CONVERT_SETTING:
        ret = Step3_Setting.check_preview(convertStepInfo);
        break;
      case E_STEP_MULTI_ANALYSIS_SETTING:
        ret = Step3_Multi_Setting.check_preview(analysisStepInfo);
        break;
      case E_STEP_FILTER_SETTING:
        ret = Step4_Setting.check_preview(filterStepInfo);
        break;
      case E_STEP_ANALYSIS_SETTING:
        ret = Step5_Setting.check_preview(analysisStepInfo);
        break;
      case E_STEP_VISUAL_SETTING:
      case E_STEP_MULTI_VISUAL_SETTING:
        ret = false;
        break;
      default:
        if (StepConfigure[current].preview === undefined) {
          ret = false;
        }
        break;
    }
    return ret;
  };
  const previewOnClick = () => {
    console.log('steps[current].preview', StepConfigure[current].preview);
    const previewRequest = async () => {
      switch (current) {
        case E_STEP_LOG_SELECT_SETTING:
          {
            const result = await Step2_Setting.btn_preview({
              func_id,
              funcStepInfo,
              data,
              setData,
              enable: Step2_Setting.check_preview(funcStepInfo),
            });
            console.log('preview result', result);
            if (result?.data ?? false) {
              addCurrentStepPreview({
                current: result?.step ?? E_STEP_LOG_SELECT_SETTING,
                info: result.data,
              });
            }
          }
          break;
        case E_STEP_FUNC_SELECT_SETTING:
          {
            const result = await Step2_Multi_Setting.btn_preview({
              func_id,
              funcStepInfo,
              updateFuncInfo,
              data,
              setData,
            });
            console.log('preview result', result);
            if (result?.data ?? false) {
              addCurrentStepPreview({
                current: result?.step ?? E_STEP_FUNC_SELECT_SETTING,
                info: result.data,
              });
            }
          }
          break;
        case E_STEP_MULTI_ANALYSIS_SETTING:
          {
            const result = await Step3_Multi_Setting.btn_preview({
              funcStepInfo,
              func_id,
              analysisStepInfo,
              setData,
              data,
              originLog:
                ruleStepConfig.find(
                  (obj) => obj.step === E_STEP_FUNC_SELECT_SETTING,
                )?.data.data ?? [],
            });
            console.log('preview result', result);
            if (result?.data ?? false) {
              addCurrentStepPreview({
                current: result?.step ?? E_STEP_MULTI_ANALYSIS_SETTING,
                info: result.data,
              });
            }
          }
          break;

        case E_STEP_LOG_CONVERT_SETTING:
          {
            const result = await Step3_Setting.btn_preview({
              data,
              setData,
              convertStepInfo,
              func_id,
              originLog:
                ruleStepConfig.find(
                  (obj) => obj.step === E_STEP_LOG_SELECT_SETTING,
                )?.data ?? [],
            });
            console.log('preview result', result);
            if (result?.data ?? false) {
              addCurrentStepPreview({
                current: result?.step ?? E_STEP_LOG_CONVERT_SETTING,
                info: result.data,
              });
            }
          }
          break;
        case E_STEP_FILTER_SETTING:
          {
            const result = await Step4_Setting.btn_preview({
              setData,
              filterStepInfo,
              originLog:
                ruleStepConfig.find(
                  (obj) => obj.step === E_STEP_LOG_CONVERT_SETTING,
                )?.data ?? [],
            });
            console.log('preview result', result);
            if (result?.data ?? false) {
              addCurrentStepPreview({
                current: result?.step ?? E_STEP_FILTER_SETTING,
                info: result.data,
              });
            }
          }
          break;
        case E_STEP_ANALYSIS_SETTING:
          {
            const result = await Step5_Setting.btn_preview({
              analysisStepInfo,
              func_id,
              data,
              setData,
              originLog: list.includes(E_STEP_FILTER_SETTING)
                ? ruleStepConfig.find(
                    (obj) => obj.step === E_STEP_FILTER_SETTING,
                  )?.data ?? []
                : ruleStepConfig.find(
                    (obj) => obj.step === E_STEP_LOG_CONVERT_SETTING,
                  )?.data ?? [],
            });
            console.log('preview result', result);
            if (result?.data ?? false) {
              addCurrentStepPreview({
                current: result?.step ?? E_STEP_ANALYSIS_SETTING,
                info: result.data,
              });
            }
          }
          break;
        default:
          break;
      }
    };
    previewRequest().then((_) => _);
  };
  return (
    <div css={PStyle.PreviewFrameStyle}>
      <div css={PStyle.graphFrameStyle}>
        <div
          css={PStyle.PreviewTitleStyle}
          style={{ fontWeight: '500' }}
        >
          {Message.button.preview}
          {[E_STEP_VISUAL_SETTING, E_STEP_MULTI_VISUAL_SETTING].includes(
            current,
          ) ? (
            <Button
              type="dashed"
              icon={<LineChartOutlined />}
              disabled={!!addGraphData?.row}
              onClick={() =>
                openModal(GraphAddEdit, {
                  data: addGraphData(),
                })
              }
            >
              Add Graph
            </Button>
          ) : (
            <Button
              type="dashed"
              icon={<ReadFilled />}
              disabled={!Enable_Preview()}
              onClick={previewOnClick}
            >
              {Message.button.preview}
            </Button>
          )}
        </div>
        <Divider height={'1'} type={'solid'} style={{ marginBottom: '0' }} />
        <div
          css={[
            PStyle.ContentsFrameStyle,
            [E_STEP_VISUAL_SETTING, E_STEP_MULTI_VISUAL_SETTING].includes(
              current,
            )
              ? PStyle.graphFrameStyle
              : '',
          ]}
        >
          {current === E_STEP_TITLE_SETTING ? (
            <Step1_Setting.view_preview data={data} />
          ) : current === E_STEP_LOG_SELECT_SETTING ? (
            <Step2_Setting.view_preview data={data} />
          ) : current === E_STEP_FUNC_SELECT_SETTING ? (
            <Step2_Multi_Setting.view_preview data={data} type={E_MULTI_TYPE} />
          ) : current === E_STEP_LOG_CONVERT_SETTING ? (
            <Step3_Setting.view_preview data={data} />
          ) : current === E_STEP_MULTI_ANALYSIS_SETTING ? (
            <Step3_Multi_Setting.view_preview data={data} />
          ) : current === E_STEP_FILTER_SETTING ? (
            <Step4_Setting.view_preview data={data} />
          ) : current === E_STEP_MULTI_VISUAL_SETTING ? (
            <Step4_Multi_Setting.view_preview type={type} />
          ) : current === E_STEP_ANALYSIS_SETTING ? (
            <Step5_Setting.view_preview data={data} />
          ) : current === E_STEP_VISUAL_SETTING ? (
            <Step6_Setting.view_preview type={E_SINGLE_TYPE} />
          ) : (
            <div />
          )}
        </div>
      </div>
    </div>
  );
};

export default JobStepPreview;
