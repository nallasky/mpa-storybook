import useRuleSettingInfo from '../../hooks/common/useRuleSettingInfo';
import React, { useEffect, useState, useContext } from 'react';
import { Collapse, Button } from 'antd';
import { SettingFilled } from '@ant-design/icons';
import { MSG_PREVIOUS_TABLE } from '@constants/Message';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import {
  E_SINGLE_TYPE,
  E_STEP_ANALYSIS_SETTING,
  E_STEP_MULTI_ANALYSIS_SETTING,
  E_STEP_VISUAL_SETTING,
} from '@constants/etc';
import GraphManagement from '../common/organisms/GraphManagement/GraphManagement';
import Step5_Setting from './Step5_Setting';
import Step3_Multi_Setting from './MultiAnalysis/Step3_Setting';
import useModal from '../../libs/util/modalControl/useModal';
import { JobStepInfo } from '@components/JobStep/hooks/useJobStepInfo';

const { Panel } = Collapse;

const tableWrapper = css`
  margin: 10px;
  display: flex;
  justify-content: center;
  & table {
    font-size: 14px;
  }
`;

const VisualSetting = ({ data, type }) => {
  const { ruleStepConfig } = useRuleSettingInfo();
  const { openModal } = useModal();
  const [config, setConfig] = useState(null);
  const { stepInfo } = useContext(JobStepInfo);
  useEffect(() => {
    console.log('[STEP6]data: ', data);
    const configData =
      ruleStepConfig.find(
        (item) =>
          item.step ===
          (type === E_SINGLE_TYPE
            ? E_STEP_ANALYSIS_SETTING
            : E_STEP_MULTI_ANALYSIS_SETTING),
      )?.data ?? {};

    setConfig({
      row: configData?.row ?? {},
    });
  }, []);

  if (config === null) return <></>;
  return (
    <>
      <div css={{ width: '100%', minWidth: '75%', paddingBottom: '0.9rem' }}>
        <Collapse defaultActiveKey={[1]}>
          <Panel header={MSG_PREVIOUS_TABLE} key="1">
            <div css={tableWrapper}>
              {stepInfo.current === E_STEP_VISUAL_SETTING ? (
                <Step5_Setting.view_preview data={data} />
              ) : (
                <Step3_Multi_Setting.view_preview data={data} />
              )}
            </div>
          </Panel>
        </Collapse>
      </div>
      <div css={{ width: '100%' }}>
        <Button
          icon={<SettingFilled />}
          shape="round"
          type="primary"
          onClick={() => openModal(GraphManagement, {})}
        >
          User Graph Management
        </Button>
      </div>
    </>
  );
};

VisualSetting.propTypes = {
  data: PropTypes.object,
  type: PropTypes.string,
};
export default VisualSetting;
