import React, { useEffect, useState } from 'react';
import { css } from '@emotion/react';
import Button2 from '../common/atoms/Button';
import { Popconfirm, Spin, Skeleton } from 'antd';
import {
  MSG_CANCEL,
  MSG_CONFIRM_CANCEL,
  MSG_SAVE_SETTING,
} from '@constants/Message';
import { E_SINGLE_TYPE, E_STEP_1 } from '@constants/etc';
import useRuleSettingInfo from '../../hooks/common/useRuleSettingInfo';
import { useNavigate, useParams } from 'react-router-dom';
import {
  StepConfigure,
  LogStep,
  MultiLogStep,
} from '@constants/jobStepDefault';
import { CustomBreadcrumb as Breadcrumb } from '@components/common/molecules/Breadcrumb';
import JobStepHeader from '@components/JobStep/JobStepHeader';
import useJobStepInfo, {
  JobStepInfo,
} from '@components/JobStep/hooks/useJobStepInfo';
import JobStepPreview from '@components/JobStep/JobStepPreview';

import JobStepContents from '@components/JobStep/JobStepContents';

const MenuBarWrapper = css`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
`;
const MenuButton = css`
  font-weight: 400;
  margin-left: 8px;
`;
const bodyFrame = css`
  background: var(--ckr-gray-1);
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 1px;

  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 12px;
  margin: 15px 0px;
`;

const sectionStyle = css`
  font-family: Saira;
  position: relative;
  width: 1440px;
`;

const JobStep = () => {
  const [reLoad, setReLoad] = useState(false);

  const navigate = useNavigate();
  let { func_id, category_id, type } = useParams();
  const { initialRuleSetting } = useRuleSettingInfo();
  const {
    getJobStep1Resource,
    saveSetting,
    stepInfo,
    data,
    setData,
    setStepInfo,
    loading,
    setLoading,
  } = useJobStepInfo();
  const { isLoading, isFetching } = getJobStep1Resource({
    isEdit: !!func_id,
    func_id: func_id ?? category_id,
    enabled: reLoad,
    onSettled: () => setReLoad(false),
  });
  console.log('StepConfigure', StepConfigure);

  useEffect(() => {
    console.log('UseEffect DATA', data);
  }, [data]);

  useEffect(() => {
    console.log('===============JobStep===============');
    setStepInfo({
      current: E_STEP_1,
      list: type === E_SINGLE_TYPE ? LogStep : MultiLogStep,
      func_id: func_id,
      category_id: category_id,
      type,
    });
    setReLoad(true);
    return () => {
      initialRuleSetting();
    };
  }, []);
  return (
    <section css={sectionStyle}>
      <Breadcrumb />
      <JobStepInfo.Provider
        value={{ data, setData, setStepInfo, stepInfo, loading, setLoading }}
      >
        <div>
          <Skeleton
            loading={isLoading || isFetching}
            active
            paragraph={{ rows: 5 }}
          >
            <Spin
              spinning={
                loading &&
                stepInfo.current === stepInfo.list[stepInfo.list.length - 1]
              }
              tip="Applying..."
            >
              <div css={MenuBarWrapper}>
                <Popconfirm
                  title={MSG_CONFIRM_CANCEL}
                  onConfirm={() => navigate(-1)}
                >
                  <Button2 theme={'white'} style={MenuButton}>
                    {MSG_CANCEL}
                  </Button2>
                </Popconfirm>
                <Button2
                  theme={'blue'}
                  disabled={
                    stepInfo.current !== stepInfo.list[stepInfo.list.length - 1]
                  }
                  style={MenuButton}
                  onClick={() => saveSetting(navigate)}
                >
                  {MSG_SAVE_SETTING}
                </Button2>
              </div>
              <div css={bodyFrame}>
                <JobStepHeader />
                <JobStepContents />
                <JobStepPreview />
              </div>
            </Spin>
          </Skeleton>
        </div>
      </JobStepInfo.Provider>
    </section>
  );
};
export default JobStep;
