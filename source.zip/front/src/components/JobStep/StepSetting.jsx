import { Fragment } from 'react';
import PropTypes from 'prop-types';
import {
  E_STEP_ANALYSIS_SETTING,
  E_STEP_FILTER_SETTING,
  E_STEP_FUNC_SELECT_SETTING,
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_LOG_SELECT_SETTING,
  E_STEP_MULTI_ANALYSIS_SETTING,
  E_STEP_MULTI_VISUAL_SETTING,
  E_STEP_TITLE_SETTING,
  E_STEP_VISUAL_SETTING,
} from '@constants/etc';
import Step1_Setting from './Step1_Setting';
import Step2_Setting from './Step2_Setting';
import Step3_Setting from './Step3_Setting';
import Step4_Setting from './Step4_Setting';
import Step5_Setting from './Step5_Setting';
import Step6_Setting from './Step6_Setting';
import Step2_Multi_Setting from './MultiAnalysis/Step2_Setting';
import Step3_Multi_Setting from './MultiAnalysis/Step3_Setting';
import Step4_Multi_Setting from './MultiAnalysis/Step4_Setting';

/*============================================================================
==                         STEP Setting Page                                ==
============================================================================*/

const Contents = ({ current, data, changeFunc }) => {
  return (
    <Fragment>
      {current === E_STEP_TITLE_SETTING ? (
        <Step1_Setting.view_contents onChange={changeFunc} />
      ) : current === E_STEP_LOG_SELECT_SETTING ? (
        <Step2_Setting.view_contents data={data} onChange={changeFunc} />
      ) : current === E_STEP_FUNC_SELECT_SETTING ? (
        <Step2_Multi_Setting.view_contents data={data} onChange={changeFunc} />
      ) : current === E_STEP_LOG_CONVERT_SETTING ? (
        <Step3_Setting.view_contents data={data} onChange={changeFunc} />
      ) : current === E_STEP_MULTI_ANALYSIS_SETTING ? (
        <Step3_Multi_Setting.view_contents data={data} onChange={changeFunc} />
      ) : current === E_STEP_FILTER_SETTING ? (
        <Step4_Setting.view_contents data={data} />
      ) : current === E_STEP_MULTI_VISUAL_SETTING ? (
        <Step4_Multi_Setting.view_contents data={data} onChange={changeFunc} />
      ) : current === E_STEP_ANALYSIS_SETTING ? (
        <Step5_Setting.view_contents data={data} onChange={changeFunc} />
      ) : current === E_STEP_VISUAL_SETTING ? (
        <Step6_Setting.view_contents data={data} />
      ) : (
        <div>{''}</div>
      )}
    </Fragment>
  );
};
Contents.propTypes = {
  current: PropTypes.number,
  data: PropTypes.object,
  changeFunc: PropTypes.func,
  type: PropTypes.string,
};

const StepSetting = ({ children }) => {
  return <div>{children}</div>;
};

StepSetting.propTypes = {
  children: PropTypes.node,
};
StepSetting.contents = Contents;
export default StepSetting;
