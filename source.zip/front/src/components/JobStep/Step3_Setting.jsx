import React from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { Table } from 'antd';
import { CommonRegex } from '@libs/util/regExp';
import {
  R_OK,
  E_STEP_LOG_CONVERT_SETTING,
  E_STEP_ANALYSIS_SETTING,
  E_STEP_FILTER_SETTING,
} from '@constants/etc';
import {
  getArray,
  getFormdataFiles,
  getParseJsonData,
  getTableForm,
} from '@libs/util/util';
import { postRequestFormData } from '@libs/axios/requests';
import { StepConfigure } from '@constants/StepDefault';
import { URL_PREVIEW_CONVERTED } from '@constants/URL';
import { NotificationBox } from '../common/molecules/NotificationBox';
import ConvertSetting from './ConvertSetting';

const tableWrapper = css`
  display: contents;
`;

const notificationWrapper = css`
  & > p:not(:first-of-type) {
    margin-bottom: 0;
  }
  & > p:first-of-type {
    font-weight: bold;
  }
  & > p > span {
    color: var(--ckr-blue-6);
    font-weight: bold;
    margin-right: 0.5rem;
  }
`;

const TableErrorMsg = (info) => {
  const table = Object.keys(info.err);
  const idx = table.findIndex((item) => info.err[item].length !== 0);
  const contents = info.err[table[idx]][0];
  const columnName = contents.msg[0].key;
  const errMsg = `[${contents.msg[0].name}]: ${contents.msg[0].reason}`;
  return (
    <div css={notificationWrapper}>
      <p>[{table[idx]} Columns ] SETTING ERROR</p>
      <p>
        <span>Index:</span> {contents.index + 1}
      </p>
      <p>
        <span>Columns:</span> {columnName}
      </p>
      <p>
        <span>ErrorMsg:</span> {errMsg}
      </p>
    </div>
  );
};
const PreviewRequest = async ({
  convertStepInfo,
  func_id,
  data,
  originLog,
  setData,
}) => {
  const convertTmp = { ...convertStepInfo };

  const infoArr = getArray(convertTmp?.info ?? [], true, false);
  const customArr = getArray(convertTmp?.custom ?? [], false, false);
  const headerArr = getArray(convertTmp?.header ?? [], true, false);

  {
    const obj = Object.assign(
      {},
      {
        data: originLog?.data ?? originLog ?? [],
        convert: {
          log_define:
            convertStepInfo.mode === 'empty'
              ? {
                  log_name: convertStepInfo.log_define.log_name,
                  table_name: convertStepInfo.log_define.table_name,
                }
              : {
                  log_name: convertStepInfo.log_define.log_name,
                  table_name: convertStepInfo.log_define.table_name,
                  rule_name: convertStepInfo.log_define.rule_name,
                },
          info: infoArr ?? [],
          header: headerArr ?? [],
          custom: customArr ?? [],
        },
      },
    );
    const requestObj = getParseJsonData({
      json_data: new Blob([JSON.stringify(obj)], {
        type: 'application/json',
      }),
      mode: convertStepInfo?.mode ?? '',
      func_id: func_id ?? null,
      script_file: getFormdataFiles(data?.step3_script ?? null),
      use_script: convertStepInfo?.script?.use_script ?? false,
    }).filter((obj) => obj.value !== null);
    const FormObj = new FormData();
    requestObj.map((obj) => FormObj.append(obj.id, obj.value));
    try {
      const { info, status } = await postRequestFormData(
        convertStepInfo.mode !== 'empty'
          ? StepConfigure[E_STEP_LOG_CONVERT_SETTING].preview
          : URL_PREVIEW_CONVERTED,
        FormObj,
      );
      console.log('info', info);
      console.log('status', status);
      if (status === R_OK) {
        if (info.result === true) {
          const tableData = getTableForm({ info: info.data, max_row: 5 });
          setData((prevState) => ({
            ...prevState,
            ['convert_header']: tableData.columns,
            ['convert_data']: tableData.dataSource,
            ['convert_error']: undefined,
          }));
          return { data: info.data, step: E_STEP_LOG_CONVERT_SETTING };
        } else {
          console.log('info.result === false1111');
          if (typeof info.err === 'object') {
            const tableData = info?.data
              ? getTableForm({ info: info.data, max_row: 5 })
              : undefined;
            console.log('tableData', tableData);
            setData((prevState) => ({
              ...prevState,
              ['convert_header']: tableData?.columns,
              ['convert_data']: tableData?.dataSource,
              ['convert_error']: {
                info: (info.err?.info ?? []).reduce(
                  (acc, obj) => ({ ...acc, [obj.index]: obj.msg }),
                  {},
                ),
                header: (info.err?.header ?? []).reduce(
                  (acc, obj) => ({ ...acc, [obj.index]: obj.msg }),
                  {},
                ),
                custom: (info.err?.custom ?? []).reduce(
                  (acc, obj) => ({ ...acc, [obj.index]: obj.msg }),
                  {},
                ),
              },
            }));
            NotificationBox({
              title: 'ERROR',
              message: TableErrorMsg(info),
              time: 0,
            });
            return { data: undefined, step: undefined, error: info.err };
          } else {
            NotificationBox({ title: 'ERROR', message: info.err });
          }
          return { data: undefined, step: undefined };
        }
      }
    } catch (e) {
      if (e.response) {
        const {
          data: { msg },
        } = e.response;
        console.log(e.response);
        NotificationBox({ title: 'ERROR', message: msg });
      }
    }
  }
};
const PreviewButtonEvent = ({
  convertStepInfo,
  func_id,
  data,
  originLog,
  setData,
}) => {
  return PreviewRequest({
    convertStepInfo,
    setData,
    func_id,
    data,
    originLog,
  }).then((_) => _);
};

const PreviousButtonEvent = () => {};

const NextButtonEvent = async ({
  setLoading,
  convertStepInfo,
  data,
  func_id,
  originLog,
}) => {
  if (EnableCheck(convertStepInfo) ?? false) {
    setLoading(true);
    const result = await PreviewRequest({
      convertStepInfo,
      setData: data.func,
      func_id,
      data: data.data,
      originLog,
    }).finally(() => setLoading(false));
    if (result.step !== undefined) {
      return {
        info: undefined,
        next:
          convertStepInfo.mode === 'empty'
            ? E_STEP_ANALYSIS_SETTING
            : E_STEP_FILTER_SETTING,
        preview: { current: result.step, info: result.data },
      };
    }
  }
  console.log('next button invalid');
};
const EnableCheck = (convertStepInfo) => {
  const isValidLogName = CommonRegex.test(
    convertStepInfo?.log_define?.log_name ?? '',
  );

  return convertStepInfo.mode === 'empty'
    ? Boolean(convertStepInfo?.log_define?.log_name)
    : Boolean(convertStepInfo?.log_define?.log_name && isValidLogName);
};

const ContentsForm = ({ data, onChange }) => {
  return <ConvertSetting data={data} onChange={onChange} />;
};
ContentsForm.propTypes = {
  data: PropTypes.object,
  onChange: PropTypes.func,
};

const PreviewForm = ({ data }) => {
  if (data == null) return <></>;

  const { convert_header, convert_data, convert_error } = data;

  if (
    convert_header === undefined &&
    convert_data === undefined &&
    convert_error === undefined
  )
    return <></>;

  return (
    <div css={tableWrapper}>
      {convert_header && (
        <Table
          bordered
          pagination={false}
          columns={convert_header}
          dataSource={convert_data}
          size="middle"
          rowKey="key"
          scroll={{ x: 'max-content' }}
        />
      )}
    </div>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const Step3_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step3_Setting.propTypes = {
  children: PropTypes.node,
};
Step3_Setting.btn_next = NextButtonEvent;
Step3_Setting.btn_previous = PreviousButtonEvent;
Step3_Setting.btn_preview = PreviewButtonEvent;
Step3_Setting.check_next = EnableCheck;
Step3_Setting.check_preview = EnableCheck;
Step3_Setting.view_contents = ContentsForm;
Step3_Setting.view_preview = PreviewForm;

export default Step3_Setting;
