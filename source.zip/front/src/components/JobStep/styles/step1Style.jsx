import styled from '@emotion/styled';

export const mixinLists = {
  flex: ({ direction = 'row', align = 'center', justify = 'center' }) => `
    display: flex;
    flex-direction: ${direction};
    align-items: ${align};
    justify-content: ${justify};
  `,
};
export const CommonLogWrapper = styled.div`
  position: relative;
  width: 1440px;
  margin: 2rem 0;
  ${mixinLists.flex({
    direction: 'column',
    justify: 'center',
    align: 'initial',
  })}
  &.view-mode {
    & > .header {
      & > .wrapper {
        & > .buttons {
          justify-content: right;
          & > .left {
            display: none;
          }
        }
      }
    }
    & > .content {
      & > .category-list {
        & > .category {
          & > .title {
            & > input[type='text'] {
              pointer-events: none;
              cursor: initial;
              border-color: transparent;
              background-color: transparent;
            }
            & > button {
              display: none;
            }
          }
          & > .items {
            & > .item {
              cursor: pointer;
              box-shadow: 0px 2px 4px 1px rgb(0 0 0 / 20%);
              &:hover {
                background-position: 95%;
                background-color: var(--ckr-blue-5);
              }
              &:active {
                transition: all 0.2s;
                box-shadow: none;
                transform: translateY(2px);
              }
              & > .titles-and-buttons {
                & > .titles {
                  width: 100%;
                  max-width: 307px;
                }
                & > .buttons {
                  display: none;
                }
              }
            }
          }
        }
      }
    }
  }
`;
