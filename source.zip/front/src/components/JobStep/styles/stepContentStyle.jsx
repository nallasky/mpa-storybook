import { css } from '@emotion/react';
export const directionButton = css`
  font-weight: 400;
  margin-left: 8px;
  box-sizing: border-box;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 8px;
`;
export const TitleFrameStyle = css`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;

  flex: none;
  order: 2;
  align-self: stretch;
  flex-grow: 0;

  margin-top: 10px;
  margin-bottom: 10px;
`;
export const ContentsFrameStyle = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 0px 4px 4px;

  flex: none;
  order: 2;
  align-self: stretch;
  flex-grow: 0;
  margin: 12px 0px;
  & .ant-form-item-label {
    text-align: left;
    max-width: 130px;
  }
`;
