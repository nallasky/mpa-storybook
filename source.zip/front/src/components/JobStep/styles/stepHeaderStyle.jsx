import { css } from '@emotion/react';
export const dividerStyle = css`
  display: flex;
  border: 2px solid var(--ckr-gray-7);
`;

export const StepFrameStyle = css`
  display: contents;
  justify-content: space-between;
  align-items: center;
  & span.ant-steps-icon {
    position: relative;
    top: -2px;
  }
`;
