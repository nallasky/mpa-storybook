import { Fragment, useContext } from 'react';
import { LeftCircleFilled, RightCircleFilled } from '@ant-design/icons';
import { JobStep as Message } from '@assets/locale/en';
import { StepConfigure } from '@constants/jobStepDefault';
import StepSetting from '@components/JobStep/StepSetting';
import * as CStyle from './styles/stepContentStyle';
import { JobStepInfo } from '@components/JobStep/hooks/useJobStepInfo';
import useJobStepContent from '@components/JobStep/hooks/useJobStepContent';
import { Button } from 'antd';

const JobStepContents = () => {
  const { stepInfo, loading, data } = useContext(JobStepInfo);
  const { PreviousOnClick, nextButton, nextStepValid, onChange } =
    useJobStepContent();
  return (
    <Fragment>
      <div css={CStyle.TitleFrameStyle}>
        <Button
          type="dashed"
          css={CStyle.directionButton}
          onClick={PreviousOnClick}
          disabled={stepInfo.current === 0}
        >
          <LeftCircleFilled /> {Message.button.previous}
        </Button>
        <div
          css={{
            textAlign: 'center',
            fontSize: '24px',
            lineHeight: '32px',
          }}
        >
          {StepConfigure[stepInfo?.current ?? 0].description}
        </div>
        <Button
          type="dashed"
          css={CStyle.directionButton}
          onClick={nextButton}
          loading={
            loading &&
            stepInfo.current !== stepInfo.list[stepInfo.list.length - 1]
          }
          disabled={
            !nextStepValid() ||
            stepInfo.current === stepInfo.list[stepInfo.list.length - 1]
          }
        >
          {Message.button.next} <RightCircleFilled />
        </Button>
      </div>
      <div css={CStyle.ContentsFrameStyle}>
        <StepSetting.contents
          current={stepInfo.current}
          data={data}
          changeFunc={onChange}
        />
      </div>
    </Fragment>
  );
};
export default JobStepContents;
