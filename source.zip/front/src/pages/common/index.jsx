export { default as CommonPage } from './Common';
