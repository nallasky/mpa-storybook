import { CommonLog } from '@components/CommonLog';
import BasicPageLayout from '@components/common/templates/BasicPageLayout/BasicPageLayout';

const CommonPage = () => {
  return (
    <BasicPageLayout>
      <CommonLog />
    </BasicPageLayout>
  );
};

export default CommonPage;
