import React from 'react';
import JobAnalysis from '../../components/JobAnalysis/JobAnalysis';
import CustomBreadcrumb from '@components/common/molecules/Breadcrumb/Breadcrumb';
import BasicPageLayout from '@components/common/templates/BasicPageLayout/BasicPageLayout';

const Job = () => {
  return (
    <BasicPageLayout>
      <CustomBreadcrumb />
      <JobAnalysis />
    </BasicPageLayout>
  );
};

export default Job;
