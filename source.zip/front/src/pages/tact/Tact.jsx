import React, { useEffect } from 'react';
import { Route, Switch } from 'react-router-dom';
import ModalProvider from '../../libs/util/modalControl/ModalProvider';
import {
  TACT_MEMORY_DUMP,
  TACT_SETTING,
  TACT_STATUS_MONITOR,
} from '../../constants/URL';
import { Setting } from './settings';
import TactStatusMonitor from '../../components/pages/Tact/StatusMonitor/TactStatusMonitor';
import TactMemoryDump from '../../components/pages/Tact/TSMemoryDump/TactMemoryDump';

const Tact = () => {
  useEffect(() => {
    console.log('Tact component mounted !');
    return () => {
      console.log('Tact component unmounted !');
    };
  }, []);

  return (
    <ModalProvider>
      <Switch>
        <Route path={TACT_STATUS_MONITOR} component={TactStatusMonitor} />
        <Route path={TACT_MEMORY_DUMP} component={TactMemoryDump} />
        <Route path={TACT_SETTING} component={Setting} />
      </Switch>
    </ModalProvider>
  );
};
export default Tact;
