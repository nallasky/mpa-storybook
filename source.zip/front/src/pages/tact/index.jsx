export { Memory as MemoryDumpPage } from './memory';
export { Status as StatusMonitorPage } from './status';
export { Settings as TactSettingsPage } from './settings';
export { TactLog as TactLogSettingPage } from './tactlog';
