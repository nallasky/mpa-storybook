export { default as Tact } from './Tact';
