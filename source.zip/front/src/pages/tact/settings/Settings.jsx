import React from 'react';
import { Breadcrumb } from '../../../components/common/molecules/Breadcrumb';
import { css } from '@emotion/react';
import { TactSettingComp } from '../../../components/Tact/Settings';

export const sectionStyle = css`
  position: relative;
  width: 100%;
  padding: 1rem;
`;

const Settings = () => {
  return (
    <section css={sectionStyle}>
      <Breadcrumb />
      <TactSettingComp />
    </section>
  );
};
export default Settings;
