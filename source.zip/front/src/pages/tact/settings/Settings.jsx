import { useEffect } from 'react';
import { css } from '@emotion/react';
import useTactSetting from '@components/Tact/Settings/hooks/useTactSetting';
import { TactSettingComponent } from '@components/Tact/Settings';
import { CustomBreadcrumb as Breadcrumb } from '@components/common/molecules/Breadcrumb';

export const sectionStyle = css`
  position: relative;
  width: 1440px;
`;

const Settings = () => {
  const { initialSetting } = useTactSetting();
  useEffect(() => {
    return () => {
      console.log('Tact Setting component unmounted !');
      initialSetting();
    };
  }, []);
  return (
    <section css={sectionStyle}>
      <Breadcrumb />
      <TactSettingComponent />
    </section>
  );
};
export default Settings;
