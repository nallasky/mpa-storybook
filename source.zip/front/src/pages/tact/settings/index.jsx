export { default as Settings } from './Settings';
