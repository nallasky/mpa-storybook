import React from 'react';

import { css } from '@emotion/react';
import { TactLogSetting } from '@components/Tact/LOG/TactLogSetting';
import { CustomBreadcrumb as Breadcrumb } from '@components/common/molecules/Breadcrumb';

export const sectionStyle = css`
  position: relative;
  width: 1440px;
  animation: fadeIn 1s;
`;

const TactLog = () => {
  return (
    <section css={sectionStyle}>
      <Breadcrumb />
      <TactLogSetting />
    </section>
  );
};
export default TactLog;
