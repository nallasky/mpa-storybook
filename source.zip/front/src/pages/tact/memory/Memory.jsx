import { CustomBreadcrumb as Breadcrumb } from '@components/common/molecules/Breadcrumb';
import { MemoryDumpComponent } from '@components/Tact/Memory';
import { css } from '@emotion/react';

export const sectionStyle = css`
  position: relative;
  width: 1440px;
`;

const Memory = () => {
  return (
    <section css={sectionStyle}>
      <Breadcrumb />
      <MemoryDumpComponent />
    </section>
  );
};
export default Memory;
