import { CustomBreadcrumb as Breadcrumb } from '@components/common/molecules/Breadcrumb';
import { StatusMonitorComponent } from '@components/Tact/Status';
import { css } from '@emotion/react';

export const sectionStyle = css`
  position: relative;
  width: 1440px;
`;

const Status = () => {
  return (
    <section css={sectionStyle}>
      <Breadcrumb />
      <StatusMonitorComponent />
    </section>
  );
};
export default Status;
