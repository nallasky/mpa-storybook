import React from 'react';
import { css } from '@emotion/react';
import { useRoutes, Link } from 'react-router-dom';
import {
  URL_MAIN,
  CONFIGURATION,
  ANALYSIS,
  OVERLAY,
  TACT,
  FOCUS,
  NEW,
  EDIT,
  CORRECTION,
  ADC_MEASUREMENT,
  OAS_BASELINE,
  STATUS_MONITOR,
  MEMORY_DUMP,
  SETTINGS,
  COMMON_LOG,
  LOG,
  NEW_LOG,
  NEW_RULE,
  EDIT_RULE,
  PRESCAN_COE,
} from '@constants/URL';
import { Main as message } from '@assets/locale/en';
import { ModalProvider, CommonModal } from '@libs/util/modalControl';
import { ConfigPage } from '@pages/configuration';
import { MainPage } from '@pages/main';
import { JobPage } from '@pages/job';
import { CommonPage } from '@pages/common';
import {
  MemoryDumpPage,
  StatusMonitorPage,
  TactSettingsPage,
  TactLogSettingPage,
} from '@pages/tact';
import {
  CorrectionPage,
  MeasurementPage,
  OasBaselinePage,
  OverlayLogSettingPage,
} from '@pages/overlay';
import JobStep from '@components/JobStep/JobStep';
import FocusAnalysisPage from '@pages/focus/analysis/Analysis';
import FocusCorrectionOfExposurePage from '@pages/focus/prescan/CorrectionOfExposure';
import FocusLogPage from '@pages/focus/focuslog/FocusLog';
import AppLayout from '@components/common/templates';
import { VersionInfo } from '@components/Version';
import MainIcon from '@assets/MainIcon.svg';
import { Error } from '@components/Error';
import LogStep from '@components/LogStep/LogStep';
const titleStyle = css`
  width: 1440px;
  display: flex;
  align-items: center;
  user-select: none;
  & > a {
    font-size: 16px;
    font-weight: 700;
    color: var(--ckr-gray-1);
    background: transparent;
    border: unset;
    cursor: pointer;
    &:hover {
      color: var(--ckr-gray-1);
      text-shadow: 0 0 7px #fff, 0 0 10px #fff, 0 0 21px #fff, 0 0 42px #0fa,
        0 0 82px #0fa, 0 0 92px #0fa, 0 0 102px #0fa, 0 0 151px #0fa;
    }
  }
`;

const Router = () => {
  return useRoutes([
    {
      path: URL_MAIN,
      children: [
        { index: true, element: <MainPage /> },
        {
          path: `${CONFIGURATION}/*`,
          children: [
            { index: true, element: <ConfigPage /> },
            { path: NEW_LOG, element: <LogStep /> },
            {
              path: `${NEW_RULE}/:log_name`,
              element: <LogStep />,
            },
            {
              path: `${EDIT_RULE}/:log_name/:rule_id`,
              element: <LogStep />,
            },
          ],
        },
        { path: ANALYSIS, element: <JobPage /> },
        {
          path: `${COMMON_LOG}/*`,
          children: [
            { index: true, element: <CommonPage /> },
            {
              path: `${NEW}/:type/:category_id`,
              element: <JobStep />,
            },
            {
              path: `${EDIT}/:type/:func_id`,
              element: <JobStep />,
            },
          ],
        },
        {
          path: OVERLAY,
          children: [
            { path: CORRECTION, element: <CorrectionPage /> },
            { path: ADC_MEASUREMENT, element: <MeasurementPage /> },
            { path: OAS_BASELINE, element: <OasBaselinePage /> },
            { path: LOG, element: <OverlayLogSettingPage /> },
          ],
        },
        {
          path: TACT,
          children: [
            { path: STATUS_MONITOR, element: <StatusMonitorPage /> },
            { path: MEMORY_DUMP, element: <MemoryDumpPage /> },
            { path: SETTINGS, element: <TactSettingsPage /> },
            { path: LOG, element: <TactLogSettingPage /> },
          ],
        },
        {
          path: FOCUS,
          children: [
            { path: ANALYSIS, element: <FocusAnalysisPage /> },
            { path: LOG, element: <FocusLogPage /> },
            { path: PRESCAN_COE, element: <FocusCorrectionOfExposurePage /> },
          ],
        },
        { path: '*', element: <Error.notfound /> },
      ],
    },
  ]);
};

const Pages = () => {
  return (
    <ModalProvider>
      <AppLayout>
        <AppLayout.Header>
          <div css={titleStyle}>
            <img src={MainIcon} />
            <Link to={URL_MAIN}>{message.title}</Link>
          </div>
        </AppLayout.Header>
        <AppLayout.Content>
          <Router />
        </AppLayout.Content>
        <AppLayout.Footer>
          <VersionInfo />
        </AppLayout.Footer>
      </AppLayout>
      <CommonModal />
    </ModalProvider>
  );
};

export default Pages;
