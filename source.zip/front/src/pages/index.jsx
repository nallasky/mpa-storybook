export { default as Pages } from './Pages';
