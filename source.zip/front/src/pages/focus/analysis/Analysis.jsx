import React from 'react';
import BasicPageLayout from '@components/common/templates/BasicPageLayout/BasicPageLayout';
import CustomBreadcrumb from '@components/common/molecules/Breadcrumb/Breadcrumb';
import FocusAnalysisComponent from '@components/Focus/Analysis/Analysis';

const FocusAnalysisPage = () => {
  return (
    <BasicPageLayout>
      <CustomBreadcrumb />
      <FocusAnalysisComponent />
    </BasicPageLayout>
  );
};

export default FocusAnalysisPage;
