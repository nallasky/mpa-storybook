import React from 'react';
import BasicPageLayout from '@components/common/templates/BasicPageLayout/BasicPageLayout';
import CustomBreadcrumb from '@components/common/molecules/Breadcrumb/Breadcrumb';
import { FocusLogSetting } from '@components/Focus/Log/FocusLogSetting';

const FocusLog = () => {
  return (
    <BasicPageLayout>
      <CustomBreadcrumb />
      <FocusLogSetting />
    </BasicPageLayout>
  );
};

export default FocusLog;
