import React from 'react';
import BasicPageLayout from '@components/common/templates/BasicPageLayout/BasicPageLayout';
import CustomBreadcrumb from '@components/common/molecules/Breadcrumb/Breadcrumb';
import FocusCorrectionOfExposureComponent from '@components/Focus/PreScan/CorrectionOfExposure';

const FocusCorrectionOfExposurePage = () => {
  return (
    <BasicPageLayout>
      <CustomBreadcrumb />
      <FocusCorrectionOfExposureComponent />
    </BasicPageLayout>
  );
};

export default FocusCorrectionOfExposurePage;
