import { Configuration as ConfigComponent } from '@components/Configuration';

const Configuration = () => {
  return <ConfigComponent />;
};

export default Configuration;
