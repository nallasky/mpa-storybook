export { default as ConfigPage } from './Configuration';
