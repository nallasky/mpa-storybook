import React from 'react';
import { MainPage } from '../../components/Main';

const Main = () => {
  return <MainPage />;
};

export default Main;
