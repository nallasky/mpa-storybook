import { useEffect } from 'react';
import { css } from '@emotion/react';
import { Overlay_OasBaseline } from '@components/Overlay/OasBaseline';
import { CustomBreadcrumb as Breadcrumb } from '@components/common/molecules/Breadcrumb';
import useOverlaySettingInfo from '@hooks/common/useOverlaySettingInfo';

export const sectionStyle = css`
  position: relative;
  width: 1440px;
  animation: fadeIn 1s;
  margin: 1rem 0;
`;

const OasBaseline = () => {
  const { initialOverlayInfo } = useOverlaySettingInfo();
  useEffect(() => {
    console.log('Overlay component mounted !');
    return () => {
      console.log('Overlay component unmounted !');
      initialOverlayInfo();
    };
  }, []);
  return (
    <section css={sectionStyle}>
      <Breadcrumb />
      <Overlay_OasBaseline />
    </section>
  );
};
export default OasBaseline;
