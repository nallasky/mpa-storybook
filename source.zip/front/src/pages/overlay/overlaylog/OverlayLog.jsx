import React from 'react';
import { OverlayLogSetting } from '@components/Overlay/LOG/OverlayLogSetting';
import { CustomBreadcrumb as Breadcrumb } from '@components/common/molecules/Breadcrumb';
import BasicPageLayout from '@components/common/templates/BasicPageLayout/BasicPageLayout';

const OverlayLog = () => {
  return (
    <BasicPageLayout>
      <Breadcrumb />
      <OverlayLogSetting />
    </BasicPageLayout>
  );
};
export default OverlayLog;
