import { useEffect } from 'react';
import { Overlay_Measurement } from '@components/Overlay/Measurement';
import { CustomBreadcrumb as Breadcrumb } from '@components/common/molecules/Breadcrumb';
import BasicPageLayout from '@components/common/templates/BasicPageLayout/BasicPageLayout';
import useOverlaySettingInfo from '@hooks/common/useOverlaySettingInfo';

const Measurement = () => {
  const { initialOverlayInfo } = useOverlaySettingInfo();
  useEffect(() => {
    console.log('Overlay component mounted !');
    return () => {
      console.log('Overlay component unmounted !');
      initialOverlayInfo();
    };
  }, []);
  return (
    <BasicPageLayout>
      <Breadcrumb />
      <Overlay_Measurement />
    </BasicPageLayout>
  );
};
export default Measurement;
