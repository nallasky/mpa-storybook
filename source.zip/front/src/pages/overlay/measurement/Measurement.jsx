import React from 'react';
import SelectSource from '../../../components/Overlay/Fragments/SelectSource/SelectSource';
import SelectTarget from '../../../components/Overlay/Fragments/SelectTarget/SelectTarget';
import OverlayResult from '../../../components/Overlay/Fragments/OverlayResult/OverlayResult';
import { OVERLAY_ADC_CATEGORY } from '../../../constants/etc';
import { sectionStyle } from '../../../components/Overlay/Fragments/styleGroup';

const Measurement = () => {
  return (
    <section css={sectionStyle}>
      <SelectSource mode={OVERLAY_ADC_CATEGORY} />
      <SelectTarget mode={OVERLAY_ADC_CATEGORY} />
      <OverlayResult mode={OVERLAY_ADC_CATEGORY} />
    </section>
  );
};
export default Measurement;
