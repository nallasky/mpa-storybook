import React from 'react';
import SelectSource from '../../../components/Overlay/Fragments/SelectSource/SelectSource';
import SelectTarget from '../../../components/Overlay/Fragments/SelectTarget/SelectTarget';
import OverlayResult from '../../../components/Overlay/Fragments/OverlayResult/OverlayResult';
import { OVERLAY_CORRECTION_CATEGORY } from '../../../constants/etc';
import { css } from '@emotion/react';

export const sectionStyle = css`
  position: relative;
  display: grid;
  grid-template-columns: 0.4fr 0.6fr;
  gap: 1rem;
  width: 100%;
  padding: 1rem;
`;

const Correction = () => {
  return (
    <section css={sectionStyle}>
      <SelectSource mode={OVERLAY_CORRECTION_CATEGORY} />
      <SelectTarget mode={OVERLAY_CORRECTION_CATEGORY} />
      <OverlayResult mode={OVERLAY_CORRECTION_CATEGORY} />
    </section>
  );
};

export default Correction;
