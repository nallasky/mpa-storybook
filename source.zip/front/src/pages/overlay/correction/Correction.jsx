import { useEffect } from 'react';
import { Overlay_Correction } from '@components/Overlay/Correction';
import { CustomBreadcrumb as Breadcrumb } from '@components/common/molecules/Breadcrumb';
import BasicPageLayout from '@components/common/templates/BasicPageLayout/BasicPageLayout';
import useOverlaySettingInfo from '@hooks/common/useOverlaySettingInfo';

const Correction = () => {
  const { initialOverlayInfo } = useOverlaySettingInfo();
  useEffect(() => {
    console.log('Overlay component mounted !');
    return () => {
      console.log('Overlay component unmounted !');
      initialOverlayInfo();
    };
  }, []);

  return (
    <BasicPageLayout>
      <Breadcrumb />
      <Overlay_Correction />
    </BasicPageLayout>
  );
};

export default Correction;
