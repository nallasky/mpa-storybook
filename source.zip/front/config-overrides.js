const {
  useBabelRc,
  removeModuleScopePlugin,
  addWebpackPlugin,
  addWebpackAlias,
  override,
  overrideDevServer,
} = require('customize-cra');
const AntdDayjsWebpackPlugin = require('antd-dayjs-webpack-plugin');
const path = require('path');

const devServerConfig = () => (config) => {
  return {
    ...config,
    proxy: {
      '/api': {
        target: process.env.REACT_APP_DEV_SERVER,
        changeOrigin: true,
        secure: false,
      },
    },
  };
};

module.exports = {
  webpack: override(
    addWebpackPlugin(new AntdDayjsWebpackPlugin()), // required loader-utils v2 for webpack v4
    useBabelRc(),
    addWebpackAlias({
      '@assets': path.resolve(__dirname, 'src/assets'),
      '@components': path.resolve(__dirname, 'src/components'),
      '@constants': path.resolve(__dirname, 'src/constants'),
      '@hooks': path.resolve(__dirname, 'src/hooks'),
      '@libs': path.resolve(__dirname, 'src/libs'),
      '@pages': path.resolve(__dirname, 'src/pages'),
      '@reducers': path.resolve(__dirname, 'src/reducers'),
      '@styles': path.resolve(__dirname, 'src/styles'),
      '@typesdef': path.resolve(__dirname, 'src/types'),
      '@': path.resolve(__dirname, 'src'),
    }),
    removeModuleScopePlugin(),
  ),
  devServer: overrideDevServer(devServerConfig()),
  paths: (paths, env) => {
    // ...add your paths config
    console.log('buildPathConfig[env]', env);
    console.log('buildPathConfig[paths]', paths);
    if (env !== 'development') {
      paths.appBuild = path.resolve(
        __dirname,
        process.env.REACT_APP_BUILD_PATH,
      );
    }
    return paths;
  },
};
