import warnings
warnings.filterwarnings("ignore", message=".*pandas only support SQLAlchemy.*")

import datetime
import logging
import sqlite3
import traceback
from abc import *
from copy import deepcopy
from io import StringIO

import pandas as pd
import psycopg2 as pg2

from common.utils.response import ResponseForm
from config.app_config import *
from dao.utils import get_db_config

logger = logging.getLogger(LOG)


class DAOBaseClass(metaclass=ABCMeta):
    def __init__(self, **kwargs):
        self.df = None

        if 'table_name' in kwargs:
            self.table_name = kwargs['table_name'].replace('.', '_')
        else:
            self.table_name = None

        self.config = get_db_config()

        if 'dbpath' in kwargs:
            self.config['dbpath'] = kwargs['dbpath']

        self.connect = sqlite3.connect(self.config['dbpath'], isolation_level=None)     # check_same_thread=False

        if self.connect is not None:
            self.connect.execute("PRAGMA busy_timeout=10000")
            self.connect.execute("PRAGMA foreign_keys = 1")
            self.connect.row_factory = sqlite3.Row
            self.cursor = self.connect.cursor()
        else:
            raise Exception(f'DB Connect Fail.')

    def __del__(self):
        del self.table_name
        del self.config
        del self.df
        self.cursor.close()
        self.connect.close()
        print('__del__', __class__)

    def execute(self, query, args=None):
        if args is None:
            self.cursor.execute(query)
        else:
            self.cursor.execute(query, args)
        row = self.cursor.fetchall()

        return row

    def read_sql(self, query):
        return pd.read_sql(query, self.connect)

    def fetch_one(self, table=None, args=None):
        """
        [sqlite OK] select one from table.

        :return: DataFrame
        """
        if args is None:
            args = {}

        table_name = table
        if table_name is None:
            table_name = self.table_name
        else:
            table_name = table_name.replace('.', '_')

        if 'select' in args:
            if 'where' in args:
                query = 'select %s from %s where %s' % (args['select'], table_name, args['where'])
            else:
                query = 'select %s from %s' % (args['select'], table_name)
        else:
            if 'where' in args:
                query = 'select * from %s where %s' % (table_name, args['where'])
            else:
                query = 'select * from %s' % table_name

        self.cursor.execute(query)
        row = self.cursor.fetchone()

        return row

    def fetch_all(self, table=None, args=None):
        """
        [sqlite OK] select from table.

        :return: DataFrame
        """
        if args is None:
            args = {}

        table_name = table
        if table_name is None:
            table_name = self.table_name
        else:
            table_name = table_name.replace('.', '_')

        if 'select' in args:
            if 'where' in args:
                query = 'select %s from %s where %s' % (args['select'], table_name, args['where'])
            else:
                query = 'select %s from %s' % (args['select'], table_name)
        else:
            if 'where' in args:
                query = 'select * from %s where %s' % (table_name, args['where'])
            else:
                query = 'select * from %s' % table_name

        return pd.read_sql(query, self.connect)

    def connection_check(self):
        """
        [sqlite OK] Check sqlite db.

        :return: ResponseForm
        """
        try:
            # #sqlite
            # query = 'select version()'
            query = 'select sqlite_version()'
            with sqlite3.connect(self.config['dbpath']) as conn:
                cur = conn.cursor()
                cur.execute(query)
                row = cur.fetchall()
            data = row[0][0]
            return ResponseForm(res=True, data=data)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            msg = str(e) if len(str(e)) > 0 else 'Cannot Connect Database. Check username or dbname or password.'
            return ResponseForm(res=False, msg=msg, status=400)

    def update(self, table=None, set=None, where=None):
        """
        [sqlite OK] Update table data.

        :return: ResponseForm
        """
        table_name = table
        if table_name is None:
            table_name = self.table_name
        else:
            table_name = table_name.replace('.', '_')

        if set is not None:
            value_list = list()
            query = 'update {0} set '.format(table_name)
            for key, val in set.items():
                if val is None:
                    query = query + f"{key}=null, "
                else:
                    # #sqlite
                    # query = query + f"{key}=%s, "
                    query = query + f"{key}=?, "
                    value_list.append(val)

            query = query[:-2]

            if where is not None:
                query = query + ' where '
                for key, val in where.items():
                    query = query + "{0}='{1}' and ".format(key, val)
                query = query[:-5]

            # query = query + ' RETURNING *'
            try:
                ret = self.cursor.execute(query, tuple(value_list))

                if ret.rowcount == 0:
                    return ResponseForm(res=False, msg='There is nothing to Update.')

                self.connect.commit()
                return ResponseForm(res=True)
            except Exception as e:
                logger.error(str(e))
                logger.error(traceback.format_exc())
                return ResponseForm(res=False, msg=str(e))
        else:
            return ResponseForm(res=False, msg='Nothing to Update.')

    def insert(self, data=None, rtn_id=False, table=None):
        """
        [sqlite OK] Insert table data.

        :return: ResponseForm
        """
        if data is None:
            data = {}
        table_name = table
        if table_name is None:
            table_name = self.table_name
        else:
            table_name = table_name.replace('.', '_')

        key_str = ','.join(data.keys())
        # #sqlite
        # value_str = ','.join([f"{_}" if isinstance(_, (int, float)) else f"'{_}'" for _ in data.values()])
        value_str = ','.join(['?' for _ in data.values()])
        query = f'insert into {table_name}({key_str}) values({value_str})'

        try:
            self.cursor.execute(query, tuple(data.values()))
            self.connect.commit()
            if rtn_id:
                return ResponseForm(res=True, data=self.cursor.lastrowid)
            else:
                return ResponseForm(res=True)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def drop_tables(self, schema_list=[], omit_schema_list=[], omit_tbl_list=[]):
        """
        drop table.

        :return: ResponseForm
        """
        try:
            with pg2.connect(**self.config) as conn:
                conn.autocommit = True
                with conn.cursor() as cur:
                    for schema in schema_list:
                        if schema not in omit_schema_list:
                            # #sqlite
                            # sql = "SELECT table_schema,table_name FROM information_schema.tables " \
                            #       "WHERE table_schema = '%s' ORDER BY table_schema,table_name" % schema
                            sql = "SELECT name FROM sqlite_schema WHERE type = 'table' AND name LIKE '%s%%' ORDER BY name" % schema
                            cur.execute(sql)
                            tables = cur.fetchall()
                            for table in tables:
                                # #sqlite
                                # tb_name = schema + '.' + table[1]
                                tb_name = table[0]
                                if tb_name not in omit_tbl_list:
                                    sql = 'drop table ' + tb_name + " cascade"
                                    cur.execute(sql)
            return ResponseForm(res=True)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def export_tables_from_schema(self, schema_list, omit_tb_list=None):
        """
        [sqlite OK] Export table data from schema except omit_tb_list.

        :return: ResponseForm
        """
        if omit_tb_list is None:
            omit_tb_list = []
        try:
            data = dict()
            for schema in schema_list:
                # #sqlite
                # sql = "SELECT table_schema,table_name FROM information_schema.tables " \
                #       "WHERE table_schema = '%s' ORDER BY table_schema,table_name" % schema
                sql = "SELECT name FROM sqlite_schema WHERE type = 'table' AND name LIKE '%s%%' ORDER BY name" % schema
                self.cursor.execute(sql)
                tables = self.cursor.fetchall()
                for table in tables:
                    # #sqlite
                    # tb_name = schema + '.' + table[1]
                    tb_name = table[0]
                    if tb_name not in omit_tb_list:
                        buffer = self.fetch_all_as_csv(table=tb_name)
                        data[tb_name] = buffer

            return ResponseForm(res=True, data=data)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def get_table_list_from_schema(self, schema_list, omit_list=None):
        """
        [sqlite OK] Get table list from schema except omit_list.

        :return: ResponseForm
        """
        if omit_list is None:
            omit_list = []

        try:
            table_list = []
            for schema in schema_list:
                # #sqlite
                # sql = "SELECT table_schema,table_name FROM information_schema.tables " \
                #       "WHERE table_schema = '%s' ORDER BY table_schema,table_name" % schema
                sql = "SELECT name FROM sqlite_schema WHERE type = 'table' AND name LIKE '%s%%' ORDER BY name" % schema
                self.cursor.execute(sql)
                tables = self.cursor.fetchall()
                for table in tables:
                    # #sqlite
                    # tb_name = schema + '.' + table[1]
                    tb_name = table[0]
                    if tb_name not in omit_list:
                        table_list.append(tb_name)

            return ResponseForm(res=True, data=table_list)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def fetch_all_as_csv(self, table):
        """
        [sqlite OK] Save table data to buffer.

        :return: None or buffer
        """
        buffer = StringIO()
        try:
            # #sqlite
            # self.cursor.copy_to(buffer, table, sep='\t', null=NA_VALUE)
            # self.connect.commit()
            table_data = pd.read_sql("SELECT * from %s" % table, self.connect)
            table_data.to_csv(buffer, sep='\t', na_rep=NA_VALUE, header=False, index=False)
            return buffer
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return None

    def delete(self, table=None, where_dict=None, where_phrase=None, rtn_id=False):
        """
        [sqlite dummy tested] delete table data from where.

        :return: ResponseForm
        """
        table_name = table
        if table_name is None:
            table_name = self.table_name
        else:
            table_name = table_name.replace('.', '_')

        if where_dict is None and where_phrase is None:
            return ResponseForm(res=False, msg='WHERE condition is empty.')

        query = f"delete from {table_name} where "
        if where_dict is not None:
            for key, val in where_dict.items():
                query = query + "{0}='{1}' and ".format(key, val)
            query = query[:-5]

            if where_phrase is not None:
                query = query + ' and '

        if where_phrase is not None:
            query = query + where_phrase

        # if rtn_id:
        #     query = query + ' RETURNING id'

        try:
            self.cursor.execute(query)
            self.connect.commit()
            if rtn_id:
                if self.cursor.rowcount == 0:
                    return ResponseForm(res=False, msg='Delete Fail. No matching condition.')
                else:
                    return ResponseForm(res=True)
            else:
                return ResponseForm(res=True)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def get_log_period(self, table=None, where=None, column_name='log_time'):
        table_name = table
        if table_name is None:
            table_name = self.table_name
        else:
            table_name = table_name.replace('.', '_')

        try:
            query = f"select to_char(min({column_name}), 'YYYY-MM-DD HH24:MI:SS') as start, " \
                    f"to_char(max({column_name}), 'YYYY-MM-DD HH24:MI:SS') as end from {table_name}"

            if where is not None:
                query = query + ' where '
                for key, val in where.items():
                    query = query + "{0}='{1}' and ".format(key, val)
                query = query[:-5]

            self.cursor.execute(query)
            ret = self.cursor.fetchone()
            if ret is None:
                return ResponseForm(res=False, msg='There is no data')
            else:
                return ResponseForm(res=True, data=dict(ret))
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def get_log_time_min(self):
        return self.df['log_time'].min()

    def get_log_time_max(self):
        return self.df['log_time'].max()

    def load_data(self, table=None, rid=None, select=None, time_column='log_time', **filters):
        fetch_args = dict()
        where = ''
        if select is not None:
            fetch_args['select'] = select

        if rid is not None:
            where = f"request_id='{rid}'"

        for key, val in filters.items():
            if len(where) > 0:
                where = where + ' and '
            if key == time_column:
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                where = where + f"{time_column} between '{filters[key]['start']}' and '{end}'"
            else:
                if isinstance(val, list):
                    if len(val) > 1:
                        val = ["'"+str(v)+"'" for v in val]
                        _in = ','.join(val)
                        cond = f"{key} in ({_in})"
                        where = where + cond
                    else:
                        where = where + f"{key}='{val[0]}'"
                else:
                    where = where + f"{key}='{val}'"

        if len(where) > 0:
            fetch_args['where'] = where

        self.df = self.fetch_all(table=table, args=fetch_args)
        for col in COLUMN_OMIT_LIST:
            if col in self.df.columns:
                self.df.drop(col, axis=1, inplace=True)

        if time_column in self.df.columns:
            # 時間順序で整列
            self.df.sort_values(by=time_column, ascending=True, inplace=True)
            self.df.reset_index(inplace=True, drop=True)

            if time_column != 'log_time':
                self.df.rename(columns={time_column: 'log_time'}, inplace=True)

        return len(self.df)

    def get_df(self):
        return deepcopy(self.df)

    def get_column_info(self, table=None):
        """
        get column info from table.

        :return: DataFrame
        """
        # #sqlite
        # table_name = table
        # if table_name is None:
        #     table_name = self.table_name
        #
        # if '.' in table:
        #     schema_name = table_name.split('.')[0]
        #     table_name = table_name.split('.')[1]
        #
        #     query = f"select column_name, data_type, character_maximum_length from information_schema.columns " \
        #             f"where table_schema='{schema_name}' and table_name='{table_name}'"
        # else:
        #     query = f"select column_name, data_type, character_maximum_length from information_schema.columns " \
        #             f"where table_name='{table_name}'"
        #
        # return pd.read_sql(query, self.connect)

        table_name = table
        if table_name is None:
            table_name = self.table_name
            table_name = table_name.replace('.', '_')
        else:
            table_name = table_name.replace('.', '_')

        query = f"PRAGMA table_info('{table_name}')"
        self.cursor.execute(query)
        desc = self.cursor.fetchall()
        nested_list = list()
        for fields in desc:
            # fileds[1] is name, fields[2] is type
            list_tmp = [fields[1], fields[2], 255]
            nested_list.append(list_tmp)
        df = pd.DataFrame(nested_list, columns=["column_name", "data_type", "character_maximum_length"])
        return df


    def get_column_info_from_rules(self, log_name):
        """
        get column info from rules.

        :return: DataFrame
        """
        sql = f"select id from cnvbase_log_define_master where log_name='{log_name}'"
        self.cursor.execute(sql)
        ret = self.cursor.fetchone()
        if ret is None:
            return pd.DataFrame()

        sql = f"select id from cnvbase_convert_rule where log_id={ret['id']}"
        rule_df = pd.read_sql(sql, self.connect)

        # List all output columns from all rules.
        output_column_list = list()

        for i in range(len(rule_df)):
            sql = f"select * from cnvbase_convert_rule_item where rule_id={rule_df['id'].values[i]}"
            items_df = pd.read_sql(sql, self.connect)
            for item_index in items_df[items_df['output_column'] != ''].index:
                item = items_df.loc[item_index]
                output_column = item['output_column'].lower()
                if output_column not in [o['column_name'] for o in output_column_list]:
                    output_column_list.append({
                        'column_name': output_column,
                        'data_type': item['data_type']
                    })

        df = pd.DataFrame(output_column_list)
        return df

    def remove_all_records(self, schema_list, omit_tb_list):
        """
        [sqlite OK] delete all tables.

        :return: ResponseForm
        """
        try:
            data = dict()
            for schema in schema_list:
                # #sqlite
                # sql = "SELECT table_schema,table_name FROM information_schema.tables " \
                #       "WHERE table_schema = '%s' ORDER BY table_schema,table_name" % schema
                sql = "SELECT name FROM sqlite_schema WHERE type = 'table' AND name LIKE '%s%%' ORDER BY name" % schema
                self.cursor.execute(sql)
                tables = self.cursor.fetchall()
                for table in tables:
                    # tb_name = schema + '.' + table[1]
                    tb_name = table[0]
                    if tb_name not in omit_tb_list:
                        # #sqlite
                        # sql = f"truncate table {tb_name} restart identity cascade"
                        sql = f"DELETE FROM {tb_name}"
                        self.cursor.execute(sql)
                        sql = f"UPDATE sqlite_sequence SET seq=0 where name='{tb_name}'"
                        self.cursor.execute(sql)
                        self.connect.commit()

            return ResponseForm(res=True, data=data)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))
