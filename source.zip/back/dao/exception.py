class DatabaseQueryException(Exception):
    pass

class DatabaseConnectError(Exception):
    pass