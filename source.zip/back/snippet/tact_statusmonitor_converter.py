import datetime
import psycopg2
import json
import datetime
import os
import pandas as pd
import numpy as np

class StatusMonitorConveter():
    # 機能名
    FUNCTION_STATUS_MONITOR = 'StatusMonitor'
    json_list = []
    ADC = 0
    FDC = 1

    def status_monitor_conveter(self, data_list):
        # LotIdBlock用の変数
        listCnt = 1
        lot_id_block = ''
        lot_id_block_cnt = 0
        cont_day = ''  # データが継続している場合、値が入る
        adc_fdc = 0
        # LotEnd確認用の変数
        lotEndCnt = 0
        lotEndId = ''
        first_log = True
        update_flg = False
        plate_keep = 0
        plate_current = 0
        # 予測値ファイル用のdev/pro保存変数
        prediction_id_date = datetime.datetime.now()
        prediction_id = prediction_id_date.strftime("%Y%m%d%H%M%S")
        prediction_id_str = ''
        dev_pro_count = 0
        insert_job_start_flg = False

        for data_dict in data_list:
            # Elasticsearchに同じインデックスで型違いのデータが入るとエラーが発生するため、string型に変換する
            if 'device_' in data_dict:
                data_dict['device_'] = str(data_dict.get('device_'))
            if 'process_' in data_dict:
                data_dict['process_'] = str(data_dict.get('process_'))
            if 'glass_id_' in data_dict:
                data_dict['glass_id_'] = str(data_dict.get('glass_id_'))
            if 'lot_id_' in data_dict:
                data_dict['lot_id_'] = str(data_dict.get('lot_id_'))
            if 'bend_glass_slot_' in data_dict:
                data_dict['bend_glass_slot_'] = str(data_dict.get('bend_glass_slot_'))

            date_time = data_dict.get('date_time_')
            event = data_dict.get('event_')
            device = data_dict.get('device_')
            process = data_dict.get('process_')
            lot_id = data_dict.get('lot_id_')
            plate_current = data_dict.get('plate_')
            # Device/Processのいずれかが空だったらスキップ
            if(device == '' or process == ''):
                # 読み込み行数を増加
                listCnt += 1
                continue
            # 日付と時間に分離
            date, time = date_time.split(' ')

            # RecallログのDevPro情報がある最初のログか？
            if (first_log):
                first_log = False
                plate_keep = plate_current
                before_lot_id = lot_id
                # 日付型に変換
                date_time = datetime.datetime.strptime(
                    date, '%Y/%m/%d')

                # 空でなければデータ継続
                if (lot_id_block == ''):
                    # 日付を整形してlotidblockを作成（疑似LotIDのフォーマットに合わせる）
                    lot_id_block = 'LOTID_' + str(date).replace('/', '-') + \
                                   '_' + str(lot_id_block_cnt)

                # 予測値ファイル紐づけIDが前日から続くかチェック
                before_prediction_id = ''

                if before_prediction_id == '':
                    # 前日から続いていないので新規prediction_idを発行
                    prediction_id_str = prediction_id + \
                                        '_' + str(dev_pro_count)
                    dev_pro_count = dev_pro_count + 1
                else:
                    # 前日から続くので前日のIDを利用する
                    prediction_id_str = before_prediction_id
                    insert_job_start_flg = True

                # beforeの初期化
                before_lot_id = lot_id_block

            # LotEndの次のイベントの時刻を次の開始時刻として設定
            if lotEndCnt == listCnt or update_flg:
                update_flg = False

            # EventはJOB Endで尚且つLotEndの次のイベントか？
            if(event.startswith('JOB End') and lotEndCnt == listCnt):
                data_dict['lot_id_block'] = lotEndId
                update_flg = True
            else:
                # 投入するデータにlotidblockを設定
                data_dict['lot_id_block'] = lot_id_block

            # 予測値ファイル紐づけ用の処理

            # 紐づけ用IDを設定する
            data_dict['prediction_id'] = prediction_id_str

            # job name
            data_dict['job_name'] = device + '/' + process

            # JOB Startイベントか
            if event.startswith('JOB Start'):
                if insert_job_start_flg:
                    # JOB Endがこず、JOB Startが続けて来た場合
                    prediction_id_str = prediction_id + \
                        '_' + str(dev_pro_count)
                    dev_pro_count = dev_pro_count + 1
                    # 古いidを登録してしまっているため、最新idを再設定
                    data_dict['prediction_id'] = prediction_id_str

                # JOB Endせず日を跨いだ場合、JOB Start情報をDBに登録する
                insert_job_start_flg = True

            # JOB Endイベントか
            if event.startswith('JOB End'):
                prediction_id_str = prediction_id + '_' + str(dev_pro_count)
                insert_job_start_flg = False
                dev_pro_count = dev_pro_count + 1

            # 読み込み行数を増加
            listCnt += 1

            self.json_list.append(data_dict)

            # EventはLotEndか？
            if(event.startswith('Lot End')):
                before_lot_id = lot_id_block
                # Lot End時の状態を保存
                lotEndCnt = listCnt
                lotEndId = lot_id_block

                # lotidblockのカウンタを増加
                lot_id_block_cnt += 1
                # 前日のlotidblockのカウンタを使用していた場合、今日のカウンタを0からスタートさせる
                if(cont_day != ''):
                    lot_id_block_cnt = 0
                    cont_day = ''
                # lotidblockを新規作成
                lot_id_block = 'LOTID_' + str(date).replace('/', '-') + \
                    '_' + str(lot_id_block_cnt)
            elif(plate_current != plate_keep or before_lot_id != data_dict['lot_id_block'] or len(data_list) == listCnt - 1):
                # 以下のいずれかの条件でPlateの情報を集計
                # 1.Plateの番号が変わる
                # 2.LotIdBlockが変わる
                # 3.ログの最終行
                #
                # Lotが切り替わっても同じPlate番号のケースがあるため、Lotも確認する。
                # LotIDが空のケースがあるため、LotIdBlockで判断する。
                # 最終行は現在取得出来ているところまでを登録する。
                # 翌日に続く場合は、翌日のデータを読み込んだ際に更新される。

                # Plateが0の場合は、0の時間は次のPlateNoに含める
                if(plate_keep == 0):
                    plate_keep = plate_current
                    continue

                # Adc/Fdcの設定によって登録するdictを切り替える
                if(adc_fdc != -1):
                    if(self.ADC == adc_fdc):
                        # before_data_dict['adc'] = True
                        self.json_list[before_data_cnt]['adc'] = True
                    else:
                        # before_data_dict['adc'] = False
                        self.json_list[before_data_cnt]['adc'] = False

                plate_keep = plate_current
                # 現在のdictを使用する
                startTimePlate = data_dict.get('date_time_')
                adc_fdc = data_dict.get('adc_fdc_')

                # Plateが切り替わったタイミングのLotIdBlockを保存
                before_lot_id = lot_id_block

            # adc/fdcを更新。Plateが変化した直後はadc/fdcの値が-1の場合があるため、plateが切り替わる直前のデータを使用する。
            adc_fdc = data_dict.get('adc_fdc_')
            # 現在のデータを保存
            before_data_dict = data_dict
            before_data_cnt = listCnt - 2

        return self.json_list

    # def load_status_monitor(rid, **filters):
    def load_status_monitor(self, **filters):
        # root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), ADC_MEAS_LOGNAME)
        root_dir = 'D:\\source\\fpdloganalysissystem\\db\\dataimporter\\csv'
        if not os.path.exists(root_dir):
            return None

        files = os.listdir(root_dir)
        dfs = list()
        for file in files:
            path = os.path.join(root_dir, file)
            # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
            df = pd.read_csv(path, index_col=False, dtype=str)
            dfs.append(df)

        df = pd.concat(dfs)

        if 'date_time_' in df.columns:
            df['date_time_'] = pd.to_datetime(df['date_time_'], format="%Y/%m/%d %H:%M:%S:%f")

        for key, val in filters.items():
            if key == 'date_time':
                if 'date_time_' in df.columns:
                    start = filters[key]['start']
                    end = filters[key]['end']
                    try:
                        datetime.datetime.strptime(end, '%Y/%m/%d')
                        end = end + ' 23:59:59'
                    except Exception as e:
                        pass
                    df = df[(start <= df['date_time_']) & (df['date_time_'] <= end)]
            elif key == 'job':
                if 'job_name' in df.columns:
                    job = filters[key]
                    df = df[job == df['job_name']]
            elif key == 'lot_id_block':
                if 'lot_id_block' in df.columns:
                    lot_id_block = filters[key]
                    df = df[lot_id_block == df['lot_id_block']]
            elif key == 'plate':
                if 'plate_' in df.columns:
                    plate = filters[key]
                    df = df[plate == df['plate_']]
            else:
                if key not in df.columns:
                    df[key] = None

                df_copy = df.astype({key: str})

                if isinstance(val, list):
                    if len(val) > 0:
                        val = [str(_) for _ in val]
                        df = df[df_copy[key].isin(val)]
                else:
                    df = df[df_copy[key] == str(val)]

        # for col in COLUMN_OMIT_LIST:
        #     if col in df.columns:
        #         df.drop(col, axis=1, inplace=True)

        if len(df) > 0:
            if 'date_time_' in df.columns:
                # if 'plate' in df.columns and 'step' in df.columns:
                if 'plate' in df.columns:
                    df.sort_values(by=['date_time_', 'plate'], ascending=True, inplace=True)
                else:
                    # 時間順序で整列
                    df.sort_values(by='date_time_', ascending=True, inplace=True)

            # df = df.drop_duplicates(subset=['lot_id', 'glass_id', 'step'], keep='last')

            df.reset_index(inplace=True, drop=True)

            df['event_'] = df['event_'].str.strip()
            df['lot_id_'] = df['lot_id_'].str.strip()

        return df

    def get_end_time(self, df):
        jobend_df = df[df['event_'] == 'JOB End']
        if len(jobend_df):
            return jobend_df['date_time_'].values[0]

        jobend_df = df[df['event_'] == 'Lot End']
        if len(jobend_df):
            return jobend_df['date_time_'].values[0]

        return df['date_time_'].max()


    def get_job_tact_calc(self, args):
        filter = dict()
        filter['date_time'] = {
            # 'start': args['period'].split(sep='~')[0],
            # 'end': args['period'].split(sep='~')[1],
            'start': '2020/11/26',
            'end': '2020/11/26',
        }

        # org_df = self.load_status_monitor(rid=args['rid'], **filter)
        org_df = self.load_status_monitor(**filter)

        job_tact_calc = {}
        for job in org_df['job_name'].unique():
            if job not in job_tact_calc:
                job_tact_calc[job] = {}
            if 'lot' not in job_tact_calc[job]:
                job_tact_calc[job]['lot'] = {}
            if 'lot_id' not in job_tact_calc[job]['lot']:
                job_tact_calc[job]['lot']['lot_id'] = list()
            if 'lot_id_block' not in job_tact_calc[job]['lot']:
                job_tact_calc[job]['lot']['lot_id_block'] = list()
            if 'calc' not in job_tact_calc[job]['lot']:
                job_tact_calc[job]['lot']['calc'] = list()

            job_df = org_df[org_df['job_name'] == job]
            lot_id_block_diff = job_df.groupby('lot_id_block', sort=False)[['date_time_', 'event_']].apply(lambda x: self.get_end_time(x)) - job_df.groupby('lot_id_block', sort=False)[['date_time_']].apply(np.nanmin)

            job_tact_calc[job]['lot']['lot_id_block'] = lot_id_block_diff.index.tolist()
            # job_tact_calc[job]['lot']['calc'] = lot_id_block_diff.values.tolist()
            job_tact_calc[job]['lot']['calc'] = [lot_id_block_diff[index].total_seconds() for index in range(len(lot_id_block_diff.values.tolist()))]
            job_tact_calc[job]['lot']['lot_id'] = job_df.groupby('lot_id_block', sort=False)['lot_id_'].apply(lambda x: x.unique().tolist()[0]).values.tolist()

            if 'plate' not in job_tact_calc[job]:
                job_tact_calc[job]['plate'] = {}

            for lot_id_block in job_df['lot_id_block'].unique():
                if lot_id_block not in job_tact_calc[job]['plate']:
                    job_tact_calc[job]['plate'][lot_id_block] = {}
                if 'lot_id' not in job_tact_calc[job]['plate'][lot_id_block]:
                    job_tact_calc[job]['plate'][lot_id_block]['lot_id'] = list()
                if 'plate_no' not in job_tact_calc[job]['plate'][lot_id_block]:
                    job_tact_calc[job]['plate'][lot_id_block]['plate_no'] = list()
                if 'adc_fdc' not in job_tact_calc[job]['plate'][lot_id_block]:
                    job_tact_calc[job]['plate'][lot_id_block]['adc_fdc'] = list()
                if 'calc' not in job_tact_calc[job]['plate'][lot_id_block]:
                    job_tact_calc[job]['plate'][lot_id_block]['calc'] = list()

                lot_id_block_df = job_df[job_df['lot_id_block'] == lot_id_block]

                job_tact_calc[job]['plate'][lot_id_block]['lot_id'] = lot_id_block_df.groupby('lot_id_block', sort=False)['lot_id_'].apply(lambda x: x.unique().tolist()[0]).values.tolist()
                job_tact_calc[job]['plate'][lot_id_block]['adc_fdc'] = lot_id_block_df['adc'].dropna(how='any', axis=0).tolist()
                plate_diff = lot_id_block_df.groupby('plate_', sort=False)[['date_time_']].apply(np.nanmax) - lot_id_block_df.groupby('plate_', sort=False)[['date_time_']].apply(np.nanmin)
                job_tact_calc[job]['plate'][lot_id_block]['plate_no'] = plate_diff.index.tolist()
                # job_tact_calc[job]['plate'][lot_id_block]['calc'] = plate_diff.values.tolist()
                job_tact_calc[job]['plate'][lot_id_block]['calc'] = [plate_diff[index].total_seconds() for index in range(len(plate_diff.values.tolist()))]

        return job_tact_calc
