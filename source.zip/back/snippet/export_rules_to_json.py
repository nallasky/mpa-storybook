from dao.dao_base import DAOBaseClass
import json
import numpy as np

if __name__ == '__main__':
    dao_base = DAOBaseClass()

    log_define_df = dao_base.fetch_all(table='cnvbase.log_define_master').replace({np.nan: None})
    rule_df = dao_base.fetch_all(table='cnvbase.convert_rule').replace({np.nan: None})
    rule_item_df = dao_base.fetch_all(table='cnvbase.convert_rule_item').replace({np.nan: None})

    log_define_list = list()
    for i in range(len(log_define_df)):
        log_id = log_define_df['id'].values[i]

        matches_rule_df = rule_df[rule_df['log_id'] == log_id]
        convert_rule_list = list()
        for j in range(len(matches_rule_df)):
            rule_id = matches_rule_df['id'].values[j]

            matches_item_df = rule_item_df[rule_item_df['rule_id'] == rule_id]
            matches_item_dict = matches_item_df[['coef', 'col_index', 'data_type', 'def_type', 'def_val',
                                                 'name', 'output_column', 'row_index', 'skip', 'type', 'unit']]\
                .to_dict(orient='records')

            tmp_dict = {'convert_rule_item': matches_item_dict,
                        'rule_name': matches_rule_df['rule_name'].values[j],
                        'commit': bool(matches_rule_df['commit'].values[j])}

            convert_rule_list.append(tmp_dict)

        tmp_log_dict = {'convert_rule': convert_rule_list,
                        'log_define_master': {
                            'input_type': log_define_df['input_type'].values[i],
                            'log_name': log_define_df['log_name'].values[i],
                            'table_name': log_define_df['table_name'].values[i]
                            }
                        }

        log_define_list.append(tmp_log_dict)

    with open('./rules.json', 'w') as f:
        json.dump(log_define_list, f, ensure_ascii=False, indent=4)
