
import sqlite3

conn = sqlite3.connect("..\\db\\analysistool.db", isolation_level=None)
conn.execute("PRAGMA busy_timeout=10000")
conn.execute("PRAGMA foreign_keys = 1")
conn.row_factory = sqlite3.Row
cur = conn.cursor()

def get_cursor():
    return cur


def fetch_one():
    cur = get_cursor()

    query = "select * from 'cnvbase_log_define_master'"
    cur.execute(query)
    row = cur.fetchone()
    print('fetch_one ', row)


def fetch_all():
    cur = get_cursor()

    query = "select * from 'cnvbase_log_define_master'"
    cur.execute(query)
    row = cur.fetchall()
    print('fetch_all ', row)


def get_version():
    cur = get_cursor()

    query = 'select sqlite_version()'
    cur.execute(query)
    row = cur.fetchall()
    data = row[0][0]

    print('get_version ', data)
    return data


def delete_tst():
    cur = get_cursor()

    # query = "delete from 'cnvbase_log_define_master' where id = 11"
    query = "delete from settings_management_setting"
    cur.execute(query)
    conn.commit()
    # id = cur.fetchone()
    # if id is None:
    #     print('delete_tst ', id)
    # else:
    #     print('delete_tst ', id[0])
    print('delete_tst OK')


def insert():
    cur = get_cursor()
    # query = "insert into fab_correction_component_setting(fab_nm,category,setting,item,val) values(?,?,?,?,?)"
    query = "insert into settings_management_setting(target,host,username,password,dbname,port,name,id) values(?,?,?,?,?,?,?,?)"
    cur.execute(query, ('remote', 'localhost', 'postgres', 'postgres', 'cras_db', 5432, 'name1', 1))
    conn.commit()
    print('insert ', cur.lastrowid)


def insert_without_id():
    cur = get_cursor()
    # query = "insert into fab_correction_component_setting(fab_nm,category,setting,item,val) values(?,?,?,?,?)"
    # query = "insert into settings_management_setting(target,host,username,password,dbname,port,name) values(?,?,?,?,?,?,?)"
    # cur.execute(query, ('remote', 'localhost', 'postgres', 'postgres', 'cras_db', 5432, 'name1'))

    query = "insert into cnvbase_log_define_master(log_name, input_type, table_name) values(?,?,?)"
    cur.execute(query, ('test', 'csv', 'test_table'))

    conn.commit()
    print('insert ', cur.lastrowid)


def get_info():
    import pandas as pd
    cur = get_cursor()
    query = f"PRAGMA table_info('cnvbase_log_define_master')"
    cur.execute(query)
    desc = cur.fetchall()
    nested_list = list()
    for fields in desc:
        # fileds[1] is name, fields[2] is type
        list_tmp = [fields[1], fields[2], 255]
        nested_list.append(list_tmp)
    df = pd.DataFrame(nested_list, columns=["column_name", "data_type", "character_maximum_length"])

    print('get_info ', df)


def insert_and_updata_sequence():
    cur = get_cursor()
    _id = 1
    query = "insert into settings_management_setting(target,host,username,password,dbname,port,name,id) values(?,?,?,?,?,?,?,?)"
    cur.execute(query, ('remote', 'localhost', 'postgres', 'postgres', 'cras_db', 5432, 'name1', _id))
    conn.commit()
    print('insert ', cur.lastrowid)


    query = f"update sqlite_sequence set seq={_id} where name='settings_management_setting'"
    cur.execute(query)
    conn.commit()
    # print('insert ', cur.lastrowid)

def foreign_key_tst():
    cur = get_cursor()

    check_job = {
        'id': 'request_20220810_082340996198',
        'file': '31,32,33,34,35',
        'start': '2022-08-10 08:23:41.000197',
        'status': 'idle',
        'job_type': 'local',
        'log_name': 'PLATEAUTOFOCUSCOMPENSATION'
    }

    query = f'insert into cnvset_job (id, file, start, status, job_type, log_name) values (?,?,?,?,?,?)'
    cur.execute(query, (check_job['id'], check_job['file'], check_job['start'],
                                check_job['status'], check_job['job_type'], check_job['log_name']))



if __name__ == "__main__":
    # get_version()
    # delete_tst()
    # fetch_one()
    # fetch_all()
    # insert()
    # insert_without_id()
    # insert_and_updata_sequence()
    # get_info()
    foreign_key_tst()











