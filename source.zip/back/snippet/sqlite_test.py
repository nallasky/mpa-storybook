import os
import sqlite3
from werkzeug.datastructures import FileStorage
from convert.sqlite_datasource import Connect
import time
import pandas as pd
from sqlalchemy import create_engine

from dao.exception import *

from dao import get_db_config


def init_database():
    config = get_db_config()
    db_path = config['dbpath']
    dir = os.path.dirname(os.path.abspath(db_path))

    try:
        if not os.path.exists(dir):
            os.mkdir(dir)
        conn = sqlite3.connect(config['dbpath'])
        conn.close()
    except Exception as e:
        raise DatabaseConnectError()


def insert_test():
    table_dict = {
        "plate_tact": "tact_plate_tact",
        "plate_event": "tact_plate_tact_event",
        "plate_detail": "tact_plate_detail_tact",
        "name_data": "tact_name_dat",
        "primary_pu_item": "tact_primary_pu_item",
        "primary_pu": "tact_primary_pu",
        "ref_pu": "tact_ref_pu"
    }
    config = get_db_config()
    engine = create_engine(f"sqlite:///{config['dbpath']}")

    file_name = 'name_data.dat'
    table = file_name.split(sep='.')[0]
    with open(os.path.join('migrations/resource/v2_0_0/data/tact_settings', file_name), 'rb') as f:
        file = FileStorage(f)

        with Connect(config) as conn:
            pu_list = list()
            name_list = list()
            temp_list = read_file_data(table, file)
            for data in temp_list:
                if len(data) == 0:
                    continue
                pu_list.append(data.strip().replace('"', "").split(maxsplit=1)[0])
                name_list.append(data.strip().replace('"', "").split(maxsplit=1)[1])
            tup_list = list(zip(pu_list, name_list))
            df = pd.DataFrame(zip(pu_list, name_list), columns=['puid', 'name'])

            # print('executemany start.')
            # start = time.time()
            # conn.cur.executemany(f'insert into {table_dict[table]}(puid, name) values (?, ?)', tup_list)
            # conn.conn.commit()
            # print(f'executemany takes {time.time() - start} sec')
            #
            # print('to_sql start.')
            # start = time.time()
            # df.to_sql(table_dict[table], conn.conn, if_exists='append', index=False)
            # print(f'to_sql takes {time.time() - start} sec')

            print('to_sql sqlalchemy start.')
            start = time.time()
            df.to_sql(table_dict[table], engine, if_exists='append', index=False)
            print(f'to_sql sqlalchemy takes {time.time() - start} sec')


def read_file_data(tab, file):
    encoding_list = ['shift_jis', 'cp932', 'UTF8']
    result_df = pd.DataFrame()
    result_list = list()
    if tab == 'name_data':
        for encode in encoding_list:
            try:
                result_list = str(file.stream.read(), encode).splitlines()
                break
            except:
                file.seek(0)
                continue
        return result_list
    else:
        for encode in encoding_list:
            try:
                result_df = pd.read_csv(file, index_col=False, encoding=encode)
                break
            except:
                file.seek(0)
                continue

        return result_df



def insert_executemany(self, table, files, primary_pu_name=None):
    """
    :param table:
    :param files: [files]
    :return: {'log_name': [fids]}
    """

    clumns_dict = {
        "plate_tact": ["category", "display_order"],
        "plate_event": ["event_kind"],
        "plate_detail": ["event", "event_start", "event_end", "category", "display"],
        "name_data": ["puid", "name"],
        "primary_pu": ["pu_name"],
        "primary_pu_item": ["puid", "name", "level", "primary_pu_id"],
        "ref_pu": ["puid", "primary_pu_name"]
    }


if __name__ == '__main__':
    insert_test()