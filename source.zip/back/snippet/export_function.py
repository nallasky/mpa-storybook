from dao import get_db_config
from dao.dao_function import DAOFunction
import json

def export_function():
    dao_func = DAOFunction()
    ret_list = list()

    resp_form = dao_func.connection_check()
    if not resp_form.res:
        return ret_list

    func_df = dao_func.fetch_all(args={'where': 'system_func=true'})
    for i in range(len(func_df)):
        ret_dict = dict()
        func_id = func_df['id'].values[i]

        resp_form = dao_func.get_category_info(func_id)
        if not resp_form.res:
            print(f'get_category_info() : {resp_form.msg}')
            continue

        ret_dict['category'] = resp_form.data

        resp_form = dao_func.get_function_info(func_id)
        if not resp_form.res:
            print(f'get_function_info() : {resp_form.msg}')
            continue

        analysis_type = resp_form.data.pop('analysis_type')
        ret_dict['func'] = resp_form.data

        source_type = resp_form.data['source_type']
        if source_type == 'multi':
            print(f'Not support exporting multi function.')
            continue

        resp_form = dao_func.get_source_info(func_id)
        if not resp_form.res:
            print(f'get_source_info() : {resp_form.msg}')
            continue

        ret_dict['func']['info'] = resp_form.data

        resp_form = dao_func.get_script(table='analysis.preprocess_script', func_id=func_id)
        if not resp_form.res:
            preprocess_script = {'file_name': None, 'use_script': False}
        else:
            preprocess_script = resp_form.data

        ret_dict['func']['script'] = preprocess_script

        ret_dict['convert'] = dict()
        if ret_dict['func']['source_type'] == 'local':
            resp_form = dao_func.get_script(table='analysis.convert_script', func_id=func_id)
            if not resp_form.res:
                convert_script = {'file_name': None, 'use_script': False}
            else:
                convert_script = resp_form.data

            ret_dict['convert']['script'] = convert_script

        analysis_items = list()
        resp_form = dao_func.get_analysis_items_info(func_id)
        if resp_form.res:
            analysis_items = resp_form.data

        ret_dict['analysis'] = dict()
        ret_dict['analysis']['type'] = analysis_type
        ret_dict['analysis']['setting'] = dict()
        ret_dict['analysis']['setting']['items'] = analysis_items

        # 2022.P3 Deleted Filter Setting
        # resp_form = dao_func.get_filter_default_info(func_id)
        # if not resp_form.res:
        #     filter_default = []
        # else:
        #     filter_default = resp_form.data

        filter_default = list()
        ret_dict['analysis']['setting']['filter_default'] = filter_default

        resp_form = dao_func.get_aggregation_default_info(func_id)
        if not resp_form.res:
            aggregation_default = dict()
        else:
            aggregation_default = resp_form.data

        ret_dict['analysis']['setting']['aggregation_default'] = aggregation_default

        resp_form = dao_func.get_script(table='analysis.analysis_script', func_id=func_id)
        if not resp_form.res:
            analysis_script = {'db_id': None, 'sql': None, 'file_name': None, 'use_script': False}
        else:
            analysis_script = resp_form.data

        ret_dict['analysis']['script'] = analysis_script

        resp_form = dao_func.get_function_graph_type(func_id)
        if not resp_form.res:
            continue

        ret_dict['visualization'] = dict()
        ret_dict['visualization']['function_graph_type'] = resp_form.data

        resp_form = dao_func.get_visualization_default_info(func_id)
        if not resp_form.res:
            items = []
        else:
            items = resp_form.data

        ret_dict['visualization']['items'] = items

        ret_list.append(ret_dict)

    return ret_list

if __name__ == '__main__':
    func_list = export_function()

    with open('../migrations/resource/v2_1_0/data/functions.json', 'w', encoding='utf-8') as f:
        json.dump(func_list, f, indent=4, sort_keys=True, ensure_ascii=False)
