import json
import datetime
from snippet.tact_prediction_file_converter import TactPredictionFileConveter
from snippet.convert_tact_prediction import load_logfile
from snippet.tact_statusmonitor_converter import StatusMonitorConveter
from snippet.load_statusmonitor import load_status_monitor
from snippet.tact_plate_tact_calc import TactPlateTactCalc
import csv
import pandas as pd

def _json_dump(filename, data):
    root_path = 'D:\\source\\fpdloganalysissystem\\db\\dataimporter\\newcreate_diff\\'
    path = root_path + filename + '.json'

    with open(path, mode="w") as file:
        json.dump(data, file)

def _write_csv(filename, data):
    root_path = 'D:\\source\\fpdloganalysissystem\\db\\dataimporter\\newcreate_diff\\'
    date_time = datetime.datetime.now()
    date = date_time.strftime("%Y%m%d")
    path = root_path + filename + '_' + date + '.csv'

    df = pd.DataFrame(data)
    df.to_csv(path, index=False)

if __name__ == '__main__':
    # _json_format()
    # POST api/tact/statusmonitor/convert
    print('[load_status_monitor] start time : ', datetime.datetime.now())
    data_list = load_status_monitor()
    print('[load_status_monitor] end time : ', datetime.datetime.now())

    # Conveter呼び出し
    print('[status_monitor_conveter] start time : ', datetime.datetime.now())
    statusMonitorConveter = StatusMonitorConveter()
    result_json_list = statusMonitorConveter.status_monitor_conveter(data_list)
    print('[status_monitor_conveter] end time : ', datetime.datetime.now())
    # _json_dump('result_json_list', result_json_list)
    # _write_csv('result_json_list', result_json_list)

    # POST api/tact/statusmonitor/analysis/job-tact
    print('[get_statusmonitor_data] start time : ', datetime.datetime.now())
    result = statusMonitorConveter.get_job_tact_calc(0)
    print('[get_statusmonitor_data] end time : ', datetime.datetime.now())



    # POST api/tact/statusmonitor/analysis/plate-tact
    # # 予測値ファイルを読み込む
    print('[tact_prediction_file_conveter] start time : ', datetime.datetime.now())
    path = 'D:\\source\\fpdloganalysissystem\\db\\dataimporter\\tact_prediction_log\\' + '20210708003914_tactprediction_E033'
    tactPredictionFileConveter = TactPredictionFileConveter(path)
    # Converter呼び出し
    result_tact_json_list = tactPredictionFileConveter.tact_prediction_file_conveter(result_json_list)
    print('[tact_prediction_file_conveter] end time : ', datetime.datetime.now())

    # _json_dump('result_tact_json_list', result_tact_json_list)

    filter = dict()
    filter['date_time'] = {
        # 'start': args['period'].split(sep='~')[0],
        # 'end': args['period'].split(sep='~')[1],
        'start': '2020/11/26',
        'end': '2020/11/26',
    }
    filter['job'] = '315A07A1/1LAA1EE'

    # 予測値ファイルを読み込む
    # tact_prediction = tactPredictionFileConveter.load_tact_prediction_file('315A07A1_1LAA1EE')

    #StatusMonitorの場合は計算結果を書き込む
    # print('[tact_plate_tact_calc] start time : ', datetime.datetime.now())
    tactPlateTactCalc = TactPlateTactCalc()

    # org_df = self.load_status_monitor(rid=args['rid'], **filter)
    org_df = statusMonitorConveter.load_status_monitor(**filter)
    print('[create_throughput_list] start time : ', datetime.datetime.now())
    # all_throughput_df, adc_throughput_df, fdc_throughput_df = tactPlateTactCalc.create_throughput_list(org_df)
    print('[create_throughput_list] end time : ', datetime.datetime.now())

    # _write_csv('all_throughput_df', all_throughput_df)

    print('[extract_working_and_waiting] start time : ', datetime.datetime.now())
    # all_working_df, all_waiting_df = tactPlateTactCalc.extract_working_and_waiting(all_throughput_df)
    print('[extract_working_and_waiting] end time : ', datetime.datetime.now())

    print('[calculate_plate_tact] start time : ', datetime.datetime.now())
    # result_plate_tact = tactPlateTactCalc.calculate_plate_tact(result_tact_json_list, all_throughput_df, 'throughput', 2)   # adc=0 / fdc=1 / all =2
    print('[calculate_plate_tact] end time : ', datetime.datetime.now())

    filter = dict()
    filter['date_time'] = {
        # 'start': args['period'].split(sep='~')[0],
        # 'end': args['period'].split(sep='~')[1],
        'start': '2020/11/26',
        'end': '2020/11/26',
    }
    filter['job'] = '315A07A1/1LAA1EE'
    filter['plate'] = '1'
    filter['lot_id_block'] = 'LOTID_2020-11-26_1'
    print('[calculate_plate_detail_tact] start time : ', datetime.datetime.now())
    org_df = statusMonitorConveter.load_status_monitor(**filter)
    result_plate_detail_tact = tactPlateTactCalc.calculate_plate_detail_tact(org_df, result_tact_json_list)
    print('[calculate_plate_detail_tact] end time : ', datetime.datetime.now())
    print(result_plate_detail_tact)


    # write_data_list, write_setting_list = tactPlateTactCalc.tact_plate_tact_calc(result_json_list, result_tact_json_list)
    # print('[tact_plate_tact_calc] end time : ', datetime.datetime.now())
    #
    # _json_dump('write_data_list', write_data_list)
    # _json_dump('write_setting_list', write_setting_list)
