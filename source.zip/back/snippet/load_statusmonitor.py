import os
import pandas as pd

# col_list = ['type','log_time','event','plate','recipe','device','process','adc_fdc','adc_mode','glass_id','bend_glass_slot_mask','mask_slot','bend_glass_slot_mask','keep_lot_fdc_status','apc','lot_id']

def load_status_monitor():
    root_dir = 'D:\\source\\fpdloganalysissystem\\db\\dataimporter\\status_monitor_csv'
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    for file in files:
        path = os.path.join(root_dir, file)
        df = pd.read_csv(path, index_col=False, dtype=str)
        dfs.append(df)

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    data_list = list()
    for i in range(len(df)):
        data_dict = dict()

        # 'type', 'log_time', 'event', 'plate', 'recipe', 'device', 'process', 'adc_fdc', 'adc_mode',
        # 'glass_id', 'bend_glass_slot_mask', 'mask_slot', 'bend_glass_slot_mask', 'keep_lot_fdc_status',
        # 'apc', 'lot_id'
        data_dict['type_'] = int(df['type'].values[i])
        data_dict['date_time_'] = str(df['log_time'].values[i])
        data_dict['event_'] = str(df['event'].values[i])
        data_dict['plate_'] = int(df['plate'].values[i])
        data_dict['recipe_'] = int(df['recipe'].values[i])
        data_dict['device_'] = str(df['device'].values[i])
        data_dict['process_'] = str(df['process'].values[i])
        data_dict['adc_fdc_'] = int(df['adc_fdc'].values[i])
        data_dict['adc_mode_'] = int(df['adc_mode'].values[i])
        data_dict['glass_id_'] = str(df['glass_id'].values[i])
        data_dict['bend_glass_slot_'] = str(df['bend_glass_slot'].values[i])
        data_dict['mask_slot_'] = str(df['mask_slot'].values[i])
        data_dict['bend_glass_slot_mask_'] = str(df['bend_glass_slot_mask'].values[i])
        data_dict['keep_lot_fdc_status_'] = int(df['keep_lot_fdc_status'].values[i])
        data_dict['apc_'] = str(df['apc'].values[i])
        data_dict['lot_id_'] = str(df['lot_id'].values[i])

        # for col in col_list:
        #     if 'log_time' == col:
        #         data_col = 'date_time_'
        #         data_dict[data_col] = df[col].values[i]
        #     else:
        #         data_col = col + '_'
        #         data_dict[data_col] = df[col].values[i]
        data_list.append(data_dict)

    return data_list
