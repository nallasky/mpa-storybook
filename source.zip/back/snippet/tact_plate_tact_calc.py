# coding:utf-8
import logging
import json
import datetime
import re
import csv
import copy
import os
import os.path
from datetime import datetime
import pandas as pd

'''
---------------------------------------------
Plate TACT Calc

Update History:
    [2021/01/12] 新規作成

Copyright(C) Canon Inc. All right reserved.
---------------------------------------------
'''


class TactPlateTactCalc():

    # JSON化する項目
    event_id_name = 'PlateTactCalc'
    event_id_name_setting = 'PlateTactCalcSetting'
    event_id = 'event_id'
    # event_time = 'event_time'
    # equipment_name = 'equipment_name_'
    date_time = 'date_time_'
    device = 'device_'
    process = 'process_'
    plate = 'plate_'
    lot_id = 'lot_id_'
    lot_id_block = 'lot_id_block'
    settings = 'settings'
    throughput_all = 'throughput_all'
    throughput_adc = 'throughput_adc'
    throughput_fdc = 'throughput_fdc'
    working_all = 'working_all'
    working_adc = 'working_adc'
    working_fdc = 'working_fdc'
    waiting_all = 'waiting_all'
    waiting_adc = 'waiting_adc'
    waiting_fdc = 'waiting_fdc'
    predict_throughput_all = 'predict_throughput_all'
    predict_throughput_adc = 'predict_throughput_adc'
    predict_throughput_fdc = 'predict_throughput_fdc'
    predict_working_all = 'predict_working_all'
    predict_working_adc = 'predict_working_adc'
    predict_working_fdc = 'predict_working_fdc'
    predict_waiting_all = 'predict_waiting_all'
    predict_waiting_adc = 'predict_waiting_adc'
    predict_waiting_fdc = 'predict_waiting_fdc'
    throughput = 'throughput_'
    working = 'working_'
    waiting = 'waiting_'

    # StatusMonitorから取得する項目
    adc_fdc = 'adc_fdc_'
    event = 'event_'

    # list
    sm_data_list_str = []
    sm_data_all_list_dict = []
    lot_id_block_list = []
    lot_id_block_included_plate_cnt_list = []
    tool_included_plate_list = []
    tool_included_sm_data_all_throughput_list = []
    tool_included_sm_data_adc_throughput_list = []
    tool_included_sm_data_fdc_throughput_list = []
    tool_included_sm_data_all_working_list = []
    tool_included_sm_data_adc_working_list = []
    tool_included_sm_data_fdc_working_list = []
    tool_included_sm_data_all_waiting_list = []
    tool_included_sm_data_adc_waiting_list = []
    tool_included_sm_data_fdc_waiting_list = []

    # 設定情報
    plate_tact_setting_path = ""
    plate_detail_tact_setting_path = ""
    plate_tact_setting_list = []
    plate_detail_tact_setting_list = []
    setting_event = 'event'
    setting_event_start = 'event_start'
    setting_event_end = 'event_end'
    setting_category = 'category'
    setting_display = 'display'
    setting_display_order = 'display_order'
    setting_total_time = 'total_time'
    setting_category_other = 'Other'
    setting_predict_total_time = 'predict_total_time'

    # 計算結果
    calc_result_all_throughput_list = []
    calc_result_adc_throughput_list = []
    calc_result_fdc_throughput_list = []
    calc_result_all_working_list = []
    calc_result_adc_working_list = []
    calc_result_fdc_working_list = []
    calc_result_all_waiting_list = []
    calc_result_adc_waiting_list = []
    calc_result_fdc_waiting_list = []
    calc_result_predict_all_throughput_list = []
    calc_result_predict_adc_throughput_list = []
    calc_result_predict_fdc_throughput_list = []
    calc_result_predict_all_working_list = []
    calc_result_predict_adc_working_list = []
    calc_result_predict_fdc_working_list = []
    calc_result_predict_all_waiting_list = []
    calc_result_predict_adc_waiting_list = []
    calc_result_predict_fdc_waiting_list = []
    result_plate_tact = {}
    resutl_plate_detail_tact = []
    # 予測値
    predict_dict_all = {}
    predict_dict = {}
    adc = 0
    fdc = 1
    all = 2
    event_name = 'event_name_'
    event_tact = 'event_tact_'
    prediction_id = 'prediction_id'
    fdc_detail_tact = 'fdc_detail_tact_'
    fdc_plate_tact = 'fdc_plate_tact_'
    adc_detail_tact = 'adc_detail_tact_'
    adc_plate_tact = 'adc_plate_tact_'
    plate_load_event = 'Plate Load'
    plate_unload_event = 'Plate Unload'
    isPlateLoad = False
    isPlateUnLoad = False

    count = 1

    def __init__(self):
        """コンストラクタ
        """
        self.log = logging.getLogger(__name__)

    def _tact_json_dump(self, filename, data):
        root_path = 'D:\\source\\fpdloganalysissystem\\db\\dataimporter\\newcreate_diff\\'
        path = root_path + filename + '.json'

        with open(path, mode="w") as file:
            json.dump(data, file)

    def _tact_write_csv(self, filename, data):
        root_path = 'D:\\source\\fpdloganalysissystem\\db\\dataimporter\\newcreate_diff\\'
        path = root_path + filename + '.csv'

        df = pd.DataFrame(data)
        df.to_csv(path, index=False)


    # @logger(__name__, "TactPlateTactCalc")
    def tact_plate_tact_calc(self, sm_data_list, predict_dict):
        """PlateTACT計算処理
        param sm_json_list StatusMonitorのRecallログ
        """
        # self.plate_tact_setting_path = CONFIG["FILEPATH"]["PLATE_TACT_SETTING_PATH"]
        # self.plate_detail_tact_setting_path = CONFIG["FILEPATH"]["PLATE_DETAIL_TACT_SETTING_PATH"]
        self.plate_tact_setting_path = os.path.join(os.getcwd(), 'config') + os.sep + 'plate_tact.csv'
        self.plate_detail_tact_setting_path = os.path.join(os.getcwd(), 'config') + os.sep + 'plate_detail_tact.csv'
        self.sm_data_list_str = sm_data_list
        self.predict_dict_all = predict_dict

        # 設定情報を生成する
        print(' +[設定情報を生成する] start time : ', datetime.now())
        self.create_plate_tact_setting()
        self.create_plate_detail_tact_setting()
        print(' +[設定情報を生成する] end time : ', datetime.now())
        # lot_id_blockのリストを作成
        print(' +[lot_id_blockのリストを作成] start time : ', datetime.now())
        self.create_lot_id_block_list()
        print(' +[lot_id_blockのリストを作成] end time : ', datetime.now())
        # データ作成
        print(' +[データ作成] start time : ', datetime.now())
        self.create_calc_data()
        print(' +[データ作成] end time : ', datetime.now())
        # type_settingに応じたデータの抽出を行う
        print(' +[type_settingに応じたデータの抽出を行う] start time : ', datetime.now())
        self.tool_included_sm_data_all_working_list, self.tool_included_sm_data_all_waiting_list = self.extract_type_setting(
            self.tool_included_sm_data_all_throughput_list)
        self.tool_included_sm_data_adc_working_list, self.tool_included_sm_data_adc_waiting_list = self.extract_type_setting(
            self.tool_included_sm_data_adc_throughput_list)
        self.tool_included_sm_data_fdc_working_list, self.tool_included_sm_data_fdc_waiting_list = self.extract_type_setting(
            self.tool_included_sm_data_fdc_throughput_list)
        print(' +[type_settingに応じたデータの抽出を行う] end time : ', datetime.now())
        # 計算実行
        print(' +[計算実行] start time : ', datetime.now())
        # self._tact_write_csv('tool_included_sm_data_all_throughput_list', self.tool_included_sm_data_all_throughput_list)
        # self._tact_write_csv('tool_included_sm_data_all_working_list', self.tool_included_sm_data_all_working_list)
        # self._tact_write_csv('tool_included_sm_data_all_waiting_list', self.tool_included_sm_data_all_waiting_list)
        # self._tact_write_csv('tool_included_sm_data_adc_throughput_list', self.tool_included_sm_data_adc_throughput_list)
        # self._tact_write_csv('tool_included_sm_data_adc_working_list', self.tool_included_sm_data_adc_working_list)
        # self._tact_write_csv('tool_included_sm_data_adc_waiting_list', self.tool_included_sm_data_adc_waiting_list)
        # self._tact_write_csv('tool_included_sm_data_fdc_throughput_list', self.tool_included_sm_data_fdc_throughput_list)
        # self._tact_write_csv('tool_included_sm_data_fdc_working_list', self.tool_included_sm_data_fdc_working_list)
        # self._tact_write_csv('tool_included_sm_data_fdc_waiting_list', self.tool_included_sm_data_fdc_waiting_list)
        # # self._tact_json_dump('tool_included_sm_data_all_throughput_list', self.tool_included_sm_data_all_throughput_list)
        # self._tact_json_dump('tool_included_sm_data_all_working_list', self.tool_included_sm_data_all_working_list)
        # self._tact_json_dump('tool_included_sm_data_all_waiting_list', self.tool_included_sm_data_all_waiting_list)
        # self._tact_json_dump('tool_included_sm_data_adc_throughput_list', self.tool_included_sm_data_adc_throughput_list)
        # self._tact_json_dump('tool_included_sm_data_adc_working_list', self.tool_included_sm_data_adc_working_list)
        # self._tact_json_dump('tool_included_sm_data_adc_waiting_list', self.tool_included_sm_data_adc_waiting_list)
        # self._tact_json_dump('tool_included_sm_data_fdc_throughput_list', self.tool_included_sm_data_fdc_throughput_list)
        # self._tact_json_dump('tool_included_sm_data_fdc_working_list', self.tool_included_sm_data_fdc_working_list)
        # self._tact_json_dump('tool_included_sm_data_fdc_waiting_list', self.tool_included_sm_data_fdc_waiting_list)

        self.calc_result_all_throughput_list, self.calc_result_predict_all_throughput_list = self.execute_calc(
            self.tool_included_sm_data_all_throughput_list, self.throughput, self.all)
        self.calc_result_all_working_list, self.calc_result_predict_all_working_list = self.execute_calc(
            self.tool_included_sm_data_all_working_list, self.working, self.all)
        self.calc_result_all_waiting_list, self.calc_result_predict_all_waiting_list = self.execute_calc(
            self.tool_included_sm_data_all_waiting_list, self.waiting, self.all)
        self.calc_result_adc_throughput_list, self.calc_result_predict_adc_throughput_list = self.execute_calc(
            self.tool_included_sm_data_adc_throughput_list, self.throughput, self.adc)
        self.calc_result_adc_working_list, self.calc_result_predict_adc_working_list = self.execute_calc(
            self.tool_included_sm_data_adc_working_list, self.working, self.adc)
        self.calc_result_adc_waiting_list, self.calc_result_predict_adc_waiting_list = self.execute_calc(
            self.tool_included_sm_data_adc_waiting_list, self.waiting, self.adc)
        self.calc_result_fdc_throughput_list, self.calc_result_predict_fdc_throughput_list = self.execute_calc(
            self.tool_included_sm_data_fdc_throughput_list, self.throughput, self.fdc)
        self.calc_result_fdc_working_list, self.calc_result_predict_fdc_working_list = self.execute_calc(
            self.tool_included_sm_data_fdc_working_list, self.working, self.fdc)
        self.calc_result_fdc_waiting_list, self.calc_result_predict_fdc_waiting_list = self.execute_calc(
            self.tool_included_sm_data_fdc_waiting_list, self.waiting, self.fdc)
        print(' +[計算実行] end time : ', datetime.now())
        # ファイルに書き出し
        print(' +[ファイルに書き出し] start time : ', datetime.now())
        return self.write_data()
        # print(' +[ファイルに書き出し] end time : ', datetime.now())

    def write_data(self):
        write_data_dict = {}
        write_data_list = []
        write_setting_dict = {}
        write_setting_list = []

        # job_tool_included_plate_list = []
        # for tool_included_plate_dict in self.tool_included_plate_list:
        #     if tool_included_plate_dict['device_'] == '315A07A1' and tool_included_plate_dict['process_'] == '1LAA1EE':
        #         job_tool_included_plate_list.append(tool_included_plate_dict)
        # print('   =[len(job_tool_included_plate_list)] : ', len(job_tool_included_plate_list))
        # # [test]for one job only

        # ファイル書き出し用のデータを生成する
        for index, tool_included_plate_dict in enumerate(
                # job_tool_included_plate_list):
                self.tool_included_plate_list):
            write_data_dict[self.event_id] = self.event_id_name
            # write_data_dict[self.event_time] = tool_included_plate_dict.get(
            #     self.event_time)
            # write_data_dict[self.equipment_name] = tool_included_plate_dict.get(
            #     self.equipment_name)
            write_data_dict[self.device] = str(tool_included_plate_dict.get(
                self.device))
            write_data_dict[self.process] = str(tool_included_plate_dict.get(
                self.process))
            write_data_dict[self.plate] = tool_included_plate_dict.get(
                self.plate)
            write_data_dict[self.lot_id] = str(tool_included_plate_dict.get(
                self.lot_id))
            write_data_dict[self.lot_id_block] = tool_included_plate_dict.get(
                self.lot_id_block)
            write_data_dict[self.adc_fdc] = tool_included_plate_dict.get(
                self.adc_fdc)
            write_data_dict[self.throughput_all] = ", ".join(
                repr(e) for e in self.calc_result_all_throughput_list[index])
            write_data_dict[self.working_all] = ", ".join(
                repr(e) for e in self.calc_result_all_working_list[index])
            write_data_dict[self.waiting_all] = ", ".join(
                repr(e) for e in self.calc_result_all_waiting_list[index])
            write_data_dict[self.throughput_adc] = ", ".join(
                repr(e) for e in self.calc_result_adc_throughput_list[index])
            write_data_dict[self.working_adc] = ", ".join(
                repr(e) for e in self.calc_result_adc_working_list[index])
            write_data_dict[self.waiting_adc] = ", ".join(
                repr(e) for e in self.calc_result_adc_waiting_list[index])
            write_data_dict[self.throughput_fdc] = ", ".join(
                repr(e) for e in self.calc_result_fdc_throughput_list[index])
            write_data_dict[self.working_fdc] = ", ".join(
                repr(e) for e in self.calc_result_fdc_working_list[index])
            write_data_dict[self.waiting_fdc] = ", ".join(
                repr(e) for e in self.calc_result_fdc_waiting_list[index])
            write_data_dict[self.predict_throughput_all] = ", ".join(
                repr(e) for e in self.calc_result_predict_all_throughput_list[index])
            write_data_dict[self.predict_working_all] = ", ".join(
                repr(e) for e in self.calc_result_predict_all_working_list[index])
            write_data_dict[self.predict_waiting_all] = ", ".join(
                repr(e) for e in self.calc_result_predict_all_waiting_list[index])
            write_data_dict[self.predict_throughput_adc] = ", ".join(
                repr(e) for e in self.calc_result_predict_adc_throughput_list[index])
            write_data_dict[self.predict_working_adc] = ", ".join(
                repr(e) for e in self.calc_result_predict_adc_working_list[index])
            write_data_dict[self.predict_waiting_adc] = ", ".join(
                repr(e) for e in self.calc_result_predict_adc_waiting_list[index])
            write_data_dict[self.predict_throughput_fdc] = ", ".join(
                repr(e) for e in self.calc_result_predict_fdc_throughput_list[index])
            write_data_dict[self.predict_working_fdc] = ", ".join(
                repr(e) for e in self.calc_result_predict_fdc_working_list[index])
            write_data_dict[self.predict_waiting_fdc] = ", ".join(
                repr(e) for e in self.calc_result_predict_fdc_waiting_list[index])
            write_data_list.append(write_data_dict.copy())

        # settingは最初の値を使用して生成する
        settings = 'Totaltime'
        for plate_tact_setting_dict in self.plate_tact_setting_list:
            settings += ',' + \
                plate_tact_setting_dict.get(self.setting_category)
        if len(self.tool_included_plate_list) != 0:
            write_setting_dict[self.event_id] = self.event_id_name_setting
            # write_setting_dict[self.event_time] = self.tool_included_plate_list[0].get(
            #     self.event_time)
            write_setting_dict[self.settings] = settings
            write_setting_list.append(write_setting_dict.copy())
        elif len(self.sm_data_all_list_dict) != 0:
            write_setting_dict[self.event_id] = self.event_id_name_setting
            # write_setting_dict[self.event_time] = self.sm_data_all_list_dict[0].get(
            #     self.event_time)
            write_setting_dict[self.settings] = settings
            write_setting_list.append(write_setting_dict.copy())

        return write_data_list, write_setting_list

    def create_calc_data(self):
        plate_dict = {}

        # lot_id_block数分繰り返し
        for index, lot_id_block_dict in enumerate(self.lot_id_block_list):
            lot_id_block_included_plate_list = []

            # 現在のlot_id_blockを取得する
            lot_id_block_now = lot_id_block_dict.get(self.lot_id_block)

            # StatusMonitorのレコード数分繰り返し
            added_plate_list = []
            for data_dict in self.sm_data_all_list_dict:

                # lot_id_blockを取得する
                lot_id_block = data_dict.get(self.lot_id_block)

                # 現在のlot_id_blockと一致した場合
                if lot_id_block_now == lot_id_block:

                    # plateを取得する
                    plate = data_dict.get(self.plate)

                    # 追加済みのplateでない且つPlateIDが0でない
                    if plate not in added_plate_list and plate != 0:
                        plate_dict[self.lot_id] = data_dict.get(self.lot_id)
                        plate_dict[self.lot_id_block] = data_dict.get(
                            self.lot_id_block,)
                        plate_dict[self.plate] = data_dict.get(self.plate)
                        plate_dict[self.adc_fdc] = -1
                        # plate_dict[self.event_time] = data_dict.get(
                        #     self.event_time)
                        # plate_dict[self.equipment_name] = data_dict.get(
                        #     self.equipment_name)
                        plate_dict[self.device] = data_dict.get(self.device)
                        plate_dict[self.process] = data_dict.get(self.process)
                        plate_dict[self.prediction_id] = data_dict.get(
                            self.prediction_id)

                        self.tool_included_plate_list.append(plate_dict.copy())
                        lot_id_block_included_plate_list.append(
                            plate_dict.copy())
                        added_plate_list.append(plate)

            # lot_id_blockに含まれるplate数の一覧を作成する
            self.lot_id_block_included_plate_cnt_list.append(
                len(lot_id_block_included_plate_list))

            # lot_id_blockに含まれるplate数分処理を繰り返す
            for i, plate_dict in enumerate(
                    lot_id_block_included_plate_list):

                # 対象のplateのStatusMonitorのレコードを取得する
                plate_included_sm_data_list = []
                for sm_data_dict in self.sm_data_all_list_dict:
                    if sm_data_dict.get(self.lot_id_block) == plate_dict.get(self.lot_id_block) and sm_data_dict.get(self.plate) == plate_dict.get(self.plate):
                        plate_included_sm_data_list.append(sm_data_dict)

                # 対象のplateが属するADC/FDCの値を取得する
                plate_adc_fdc = -1
                for plate_included_sm_data_dict in plate_included_sm_data_list:
                    # 末尾のスペースを除去した文字列と比較する
                    replace_str = re.sub(
                        r'\s+$',
                        '',
                        plate_included_sm_data_dict.get(self.event))
                    if replace_str == 'Step Start':
                        plate_adc_fdc = plate_included_sm_data_dict.get(
                            self.adc_fdc)
                        # 対象のplateのADC/FDCを書き換える
                        for tool_included_plate in self.tool_included_plate_list:
                            if tool_included_plate[self.lot_id_block] == plate_included_sm_data_dict.get(self.lot_id_block) and tool_included_plate[self.plate] == plate_included_sm_data_dict.get(self.plate):
                                tool_included_plate[self.adc_fdc] = plate_adc_fdc
                                break
                        break

                # lot_id_blockに含まれるStatusMonitorのレコード数分繰り返す
                sm_data_plate_dict = {}
                for plate_included_sm_data_dict in plate_included_sm_data_list:
                    # sm_data_plate_dict[self.equipment_name] = plate_included_sm_data_dict.get(
                    #     self.equipment_name)
                    sm_data_plate_dict[self.lot_id] = plate_included_sm_data_dict.get(
                        self.lot_id)
                    sm_data_plate_dict[self.lot_id_block] = plate_included_sm_data_dict.get(
                        self.lot_id_block)
                    sm_data_plate_dict[self.plate] = plate_included_sm_data_dict.get(
                        self.plate)
                    sm_data_plate_dict[self.event] = plate_included_sm_data_dict.get(
                        self.event)
                    sm_data_plate_dict[self.date_time] = plate_included_sm_data_dict.get(
                        self.date_time)

                    # allは無条件で追加
                    self.tool_included_sm_data_all_throughput_list.append(
                        sm_data_plate_dict.copy())
                    # adcの場合
                    if plate_adc_fdc == 0:
                        self.tool_included_sm_data_adc_throughput_list.append(
                            sm_data_plate_dict.copy())
                    # fdcの場合
                    elif plate_adc_fdc == 1:
                        self.tool_included_sm_data_fdc_throughput_list.append(
                            sm_data_plate_dict.copy())

        # lot_id_blockに含まれるplateがない場合
        if len(self.lot_id_block_included_plate_cnt_list) == 0:
            self.lot_id_block_included_plate_cnt_list.append(0)

        return

    def extract_type_setting(self, target_sm_data_list):
        tmp_sm_data_list = []
        sm_data_waiting_list = []
        sm_data_working_list = []
        loading_flg = 0

        # StatusMonitorのデータ数分繰り返し
        for data_dict in target_sm_data_list:
            event_name = re.sub(r'\s+$', '', data_dict.get(self.event))

            if event_name == self.plate_load_event and loading_flg == 0:
                # working期間開始イベント
                loading_flg = 1
                sm_data_waiting_list.extend(tmp_sm_data_list)
                tmp_sm_data_list.clear()
                tmp_sm_data_list.append(data_dict)
            elif event_name != self.plate_unload_event and loading_flg == 1:
                # working期間中イベント
                tmp_sm_data_list.append(data_dict)
            elif event_name == self.plate_unload_event and loading_flg == 1:
                # working期間終了イベント
                loading_flg = 0
                tmp_sm_data_list.append(data_dict)
                sm_data_working_list.extend(tmp_sm_data_list)
                tmp_sm_data_list.clear()
                tmp_sm_data_list.append(data_dict)
            elif event_name == self.plate_unload_event and loading_flg == 0:
                # working期間中イベント
                sm_data_working_list.extend(tmp_sm_data_list)
                tmp_sm_data_list.clear()
                tmp_sm_data_list.append(data_dict)
            else:
                tmp_sm_data_list.append(data_dict)

        # PlateLoadが出たが、以降にPlateUnloadが出てこなかった場合はworking期間イベント扱い
        if len(tmp_sm_data_list) != 0 and loading_flg == 1:
            sm_data_working_list.extend(tmp_sm_data_list)

        # PlateUnloadが出たが、以降にPlateLoadが出てこなかった場合はwaiting期間イベント扱い
        # (PlateLoad、PlateUnload共に一度も出ない場合もここに入る)
        if len(tmp_sm_data_list) != 0 and loading_flg == 0:
            sm_data_waiting_list.extend(tmp_sm_data_list)

        return sm_data_working_list, sm_data_waiting_list

    def getPredictData(self, plate_adc_fdc, kind, adc_fdc,
                       device, process, prediction_id):
        predict_detail_dict = []
        predict_plate_time = 0

        # 対象のデバイスプロセスの予測値を取得する
        self.predict_dict = {}
        for predict in self.predict_dict_all:
            if predict[self.device] == device and predict[self.process] == process and predict[self.prediction_id] == prediction_id:
                self.predict_dict = predict
                break
        # 対象の予測値がなければ空を返す
        if not self.predict_dict:
            return predict_detail_dict, predict_plate_time
        # 対象のADC/FDCの予測値を取得する
        if(self.fdc == plate_adc_fdc):
            predict_detail_dict = self.predict_dict[self.fdc_detail_tact]
            predict_plate_time = self.predict_dict[self.fdc_plate_tact][kind]
        else:
            predict_detail_dict = self.predict_dict[self.adc_detail_tact]
            predict_plate_time = self.predict_dict[self.adc_plate_tact][kind]
        if self.all != adc_fdc and plate_adc_fdc != adc_fdc:
            predict_plate_time = 0
        return predict_detail_dict, predict_plate_time

    def getPlateList(self, tool_included_plate_dict, target_sm_data_list):
        plate_sm_data_list = []
        for target_sm_data_dict in target_sm_data_list:
            # plateとlot_id_blockが一致したデータを対象とする
            if tool_included_plate_dict.get(self.plate) == target_sm_data_dict.get(
                    self.plate) and tool_included_plate_dict.get(self.lot_id_block) == target_sm_data_dict.get(self.lot_id_block):
                plate_sm_data_list.append(target_sm_data_dict)
        return plate_sm_data_list

    def setPlateLoad(self, base_event_name):
        if base_event_name == self.plate_load_event:
            self.isPlateLoad = True
        if base_event_name == self.plate_unload_event:
            self.isPlateUnLoad = True

    def execute_calc(self, target_sm_data_list, kind, adc_fdc):
        finding_end_event = ''
        start_time = 0
        category = ''
        end_time = 0
        setting_total_time = 0
        setting_predict_total_time = 0
        calc_result_plate_list = []
        calc_result_list = []
        calc_result_predict_plate_list = []
        calc_result_predict_list = []
        event_name = ''
        predict_detail_dict = []
        predict_index = 0
        predict_time = 0
        predict_plate_time = 0

        # print('  **== ', self.count ,' ==**')
        # self.count = self.count + 1
        # # plate数分処理を繰り返す
        # print('  +[plate数分処理を繰り返す] start time : ', datetime.now())
        # # [test]for one job only
        # job_tool_included_plate_list = []
        # for tool_included_plate_dict in self.tool_included_plate_list:
        #     if tool_included_plate_dict['device_'] == '315A07A1' and tool_included_plate_dict['process_'] == '1LAA1EE':
        #         job_tool_included_plate_list.append(tool_included_plate_dict)
        # print('   =[len(job_tool_included_plate_list)] : ', len(job_tool_included_plate_list))
        # # [test]for one job only
        # for tool_included_plate_dict in job_tool_included_plate_list:
        for tool_included_plate_dict in self.tool_included_plate_list:
            plate_sm_data_list = []
            self.isPlateLoad = False
            self.isPlateUnLoad = False
            predict_index = 0

            # 対象のStatusMonitorのデータを取得する
            plate_sm_data_list = self.getPlateList(
                tool_included_plate_dict,
                target_sm_data_list)
            # plateのADC/FDCを取得する
            plate_adc_fdc = tool_included_plate_dict.get(self.adc_fdc)
            # 対象の予測値データを取得する
            predict_detail_dict, predict_plate_time = self.getPredictData(
                plate_adc_fdc, kind, adc_fdc, tool_included_plate_dict[self.device],
                tool_included_plate_dict[self.process], tool_included_plate_dict[self.prediction_id])

            # 対象のplateに含まれるデータ数分繰り返す
            # print('  +[対象のplateに含まれるデータ数分繰り返す] start time : ', datetime.now())
            for index, plate_sm_data_dict in enumerate(plate_sm_data_list):
                base_date_time = plate_sm_data_dict.get(self.date_time)
                base_event_name = re.sub(
                    r'\s+$',
                    '',
                    plate_sm_data_dict.get(
                        self.event))

                # PlateLoadの状況を更新する
                self.setPlateLoad(base_event_name)

                # 比較するイベントと一致するStartとEndを取得する
                if finding_end_event == '':
                    for plate_detail_tact_setting_dict in self.plate_detail_tact_setting_list:
                        event_start_name = plate_detail_tact_setting_dict.get(
                            self.setting_event_start)
                        event_name = plate_detail_tact_setting_dict.get(
                            self.setting_event)
                        if base_event_name == event_start_name:
                            start_time = base_date_time
                            category = plate_detail_tact_setting_dict.get(
                                self.setting_category)
                            finding_end_event = plate_detail_tact_setting_dict.get(
                                self.setting_event_end)
                            break
                # Startに対応するEndと一致するイベントを検索する（比較元以降のイベントを対象とする）
                # print('  +[Startに対応するEndと一致するイベントを検索する] start time : ', datetime.now())
                for i in range(index + 1, len(plate_sm_data_list)):
                    now_date_time = plate_sm_data_list[i].get(self.date_time)
                    now_event_name = re.sub(
                        r'\s+$',
                        '',
                        plate_sm_data_list[i].get(
                            self.event))
                    # 一致した場合
                    event_name_flg = False
                    if finding_end_event != '' and finding_end_event == now_event_name:
                        # event時間を取得する
                        end_time = now_date_time
                        start = datetime.strptime(
                            start_time, "%Y/%m/%d %H:%M:%S:%f")
                        end = datetime.strptime(
                            end_time, "%Y/%m/%d %H:%M:%S:%f")
                        diff_time = end - start
                        diff_time_milli = diff_time.total_seconds() * 1000

                        # PlateLoadが始まってから予測値を取得する
                        predict_time = 0
                        if self.isPlateLoad:
                            if predict_index < len(predict_detail_dict):
                                # 実測値と予測値でイベントが一致した場合
                                if event_name == predict_detail_dict[predict_index][self.event_name]:
                                    predict_time = predict_detail_dict[predict_index][self.event_tact]
                                    if diff_time_milli <= 15:
                                        # 実測値が15ms以下の場合は対象外
                                        predict_time = 0
                                    else:
                                        predict_index += 1
                                # 実測値と予測値でイベントが一致しない場合
                                else:
                                    # 現在より前のイベントで一致するものを探す
                                    for j in range(0, predict_index)[::-1]:
                                        if event_name == predict_detail_dict[j][self.event_name]:
                                            predict_time = predict_detail_dict[j][self.event_tact]
                                            event_name_flg = True
                                            break
                                    if event_name_flg is False:
                                        # 現在より後のイベントで一致するものを探す
                                        for k in range(
                                                predict_index + 1, len(predict_detail_dict)):
                                            if event_name == predict_detail_dict[k][self.event_name]:
                                                predict_time = predict_detail_dict[k][self.event_tact]
                                                predict_index = k
                                                break

                        # 大分類を取得する
                        category_list = [d.get(self.setting_category)
                                         for d in self.plate_tact_setting_list]
                        # 一致する大分類があった場合
                        if category in category_list:
                            setting_total_time = self.plate_tact_setting_list[category_list.index(
                                category)][self.setting_total_time]
                            self.plate_tact_setting_list[category_list.index(
                                category)][self.setting_total_time] = setting_total_time + diff_time_milli
                            setting_predict_total_time = self.plate_tact_setting_list[category_list.index(
                                category)][self.setting_predict_total_time]
                            self.plate_tact_setting_list[category_list.index(
                                category)][self.setting_predict_total_time] = setting_predict_total_time + predict_time
                        # 一致する大分類がない場合、OtherがあればOtherに含める
                        elif self.setting_category_other in category_list:
                            setting_total_time = self.plate_tact_setting_list[category_list.index(
                                self.setting_category_other)][self.setting_total_time]
                            self.plate_tact_setting_list[category_list.index(
                                self.setting_category_other)][self.setting_total_time] = setting_total_time + diff_time_milli
                            setting_predict_total_time = self.plate_tact_setting_list[category_list.index(
                                self.setting_category_other)][self.setting_predict_total_time]
                            self.plate_tact_setting_list[category_list.index(
                                self.setting_category_other)][self.setting_predict_total_time] = setting_predict_total_time + predict_time
                        start_time = 0
                        finding_end_event = ''
                        diff_time_milli = 0
                        break
                # print('  +[Startに対応するEndと一致するイベントを検索する] end time : ', datetime.now())
                finding_end_event = ''

            # 登録するデータを作成する
            # print('  +[登録するデータを作成する] start time : ', datetime.now())
            calc_result_list, calc_result_predict_list = self.create_output_data(
                plate_sm_data_list, predict_plate_time, kind)
            calc_result_plate_list.append(copy.deepcopy(calc_result_list))
            calc_result_predict_plate_list.append(
                copy.deepcopy(calc_result_predict_list))
            # print('  +[登録するデータを作成する] end time : ', datetime.now())
            # print('  +[対象のplateに含まれるデータ数分繰り返す] start time : ', datetime.now())

        # print('  +[plate数分処理を繰り返す] end time : ', datetime.now())

        return calc_result_plate_list, calc_result_predict_plate_list

    def create_output_data(self, plate_sm_data_list, predict_plate_time, kind):
        calc_result_list = []
        calc_result_predict_list = []
        result_predict_plate_time = 0

        if kind == self.waiting:
            # waitingの場合はPlateUnLoadがない場合は予測値を表示しない
            if not self.isPlateLoad and self.isPlateUnLoad:
                result_predict_plate_time = predict_plate_time
        else:
            # waiting以外の場合はPlateLoadまたはPlateUnLoadがない場合は予測値を表示しない
            if self.isPlateLoad and self.isPlateUnLoad:
                result_predict_plate_time = predict_plate_time

        # Plateの合計時間を取得する
        plate_time_milli = 0
        if len(plate_sm_data_list) > 1:
            plate_start_time = datetime.strptime(
                plate_sm_data_list[0].get(self.date_time), "%Y/%m/%d %H:%M:%S:%f")
            plate_end_time = datetime.strptime(
                plate_sm_data_list[len(plate_sm_data_list) - 1].get(self.date_time), "%Y/%m/%d %H:%M:%S:%f")
            plate_time = plate_end_time - plate_start_time
            plate_time_milli = plate_time.total_seconds() * 1000
        # イベントの合計時間を取得する
        event_total_time = 0
        predict_total_time = 0
        for plate_tact_setting_dict in self.plate_tact_setting_list:
            event_total_time = event_total_time + plate_tact_setting_dict.get(
                self.setting_total_time)
            predict_total_time = predict_total_time + plate_tact_setting_dict.get(
                self.setting_predict_total_time)
        # Plateの合計時間よりイベントの合計時間が短い場合は差分をOtherに含める
        if event_total_time < plate_time_milli:
            # 大分類を取得する
            category_list = [d.get(self.setting_category)
                             for d in self.plate_tact_setting_list]
            if self.setting_category_other in category_list:
                setting_total_time = self.plate_tact_setting_list[category_list.index(
                    self.setting_category_other)][self.setting_total_time]
                self.plate_tact_setting_list[category_list.index(
                    self.setting_category_other)][self.setting_total_time] = setting_total_time + (plate_time_milli - event_total_time)
                event_total_time = event_total_time + \
                    (plate_time_milli - event_total_time)
        if predict_total_time < result_predict_plate_time:
            # 大分類を取得する
            category_list = [d.get(self.setting_category)
                             for d in self.plate_tact_setting_list]
            if self.setting_category_other in category_list:
                setting_predict_total_time = self.plate_tact_setting_list[category_list.index(
                    self.setting_category_other)][self.setting_predict_total_time]
                self.plate_tact_setting_list[category_list.index(
                    self.setting_category_other)][self.setting_predict_total_time] = \
                    setting_predict_total_time + \
                    (result_predict_plate_time - predict_total_time)
                predict_total_time = predict_total_time + \
                    (result_predict_plate_time - predict_total_time)
        # グラフに表示する時間はイベントの時間を実際のPlate処理時間を基に按分する
        calc_result_list.clear()
        calc_result_predict_list.clear()
        plate_total_time = 0
        predict_plate_total_time = 0
        for plate_tact_setting_dict in self.plate_tact_setting_list:
            # 実測値の集計
            time = 0
            if event_total_time != 0:
                time = round(plate_tact_setting_dict.get(
                    self.setting_total_time) / event_total_time * plate_time_milli / 1000, 2)
                calc_result_list.append(time)
            else:
                calc_result_list.append(time)
            plate_total_time += time
            plate_tact_setting_dict[self.setting_total_time] = 0
            # 予測値の集計
            time = 0
            if predict_total_time != 0:
                time = round(plate_tact_setting_dict.get(
                    self.setting_predict_total_time) / predict_total_time * result_predict_plate_time / 1000, 2)
                calc_result_predict_list.append(time)
            else:
                calc_result_predict_list.append(time)
            predict_plate_total_time += time
            plate_tact_setting_dict[self.setting_predict_total_time] = 0

        calc_result_list.insert(0, round(plate_total_time, 2))
        calc_result_predict_list.insert(
            0, round(predict_plate_total_time, 2))

        return calc_result_list, calc_result_predict_list

    def create_lot_id_block_list(self):
        self.log.info("create_lot_id_block_list called.")
        lot_id_block_dict = {}

        # StatusMonitorのレコード数分繰り返し
        for data_str in self.sm_data_list_str:
            # data_dict = json.loads(data_str)
            data_dict = data_str
            self.sm_data_all_list_dict.append(data_dict.copy())
            lot_id_block = data_dict.get(self.lot_id_block)

            # lot_id_blockの一覧を取得する
            lot_id_block_list = [d.get(self.lot_id_block)
                                 for d in self.lot_id_block_list]
            # plateを取得する
            plate = data_dict.get(self.plate)

            # 追加済みのlot_id_blockでない且つPlateIDが0でない
            if lot_id_block not in lot_id_block_list and plate != 0:
                lot_id_block_dict[self.lot_id_block] = lot_id_block
                lot_id_block_dict[self.lot_id] = data_dict.get(self.lot_id)
                self.lot_id_block_list.append(lot_id_block_dict.copy())

        return

    def create_plate_tact_setting(self):
        self.log.info("create_plate_tact_setting called.")
        setting_list = []
        with open(self.plate_tact_setting_path, mode="r") as file:
            reader = csv.reader(file, delimiter=",")
            # 1行目のヘッダーは読み飛ばす
            next(reader)
            for row in reader:
                plate_tact_setting_dict = {
                    self.setting_category: row[0],
                    self.setting_display_order: row[1],
                    self.setting_total_time: 0,
                    self.setting_predict_total_time: 0,
                }
                setting_list.append(
                    plate_tact_setting_dict.copy())
        self.plate_tact_setting_list = sorted(
            setting_list, key=lambda x: x[self.setting_display_order])
        return

    def create_plate_detail_tact_setting(self):
        self.log.info("create_plate_detail_tact_setting called.")
        with open(self.plate_detail_tact_setting_path, mode="r") as file:
            reader = csv.reader(file, delimiter=",")
            # 1行目のヘッダーは読み飛ばす
            next(reader)
            for row in reader:
                plate_detail_tact_setting_dict = {
                    self.setting_event: row[0],
                    self.setting_event_start: row[1],
                    self.setting_event_end: row[2],
                    self.setting_category: row[3],
                    self.setting_display: row[4],
                }
                if plate_detail_tact_setting_dict[self.setting_display].lower(
                ) == 'true':
                    self.plate_detail_tact_setting_list.append(
                        plate_detail_tact_setting_dict.copy())
        return


    def create_throughput_list(self, df):
        # 追加済みのplateでない且つPlateIDが0でない
        all_throughput_df = df.drop(df[df['plate_'] == '0'].index)
        all_throughput_df.reset_index(inplace=True, drop=True)
        adc_throughput_list = list()
        fdc_throughput_list = list()
        lot_id_block_list = all_throughput_df['lot_id_block'].unique().tolist()
        # for lot_id_block in lot_id_block_list:
        for _, lot_id_block in enumerate(lot_id_block_list):
            plate_list = all_throughput_df[all_throughput_df['lot_id_block'] == lot_id_block]['plate_'].unique().tolist()
            for _, plate in enumerate(plate_list):
            # for plate in plate_list:
                plate_df = all_throughput_df[(all_throughput_df['lot_id_block'] == lot_id_block) & (all_throughput_df['plate_'] == plate)]
                plate_adc_fdc = -1
                # 対象のplateが属するADC/FDCの値を取得する
                if 'Step Start' in plate_df['event_'].values:
                    plate_adc_fdc = int(plate_df[plate_df['event_'] == 'Step Start']['adc_fdc_'].values[0])

                # adcの場合
                if plate_adc_fdc == 0:
                    adc_throughput_list.extend(plate_df.index.values.tolist())
                    # adc_throughput_df = adc_throughput_df.append(plate_df)
                # fdcの場合
                elif plate_adc_fdc == 1:
                    fdc_throughput_list.extend(plate_df.index.values.tolist())
                    # fdc_throughput_df = fdc_throughput_df.append(plate_df)

        adc_throughput_df = df.loc[adc_throughput_list, :]
        adc_throughput_df.reset_index(inplace=True, drop=True)
        fdc_throughput_df = df.loc[fdc_throughput_list, :]
        fdc_throughput_df.reset_index(inplace=True, drop=True)

        return all_throughput_df, adc_throughput_df, fdc_throughput_df

    def extract_working_and_waiting(self, df):
        working_list = list()
        waiting_list = list()
        tmp_list = list()
        loading_flg = 0

        # StatusMonitorのデータ数分繰り返し
        event_list = df['event_'].to_list()
        for idx, event in enumerate(event_list):
            if event == 'Plate Load' and loading_flg == 0:
                # working期間開始イベント
                loading_flg = 1
                waiting_list.extend(tmp_list)
                tmp_list.clear()
                tmp_list.append(idx)
            elif event != 'Plate Unload' and loading_flg == 1:
                # working期間中イベント
                tmp_list.append(idx)
            elif event == 'Plate Unload' and loading_flg == 1:
                # working期間終了イベント
                loading_flg = 0
                tmp_list.append(idx)
                working_list.extend(tmp_list)
                tmp_list.clear()
                tmp_list.append(idx)
            elif event == 'Plate Unload' and loading_flg == 0:
                # working期間中イベント
                waiting_list.extend(tmp_list)
                tmp_list.clear()
                tmp_list.append(idx)
            else:
                tmp_list.append(idx)

        # PlateLoadが出たが、以降にPlateUnloadが出てこなかった場合はworking期間イベント扱い
        if len(tmp_list) != 0 and loading_flg == 1:
            working_list.extend(tmp_list)

        # PlateUnloadが出たが、以降にPlateLoadが出てこなかった場合はwaiting期間イベント扱い
        # (PlateLoad、PlateUnload共に一度も出ない場合もここに入る)
        if len(tmp_list) != 0 and loading_flg == 0:
            waiting_list.extend(tmp_list)

        working_df = df.loc[working_list, :]
        working_df.reset_index(inplace=True, drop=True)
        waiting_df = df.loc[waiting_list, :]
        waiting_df.reset_index(inplace=True, drop=True)

        return working_df, waiting_df

    def get_plate_detail_tact_setting(self):
        path = 'D:\\source\\fpdloganalysissystem\\db\\dataimporter\\mdasimporter\\config\\plate_detail_tact.csv'
        df = pd.DataFrame()
        with open(path, mode="r") as file:
            df = pd.read_csv(path, index_col=False, dtype=str)
        return df

    def get_plate_tact_setting(self):
        path = 'D:\\source\\fpdloganalysissystem\\db\\dataimporter\\mdasimporter\\config\\plate_tact.csv'
        df = pd.DataFrame()
        with open(path, mode="r") as file:
            df = pd.read_csv(path, index_col=False, dtype=str)
        return df

    def calculate_plate_tact(self, predict, df, kind, adc_fdc):
        plate_tact_calc = {}
        category_calc = {}
        category_predict_calc = {}
        predict_time = 0
        predict_index = 0
        event_name = ''
        plate_adc_fdc = 0

        plate_detail_tact_setting = self.get_plate_detail_tact_setting()
        plate_tact_setting = self.get_plate_tact_setting()
        # lot_id_block_list = df['lot_id_block'].unique()
        lot_id_block_list = df['lot_id_block'].unique().tolist()
        # plate数分処理を繰り返す
        for _, lot_id_block in enumerate(lot_id_block_list):
            plate_list = df[df['lot_id_block'] == lot_id_block]['plate_'].unique().tolist()
            for _, plate in enumerate(plate_list):
                # category_calc.clear()

                self.isPlateLoad = False
                self.isPlateUnLoad = False
                predict_index = 0

                list = plate_tact_setting['category'].to_list()
                for idx, category in enumerate(list):
                    category_calc[category] = 0
                    category_predict_calc[category] = 0

                # 対象のStatusMonitorのデータを取得する
                plate_df = df[(df['lot_id_block'] == lot_id_block) & (df['plate_'] == plate)]

                # plateのADC/FDCを取得する
                plate_adc_fdc = -1
                if 'Step Start' in plate_df['event_'].values:
                    plate_adc_fdc = int(plate_df[plate_df['event_'] == 'Step Start']['adc_fdc_'].values[0])

                # 対象の予測値データを取得する
                device = plate_df['device_'].unique()[0]
                process = plate_df['process_'].unique()[0]
                predict_detail_dict, predict_plate_time = self.get_tact_predict(plate_adc_fdc, kind, adc_fdc, predict, device, process)

                # 対象のplateに含まれるデータ数分繰り返す
                # event_list = plate_df['event_'].tolist()
                for idx, item in plate_df.iterrows():
                    start_item = item
                    base_event_name = start_item.loc['event_']

                    # PlateLoadの状況を更新する
                    self.setPlateLoad(base_event_name)

                    # 比較するイベントと一致するStartとEndを取得する
                    select_detail_tact_setting = plate_detail_tact_setting[plate_detail_tact_setting['event_start'] == base_event_name]
                    if len(select_detail_tact_setting.index) != 0:
                        event_name = select_detail_tact_setting['event'].values[0]
                        # Startに対応するEndと一致するイベントを検索する（比較元以降のイベントを対象とする）
                        end_event_name = select_detail_tact_setting['event_end'].values[0]
                        end_item = plate_df[(plate_df['event_'] == end_event_name) & (plate_df.index > idx)].head(1)
                        # start = plate_df[plate_df.index == idx]
                        # start = plate_df.loc[idx]

                        # 一致した場合
                        event_name_flg = False
                        if len(end_item) != 0:
                            diff_time = end_item['date_time_'] - start_item['date_time_']
                            diff_time_milli = diff_time.item().total_seconds() * 1000

                            # PlateLoadが始まってから予測値を取得する
                            predict_time = 0
                            if self.isPlateLoad:
                                if predict_index < len(predict_detail_dict):
                                    # 実測値と予測値でイベントが一致した場合
                                    if event_name == predict_detail_dict[predict_index][self.event_name]:
                                        predict_time = predict_detail_dict[predict_index][self.event_tact]
                                        if diff_time_milli <= 15:
                                            # 実測値が15ms以下の場合は対象外
                                            predict_time = 0
                                        else:
                                            predict_index += 1
                                    # 実測値と予測値でイベントが一致しない場合
                                    else:
                                        # 現在より前のイベントで一致するものを探す
                                        for j in range(0, predict_index)[::-1]:
                                            if event_name == predict_detail_dict[j][self.event_name]:
                                                predict_time = predict_detail_dict[j][self.event_tact]
                                                event_name_flg = True
                                                break
                                        if event_name_flg is False:
                                            # 現在より後のイベントで一致するものを探す
                                            for k in range(
                                                    predict_index + 1, len(predict_detail_dict)):
                                                if event_name == predict_detail_dict[k][self.event_name]:
                                                    predict_time = predict_detail_dict[k][self.event_tact]
                                                    predict_index = k
                                                    break

                            category = select_detail_tact_setting['category'].values[0]
                            select_tact_setting = plate_tact_setting[plate_tact_setting['category'] == category]
                            if len(select_tact_setting.index) != 0:
                                if category in category_calc:
                                    category_calc[category] = category_calc[category] + diff_time_milli
                                    category_predict_calc[category] = category_predict_calc[category] + predict_time
                            else:
                                if category in category_calc:
                                    category_calc['Other']['total_time'] = category_calc['Other']['total_time'] + diff_time_milli
                                    category_predict_calc['Other'] = category_predict_calc['Other'] + predict_time
                        # else:
                        #     print('skip.......event:', base_event_name)
                # print('[plate:',plate,']', ' category_calc : ', category_calc)
                # print('[plate:',plate,']', ' category_predict_calc : ', category_predict_calc)

                calc_result_list, calc_result_predict_list = self.make_out_data(kind, predict_plate_time, plate_df, category_calc, category_predict_calc)
                # # create_output_data
                # calc_result_list = {}
                # calc_result_predict_list = {}
                # result_predict_plate_time = 0
                # if kind == self.waiting:
                #     # waitingの場合はPlateUnLoadがない場合は予測値を表示しない
                #     if not self.isPlateLoad and self.isPlateUnLoad:
                #         result_predict_plate_time = predict_plate_time
                # else:
                #     # waiting以外の場合はPlateLoadまたはPlateUnLoadがない場合は予測値を表示しない
                #     if self.isPlateLoad and self.isPlateUnLoad:
                #         result_predict_plate_time = predict_plate_time
                #
                # # Plateの合計時間を取得する
                # plate_time_milli = 0
                # if len(plate_df) > 0:
                #     date_time = plate_df['date_time_'].to_numpy()
                #     plate_time = date_time.max() - date_time.min()
                #     plate_time_milli = float(plate_time) / 1000000
                #
                # # イベントの合計時間を取得する
                # event_total_time = 0
                # predict_total_time = 0
                # for key, value in category_calc.items():
                #     event_total_time = event_total_time + value
                # for key, value in category_predict_calc.items():
                #     predict_total_time = predict_total_time + value
                #
                # # Plateの合計時間よりイベントの合計時間が短い場合は差分をOtherに含める
                # if event_total_time < plate_time_milli:
                #     category_calc['Other'] = category_calc['Other'] + (plate_time_milli - event_total_time)
                #     event_total_time = event_total_time + (plate_time_milli - event_total_time)
                #
                # if predict_total_time < result_predict_plate_time:
                #     category_predict_calc['Other'] = category_predict_calc['Other'] + (result_predict_plate_time - predict_total_time)
                #     predict_total_time = predict_total_time + (result_predict_plate_time - predict_total_time)
                #
                # # グラフに表示する時間はイベントの時間を実際のPlate処理時間を基に按分する
                # plate_total_time = 0
                # for key, value in category_calc.items():
                #     # 実測値の集計
                #     time = 0
                #     if event_total_time != 0:
                #         time = round(value / event_total_time * plate_time_milli / 1000, 2)
                #         # calc_result_list.append(time)
                #         calc_result_list[key] = time
                #     else:
                #         # calc_result_list.append(time)
                #         calc_result_list[key] = time
                #     plate_total_time += time
                # # calc_result_list.insert(0, round(plate_total_time, 2))
                # calc_result_list['sum'] = round(plate_total_time, 2)
                # # print(calc_result_list)
                #
                # predict_plate_total_time = 0
                # for key, value in category_predict_calc.items():
                #     # 予測値の集計
                #     time = 0
                #     if predict_total_time != 0:
                #         time = round(value / predict_total_time * result_predict_plate_time / 1000, 2)
                #         # calc_result_predict_list.append(time)
                #         calc_result_predict_list[key] = time
                #     else:
                #         # calc_result_predict_list.append(time)
                #         calc_result_predict_list[key] = time
                #     predict_plate_total_time += time
                # # calc_result_predict_list.insert(0, round(predict_plate_total_time, 2))
                # calc_result_predict_list['sum'] = round(predict_plate_total_time, 2)
                # # print(calc_result_predict_list)

                self.make_result_plate_tact(lot_id_block, plate, plate_adc_fdc, kind, calc_result_list, calc_result_predict_list)
                # if 'lot_id_block' not in result_plate_tact:
                #     result_plate_tact['lot_id_block'] = {}
                # if lot_id_block not in result_plate_tact['lot_id_block']:
                #     result_plate_tact['lot_id_block'][lot_id_block] = {}
                # if 'plate' not in result_plate_tact['lot_id_block'][lot_id_block]:
                #     result_plate_tact['lot_id_block'][lot_id_block]['plate'] = []
                #     result_plate_tact['lot_id_block'][lot_id_block]['plate'].append(int(plate))
                # else:
                #     result_plate_tact['lot_id_block'][lot_id_block]['plate'].append(int(plate))
                # if 'adc_fdc' not in result_plate_tact['lot_id_block'][lot_id_block]:
                #     result_plate_tact['lot_id_block'][lot_id_block]['adc_fdc'] = []
                #     result_plate_tact['lot_id_block'][lot_id_block]['adc_fdc'].append(plate_adc_fdc)
                # else:
                #     result_plate_tact['lot_id_block'][lot_id_block]['adc_fdc'].append(plate_adc_fdc)
                # if 'plate_tact' not in result_plate_tact['lot_id_block'][lot_id_block]:
                #     result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'] = {}
                # if kind not in result_plate_tact['lot_id_block'][lot_id_block]['plate_tact']:
                #     result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind] = {}
                #     for key, value in calc_result_list.items():
                #         if key not in result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind]:
                #             result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key] = []
                #             result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)
                #         else:
                #             result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)
                # else:
                #     for key, value in calc_result_list.items():
                #         if key not in result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind]:
                #             result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key] = []
                #             result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)
                #         else:
                #             result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)
                #
                # if 'predict' not in result_plate_tact['lot_id_block'][lot_id_block]:
                #     result_plate_tact['lot_id_block'][lot_id_block]['predict'] = {}
                # if kind not in result_plate_tact['lot_id_block'][lot_id_block]['predict']:
                #     result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind] = {}
                #     for key, value in calc_result_predict_list.items():
                #         if key not in result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind]:
                #             result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key] = []
                #             result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].append(value)
                #         else:
                #             result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].append(value)
                # else:
                #     for key, value in calc_result_predict_list.items():
                #         if key not in result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind]:
                #             result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key] = []
                #             result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].apppend(value)
                #         else:
                #             result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].append(value)

        return self.result_plate_tact

    def make_out_data(self, kind, predict_plate_time, plate_df, category_calc, category_predict_calc):
        # category_calc = {}
        # category_predict_calc = {}

        # create_output_data
        calc_result_list = {}
        calc_result_predict_list = {}
        result_predict_plate_time = 0
        if kind == self.waiting:
            # waitingの場合はPlateUnLoadがない場合は予測値を表示しない
            if not self.isPlateLoad and self.isPlateUnLoad:
                result_predict_plate_time = predict_plate_time
        else:
            # waiting以外の場合はPlateLoadまたはPlateUnLoadがない場合は予測値を表示しない
            if self.isPlateLoad and self.isPlateUnLoad:
                result_predict_plate_time = predict_plate_time

        # Plateの合計時間を取得する
        plate_time_milli = 0
        if len(plate_df) > 0:
            date_time = plate_df['date_time_'].to_numpy()
            plate_time = date_time.max() - date_time.min()
            plate_time_milli = float(plate_time) / 1000000

        # イベントの合計時間を取得する
        event_total_time = 0
        predict_total_time = 0
        for key, value in category_calc.items():
            event_total_time = event_total_time + value
        for key, value in category_predict_calc.items():
            predict_total_time = predict_total_time + value

        # Plateの合計時間よりイベントの合計時間が短い場合は差分をOtherに含める
        if event_total_time < plate_time_milli:
            category_calc['Other'] = category_calc['Other'] + (plate_time_milli - event_total_time)
            event_total_time = event_total_time + (plate_time_milli - event_total_time)

        if predict_total_time < result_predict_plate_time:
            category_predict_calc['Other'] = category_predict_calc['Other'] + (
                        result_predict_plate_time - predict_total_time)
            predict_total_time = predict_total_time + (result_predict_plate_time - predict_total_time)

        # グラフに表示する時間はイベントの時間を実際のPlate処理時間を基に按分する
        plate_total_time = 0
        for key, value in category_calc.items():
            # 実測値の集計
            time = 0
            if event_total_time != 0:
                time = round(value / event_total_time * plate_time_milli / 1000, 2)
                # calc_result_list.append(time)
                calc_result_list[key] = time
            else:
                # calc_result_list.append(time)
                calc_result_list[key] = time
            plate_total_time += time
        # calc_result_list.insert(0, round(plate_total_time, 2))
        calc_result_list['sum'] = round(plate_total_time, 2)
        # print(calc_result_list)

        predict_plate_total_time = 0
        for key, value in category_predict_calc.items():
            # 予測値の集計
            time = 0
            if predict_total_time != 0:
                time = round(value / predict_total_time * result_predict_plate_time / 1000, 2)
                # calc_result_predict_list.append(time)
                calc_result_predict_list[key] = time
            else:
                # calc_result_predict_list.append(time)
                calc_result_predict_list[key] = time
            predict_plate_total_time += time
        # calc_result_predict_list.insert(0, round(predict_plate_total_time, 2))
        calc_result_predict_list['sum'] = round(predict_plate_total_time, 2)
        # print(calc_result_predict_list)
        return calc_result_list, calc_result_predict_list

    def make_result_plate_tact(self, lot_id_block, plate, plate_adc_fdc, kind, calc_result_list, calc_result_predict_list):

        if 'lot_id_block' not in self.result_plate_tact:
            self.result_plate_tact['lot_id_block'] = {}
        if lot_id_block not in self.result_plate_tact['lot_id_block']:
            self.result_plate_tact['lot_id_block'][lot_id_block] = {}
        if 'plate' not in self.result_plate_tact['lot_id_block'][lot_id_block]:
            self.result_plate_tact['lot_id_block'][lot_id_block]['plate'] = []
            self.result_plate_tact['lot_id_block'][lot_id_block]['plate'].append(int(plate))
        else:
            self.result_plate_tact['lot_id_block'][lot_id_block]['plate'].append(int(plate))
        if 'adc_fdc' not in self.result_plate_tact['lot_id_block'][lot_id_block]:
            self.result_plate_tact['lot_id_block'][lot_id_block]['adc_fdc'] = []
            self.result_plate_tact['lot_id_block'][lot_id_block]['adc_fdc'].append(plate_adc_fdc)
        else:
            self.result_plate_tact['lot_id_block'][lot_id_block]['adc_fdc'].append(plate_adc_fdc)
        if 'plate_tact' not in self.result_plate_tact['lot_id_block'][lot_id_block]:
            self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'] = {}
        if kind not in self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact']:
            self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind] = {}
            for key, value in calc_result_list.items():
                if key not in self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind]:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key] = []
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)
                else:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)
        else:
            for key, value in calc_result_list.items():
                if key not in self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind]:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key] = []
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)
                else:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)

        if 'predict' not in self.result_plate_tact['lot_id_block'][lot_id_block]:
            self.result_plate_tact['lot_id_block'][lot_id_block]['predict'] = {}
        if kind not in self.result_plate_tact['lot_id_block'][lot_id_block]['predict']:
            self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind] = {}
            for key, value in calc_result_predict_list.items():
                if key not in self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind]:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key] = []
                    self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].append(value)
                else:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].append(value)
        else:
            for key, value in calc_result_predict_list.items():
                if key not in self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind]:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key] = []
                    self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].apppend(value)
                else:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].append(value)


    def get_tact_predict(self, plate_adc_fdc, kind, adc_fdc, predict_dict_list, device, process):
        predict_detail_dict = []
        predict_plate_time = 0

        # 対象のデバイスプロセスの予測値を取得する
        predict_dict = {}
        for predict in predict_dict_list:
            if predict['device_'] == device and predict['process_'] == process:
                predict_dict = predict
                break

        # 対象の予測値がなければ空を返す
        if not predict_dict:
            return predict_detail_dict, predict_plate_time
        # 対象のADC/FDCの予測値を取得する
        kind = kind + '_'
        if(plate_adc_fdc == 1): # fdc(self.fdc)
            predict_detail_dict = predict_dict['fdc_detail_tact_']
            predict_plate_time = predict_dict['fdc_plate_tact_'][kind]
        else:
            predict_detail_dict = predict_dict['adc_detail_tact_']
            predict_plate_time = predict_dict['adc_plate_tact_'][kind]
        if 2 != adc_fdc and plate_adc_fdc != adc_fdc:   # all = 2(self.all)
            predict_plate_time = 0

        return predict_detail_dict, predict_plate_time

    def calculate_plate_detail_tact(self, statusmonitor_df, predict):
        first = 0
        base_event_time = 0
        plate_detail_tact_setting = self.get_plate_detail_tact_setting()

        # plateのADC/FDCを取得する
        plate_adc_fdc = -1
        if 'Step Start' in statusmonitor_df['event_'].values:
            plate_adc_fdc = int(statusmonitor_df[statusmonitor_df['event_'] == 'Step Start']['adc_fdc_'].values[0])

        # 対象の予測値データを取得する
        device = statusmonitor_df['device_'].unique()[0]
        process = statusmonitor_df['process_'].unique()[0]
        kind = 'throughput'
        adc_fdc = 2
        predict_detail_dict, predict_plate_time = self.get_tact_predict(plate_adc_fdc, kind, adc_fdc, predict, device, process)

        for idx, item in statusmonitor_df.iterrows():
            start_item = item
            start_event_name = start_item.loc['event_']
            event_detail_tact = {}

            # 比較するイベントと一致するStartとEndを取得する
            select_detail_tact_setting = plate_detail_tact_setting[plate_detail_tact_setting['event_start'] == start_event_name]
            if len(select_detail_tact_setting.index) != 0:
                event_name = select_detail_tact_setting['event'].values[0]
                # Startに対応するEndと一致するイベントを検索する（比較元以降のイベントを対象とする）
                end_event_name = select_detail_tact_setting['event_end'].values[0]
                end_item = statusmonitor_df[(statusmonitor_df['event_'] == end_event_name) & (statusmonitor_df.index > idx)].head(1)
                # 一致した場合
                event_name_flg = False
                if len(end_item) != 0:
                    diff_time = pd.to_datetime(end_item['date_time_'].values[0]) - start_item['date_time_']
                    diff_time_milli = diff_time.total_seconds() * 1000

                    if first == 0:
                        base_event_time = start_item['date_time_']
                        first = 1

                    event_detail_tact['event'] = event_name
                    event_detail_tact['tact'] = diff_time_milli
                    event_detail_tact['start'] = start_item['date_time_']
                    event_detail_tact['end'] = pd.to_datetime(end_item['date_time_'].values[0])
                    base_time = start_item['date_time_'] - base_event_time
                    base_time_milli = base_time.total_seconds() * 1000
                    event_detail_tact['base'] = base_time_milli
                    for j in range(0, len(predict_detail_dict)):
                        if event_name == predict_detail_dict[j][self.event_name]:
                            event_detail_tact['predict'] = predict_detail_dict[j][self.event_tact]
                        else:
                            event_detail_tact['predict'] = 0

                    self.make_result_plate_detail_tact(event_detail_tact)

        return self.resutl_plate_detail_tact

    def make_result_plate_detail_tact(self, detail_tact):
        self.resutl_plate_detail_tact.append(detail_tact)


