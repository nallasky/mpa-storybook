import pandas as pd
from dao.dao_base import DAOBaseClass
import numpy as np



if __name__ == '__main__':
    dao_base = DAOBaseClass()
    df = dao_base.fetch_all(table='cnvbase_convert_rule_item')
    info_df = df[df['type'] == 'info']
    header_df = df[df['type'] == 'header']

    info_column_names = sorted(set(info_df['output_column'].values.tolist()))
    header_column_names = sorted(set(header_df['output_column'].values.tolist()))

    for output_column in info_column_names:
        if len(output_column) == 0:
            continue

        target_dict = df[(df['output_column'] == output_column) & (df['type'] == 'info')].iloc[0][['type', 'output_column', 'data_type', 'def_val',
                                                                      'coef', 'unit']].to_dict()
        if not pd.isna(target_dict['coef']) and len(str(target_dict['coef'])) != 0:
            target_dict['coef'] = int(target_dict['coef'])

        target_dict['output_column_name'] = target_dict.pop('output_column')
        target_dict['output_column_type'] = target_dict.pop('data_type')
        target_dict['default_value'] = target_dict.pop('def_val')
        target_dict['coefficient'] = target_dict.pop('coef')
        dao_base.insert(table='settings_column_define', data=target_dict)

    for output_column in header_column_names:
        if len(output_column) == 0:
            continue

        target_dict = df[(df['output_column'] == output_column) & (df['type'] == 'header')].iloc[0][['type', 'output_column', 'data_type', 'def_val',
                                                                      'coef', 'unit']].to_dict()
        if not pd.isna(target_dict['coef']) and len(str(target_dict['coef'])) != 0:
            target_dict['coef'] = int(target_dict['coef'])

        target_dict['output_column_name'] = target_dict.pop('output_column')
        target_dict['output_column_type'] = target_dict.pop('data_type')
        target_dict['default_value'] = target_dict.pop('def_val')
        target_dict['coefficient'] = target_dict.pop('coef')
        dao_base.insert(table='settings_column_define', data=target_dict)

