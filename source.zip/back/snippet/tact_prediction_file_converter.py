# coding:utf-8
import os
import logging
import datetime
import psycopg2
import json
import glob
# from mdasimporter import CONFIG
from snippet.convert_tact_prediction import load_logfile
'''
---------------------------------------------
Tact予測値ファイルのConveterクラス

Update History:
    [2021/07/07] 新規作成

Copyright(C) Canon Inc. All right reserved.
---------------------------------------------
'''


class TactPredictionFileConveter():
    # db_info = ''
    json_list = []
    job_list = []
    # fab_name = ''
    tool_name = ''
    SEPATOR = '_'
    path = ''
    del_dev = ''
    del_pro = ''
    del_date = ''
    # TACT_PREDICTION_FILE = '*TactPrediction*.json'
    TACT_PREDICTION_FILE = '*TactPrediction*'

    def __init__(self, path):
        """コンストラクタ
        """
        self.path = path

    # @logger(__name__, "TactPredictionFileConveter")
    def tact_prediction_file_conveter(self, status_monitor_list):
        data_list = ""
        result_data_list = []
        not_found_list = []
        # StatusMonitorログがJob Startで始まるか確認するflg
        delete_flg = False
        logger = logging.getLogger('develop')
        first_log = True

        # ファイル存在チェックようにファイルパスを成形する。
        # ファイル名を除いたディレクトリパスを取得する
        file_dir = os.path.dirname(self.path)

        # 予測値ファイルが置いてあるかチェックする
        if not self._check_prediction_file(file_dir):
            # 予測値ファイルが1ファイルもない場合StatusMonitorのみを読み込む
            return result_data_list

        # StatusMonitorからDev/Pro情報を取得する
        for status_monitor_dict in status_monitor_list:
            if 'device_' in status_monitor_dict:
                device = str(status_monitor_dict.get('device_'))
            if 'process_' in status_monitor_dict:
                process = str(status_monitor_dict.get('process_'))
            if 'date_time_' in status_monitor_dict:
                date_time = str(status_monitor_dict.get('date_time_'))
            # if 'event_time' in status_monitor_dict:
            if 'date_time_' in status_monitor_dict:
                event_time = str(status_monitor_dict.get('date_time_'))

            # 値が取得できなければスキップ
            if device == '' or process == '' or date_time == '' or event_time == '':
                continue
            # 一番最初の行の読み込みか
            if first_log:
                first_log = False
                # # 最初の行読み込みの場合、前日から引き継いでいるJOBかどうかをチェック
                # before_device, before_process, before_date_time, before_event_time, before_prediction_id = self._get_before_day_prediction_data(
                #     device, process, date_time)
                # # 前日のデータがあったら取得したデータで処理する
                # if(before_prediction_id != ''):
                #     # 取得したdev/proを全て格納する（重複分も含めて）
                #     self._set_job_list(
                #         before_device,
                #         before_process,
                #         before_date_time,
                #         before_event_time,
                #         status_monitor_dict.get('event_'),
                #         before_prediction_id)
                #     # 前日データを取得できたので前日データを削除する準備をする
                #     delete_flg = True

            # JOB Startイベントの場合
            if status_monitor_dict.get('event_').startswith('JOB Start'):
                # 取得したdev/proを全て格納する（重複分も含めて）
                self._set_job_list(
                    device, process, date_time, event_time, status_monitor_dict.get('event_'), str(
                        status_monitor_dict.get('prediction_id')))

        read_comp_count = 0
        for job in self.job_list:
            default_flg = True
            not_found_flg = True
            result_list = []
            # pre_data_path = file_dir + '/' + '*' + job['job'] + '*' + '.json'
            pre_data_path = file_dir + '/' + '*' + job['job'] + '*'
            result_list = [file_path for file_path in glob.glob(
                pre_data_path) if 'default' not in file_path]

            for json_file in result_list:
                # with open(json_file, mode="r") as file:
                #     json_dict = json.load(file)
                #     data_list = json_dict.get("data")
                data_list = load_logfile(json_file)
                # 予測値ファイルの日時の範囲に入っているか確認する
                # exec_data = data_list[0]['execute_time_']
                exec_data = data_list['execute_time_']
                job_date = job['data_time']
                # 複数ファイルある場合最新のファイルのみ取得する
                conv_exec_date = datetime.datetime.strptime(
                    exec_data, '%Y/%m/%d %H:%M:%S')
                conv_job_date = datetime.datetime.strptime(
                    job_date, '%Y/%m/%d %H:%M:%S:%f')
                # 前後3分の幅で一致確認
                job_date_plus = conv_job_date + \
                    datetime.timedelta(minutes=3)
                job_date_minus = conv_job_date + \
                    datetime.timedelta(minutes=-3)

                if job_date_minus <= conv_exec_date and job_date_plus >= conv_exec_date:
                    # 日時が範囲内に入っていたら予測データを読み込む
                    # data_list[0]['data_time'] = job['data_time']
                    data_list['data_time'] = job['data_time']
                    # StatusMonitorとの紐づけ用の文字列を設定する
                    # data_list[0]['prediction_id'] = job['prediction_id']
                    # result_data_list.append(data_list[0])
                    data_list['prediction_id'] = job['prediction_id']
                    result_data_list.append(data_list)
                    read_comp_count = read_comp_count + 1
                    default_flg = False
                    not_found_flg = False
                    break

            # 予測値ファイルが見つからない場合
            if default_flg:
                # default_data_path = file_dir + '/' + '*' + \
                #     job['job'] + '_default' + '*' + '.json'
                default_data_path = file_dir + '/' + '*' + \
                    job['job'] + '_default' + '*'
                result_list = glob.glob(default_data_path)
                # デフォルトファイルを読み込む
                for json_file in result_list:
                    # with open(json_file, mode="r") as file:
                    #     json_dict = json.load(file)
                    #     data_list = json_dict.get("data")
                    data_list = load_logfile(json_file)
                    # デフォルトファイルだったらそのまま読み込む
                    # data_list[0]['data_time'] = job['data_time']
                    data_list['data_time'] = job['data_time']
                    # 同じdev/proが複数ある場合event_timeをずらすためdata_timeを登録する
                    # data_list[0]['event_time'] = job['event_time']
                    data_list['event_time'] = job['event_time']
                    # StatusMonitorとの紐づけ用の文字列を設定する
                    # data_list[0]['prediction_id'] = job['prediction_id']
                    # result_data_list.append(data_list[0])
                    data_list['prediction_id'] = job['prediction_id']
                    result_data_list.append(data_list)
                    read_comp_count = read_comp_count + 1
                    not_found_flg = False

            if not_found_flg:
                not_found_list.append(job['job'])

        if read_comp_count < len(self.job_list):
            # StatusMonitorのDev/Proに対して予測値ファイルが少ない場合はエラーにしないがメッセージだけだす
            dev_pro_info = ','.join(not_found_list)
            logger.info('prediction file not found. Job = %s', dev_pro_info)

        # 前日データが問題なく取得できていたら、今後必要ないので削除する
        # if delete_flg:
        #     self._delete_before_day_prediction_data()

        return result_data_list

    def load_tact_prediction_file(self, job):
        result_data_list = []
        not_found_list = []

        # ファイル存在チェックようにファイルパスを成形する。
        # ファイル名を除いたディレクトリパスを取得する
        file_dir = os.path.dirname(self.path)

        # 予測値ファイルが置いてあるかチェックする
        if not self._check_prediction_file(file_dir):
            # 予測値ファイルが1ファイルもない場合StatusMonitorのみを読み込む
            return result_data_list


        read_comp_count = 0
        default_flg = True
        not_found_flg = True
        pre_data_path = file_dir + '/' + '*' + job + '*'
        result_list = [file_path for file_path in glob.glob(
            pre_data_path) if 'default' not in file_path]

        for json_file in result_list:
            data_list = load_logfile(json_file)
            # 予測値ファイルの日時の範囲に入っているか確認する
            exec_data = data_list['execute_time_']
            job_date = job['data_time']
            # 複数ファイルある場合最新のファイルのみ取得する
            conv_exec_date = datetime.datetime.strptime(
                exec_data, '%Y/%m/%d %H:%M:%S')
            conv_job_date = datetime.datetime.strptime(
                job_date, '%Y/%m/%d %H:%M:%S:%f')
            # 前後3分の幅で一致確認
            job_date_plus = conv_job_date + \
                datetime.timedelta(minutes=3)
            job_date_minus = conv_job_date + \
                datetime.timedelta(minutes=-3)

            if job_date_minus <= conv_exec_date and job_date_plus >= conv_exec_date:
                # 日時が範囲内に入っていたら予測データを読み込む
                data_list['data_time'] = job['data_time']
                # StatusMonitorとの紐づけ用の文字列を設定する
                data_list['prediction_id'] = job['prediction_id']
                result_data_list.append(data_list)
                read_comp_count = read_comp_count + 1
                default_flg = False
                not_found_flg = False
                break

        # 予測値ファイルが見つからない場合
        if default_flg:
            default_data_path = file_dir + '/' + '*' + \
                job['job'] + '_default' + '*'
            result_list = glob.glob(default_data_path)
            # デフォルトファイルを読み込む
            for json_file in result_list:
                data_list = load_logfile(json_file)
                # デフォルトファイルだったらそのまま読み込む
                data_list['data_time'] = job['data_time']
                # 同じdev/proが複数ある場合event_timeをずらすためdata_timeを登録する
                data_list['event_time'] = job['event_time']
                # StatusMonitorとの紐づけ用の文字列を設定する
                data_list['prediction_id'] = job['prediction_id']
                result_data_list.append(data_list)
                read_comp_count = read_comp_count + 1
                not_found_flg = False

        if not_found_flg:
            not_found_list.append(job['job'])

        if read_comp_count < len(self.job_list):
            # StatusMonitorのDev/Proに対して予測値ファイルが少ない場合はエラーにしないがメッセージだけだす
            dev_pro_info = ','.join(not_found_list)

        # 前日データが問題なく取得できていたら、今後必要ないので削除する
        # if delete_flg:
        #     self._delete_before_day_prediction_data()

        return result_data_list

    def _set_job_list(self, device, process, date_time,
                      event_time, event, prediction_id):
        job_dict = {}
        # 取得したdev/proを全て格納する（重複分も含めて）
        job_info = device + self.SEPATOR + process
        job_dict['job'] = job_info
        job_dict['data_time'] = date_time
        job_dict['event_time'] = event_time
        # job_dict['event'] = event
        job_dict['prediction_id'] = prediction_id
        self.job_list.append(job_dict)

        return event_time

    # def _get_job_start_info(self, device, process, date):
    #     """device, processと合致する前日のデータがあるかチェックする"""
    #     res_device = ''
    #     res_process = ''
    #     res_date_time = ''
    #     res_event_id = ''
    #     res_prediction_id = ''
    #     # コネクションの作成
    #     with psycopg2.connect(self._get_setup()) as connect:
    #         # カーソルの作成
    #         with connect.cursor() as cur:
    #             try:
    #                 sql = "SELECT device, process, date_time, event_time, prediction_id " \
    #                     "FROM t_job_start " \
    #                     "WHERE fab = '{}' AND tool = '{}' AND device = '{}' AND process = '{}' AND date = '{}'".format(
    #                         self.fab_name, self.tool_name, device, process, date)
    #
    #                 cur.execute(sql)
    #                 record = cur.fetchall()
    #                 if len(record) != 0:
    #                     # タプルなので0番目の要素を指定して取得
    #                     res_device = record[0][0]
    #                     res_process = record[0][1]
    #                     res_date_time = record[0][2]
    #                     res_event_id = record[0][3]
    #                     res_prediction_id = record[0][4]
    #
    #             except Exception:
    #                 connect.rollback()
    #             else:
    #                 connect.commit()
    #     return res_device, res_process, res_date_time, res_event_id, res_prediction_id

    def _check_prediction_file(self, dir_path):
        """チェック対象のディレクトリパスを受け取って、その中に予測値ファイルがなければFalseを返す"""
        check_path = dir_path + '/' + self.TACT_PREDICTION_FILE
        result_list = glob.glob(check_path)

        if len(result_list) == 0:
            # 予測値ファイルがない(StatusMonitorのみが置かれている)のでFalse
            return False

        return True

    # def _get_before_day_prediction_data(self, device, process, today_date):
    #     """前日のprediction_idを取得する"""
    #     # 予測値ファイル紐づけIDが前日から続くかチェック
    #     # 日付型に変換
    #     today, time = str(today_date).split(' ')
    #     date_time = datetime.datetime.strptime(
    #         today, '%Y/%m/%d')
    #
    #     before_day = date_time - datetime.timedelta(days=1)
    #     before_day, before_time = str(before_day).split(' ')
    #     before_day = before_day.replace('-', '/')
    #     before_prediction_id = ''
    #     before_device, before_process, before_date_time, before_event_id, before_prediction_id = self._get_job_start_info(
    #         device, process, before_day)
    #     self.del_date = before_day
    #     self.del_dev = device
    #     self.del_pro = process
    #     return before_device, before_process, before_date_time, before_event_id, before_prediction_id

    # def _delete_before_day_prediction_data(self):
    #     """前日のデータを削除"""
    #     # コネクションの作成
    #     with psycopg2.connect(self._get_setup()) as connect:
    #         # カーソルの作成
    #         with connect.cursor() as cur:
    #             try:
    #                 sql = "DELETE FROM t_job_start " \
    #                     "WHERE fab = '{}' AND tool = '{}' AND device = '{}' AND process = '{}' AND date = '{}'".format(
    #                         self.fab_name, self.tool_name, self.del_dev, self.del_pro, self.del_date)
    #
    #                 cur.execute(sql)
    #             except Exception:
    #                 connect.rollback()
    #             else:
    #                 connect.commit()
    #
    # def _set_setup(self, info):
    #     self.db_info = info
    #
    # def _get_setup(self):
    #     return self.db_info
