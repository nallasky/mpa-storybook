import os
import logging
import sqlite3

import pandas as pd
import numpy as np
import traceback
import json
import time

from service.overlay.service_overlay_base import ServiceOverlayBase
from service.converter.convert_process import ConvertProcess
from common.utils.response import ResponseForm
from config import app_config
from dao.dao_file import FileDao
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from controller.converter.converter import create_request_id
from common.utils import preprocessing
from common.utils import calculator

logger = logging.getLogger(app_config.LOG)


class ServiceOasBase(ServiceOverlayBase):
    log_name = app_config.OASBASELINE_LOGNAME
    category_name = "Overlay"

    def __init__(self):
        super().__init__()

        self.root_path = app_config.root_path
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.log_name
        }
        # reusing pre-calculated dataframe
        self._calc_df_data = None
        # For ANOVA
        # ショット数
        self._shot_num = None
        # プレート数
        self._plate_num = None
        # ショット内サンプルポジション数
        self._position_num = None
        # betaデータ Kye:'x', 'y'
        self._beta_df = dict()
        # errデータ Key:'x', 'y'
        self._err_df = dict()

    def file_check(self, files):
        """
        :param files: [files]
        :return: {'log_name': [fids]}
        """

        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        folder = os.path.join(self.root_path, self.log_name)
        if not os.path.exists(folder):
            os.makedirs(folder)

        # Save files and Insert file info into cnvset.file table
        data = dict()
        data[self.log_name] = list()

        for log_name, file_data in files.items():
            if file_data is None:
                continue
            for file in file_data:
                filename = file.filename
                foldername = os.path.join(self.root_path, log_name)
                if not os.path.exists(foldername):
                    os.mkdir(foldername)
                if log_name not in data:
                    data[log_name] = list()
                f = None
                file_index = 1
                while f is None or os.path.exists(f):
                    _filename = f'{file_index}{app_config.UPLOAD_FILE_SEPERATOR}{filename}'
                    f = os.path.join(foldername, _filename)
                    file_index += 1
                file.save(f)
                fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))

                if fid is None:
                    logger.error('failed to store file info')
                    return ResponseForm(res=False, msg='failed to store file info')
                # data[self.log_name].append(fid)
                data[log_name].append(fid)

        return ResponseForm(res=True, data=data)

    def convert(self, logs):
        """

        :param logs: { 'log_name': [fids] }
        :return:
        """

        # Create Request ID
        self.form['id'] = create_request_id()

        file_id_list = list()
        for log_name, val in logs.items():
            file_id_list.append(','.join([str(_) for _ in logs[log_name]]))

        self.form['file'] = ','.join(file_id_list)

        # Insert Job info into cnvset.job
        io = DAOJob.instance()
        try:
            io.insert_job(**self.form)
        except Exception as e:
            logger.error('failed to insert job')
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

        # Create sub processor to convert log
        target_logs = dict()
        dao = DAOBaseClass()
        for log_name, val in logs.items():
        # #sqlite
            if isinstance(dao.connect, sqlite3.Connection):
                # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis_function as a " \
                #         f"inner join analysis_local_info as b on a.id = b.func_id) as c " \
                #         f"where system_func=true and log_name='{self.log_name}'"
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis_function as a " \
                        f"inner join analysis_local_info as b on a.id = b.func_id " \
                        f"inner join analysis_category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{self.log_name}' and title='{self.category_name}'"
            else:
                # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis.function as a " \
                #         f"inner join analysis.local_info as b on a.id = b.func_id) as c " \
                #         f"where system_func=true and log_name='{self.log_name}'"
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis.function as a " \
                        f"inner join analysis.local_info as b on a.id = b.func_id " \
                        f"inner join analysis.category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{self.log_name}' and title='{self.category_name}'"

            row = dao.execute(query)
            if row is None:
                return ResponseForm(res=False, msg=f'Cannot find {self.log_name} function.')

            target_logs[log_name] = row[0][0]

        cnv_proc = ConvertProcess(self.form['id'], target_logs)
        cnv_proc.start()

        return ResponseForm(res=True, data=self.form['id'])

    def get_oas_base_data(self, args):
        filter = dict()
        filter['log_time'] = {
            'start': args['period'].split(sep='~')[0],
            'end': args['period'].split(sep='~')[1],
        }
        filter['job'] = args['job']
        filter['lot_id'] = args['lot_id']

        org_df = preprocessing.load_oas_base(rid=args['rid'], **filter)
        adc_df = preprocessing.load_adc_meas(rid=args['rid'], **filter)
        map_df = pd.DataFrame()
        # len(adc_df) > 0 일 경우 Plate/shot별 Logical X/Y, CP/VS 정보 추출
        # len(adc_df) < 0 일 경우 skip 하고 OAS data만 출력


        # p1_xl...p3yr, logicalposition_x/y, cp/vs -> float
        # plate, step -> int
        tmp_astype = dict()
        for key, val in app_config.oas_column_type.items():
            if key in org_df:
                tmp_astype[key] = val

        org_df = org_df.astype(tmp_astype)
        # CPVS정보는 ADCMEASURE에서?
        if len(adc_df) > 0:
            cp_vs_list = app_config.cp_vs_list
            if all([item in adc_df.columns for item in cp_vs_list]):
                cp_vs_included = False if adc_df[cp_vs_list].isnull().any().any() else True
            else:
                cp_vs_included = False

            cp_vs = args['cp_vs']
            if cp_vs is not None and cp_vs['use_from_log'] is False:
                cp_vs_default = pd.DataFrame(cp_vs['adc_measurement'])
                cp_vs_values = cp_vs_default[cp_vs_list].astype(float)
                cp_vs_values = cp_vs_values.apply(lambda x: calculator.mm_to_nm(x.to_numpy()))
                cp_vs_values = cp_vs_values.reset_index().rename(columns={'index': 'step'})
                cp_vs_values = cp_vs_values.astype({'step': int})
                for i in range(len(cp_vs_values)):
                    target_step = cp_vs_values['step'].values[i]
                    for col in cp_vs_list:
                        adc_df.loc[org_df['step'] == target_step, col] = cp_vs_values[col].values[i]
            else:
                with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_SETTING_OAS_BASELINE_CP_VS_DEFAULT),
                          'r') as f:
                    cp_vs_default = json.load(f)

                for col in app_config.oas_cp_vs_list:
                    if col not in adc_df.columns:
                        adc_df[col] = calculator.mm_to_nm(cp_vs_default[col])
                    else:
                        adc_df.fillna({col: calculator.mm_to_nm(cp_vs_default[col])}, inplace=True)

            # inversion by y-axis
            inverse_list = ['bl_baseline_x', 'br_baseline_x', 'fl_baseline_x', 'fr_baseline_x']
            org_df[inverse_list] = -org_df[inverse_list]
        else:
            cp_vs_included = False

        return org_df, map_df, cp_vs_included


    def create_map(self, log_data, adc_data):
        """
        MAPを作成するためのデータを生成
        param log_data : ファイル及びDBから取得したデータ[Pandas DataFrame]
        return Map_data : Plotly Carpet TypeのGraph作成用座標データ[Dict]
        """

        try:
            map_data = dict()
            # lot_idリスt作成
            # データからlot_idリスt作成
            lot_id = log_data['lot_id'].unique()
            for lot_index in lot_id:
                map_data[lot_index] = dict()
                map_data[lot_index]['extra_info'] = dict()
                # 対象LotIDのデータ抽出
                lot_temp = log_data[log_data['lot_id'] == lot_index]
                map_data[lot_index]['extra_info']['range'] = self.get_meas_min_max(lot_temp)
                # Plateリスト作成
                plate_list = lot_temp['plate'].unique()
                plate = {}
                for plate_index in plate_list:
                    # 対象Plateのデータ抽出
                    plate_temp = lot_temp[lot_temp['plate'] == plate_index]
                    # 対象PlateのGlass名を抽出
                    glass_name = plate_temp['glass_id'].unique()
                    # Shotリスト作成
                    shot_list = plate_temp['step'].unique()
                    shot = {}
                    for shot_index in shot_list:
                        # 対象Shotのデータ抽出
                        shot_temp = plate_temp[plate_temp['step'] == shot_index]
                        # MAP作成用座標を計算
                        base, measurement = self.shot_pos_calc(shot_temp)
                        # Shot別のデータをDict形式で保存
                        shot[int(shot_index)] = {"base": base, "measurement": measurement}
                    # Glass名とPlate別のでーたをDict形式で保存
                    plate[int(plate_index)] = {"glass_num": glass_name[0], "shot": shot}
                # LotID別のデータをDict形式で保存
                map_data[lot_index]['plate'] = plate
            return ResponseForm(res=True, data=map_data)

        except Exception as e:
            logger.error('failed to create map')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def shot_pos_calc(self, shot_info):
        """
        Shotデータから基本格子、ズレ格子の座標を演算
        param shot_info : 対象ShotのLogData [Pandas DataFrame]
        return base : 基本格子の各Shot別計測点の座標 [DICT]
        retun measurement :各Shot別計測点の計測値 [DICT]
        """

        try:
            # LogicalPositionX,Yを㎜単位で変更
            x_pos = shot_info['logicalposition_x'].values[0]
            y_pos = shot_info['logicalposition_y'].values[0]
            # MAP座標名リストを生成
            pos_list = ['BR', 'BL', 'FR', 'FL']
            # DataFrameの各ズレのColumn名リスト生成
            dx_list = app_config.oas_meas_column_list_x
            dy_list = app_config.oas_meas_column_list_y
            base = {}
            measurement = {}
            # ShotのCP/VS情報を㎜単位で変更してリスト生成
            vs_list = [shot_info['vs1'].values[0], shot_info['vs3'].values[0]]
            cp_list = [shot_info['cp1'].values[0], shot_info['cp3'].values[0]]

            for index in range(len(pos_list)):
                cpvs_index = int(index / 2)
                # 右側のCP座標:logical_position_x - vs/2
                # 左側のCP座標:logical_position_x + vs/2
                if index % 2 == 0:
                    x = x_pos - vs_list[cpvs_index] / 2
                else:
                    x = x_pos + vs_list[cpvs_index] / 2

                y = y_pos + cp_list[cpvs_index]

                base[pos_list[index]] = {"x": calculator.nm_to_mm(x), "y": calculator.nm_to_mm(y)}

                # measurement[pos_list[index]] = {"x": shot_info[dx_list[index]].values[0] * app_config.NM_TO_MM,
                #                                 "y": shot_info[dy_list[index]].values[0] * app_config.NM_TO_MM}
                # 　計測値の単位をUMで変更
                measurement[pos_list[index]] = {"x": calculator.nm_to_um(shot_info[dx_list[index]].values[0]),
                                                "y": calculator.nm_to_um(shot_info[dy_list[index]].values[0])}

            # columns = shot_info.columns
            # if 'vs_inside' in columns and not pd.isna(shot_info['vs_inside'].values[0]):
            #     inside_pos_list = ['INSIDE_P1R', 'INSIDE_P2R', 'INSIDE_P3R']
            #     vs_inside = float(shot_info['vs_inside'].values[0])
            #     inside_dx_list = app_config.inside_dx_list
            #     inside_dy_list = app_config.inside_dy_list
            #     for index in range(len(inside_pos_list)):
            #         if (inside_dx_list[index] in columns and not pd.isna(shot_info[inside_dx_list[index]].values[0])) \
            #                 and (inside_dy_list[index] in columns and not pd.isna(shot_info[inside_dy_list[index]].values[0])):
            #             dx_val = float(shot_info[inside_dx_list[index]].values[0])
            #             dy_val = float(shot_info[inside_dy_list[index]].values[0])
            #
            #             x = x_pos + vs_inside / 2
            #             y = y_pos + cp_list[index]
            #             base[inside_pos_list[index]] = {"x": calculator.nm_to_mm(x), "y": calculator.nm_to_mm(y)}
            #             measurement[inside_pos_list[index]] = {
            #                 "x": calculator.nm_to_um(dx_val),
            #                 "y": calculator.nm_to_um(dy_val)
            #             }

            return base, measurement

        except Exception as e:
            logger.error('failed to shot_pos_calc')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def get_meas_min_max(self, df):
        """
        Get min, max value(micro meter) for each measurement position.

        :param df: ADC Measurement Log DataFrame
        :return: {
            'p1_xl': [min, max],
            ...
            'p3_yr': [min, max]
        }
        """
        min_max = dict()
        for col in app_config.oas_meas_column_list:
            min_max[col] = [calculator.nm_to_um(df[col].min()), calculator.nm_to_um(df[col].max())]

        return min_max

    def mean_deviation(self, log_data, selected_plate_list):
        """
        選択されたPlateの各Shot別計測値び平均を算出して、log各計測値の平均差分を演算する。
        param log_data : logデータ[Pandas Dataframe]
        param selected_plate_list : 選択されたPlateのList[List]
        return log_data : 平均差分演算値が適用されたLogデータ
        """

        try:
            temp_data = log_data[log_data['plate'].isin(selected_plate_list)].get(
                (["step"] + app_config.oas_meas_column_list))
            average_data = temp_data.groupby(['step']).mean().reset_index().rename({'index': 'step'})
            result_df = pd.DataFrame()

            for i in range(len(average_data)):
                step = average_data['step'].values[i]
                target_df = log_data[log_data['step'] == step]
                for col in app_config.oas_meas_column_list:
                    if target_df[col].dtype != 'float64':
                        target_df[col] = target_df[col].astype('float') - average_data[average_data['step'] == step][col].values[0]
                    else:
                        target_df[col] = target_df[col] - average_data[average_data['step'] == step][col].values[0]

                result_df = pd.concat([result_df, target_df])

            result_df.sort_index(inplace=True)
            return result_df

        except Exception as e:
            logger.error('failed to mean_deviation')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))