import os
import logging
import sqlite3

import pandas as pd
import numpy as np
import traceback
import json
import datetime

from service.overlay.service_overlay_base import ServiceOverlayBase
from service.converter.convert_process import ConvertProcess
from common.utils.response import ResponseForm
from config import app_config
from dao.dao_file import FileDao
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from controller.converter.converter import create_request_id
from common.utils import preprocessing
from common.utils import calculator

logger = logging.getLogger(app_config.LOG)


class ServiceOasBase(ServiceOverlayBase):
    log_name = app_config.OASBASELINE_LOGNAME
    category_name = "Overlay"

    def __init__(self):
        super().__init__()

        self.root_path = app_config.root_path
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.log_name
        }
        # reusing pre-calculated dataframe
        self._calc_df_data = None
        # For ANOVA
        # ショット数
        self._shot_num = None
        # プレート数
        self._plate_num = None
        # ショット内サンプルポジション数
        self._position_num = None
        # betaデータ Kye:'x', 'y'
        self._beta_df = dict()
        # errデータ Key:'x', 'y'
        self._err_df = dict()

    def file_check(self, files):
        """
        :param files: [files]
        :return: {'log_name': [fids]}
        """

        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        folder = os.path.join(self.root_path, self.log_name)
        if not os.path.exists(folder):
            os.makedirs(folder)

        # Save files and Insert file info into cnvset.file table
        data = dict()
        data[self.log_name] = list()

        for log_name, file_data in files.items():
            if file_data is None:
                continue
            for file in file_data:
                filename = file.filename
                foldername = os.path.join(self.root_path, log_name)
                if not os.path.exists(foldername):
                    os.mkdir(foldername)
                if log_name not in data:
                    data[log_name] = list()
                f = None
                file_index = 1
                while f is None or os.path.exists(f):
                    _filename = f'{file_index}{app_config.UPLOAD_FILE_SEPERATOR}{filename}'
                    f = os.path.join(foldername, _filename)
                    file_index += 1
                file.save(f)
                fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))

                if fid is None:
                    logger.error('failed to store file info')
                    return ResponseForm(res=False, msg='failed to store file info')
                # data[self.log_name].append(fid)
                data[log_name].append(fid)

        return ResponseForm(res=True, data=data)

    def convert(self, logs):
        """

        :param logs: { 'log_name': [fids] }
        :return:
        """

        # Create Request ID
        self.form['id'] = create_request_id()

        file_id_list = list()
        for log_name, val in logs.items():
            file_id_list.append(','.join([str(_) for _ in logs[log_name]]))

        self.form['file'] = ','.join(file_id_list)

        # Insert Job info into cnvset.job
        io = DAOJob.instance()
        try:
            io.insert_job(**self.form)
        except Exception as e:
            logger.error('failed to insert job')
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

        # Create sub processor to convert log
        target_logs = dict()
        dao = DAOBaseClass()
        for log_name, val in logs.items():
        #sqlite
            if isinstance(dao.connect, sqlite3.Connection):
                # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis_function as a " \
                #         f"inner join analysis_local_info as b on a.id = b.func_id) as c " \
                #         f"where system_func=true and log_name='{self.log_name}'"
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis_function as a " \
                        f"inner join analysis_local_info as b on a.id = b.func_id " \
                        f"inner join analysis_category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{log_name}' and title='{self.category_name}'"
            else:
                # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis.function as a " \
                #         f"inner join analysis.local_info as b on a.id = b.func_id) as c " \
                #         f"where system_func=true and log_name='{self.log_name}'"
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis.function as a " \
                        f"inner join analysis.local_info as b on a.id = b.func_id " \
                        f"inner join analysis.category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{log_name}' and title='{self.category_name}'"

            row = dao.execute(query)
            if row is None:
                return ResponseForm(res=False, msg=f'Cannot find {log_name} function.')

            target_logs[log_name] = row[0][0]

        cnv_proc = ConvertProcess(self.form['id'], target_logs)
        cnv_proc.start()

        return ResponseForm(res=True, data=self.form['id'])

    def get_etc_settings(self, args, org_df):
        etc = dict()
        dao_base = DAOBaseClass()
        fab_info = dao_base.fetch_one(table='fab.fab', args={'where': f"fab_nm='{args.fab_nm}'"})
        if fab_info is None:
            return ResponseForm(res=False, msg='Cannot find Fab name.')

        etc['display_map'] = {'min': org_df['plate'].min(), 'max': org_df['plate'].max()}
        etc['column_num'] = app_config.MAP_COLUMN_NUM
        etc['div'] = {'div_upper': fab_info['div_upper'],
                      'scale': app_config.MAP_SCALE}
        etc['plate_size'] = {'size_x': fab_info['plate_size_x'], 'size_y': fab_info['plate_size_y']}

        return ResponseForm(res=True, data=etc)

    def get_cp_vs_disp_settings(self, args, org_df, included):
        dao_base = DAOBaseClass()
        with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_SETTING_OAS_BASELINE_CP_VS_DEFAULT),
                  'r') as f:
            cp_vs_default = json.load(f)

        ret_cp_vs = dict()
        ret_cp_vs['included'] = included
        if 'expo_mode' in org_df.columns and org_df['expo_mode'].isnull().sum() == 0:
            ret_cp_vs['expo_mode'] = int(org_df['expo_mode'].values[0])
        else:
            ret_cp_vs['expo_mode'] = 0
        ret_cp_vs['default'] = cp_vs_default
        ret_cp_vs['shot'] = org_df['step'].unique().tolist()

        cp_vs_preset_df = dao_base.fetch_all(table='fab.oasbaseline_cp_vs_preset',
                                             args={'where': f"fab_nm='{args.fab_nm}'"})

        preset_dict = dict()
        for i in range(len(cp_vs_preset_df)):
            preset_dict[int(cp_vs_preset_df['id'].values[i])] = cp_vs_preset_df['name'].values[i]

        ret_cp_vs['preset'] = preset_dict

        return ret_cp_vs

    def get_auto_xy_offset(self, df_data):
        # 結果データフレーム
        calc_df = pd.DataFrame()
        # 基本計測店位置を計算する。 (X1L, X1R, Y1L, Y1R...)
        df_data = self.calc_base_position(df_data)

        # 計算結果保存 Column 追加
        df_data['x'] = 0
        df_data['y'] = 0

        lot_id_list = df_data['lot_id'].unique().tolist()
        for lot_id in lot_id_list:
            lot_df = df_data[df_data['lot_id'] == lot_id]

            # 計測する考慮しないで CP 位置だけ利用して位置計算
            # 各プレートごとにショットあまり Offsetが計算されなければならない
            for i_plate in lot_df['plate'].unique().tolist():
                # 各プレート単位で DataFrame 取得
                target_plate = lot_df[lot_df['plate'] == i_plate]

                # Y軸基準で整列
                grp_df = target_plate.sort_values(by='logicalposition_y', ascending=True)

                # 以前行きと現在行義沈着を計算
                diff_v = grp_df['logicalposition_y'].diff()

                # グリッド一軒の大きさの 2倍(100mm)の沈着は皆 0で見做す。
                diff_v[(diff_v < app_config.GRP_THREASHOLD) | np.isnan(diff_v)] = 0
                grp_df['v_grp'] = diff_v.cumsum()  # 累積寄せ算。 (default = row )

                # グループの手順
                group = grp_df.groupby('v_grp')

                # 計算された back,front中に最大値/最小値求め
                bound_max = group[['bs_bl_baseline_y', 'bs_fl_baseline_y']].apply(lambda x: np.nanmax(x.values))
                bound_min = group[['bs_bl_baseline_y', 'bs_fl_baseline_y']].apply(lambda x: np.nanmin(x.values))

                # DataFrameで変換
                bound_max = pd.DataFrame(bound_max)
                bound_min = pd.DataFrame(bound_min)

                # グループの個数を確認
                grp_list = grp_df['v_grp'].unique().tolist()
                grp_num = len(grp_list)
                accumulated = 0
                # Y祝意オフセット計算
                for idy in range(grp_num - 1):
                    if bound_min.loc[grp_list[idy + 1]].values[0] <= bound_max.loc[grp_list[idy]].values[0]:
                        diff = bound_min.loc[grp_list[idy + 1]].values[0] - bound_max.loc[grp_list[idy]].values[0]
                        diff = np.abs(diff)  # 自動計算オフセットは次の shotでから落とすから増加しならなければならない。
                        # 二番目グループのすべての Y軸にオ
                        target_grp_val = grp_list[idy + 1]
                        grp_df.loc[grp_df['v_grp'] == target_grp_val, 'y'] = diff + accumulated
                        accumulated += diff

                # X祝意オフセット計算(グループ別)
                for idx in range(grp_num):
                    target_grp_val = grp_list[idx]
                    # グループ内で X軸方向に昇順整列
                    grp_shot_list = grp_df[grp_df['v_grp'] == target_grp_val].sort_values(by=['logicalposition_x'],
                                                                                          ascending=True)
                    step_list = grp_shot_list['step'].tolist()
                    accumulated = 0
                    for sid in range(len(step_list) - 1):
                        # shotの x位置の中で xrの最大値、xlの最小値を X祝意基準にする。
                        next_xr_min = grp_shot_list[grp_shot_list['step'] == step_list[sid + 1]][[
                            'bs_br_baseline_x', 'bs_fr_baseline_x']].min(axis=1)
                        curr_xl_max = grp_shot_list[grp_shot_list['step'] == step_list[sid]][[
                            'bs_bl_baseline_x', 'bs_fl_baseline_x']].max(axis=1)
                        if next_xr_min.values[0] <= curr_xl_max.values[0]:
                            diff = next_xr_min.values[0] - curr_xl_max.values[0]
                            diff = np.abs(diff)
                            grp_df.loc[(grp_df['v_grp'] == target_grp_val) & (grp_df['step'] == step_list[sid + 1]),
                                       'x'] = diff + accumulated
                            accumulated += diff
                        else:
                            pass
                # 各 Plateあまり取得した offset データを結合。
                calc_df = pd.concat([calc_df, grp_df.sort_index()])

        # オフセットデータで最大値を取得して代表オフセットで設定
        offset_table = calc_df.groupby(by='step')[['x', 'y']].max().fillna(0)
        calc_data = offset_table.to_dict('index')

        return calc_data

    def calc_base_position(self, df_data):
        # キャッシュされたデータがある場合は再利用
        if self._calc_df_data is not None:
            return self._calc_df_data

        io_list = ['lot_id', 'plate', 'step', 'logicalposition_x', 'logicalposition_y']
        io_data = df_data[io_list + app_config.oas_meas_column_list + app_config.oas_cp_vs_list]
        # 単位変更(for auto xy offset, anova calc)
        unit_mm_list = ['logicalposition_x', 'logicalposition_y'] + app_config.oas_cp_vs_list
        io_data[unit_mm_list] = io_data[unit_mm_list].apply(lambda x: calculator.nm_to_mm(x.to_numpy()))
        unit_um_list = app_config.oas_meas_column_list
        io_data[unit_um_list] = io_data[unit_um_list].apply(lambda x: calculator.nm_to_um(x.to_numpy()))

        steps_list = []
        for idx in range(len(io_data)):
            # 一つのショットごとに持って来て計算
            ishot = io_data.loc[idx]
            logipos_x = ishot['logicalposition_x']
            logipos_y = ishot['logicalposition_y']
            step_dict = dict()
            step_dict['bs_br_baseline_x'] = logipos_x - (ishot['vs_back'] / 2)
            step_dict['bs_br_baseline_y'] = logipos_y + ishot['back']
            step_dict['bs_bl_baseline_x'] = logipos_x + (ishot['vs_back'] / 2)
            step_dict['bs_bl_baseline_y'] = logipos_y + ishot['back']
            step_dict['bs_fr_baseline_x'] = logipos_x - (ishot['vs_front'] / 2)
            step_dict['bs_fr_baseline_y'] = logipos_y + ishot['front']
            step_dict['bs_fl_baseline_x'] = logipos_x + (ishot['vs_front'] / 2)
            step_dict['bs_fl_baseline_y'] = logipos_y + ishot['front']
            steps_list.append(step_dict)

        calc_df = pd.DataFrame(steps_list)
        io_data = pd.concat([io_data, calc_df], axis=1)
        # 結果を保存
        self._calc_df_data = io_data.copy(deep=True)
        return io_data


    def create_map(self, log_data):
        """
        MAPを作成するためのデータを生成
        param log_data : ファイル及びDBから取得したデータ[Pandas DataFrame]
        return Map_data : Plotly Carpet TypeのGraph作成用座標データ[Dict]
        """

        try:
            map_data = dict()
            # lot_idリスt作成
            # データからlot_idリスt作成
            lot_id = log_data['lot_id'].unique()
            for lot_index in lot_id:
                map_data[lot_index] = dict()
                map_data[lot_index]['extra_info'] = dict()
                # 対象LotIDのデータ抽出
                lot_temp = log_data[log_data['lot_id'] == lot_index]
                map_data[lot_index]['extra_info']['range'] = self.get_meas_min_max(lot_temp)
                # Plateリスト作成
                plate_list = lot_temp['plate'].unique()
                plate = {}
                for plate_index in plate_list:
                    # 対象Plateのデータ抽出
                    plate_temp = lot_temp[lot_temp['plate'] == plate_index]
                    # 対象PlateのGlass名を抽出
                    glass_name = plate_temp['glass_id'].unique()
                    # Shotリスト作成
                    shot_list = plate_temp['step'].unique()
                    shot = {}
                    for shot_index in shot_list:
                        # 対象Shotのデータ抽出
                        shot_temp = plate_temp[plate_temp['step'] == shot_index]
                        # MAP作成用座標を計算
                        base, measurement = self.shot_pos_calc(shot_temp)
                        # Shot別のデータをDict形式で保存
                        shot[int(shot_index)] = {"base": base, "measurement": measurement}
                        if len(shot[int(shot_index)]['measurement']) == 0:
                            del shot[int(shot_index)]['measurement']
                    # Glass名とPlate別のでーたをDict形式で保存
                    plate[int(plate_index)] = {"glass_num": glass_name[0], "shot": shot}
                # LotID別のデータをDict形式で保存
                map_data[lot_index]['plate'] = plate
            return ResponseForm(res=True, data=map_data)

        except Exception as e:
            logger.error('failed to create map')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def shot_pos_calc(self, shot_info):
        """
        Shotデータから基本格子、ズレ格子の座標を演算
        param shot_info : 対象ShotのLogData [Pandas DataFrame]
        return base : 基本格子の各Shot別計測点の座標 [DICT]
        retun measurement :各Shot別計測点の計測値 [DICT]
        """

        try:
            # LogicalPositionX,Yを㎜単位で変更
            x_pos = shot_info['logicalposition_x'].values[0]
            y_pos = shot_info['logicalposition_y'].values[0]
            # MAP座標名リストを生成
            pos_list = ['BR', 'BL', 'FR', 'FL']
            # DataFrameの各ズレのColumn名リスト生成
            dx_list = app_config.oas_meas_column_list_x
            dy_list = app_config.oas_meas_column_list_y
            base = {}
            measurement = {}
            # ShotのCP/VS情報を㎜単位で変更してリスト生成
            vs_list = [shot_info['vs_back'].values[0], shot_info['vs_front'].values[0]]
            cp_list = [shot_info['back'].values[0], shot_info['front'].values[0]]

            for index in range(len(pos_list)):
                cpvs_index = int(index / 2)
                # 右側のCP座標:logical_position_x - vs/2
                # 左側のCP座標:logical_position_x + vs/2
                if index % 2 == 0:
                    x = x_pos - vs_list[cpvs_index] / 2
                else:
                    x = x_pos + vs_list[cpvs_index] / 2

                y = y_pos + cp_list[cpvs_index]

                base[pos_list[index]] = {"x": calculator.nm_to_mm(x), "y": calculator.nm_to_mm(y)}
                if pd.isna(shot_info[dx_list[index]].values[0]) and pd.isna(shot_info[dy_list[index]].values[0]):
                    continue
                measurement[pos_list[index]] = {"x": calculator.nm_to_um(shot_info[dx_list[index]].values[0]),
                                                "y": calculator.nm_to_um(shot_info[dy_list[index]].values[0])}
            return base, measurement

        except Exception as e:
            logger.error('failed to shot_pos_calc')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def get_meas_min_max(self, df):
        """
        Get min, max value(micro meter) for each measurement position.

        :param df: ADC Measurement Log DataFrame
        :return: {
            'p1_xl': [min, max],
            ...
            'p3_yr': [min, max]
        }
        """
        col_map = {'bl_baseline_x': 'BL_X', 'br_baseline_x': 'BR_X', 'fl_baseline_x': 'FL_X', 'fr_baseline_x': 'FR_X',
                   'bl_baseline_y': 'BL_Y', 'br_baseline_y': 'BR_Y', 'fl_baseline_y': 'FL_Y', 'fr_baseline_y': 'FR_Y'}
        min_max = dict()
        for col in app_config.oas_meas_column_list:
            min_max[col_map[col]] = [calculator.nm_to_um(df[col].min()), calculator.nm_to_um(df[col].max())]

        return min_max

    def get_3sigma_max_pos(self, df):

        # 必要な Columnsデータだけ持って来る。
        filterlist = ['plate', 'step', 'lot_id'] + app_config.oas_meas_column_list
        target_data = df[filterlist]
        lot_id_list = target_data['lot_id'].unique().tolist()

        res_data = dict()

        for lot_id in lot_id_list:
            lot_df = target_data[target_data['lot_id'] == lot_id]

            shot_list = lot_df['step'].unique().tolist()
            shot_list = np.sort(shot_list)  # 昇順で整列

            # 各シャッビョルでグループ化して演算準備
            grped_shot = lot_df.groupby(by='step')

            # 標準偏差計算 -> 3σ値段計算
            std_deviation = grped_shot.std() * 3
            # 小数点 3桁まで取得
            std_deviation = np.round(std_deviation, 3)

            label_list = []
            x_dataset_list = []
            y_dataset_list = []

            # 軸ラベル文字列作成
            for sn in shot_list:
                label_list.append(f'{sn}/BL')
                label_list.append(f'{sn}/BR')
                label_list.append(f'{sn}/FL')
                label_list.append(f'{sn}/FR')

                x_dataset_list += std_deviation.loc[sn, app_config.oas_meas_column_list_x].tolist()
                y_dataset_list += std_deviation.loc[sn, app_config.oas_meas_column_list_y].tolist()

            # 結果を保存する DataFrame 生成
            calc_data = pd.DataFrame(None, columns=['x', 'y'], index=label_list)
            calc_data['x'] = x_dataset_list
            calc_data['y'] = y_dataset_list

            x_max = calc_data['x'].max()
            y_max = calc_data['y'].max()
            x_max_df = calc_data[calc_data['x'] == x_max]
            y_max_df = calc_data[calc_data['y'] == y_max]

            x_list = list()
            for i in range(len(x_max_df)):
                info = x_max_df.index[i].split(sep='/')
                x_list.append({'shot': int(info[0]), 'pos': info[1]})

            y_list = list()
            for i in range(len(y_max_df)):
                info = y_max_df.index[i].split(sep='/')
                y_list.append({'shot': int(info[0]), 'pos': info[1]})

            res_data[lot_id] = {'x': x_list, 'y': y_list}

        return res_data

    def mean_deviation(self, log_data, selected_plate_list):
        """
        選択されたPlateの各Shot別計測値び平均を算出して、log各計測値の平均差分を演算する。
        param log_data : logデータ[Pandas Dataframe]
        param selected_plate_list : 選択されたPlateのList[List]
        return log_data : 平均差分演算値が適用されたLogデータ
        """

        try:
            temp_data = log_data[log_data['plate'].isin(selected_plate_list)].get(
                (["step"] + app_config.oas_meas_column_list))
            average_data = temp_data.groupby(['step']).mean().reset_index().rename({'index': 'step'})
            result_df = pd.DataFrame()

            for i in range(len(average_data)):
                step = average_data['step'].values[i]
                target_df = log_data[log_data['step'] == step]
                for col in app_config.oas_meas_column_list:
                    if target_df[col].dtype != 'float64':
                        target_df[col] = target_df[col].astype('float') - average_data[average_data['step'] == step][col].values[0]
                    else:
                        target_df[col] = target_df[col] - average_data[average_data['step'] == step][col].values[0]

                result_df = pd.concat([result_df, target_df])

            result_df.sort_index(inplace=True)
            return result_df

        except Exception as e:
            logger.error('failed to mean_deviation')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def get_oas_base_data(self, args):
        try:
            result = dict()
            filter = dict()
            filter['log_time'] = {
                'start': args['period'].split(sep='~')[0],
                'end': args['period'].split(sep='~')[1],
            }
            filter['job'] = args['job']
            filter['lot_id'] = args['lot_id']
            filter['data_type'] = args['graph_select']
            org_df = preprocessing.load_oas_base(rid=args['rid'], **filter)
            # bl_baseline_x...fr_baseline_y, logicalposition_x/y, cp/vs -> float
            # plate, step -> int
            tmp_astype = dict()
            for key, val in app_config.oas_column_type.items():
                if key in org_df:
                    tmp_astype[key] = val
            org_df = org_df.astype(tmp_astype)
            for col in app_config.UN_USE_OAS_BASELINE_COL:
                if col in org_df.columns:
                    org_df.drop(col, axis=1, inplace=True)

            return org_df

        except Exception as e:
            logger.error('failed to oas_baseline_plot_data_create')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def create_oas_base_plot_data(self, org_df):
        try:
            org_dict = org_df.fillna(0).to_dict(orient='index')
            result = dict()
            for key, value in org_dict.items():

                if value['step'] not in result.keys():
                    result[value['step']] = dict()
                if value['glass_id'] not in result[value['step']].keys():
                    result[value['step']][value['glass_id']] = dict()
                data = {
                    "BL_X": calculator.nm_to_um(value['bl_baseline_x']),
                    "BL_Y": calculator.nm_to_um(value['bl_baseline_y']),
                    "BR_X": calculator.nm_to_um(value['br_baseline_x']),
                    "BR_Y": calculator.nm_to_um(value['br_baseline_y']),
                    "FL_X": calculator.nm_to_um(value['fl_baseline_x']),
                    "FL_Y": calculator.nm_to_um(value['fl_baseline_y']),
                    "FR_X": calculator.nm_to_um(value['fr_baseline_x']),
                    "FR_Y": calculator.nm_to_um(value['fr_baseline_y'])
                }
                result[value['step']][value['glass_id']]['log_date'] = value['log_time']
                result[value['step']][value['glass_id']]['plate'] = value['plate']
                result[value['step']][value['glass_id']]['data'] = data

            return ResponseForm(res=True, data=result)

        except Exception as e:
            logger.error('failed to oas_baseline_plot_data_create')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def get_oas_base_map_data(self, args, func='analysis'):
        try:
            filter = dict()
            cp_vs_included = False
            filter['log_time'] = {
                'start': args['period'].split(sep='~')[0],
                'end': args['period'].split(sep='~')[1],
            }
            filter['job'] = args['job']
            filter['lot_id'] = args['lot_id']
            filter['data_type'] = args['graph_select']
            oas_base_df = preprocessing.load_oas_base(rid=args['rid'], **filter).fillna(0)

            del filter['log_time']
            start = datetime.datetime.strptime(args['period'].split(sep='~')[0].split()[0], '%Y-%m-%d') - \
                    datetime.timedelta(days=1)
            end = datetime.datetime.strptime(args['period'].split(sep='~')[1].split()[0], '%Y-%m-%d') + \
                  datetime.timedelta(days=2) - datetime.timedelta(minutes=1)
            filter['log_time'] = {
                'start': str(start),
                'end': str(end)
            }
            # p1_xl...p3yr, logicalposition_x/y, cp/vs -> float
            # plate, step -> int
            tmp_astype = dict()
            for key, val in app_config.oas_column_type.items():
                if key in oas_base_df:
                    tmp_astype[key] = val

            oas_base_df = oas_base_df.astype(tmp_astype)
            for col in app_config.UN_USE_OAS_BASELINE_COL:
                if col in oas_base_df.columns:
                    oas_base_df.drop(col, axis=1, inplace=True)

            map_df = pd.DataFrame()

            if args['graph_select'] in app_config.OAS_MAP_DISPLAY_DATA_TYPE:
                adc_df = preprocessing.load_adc_meas(rid=args['rid'], **filter)

                # len(adc_df) > 0 일 경우 Plate/shot별 Logical X/Y, CP/VS 정보 추출
                # len(adc_df) < 0 일 경우 skip 하고 OAS data만 출력0

                if adc_df is not None:
                    if len(adc_df) > 0:
                        # CP/VS 명칭 변경
                        adc_df.rename(columns=app_config.oas_cp_vs_rename_dict, inplace=True)
                        cp_vs_list = app_config.oas_cp_vs_list
                        if all([item in adc_df.columns for item in cp_vs_list]):
                            cp_vs_included = False if adc_df[cp_vs_list].isnull().any().any() else True
                        else:
                            cp_vs_included = False

                        cp_vs = args['cp_vs']
                        if cp_vs is not None and cp_vs['use_from_log'] is False:
                            cp_vs_default = pd.DataFrame(cp_vs['oasbaseline'])
                            cp_vs_values = cp_vs_default[cp_vs_list].astype(float)
                            cp_vs_values = cp_vs_values.apply(lambda x: calculator.mm_to_nm(x.to_numpy()))
                            cp_vs_values = cp_vs_values.reset_index().rename(columns={'index': 'step'})
                            cp_vs_values = cp_vs_values.astype({'step': int})
                            adc_df = adc_df.astype({'plate': int, 'step': int})
                            for i in range(len(cp_vs_values)):
                                target_step = cp_vs_values['step'].values[i]
                                for col in cp_vs_list:
                                    adc_df.loc[adc_df['step'] == target_step, col] = cp_vs_values[col].values[i]
                        else:
                            with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_SETTING_OAS_BASELINE_CP_VS_DEFAULT),
                                      'r') as f:
                                cp_vs_default = json.load(f)

                            for col in app_config.oas_cp_vs_list:
                                if col not in adc_df.columns:
                                    adc_df[col] = calculator.mm_to_nm(cp_vs_default[col])
                                else:
                                    adc_df.fillna({col: calculator.mm_to_nm(cp_vs_default[col])}, inplace=True)

                        # inversion by y-axis
                        inverse_list = ['bl_baseline_x', 'br_baseline_x', 'fl_baseline_x', 'fr_baseline_x']
                        oas_base_df[inverse_list] = -oas_base_df[inverse_list]

                        for col in app_config.OAS_BASELINE_MAP_OMIT_LIST:
                            if col in oas_base_df.columns:
                                oas_base_df.drop(col, axis=1, inplace=True)
                        adc_df = adc_df.astype(app_config.oas_map_column_type)
                        if func == 'analysis':
                            map_df = pd.merge(adc_df, oas_base_df, how='outer', on=['plate', 'step'])
                            map_df = map_df[map_df['plate'].isin(oas_base_df['plate'].unique())]
                        else:
                            map_df = adc_df

                        for col in app_config.OAS_BASELINE_MAP_ADC_OMIT_LIST:
                            if col in map_df.columns:
                                map_df.drop(col, axis=1, inplace=True)
            else:
                map_df = pd.DataFrame()

            return map_df, cp_vs_included

        except Exception as e:
            logger.error('failed to oas_baseline_map_data_create')
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))