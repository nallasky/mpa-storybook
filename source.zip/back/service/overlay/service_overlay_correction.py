import os
import logging

from service.overlay.service_overlay_base import ServiceOverlayBase
from common.utils.response import ResponseForm
from config import app_config
from dao.dao_file import FileDao
from controller.converter.converter import create_request_id

logger = logging.getLogger(app_config.LOG)


class ServiceCorrection(ServiceOverlayBase):
    def __init__(self):
        super().__init__()

    def file_check(self, files):
        """

        :param files: [files]
        :return: {'log_name': [fids]}
        """
        # Check file extension
        if '.zip' not in files.filename.lower():
            return ResponseForm(res=False, msg='Not supported extension. Allowed zip file only.')

        if not os.path.exists(self.root_path):
            os.mkdir(self.root_path)

        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        # Save files and Insert file info into cnvset.file table
        data = dict()
        data[self.log_name] = list()

        for file in files:
            filename = file.filename
            f = None
            file_index = 1
            while f is None or os.path.exists(f):
                _filename = f'{file_index}____{filename}'
                f = os.path.join(self.root_path, _filename)
                file_index += 1
            file.save(f)
            fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))
            if fid is None:
                logger.error('failed to store file info')
                return ResponseForm(res=False, msg='failed to store file info')

            data[self.log_name].append(fid)

        return ResponseForm(res=True, data=data)

    def convert(self):
        pass
