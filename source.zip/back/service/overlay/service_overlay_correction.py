import os
import logging
import zipfile
import pandas as pd
import math

from service.overlay.service_overlay_base import ServiceOverlayBase
from service.converter.convert_process import ConvertProcess
from common.utils.response import ResponseForm
from config import app_config
from dao.dao_file import FileDao
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from controller.converter.converter import create_request_id
from service.overlay import correction_param
from service.overlay.correction_conveter import CorrectionConverter
from common.utils import preprocessing

logger = logging.getLogger(app_config.LOG)


class ServiceCorrection(ServiceOverlayBase):
    log_name = 'correction'

    def __init__(self):
        super().__init__()

        self.root_path = app_config.root_path
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.log_name
        }

    def file_check(self, files):
        """

        :param files: [files]
        :return: {'log_name': [fids]}
        """
        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        if len(files) > 1:
            return ResponseForm(res=False, msg='Too many files.')

        # Check file extension
        for file in files:
            if '.zip' not in file.filename.lower():
                return ResponseForm(res=False, msg='Not supported extension. Allowed zip file only.')

        if not os.path.exists(self.root_path):
            os.mkdir(self.root_path)

        data = dict()

        for file in files:
            zfobj = zipfile.ZipFile(file)
            for filepath in zfobj.namelist():
                if not zfobj.getinfo(filepath).is_dir():
                    uncompressed = zfobj.read(filepath)
                    filename = os.path.basename(filepath)
                    filepath = os.path.dirname(filepath)
                    log_name = filepath.split(sep='/')[-1]
                    if log_name not in data:
                        data[log_name] = list()
                    f = None
                    file_index = 1
                    folder = os.path.join(self.root_path, filepath)
                    if not os.path.exists(folder):
                        os.makedirs(folder)

                    while f is None or os.path.exists(f):
                        _filename = f'{file_index}____{filename}'
                        f = os.path.join(folder, _filename)
                        file_index += 1

                    with open(f, 'wb') as output:
                        output.write(uncompressed)

                    fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))
                    if fid is None:
                        logger.error('failed to store file info')
                        return ResponseForm(res=False, msg='failed to store file info')

                    data[log_name].append(fid)

        return ResponseForm(res=True, data=data)

    def convert(self, logs):
        """

        :param logs: { 'log_name': [fids] }
        :return:
        """

        # Create Request ID
        self.form['id'] = create_request_id()

        file_id_list = list()
        for log_name, val in logs.items():
            file_id_list.append(','.join([str(_) for _ in logs[log_name]]))

        self.form['file'] = ','.join(file_id_list)

        # Insert Job info into cnvset.job
        io = DAOJob.instance()
        try:
            io.insert_job(**self.form)
        except Exception as e:
            logger.error('failed to insert job')
            return ResponseForm(res=False, msg=str(e))

        # Create sub processor to convert log
        target_logs = dict()
        dao = DAOBaseClass()
        for log_name, val in logs.items():
            query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis.function as a " \
                    f"inner join analysis.local_info as b on a.id = b.func_id) as c " \
                    f"where system_func=true and log_name='{log_name}'"
            row = dao.execute(query)
            if row is None:
                return ResponseForm(res=False, msg=f'Cannot find {log_name} function.')

            target_logs[log_name] = row[0][0]

        cnv_proc = ConvertProcess(self.form['id'], target_logs)
        cnv_proc.start()

        return ResponseForm(res=True, data=self.form['id'])

    def get_correction_data(self, args):
        filter = dict()
        filter['log_time'] = {
            'start': args.period.split(sep='~')[0],
            'end': args.period.split(sep='~')[1],
        }
        filter['job'] = args.job

        return preprocessing.load_correction_file(rid=args.rid, **filter)

    def correction_data_convert(self, data_file):
        """
        param data_file : Correction Component データを変換されたファイル
        return df_dict :
        """
        data_list = list()
        open_file = open(data_file)
        lines = open_file.readlines()
        for line in lines:
            rep_line = line.replace('NaN', '"NaN"')
            temp_dict = eval(rep_line)
            data_list.append(temp_dict)
        test_df = pd.DataFrame(data_list)
        event_id_list = test_df['event_id'].unique()
        df_dict = dict()
        for event_id in event_id_list:
            if event_id == "nan":
                continue
            temp = test_df[test_df['event_id'] == event_id]
            tp_temp = pd.DataFrame.transpose(temp)
            drop_temp = tp_temp.dropna(how="any")
            org_temp = pd.DataFrame.transpose(drop_temp)
            df_dict[event_id] = org_temp.reset_index(drop=True)
        return df_dict

    def corretion_image_aggregateData(self, graph_category, param, df_dict):
        """
        param param :
        parma data :
        retun result_map :
        """
        # graph_category = 'correction_image' or 'correction_component'
        data_dict = {
            'ADC Measurement': 'AdcCorrectionMeasEvent',
            'ADC Offset': 'AdcCorrectionOffsetEvent',
            'ADC Measurement + Offset': 'AdcCorrectionMeasOffsetEvent'
        }

        if graph_category == 'correction_image':
            data = df_dict['AdcCorrectionMeasOffsetEvent']
        else:
            data_index = data_dict[param['correction_component']['adc_correction']['selected']]
            data = df_dict[data_index]

        cpvs_map = param['cp_vs']
        select_plate = param['mean_deviation']
        adc_correction_item = param['correction_component']['adc_correction']

        dx_table = list()
        dy_table = list()
        cp_name_list = ['cp1', 'cp12d', 'cp1d', 'cp21d', 'cp2', 'cp23d', 'cp3d', 'cp32d', 'cp3']
        vs_name_list = ['vs1l', 'vs2l', 'vs3l', 'vs4l', 'vsc', 'vs4r', 'vs3r', 'vs2r', 'vs1r']
        correction_data_list = ['dr', 'my', 'yaw', 'mx', 'arc', 'x_mag_pitch', 'x_mag_roll', 'y_mag_pitch',
                                'y_mag_roll', 'i_mag_pitch', 'i_mag_roll', 'mag_tilt_mx', 'mag_tilt_arc']

        glass_id_map = dict()
        glass_graph_map = dict()
        base_vs_map = dict()
        r_map = dict()

        average_map_x = dict()
        average_map_y = dict()
        init_flg = True
        base_vs = 0
        arc_r = 0
        vs = 0
        arc_e = 0

        step_map = dict()
        time_map = dict()
        glass_id_check = ''
        lot_id_temp = ''
        lot_id_count = 0

        for index_int in range(len(data)):
            index = str(index_int)
            if lot_id_temp != data[index_int]['lot_id']:
                lot_id_count += 1
                lot_id_temp = data[index_int]['lot_id']

            plate = data[index_int]['plate']
            time_id = data[index_int]['time_id']
            glass_id = data[index_int]['glass_id']
            data_map = dict()
            data_map['time_id'] = time_id
            data_map['plate'] = plate
            data_map['glass_id'] = glass_id

            for data_index in correction_data_list:
                correction_comp_list = ['dr', 'my', 'yaw', 'mx', 'arc']
                if (graph_category == 'correction_component') & (data_index in correction_comp_list):
                    if adc_correction_item[data_index] == False:
                        data_map[data_index] = 0
                    else:
                        data_map[data_index] = data[index_int][data_index]

                else:
                    data_map[data_index] = data[index_int][data_index]

            data_map['logical_pos_x'] = float(data[index_int]['logical_posx']) * app_config.NM_TO_MM
            data_map['logical_pos_y'] = float(data[index_int]['logical_posy']) * app_config.NM_TO_MM
            msy = data[index_int]['msy']
            step = data[index_int]['step']

            if glass_id_check != glass_id:
                step_map = dict()
                time_map = dict()
                glass_id_check = glass_id
                if glass_id in glass_id_map:
                    time_map = glass_id_map[data]
                else:
                    time_map = dict()
            msy_map = dict()
            if step in step_map:
                msy_map = step_map[step]
            else:
                msy_map = dict()
                step_map[step] = msy_map
                average_list_x = None
                average_list_y = None
                average_map_x[step] = average_list_x
                average_map_y[step] = average_list_y

            msy_map[msy] = data_map
            time_map[time_id] = step_map
            glass_id_map[glass_id] = time_map
            if init_flg:
                arc_r = data[index_int]['arc_r']
                base_vs = data[index_int]['base_vs']
                vs = data[index_int]['vs']

                init_flg = False
                glass_id_check = data[index_int]['glass_id']

                arc_e = arc_r - math.sqrt(arc_r ** 2 - (base_vs / 2) ** 2)
                dx_table = correction_param.sensitivity_table['mode_' + str(data[index_int]['il_mode']) + '_x']
                dy_table = correction_param.sensitivity_table['mode_' + str(data[index_int]['il_mode']) + '_y']

            ch_glass_map = dict()
            ch_time_map = dict()

            if glass_id in glass_graph_map:
                if time_id in glass_graph_map[glass_id]:
                    if step in glass_graph_map[glass_id][time_id]:
                        continue
                    else:
                        glass_graph_map[glass_id][time_id][step] = dict()
                else:
                    ch_time_map[step] = dict()
                    glass_graph_map[glass_id][time_id] = ch_time_map
            else:
                ch_time_map[step] = dict()
                ch_glass_map[time_id] = ch_time_map
                glass_graph_map[glass_id] = ch_glass_map

        step_index_list = list(cpvs_map['cp1'].keys())
        for step_index in step_index_list:
            step_vs_map = dict()
            for cp_index in cp_name_list:
                cp_data = cpvs_map[cp_index][step_index]
                result = cp_data - (math.sqrt(arc_r ** 2 - (vs / 2) ** 2) - math.sqrt(arc_r ** 2 - (base_vs / 2) ** 2))
                step_vs_map[cp_index] = result
                base_vs_map[step_index] = step_vs_map

        for step_index in step_index_list:
            cp_map = dict()
            for cp_index in cp_name_list:
                step_cp_map = dict()
                cp_data = cpvs_map[cp_index][step_index]
                for vs_index in vs_name_list:
                    vs_data = cpvs_map[vs_index][step_index]
                    result = cp_data - (
                            math.sqrt(arc_r ** 2 - vs_data ** 2) - math.sqrt(arc_r ** 2 - (base_vs / 2) ** 2))
                    step_cp_map[vs_index] = result
                cp_map[cp_index] = step_cp_map
            r_map[step_index] = cp_map

        glass_id_list = list(glass_id_map.keys())
        for glass_result in glass_id_list:
            time_list = list(glass_id_map[glass_result].keys())
            for time_result in time_list:
                step_list = list(glass_id_map[glass_result][time_result].keys())
                for step_result in step_list:
                    list_cnt = 0
                    plate_info = -1
                    cp_list = list(r_map[step_result].keys())
                    for cp_result in cp_list:
                        vs_list = list(r_map[step_result][cp_result].keys())
                        for vs_result in vs_list:
                            yd_data = r_map[step_result][cp_result][vs_result]
                            msy_list = list(glass_id_map[glass_result][time_result][step_result])
                            msy_keys = []
                            diff = None
                            keep_diff = None
                            keep_cnt = 0
                            cnt = 0
                            keep_msy = 0
                            for msy_result in msy_list:
                                msy_keys.append(msy_result)
                                if yd_data <= msy_result:
                                    break
                                if yd_data >= 0:
                                    diff = msy_result - abs(yd_data)
                                else:
                                    diff = msy_result + abs(yd_data)

                                diff = abs(diff)

                                if keep_diff == None:
                                    keep_diff = diff
                                else:
                                    if keep_diff > diff:
                                        keep_diff = diff
                                        keep_cnt = cnt
                                        keep_msy = msy_result
                                    else:
                                        break
                                cnt += 1

                            calc_data_list = dict()
                            for calc_index in correction_data_list:
                                calc_data_list[calc_index] = self.calc_data(glass_id_map, yd_data, glass_result,
                                                                            time_result,
                                                                            step_result, msy_keys[keep_cnt],
                                                                            msy_keys[keep_cnt + 1],
                                                                            calc_index)

                            disp_vs = cpvs_map[vs_result][step_result]
                            disp_cp = cpvs_map[cp_result][step_result]

                            x_calc = calc_data_list['dr'] + (calc_data_list['mx'] * disp_vs)
                            vs_data = base_vs_map[step_result][cp_result]

                            y_calc = calc_data_list['my'] + (
                                    disp_vs * 1000 * (math.tan(calc_data_list['yaw'] / 180 / 3600 * math.pi))) + (
                                             vs_data - yd_data) * calc_data_list['arc']

                            logical_p_x = glass_id_map[glass_result][time_result][step_result][keep_msy][
                                'logical_pos_x']
                            logical_p_y = glass_id_map[glass_result][time_result][step_result][keep_msy][
                                'logical_pos_y']
                            plate = glass_id_map[glass_result][time_result][step_result][keep_msy]['plate']
                            glass_id = glass_id_map[glass_result][time_result][step_result][keep_msy]['glass_id']

                            if disp_vs == 0:
                                if (graph_category == 'correction_component') & (
                                        adc_correction_item['mag tilt dx'] == False):
                                    mag_tilt_x = 0
                                else:
                                    x_mag_pitch = dx_table[0][6] * calc_data_list['x_mag_pitch']
                                    x_mag_roll = dx_table[1][6] * calc_data_list['x_mag_roll']
                                    y_mag_pitch = dx_table[2][6] * calc_data_list['y_mag_pitch']
                                    y_mag_roll = dx_table[3][6] * calc_data_list['y_mag_roll']
                                    i_mag_pitch = dx_table[4][6] * calc_data_list['i_mag_pitch']
                                    i_mag_roll = dx_table[5][6] * calc_data_list['i_mag_roll']
                                    mag_tilt_x = x_mag_pitch + x_mag_roll + y_mag_pitch + y_mag_roll + i_mag_pitch + i_mag_roll
                                if (graph_category == 'correction_component') & (
                                        adc_correction_item['mag tilt dy'] == False):
                                    mag_tilt_y = 0
                                else:
                                    x_mag_pitch = dy_table[0][6] * calc_data_list['x_mag_pitch']
                                    x_mag_roll = dy_table[1][6] * calc_data_list['x_mag_roll']
                                    y_mag_pitch = dy_table[2][6] * calc_data_list['y_mag_pitch']
                                    y_mag_roll = dy_table[3][6] * calc_data_list['y_mag_roll']
                                    i_mag_pitch = dy_table[4][6] * calc_data_list['i_mag_pitch']
                                    i_mag_roll = dy_table[5][6] * calc_data_list['i_mag_roll']
                                    mag_tilt_y = x_mag_pitch + x_mag_roll + y_mag_pitch + y_mag_roll + i_mag_pitch + i_mag_roll
                            else:
                                if (graph_category == 'correction_component') & (
                                        adc_correction_item['mag tilt dx'] == False):
                                    mag_tilt_x = 0
                                else:
                                    x_mag_pitch = self.get_sensitivity_data_calc(dx_table, 0, disp_vs) * calc_data_list[
                                        'x_mag_pitch']
                                    x_mag_roll = self.get_sensitivity_data_calc(dx_table, 1, disp_vs) * calc_data_list[
                                        'x_mag_roll']
                                    y_mag_pitch = self.get_sensitivity_data_calc(dx_table, 2, disp_vs) * calc_data_list[
                                        'y_mag_pitch']
                                    y_mag_roll = self.get_sensitivity_data_calc(dx_table, 3, disp_vs) * calc_data_list[
                                        'y_mag_roll']
                                    i_mag_pitch = self.get_sensitivity_data_calc(dx_table, 4, disp_vs) * calc_data_list[
                                        'i_mag_pitch']
                                    i_mag_roll = self.get_sensitivity_data_calc(dx_table, 5, disp_vs) * calc_data_list[
                                        'i_mag_roll']
                                    mag_tilt_x = disp_vs * calc_data_list[
                                        'mag_tilt_mx'] / base_vs + x_mag_pitch + x_mag_roll + y_mag_pitch + y_mag_roll + i_mag_pitch + i_mag_roll
                                if (graph_category == 'correction_component') & (
                                        adc_correction_item['mag tilt dy'] == False):
                                    mag_tilt_y = 0
                                else:
                                    x_mag_pitch = self.get_sensitivity_data_calc(dy_table, 0, disp_vs) * calc_data_list[
                                        'x_mag_pitch']
                                    x_mag_roll = self.get_sensitivity_data_calc(dy_table, 1, disp_vs) * calc_data_list[
                                        'x_mag_roll']
                                    y_mag_pitch = self.get_sensitivity_data_calc(dy_table, 2, disp_vs) * calc_data_list[
                                        'y_mag_pitch']
                                    y_mag_roll = self.get_sensitivity_data_calc(dy_table, 3, disp_vs) * calc_data_list[
                                        'y_mag_roll']
                                    i_mag_pitch = self.get_sensitivity_data_calc(dy_table, 4, disp_vs) * calc_data_list[
                                        'i_mag_pitch']
                                    i_mag_roll = self.get_sensitivity_data_calc(dy_table, 5, disp_vs) * calc_data_list[
                                        'i_mag_roll']
                                    mag_tilt_y = (disp_cp - yd_data) * calc_data_list[
                                        'mag_tilt_arc'] / arc_e + x_mag_pitch + x_mag_roll + y_mag_pitch + y_mag_roll + i_mag_pitch + i_mag_roll

                            base_pos_x = logical_p_x + disp_vs
                            base_pos_y = logical_p_y + disp_cp

                            measurement_x = (x_calc + mag_tilt_x)
                            measurement_y = (y_calc + mag_tilt_y)

                            insert_map = glass_graph_map[glass_result][time_result][step_result]
                            base_x_list = list()
                            base_y_list = list()
                            measurement_x_list = list()
                            measurement_y_list = list()

                            if 'base_x' not in insert_map:
                                insert_map['base_x'] = base_x_list
                            if 'base_y' not in insert_map:
                                insert_map['base_y'] = base_y_list
                            if 'measurement_x' not in insert_map:
                                insert_map['measurement_x'] = measurement_x_list
                            if 'measurement_y' not in insert_map:
                                insert_map['measurement_y'] = measurement_y_list
                            if 'plate' not in insert_map:
                                insert_map['plate'] = plate
                            if 'glass_id' not in insert_map:
                                insert_map['glass_id'] = glass_id

                            base_x_list = insert_map['base_x']
                            base_x_list.append(base_pos_x)
                            base_y_list = insert_map['base_y']
                            base_y_list.append(base_pos_y)
                            measurement_x_list = insert_map['measurement_x']
                            measurement_x_list.append(measurement_x)
                            measurement_y_list = insert_map['measurement_y']
                            measurement_y_list.append(measurement_y)

                            plate_info = plate
                            list_cnt += 1

                    if (len(select_plate) != 0) & (plate_info in select_plate):
                        average_list_x = average_map_x[step_result]
                        average_list_y = average_map_y[step_result]
                        if average_list_x == None:
                            average_list_x = dict()
                            for index in range(0, list_cnt):
                                average_list_x[index] = 0
                        if average_list_y == None:
                            average_list_y = dict()
                            for index in range(0, list_cnt):
                                average_list_y[index] = 0
                        temp_map = glass_graph_map[glass_result][time_result][step_result]
                        measurement_map_x = temp_map['measurement_x']
                        measurement_map_y = temp_map['measurement_y']
                        for index in range(len(measurement_map_x)):
                            average_list_x[index] = average_list_x[index] + measurement_map_x[index]
                        for index in range(len(measurement_map_y)):
                            average_list_y[index] = average_list_y[index] + measurement_map_y[index]
                        average_map_x[step_result] = average_list_x
                        average_map_y[step_result] = average_list_y

        if len(select_plate) != 0:
            for glass_mean_result in glass_id_list:
                time_list = list(glass_id_map[glass_mean_result].keys())
                for time_mean_result in time_list:
                    step_list = list(glass_id_map[glass_mean_result][time_mean_result].keys())
                    for step_mean_result in step_list:
                        average_list_x = average_map_x[step_mean_result]
                        average_list_y = average_map_y[step_mean_result]
                        for average_x_index in range(len(average_list_x)):
                            average_list_x[average_x_index] = average_list_x[average_x_index] / (
                                    len(select_plate) * lot_id_count)
                        for average_y_index in range(len(average_list_y)):
                            average_list_y[average_y_index] = average_list_y[average_y_index] / (
                                    len(select_plate) * lot_id_count)
                        temp_map = glass_graph_map[glass_mean_result][time_mean_result][step_mean_result]
                        measurement_x_list = temp_map['measurement_x']
                        measurement_y_list = temp_map['measurement_y']
                        for mesurement_x_index in range(len(measurement_x_list)):
                            measurement_x_list[mesurement_x_index] = measurement_x_list[mesurement_x_index] - \
                                                                     average_list_x[mesurement_x_index]
                        for mesurement_y_index in range(len(measurement_y_list)):
                            measurement_y_list[mesurement_y_index] = measurement_y_list[mesurement_y_index] - \
                                                                     average_list_y[mesurement_y_index]
        # 입력 데이터의 Step이 역으로 6-> 1로 된경우에 1->6 순으로 정렬
        # result_map = dict()
        # sort_glass_list = glass_graph_map.keys()
        # for sort_glass_index in sort_glass_list:
        #     result_map[sort_glass_index] = dict()
        #     sort_time_list = glass_graph_map[sort_glass_index]
        #     for sort_time_index in sort_time_list:
        #         result_map[sort_glass_index][sort_time_index] = dict()
        #         sort_step_list = list(glass_graph_map[sort_glass_index][sort_time_index].keys())
        #         sort_step_list.sort()
        #         for sort_step_index in sort_step_list:
        #             result_map[sort_glass_index][sort_time_index][sort_step_index] = \
        #             glass_graph_map[sort_glass_index][sort_time_index][sort_step_index]
        # return result_map

        return glass_graph_map

    def calc_data(self, glass_id_map, yd_data, glass_id, time_id, step, msy_key, msy_key_2nd, target):
        msy_data = glass_id_map[glass_id][time_id][step][msy_key][target]
        msy_data_2nd = glass_id_map[glass_id][time_id][step][msy_key_2nd][target]
        msy_data_diff = msy_data - msy_data_2nd
        msy_key_diff = msy_key - msy_key_2nd
        msy_diff = msy_data_diff / msy_key_diff
        yd_calc = yd_data - msy_key_2nd

        result = msy_data_2nd + (msy_diff * yd_calc)
        mm_list = ['mx', 'arc']
        um_list = ['x_mag_pitch', 'x_mag_roll', 'y_mag_pitch', 'y_mag_roll', 'i_mag_pitch', 'i_mag_roll', 'mag_tilt_mx',
                   'mag_tilt_arc']
        if target in mm_list:
            result = result * app_config.NM_TO_MM
        elif target in um_list:
            result = result
        else:
            result = result * app_config.NM_TO_UM

        return result

    def get_sensitivity_data_calc(self, table, x, disp_vs):
        pow_cnt = 6
        result = 0
        for index in range(len(table[x])):
            result += (table[x][index]) * (disp_vs ** pow_cnt)
            pow_cnt -= 1
        return result

    def make_correction_file(self, rid):
        correction_conveter = CorrectionConverter(rid)
        correction_conveter.exec_impl()

    def create_expo_width(self, data_list):
        logger.info("Correction createExpoWidthJson in %d", len(data_list))
        dict_list = []
        step_list = []
        # Stepを先に集計
        for source in data_list:
            # Step
            step = source.get('step', None)
            step_list.append(step)
        # 重複を削除
        step_list = set(step_list)
        check_step_list = []
        for step in step_list:
            for source in data_list:
                # Step
                step = source.get('step', None)
                # Job内のStepはどのLotIDでも同じになるため、1回のみチェックする
                if step not in check_step_list:
                    # チェック済みリストに追加
                    check_step_list.append(step)
                    # # tool_nm
                    # tool_nm = data_row['_index'].split('.')[4]
                    # Job
                    job = source.get('job', None)
                    # 露光幅を取得
                    expo_left = source.get('expo_left', None)
                    expo_right = source.get('expo_right', None)
                    cp1 = source.get('cp1', None)
                    cp1d = source.get('cp1d', None)
                    cp2 = source.get('cp2', None)
                    cp3d = source.get('cp3d', None)
                    cp3 = source.get('cp3', None)

                    dict_list.append({
                        # 'tool_nm': tool_nm,
                        'job': job,
                        'step': step,
                        'expo_left': expo_left,
                        'expo_right': expo_right,
                        'cp1': cp1,
                        'cp1d': cp1d,
                        'cp2': cp2,
                        'cp3d': cp3d,
                        'cp3': cp3
                    })
        logger.info("Correction createExpoWidthJson out")

        cp_vs_dict = {'cp1': dict(), 'cp12d': dict(), 'cp1d': dict(),
                      'cp21d': dict(), 'cp2': dict(), 'cp23d': dict(),
                      'cp3d': dict(), 'cp32d': dict(), 'cp3': dict(),
                      'vs1l': dict(), 'vs2l': dict(), 'vs3l': dict(),
                      'vs4l': dict(), 'vsc': dict(), 'vs4r': dict(),
                      'vs3r': dict(), 'vs2r': dict(), 'vs1r': dict() }

        for item in dict_list:
            expo_left = float(item['expo_left'])
            expo_right = float(item['expo_right'])
            cp1 = item['cp1']
            cp1d = item['cp1d']
            cp2 = item['cp2']
            cp3d = item['cp3d']
            cp3 = item['cp3']
            step = item['step']

            # 露光幅の範囲を算出
            result = expo_left - expo_right
            # 符号を反転
            if result < 0:
                result = result * -1
            # 画面と単位を揃える
            result = result / 1.0e6
            # 等間隔の幅を設定
            vs_width = result / 8

            cp_vs_dict['cp1'][step] = cp1
            cp_vs_dict['cp12d'][step] = (cp1 + cp1d) / 2
            cp_vs_dict['cp1d'][step] = cp1d
            cp_vs_dict['cp21d'][step] = (cp1d + cp2) /2
            cp_vs_dict['cp2'][step] = cp2
            cp_vs_dict['cp23d'][step] = (cp2 + cp3d) / 2
            cp_vs_dict['cp3d'][step] = cp3d
            cp_vs_dict['cp32d'][step] = (cp3d + cp3) / 2
            cp_vs_dict['cp3'][step] = cp3

            expo_left = expo_left / 1.0e6
            cp_vs_dict['vs1l'][step] = expo_left
            cp_vs_dict['vs2l'][step] = expo_left + (vs_width * 1)
            cp_vs_dict['vs3l'][step] = expo_left + (vs_width * 2)
            cp_vs_dict['vs4l'][step] = expo_left + (vs_width * 3)
            cp_vs_dict['vsc'][step] = expo_left + (vs_width * 4)
            cp_vs_dict['vs4r'][step] = expo_left + (vs_width * 5)
            cp_vs_dict['vs3r'][step] = expo_left + (vs_width * 6)
            cp_vs_dict['vs2r'][step] = expo_left + (vs_width * 7)
            cp_vs_dict['vs1r'][step] = expo_right / 1.0e6

        return cp_vs_dict