import logging
import pandas as pd
import traceback

from dao.utils import get_db_config
from sqlalchemy import create_engine


from service.tact.service_tact_base import ServiceTactBase
from common.utils.response import ResponseForm
from config import app_config
from dao.dao_base import DAOBaseClass

logger = logging.getLogger(app_config.LOG)


class ServiceTactSettings(ServiceTactBase):
    log_name = app_config.STATUSMONIOTOR_LOGNAME
    prediction = app_config.PREDICTION_LOGNAME

    def __init__(self):
        super().__init__()

        self.root_path = app_config.root_path
        self.conv_path = app_config.CNV_RESULT_PATH
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.log_name
        }

    def file_check(self, files):
        """

        :param files: [files]
        :return: {'log_name': [fids]}
        """
        return ResponseForm(res=True)

    def convert(self, logs):
        """

        :param logs: { 'log_name': [fids] }
        :return:
        """
        return ResponseForm(res=True, data=self.form['id'])

    def upload_settings(self, table, files, primary_pu_name=None):
        """
        :param table:
        :param files: [files]
        :return: {'log_name': [fids]}
        """
        table_dict = {
            "plate_tact": "tact_plate_tact",
            "plate_event": "tact_plate_tact_event",
            "plate_detail": "tact_plate_detail_tact",
            "name_data": "tact_name_dat",
            "primary_pu_item": "tact_primary_pu_item",
            "primary_pu": "tact_primary_pu",
            "ref_pu": "tact_ref_pu"
        }
        clumns_dict = {
            "plate_tact": ["category", "display_order"],
            "plate_event": ["event_kind"],
            "plate_detail": ["event", "event_start", "event_end", "category", "display"],
            "name_data": ["puid", "name"],
            "primary_pu": ["pu_name"],
            "primary_pu_item": ["puid", "name", "level"],
            "ref_pu": ["puid", "primary_pu_name"]
        }
        dao = DAOBaseClass()

        config = get_db_config()
        engine = create_engine(f"sqlite:///{config['dbpath']}")
        backup_df = pd.DataFrame()

        exist_f = False
        primary_pu_id = None

        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')
        if table == "primary_pu":
            primary_pu_list = dao.fetch_all(table=table_dict[table])['pu_name'].tolist()
            if primary_pu_name not in primary_pu_list:
                pu_name_dict = {"pu_name": primary_pu_name}
                id_resp = dao.insert(data=pu_name_dict, rtn_id=True, table=table_dict[table])
                primary_pu_id = id_resp.data
                if primary_pu_id is None:
                    return ResponseForm(res=False, msg='Primary Pu Name is duplicated.')
            else:
                primary_pu_id = dao.fetch_one(table=table_dict[table], args={'select': 'id', 'where': f"pu_name='{primary_pu_name}'"})[0]
                exist_f = True

        try:
            df_dict = dict()
            for file in files:
                if table == 'name_data':
                    pu_list = list()
                    name_list = list()
                    temp_list = self.read_file_data(table, file)
                    for data in temp_list:
                        if len(data) == 0:
                            continue
                        pu_list.append(data.strip().replace('"', "").split(maxsplit=1)[0])
                        name_list.append(data.strip().replace('"', "").split(maxsplit=1)[1])
                    df = pd.DataFrame(zip(pu_list, name_list))
                    df.columns = clumns_dict[table]

                elif table == 'primary_pu':
                    df = self.read_file_data(table, file)
                    item_table = 'primary_pu_item'
                    df.columns = clumns_dict[item_table]
                    df['primary_pu_id'] = primary_pu_id

                else:
                    df = self.read_file_data(table, file)
                    df.columns = clumns_dict[table]

                df_dict[file.filename] = df

            total_df = pd.concat(df_dict)

            if table == "primary_pu":
                table = 'primary_pu_item'
                if exist_f is True:
                    backup_df = dao.fetch_all(table=table_dict[table], args={'where': f'"primary_pu_id" = "{primary_pu_id}"'})
                    backup_df = backup_df.drop(columns=['id'])
                    dao.delete(table=table_dict[table], where_dict={'primary_pu_id': primary_pu_id})
            else:
                backup_df = dao.fetch_all(table=table_dict[table])
                backup_df = backup_df.drop(columns=['id'])
                sql = f"DELETE FROM {table_dict[table]}"
                dao.cursor.execute(sql)
                sql = f"UPDATE sqlite_sequence SET seq=0 where name='{table_dict[table]}'"
                dao.cursor.execute(sql)
                dao.connect.commit()

            try:
                total_df.to_sql(table_dict[table], engine, if_exists='append', index=False)

            except:
                if table == 'primary_pu' and primary_pu_name is not None:
                    dao.delete(table=table_dict[table], where_dict={'pu_name': primary_pu_name})
                elif table == 'primary_pu_item' and primary_pu_id is not None:
                    dao.delete(table=table_dict[table], where_dict={'primary_pu_id': primary_pu_id})
                    backup_df.to_sql(table_dict[table], engine, if_exists='append',  index=False)
                else:
                    sql = f"DELETE FROM {table_dict[table]}"
                    dao.cursor.execute(sql)
                    sql = f"UPDATE sqlite_sequence SET seq=0 where name='{table_dict[table]}'"
                    dao.cursor.execute(sql)
                    dao.connect.commit()
                    backup_df.to_sql(table_dict[table], engine, if_exists='append', index=False)


        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            if table == 'primary_pu' and primary_pu_name is not None:
                dao.delete(table=table_dict[table], where_dict={'pu_name': primary_pu_name})
            elif table == 'primary_pu_item' and primary_pu_id is not None:
                dao.delete(table=table_dict[table], where_dict={'primary_pu_id': primary_pu_id})
                backup_df.to_sql(table_dict[table], engine, if_exists='append', index=False)
            else:
                sql = f"DELETE FROM {table_dict[table]}"
                dao.cursor.execute(sql)
                sql = f"UPDATE sqlite_sequence SET seq=0 where name='{table_dict[table]}'"
                dao.cursor.execute(sql)
                dao.connect.commit()
                backup_df.to_sql(table_dict[table], engine, if_exists='append', index=False)
            return ResponseForm(res=False, msg=str(e))

        return ResponseForm(res=True)

    def read_file_data(self, tab, file):
        encoding_list = ['shift_jis', 'cp932', 'UTF8']
        result_df = pd.DataFrame()
        result_list = list()
        if tab == 'name_data':
            for encode in encoding_list:
                try:
                    result_list = str(file.stream.read(), encode).splitlines()
                    break
                except:
                    file.seek(0)
                    continue
            return result_list
        else:
            for encode in encoding_list:
                try:
                    result_df = pd.read_csv(file, index_col=False, encoding=encode)
                    break
                except:
                    file.seek(0)
                    continue

            return result_df

    def update_setting(self, table, update_data, primary_pu_name=None):
        table_dict = {
            "plate_tact": "tact.plate_tact",
            "plate_event": "tact.plate_tact_event",
            "plate_detail": "tact.plate_detail_tact",
            "name_data": "tact.name_dat",
            "primary_pu_item": "tact.primary_pu_item",
            "primary_pu": "tact.primary_pu",
            "ref_pu": "tact.ref_pu"
        }
        columns_dict = {
            "plate_tact": "category, display_order",
            "plate_event": "event_kind",
            "plate_detail": "event, event_start, event_end, category, display",
            "name_data": "puid, name",
            "primary_pu": "pu_name",
            "primary_pu_item": "puid, name, level, primary_pu_id",
            "ref_pu": "puid, primary_pu_name"
        }
        try:
            dao = DAOBaseClass()
            update_item_list = list()
            add_item_list = list()
            id_list = list()
            if primary_pu_name is not None:
                table = "primary_pu_item"

            if table == "primary_pu_item":
                temp = primary_pu_name
                primary_pu_df = dao.fetch_all(table=table_dict['primary_pu'])
                primary_pu_id = primary_pu_df.loc[(primary_pu_df['pu_name'] == primary_pu_name)]['id'].tolist()[0]
                for item in update_data:
                    if item['id'] is None:
                        add_item_list.append(item)
                    else:
                        id_list.append(item['id'])
                        update_item_list.append(item)

                for item in update_item_list:
                    id = item.pop('id')
                    resp_form = dao.update(table=table_dict[table],
                                           set={**item},
                                           where={'id': id})
                    if not resp_form.res:
                        return resp_form

                f_setting_df = dao.fetch_all(table=table_dict[table], args={'select': f'id, {columns_dict[table]}'})
                not_included_df = f_setting_df[~f_setting_df['id'].isin(id_list)]
                for i in range(len(not_included_df)):
                    dao.delete(table=table_dict[table], where_dict={'id': not_included_df['id'].values[i]})

                for item in add_item_list:
                    item.pop('id')
                    item['primary_pu_id'] = str(primary_pu_id)
                    resp_form = dao.insert(data={**item}, rtn_id=True, table=table_dict[table])

                    if not resp_form.res:
                        return resp_form

            elif table == 'primary_pu':
                for item in update_data:
                    if item['id'] is None:
                        add_item_list.append(item)
                    else:
                        id_list.append(item['id'])
                        update_item_list.append(item)
                for item in add_item_list:
                    item.pop('id')
                    resp_form = dao.insert(data={**item}, rtn_id=True, table=table_dict[table])

                    if not resp_form.res:
                        return resp_form
            else:
                for item in update_data:
                    if item['id'] is None:
                        add_item_list.append(item)
                    else:
                        id_list.append(item['id'])
                        update_item_list.append(item)

                for item in update_item_list:
                    id = item.pop('id')
                    resp_form = dao.update(table=table_dict[table],
                                           set={**item},
                                           where={'id': id})
                    if not resp_form.res:
                        return resp_form

                f_setting_df = dao.fetch_all(table=table_dict[table], args={'select': f'id, {columns_dict[table]}'})
                not_included_df = f_setting_df[~f_setting_df['id'].isin(id_list)]
                for i in range(len(not_included_df)):
                    dao.delete(table=table_dict[table], where_dict={'id': not_included_df['id'].values[i]})

                for item in add_item_list:
                    item.pop('id')
                    resp_form = dao.insert(data={**item}, rtn_id=True, table=table_dict[table])

                    if not resp_form.res:
                        return resp_form

            return ResponseForm(res=True)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))
