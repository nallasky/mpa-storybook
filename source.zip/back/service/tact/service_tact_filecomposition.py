from datetime import datetime

class TsFileComposition(object):
    """
    ログファイルの形態を検証するためのクラス
    """
    # TS(Memory)ログファイル名リスト(Lower)
    tsmem_file_list = ['main', 'perl', 'scan']

    # TS(Memory)
    is_ts_memory = 'copy'
    # imported data
    is_ts_imported = 'tsimport'
    # LogServerログ
    is_log_server = 'logserver'
    # 結果グループ
    type_group = (is_ts_imported, is_ts_memory, is_log_server)

    # 試す文字エンコード
    _encoding_list = ['utf_8', 'cp932', 'euc_jp']

    # 最初のデータ行としてチェックする行数
    # - もしかしたらコメント行や空行ある？とか色々思って数行見ることにした
    _check_start_limit = 5
    _ts_log_column_count = 13

    # 日時フォーマット
    _datetime_format = '%Y/%m/%d %H:%M:%S.%f'

    def check_logfiles(self, files, logtype):
        """
        log file verify

        :param files: input log files
        :return: type of log
        """
        if logtype == "copy":
            p_type = self._ts_memory_log(files)
            if p_type is self.is_ts_memory:
                return True
        elif logtype == "logserver":
            p_type = self._log_server_log(files)
            if p_type is self.is_log_server:
                return True
        else:
            p_type = self._import_data(files)
            if p_type is self.is_ts_imported:
                return True

        return False

    @classmethod
    def search_target(cls, req_files):
        """
        指定パスについてTact解析用ファイル種別を調べる

        :param req_files: log files for determine log type.
        :return: type
        """

        p_type = cls._ts_memory_log(req_files)
        if p_type is not None:
            return p_type

        p_type = cls._log_server_log(req_files)
        if p_type is not None:
            return p_type

        p_type = cls._import_data(req_files)
        if p_type is not None:
            return p_type

        return None

    @classmethod
    def _import_data(cls, files):
        """
        バックアップしたログを再利用する

        :param files: input log files
        :return: type of log
        """
        for file in files:
            imp = cls._check_importfile(file)
            if imp is None:
                return None

        return cls.is_ts_imported

    @classmethod
    def _check_importfile(cls, file):
        # fixme -
        # 결과 테이블을 통체로 저장하고 다시 읽을 때도 그대로 사용 할 듯 ...
        res = None
        encoding_list = cls._encoding_list
        for idx, encoding in enumerate(encoding_list):
            try:
                file.seek(0)
                res = cls._get_history_dump(file, encoding)
                if idx != 0:
                    # 成功したencodingを次回最初に試す
                    cls._encoding_list.remove(encoding)
                    cls._encoding_list = [encoding] + cls._encoding_list
                break
            except:
                continue

        return res

    @classmethod
    def _get_history_dump(cls):

        return None

    @classmethod
    def _ts_memory_log(cls, files):
        """
        pathがTS(Memory)ファイルそのものor格納フォルダかを調べる

        :param files: file list uploaded
        :return: True/False - whether TS(Memory)ファイル or not
        """
        for file in files:
            #ファイル名中には main/scan/perlの中に一つの文字列が含まれていなければならない。
            if True not in [file.filename.lower().find(x) >= 0 for x in cls.tsmem_file_list]:
                return None

            st, ed = cls.get_csvcount(file)
            if None in [st, ed]:
                return None

        return cls.is_ts_memory

    @classmethod
    def get_csvcount(cls, file):
        """
        pathがTS(Memory)ファイルそのものor格納フォルダかを調べる

        :param files: file list uploaded
        :return: dt_st, dt_ed - 最初 /最後の確認結果
        """
        st, ed = None, None

        encoding_list = cls._encoding_list
        for idx, encoding in enumerate(encoding_list):
            try:
                file.seek(0)
                st, ed = cls._get_csvcount(file, encoding)
                if idx != 0:
                    # 成功したencodingを次回最初に試す
                    cls._encoding_list.remove(encoding)
                    cls._encoding_list = [encoding] + cls._encoding_list
                break
            except:
                continue

        return st, ed

    @classmethod
    def _get_csvcount(cls, file, encoding):
        """
        ts mem logフォーマットチェック

        :param files: log file
        :encoding: kind of encoding
        :return: checked - verifying log format
        """
        st, ed = None, None
        limit = 0
        readfile = file.readlines()
        # 5line check
        for read_line in readfile:
            line = read_line.decode(encoding=encoding).strip()
            if line == '' or line.startswith('#'):
                continue
            items = line.split(',')
            if len(items) != cls._ts_log_column_count or '' in items:
                break
            limit += 1
            if limit > cls._check_start_limit:
                st = True
                break

        limit = 0
        tail_lines = readfile[-5:]
        for line in reversed(tail_lines):
            items = line.decode(encoding=encoding).strip().split(',')
            if len(items) != cls._ts_log_column_count or '' in items:
                break
            limit += 1
            if limit >= cls._check_start_limit:
                ed = True
                break

        return st, ed

    @classmethod
    def _log_server_log(cls, files):
        """
        LogServerログファイルで構成されたfileであるかを再帰的に調べる

        :param file: log files
        :return: True / False
        """
        for file in files:
            st, ed = cls.get_period(file)
            if None in [st, ed]:
                return None

        return cls.is_log_server

    @classmethod
    def get_period(cls, file):
        """
        pathファイルの開始/終了タイムスタンプ/byte数を取得する
        - タイムスタンプ情報を取得できなかった場合、(None, None, 0) が返る。

        :param str file: ファイルフルパス
        :rtype: tuple
        :return: 開始datetime, 終了datetime, byte数
        """
        dt_st, dt_ed = None, None

        encoding_list = cls._encoding_list
        for idx, encoding in enumerate(encoding_list):
            try:
                file.seek(0)
                dt_st, dt_ed = cls._get_period(file, encoding)
                if idx != 0:
                    # 成功したencodingを次回最初に試す
                    cls._encoding_list.remove(encoding)
                    cls._encoding_list = [encoding] + cls._encoding_list
                break
            except:
                continue

        return dt_st, dt_ed

    @classmethod
    def _get_period(cls, file, encoding):
        """
        pathファイルの開始/終了タイムスタンプ/byte数を取得する
        - タイムスタンプ情報を取得できなかった場合、(None, None, 0) が返る。

        :param str file: ファイルフルパス
        :param str encoding: エンコード
        :rtype: tuple
        :return: 開始datetime, 終了datetime, byte数
        """
        st = None
        ed = None

        limit = 0
        readfile = file.readlines()
        # 5line check
        for read_line in readfile:
            line = read_line.decode(encoding=encoding)
            items = line.split(',')
            st = cls._str2datetime(items[0])
            if st is not None:
                break
            limit += 1
            if limit > cls._check_start_limit:
                break
            else:
                return None, None

        tail_lines = readfile[-5:]
        for line in reversed(tail_lines):
            items = line.decode(encoding=encoding).split(',')
            ed = cls._str2datetime(items[0])
            if ed is not None:
                break
        else:
            # 終了行が無い
            return None, None

        return st, ed

    @classmethod
    def _str2datetime(cls, dt_str):
        """
        文字列TimeStampをdatetimeへ変換する

        :param str dt_str: 文字列TimeStamp
        :rtype: None|datetime
        :return: 変換結果
        """
        try:
            dt = datetime.strptime(dt_str, cls._datetime_format)
        except:
            dt = None
        return dt
