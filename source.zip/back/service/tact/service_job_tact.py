import numpy as np

class ServiceJobTact():
    job_tact_calc = {}

    def __init__(self, job_list):
        self.job_tact_calc = {}
        for job in job_list:
            if job not in self.job_tact_calc:
                self.job_tact_calc[job] = {}
            if 'lot' not in self.job_tact_calc[job]:
                self.job_tact_calc[job]['lot'] = {}
            if 'plate' not in self.job_tact_calc[job]:
                self.job_tact_calc[job]['plate'] = {}
            if 'lot_id' not in self.job_tact_calc[job]['lot']:
                self.job_tact_calc[job]['lot']['lot_id'] = list()
            if 'lot_id_block' not in self.job_tact_calc[job]['lot']:
                self.job_tact_calc[job]['lot']['lot_id_block'] = list()
            if 'calc' not in self.job_tact_calc[job]['lot']:
                self.job_tact_calc[job]['lot']['calc'] = list()

    def make_lot_data(self, job, lot_id_list, lot_id_block_list, calc_list):
        self.job_tact_calc[job]['lot']['lot_id_block'] = lot_id_block_list
        self.job_tact_calc[job]['lot']['calc'] = calc_list
        self.job_tact_calc[job]['lot']['lot_id'] = lot_id_list

    def make_plate_data(self, job, lot_id_block, lot_id, adc_fdc_list, plate_no_list, calc_list):
        if lot_id_block not in self.job_tact_calc[job]['plate']:
            self.job_tact_calc[job]['plate'][lot_id_block] = {}
        if 'lot_id' not in self.job_tact_calc[job]['plate'][lot_id_block]:
            self.job_tact_calc[job]['plate'][lot_id_block]['lot_id'] = None
        if 'plate_no' not in self.job_tact_calc[job]['plate'][lot_id_block]:
            self.job_tact_calc[job]['plate'][lot_id_block]['plate_no'] = list()
        if 'adc_fdc' not in self.job_tact_calc[job]['plate'][lot_id_block]:
            self.job_tact_calc[job]['plate'][lot_id_block]['adc_fdc'] = list()
        if 'calc' not in self.job_tact_calc[job]['plate'][lot_id_block]:
            self.job_tact_calc[job]['plate'][lot_id_block]['calc'] = list()

        self.job_tact_calc[job]['plate'][lot_id_block]['lot_id'] = lot_id
        self.job_tact_calc[job]['plate'][lot_id_block]['adc_fdc'] = adc_fdc_list
        self.job_tact_calc[job]['plate'][lot_id_block]['plate_no'] = plate_no_list
        self.job_tact_calc[job]['plate'][lot_id_block]['calc'] = calc_list

    def get_end_time(self, df):
        jobend_df = df[df['event'] == 'JOB End']
        if len(jobend_df):
            return jobend_df['log_time'].values[0]

        jobend_df = df[df['event'] == 'Lot End']
        if len(jobend_df):
            return jobend_df['log_time'].values[0]
        return df['log_time'].max()

    def calculate_job_tact(self, org_df):
        org_df['plate'] = org_df['plate'].astype(int)
        org_df['adc_fdc'] = org_df['adc_fdc'].astype(int)

        for job in org_df['job'].unique():
            job_df = org_df[org_df['job'] == job]

            lot_id_list = job_df.groupby('lot_id_block', sort=False)['lot_id'].apply(lambda x: x.unique().tolist()[0]).values.tolist()
            lot_id_block_diff = job_df.groupby('lot_id_block', sort=False)[['log_time', 'event']].apply(lambda x: self.get_end_time(x)) - job_df.groupby('lot_id_block', sort=False)[['log_time']].apply(np.nanmin)
            lot_id_block_list = lot_id_block_diff.index.tolist()
            calc_list = [lot_id_block_diff[index].total_seconds() for index in lot_id_block_diff.index.tolist()]

            self.make_lot_data(job, lot_id_list, lot_id_block_list, calc_list)

            for lot_id_block in job_df['lot_id_block'].unique():
                lot_id_block_df = job_df[job_df['lot_id_block'] == lot_id_block]

                lot_id = lot_id_block_df['lot_id'].unique().tolist()[0]
                adc_fdc_list = lot_id_block_df.groupby('plate', sort=False)['adc_fdc'].last().values.tolist()
                plate_diff = lot_id_block_df.groupby('plate', sort=False)[['log_time']].apply(np.nanmax) - lot_id_block_df.groupby('plate', sort=False)[['log_time']].apply(np.nanmin)
                plate_no_list = plate_diff.index.tolist()
                calc_list = [plate_diff[index].total_seconds() for index in plate_diff.index.tolist()]

                self.make_plate_data(job, lot_id_block, lot_id, adc_fdc_list, plate_no_list, calc_list)

    def get_job_tact(self):
        return self.job_tact_calc
