import os
import time
import pandas as pd
from dao import DAOBaseClass


class TsMemoryDumpLogConvert:
    """
    logserver logを ts memory dump logのポメッで変換処理
    """
    main_data = list()
    scan_data = list()
    perl_data = list()
    scan_dif = 0
    perl_dif = 0

    # 整列された入力ログデータ
    ord_pd_data = list()

    def get_tsmemlog_data(self, file_path):
        # ログファイルごとに処理
        return self._convert(file_path)

    def _convert(self, log_file):
        """
        LogserverLogを ts memory dump logで変換
        """
        start = time.time()
        # ログ変換のための PU NAME 情報テーブル取得
        self.pu_table = self.load_puid_table()

        if not os.path.exists(log_file):
            return ('main', None), ('scan', None), ('perl', None)

        f_encoding = self.check_encode_type(log_file)
        with open(log_file, 'r', encoding=f_encoding) as f:
            lines = f.readlines()
            for line in lines:
                self.parse_log_file(line.strip())

        print("convert detail parse log stamp: ", time.time() - start)

        if len(self.main_data) < 1 and len(self.scan_data) < 1 and len(self.perl_data) < 1:
            return ('main', None), ('scan', None), ('perl', None)

        # create Dataframe
        main_df = pd.DataFrame(self.main_data)
        scan_df = pd.DataFrame(self.scan_data)
        perl_df = pd.DataFrame(self.perl_data)
        # tagging pu type
        main_df['unit'] = 'main'
        scan_df['unit'] = 'scan'
        perl_df['unit'] = 'perl'

        return ('main', main_df), ('scan', scan_df), ('perl', perl_df)

    @classmethod
    def check_encode_type(cls, file):
        """
        ファイル読み取りエンコディング形式を確認
        """
        _encoding_list = ['cp932', 'utf_8', 'euc_jp']
        encoding = None
        buff = None
        for enc in _encoding_list:
            try:
                with open(file, encoding=enc) as r:
                    buff = r.read()
                encoding = enc
                break
            except:
                if enc == _encoding_list[-1]:
                    encoding = None
        return encoding

    def parse_log_file(self, line):
        """
        ファイルの一つのライン当たりパッシング処理
        """
        if line and not line.startswith('#') and line != '':
            # separate with comma
            sepa = line.strip().split(',')
            kind_pu = sepa[1].strip()

            # Main PU
            if kind_pu == 'MPUSTR':
                self._set_start_data(self.main_data, sepa)
            elif kind_pu == 'MPUEND':
                self._set_end_data(self.main_data, sepa)
            elif kind_pu == 'MPUERR':
                self._set_err_data(self.main_data, sepa)
            # Scan PU
            elif kind_pu == 'SPUSTR':
                self._set_start_data(self.scan_data, sepa)
            elif kind_pu == 'SPUEND':
                self._set_end_data(self.scan_data, sepa)
            elif kind_pu == 'SPUERR':
                self._set_err_data(self.scan_data, sepa)
            # Perl PU
            elif kind_pu == 'PPUSTR':
                self._set_start_data(self.perl_data, sepa)
            elif kind_pu == 'PPUEND':
                self._set_end_data(self.perl_data, sepa)
            elif kind_pu == 'PPUERR':
                self._set_err_data(self.perl_data, sepa)
            else:
                pass
                # print('Skip PU: ', kind_pu)
        else:
            print(line)

    def _get_puname(self, name):
        """
        PU IDにあたる名を得る
        """
        try:
            return self.pu_table[name]
        except:
            return None

    @staticmethod
    def _get_time(timestamp):
        """
        [日/時/分/超]までのデータだけ取得
        """
        fr = timestamp.rfind('/') + 1
        bl = timestamp.rfind('.')
        if bl == -1:
            dms = timestamp[fr:]
        else:
            dms = timestamp[fr:bl]
        return dms.replace(':', '').replace(' ', '')

    def _set_err_data(self, tag, data):
        """
        該当のユニットのエラー情報を登録
        """
        for i in range(len(tag), 0, -1):
            if tag[i - 1]['pu'] == data[8]:
                tag[i - 1]['net'] = data[15]
                tag[i - 1]['node'] = data[16]
                break

    def _set_start_data(self, tag, data):
        """
        各ユニットの開始を登録
        """
        puname = self._get_puname(data[8])
        if puname is None:
            return
        gtime = self._get_time(data[0])
        # pu, name, kick, call, cond, time, start, end, elapse, net, node, plate, step
        dataset = {'pu': data[8], 'name': puname, 'kick': data[10], 'call': data[11],
                   'cond': data[12], 'time': gtime, 'start': data[13], 'end': data[14],
                   'elapse': '00000000', 'net': data[15], 'node': data[16], 'plate': data[17], 'step': data[18]}
        tag.append(dataset)

    def _set_end_data(self, tag, data):
        """
        各ユニットの終了を登録
        """
        for i in range(len(tag), 0, -1):
            if tag[i - 1]['pu'] == data[8]:
                tag[i - 1]['cond'] = data[12]
                tag[i - 1]['end'] = data[14]
                tag[i - 1]['elapse'] = (int(data[14]) - int(tag[i - 1]['start'])) * 2  # calc elapse time
                break

    @classmethod
    def load_puid_table(cls):
        """
        get puname table from DB instead of name(like name(PU__H70).dat)
        """
        dao_base = DAOBaseClass()
        puname_table = dao_base.fetch_all(table='tact.name_dat', args={'select': 'puid, name'})\
            .set_index('puid').to_dict()['name']

        return puname_table



