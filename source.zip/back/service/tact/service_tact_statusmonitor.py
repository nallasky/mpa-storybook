import datetime
import logging
import os
import sqlite3
import time
import traceback
import json

import pandas as pd
import dateutil.parser as dparser

from common.utils import preprocessing
from common.utils.response import ResponseForm
from config import app_config
from controller.converter.converter import create_request_id
from dao.dao_base import DAOBaseClass
from dao.dao_file import FileDao
from dao.dao_job import DAOJob
from service.converter.convert_process import ConvertProcess
from service.tact.service_job_tact import ServiceJobTact
from service.tact.service_plate_detail_tact import ServicePlateDetailTact
from service.tact.service_plate_tact import ServicePlateTact
from service.tact.service_tact_base import ServiceTactBase

logger = logging.getLogger(app_config.LOG)


class ServiceStatusMonitor(ServiceTactBase):
    log_name = app_config.STATUSMONIOTOR_LOGNAME
    prediction = app_config.PREDICTION_LOGNAME
    category_name = "Tact"

    def __init__(self):
        super().__init__()

        self.root_path = app_config.root_path
        self.conv_path = app_config.CNV_RESULT_PATH
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.log_name
        }

    def file_check(self, files):
        """

        :param files: [files]
        :return: {'log_name': [fids]}
        """

        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        folder = os.path.join(self.root_path, self.log_name)
        if not os.path.exists(folder):
            os.makedirs(folder)

        data = dict()
        data[self.log_name] = list()

        for file in files:
            filename = file.filename
            f = None
            file_index = 1
            while f is None or os.path.exists(f):
                _filename = f'{file_index}{app_config.UPLOAD_FILE_SEPERATOR}{filename}'
                f = os.path.join(os.path.join(self.root_path, self.log_name), _filename)
                file_index += 1
            file.save(f)
            fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))
            if fid is None:
                logger.error('failed to store file info')
                return ResponseForm(res=False, msg='failed to store file info')

            data[self.log_name].append(fid)

        return ResponseForm(res=True, data=data)

    def convert(self, logs):
        """

        :param logs: { 'log_name': [fids] }
        :return:
        """

        # Create Request ID
        self.form['id'] = create_request_id()
        self.form['file'] = ','.join([str(_) for _ in logs[self.log_name]])

        # Insert Job info into cnvset.job
        io = DAOJob.instance()
        try:
            io.insert_job(**self.form)
        except Exception as e:
            logger.error('failed to insert job')
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

        # Create sub processor to convert log
        dao = DAOBaseClass()
        # #sqlite
        if isinstance(dao.connect, sqlite3.Connection):
            # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis_function as a " \
            #         f"inner join analysis_local_info as b on a.id = b.func_id) as c " \
            #         f"where system_func=true and log_name='{self.log_name}'"
            query = f"select d.id from " \
                    f"(select a.id, a.system_func, b.log_name, c.title from analysis_function as a " \
                    f"inner join analysis_local_info as b on a.id = b.func_id " \
                    f"inner join analysis_category as c on a.category_id = c.id) as d " \
                    f"where system_func=true and log_name='{self.log_name}' and title='{self.category_name}'"
        else:
            # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis.function as a " \
            #         f"inner join analysis.local_info as b on a.id = b.func_id) as c " \
            #         f"where system_func=true and log_name='{self.log_name}'"
            query = f"select d.id from " \
                    f"(select a.id, a.system_func, b.log_name, c.title from analysis.function as a " \
                    f"inner join analysis.local_info as b on a.id = b.func_id " \
                    f"inner join analysis.category as c on a.category_id = c.id) as d " \
                    f"where system_func=true and log_name='{self.log_name}' and title='{self.category_name}'"
        row = dao.execute(query)
        if row is None:
            return ResponseForm(res=False, msg=f'Cannot find {self.log_name} function.')

        func_id = row[0][0]
        cnv_proc = ConvertProcess(self.form['id'], {self.log_name: func_id})
        cnv_proc.start()

        return ResponseForm(res=True, data=self.form['id'])

    def upload_prediction(self, files, rid):
        """
        :param files: [files]
        :return: {'log_name': [fids]}
        """
        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        folder = os.path.join(self.conv_path, os.path.join(rid, self.prediction))
        if not os.path.exists(folder):
            os.makedirs(folder)

        # Save files and Insert file info into cnvset.file table
        data = dict()
        data[self.prediction] = list()

        for file in files:
            filename = file.filename
            temp_list = str(file.stream.read(), 'shift_jis').splitlines()

            category = None

            data_dict = dict()

            for linelog in temp_list:
                if len(linelog) < 3:
                    continue

                if "###" in linelog:
                    if app_config.PREDICT_CATEGORY_EXEC_TIME in linelog:
                        data_dict[app_config.PREDICT_CATEGORY_EXEC_TIME] = str(dparser.parse(linelog, fuzzy=True))
                    continue

                if "#" in linelog:
                    category = linelog.strip('#').strip(',,').strip()
                    data_dict[category] = dict()
                    continue

                if category is not None:
                    info = linelog.strip().split(',')
                    if category == app_config.PREDICT_CATEGORY_JOB_INFO:
                        data_dict[category]['device'] = info[0]
                        data_dict[category]['process'] = info[1]
                    elif category == app_config.PREDICT_CATEGORY_ADC_PLATE or \
                            category == app_config.PREDICT_CATEGORY_FDC_PLATE:
                        data_dict[category]["throughput"] = info[0]
                        data_dict[category]["working"] = info[1]
                        data_dict[category]["waiting"] = info[2]
                    elif category == app_config.PREDICT_CATEGORY_ADC_DETAIL or \
                            category == app_config.PREDICT_CATEGORY_FDC_DETAIL:
                        # data_dict[category][info[0]] = dict()  # display_num
                        if info[1] not in data_dict[category]:
                            data_dict[category][info[1]] = dict()
                            data_dict[category][info[1]]['display_num'] = info[0]
                            data_dict[category][info[1]]["event_tact"] = info[2]

            job_name = f"{filename}_{data_dict[app_config.PREDICT_CATEGORY_JOB_INFO]['device']}_" \
                       f"{data_dict[app_config.PREDICT_CATEGORY_JOB_INFO]['process']}"
            full_path = os.path.join(folder, job_name)

            with open(full_path, 'w') as f:
                json.dump(data_dict, f, ensure_ascii=False, indent=4)

        return ResponseForm(res=True)

    def job_tact_analysis(self, info):

        rid = info['rid']
        filter = dict()
        filter['log_time'] = {
            'start': info['period'][0],
            'end': info['period'][1],
        }
        job_list = filter['job'] = info['job']

        org_df = preprocessing.load_status_monitor(rid=rid, **filter)
        servicejobtact = ServiceJobTact(job_list)
        servicejobtact.calculate_job_tact(org_df)
        result = servicejobtact.get_job_tact()

        return result

    def plate_tact_analysis(self, info):

        rid = info['rid']
        filter = dict()
        filter['log_time'] = {
            'start': info['period'][0],
            'end': info['period'][1],
        }
        filter['job'] = info['job']
        type = info['data_type']
        adc_fdc = info['adc_fdc']
        plate_detail_tact_setting = info["plate_detail_tact"]
        plate_tact_setting = info["plate_tact"]

        service_plate_tact = ServicePlateTact()
        now = time.time()
        org_df = preprocessing.load_status_monitor(rid=rid, **filter)
        logger.debug(f'* load_status_monitor : {time.time() - now}')

        filter['df'] = org_df
        now = time.time()
        predict_dict = self.load_tact_prediction(rid=rid, **filter)
        logger.debug(f'* load_tact_prediction : {time.time() - now}')
        now = time.time()
        all_throughput_df, adc_throughput_df, fdc_throughput_df = service_plate_tact.create_throughput_list(org_df)
        logger.debug(f'* create_throughput_list : {time.time() - now}')

        throughput_df = ''
        if adc_fdc == 'ALL':
            throughput_df = all_throughput_df
        elif adc_fdc == 'ADC':
            throughput_df = adc_throughput_df
        else:
            throughput_df = fdc_throughput_df

        now = time.time()
        working_df, waiting_df = service_plate_tact.extract_working_and_waiting(throughput_df)
        logger.debug(f'* extract_working_and_waiting : {time.time() - now}')

        target_df = ''
        if type == 'Throughput':
            target_df = throughput_df
        elif type == 'Working':
            target_df = working_df
        else:
            target_df = waiting_df

        now = time.time()
        result = service_plate_tact.calculate_plate_tact(predict_dict, target_df, type, adc_fdc, plate_detail_tact_setting, plate_tact_setting)
        logger.debug(f'* calculate_plate_tact : {time.time() - now}')
        return result

    def plate_detail_tact_analysis(self, info):

        rid = info['rid']
        filter = dict()
        filter['log_time'] = {
            'start': info['period'][0],
            'end': info['period'][1],
        }
        filter['job'] = info['job']
        type = info['data_type']
        adc_fdc = info['adc_fdc']
        plate_detail_tact_setting = info["plate_detail_tact"]

        service_plate_detail_tact = ServicePlateDetailTact()
        org_df = preprocessing.load_status_monitor(rid=rid, **filter)

        filter['df'] = org_df
        predict_dict = self.load_tact_prediction(rid=rid, **filter)
        org_df = org_df[(org_df['plate'] == int(info['plate'])) & (org_df['lot_id_block'] == info['lot_id_block'])]
        result = service_plate_detail_tact.calculate_plate_detail_tact(org_df, predict_dict, type, adc_fdc, plate_detail_tact_setting)

        return result

    def load_tact_prediction(self, rid, **filters):

        tact_prediction = dict()
        job = filters['job']
        statusmonitor_df = filters['df']
        root_dir = os.path.join(os.path.join(app_config.CNV_RESULT_PATH, rid), app_config.PREDICTION_LOGNAME)
        if not os.path.exists(root_dir):
            return tact_prediction

        files = os.listdir(root_dir)
        job = job.replace('/', '_')
        for file in files:
            if job not in file:
                continue
            path = os.path.join(root_dir, file)
            with open(path, 'r') as f:
                predict_dict = json.load(f)

            # 予測値ファイルの日時の範囲に入っているか確認する
            exec_data = predict_dict[app_config.PREDICT_CATEGORY_EXEC_TIME]

            prediction_id_list = statusmonitor_df['prediction_id'].unique().tolist()
            for prediction_id in prediction_id_list:
                job_date = statusmonitor_df[statusmonitor_df['prediction_id'] == prediction_id]['log_time'].head(1).values[0]

                # 複数ファイルある場合最新のファイルのみ取得する
                conv_exec_date = pd.to_datetime(exec_data, format='%Y-%m-%d %H:%M:%S')
                conv_job_date = pd.to_datetime(job_date, format='%Y-%m-%d %H:%M:%S')
                # 前後3分の幅で一致確認
                job_date_plus = conv_job_date + \
                    datetime.timedelta(minutes=3)
                job_date_minus = conv_job_date + \
                    datetime.timedelta(minutes=-3)

                if job_date_minus <= conv_exec_date <= job_date_plus:
                    tact_prediction[prediction_id] = predict_dict

        return tact_prediction
