import logging
from config import app_config
'''
---------------------------------------------
Plate TACT Calc

Update History:
    [2021/01/12] 新規作成

Copyright(C) Canon Inc. All right reserved.
---------------------------------------------
'''

logger = logging.getLogger(app_config.LOG)


class ServicePlateTact:
    throughput = 'throughput'
    working = 'working'
    waiting = 'waiting'

    # 設定情報
    setting_event = 'event'
    setting_event_start = 'event_start'
    setting_event_end = 'event_end'
    setting_category = 'category'
    setting_display = 'display'
    setting_display_order = 'display_order'
    setting_total_time = 'total_time'
    setting_category_other = 'Other'
    setting_predict_total_time = 'predict_total_time'

    # 計算結果
    result_plate_tact = {}
    # 予測値
    adc = 0
    fdc = 1
    all = 2
    plate_load_event = 'Plate Load'
    plate_unload_event = 'Plate Unload'
    isPlateLoad = False
    isPlateUnLoad = False

    def __init__(self):
        self.result_plate_tact = {}

    def create_throughput_list(self, df):
        # 追加済みのplateでない且つPlateIDが0でない
        all_throughput_df = df.drop(df[df['plate'] == '0'].index)
        all_throughput_df.reset_index(inplace=True, drop=True)
        adc_throughput_list = list()
        fdc_throughput_list = list()
        lot_id_block_list = all_throughput_df['lot_id_block'].unique().tolist()

        for lot_id_block in lot_id_block_list:
            lot_id_block_df = all_throughput_df[all_throughput_df['lot_id_block'] == lot_id_block]
            plate_list = lot_id_block_df['plate'].unique().tolist()
            for plate in plate_list:
                plate_df = lot_id_block_df[lot_id_block_df['plate'] == plate]
                plate_adc_fdc = -1
                # 対象のplateが属するADC/FDCの値を取得する
                step_start_df = plate_df[plate_df['event'] == 'Step Start']
                if len(step_start_df) > 0:
                    plate_adc_fdc = int(step_start_df['adc_fdc'].values[0])

                # adcの場合
                if plate_adc_fdc == 0:
                    adc_throughput_list.extend(plate_df.index.values.tolist())
                # fdcの場合
                elif plate_adc_fdc == 1:
                    fdc_throughput_list.extend(plate_df.index.values.tolist())

        adc_throughput_df = df.loc[adc_throughput_list, :]
        adc_throughput_df.reset_index(inplace=True, drop=True)
        fdc_throughput_df = df.loc[fdc_throughput_list, :]
        fdc_throughput_df.reset_index(inplace=True, drop=True)

        return all_throughput_df, adc_throughput_df, fdc_throughput_df

    def extract_working_and_waiting(self, df):
        working_list = list()
        waiting_list = list()
        tmp_list = list()
        loading_flg = 0

        # StatusMonitorのデータ数分繰り返し
        event_list = df['event'].to_list()
        for idx, event in enumerate(event_list):
            if event == 'Plate Load' and loading_flg == 0:
                # working期間開始イベント
                loading_flg = 1
                waiting_list.extend(tmp_list)
                tmp_list.clear()
                tmp_list.append(idx)
            elif event != 'Plate Unload' and loading_flg == 1:
                # working期間中イベント
                tmp_list.append(idx)
            elif event == 'Plate Unload' and loading_flg == 1:
                # working期間終了イベント
                loading_flg = 0
                tmp_list.append(idx)
                working_list.extend(tmp_list)
                tmp_list.clear()
                tmp_list.append(idx)
            elif event == 'Plate Unload' and loading_flg == 0:
                # working期間中イベント
                waiting_list.extend(tmp_list)
                tmp_list.clear()
                tmp_list.append(idx)
            else:
                tmp_list.append(idx)

        # PlateLoadが出たが、以降にPlateUnloadが出てこなかった場合はworking期間イベント扱い
        if len(tmp_list) != 0 and loading_flg == 1:
            working_list.extend(tmp_list)

        # PlateUnloadが出たが、以降にPlateLoadが出てこなかった場合はwaiting期間イベント扱い
        # (PlateLoad、PlateUnload共に一度も出ない場合もここに入る)
        if len(tmp_list) != 0 and loading_flg == 0:
            waiting_list.extend(tmp_list)

        working_df = df.loc[working_list, :]
        working_df.reset_index(inplace=True, drop=True)
        waiting_df = df.loc[waiting_list, :]
        waiting_df.reset_index(inplace=True, drop=True)

        return working_df, waiting_df

    def setPlateLoad(self, base_event_name):
        if base_event_name == self.plate_load_event:
            self.isPlateLoad = True
        if base_event_name == self.plate_unload_event:
            self.isPlateUnLoad = True

    # [@@calculate_plate_tact] start time :  2022-04-29 19:13:15.847514
    # @@calculate_plate_tact] end time :  2022-04-29 19:22:07.518768
    # total time : 00:08:30?
    # def calculate_plate_tact_A(self, predict, df, kind, adc_fdc, plate_detail_tact_setting, plate_tact_setting):
    #     plate_tact_calc = {}
    #     category_calc = {}
    #     category_predict_calc = {}
    #     predict_time = 0
    #     event_name = ''
    #     plate_adc_fdc = 0
    #
    #     lot_id_block_list = df['lot_id_block'].unique().tolist()
    #     # plate数分処理を繰り返す
    #     for _, lot_id_block in enumerate(lot_id_block_list):
    #         plate_list = df[df['lot_id_block'] == lot_id_block]['plate'].unique().tolist()
    #         for _, plate in enumerate(plate_list):
    #
    #             self.isPlateLoad = False
    #             self.isPlateUnLoad = False
    #
    #             list = plate_tact_setting['category'].to_list()
    #             for idx, category in enumerate(list):
    #                 category_calc[category] = 0
    #                 category_predict_calc[category] = 0
    #
    #             # 対象のStatusMonitorのデータを取得する
    #             plate_df = df[(df['lot_id_block'] == lot_id_block) & (df['plate'] == plate)]
    #
    #             # plateのADC/FDCを取得する
    #             plate_adc_fdc = -1
    #             if 'Step Start' in plate_df['event'].values:
    #                 plate_adc_fdc = int(plate_df[plate_df['event'] == 'Step Start']['adc_fdc'].values[0])
    #
    #             # 対象の予測値データを取得する
    #             device = plate_df['device'].unique()[0]
    #             process = plate_df['process'].unique()[0]
    #             predict_id = plate_df['process'].unique()[0]
    #             predict_detail_df, predict_plate_time = self.get_tact_predict(plate_adc_fdc, kind, adc_fdc, predict, device, process, predict_id)
    #
    #             #対象のplateに含まれるデータ数分繰り返す
    #             for idx, item in plate_df.iterrows():
    #                 start_item = item
    #                 base_event_name = start_item.loc['event']
    #
    #                 # PlateLoadの状況を更新する
    #                 self.setPlateLoad(base_event_name)
    #
    #                 # 比較するイベントと一致するStartとEndを取得する
    #                 select_detail_tact_setting = plate_detail_tact_setting[plate_detail_tact_setting['event_start'] == base_event_name]
    #                 if len(select_detail_tact_setting.index) != 0:
    #                     event_name = select_detail_tact_setting['event'].values[0]
    #                     # Startに対応するEndと一致するイベントを検索する（比較元以降のイベントを対象とする）
    #                     end_event_name = select_detail_tact_setting['event_end'].values[0]
    #                     end_item = plate_df[(plate_df['event'] == end_event_name) & (plate_df.index > idx)].head(1)
    #
    #                     # 一致した場合
    #                     # event_name_flg = False
    #                     if len(end_item) != 0:
    #                         diff_time = end_item['log_time'] - start_item['log_time']
    #                         diff_time_milli = diff_time.item().total_seconds() * 1000
    #
    #                         # PlateLoadが始まってから予測値を取得する
    #                         predict_time = 0
    #                         if self.isPlateLoad:
    #                             if len(predict_detail_df) != 0:
    #                                 predict_info = predict_detail_df[predict_detail_df['event_name'] == event_name]['event_tact']
    #
    #                                 if len(predict_info) == 1:
    #                                     predict_time = predict_info.values[0]
    #                                 elif len(predict_info) > 1:
    #                                     predict_time = predict_info.values[0]
    #                                     predict_detail_df.drop(index=predict_info.index[0])
    #                                 else:
    #                                     predict_time = 0
    #
    #                                 if diff_time_milli <= 15:
    #                                     # 実測値が15ms以下の場合は対象外
    #                                     predict_time = 0
    #
    #                     category = select_detail_tact_setting['category'].values[0]
    #                     select_tact_setting = plate_tact_setting[plate_tact_setting['category'] == category]
    #                     if len(select_tact_setting.index) != 0:
    #                         if category in category_calc:
    #                             category_calc[category] = category_calc[category] + diff_time_milli
    #                             category_predict_calc[category] = category_predict_calc[category] + predict_time
    #                     else:
    #                         if category in category_calc:
    #                             category_calc['Other'] = category_calc['Other'] + diff_time_milli
    #                             category_predict_calc['Other'] = category_predict_calc['Other'] + predict_time
    #
    #             calc_result_list, calc_result_predict_list = self.make_out_data(kind, predict_plate_time, plate_df, category_calc, category_predict_calc)
    #             self.make_result_plate_tact(lot_id_block, plate, plate_adc_fdc, kind, calc_result_list, calc_result_predict_list)
    #
    #     return self.result_plate_tact

    # [@@calculate_plate_tact] start time :  2022-04-29 18:47:09.281515
    # [@@calculate_plate_tact] end time :  2022-04-29 18:57:33.906665
    # total : 00:10:24
    # def calculate_plate_tact_B(self, predict, df, kind, adc_fdc, plate_detail_tact_setting, plate_tact_setting):
    #     plate_tact_calc = {}
    #     category_calc = {}
    #     category_predict_calc = {}
    #     predict_time = 0
    #     event_name = ''
    #     plate_adc_fdc = 0
    #
    #     lot_id_block_list = df['lot_id_block'].unique().tolist()
    #     # plate数分処理を繰り返す
    #     for _, lot_id_block in enumerate(lot_id_block_list):
    #         plate_list = df[df['lot_id_block'] == lot_id_block]['plate'].unique().tolist()
    #         for _, plate in enumerate(plate_list):
    #
    #             self.isPlateLoad = False
    #             self.isPlateUnLoad = False
    #
    #             list = plate_tact_setting['category'].to_list()
    #             for idx, category in enumerate(list):
    #                 category_calc[category] = 0
    #                 category_predict_calc[category] = 0
    #
    #             # 対象のStatusMonitorのデータを取得する
    #             plate_df = df[(df['lot_id_block'] == lot_id_block) & (df['plate'] == plate)]
    #
    #             # plateのADC/FDCを取得する
    #             plate_adc_fdc = -1
    #             if 'Step Start' in plate_df['event'].values:
    #                 plate_adc_fdc = int(plate_df[plate_df['event'] == 'Step Start']['adc_fdc'].values[0])
    #
    #             # 対象の予測値データを取得する
    #             device = plate_df['device'].unique()[0]
    #             process = plate_df['process'].unique()[0]
    #             predict_detail_df, predict_plate_time = self.get_tact_predict(plate_adc_fdc, kind, adc_fdc, predict, device, process)
    #
    #             event_list = plate_detail_tact_setting['event'].to_list()
    #             category_list = plate_detail_tact_setting['category'].to_list()
    #             for idx, event in enumerate(event_list):
    #                 event_start = plate_detail_tact_setting[plate_detail_tact_setting['event'] == event]['event_start'].values[0]
    #                 event_end = plate_detail_tact_setting[plate_detail_tact_setting['event'] == event]['event_end'].values[0]
    #
    #                 start_item = plate_df[(plate_df['event'] == event_start)]['log_time']
    #                 if len(start_item) == 0:
    #                     continue
    #                 else:
    #                     start_time = start_item.values[0]
    #                     plate_df.drop(index=start_item.index[0])
    #
    #                 # PlateLoadの状況を更新する
    #                 self.setPlateLoad(event_start)
    #
    #                 end_item = plate_df[(plate_df['event'] == event_end)]['log_time']
    #                 if len(end_item) == 0:
    #                     continue
    #                 else:
    #                     end_time = end_item.values[0]
    #                     plate_df.drop(index=end_item.index[0])
    #
    #                 diff_time = end_time - start_time
    #                 diff_time_milli = float(diff_time) / 1000000
    #                 # PlateLoadが始まってから予測値を取得する
    #                 predict_time = 0
    #                 if self.isPlateLoad:
    #                     if len(predict_detail_df) != 0:
    #                         predict_info = predict_detail_df[predict_detail_df['event_name'] == event_name]['event_tact']
    #
    #                         if len(predict_info) == 1:
    #                             predict_time = predict_info.values[0]
    #                         elif len(predict_info) > 1:
    #                             predict_time = predict_info.values[0]
    #                             predict_detail_df.drop(index=predict_info.index[0])
    #                         else:
    #                             predict_time = 0
    #
    #                         if diff_time_milli <= 15:
    #                             # 実測値が15ms以下の場合は対象外
    #                             predict_time = 0
    #
    #                 category = category_list[idx]
    #                 select_tact_setting = plate_tact_setting[plate_tact_setting['category'] == category]
    #                 if len(select_tact_setting.index) != 0:
    #                     if category in category_calc:
    #                         category_calc[category] = category_calc[category] + diff_time_milli
    #                         category_predict_calc[category] = category_predict_calc[category] + predict_time
    #                 else:
    #                     if category in category_calc:
    #                         category_calc['Other'] = category_calc['Other'] + diff_time_milli
    #                         category_predict_calc['Other'] = category_predict_calc['Other'] + predict_time
    #
    #             calc_result_list, calc_result_predict_list = self.make_out_data(kind, predict_plate_time, plate_df, category_calc, category_predict_calc)
    #             self.make_result_plate_tact(lot_id_block, plate, plate_adc_fdc, kind, calc_result_list, calc_result_predict_list)
    #
    #     return self.result_plate_tact

    def calculate_plate_tact(self, predict_dict, df, kind, adc_fdc, plate_detail_tact_setting, plate_tact_setting):
        plate_tact_calc = {}
        category_calc = {}
        category_predict_calc = {}
        predict_time = 0
        event_name = ''
        plate_adc_fdc = 0
        isPredict = False
        category_list = plate_tact_setting['category'].to_list()

        detail_category_list = plate_detail_tact_setting['category'].to_list()
        event_start_list = plate_detail_tact_setting['event_start'].to_list()
        event_end_list = plate_detail_tact_setting['event_end'].to_list()
        detail_tact_event_list = plate_detail_tact_setting['event'].to_list()

        plate_detail_tact_setting_dict = dict()
        for i in range(len(event_start_list)):
            event_start = event_start_list[i]
            event_end = event_end_list[i]
            category = detail_category_list[i]
            event = detail_tact_event_list[i]
            if event_start not in plate_detail_tact_setting_dict:
                plate_detail_tact_setting_dict[event_start] = {'event_end': event_end,
                                                               'category': category,
                                                               'event': event}

        lot_id_block_list = df['lot_id_block'].unique().tolist()
        # plate数分処理を繰り返す
        for lot_id_block in lot_id_block_list:
            lot_id_block_df = df[df['lot_id_block'] == lot_id_block]
            plate_list = lot_id_block_df['plate'].unique().tolist()

            for plate in plate_list:
                predict_detail_dict = None

                # 追加済みのplateでない且つPlateIDが0でない
                if plate == 0:
                    continue

                self.isPlateLoad = False
                self.isPlateUnLoad = False

                for category in category_list:
                    category_calc[category] = 0
                    category_predict_calc[category] = 0

                # 対象のStatusMonitorのデータを取得する
                plate_df = lot_id_block_df[lot_id_block_df['plate'] == plate]

                # plateのADC/FDCを取得する
                plate_adc_fdc = -1
                step_start_df = plate_df[plate_df['event'] == 'Step Start']
                if len(step_start_df) > 0:
                    plate_adc_fdc = int(step_start_df['adc_fdc'].values[0])

                # 対象の予測値データを取得する
                if len(predict_dict) == 0:
                    isPredict = False
                    predict_plate_time = 0
                else:
                    device = plate_df['device'].unique()[0]
                    process = plate_df['process'].unique()[0]
                    predict_id = plate_df['prediction_id'].unique()[0]

                    predict_detail_dict, predict_plate_time = self.get_tact_predict(plate_adc_fdc, kind, adc_fdc, predict_dict, device, process, predict_id)

                    if len(predict_detail_dict) > 0:
                        isPredict = True
                    else:
                        isPredict = False

                event_list = plate_df['event'].to_list()
                log_time_list = plate_df['log_time'].to_list()

                total_event = len(event_list)
                index_list = [i for i in range(total_event)]
                while len(index_list) > 0:
                    start_idx = index_list.pop(0)
                    base_event_name = event_list[start_idx]

                    # PlateLoadの状況を更新する
                    self.setPlateLoad(base_event_name)

                    # 比較するイベントと一致するStartとEndを取得する
                    try:
                        select_detail_tact_setting = plate_detail_tact_setting_dict[base_event_name]
                    except Exception:
                        continue

                    # Startに対応するEndと一致するイベントを検索する（比較元以降のイベントを対象とする）
                    end_time = None
                    event_end = select_detail_tact_setting['event_end']
                    # PlateUnloadの状況を更新する
                    self.setPlateLoad(event_end)
                    for i in range(start_idx + 1, len(event_list)):
                        if event_list[i] == event_end:
                            end_time = log_time_list[i]
                            try:
                                index_list.remove(i)
                            except Exception as e:
                                pass
                            break

                    # 一致した場合
                    if end_time != None:
                        start_time = log_time_list[start_idx]
                        diff_time = end_time - start_time
                        diff_time_milli = diff_time.total_seconds() * 1000

                        # PlateLoadが始まってから予測値を取得する
                        predict_time = 0
                        if self.isPlateLoad:
                            if predict_detail_dict is not None and len(predict_detail_dict) != 0:
                                event_name = select_detail_tact_setting['event']
                                if event_name in predict_detail_dict:
                                    predict_time = int(predict_detail_dict[event_name]['event_tact'])
                                else:
                                    predict_time = 0

                                if diff_time_milli <= 15:
                                    # 実測値が15ms以下の場合は対象外
                                    predict_time = 0

                        category = select_detail_tact_setting['category']
                        # select_tact_setting = plate_tact_setting[plate_tact_setting['category'] == category]
                        # if len(select_tact_setting.index) != 0:
                        if category in category_calc:
                            category_calc[category] = category_calc[category] + diff_time_milli
                            category_predict_calc[category] = category_predict_calc[category] + predict_time
                        elif 'Other' in category_calc:
                            category_calc['Other'] = category_calc['Other'] + diff_time_milli
                            category_predict_calc['Other'] = category_predict_calc['Other'] + predict_time

                calc_result_list, calc_result_predict_list = self.make_out_data(kind, predict_plate_time, plate_df,
                                                                                category_calc,
                                                                                category_predict_calc)
                self.make_result_plate_tact(lot_id_block, plate, plate_adc_fdc, kind, calc_result_list,
                                            calc_result_predict_list, isPredict)

        return self.result_plate_tact

    def make_out_data(self, kind, predict_plate_time, plate_df, category_calc, category_predict_calc):
        calc_result_list = {}
        calc_result_predict_list = {}
        result_predict_plate_time = 0
        if kind == self.waiting:
            # waitingの場合はPlateUnLoadがない場合は予測値を表示しない
            if not self.isPlateLoad and self.isPlateUnLoad:
                result_predict_plate_time = predict_plate_time
        else:
            # waiting以外の場合はPlateLoadまたはPlateUnLoadがない場合は予測値を表示しない
            if self.isPlateLoad and self.isPlateUnLoad:
                result_predict_plate_time = predict_plate_time

        # Plateの合計時間を取得する
        plate_time_milli = 0
        if len(plate_df) > 0:
            date_time = plate_df['log_time'].to_numpy()
            plate_time = date_time.max() - date_time.min()
            plate_time_milli = float(plate_time) / 1000000

        # イベントの合計時間を取得する
        event_total_time = 0
        predict_total_time = 0
        for key, value in category_calc.items():
            event_total_time = event_total_time + value
        for key, value in category_predict_calc.items():
            predict_total_time = predict_total_time + value

        # Plateの合計時間よりイベントの合計時間が短い場合は差分をOtherに含める
        if event_total_time < plate_time_milli:
            category_calc['Other'] = category_calc['Other'] + (plate_time_milli - event_total_time)
            event_total_time = event_total_time + (plate_time_milli - event_total_time)

        if predict_total_time < result_predict_plate_time:
            category_predict_calc['Other'] = category_predict_calc['Other'] + (
                    result_predict_plate_time - predict_total_time)
            predict_total_time = predict_total_time + (result_predict_plate_time - predict_total_time)

        # グラフに表示する時間はイベントの時間を実際のPlate処理時間を基に按分する
        plate_total_time = 0
        for key, value in category_calc.items():
            # 実測値の集計
            time = 0
            if event_total_time != 0:
                time = round(value / event_total_time * plate_time_milli / 1000, 2)
                calc_result_list[key] = time
            else:
                calc_result_list[key] = time
            plate_total_time += time
        calc_result_list['sum'] = round(plate_total_time, 2)

        predict_plate_total_time = 0
        for key, value in category_predict_calc.items():
            # 予測値の集計
            time = 0
            if predict_total_time != 0:
                time = round(value / predict_total_time * result_predict_plate_time / 1000, 2)
                calc_result_predict_list[key] = time
            else:
                calc_result_predict_list[key] = time
            predict_plate_total_time += time
        calc_result_predict_list['sum'] = round(predict_plate_total_time, 2)

        return calc_result_list, calc_result_predict_list

    def make_result_plate_tact(self, lot_id_block, plate, plate_adc_fdc, kind, calc_result_list, calc_result_predict_list, isPlate):

        if 'lot_id_block' not in self.result_plate_tact:
            self.result_plate_tact['lot_id_block'] = {}
        if lot_id_block not in self.result_plate_tact['lot_id_block']:
            self.result_plate_tact['lot_id_block'][lot_id_block] = {}
        if 'plate' not in self.result_plate_tact['lot_id_block'][lot_id_block]:
            self.result_plate_tact['lot_id_block'][lot_id_block]['plate'] = []
            self.result_plate_tact['lot_id_block'][lot_id_block]['plate'].append(int(plate))
        else:
            self.result_plate_tact['lot_id_block'][lot_id_block]['plate'].append(int(plate))
        if 'adc_fdc' not in self.result_plate_tact['lot_id_block'][lot_id_block]:
            self.result_plate_tact['lot_id_block'][lot_id_block]['adc_fdc'] = []
            self.result_plate_tact['lot_id_block'][lot_id_block]['adc_fdc'].append(plate_adc_fdc)
        else:
            self.result_plate_tact['lot_id_block'][lot_id_block]['adc_fdc'].append(plate_adc_fdc)
        if 'plate_tact' not in self.result_plate_tact['lot_id_block'][lot_id_block]:
            self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'] = {}
        if kind not in self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact']:
            self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind] = {}
            for key, value in calc_result_list.items():
                if key not in self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind]:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key] = []
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)
                else:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)
        else:
            for key, value in calc_result_list.items():
                if key not in self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind]:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key] = []
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)
                else:
                    self.result_plate_tact['lot_id_block'][lot_id_block]['plate_tact'][kind][key].append(value)

        if isPlate:
            if 'predict' not in self.result_plate_tact['lot_id_block'][lot_id_block]:
                self.result_plate_tact['lot_id_block'][lot_id_block]['predict'] = {}
            if kind not in self.result_plate_tact['lot_id_block'][lot_id_block]['predict']:
                self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind] = {}
                for key, value in calc_result_predict_list.items():
                    if key not in self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind]:
                        self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key] = []
                        self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].append(value)
                    else:
                        self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].append(value)
            else:
                for key, value in calc_result_predict_list.items():
                    if key not in self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind]:
                        self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key] = []
                        self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].apppend(value)
                    else:
                        self.result_plate_tact['lot_id_block'][lot_id_block]['predict'][kind][key].append(value)

    def get_tact_predict(self, plate_adc_fdc, kind, adc_fdc, predict_dict, device, process, predict_id):
        predict_detail_dict = dict()
        predict_plate_time = 0

        # 対象の予測値がなければ空を返す
        if len(predict_dict) == 0 or predict_id not in predict_dict:
            return predict_detail_dict, predict_plate_time

        # 対象のADC/FDCの予測値を取得する
        if plate_adc_fdc == 1:  # fdc(self.fdc)
            predict_detail_dict = predict_dict[predict_id][app_config.PREDICT_CATEGORY_FDC_DETAIL]
            predict_plate_time = predict_dict[predict_id][app_config.PREDICT_CATEGORY_FDC_PLATE][kind.lower()]
        else:
            predict_detail_dict = predict_dict[predict_id][app_config.PREDICT_CATEGORY_ADC_DETAIL]
            predict_plate_time = predict_dict[predict_id][app_config.PREDICT_CATEGORY_ADC_PLATE][kind.lower()]
        if 'ALL' != adc_fdc and plate_adc_fdc != adc_fdc:  # all = 2(self.all)
            predict_plate_time = 0

        predict_plate_time = int(predict_plate_time)

        return predict_detail_dict, predict_plate_time