import pandas as pd
from config import app_config


class ServicePlateDetailTact():
    # 計算結果
    resutl_plate_detail_tact = []

    def get_tact_predict(self, plate_adc_fdc, kind, adc_fdc, predict_dict, device, process, predict_id):
        predict_detail_dict = dict()
        predict_plate_time = 0

        # 対象の予測値がなければ空を返す
        if len(predict_dict) == 0 or predict_id not in predict_dict:
            return predict_detail_dict, predict_plate_time

        # 対象のADC/FDCの予測値を取得する
        if(plate_adc_fdc == 1): # fdc(self.fdc)
            predict_detail_dict = predict_dict[predict_id][app_config.PREDICT_CATEGORY_FDC_DETAIL]
            predict_plate_time = predict_dict[predict_id][app_config.PREDICT_CATEGORY_FDC_PLATE][kind.lower()]
        else:
            predict_detail_dict = predict_dict[predict_id][app_config.PREDICT_CATEGORY_ADC_DETAIL]
            predict_plate_time = predict_dict[predict_id][app_config.PREDICT_CATEGORY_ADC_PLATE][kind.lower()]
        if 'ALL' != adc_fdc and plate_adc_fdc != adc_fdc:   # all = 2(self.all)
            predict_plate_time = 0

        predict_plate_time = int(predict_plate_time)

        return predict_detail_dict, predict_plate_time

    def calculate_plate_detail_tact(self, statusmonitor_df, predict_dict, kind, adc_fdc, plate_detail_tact_setting):
        first = 0
        base_event_time = 0
        self.resutl_plate_detail_tact = []
        isPredict = False

        # plateのADC/FDCを取得する
        plate_adc_fdc = -1
        if 'Step Start' in statusmonitor_df['event'].values:
            plate_adc_fdc = int(statusmonitor_df[statusmonitor_df['event'] == 'Step Start']['adc_fdc'].values[0])

        # 対象の予測値データを取得する
        device = statusmonitor_df['device'].unique()[0]
        process = statusmonitor_df['process'].unique()[0]
        predict_id = statusmonitor_df['prediction_id'].unique()[0]

        if len(predict_dict) == 0:
            isPredict = False
            predict_detail_dict = dict()
            predict_plate_time = 0
        else:
            predict_detail_dict, predict_plate_time = self.get_tact_predict(plate_adc_fdc, kind, adc_fdc, predict_dict, device, process, predict_id)
            if len(predict_detail_dict) == 0:
                isPredict = False
            else:
                isPredict = True

        for idx, item in statusmonitor_df.iterrows():
            start_item = item
            start_event_name = start_item.loc['event']
            event_detail_tact = {}

            # 比較するイベントと一致するStartとEndを取得する
            select_detail_tact_setting = plate_detail_tact_setting[plate_detail_tact_setting['event_start'] == start_event_name]
            if len(select_detail_tact_setting.index) != 0:
                event_name = select_detail_tact_setting['event'].values[0]
                end_event_name = select_detail_tact_setting['event_end'].values[0]
                category = select_detail_tact_setting['category'].values[0]
                # Startに対応するEndと一致するイベントを検索する（比較元以降のイベントを対象とする）
                end_item = statusmonitor_df[(statusmonitor_df['event'] == end_event_name) & (statusmonitor_df.index > idx)].head(1)
                # 一致した場合
                if len(end_item) != 0:
                    diff_time = pd.to_datetime(end_item['log_time'].values[0]) - start_item['log_time']
                    diff_time_sec = diff_time.total_seconds()

                    if first == 0:
                        base_event_time = start_item['log_time']
                        first = 1

                    event_detail_tact['event'] = event_name
                    event_detail_tact['tact'] = diff_time_sec
                    event_detail_tact['start'] = start_item['log_time']
                    event_detail_tact['end'] = pd.to_datetime(end_item['log_time'].values[0])
                    base_time = start_item['log_time'] - base_event_time
                    base_time_sec = base_time.total_seconds()
                    event_detail_tact['base'] = base_time_sec
                    if isPredict:
                        event_detail_tact['predict'] = 0
                        if len(predict_detail_dict) != 0:
                            if event_name in predict_detail_dict:
                                event_detail_tact['predict'] = int(predict_detail_dict[event_name]['event_tact']) / 1000
                    event_detail_tact['category'] = category

                    self.make_result_plate_detail_tact(event_detail_tact)

        return self.resutl_plate_detail_tact

    def make_result_plate_detail_tact(self, detail_tact):
        self.resutl_plate_detail_tact.append(detail_tact)
