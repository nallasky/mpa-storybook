import os
import logging
import re
import time

import pandas as pd
import traceback
import shutil

from service.tact.service_cvt_logsrvtotsmem import TsMemoryDumpLogConvert
from service.tact.service_tact_base import ServiceTactBase
from service.converter.convert_process import ConvertProcess
from common.utils.response import ResponseForm
from config import app_config
from dao.dao_file import FileDao
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass

from controller.converter.converter import create_request_id
from service.tact.service_tact_filecomposition import TsFileComposition

logger = logging.getLogger(app_config.LOG)


class ServiceTsMemory(ServiceTactBase):
    log_name = app_config.TSMEMORY_LOGNAME

    # define type of ts logs
    is_log_main_unit = 'main'
    is_log_scan_unit = 'scan'
    is_log_perl_unit = 'perl'
    _ts_log_column_count = 13

    def __init__(self):
        super().__init__()

        self.root_path = app_config.root_path
        self.conv_path = app_config.CNV_RESULT_PATH
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.log_name
        }
        self.log_type = None
        self.auto_adjust = None
        self.main_data = list()
        self.scan_data = list()
        self.perl_data = list()
        self.ord_pd_data = None

    def set_service_log_type(self, *, log_type):
        self.log_type = log_type

    def set_service_auto_adjust(self, *, adjust):
        self.auto_adjust = adjust

    def file_check(self, files):
        """
        ログのタイプを確認
        :param files: [files]
        :return: {'log_name': [fids]}
        """

        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        folder = os.path.join(self.root_path, self.log_name)
        if not os.path.exists(folder):
            os.makedirs(folder)

        # file check and judge log type.
        tact_file_comp = TsFileComposition()
        check_file = tact_file_comp.check_logfiles(files, self.log_type)
        if check_file is False:
            return ResponseForm(res=False, msg='Mismatched file format!')

        data = dict()
        data[self.log_name] = list()

        for file in files:
            filename = file.filename
            f = None
            file_index = 1
            while f is None or os.path.exists(f):
                _filename = f'{file_index}____{filename}'
                f = os.path.join(os.path.join(self.root_path, self.log_name), _filename)
                file_index += 1
            file.seek(0)
            file.save(f)
            fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))
            if fid is None:
                logger.error('failed to store file info')
                return ResponseForm(res=False, msg='failed to store file info')

            data[self.log_name].append(fid)

        return ResponseForm(res=True, data=data)

    def convert(self, logs):
        """
        Logserver Log ファイルを Ts memory dump ファイル形態で変換
        :param logs: { 'log_name': [fids] }
        :return: rid
        """
        # Create Request ID
        self.form['id'] = create_request_id()
        self.form['file'] = ','.join([str(_) for _ in logs[self.log_name]])

        # Insert Job info into cnvset.job
        io = DAOJob.instance()
        try:
            if self.log_type == TsFileComposition.is_ts_memory:
                fio = FileDao.instance()
                rid = self.form['id']
                _cache_root = ".cnv_result"
                if not os.path.exists(_cache_root):
                    os.mkdir(_cache_root)
                cache_root = os.path.join(_cache_root, rid)
                if not os.path.exists(cache_root):
                    os.mkdir(cache_root)
                file_root = os.path.join(cache_root, app_config.TSMEMORY_LOGNAME)
                if not os.path.exists(file_root):
                    os.mkdir(file_root)
                # info = io.get_job(rid)
                file_ids = [f.strip() for f in self.form['file'].split(',') if len(f) != 0]
                files = [fio.get(_)['path'] for _ in file_ids]
                for file in files:
                    temp_file = file.split('\\')
                    file_name = temp_file[len(temp_file) - 1]
                    cnv_path = os.path.join(file_root, file_name)
                    shutil.copy(file, cnv_path)

                self.form['status'] = 'success'
                io.insert_job(**self.form)

            elif self.log_type == TsFileComposition.is_log_server:
                io.insert_job(**self.form)
                cnv_proc = ConvertProcess(self.form['id'], {self.log_name: 0})
                cnv_proc.start()

            elif self.log_type == TsFileComposition.is_ts_imported:
                pass

            return ResponseForm(res=True, data=self.form['id'])

        except Exception as e:
            logger.error('failed to insert job')
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

    def _load_tsmemdmplog_data(self, tsmlogs):
        """
        ts memory dump ログの TACT 分析を処理
        """
        # ファイルの個数位パッシング処理
        for log in tsmlogs:
            if not os.path.exists(log):
                return None
            # get file name
            file_name = os.path.splitext(os.path.basename(log))[0]

            f_encoding = TsMemoryDumpLogConvert.check_encode_type(log)
            with open(log, 'r', encoding=f_encoding) as f:
                lines = f.readlines()
                # 10ラインのヘドブを確認してログタイプを取得
                _, unit = self._verify_log_type(lines[:10])

                # ヘッダー部があるが、有効ではない場合
                if unit is None:
                    continue
                if unit is not False and file_name.upper().find(unit) < 0:
                    print('odd log file header!')
                    continue

                unit_type = self._get_type_unit(file_name)
                # データ Parse 取得
                for line in lines:
                    accum = self._parse_log_file(line.strip())
                    if accum is not None:
                        if unit_type == self.is_log_main_unit:
                            self.main_data.append(accum)
                        elif unit_type == self.is_log_scan_unit:
                            self.scan_data.append(accum)
                        elif unit_type == self.is_log_perl_unit:
                            self.perl_data.append(accum)

        if len(self.main_data) < 1 and len(self.scan_data) < 1 and len(self.perl_data) < 1:
            return None

        # create Dataframe
        main_df = pd.DataFrame(self.main_data)
        scan_df = pd.DataFrame(self.scan_data)
        perl_df = pd.DataFrame(self.perl_data)
        main_df['unit'] = 'main'
        scan_df['unit'] = 'scan'
        perl_df['unit'] = 'perl'

        # adjust time auto align
        if not main_df.empty and self.auto_adjust:
            start = time.time()
            self._apply_time_adjust()
            print("tsmemdmp auto adjustment stamp: ", time.time() - start)

            # apply auto adjustment
            if not scan_df.empty:
                scan_df['ordertime'] = scan_df['ordertime'].apply(lambda x: int(x) + self.scan_dif)
            if not perl_df.empty:
                perl_df['ordertime'] = perl_df['ordertime'].apply(lambda x: int(x) + self.perl_dif)

        pd_data = pd.concat([main_df, scan_df, perl_df], ignore_index=True)
        pd_data = pd_data.astype({'ordertime': 'int64', 'elapse': 'int64', 'plate': 'int', 'step': 'int'})

        # base on 'ordertime' do sort by ascending
        ord_pd_data = pd_data.sort_values(by=['ordertime'], kind='mergesort', ascending=True, axis=0)
        ord_pd_data.reset_index(drop=True, inplace=True)

        return ord_pd_data

    @staticmethod
    def _get_type_unit(file_name):
        """
        ユニットタイプを判断
        """
        if file_name.upper().find('MAIN') >= 0:
            return ServiceTsMemory.is_log_main_unit
        elif file_name.upper().find('SCAN') >= 0:
            return ServiceTsMemory.is_log_scan_unit
        elif file_name.upper().find('PERL') >= 0:
            return ServiceTsMemory.is_log_perl_unit
        else:
            return None

    def _parse_log_file(self, line):
        """
        ログ文字列をパッシング処理
        :param line: 1line Log Data String
        :return: dataset of Dict()
        """
        if line and not line.startswith('#') and line != '':
            # separate with comma
            elem = line.strip().split(',')
            if len(elem) < self._ts_log_column_count:
                return None

            if elem[6].isdigit() is False \
                    or elem[7].isdigit() is False \
                    or elem[8].isdigit() is False:
                return None

            # order, pu, name, kick, call, cond, time, start, end, elapse, net, node, plate, step
            dataset = {'ordertime': elem[6], 'pu': elem[0], 'name': elem[1], 'kick': elem[2], 'call': elem[3],
                       'cond': elem[4], 'time': elem[5], 'start': elem[6], 'end': elem[7],
                       'elapse': elem[8], 'net': elem[9], 'node': elem[10], 'plate': elem[11], 'step': elem[12]}

            return dataset

    def analysis_tsmemdmp_tact(self, rid):
        """
        TS TACT分析結果を生成
        :return: dict() - result of tact analysis
        """
        start = time.time()
        root_dir = os.path.join(os.path.join(app_config.CNV_RESULT_PATH, rid), app_config.TSMEMORY_LOGNAME)
        if not os.path.exists(root_dir):
            return ResponseForm(res=False, msg=app_config.ERR_FILE_NOT_EXIST)
        files = os.listdir(root_dir)

        log_file_list = list()
        for file in files:
            path = os.path.join(root_dir, file)
            log_file_list.append(path)

        # get log files from cnv_result
        self.ord_pd_data = self._load_tsmemdmplog_data(log_file_list)

        print("load_tsmemdmplog_data: ", time.time() - start)
        start = time.time()
        if self.ord_pd_data is None:
            return ResponseForm(res=False, msg=app_config.ERR_TSLOG_NOT_EXIST)

        search_pu_table, level_table = self._get_primary_table()
        if search_pu_table is None:
            return ResponseForm(res=False, msg=app_config.ERR_NOT_FIND_NAME_PU)
        if search_pu_table is False:
            return ResponseForm(res=False, msg=app_config.ERR_NOT_FIND_PRIMARY_PU)

        tact_list = list()
        # 蓄積時間を節約
        accum_start = 0
        accum_end = 0

        unit_values = self.ord_pd_data['unit'].values
        pu_values = self.ord_pd_data['pu'].values
        for log_idx in range(len(self.ord_pd_data)):
            unit = unit_values[log_idx]
            pu = pu_values[log_idx]
            if pu in search_pu_table.keys():
                if log_idx < len(self.ord_pd_data):
                    # nextPu = self.ord_pd_data['pu'].values[log_idx+1]
                    # if nextPu == pu or unit != 'main':
                    #     continue
                    if unit != self.is_log_main_unit:
                        continue

                name = search_pu_table[pu].strip()
                level = int(level_table[pu])
                elapse = float(self.ord_pd_data['elapse'].values[log_idx])/1000
                # start = float(self.ord_pd_data['start'].values[log_idx])
                plate = int(self.ord_pd_data['plate'].values[log_idx])
                accum_end += elapse
                tact_list.append(
                    {'puid': pu,                      #str
                     'puname': name,                  #str
                     'level': level,                  #int
                     'plate_no': plate,               #int
                     'base': round(accum_start, 3),   #float
                     'start': round(accum_start, 3),  #float
                     'end': round(accum_end, 3),      #float
                     'time': round(elapse, 3)         #float
                     })
                accum_start += elapse

        print("analysis_tsmemdmp_tact: ", time.time() - start)
        return ResponseForm(res=True, data=tact_list)

    def _verify_log_type(self, lines):
        """
        ログタイプを検証
        :param lines: 10Lines Log Data
        :return: True/False, Unit Name
        """
        header_date = None
        header_unit = None
        for line in lines:
            if re.match(r'^#+ +DATE', line):
                header_date = re.sub(r'^.*DATE[ :]+([0-9/ :]+)[ #\n]*$', '\g<1>', line).strip()
            elif re.match(r'^#+ +UNIT', line):
                header_unit = re.sub(r'^.*UNIT *= *([^ ]+)[ #\n]*$', '\g<1>', line).upper()
            elif re.match(r'^#+', line):
                continue
            else:
                pass

        if header_unit is None:
            return False, False

        if header_unit.find('MAIN') >= 0:
            header_unit = 'MAIN'
        elif header_unit.find('SCAN') >= 0:
            header_unit = 'SCAN'
        elif header_unit.find('PERL') >= 0:
            header_unit = 'PERL'
        else:
            header_unit = None

        return header_date, header_unit

    def _get_primary_table(self):
        """
        DBで主要 PU テーブルを取得
        """
        p_name = self._tact_layer_info()
        if p_name is None:
            # p_name = "primary_pu1"
            return False, False
        dao_base = DAOBaseClass()
        primary_pu_id = dao_base.fetch_all(table='tact.primary_pu',
                                           args={'select': 'id', 'where': f"pu_name='{p_name}'"})['id'].values[0]
        pu_table = dao_base.fetch_all(table='tact.primary_pu_item',
                           args={'select': 'id, puid, name, level', 'where': f'primary_pu_id={primary_pu_id}'})
        name_table = pu_table.set_index('puid').to_dict()['name']
        level_table = pu_table.set_index('puid').to_dict()['level']
        if len(name_table) < 1:
            return None, None
        return name_table, level_table

    def _tact_layer_info(self):
        """
        tact分析のための Primary_pu テーブルを選択
        """
        primary_pu = None
        ref_pu_list = self._find_ref_pu_target()
        for ref_pu in ref_pu_list.keys():
            if ref_pu in self.ord_pd_data['pu'].values:
                primary_pu = ref_pu_list[ref_pu]
                break
            else:
                pass
        return primary_pu

    @staticmethod
    def _find_ref_pu_target():
        """
        レファレンス PU 対象を取得
        """
        dao_base = DAOBaseClass()
        pu_table = dao_base.fetch_all(table='tact.ref_pu', args={'select': 'puid, primary_pu_name'})
        # convert to upper case for puid
        pu_table['puid'] = pu_table['puid'].map(str.upper)
        ref_pu = pu_table.set_index('puid').to_dict()['primary_pu_name']

        return ref_pu

    def _apply_time_adjust(self):
        """
        Auto adjustment を計算
        """
        scan_loop_done = False
        perl_loop_done = False

        for mi in reversed(self.main_data):
            pu_code = mi['pu']
            call_pu = mi['call']
            # m_time = mi['time']
            m_start_time = mi['start']

            if scan_loop_done is False:
                for si in reversed(self.scan_data):
                    if pu_code == si['pu'] and call_pu == si['call']:
                        diff = int(m_start_time) - int(si['start'])
                        if app_config.THRESHOLD_AUTO_ADJUSTMENT > abs(diff):
                            self.scan_dif = diff
                            scan_loop_done = True
                            break

            if perl_loop_done is False:
                for pi in reversed(self.perl_data):
                    if pu_code == pi['pu'] and call_pu == pi['call']:
                        diff = int(m_start_time) - int(pi['start'])
                        if app_config.THRESHOLD_AUTO_ADJUSTMENT > abs(diff):
                            self.perl_dif = diff
                            perl_loop_done = True
                            break

            if scan_loop_done and perl_loop_done:
                break


