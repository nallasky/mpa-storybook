# coding:utf-8
import math
from common.utils.data_impoter_util import DataImpoterUtil
from common.utils import calculator
'''
---------------------------------------------
Update History:
    No3 AFC Drive Offset Pitch / Roll 他成分 Z LiPS Pitch 他成分Z（AFC計測時）
---------------------------------------------
'''


class LipsPitchOtherZ:
    # JSON化する項目
    event_id = 'LipsPitchOtherZEvent'
    event_time = 'event_time'
    # lips_pitch_other_z = 'lips_pitch_other_z'
    lips_pitch_other_z = 'afc_drive_lips_other_z_base'
    device = 'device'
    process = 'process'
    lot_id = 'lot_id'
    plate = 'plate_no'
    offset_left = 'offset_left'
    offset_right = 'offset_right'
    offset_center = 'offset_center'
    # plate_stage_x = 'plate_stage_x_'
    plate_stage_x = 'ps_x'
    # plate_stage_y = 'plate_stage_y_'
    plate_stage_y = 'ps_y'
    # plate_stage_z = 'plate_stage_z_'
    plate_stage_z = 'ps_z'
    # pitching = 'drive_pitching_'
    pitching = 'drive_pitch'
    # rolling = 'drive_rolling_'
    rolling = 'drive_roll'

    def __init__(self):
        """コンストラクタ
        """

    def calc_lips_pitch(self, plate_auto_focus_df, stage_position_df,
                        afcDriveOffsetZOutput, focusUtil):
        """AFC他成分の計算
        param plate_auto_focus_df AFCのRecallログ
        param stage_position_df StagePositionMonitorのRecallログ
        param afcDriveOffsetZOutput No2の計算結果
        param focusUtil Utilクラスのインスタンス
        """
        # 変数を初期化
        drive_pitching = 0
        drive_rolling = 0
        # plateStageDict = {}
        # StagePositionのデータからPS-X、PS-Y、PS-ZのAFC位置を取得する（メモ：AFC補正計算シートのC10～C12のデータ取得）
        # for devprokey in stagePositionDict:
        #     for fileCnt in stagePositionDict[devprokey]:
        #         lotdict = {}
        #         plateStageDict[devprokey] = lotdict
        #         plate_buff = 0
        #         for record in stagePositionDict[devprokey][fileCnt]:
        #             # 見づらいので置き換え
        #             data_dict = stagePositionDict[devprokey][fileCnt][record]
        #             stage_lot_id = data_dict[self.lot_id]
        #             plate = data_dict[self.plate]
        #             # plate_buffが初期値もしくは値が変わったか？
        #             if plate_buff == 0 or plate_buff != plate:
        #                 # Plateを更新
        #                 plate_buff = plate
        #                 plateStageZyzDict = {}
        #                 # PS-X AFC位置
        #                 plateStageZyzDict[self.plate_stage_x] = data_dict[self.plate_stage_x]
        #                 # PS-Y AFC位置
        #                 plateStageZyzDict[self.plate_stage_y] = data_dict[self.plate_stage_y]
        #                 # PS-Z AFC位置
        #                 plateStageZyzDict[self.plate_stage_z] = data_dict[self.plate_stage_z]
        #                 # eventtime（このクラスで返却する計算結果の時間に使用する）
        #                 plateStageZyzDict[self.event_time] = data_dict[self.event_time]
        #                 # device
        #                 plateStageZyzDict[self.device] = data_dict[self.device]
        #                 # process
        #                 plateStageZyzDict[self.process] = data_dict[self.process]
        #                 # lot_id
        #                 plateStageZyzDict[self.lot_id] = data_dict[self.lot_id]
        #                 # plate
        #                 plateStageZyzDict[self.plate] = data_dict[self.plate]
        #                 # キーが追加されていなければ追加
        #                 if stage_lot_id not in plateStageDict[devprokey].keys(
        #                 ):
        #                     plateStageDict[devprokey][stage_lot_id] = {}
        #                 # Dev/Pro{LotID{Plate{情報}}}の構成でデータをまとめる。
        #                 plateStageDict[devprokey][stage_lot_id][plate] = plateStageZyzDict
        devprokey = stage_position_df['job'].values[0]
        stage_lot_id = stage_position_df['lot_id'].values[0]
        plateStageDict = {
            devprokey: {
                stage_lot_id: {}
            }
        }

        gb = stage_position_df.groupby('plate_no')
        for plate, df in gb:
            plateStageZyzDict = {}
            # PS-X AFC位置
            plateStageZyzDict[self.plate_stage_x] = calculator.nm_to_um(df[self.plate_stage_x].values[0])
            # PS-Y AFC位置
            plateStageZyzDict[self.plate_stage_y] = calculator.nm_to_um(df[self.plate_stage_y].values[0])
            # PS-Z AFC位置
            plateStageZyzDict[self.plate_stage_z] = calculator.nm_to_um(df[self.plate_stage_z].values[0])
            # device
            plateStageZyzDict[self.device] = df[self.device].values[0]
            # process
            plateStageZyzDict[self.process] = df[self.process].values[0]
            # lot_id
            plateStageZyzDict[self.lot_id] = df[self.lot_id].values[0]
            # plate
            plateStageZyzDict[self.plate] = df[self.plate].values[0]

            # Dev/Pro{LotID{Plate{情報}}}の構成でデータをまとめる。
            plateStageDict[devprokey][stage_lot_id][plate] = plateStageZyzDict
        no2_data = None
        outputlist = []
        # 返却するデータ（N12計算用）
        outputcalcDict = {}

        # P[sec]の値取得
        # for devprokey in plate_auto_focus_df:
        #     # No2で取得したAfc Drive Offsetの値を取得
        #     if afcDriveOffsetZOutput is not None and devprokey in afcDriveOffsetZOutput:
        #         no2_data = afcDriveOffsetZOutput[devprokey]
        #     # No2の計算時にProcessデータが無い場合、以下の処理が実行される
        #     else:
        #         no2_data = {}
        #         # Processが無い場合、0で固定
        #         no2_data['offset_left'] = 0
        #         no2_data['offset_right'] = 0
        #         no2_data['offset_center'] = 0
        #         no2_data['afc_drive_offset_z'] = 0
        #     # G6でTP以外ならログからデータを取得
        #     if focusUtil.get_machine_type() == DataImpoterUtil.MACHINE_TYPE_E813_G6 \
        #             and not focusUtil.get_machine_category_tp():
        #         # ファイル単位でチェックし、リストに詰める
        #         for fileCnt in plateAutoFocusCompDict[devprokey]:
        #             plate_buff = 0
        #             for record in plateAutoFocusCompDict[devprokey][fileCnt]:
        #                 # 見づらいので置き換え
        #                 data_dict = plateAutoFocusCompDict[devprokey][fileCnt][record]
        #                 plate = data_dict[self.plate]
        #                 # plate_buffが初期値もしくは値が変わったか？
        #                 if plate_buff == 0 or plate_buff != plate:
        #                     # Plateを更新
        #                     plate_buff = plate
        #                     # P[sec]の値取得（メモ：AFC補正計算シートの34行の列名と対応している）
        #                     drive_pitching = data_dict[self.pitching]
        #                     # R[sec]の値取得
        #                     drive_rolling = data_dict[self.rolling]
        #                     # LotIDの取得
        #                     lotid = data_dict[self.lot_id]
        #                     # plateStageDict（StagePositionMonitor）とplateAutoFocusCompDictで一致する要素を取得
        #                     if devprokey in plateStageDict.keys():
        #                         if lotid in plateStageDict[devprokey]:
        #                             if plate in plateStageDict[devprokey][lotid]:
        #                                 # Plateごとに算出する
        #                                 # AFC他成分を算出してリストに詰める（メモ：AFC補正計算シートのI37あたりと対応している）
        #                                 self._calc_afc_other(drive_pitching, drive_rolling,
        #                                                      plateStageDict[devprokey][lotid][plate], no2_data, outputlist, focusUtil, outputcalcDict)
        #
        #     # G6でTP、もしくはそれ以外の機種の場合
        #     else:
        #         # P[sec]の値取得
        #         drive_pitching = -1 * \
        #             math.atan(
        #                 ((no2_data[self.offset_left] + no2_data[self.offset_right]) / 2 - no2_data[self.offset_center]) / focusUtil.get_fcs_tani()) / math.pi * 180 * 3600 / 1000
        #         # R[sec]の値取得
        #         drive_rolling = -1 * \
        #             math.atan(
        #                 (no2_data[self.offset_left] - no2_data[self.offset_right]) / focusUtil.get_fcs()) / math.pi * 180 * 3600 / 1000
        #         # plateStageDictの要素ごとに結果を出力
        #         for lotid in plateStageDict[devprokey]:
        #             for plate in plateStageDict[devprokey][lotid]:
        #                 # AFC他成分を算出してリストに詰める（メモ：AFC補正計算シートのI37あたりと対応している）
        #                 self._calc_afc_other(drive_pitching, drive_rolling,
        #                                      plateStageDict[devprokey][lotid][plate], no2_data, outputlist, focusUtil, outputcalcDict)

        # P[sec]の値取得
        job_list = plate_auto_focus_df['job'].unique().tolist()
        for job in job_list:
            # No2で取得したAfc Drive Offsetの値を取得
            devprokey = job
            if afcDriveOffsetZOutput is not None and devprokey in afcDriveOffsetZOutput:
                no2_data = afcDriveOffsetZOutput[devprokey]
            # No2の計算時にProcessデータが無い場合、以下の処理が実行される
            else:
                no2_data = {}
                # Processが無い場合、0で固定
                no2_data['offset_left'] = 0
                no2_data['offset_right'] = 0
                no2_data['offset_center'] = 0
                no2_data['afc_drive_z'] = 0
            # G6でTP以外ならログからデータを取得
            if focusUtil.get_machine_type() == DataImpoterUtil.MACHINE_TYPE_E813_G6 \
                    and not focusUtil.get_machine_category_tp():

                gb = plate_auto_focus_df.groupby('plate_no')
                for plate, df in gb:
                    # P[sec]の値取得（メモ：AFC補正計算シートの34行の列名と対応している）
                    drive_pitching = calculator.nm_to_um(df[self.pitching].values[0])
                    # R[sec]の値取得
                    drive_rolling = calculator.nm_to_um(df[self.rolling].values[0])
                    # LotIDの取得
                    lotid = df[self.lot_id].values[0]
                    # plateStageDict（StagePositionMonitor）とplateAutoFocusCompDictで一致する要素を取得
                    if devprokey in plateStageDict.keys():
                        if lotid in plateStageDict[devprokey]:
                            if plate in plateStageDict[devprokey][lotid]:
                                # Plateごとに算出する
                                # AFC他成分を算出してリストに詰める（メモ：AFC補正計算シートのI37あたりと対応している）
                                self._calc_afc_other(drive_pitching, drive_rolling,
                                                     plateStageDict[devprokey][lotid][plate], no2_data,
                                                     outputlist, focusUtil, outputcalcDict)

            # G6でTP、もしくはそれ以外の機種の場合
            else:
                # P[sec]の値取得
                drive_pitching = -1 * \
                                 math.atan(
                                     ((no2_data[self.offset_left] + no2_data[self.offset_right]) / 2 - no2_data[
                                         self.offset_center]) / focusUtil.get_fcs_tani()) / math.pi * 180 * 3600 / 1000
                # R[sec]の値取得
                drive_rolling = -1 * \
                                math.atan(
                                    (no2_data[self.offset_left] - no2_data[
                                        self.offset_right]) / focusUtil.get_fcs()) / math.pi * 180 * 3600 / 1000
                # plateStageDictの要素ごとに結果を出力
                for lotid in plateStageDict[devprokey]:
                    for plate in plateStageDict[devprokey][lotid]:
                        # AFC他成分を算出してリストに詰める（メモ：AFC補正計算シートのI37あたりと対応している）
                        self._calc_afc_other(drive_pitching, drive_rolling,
                                             plateStageDict[devprokey][lotid][plate], no2_data, outputlist, focusUtil,
                                             outputcalcDict)

        return outputlist, outputcalcDict

    def _calc_afc_other(self, drive_pitching, drive_rolling,
                        plateStageDict, no2_data, outputlist, focusUtil, outputcalcDict):
        """AFC他成分の計算
        param drive_pitching P[sec]の値
        param drive_rolling R[sec]の値
        param plateStageDict StagePositionのデータ
        param no2_data No2の計算結果
        param outputlist 返却するリスト
        param focusUtil Utilクラスのインスタンス
        param outputcalcDict 別クラスで使用する計算結果を保存する変数
        """
        # Pitch 他成分Z
        pitch_other = math.tan(
            drive_pitching / 3600 / 180 * math.pi) * (plateStageDict[self.plate_stage_y] + focusUtil.get_center_position_shift()) * 1000

        # Roll 他成分Z
        roll_other = math.tan(
            drive_rolling / 3600 / 180 * math.pi) * plateStageDict[self.plate_stage_x] * 1000

        pitch_gravity = 0
        # E813のみ重心差を求める（LK20-1371.pdfの資料P9より）
        if focusUtil.get_machine_type() == DataImpoterUtil.MACHINE_TYPE_E813_G6 or focusUtil.get_machine_type(
        ) == DataImpoterUtil.MACHINE_TYPE_E813_G5_5:
            # Pitch 重心差Z
            pitch_gravity = ((no2_data[self.offset_left] + no2_data[self.offset_right]) /
                             2 - no2_data[self.offset_center]) / focusUtil.get_fcs_tani() * focusUtil.get_center_of_gravity_diff()

        # AFC他成分
        afc_other = pitch_other - roll_other - pitch_gravity

        outputdict = {}
        outputdict['event_id'] = self.event_id
        outputdict[self.lips_pitch_other_z] = afc_other
        # outputdict[self.event_time] = plateStageDict[self.event_time]
        outputdict[self.device] = plateStageDict[self.device]
        outputdict[self.process] = plateStageDict[self.process]
        outputdict[self.lot_id] = plateStageDict[self.lot_id]
        outputdict[self.plate] = plateStageDict[self.plate]
        outputlist.append(outputdict)

        calcdict = {}
        calcdict[self.device] = plateStageDict[self.device]
        calcdict[self.process] = plateStageDict[self.process]
        calcdict[self.lot_id] = plateStageDict[self.lot_id]
        calcdict[self.plate] = plateStageDict[self.plate]
        calcdict[self.pitching] = drive_pitching
        calcdict[self.rolling] = drive_rolling
        calcdict[self.lips_pitch_other_z] = afc_other

        # ジョブ名[LotID名[plate[[計算結果]]]の形のdictにまとめる。No12で使用する
        devprokey = plateStageDict[self.device] + \
            '/' + plateStageDict[self.process]
        lotidkey = plateStageDict[self.lot_id]
        platekey = plateStageDict[self.plate]
        if devprokey not in outputcalcDict.keys():
            outputcalcDict[devprokey] = {}
        if lotidkey not in outputcalcDict[devprokey].keys():
            outputcalcDict[devprokey][lotidkey] = {}
        outputcalcDict[devprokey][lotidkey][platekey] = calcdict
