# coding:utf-8
'''
---------------------------------------------
Update History:
    No10 Position Offset PSZ
---------------------------------------------
'''


class PositionOffsetPsz:
    # JSON化する項目
    event_id = 'PositionOffsetPszEvent'
    # event_time = 'event_time'
    # device = 'device_'
    # process = 'process_'
    # ProcessデータStepタブのZ[um]の設定データコード。shot1（0x220D6）からshot36（0x22306）まで
    Z_UM_SET_CODE = 139478

    def __init__(self):
        """コンストラクタ
        """

    def calc_position_offset_psz(
            self, processDict, stepCountList, devprokey):
        """Position Offset PSZ取得処理
        param processDict Processデータ
        param stepCountList 行数
        """
        # 基準となる時間を取得
        # baseTime = eventTime.split('.')[0]
        cnt = 0
        outputlist = []
        stepCount = 0
        # if len(processDict) != 0:
        if devprokey in processDict:
            stepZumDict = {}
            # Step数とEachShotのデータを紐づける
            for num in range(1, 37):
                stepZumDict[num] = hex(self.Z_UM_SET_CODE).replace('0x', '')
                self.Z_UM_SET_CODE += 16
            # for devprokey in processDict:
            process_df = processDict[devprokey]
            outputdict = {}
            outputdict['event_id'] = self.event_id
            # outputdict['event_time'] = baseTime + \
            #     '.' + '{0:06d}'.format(cnt) + '+0900'
            # cnt += 1
            [device, process] = process_df['job'].values[0].split(sep='/')
            outputdict['device'] = device
            outputdict['process'] = process
            # DevProに合致するStep数を取得
            for stepData in stepCountList:
                stepCount = 0
                if stepData['device'] == device and \
                        stepData['process'] == process:
                    stepCount = stepData['step_count']
                    break

            for num in range(1, stepCount + 1):
                calc = process_df[process_df['key'] == stepZumDict[num]]['val'].values[0] / 1000
                outputdict['step' + str(num)] = calc
            outputlist.append(outputdict)
        else:
            outputdict = {}
            outputdict['event_id'] = self.event_id
            # outputdict['event_time'] = baseTime + \
            #     '.' + '{0:06d}'.format(cnt) + '+0900'
            # cnt += 1
            # Step数が不明のため最大数を表示
            for num in range(1, 37):
                outputdict['step' +
                           str(num)] = 0
            outputlist.append(outputdict)
        return outputlist
