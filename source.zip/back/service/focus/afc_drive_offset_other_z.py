# coding:utf-8
from common.utils import calculator
'''
---------------------------------------------
No.12 AFCDrive Offset Pitch/Roll 他成分Z
      LiPSPitch 他成分Z(露光準備時)
No.13 Mask / Plate Pre Scan Pitch / Roll 他成分Z
共通クラス

Update History:
    [2020/09/23] 新規作成

Copyright(C) Canon Inc. All right reserved.
---------------------------------------------
'''
import math


class AfcDriveOffsetOtherZ:
    """  AFCDrive Offset Pitch/Roll 他成分Z 取得Class """

    no12_event_id = 'AfcDriveOffsetOtherZEvent'
    no13_event_id = 'MaskPlatePreScanOtherZEvent'

    def __init__(self):
        """コンストラクタ
        """

    def calc_afc_drive_offset_other_z(
            self, stage_pos_monitor_data, data_no3_calc, data_no16_calc, focusUtil):
        """ AFCDrive Offset Pitch/Roll 他成分Z/LiPSPitch 他成分Z 補正取得

        Args:
            stage_pos_monitor_data: 　　stage_position_monitorデータ
            data_no3_calc:              No3で計算したP[sec]、R[sec]の値
            data_no16_calc:              No16で計算したP[sec]、R[sec]の値
            focusUtil                   Utilクラスのインスタンス
        """
        data_calc = {}
        # 返却するデータセット
        outputlist = []
        stage_ready_dict = self._create_stage_position_dict(
            stage_pos_monitor_data)

        # No3のデータがあればNo12の計算処理を行う
        # No3のデータが無ければ（No8のデータがあれば）No13の計算処理を行う
        if data_no3_calc is not None:
            data_calc = data_no3_calc
        elif data_no16_calc is not None:
            data_calc = data_no16_calc

        for devprokey in data_calc:
            # 計算クラスの各Dev/Pro、Lot、Plate情報がStagePositionにも含まれるか？
            if devprokey in stage_ready_dict:
                for lotidkey in data_calc[devprokey]:
                    if lotidkey in stage_ready_dict[devprokey]:
                        for platekey in data_calc[devprokey][lotidkey]:
                            # Step1のpitch。駆動量（他成分Zの計算）で使用する。Plateごとに更新
                            first_pitch = None
                            if platekey in stage_ready_dict[devprokey][lotidkey]:
                                # 見づらいので置き換える
                                data_dict = data_calc[devprokey][lotidkey][platekey]
                                drive_pitching = 0
                                drive_rolling = 0
                                if data_no3_calc is not None:
                                    # Pitch[sec]の取得
                                    drive_pitching = data_dict['drive_pitch']
                                    # Roll[sec]の取得
                                    drive_rolling = data_dict['drive_roll']
                                    first_pitch = drive_pitching
                                # Stepを昇順に並べ替え
                                sort_list = []
                                for step in stage_ready_dict[devprokey][lotidkey][platekey]:
                                    sort_list.append(step)
                                sort_list.sort()
                                # Stepごとに処理する
                                for step in sort_list:
                                    # stage_ready_dict[devprokey][lotidkey][platekey]:
                                    if data_no16_calc is not None:
                                        # Pitch[sec]の取得
                                        drive_pitching = data_dict[step]['pre_scan_pitch']
                                        # Roll[sec]の取得
                                        drive_rolling = data_dict[step]['pre_scan_roll']
                                        # Step1から固定で取得。無い場合は0
                                        if first_pitch is None and step == 1:
                                            first_pitch = data_dict[1]['pre_scan_pitch']
                                    # 見づらいので置き換える
                                    stage_dict = stage_ready_dict[devprokey][lotidkey][platekey][step]
                                    # Pitch 他成分Z[um]の計算
                                    pitch_calc = calculator.nm_to_um(stage_dict['ps_y']) * \
                                        math.tan(
                                        drive_pitching / 3600 / 180 * math.pi) * 1000
                                    # Roll 他成分Z[um]の計算
                                    roll_calc = - calculator.nm_to_um(stage_dict['ps_x']) * \
                                        math.tan(
                                        drive_rolling / 3600 / 180 * math.pi) * 1000
                                    # PreScan Shot Pitch/Roll他成分[um]
                                    calc_pitch_roll = pitch_calc + roll_calc
                                    # 中心位置ズレを計算
                                    center = focusUtil.get_center_position_shift(
                                    ) + focusUtil.get_center_of_gravity_diff()
                                    # 他成分Z
                                    other_z = -(center *
                                                math.tan(first_pitch / 180 / 3600 * math.pi)) * 1000
                                    # PreScan Shot Pitch/Roll他成分[um]+重心位置差
                                    calc_result = calc_pitch_roll - other_z
                                    # 演算結果をリストに設定
                                    outputdict = {}
                                    if data_no3_calc is not None:
                                        outputdict['event_id'] = self.no12_event_id
                                    elif data_no16_calc is not None:
                                        outputdict['event_id'] = self.no13_event_id
                                    # outputdict['event_time'] = stage_dict.get(
                                    #     'event_time')
                                    outputdict['device'] = stage_dict.get(
                                        'device')
                                    outputdict['process'] = stage_dict.get(
                                        'process')
                                    outputdict['plate_no'] = stage_dict.get(
                                        'plate_no')
                                    outputdict['step_no'] = stage_dict.get(
                                        'step_no')
                                    outputdict['lot_id'] = stage_dict.get(
                                        'lot_id')
                                    outputdict['afc_drive_other_z_expo'] = calc_result
                                    outputlist.append(outputdict)
        return outputlist

    def _create_stage_position_dict(self, stage_pos_monitor_data):
        """StagePositionMonitorのデータをまとめる
        """
        # stage_ready_dict = {}
        # 1データずつ取り出し
        # for devprokey in stage_pos_monitor_data:
        #     for fileCnt in stage_pos_monitor_data[devprokey]:
        #         # 1ファイルごとにplate stageを取得
        #         for record in stage_pos_monitor_data[devprokey][fileCnt]:
        #             # StagePositionMonitorの1レコードごとの取得
        #             data_dict = stage_pos_monitor_data[devprokey][fileCnt][record]
        #             pos = data_dict.get('pos_')
        #
        #             # Readyを参照してStep数をカウントする
        #             if(pos == 'Ready   '):
        #                 plateStageDict = {}
        #                 # Ready位置Xを取得
        #                 plateStageDict['plate_stage_x_'] = data_dict.get(
        #                     'plate_stage_x_')
        #                 # Ready位置Yを取得
        #                 plateStageDict['plate_stage_y_'] = data_dict.get(
        #                     'plate_stage_y_')
        #                 plateStageDict['lot_id_'] = data_dict.get(
        #                     'lot_id_')
        #                 plateStageDict['plate_'] = data_dict.get(
        #                     'plate_')
        #                 plateStageDict['step_'] = data_dict.get(
        #                     'step_')
        #                 plateStageDict['event_time'] = data_dict.get(
        #                     'event_time')
        #                 plateStageDict['device_'] = data_dict.get(
        #                     'device_')
        #                 plateStageDict['process_'] = data_dict.get(
        #                     'process_')
        #                 lotidkey = plateStageDict['lot_id_']
        #                 platekey = plateStageDict['plate_']
        #                 stepkey = plateStageDict['step_']
        #                 if devprokey not in stage_ready_dict.keys():
        #                     stage_ready_dict[devprokey] = {}
        #                 if lotidkey not in stage_ready_dict[devprokey].keys():
        #                     stage_ready_dict[devprokey][lotidkey] = {
        #                     }
        #                 if platekey not in stage_ready_dict[devprokey][lotidkey].keys(
        #                 ):
        #                     stage_ready_dict[devprokey][lotidkey][platekey] = {
        #                     }
        #                 # ジョブ名[LotID名[plate[[step[[計算結果]]]]の形のdictにまとめる。
        #                 stage_ready_dict[devprokey][lotidkey][platekey][stepkey] = plateStageDict
        devprokey = stage_pos_monitor_data['job'].values[0]
        lotidkey = stage_pos_monitor_data['lot_id'].values[0]
        stage_ready_dict = {
            devprokey: {
                lotidkey: {}
            }
        }

        target_df = stage_pos_monitor_data[stage_pos_monitor_data['position'] == 'Ready']
        for (plate_no, step_no), df in target_df.groupby(['plate_no', 'step_no']):
            if plate_no not in stage_ready_dict[devprokey][lotidkey]:
                stage_ready_dict[devprokey][lotidkey][plate_no] = dict()
            stage_ready_dict[devprokey][lotidkey][plate_no][step_no] = df[['ps_x', 'ps_y', 'lot_id', 'plate_no', 'step_no', 'device', 'process']].iloc[-1].to_dict()

        return stage_ready_dict
