# coding:utf-8
from common.utils.data_impoter_util import DataImpoterUtil

'''
---------------------------------------------
No.2 AFC Drive Offset Z

Update History:
    [2020/09/23] 新規作成

Copyright(C) Canon Inc. All right reserved.
---------------------------------------------
'''


class AfcDriveOffsetZ:
    """ AFC Drive Offset Z 取得Class """

    # AFC Drive Offset L/R/Cの設定データコード
    AFC_DRIVE_OFFSET_L = '00790'
    AFC_DRIVE_OFFSET_R = '00791'
    AFC_DRIVE_OFFSET_C = '00792'

    # イベントid
    event_id = 'AfcDriveOffsetZEvent'

    def __init__(self):
        """コンストラクタ
        """

    def calc_afc_drive_offset_z(
            self, process_data, machine_data, illmulti_table_data, focusUtil, devprokey):
        """ AFC Drive Offset Z 計算

        Args:
            process_data: 　　　　　　　processデータ
            machine_data:              machineデータ
            illmulti_table_data:        illmultiTableリコールログの最新データ
        """
        # 16Mode化licenseの取得
        license_16mode = machine_data['103CB']
        str_offset_l = self.AFC_DRIVE_OFFSET_L
        str_offset_r = self.AFC_DRIVE_OFFSET_R
        str_offset_c = self.AFC_DRIVE_OFFSET_C
        machine_type = focusUtil.get_machine_type()
        ill_mode = 0
        # 返却するデータセット（ES登録用）
        outputlist = []
        # 返却するデータセット（No3計算用）
        outputcalcDict = {}
        # 渡されたeventTimeの日時を取得し、返却する件数分event_timeをずらす
        # time_array = event_time.split('.')
        # event_idx = 0

        # 1データずつ取り出し
        # for key in process_data:
        if devprokey in process_data:
            data_df = process_data.get(devprokey)
            [device, process] = devprokey.split(sep='/')
            # H760か？
            if DataImpoterUtil.MACHINE_TYPE_H760 == machine_type:
                # ill_modeは0固定
                ill_mode = 0
            # H800か？
            elif DataImpoterUtil.MACHINE_TYPE_H800 == machine_type:
                # 16Mode化ライセンスが無効か？
                if license_16mode == 0:
                    ill_mode = 0
                else:
                    ill_mode = self._get_ill_mode(
                        data_df, illmulti_table_data)

            # E813(G6,G5.5)か？
            elif DataImpoterUtil.MACHINE_TYPE_E813_G5_5 == machine_type or DataImpoterUtil.MACHINE_TYPE_E813_G6 == machine_type:
                # カテゴリがTPか？
                if focusUtil.get_machine_category_tp():
                    ill_mode = 0
                else:
                    # IL TYPE2なら16Mode化ライセンスが無効ならHOME/AWAY。
                    # IL TYPE3なら16Mode化ライセンスが無効ならMode1,2,3。
                    # 有効ならModeになるが、取り方は変わらないため一律_get_ill_modeから取得
                    ill_mode = self._get_ill_mode(
                        data_df, illmulti_table_data)
            # H1000か？
            else:
                # 16Mode化ライセンスが無効か？
                if license_16mode == 0:
                    # ill_modeは0固定
                    ill_mode = 0
                else:
                    ill_mode = self._get_ill_mode(
                        data_df, illmulti_table_data)

            # Ill. Modeの値によってAFC Drive Offset L/R/Cの取得先設定データコードを決定する
            if(0 <= ill_mode <= 15):
                str_offset_l = self.AFC_DRIVE_OFFSET_L
                str_offset_r = self.AFC_DRIVE_OFFSET_R
                str_offset_c = self.AFC_DRIVE_OFFSET_C

                hex_int_offset_l = int(str_offset_l, 16)
                hex_int_offset_r = int(str_offset_r, 16)
                hex_int_offset_c = int(str_offset_c, 16)

                new_int_offset_l = hex_int_offset_l + (ill_mode * 3)
                new_int_offset_r = hex_int_offset_r + (ill_mode * 3)
                new_int_offset_c = hex_int_offset_c + (ill_mode * 3)

                hex_str_offset_l = format(new_int_offset_l, 'x')
                hex_str_offset_r = format(new_int_offset_r, 'x')
                hex_str_offset_c = format(new_int_offset_c, 'x')

                s_zero_offset_l = hex_str_offset_l.zfill(5)
                s_zero_offset_r = hex_str_offset_r.zfill(5)
                s_zero_offset_c = hex_str_offset_c.zfill(5)

                offset_left = machine_data.get(s_zero_offset_l.upper())
                offset_right = machine_data.get(s_zero_offset_r.upper())
                offset_center = machine_data.get(s_zero_offset_c.upper())

            else:
                # 不正なModeなのでOffset L/R/Cの値が取得できない
                offset_left = 0
                offset_right = 0
                offset_center = 0

            # Offset L/R/Cの値を16進⇒10進数に変換 + 1000で割る（5um→5000と出力されるため）
            offset_left = offset_left / 1000
            offset_right = offset_right / 1000
            offset_center = offset_center / 1000

            # Offset L/R/Cの値からAFC Drive Offset Zの値を計算する
            afc_drive_offset_z = (
                offset_left + offset_right + offset_center) / 3

            job_data = {}
            job_data['event_id'] = self.event_id
            # job_data['event_time'] = time_array[0] + \
            #     '.' + format(event_idx, '06') + '+0900'
            job_data['device'] = device
            job_data['process'] = process
            job_data['offset_left'] = offset_left
            job_data['offset_right'] = offset_right
            job_data['offset_center'] = offset_center
            job_data['afc_drive_z'] = afc_drive_offset_z
            outputlist.append(job_data)

            # No3計算用に別途登録
            outputcalcDict[device + '/' + process] = job_data

            # イベントTimeをリストの件数分ずらしていく
            # event_idx = event_idx + 1

        return outputlist, outputcalcDict

    def _get_ill_mode(self, data_df, illmulti_table_data):
        """ill modeの取得
        Args:
            data_dict:              processデータ
            illmulti_table_data:    illmultiTableリコールログの最新データ
        """
        # ill_multi_table_no = data_dict.get('303de')
        ill_multi_table_no = data_df[data_df['key'] == '303de']['val'].values[0]

        # ill Modeの初期値
        ill_mode = '0'

        if(ill_multi_table_no == 0):
            # Ill. Multi Table No=0(NOT USE)のとき
            # ill_mode = data_dict.get('12015')
            ill_mode = data_df[data_df['key'] == '12015']['val'].values[0]
        else:
            # Ill. Multi Table No=0(NOT USE)以外のとき
            for table_no in illmulti_table_data:
                # illmulti_tableのログデータから対象のtableNoのmodeを取得する
                if(int(table_no) == ill_multi_table_no):
                    illmultitbl_data = illmulti_table_data.get(
                        table_no)
                    ill_mode = illmultitbl_data.get('mode')

        # 値をString⇒intに変換する
        ill_mode = int(ill_mode)

        return ill_mode
