# coding:utf-8
from common.utils import calculator
"""
---------------------------------------------
No.14 AFC Drive Offset Pitch/Roll LiPSPitch

Update History:
    [2020/09/23] 新規作成

Copyright(C) Canon Inc. All right reserved.
---------------------------------------------
"""


class AfcDriveOffsetPitchRoll:
    """ AFC Drive Offset Pitch/Roll LiPSPitch取得Class """

    # JSON化する項目
    event_id = 'AfcDriveOffsetPitchRollEvent'

    def __init__(self):
        """コンストラクタ
        """

    def get_afc_drive_offset_pr(self, plate_auto_focus_df):
        """ AFC Drive Offset Pitch/Roll LiPSPitch取得

        Args:
            plate_afc_data: 　　plate_autofocus_compデータ
        """

        # 返却するデータセット
        outputlist = []

        # 1データずつ取り出し
        # for devprokey in plate_afc_data:
        #     lotIdList = {}
        #     plateDict = []
        #     for fileCnt in plate_afc_data[devprokey]:
        #         for record in plate_afc_data[devprokey][fileCnt]:
        #             # PlateAfcRecallの1レコードごとの取得
        #             data_dict = plate_afc_data[devprokey][fileCnt][record]
        #             plate = data_dict.get('plate_')
        #             step = data_dict.get('step_')
        #             lot_id = data_dict.get('lot_id_')
        #
        #             # plate毎の最初のStepの計測値をAFC DriveOffsetPitch/Rollとして取得
        #             # 既に同一Lot/Plateのデータを取得済みか？
        #             if lot_id in lotIdList:
        #                 plateDict = lotIdList[lot_id]
        #                 if plate in plateDict:
        #                     continue
        #             else:
        #                 plateDict = []
        #
        #             outputdict = {}
        #             outputdict['event_id'] = self.event_id
        #             outputdict['event_time'] = data_dict.get(
        #                 'event_time')
        #             outputdict['device_'] = data_dict.get('device_')
        #             outputdict['process_'] = data_dict.get('process_')
        #             outputdict['plate_'] = plate
        #             outputdict['step_'] = step
        #             outputdict['lot_id_'] = lot_id
        #             outputdict['afc_drive_offset_pitch'] = data_dict.get(
        #                 'drive_pitching_')
        #             outputdict['afc_drive_offset_roll'] = data_dict.get(
        #                 'drive_rolling_')
        #
        #             plateDict.append(plate)
        #             lotIdList[lot_id] = plateDict
        #
        #             outputlist.append(outputdict)
        plate_no_list = plate_auto_focus_df['plate_no'].unique().tolist()
        device = plate_auto_focus_df['device'].values[0]
        process = plate_auto_focus_df['process'].values[0]
        lot_id = plate_auto_focus_df['lot_id'].values[0]

        for plate_no in plate_no_list:
            target_df = plate_auto_focus_df[plate_auto_focus_df['plate_no'] == plate_no]

            outputdict = {}
            outputdict['event_id'] = self.event_id
            outputdict['device'] = device
            outputdict['process'] = process
            outputdict['plate_no'] = plate_no
            outputdict['step_no'] = target_df['step_no'].values[0]
            outputdict['lot_id'] = lot_id
            outputdict['afc_drive_pitch'] = calculator.nm_to_um(target_df['drive_pitch'].values[0])
            outputdict['afc_drive_roll'] = calculator.nm_to_um(target_df['drive_roll'].values[0])

            outputlist.append(outputdict)

        return outputlist
