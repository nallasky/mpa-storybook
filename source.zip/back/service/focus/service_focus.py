import os
import logging
import sqlite3
import pandas as pd
import math
import copy
import json
import traceback

from service.overlay.service_overlay_base import ServiceOverlayBase
from service.converter.convert_process import ConvertProcess
from common.utils.response import ResponseForm
from config import app_config
from dao.dao_file import FileDao
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from controller.converter.converter import create_request_id
from service.overlay import correction_param
from service.overlay.correction_conveter import CorrectionConverter
from common.utils import preprocessing
from common.utils import calculator
from common.utils.data_impoter_util import DataImpoterUtil
from service.focus.afc_drive_offset_z import AfcDriveOffsetZ
from service.focus.afc_drive_offset_pitch_roll import AfcDriveOffsetPitchRoll
from service.focus.lips_pitch_other_z import LipsPitchOtherZ
from service.focus.lips_correction_z import LipsCorrectionZ
from service.focus.each_shot_afc import EachShotAfc
from service.focus.pre_scan_pitch_roll_z import MaskPlatePreScanPitchRollZ
from service.focus.position_offset_psz import PositionOffsetPsz
from service.focus.plate_thickness_z import PlateThicknessZ
from service.focus.chuck_lock_afc_correction import ChuckLockAfcCorrection
from service.focus.afc_drive_offset_other_z import AfcDriveOffsetOtherZ
from service.focus.each_shot_pr_offset import EachShotPitchRollOffset
from service.focus.each_shot_pr_offset_otherz import EachShotPROffsetOtherZ
from service.focus.fc_base_psz import FcBasePSZ


logger = logging.getLogger(app_config.LOG)


class ServiceFocus:
    log_list = app_config.FOCUS_LOG_LIST
    category_name = 'Focus'

    # グラフタイプ
    GT_PSZ = 'psz'
    GT_PITCH = 'pitch'
    GT_ROLL = 'roll'

    # イベントID
    ES_STAGE_POSITION_MONITOR_EVENT = 'StagePositionMonitorEvent'
    ES_BASE_PSZ_EVENT = 'FcBasePSZEvent'
    ES_AFC_DRIVE_OFFSETZ_EVENT = 'AfcDriveOffsetZEvent'
    ES_LIPS_PITCH_OTHERZ_EVENT = 'LipsPitchOtherZEvent'
    ES_LIPS_CORRECTIONZ_EVENT = 'LipsCorrectionZEvent'
    ES_EACH_SHOT_AFC_EVENT = 'EachShotAfcEvent'
    ES_EACH_SHTO_PROOFFSET_OTHERA_EVENT = 'EachShotPROffsetOtherZEvent'
    ES_PLATE_THICKNESSZ_EVENT = 'PlateThicknessZEvent'
    # No.8　No.16と同じ(MaskPlatePreScanPitchRollZEvent)
    # No.9 なし
    ES_POSITION_OFFSET_PSZ_EVENT = 'PositionOffsetPszEvent'
    ES_CHUCK_LOCK_AFC_CORRECTION_EVENT = 'ChuckLockAfcCorrectionEvent'
    ES_AFC_DRIVE_OFFSET_OTHERZ_EVENT = 'AfcDriveOffsetOtherZEvent'
    ES_MASK_PLATE_PRE_SCAN_OTHERZ_EVENT = 'MaskPlatePreScanOtherZEvent'
    ES_AFC_DRIVE_OFFSET_PITCH_ROLL_EVENT = 'AfcDriveOffsetPitchRollEvent'
    ES_EACH_SHOT_PITCH_ROLL_OFFSET_EVENT = 'EachShotPitchRollOffsetEvent'
    ES_MASK_PLATE_PRE_SCAN_PITCH_ROLL_Z_EVENT = 'MaskPlatePreScanPitchRollZEvent'

    def __init__(self):
        self.root_path = app_config.root_path
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.category_name
        }

    def file_check(self, files):
        """

        :param files: [files]
        :return: {'log_name': [fids]}
        """
        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        # 最小必要ログチェック
        if app_config.RECALL_STAGE_POSITION not in files:
            return ResponseForm(res=False, msg='"Stage Position Monitor" Log must be included.')

        if not os.path.exists(self.root_path):
            os.mkdir(self.root_path)

        data = dict()

        for log_name, file_data in files.items():
            if file_data is None:
                continue
            # if log_name == app_config.LOG_UNKNOWN:
            #     log_name = app_config.RECALL_ADC_MEAS
            for file in file_data:
                filename = file.filename
                foldername = os.path.join(self.root_path, log_name)
                if not os.path.exists(foldername):
                    os.mkdir(foldername)
                if log_name not in data:
                    data[log_name] = list()
                f = None
                file_index = 1
                while f is None or os.path.exists(f):
                    _filename = f'{file_index}{app_config.UPLOAD_FILE_SEPERATOR}{filename}'
                    f = os.path.join(foldername, _filename)
                    file_index += 1
                file.save(f)
                fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))

                if fid is None:
                    logger.error('failed to store file info')
                    return ResponseForm(res=False, msg='failed to store file info')

                data[log_name].append(fid)

        return ResponseForm(res=True, data=data)

    def convert(self, logs):
        """

        :param logs: { 'log_name': [fids] }
        :return:
        """

        # Create Request ID
        self.form['id'] = create_request_id()

        file_id_list = list()
        for log_name, val in logs.items():
            file_id_list.append(','.join([str(_) for _ in logs[log_name]]))

        self.form['file'] = ','.join(file_id_list)

        # Insert Job info into cnvset.job
        io = DAOJob.instance()
        try:
            io.insert_job(**self.form)
        except Exception as e:
            logger.error('failed to insert job')
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

        # Create sub processor to convert log
        target_logs = dict()
        dao = DAOBaseClass()
        for log_name, val in logs.items():
            # #sqlite
            if isinstance(dao.connect, sqlite3.Connection):
                # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis_function as a " \
                #         f"inner join analysis_local_info as b on a.id = b.func_id) as c " \
                #         f"where system_func=true and log_name='{log_name}'"
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis_function as a " \
                        f"inner join analysis_local_info as b on a.id = b.func_id " \
                        f"inner join analysis_category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{log_name}' and title='{self.category_name}'"
            else:
                # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis.function as a " \
                #         f"inner join analysis.local_info as b on a.id = b.func_id) as c " \
                #         f"where system_func=true and log_name='{log_name}'"
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis.function as a " \
                        f"inner join analysis.local_info as b on a.id = b.func_id " \
                        f"inner join analysis.category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{log_name}' and title='{self.category_name}'"

            row = dao.execute(query)
            if row is None or len(row) == 0:
                return ResponseForm(res=False, msg=f'Cannot find {log_name} function.')

            target_logs[log_name] = row[0][0]

        cnv_proc = ConvertProcess(self.form['id'], target_logs)
        cnv_proc.start()

        return ResponseForm(res=True, data=self.form['id'])

    def get_focus_log_detail_data(self, args):
        log_dict = dict()

        filter = dict()
        filter['job'] = args['job']
        filter['lot_id'] = args['lot_id']

        log_dict = preprocessing.load_focus_log(rid=args['rid'], log_list=[app_config.RECALL_FOCUS_LOG_DETAIL], **filter)
        if app_config.RECALL_FOCUS_LOG_DETAIL not in log_dict:
            return ResponseForm(res=False, msg=f'{app_config.RECALL_FOCUS_LOG_DETAIL} Log is empty.')

        focus_df = log_dict[app_config.RECALL_FOCUS_LOG_DETAIL]

        filter = dict()
        filter['job'] = args['job']
        filter['lot_id'] = args['lot_id']
        filter['position'] = 'Ready'

        log_dict = preprocessing.load_focus_log(rid=args['rid'], log_list=[app_config.RECALL_STAGE_POSITION], **filter)
        if app_config.RECALL_STAGE_POSITION not in log_dict:
            return ResponseForm(res=False, msg=f'{app_config.RECALL_STAGE_POSITION} Log is empty.')
        else:
            stage_pos_df = log_dict[app_config.RECALL_STAGE_POSITION]
            stage_pos_dict_list = stage_pos_df.to_dict('records')

        stage_position_dic = dict()

        # StagePositionMonitorEvent(実位置取得用) lot_id, plate, shotを指定しても重複する場合があるので、event_timeの新しいものを使用する
        for record in stage_pos_dict_list:
            plate_no = str(record.get('plate_no', 0))
            step_no = str(record.get('step_no', 0))
            key = plate_no + '_' + step_no

            if key in stage_position_dic:
                # キーがあったらevent_timeの新しい方を有効にする
                if stage_position_dic[key]['log_time'] < record['log_time']:
                    stage_position_dic[key] = record
            else:
                # キーがなかったら追加
                stage_position_dic[key] = record

        graph_data = {'PS Pitch': list(), 'PS Roll': list(), 'PS Z': list()}
        focus_dict_list = focus_df.to_dict('records')
        for dict_data in focus_dict_list:
            stage_pos = dict()
            plate_no = str(dict_data.get('plate_no', 0))
            step_no = str(dict_data.get('step_no', 0))
            stage_pos_key = plate_no + '_' + step_no
            if stage_pos_key in stage_position_dic:
                stage_pos = stage_position_dic[stage_pos_key]

            # Pitchの場合
            afc_drive_pitch = dict_data.get('afc_drive_pitch', 0)
            each_shot_pitch = dict_data.get('each_shot_pitch', 0)
            pre_scan_pitch = dict_data.get('pre_scan_pitch', 0)
            afc_drive_diff_pitch = dict_data.get('afc_drive_diff_pitch', None)
            expoready_pitch_calc = dict_data.get('expo_ready_pitch', 0)
            if len(stage_pos) != 0:
                # expo_ready_pitch = stage_pos.get('plate_stage_pitching', 0)
                expo_ready_pitch = stage_pos.get('ps_pitch', 0)
            else:
                expo_ready_pitch = 0
            other_pitch = float(expoready_pitch_calc) - float(expo_ready_pitch)
            other_pitch_format = float('{:.4f}'.format(calculator.nm_to_um(other_pitch)))

            graph_data['PS Pitch'].append({
                'plate': dict_data.get('plate_no', 0),
                'shot': dict_data.get('step_no', 0),
                'glass_id': dict_data.get('glass_id', None),
                'AFC_Drive_Offset_Pitch': calculator.nm_to_um(float(afc_drive_pitch)),
                'Each_Shot_Pitch_Offset_i': calculator.nm_to_um(float(each_shot_pitch)),
                'Mask_Plate_PreScan_Pitch_i': calculator.nm_to_um(float(pre_scan_pitch)),
                'AFC_Drive_Diff_Pitch': calculator.nm_to_um(float(afc_drive_diff_pitch) if not pd.isna(afc_drive_diff_pitch) else 0),
                # 'ExporeadyPitch_Calc': calculator.nm_to_um(float(expoready_pitch_calc)),
                'Expoready_Pitch': calculator.nm_to_um(float(expo_ready_pitch)),
                'Other': other_pitch_format
            })

            # Rollの場合
            afc_drive_roll = dict_data.get('afc_drive_roll', 0)
            each_shot_roll = dict_data.get('each_shot_roll', 0)
            pre_scan_roll = dict_data.get('pre_scan_roll', 0)
            afc_drive_diff_roll = dict_data.get('afc_drive_diff_roll', None)
            expoready_roll_calc = dict_data.get('expoready_roll', 0)
            if len(stage_pos) != 0:
                # expoready_roll = stage_pos.get('plate_stage_rolling_', 0)
                expoready_roll = stage_pos.get('ps_roll', 0)
            else:
                expoready_roll = 0

            other_roll = float(expoready_roll_calc) - float(expoready_roll)
            other_roll_format = float('{:.4f}'.format(calculator.nm_to_um(float(other_roll))))

            graph_data['PS Roll'].append({
                'plate': dict_data.get('plate_no', 0),
                'shot': dict_data.get('step_no', 0),
                'glass_id': dict_data.get('glass_id', None),
                'AFC_Drive_Offset_Roll': calculator.nm_to_um(float(afc_drive_roll)),
                'Each_Shot_Roll_Offset_i': calculator.nm_to_um(float(each_shot_roll)),
                'Mask_Plate_PreScan_Roll_i': calculator.nm_to_um(float(pre_scan_roll)),
                'AFC_Drive_Diff_Roll': calculator.nm_to_um(float(afc_drive_diff_roll) if not pd.isna(afc_drive_diff_roll) else 0),
                # 'ExporeadyRoll_Calc': calculator.nm_to_um(float(expoready_roll_calc)),
                'Expoready_Roll': calculator.nm_to_um(float(expoready_roll)),
                'Other': other_roll_format,
            })

            # PSZの場合
            afc_base_z = dict_data.get('afc_base_z', 0)
            afc_drive_z = dict_data.get('afc_drive_z', 0)
            afc_drive_lips_other_z_base = dict_data.get('afc_drive_lips_other_z_base', 0)
            lips_z = dict_data.get('lips_z', 0)
            each_shot = dict_data.get('each_shot', 0)
            each_shot_p_r_other_z_fine = dict_data.get('each_shot_p_r_other_z_fine', 0)
            plate_thick_z = dict_data.get('plate_thick_z', 0)
            pre_scanz = dict_data.get('pre_scanz', 0)
            mag_other = dict_data.get('mag_otherz', 0)
            pos_offset_z = dict_data.get('pos_offset_z', 0)
            chuck_lock_z = dict_data.get('chuck_lock_z', 0)
            afc_drive_other_z_expo = dict_data.get('afc_drive_other_z_expo', 0)
            pre_scan_other_z = dict_data.get('pre_scan_other_z', 0)
            afc_drive_diff_z = dict_data.get('afc_drive_diff_z', None)
            exporeadyz_calc = dict_data.get('expo_ready_z', 0)
            if len(stage_pos) != 0:
                # expo_Ready_z = stage_pos.get('plate_stage_z_', 0) * 1000
                expo_Ready_z = float(stage_pos.get('ps_z', 0)) * 1000
            else:
                expo_Ready_z = 0

            other_z = float(exporeadyz_calc) - float(expo_Ready_z)

            other_z_format = float('{:.4f}'.format(calculator.nm_to_um(float(other_z))))

            graph_data['PS Z'].append({
                'plate': dict_data.get('plate_no', 0),
                'shot': dict_data.get('step_no', 0),
                'glass_id': dict_data.get('glass_id', None),
                'AFC_Base_PSZ': calculator.nm_to_um(float(afc_base_z)),
                'AFC_Drive_Offset_Z': calculator.nm_to_um(float(afc_drive_z)),
                'LiPS_Pitch_Other_Z_i': calculator.nm_to_um(float(afc_drive_lips_other_z_base)),
                'LiPS_PSZ': calculator.nm_to_um(float(lips_z)),
                'Each_Shot_AFC_i': calculator.nm_to_um(float(each_shot)),
                'Each_Shot_P/R_Offset_Other_Z_i': calculator.nm_to_um(float(each_shot_p_r_other_z_fine)),
                'Plate_Thickness_Z_i': calculator.nm_to_um(float(plate_thick_z)),
                'Mask_Plate_PreScan_Z_i': calculator.nm_to_um(float(pre_scanz)),
                'Mag_Other_Z': calculator.nm_to_um(float(mag_other)),
                'Position_Offset_Z_i': calculator.nm_to_um(float(pos_offset_z)),
                'Chuck_Lock_AFC_Z': calculator.nm_to_um(float(chuck_lock_z)),
                'AFC_Drive_Offset_Other_Z_i': calculator.nm_to_um(float(afc_drive_other_z_expo)),
                'Mask_Plate_PreScan_Other_Z_i': calculator.nm_to_um(float(pre_scan_other_z)),
                'AFC_Drive_Diff_Z': calculator.nm_to_um(float(afc_drive_diff_z) if not pd.isna(afc_drive_diff_z) else 0),
                'Other': other_z_format,
                # 'ExporeadyZ_Calc': calculator.nm_to_um(float(exporeadyz_calc)),
                'Expoready_Z': calculator.nm_to_um(float(expo_Ready_z))
            })

        return ResponseForm(res=True, data=graph_data)

    def get_focus_data(self, args):
        dataImpoterUtil = DataImpoterUtil()
        log_dict = dict()
        event_data_dict = dict()
        filter = dict()
        # filter['job'] = args['job']
        # filter['lot_id'] = args['lot_id']

        log_dict = preprocessing.load_focus_log(rid=args['rid'], log_list=[app_config.RECALL_MACHINE,
                                                                           app_config.RECALL_PROCESS,
                                                                           app_config.RECALL_ILLTABLE],
                                                **filter)
        # machine_df = log_dict[app_config.RECALL_MACHINE]
        # if len(machine_df) == 0:
        #     return ResponseForm(res=False, msg=f'{app_config.RECALL_MACHINE} Log is empty.')

        # machineデータをUtilに設定
        machine_dict = dict()
        if app_config.RECALL_MACHINE in log_dict:
            machine_df = log_dict[app_config.RECALL_MACHINE]
            machine_df['val'] = machine_df['val'].astype('int64')
            machine_dict = machine_df.set_index('key')['val'].to_dict()
            dataImpoterUtil.set_machine_data(machine_dict)
        if app_config.RECALL_PROCESS in log_dict:
            dataImpoterUtil.set_process_data(log_dict[app_config.RECALL_PROCESS])
        if app_config.RECALL_ILLTABLE in log_dict:
            dataImpoterUtil.set_ill_table_data(log_dict[app_config.RECALL_ILLTABLE])

        filter = dict()
        filter['job'] = args['job']
        filter['lot_id'] = args['lot_id']

        log_dict = preprocessing.load_focus_log(rid=args['rid'], log_list=[app_config.RECALL_STAGE_POSITION,
                                                                           app_config.RECALL_PLATE_AUTO_FOCUS,
                                                                           app_config.RECALL_PRE_SCAN_COMP],
                                                **filter)
        if app_config.RECALL_STAGE_POSITION not in log_dict:
            return ResponseForm(res=False, msg=f'{app_config.RECALL_STAGE_POSITION} Log is empty.')

        stage_pos_df = log_dict[app_config.RECALL_STAGE_POSITION]
        stepCountList = dataImpoterUtil.get_step_count_list(stage_pos_df)

        # 計算クラスのインスタンス生成（No2）
        afcDriveOffsetZ = AfcDriveOffsetZ()
        afcDriveOffsetZOutput = None
        afcDriveOffsetZDict = None
        try:
            # ProcessデータとIlluminanceMultiTableが0でなければ計算実施
            if len(dataImpoterUtil.get_process_dict()) != 0 and len(
                    dataImpoterUtil.get_machine_dict()) != 0:
                logger.info('No2 AfcDriveOffsetZ Start.')
                afcDriveOffsetZOutput, afcDriveOffsetZDict = afcDriveOffsetZ.calc_afc_drive_offset_z(
                    dataImpoterUtil.get_process_dict(),
                    dataImpoterUtil.get_machine_dict(),
                    dataImpoterUtil.get_ill_table_dict(),
                    dataImpoterUtil,
                    args['job']
                )
                event_data_dict[afcDriveOffsetZ.event_id] = afcDriveOffsetZOutput
                logger.info('No2 AfcDriveOffsetZ End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No2 AfcDriveOffsetZ Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No14）
        afcDriveOffsetPitchRoll = AfcDriveOffsetPitchRoll()
        afcDriveOffsetPitchRolloutput = None
        try:
            if app_config.RECALL_PLATE_AUTO_FOCUS in log_dict:
                logger.info('No14 AfcDriveOffsetPitchRoll Start.')
                afcDriveOffsetPitchRolloutput = afcDriveOffsetPitchRoll.get_afc_drive_offset_pr(
                    log_dict[app_config.RECALL_PLATE_AUTO_FOCUS])
                event_data_dict[afcDriveOffsetPitchRoll.event_id] = afcDriveOffsetPitchRolloutput
                logger.info('No14 AfcDriveOffsetPitchRoll End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No14 AfcDriveOffsetPitchRoll Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No3）
        lipsPitchOtherZ = LipsPitchOtherZ()
        lipsPitchOtherZOutput = None
        lipsPitchOtherZDict = None
        try:
            if app_config.RECALL_PLATE_AUTO_FOCUS in log_dict and app_config.RECALL_STAGE_POSITION in log_dict and \
                    (len(dataImpoterUtil.get_machine_dict()) != 0):
                logger.info('No3 LipsPitchOtherZ Start.')
                lipsPitchOtherZOutput, lipsPitchOtherZDict = lipsPitchOtherZ.calc_lips_pitch(
                    log_dict[app_config.RECALL_PLATE_AUTO_FOCUS],
                    log_dict[app_config.RECALL_STAGE_POSITION],
                    afcDriveOffsetZDict,
                    dataImpoterUtil)
                event_data_dict[lipsPitchOtherZ.event_id] = lipsPitchOtherZOutput
                logger.info('No3 LipsPitchOtherZ End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No3 LipsPitchOtherZ Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No4）
        lipsCorrectionZ = LipsCorrectionZ()
        lipsCorrectionZoutput = None
        lipsCorrectionZDict = None
        try:
            if app_config.RECALL_PLATE_AUTO_FOCUS in log_dict:
                logger.info('No4 LipsCorrectionZ Start.')
                lipsCorrectionZoutput, lipsCorrectionZDict = lipsCorrectionZ.calc_afc_drive_offset_z(
                    log_dict[app_config.RECALL_PLATE_AUTO_FOCUS])
                event_data_dict[lipsCorrectionZ.event_id] = lipsCorrectionZoutput
                logger.info('No4 LipsCorrectionZ End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No4 LipsCorrectionZ Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No5）
        eachShotAfc = EachShotAfc()
        eachShotAfcoutput = None
        try:
            if app_config.RECALL_PLATE_AUTO_FOCUS in log_dict:
                logger.info('No5 EachShotAfc Start.')
                eachShotAfcoutput = eachShotAfc.calc_each_shot_afc(
                    log_dict[app_config.RECALL_PLATE_AUTO_FOCUS], dataImpoterUtil.get_process_dict())
                event_data_dict[eachShotAfc.event_id] = eachShotAfcoutput
                logger.info('No5 EachShotAfc End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No5 EachShotAfc Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No8,16）
        maskPlatePreScanPitchRollZ = MaskPlatePreScanPitchRollZ()
        maskPlatePreScanPitchRollZoutput = None
        maskPlatePreScanPitchRollZDict = None
        try:
            if app_config.RECALL_PRE_SCAN_COMP in log_dict:
                logger.info('No8,16 MaskPlatePreScanPitchRollZ Start.')
                maskPlatePreScanPitchRollZoutput, maskPlatePreScanPitchRollZDict = \
                    maskPlatePreScanPitchRollZ.get_pre_scan_pr_z(log_dict[app_config.RECALL_PRE_SCAN_COMP])
                event_data_dict[maskPlatePreScanPitchRollZ.event_id] = maskPlatePreScanPitchRollZoutput
                logger.info('No8,16 MaskPlatePreScanPitchRollZ End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No8,16 MaskPlatePreScanPitchRollZ Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No10）
        positionOffsetPsz = PositionOffsetPsz()
        positionOffsetPszoutput = None
        try:
            logger.info('No10 PositionOffsetPsz Start.')
            positionOffsetPszoutput = positionOffsetPsz.calc_position_offset_psz(
                dataImpoterUtil.get_process_dict(), stepCountList, args['job'])
            event_data_dict[positionOffsetPsz.event_id] = positionOffsetPszoutput
            logger.info('No10 PositionOffsetPsz End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No10 PositionOffsetPsz Error: %s', e)
            logger.error(traceback.print_exc())

        filter = dict()
        filter['job'] = args['job']

        interlock_log_dict = preprocessing.load_focus_log(rid=args['rid'], log_list=[app_config.RECALL_PLATE_FOCUS], **filter)

        # 計算クラスのインスタンス生成（No7）
        plateThicknessZ = PlateThicknessZ()
        plateThicknessZoutput = None
        try:
            if app_config.RECALL_PLATE_FOCUS in interlock_log_dict:
                logger.info('No7 PlateThicknessZ Start.')
                plateThicknessZoutput = plateThicknessZ.calc_plate_thickness_z(
                    interlock_log_dict[app_config.RECALL_PLATE_FOCUS], dataImpoterUtil, stepCountList)
                event_data_dict[plateThicknessZ.event_id] = plateThicknessZoutput
                logger.info('No7 PlateThicknessZ End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No7 PlateThicknessZ Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No11）
        chuckLockAfcCorrection = ChuckLockAfcCorrection()
        chuckLockAfcCorrectionoutput = None
        try:
            if app_config.RECALL_PLATE_AUTO_FOCUS in log_dict:
                logger.info('No11 ChuckLockAfcCorrection Start.')
                chuckLockAfcCorrectionoutput = chuckLockAfcCorrection.calc_chuck_lock_afc_correction(
                    log_dict[app_config.RECALL_PLATE_AUTO_FOCUS], dataImpoterUtil.get_process_dict())
                event_data_dict[chuckLockAfcCorrection.event_id] = chuckLockAfcCorrectionoutput
                logger.info('No11 ChuckLockAfcCorrection End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No11 ChuckLockAfcCorrection Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No12）
        afcDriveOffsetOtherZ = AfcDriveOffsetOtherZ()
        afcDriveOffsetOtherZoutput = None
        try:
            if app_config.RECALL_STAGE_POSITION in log_dict and len(
                    dataImpoterUtil.get_machine_dict()) != 0 and lipsPitchOtherZDict is not None:
                logger.info('No12 AfcDriveOffsetOtherZ Start.')
                afcDriveOffsetOtherZoutput = afcDriveOffsetOtherZ.calc_afc_drive_offset_other_z(
                    log_dict[app_config.RECALL_STAGE_POSITION], lipsPitchOtherZDict, None, dataImpoterUtil)
                event_data_dict[afcDriveOffsetOtherZ.no12_event_id] = afcDriveOffsetOtherZoutput
                logger.info('No12 AfcDriveOffsetOtherZ End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No12 AfcDriveOffsetOtherZ Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No13）
        afcDriveOffsetOtherZ = AfcDriveOffsetOtherZ()
        maskPlatePreScanOtherZoutput = None
        try:
            if app_config.RECALL_STAGE_POSITION in log_dict and len(
                    dataImpoterUtil.get_machine_dict()) != 0 and maskPlatePreScanPitchRollZDict is not None:
                logger.info('No13 AfcDriveOffsetOtherZ Start.')
                maskPlatePreScanOtherZoutput = afcDriveOffsetOtherZ.calc_afc_drive_offset_other_z(
                    log_dict[app_config.RECALL_STAGE_POSITION], None, maskPlatePreScanPitchRollZDict, dataImpoterUtil)
                event_data_dict[afcDriveOffsetOtherZ.no13_event_id] = maskPlatePreScanOtherZoutput
                logger.info('No13 AfcDriveOffsetOtherZ End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No13 AfcDriveOffsetOtherZ Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No15）
        eachShotPitchRollOffset = EachShotPitchRollOffset()
        eachShotPitchRollOffsetoutput = None
        try:
            logger.info('No15 EachShotPitchRollOffset Start.')
            eachShotPitchRollOffsetoutput = eachShotPitchRollOffset.get_each_shot_pr_offset(
                dataImpoterUtil.get_process_dict(), stepCountList, args['job'])
            event_data_dict[eachShotPitchRollOffset.event_id] = eachShotPitchRollOffsetoutput
            logger.info('No15 EachShotPitchRollOffset End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No15 EachShotPitchRollOffset Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No6）
        eachShotPROffsetOtherZ = EachShotPROffsetOtherZ()
        eachShotPROtherZoutputPreDict = None
        eachShotPROtherZoutputFine = None
        try:
            if app_config.RECALL_STAGE_POSITION in log_dict and len(dataImpoterUtil.get_machine_dict()) != 0:
                logger.info('No6 EachShotPROffsetOtherZ Start.')
                eachShotPROtherZoutputPreDict, eachShotPROtherZoutputFine = \
                    eachShotPROffsetOtherZ.get_each_shot_pr_offset_other_z(
                        dataImpoterUtil.get_process_dict(), log_dict[app_config.RECALL_STAGE_POSITION], dataImpoterUtil)
                event_data_dict[eachShotPROffsetOtherZ.event_id] = eachShotPROtherZoutputFine
                logger.info('No6 EachShotPROffsetOtherZ End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No6 EachShotPROffsetOtherZ Error: %s', e)
            logger.error(traceback.print_exc())

        # 計算クラスのインスタンス生成（No1）
        fcBasePSZ = FcBasePSZ()
        fcBasePSZOutput = None
        try:
            if app_config.RECALL_PLATE_AUTO_FOCUS in log_dict:
                logger.info('No1 FcBasePSZ Start.')
                fcBasePSZOutput = fcBasePSZ.calc_fc_base_psz(
                    dataImpoterUtil.get_process_dict(), log_dict[app_config.RECALL_PLATE_AUTO_FOCUS],
                    afcDriveOffsetZDict, lipsPitchOtherZDict, lipsCorrectionZDict, eachShotPROtherZoutputPreDict)
                event_data_dict[fcBasePSZ.event_id] = fcBasePSZOutput
                logger.info('No1 FcBasePSZ End.')
        except Exception as e:
            # 上記計算処理でエラーが発生した場合
            logger.error('No1 FcBasePSZ Error: %s', e)
            logger.error(traceback.print_exc())

        graph_data = {'PS Pitch': list(), 'PS Roll': list(), 'PS Z': list()}

        filter = dict()
        filter['job'] = args['job']
        filter['lot_id'] = args['lot_id']
        filter['position'] = 'Ready'

        log_dict = preprocessing.load_focus_log(rid=args['rid'], log_list=[app_config.RECALL_STAGE_POSITION], **filter)
        if app_config.RECALL_STAGE_POSITION not in log_dict:
            return ResponseForm(res=False, msg=f'There is no "Ready" Position data in {app_config.RECALL_STAGE_POSITION} Log.')
        stage_pos_df = log_dict[app_config.RECALL_STAGE_POSITION]

        stage_position_dic = dict()
        event_data_dict[self.ES_STAGE_POSITION_MONITOR_EVENT] = stage_pos_df.to_dict('records')

        graph_data['PS Pitch'] = self.create_pitch_roll_data(event_data_dict, self.GT_PITCH)
        graph_data['PS Roll'] = self.create_pitch_roll_data(event_data_dict, self.GT_ROLL)
        graph_data['PS Z'] = self.create_psz_data(event_data_dict)

        return ResponseForm(res=True, data=graph_data)

    def create_pitch_roll_data(self, event_data_dict, graph_type):
        """
        pitchデータを作成
        """
        logger.info('---[FocusGraph] create_pitch_roll_data in')

        # AfcDriveOffsetPitchRollEvent(No.14)はshot1のデータのみ使用
        afc_shot1_dict = {}
        if self.ES_AFC_DRIVE_OFFSET_PITCH_ROLL_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_pitch_roll_data AfcDriveOffsetPitchRollEvent(No.14)')
            for afc_source in event_data_dict[self.ES_AFC_DRIVE_OFFSET_PITCH_ROLL_EVENT]:
                # afc_source = afc_row['_source']
                if afc_source.get('step_no', 0) == 1:
                    logger.info('---[FocusGraph] create_pitch_roll_data step1')
                    if graph_type == self.GT_PITCH:
                        logger.info('---[FocusGraph] create_pitch_roll_data AfcDriveOffsetPitchRollEvent pitch')
                        afc_shot1_dict[afc_source.get('plate_no', 0)] = afc_source.get('afc_drive_pitch', 0)
                    else:
                        logger.info('---[FocusGraph] create_pitch_roll_data AfcDriveOffsetPitchRollEvent roll')
                        afc_shot1_dict[afc_source.get('plate_no', 0)] = afc_source.get('afc_drive_roll', 0)

        # EachShotPitchRollOffsetEvent(No.15)は全てのプレートで同じ値を使用
        each_shot_source = {}
        # for each_shot_row in event_data_dict[self.ES_EACH_SHOT_PITCH_ROLL_OFFSET_EVENT]:
        #     each_shot_source = each_shot_row['_source']
        #     break
        if self.ES_EACH_SHOT_PITCH_ROLL_OFFSET_EVENT in event_data_dict:
            if len(event_data_dict[self.ES_EACH_SHOT_PITCH_ROLL_OFFSET_EVENT]) > 0:
                logger.info('---[FocusGraph] create_pitch_roll_data EachShotPitchRollOffsetEvent(No.15)')
                each_shot_source = event_data_dict[self.ES_EACH_SHOT_PITCH_ROLL_OFFSET_EVENT][0]

        # MaskPlatePreScanPitchRollZEvent(No.16)はPlate,shotごとに値があるがユーザによってはない場合もある
        # prescan_pitch_roll_source = {}
        prescan_dict = {}
        if self.ES_MASK_PLATE_PRE_SCAN_PITCH_ROLL_Z_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_pitch_roll_data MaskPlatePreScanPitchRollZEvent(No.16)')
            for prescan_pitch_roll_source in event_data_dict[self.ES_MASK_PLATE_PRE_SCAN_PITCH_ROLL_Z_EVENT]:
                # prescan_pitch_roll_source = prescan_row['_source']
                plate = str(prescan_pitch_roll_source.get('plate_no', 0))
                shot = str(prescan_pitch_roll_source.get('step_no', 0))
                if graph_type == self.GT_PITCH:
                    logger.info('---[FocusGraph] create_pitch_roll_data MaskPlatePreScanPitchRollZEvent pitch')
                    prescan_dict[plate + '_' + shot] = prescan_pitch_roll_source.get('pre_scan_pitch', 0)
                else:
                    logger.info('---[FocusGraph] create_pitch_roll_data MaskPlatePreScanPitchRollZEvent roll')
                    prescan_dict[plate + '_' + shot] = prescan_pitch_roll_source.get('prescan_roll', 0)

        # StagePositionMonitorEvent(実位置取得用) lot_id, plate, shotを指定しても重複する場合があるので、event_timeの新しいものを使用する
        stage_position_dic = {}
        for source in event_data_dict[self.ES_STAGE_POSITION_MONITOR_EVENT]:
            logger.info('---[FocusGraph] create_pitch_roll_data StagePositionMonitorEvent')
            # source = data_row['_source']
            plate = str(source.get('plate_no', 0))
            shot = str(source.get('step_no', 0))
            key = plate + '_' + shot

            if (key in stage_position_dic):
                logger.info('---[FocusGraph] create_pitch_roll_data StagePositionMonitorEvent key duplicate')
                # キーがあったらevent_timeの新しい方を有効にする
                if (stage_position_dic[key].get('log_time') < source.get('log_time')):
                    stage_position_dic[key] = source
            else:
                logger.info('---[FocusGraph] create_pitch_roll_data StagePositionMonitorEvent key none')
                # キーがなかったら追加
                stage_position_dic[key] = source

        data_list = []
        # StagePositionMonitorEvent(実位置取得用)を基準にplate、shotを決めてデータを整形する
        for key in stage_position_dic:
            data_dict = dict()

            # source = data_row['_source']
            source = stage_position_dic[key]
            plate = source.get('plate_no', 0)
            shot = source.get('step_no', 0)
            glass_id = source.get('glass_id', None)

            data_dict['plate'] = plate
            data_dict['shot'] = shot
            data_dict['glass_id'] = glass_id

            # StagePositionMonitorEventから実位置取得
            if (graph_type == self.GT_PITCH):
                logger.info('---[FocusGraph] create_pitch_roll_data StagePositionMonitorEvent pitch set')
                real_pitch_roll = calculator.nm_to_um(source.get('ps_pitch', 0))
                each_shot_key = 'step' + str(shot) + '_pitch'
                item_name = 'Pitch'
            else:
                logger.info('---[FocusGraph] create_pitch_roll_data StagePositionMonitorEvent roll set')
                real_pitch_roll = calculator.nm_to_um(source.get('ps_roll', 0))
                each_shot_key = 'step' + str(shot) + '_roll'
                item_name = 'Roll'

            # AfcDriveOffsetPitchRollEvent(No.14)取得
            no14 = afc_shot1_dict.get(plate, 0)
            if self.ES_AFC_DRIVE_OFFSET_PITCH_ROLL_EVENT in event_data_dict:
                data_dict['AFC_Drive_Offset_' + item_name] = no14

            # Each_Shot_Pitch_Offset_i /Each_Shot_roll_Offset_i　(No.15)取得
            no15 = float(each_shot_source.get(each_shot_key, 0))
            if self.ES_EACH_SHOT_PITCH_ROLL_OFFSET_EVENT in event_data_dict:
                data_dict['Each_Shot_' + item_name + '_Offset_i'] = no15

            # MaskPlatePreScanPitchRollZEvent(No.16)取得
            no16 = prescan_dict.get(str(plate) + '_' + str(shot), 0)
            if self.ES_MASK_PLATE_PRE_SCAN_PITCH_ROLL_Z_EVENT in event_data_dict:
                data_dict['Mask_Plate_PreScan_' + item_name + '_i'] = no16

            # ExporeadyPitch_Calc / ExporeadyRoll_Calc
            expoready_calc = no14 + no15 + no16


            # Other
            other = expoready_calc - real_pitch_roll
            # other = real_pitch_roll - expoready_calc
            other = float('{:.4f}'.format(other))

            data_dict['Expoready_' + item_name] = real_pitch_roll
            data_dict['Other'] = other

            data_list.append(data_dict)
            # data_list.append({
            #     'plate': plate,
            #     'shot': shot,
            #     'glass_id': glass_id,
            #     'AFC_Drive_Offset_' + item_name: no14,
            #     'Each_Shot_' + item_name + '_Offset_i': no15,
            #     'Mask_Plate_PreScan_' + item_name + '_i': no16,
            #     # 'AFC_Drive_Diff_' + item_name: None,
            #     # 'Expoready' + item_name + '_Calc': expoready_calc,
            #     'Expoready' + item_name: real_pitch_roll,
            #     'Other': other
            # })

        logger.info('---[FocusGraph] create_pitch_roll_data out')
        return data_list

    def create_psz_data(self, event_data_dict):
        """
        pszデータを作成
        """
        logger.info('---[FocusGraph] create_psz_data in')

        # FcBasePSZEvent(No.1)はplateごとに同じ値(shot1の値)を使用 LOT_IDあり
        fc_base_psz_dict = {}
        if self.ES_BASE_PSZ_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data FcBasePSZEvent(No.1)')
            for fc_base_psz_source in event_data_dict[self.ES_BASE_PSZ_EVENT]:
                # fc_base_psz_source = fc_base_psz_row['_source']
                plate = str(fc_base_psz_source.get('plate_no', 0))
                if plate not in fc_base_psz_dict.keys():
                    logger.info('---[FocusGraph] create_psz_data FcBasePSZEvent plate none')
                    fc_base_psz_dict[plate] = fc_base_psz_source.get('afc_base_z', 0)

        # AfcDriveOffsetZEvent(No.2)は全てのプレートで同じ値を使用　LOT_IDなし　DEV/PROから取得
        no2 = 0
        if self.ES_AFC_DRIVE_OFFSETZ_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data AfcDriveOffsetZEvent(No.2)')
            for afc_drive_offsetz_source in event_data_dict[self.ES_AFC_DRIVE_OFFSETZ_EVENT]:
                # afc_drive_offsetz_source = afc_drive_offsez_row['_source']
                no2 = afc_drive_offsetz_source.get('afc_drive_z', 0)
                break

        # LipsPitchOtherZEvent(No.3)はPlateごとに同じ値を使用　LOT_IDあり
        lips_pitch_otherz_dict = {}
        if self.ES_LIPS_PITCH_OTHERZ_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data LipsPitchOtherZEvent(No.3)')
            for lips_pitch_otherz_source in event_data_dict[self.ES_LIPS_PITCH_OTHERZ_EVENT]:
                # lips_pitch_otherz_source = lips_pitch_otherz_row['_source']
                plate = str(lips_pitch_otherz_source.get('plate_no', 0))
                if plate not in lips_pitch_otherz_dict.keys():
                    logger.info('---[FocusGraph] create_psz_data LipsPitchOtherZEvent plate none')
                    lips_pitch_otherz_dict[plate] = lips_pitch_otherz_source.get('afc_drive_lips_other_z_base', 0)

        # LipsCorrectionZEvent(No.4) LotIDあり　plateごとにデータを保持　
        lips_correctionz_dict = {}
        if self.ES_LIPS_CORRECTIONZ_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data LipsCorrectionZEvent(No.4)')
            for lips_correctionz_source in event_data_dict[self.ES_LIPS_CORRECTIONZ_EVENT]:
                # lips_correctionz_source = lips_correctionz_row['_source']
                plate = str(lips_correctionz_source.get('plate_no', 0))

                if plate not in lips_correctionz_dict.keys():
                    logger.info('---[FocusGraph] create_psz_data LipsCorrectionZEvent plate none')
                    lips_correctionz_dict[plate] = lips_correctionz_source.get('lips_z', 0)

        # EachShotAfcEvent(No.5) LotIDあり, plate/shot 毎にデータがある
        each_shot_afc_dict = {}
        if self.ES_EACH_SHOT_AFC_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data EachShotAfcEvent(No.5)')
            for each_shot_afc_source in event_data_dict[self.ES_EACH_SHOT_AFC_EVENT]:
                # each_shot_afc_source = each_shot_row['_source']
                plate = str(each_shot_afc_source.get('plate_no', 0))
                shot = str(each_shot_afc_source.get('step_no', 0))
                each_shot_afc_dict[plate + '_' + shot] = each_shot_afc_source.get('each_shot', 0)

        # EachShotPROffsetOtherZEvent(No.6) LotIDあり, plate/shot 毎にデータがある
        each_shot_PROffset_otherz_dict = {}
        if self.ES_EACH_SHTO_PROOFFSET_OTHERA_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data EachShotPROffsetOtherZEvent(No.6)')
            for each_shot_PROffset_otherz_source in event_data_dict[self.ES_EACH_SHTO_PROOFFSET_OTHERA_EVENT]:
                # each_shot_PROffset_otherz_source = each_shot_PROffset_otherz_row['_source']
                plate = str(each_shot_PROffset_otherz_source.get('plate_no', 0))
                shot = str(each_shot_PROffset_otherz_source.get('step_no', 0))
                each_shot_PROffset_otherz_dict[plate + '_' + shot] = each_shot_PROffset_otherz_source.get(
                    'each_shot_p_r_other_z_fine', 0)

        # PlateThicknessZEvent(No.7) LotIDなし　DEV/PROから取得　plateはなくshotごとのデータを保持
        plate_thicknessz_dict = {}
        if self.ES_PLATE_THICKNESSZ_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data PlateThicknessZEvent(No.7)')
            for plate_thicknessz_source in event_data_dict[self.ES_PLATE_THICKNESSZ_EVENT]:
                # plate_thicknessz_source = plate_thicknessz_row['_source']
                plate = str(plate_thicknessz_source.get('plate_no', 0))
                shot = str(plate_thicknessz_source.get('step_no', 0))
                plate_thicknessz_dict[plate + '_' + shot] = plate_thicknessz_source.get('plate_thick_z', 0)

        # MaskPlatePreScanPitchRollZEvent(No.8)はPlate,shotごとに値があるがユーザによってはない場合もある
        prescan_z_source = {}
        prescan_dict = {}
        if self.ES_MASK_PLATE_PRE_SCAN_PITCH_ROLL_Z_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data MaskPlatePreScanPitchRollZEvent(No.8)')
            for prescan_z_source in event_data_dict[self.ES_MASK_PLATE_PRE_SCAN_PITCH_ROLL_Z_EVENT]:
                # prescan_z_source = prescan_row['_source']
                plate = str(prescan_z_source.get('plate_no', 0))
                shot = str(prescan_z_source.get('step_no', 0))
                prescan_dict[plate + '_' + shot] = prescan_z_source.get('pre_scanz', 0)

        # PositionOffsetPszEvent(No.10) LotIDなし　DEV/PROから取得 plateはなくshotごとのデータを保持 key
        position_offset_psz_source = {}
        if self.ES_POSITION_OFFSET_PSZ_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data PositionOffsetPszEvent(No.10)')
            # for position_offset_psz_row in event_data_dict[self.ES_POSITION_OFFSET_PSZ_EVENT]:
            #     position_offset_psz_source = position_offset_psz_row['_source']
            if len(event_data_dict[self.ES_POSITION_OFFSET_PSZ_EVENT]):
                position_offset_psz_source = event_data_dict[self.ES_POSITION_OFFSET_PSZ_EVENT][0]

        # ChuckLockAfcCorrectionEvent(No.11) LotIDあり　1つのshotのみデータありその他のshotは0固定
        chunk_lock_afc_correction_dict = {}
        if self.ES_CHUCK_LOCK_AFC_CORRECTION_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data ChuckLockAfcCorrectionEvent(No.11)')
            for chunk_lock_afc_source in event_data_dict[self.ES_CHUCK_LOCK_AFC_CORRECTION_EVENT]:
                # chunk_lock_afc_source = chunk_lock_afc_row['_source']
                plate = str(chunk_lock_afc_source.get('plate_no', 0))
                step = str(chunk_lock_afc_source.get('step_no', 0))
                chunk_lock_afc_correction_dict[plate + '_' + step] = chunk_lock_afc_source.get('chuck_lock_z', 0)

        # AfcDriveOffsetOtherZEvent(No.12) LotIDあり, plate/shot 毎にデータがある
        afc_drive_offset_otherz_dict = {}
        if self.ES_AFC_DRIVE_OFFSET_OTHERZ_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data AfcDriveOffsetOtherZEvent(No.12)')
            for afc_drive_source in event_data_dict[self.ES_AFC_DRIVE_OFFSET_OTHERZ_EVENT]:
                # afc_drive_source = afc_drive_row['_source']
                plate = str(afc_drive_source.get('plate_no', 0))
                shot = str(afc_drive_source.get('step_no', 0))
                afc_drive_offset_otherz_dict[plate + '_' + shot] = afc_drive_source.get('afc_drive_other_z_expo', 0)

        # MaskPlatePreScanOtherZEvent(No.13) LotIDあり, plate/shot 毎にデータがある
        mask_plate_prescan_otherz_dict = {}
        if self.ES_MASK_PLATE_PRE_SCAN_OTHERZ_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data MaskPlatePreScanOtherZEvent(No.13)')
            for mask_plate_source in event_data_dict[self.ES_MASK_PLATE_PRE_SCAN_OTHERZ_EVENT]:
                # mask_plate_source = mask_plate_row['_source']
                plate = str(mask_plate_source.get('plate_no', 0))
                shot = str(mask_plate_source.get('step_no', 0))
                mask_plate_prescan_otherz_dict[plate + '_' + shot] = mask_plate_source.get('afc_drive_other_z_expo', 0)

        # StagePositionMonitorEvent(実位置取得用) lot_id, plate, shotを指定しても重複する場合があるので、event_timeの新しいものを使用する
        stage_position_dic = {}
        if self.ES_STAGE_POSITION_MONITOR_EVENT in event_data_dict:
            logger.info('---[FocusGraph] create_psz_data StagePositionMonitorEvent)')
            for source in event_data_dict[self.ES_STAGE_POSITION_MONITOR_EVENT]:
                # source = data_row['_source']
                plate = str(source.get('plate_no', 0))
                shot = str(source.get('step_no', 0))
                key = plate + '_' + shot

                if (key in stage_position_dic):
                    logger.info('---[FocusGraph] create_psz_data StagePositionMonitorEvent key exist')
                    # キーがあったらevent_timeの新しい方を有効にする
                    if (stage_position_dic[key].get('log_time') < source.get('log_time')):
                        logger.info('---[FocusGraph] create_psz_data StagePositionMonitorEvent key duplicate')
                        stage_position_dic[key] = source
                else:
                    logger.info('---[FocusGraph] create_psz_data StagePositionMonitorEvent key not exist')
                    # キーがなかったら追加
                    stage_position_dic[key] = source

        # sorted_items = sorted(event_data_dict[ES_STAGE_POSITION_MONITOR_EVENT], key=lambda x: (
        # x['_source']['plate_'], x['_source']['step_']))
        data_list = []
        # StagePositionMonitorEvent(実位置取得用)を基準にplate、shotを決めてデータを整形する
        for key in stage_position_dic:
            data_dict = dict()

            source = stage_position_dic[key]
            plate = str(source.get('plate_no', 0))
            shot = str(source.get('step_no', 0))

            data_dict['plate'] = source.get('plate_no', 0)
            data_dict['shot'] = source.get('step_no', 0)
            data_dict['glass_id'] = source.get('glass_id', None)

            # StagePositionMonitorEventから実位置取得
            real_z = calculator.nm_to_um(source.get('ps_z', 0)) * 1000

            no1 = fc_base_psz_dict.get(plate, 0)
            if self.ES_BASE_PSZ_EVENT in event_data_dict:
                data_dict['AFC_Base_PSZ'] = no1

            # no2 機種固定
            if self.ES_AFC_DRIVE_OFFSETZ_EVENT in event_data_dict:
                data_dict['AFC_Drive_Offset_Z'] = no2

            no3 = lips_pitch_otherz_dict.get(plate, 0)
            if self.ES_LIPS_PITCH_OTHERZ_EVENT in event_data_dict:
                data_dict['LiPS_Pitch_Other_Z_i'] = no3

            no4 = lips_correctionz_dict.get(plate, 0)
            if self.ES_LIPS_CORRECTIONZ_EVENT in event_data_dict:
                data_dict['LiPS_PSZ'] = no4

            no5 = each_shot_afc_dict.get(plate + '_' + shot, 0)
            if self.ES_EACH_SHOT_AFC_EVENT in event_data_dict:
                data_dict['Each_Shot_AFC_i'] = no5

            no6 = each_shot_PROffset_otherz_dict.get(plate + '_' + shot, 0)
            if self.ES_EACH_SHTO_PROOFFSET_OTHERA_EVENT in event_data_dict:
                data_dict['Each_Shot_P/R_Offset_Other_Z_i'] = no6

            no7 = plate_thicknessz_dict.get(plate + '_' + shot, 0)
            if self.ES_PLATE_THICKNESSZ_EVENT in event_data_dict:
                data_dict['Plate_Thickness_Z_i'] = no7

            no8 = prescan_dict.get(plate + '_' + shot, 0)
            if self.ES_MASK_PLATE_PRE_SCAN_PITCH_ROLL_Z_EVENT in event_data_dict:
                data_dict['Mask_Plate_PreScan_Z_i'] = no8

            # no9 不要

            no10 = position_offset_psz_source.get('step' + shot, 0)
            if self.ES_POSITION_OFFSET_PSZ_EVENT in event_data_dict:
                data_dict['Position_Offset_Z_i'] = no10

            no11 = chunk_lock_afc_correction_dict.get(plate + '_' + shot, 0)
            if self.ES_CHUCK_LOCK_AFC_CORRECTION_EVENT in event_data_dict:
                data_dict['Chuck_Lock_AFC_Z'] = no11

            no12 = afc_drive_offset_otherz_dict.get(plate + '_' + shot, 0)
            if self.ES_AFC_DRIVE_OFFSET_OTHERZ_EVENT in event_data_dict:
                data_dict['AFC_Drive_Offset_Other_Z_i'] = no12

            no13 = mask_plate_prescan_otherz_dict.get(plate + '_' + shot, 0)
            if self.ES_MASK_PLATE_PRE_SCAN_OTHERZ_EVENT in event_data_dict:
                data_dict['Mask_Plate_PreScan_Other_Z_i'] = no13

            # = C5 -D5 -E5 -G5 +I5 -J5 +L5  +M5   +N5  -O5  +P5
            # = no1-no5-no2-no4+no6-no7+no13+(no9)+no10-no11+no12
            exporeadyz_calc = no1 - no5 - no2 - no4 + no6 - no7 + no13 + no10 - no11 + no12

            other = exporeadyz_calc - real_z
            # other = real_z - exporeadyz_calc
            other = float('{:.4f}'.format(other))


            data_dict['Other'] = other
            data_dict['Expoready_Z'] = real_z

            data_list.append(data_dict)

            # data_list.append({
            #     'plate': source.get('plate_no', 0),
            #     'shot': source.get('step_no', 0),
            #     'glass_id': source.get('glass_id', None),
            #     'AFC_Base_PSZ': no1,
            #     'AFC_Drive_Offset_Z': no2,
            #     'LiPS_Pitch_Other_Z_i': no3,
            #     'LiPS_PSZ': no4,
            #     'Each_Shot_AFC_i': no5,
            #     'Each_Shot_P/R_Offset_Other_Z_i': no6,
            #     'Plate_Thickness_Z_i': no7,
            #     'Mask_Plate_PreScan_Z_i': no8,
            #     'Mag_Other_Z': None,
            #     'Position_Offset_Z_i': no10,
            #     'Chuck_Lock_AFC_Z': no11,
            #     'AFC_Drive_Offset_Other_Z_i': no12,
            #     'Mask_Plate_PreScan_Other_Z_i': no13,
            #     'AFC_Drive_Diff_Z': None,
            #     'Other': other,
            #     'ExporeadyZ_Calc': exporeadyz_calc,
            #     'ExporeadyZ': real_z
            # })

        logger.info('---[FocusGraph] create_psz_data out')
        return data_list
