import os
import logging
import sqlite3
import pandas as pd
import math
import copy
import json
import traceback

from service.overlay.service_overlay_base import ServiceOverlayBase
from service.converter.convert_process import ConvertProcess
from common.utils.response import ResponseForm
from config import app_config
from dao.dao_file import FileDao
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from controller.converter.converter import create_request_id
from service.overlay import correction_param
from service.overlay.correction_conveter import CorrectionConverter
from common.utils import preprocessing
from common.utils import calculator

logger = logging.getLogger(app_config.LOG)


class ServiceFocus:
    log_list = app_config.FOCUS_LOG_LIST
    category_name = 'Focus'

    def __init__(self):
        self.root_path = app_config.root_path
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.category_name
        }

    def file_check(self, files):
        """

        :param files: [files]
        :return: {'log_name': [fids]}
        """
        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        # todo 필수 파일 체크
        # old version의 경우
        # # machine : cons.data, main.data
        # # PlateAutoFocusCompensation 또는 StagePositionMonitor 중 1개  <- 더 확인이 필요함. 진짜 필요한건가..
        # FocusLogDetail이 존재하는 경우
        # # StagePositionMonitor는 필수

        if not os.path.exists(self.root_path):
            os.mkdir(self.root_path)

        data = dict()

        for log_name, file_data in files.items():
            if file_data is None:
                continue
            # if log_name == app_config.LOG_UNKNOWN:
            #     log_name = app_config.RECALL_ADC_MEAS
            for file in file_data:
                filename = file.filename
                foldername = os.path.join(self.root_path, log_name)
                if not os.path.exists(foldername):
                    os.mkdir(foldername)
                if log_name not in data:
                    data[log_name] = list()
                f = None
                file_index = 1
                while f is None or os.path.exists(f):
                    _filename = f'{file_index}____{filename}'
                    f = os.path.join(foldername, _filename)
                    file_index += 1
                file.save(f)
                fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))

                if fid is None:
                    logger.error('failed to store file info')
                    return ResponseForm(res=False, msg='failed to store file info')

                data[log_name].append(fid)

        return ResponseForm(res=True, data=data)

    def convert(self, logs):
        """

        :param logs: { 'log_name': [fids] }
        :return:
        """

        # Create Request ID
        self.form['id'] = create_request_id()

        file_id_list = list()
        for log_name, val in logs.items():
            file_id_list.append(','.join([str(_) for _ in logs[log_name]]))

        self.form['file'] = ','.join(file_id_list)

        # Insert Job info into cnvset.job
        io = DAOJob.instance()
        try:
            io.insert_job(**self.form)
        except Exception as e:
            logger.error('failed to insert job')
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

        # Create sub processor to convert log
        target_logs = dict()
        dao = DAOBaseClass()
        for log_name, val in logs.items():
            # #sqlite
            if isinstance(dao.connect, sqlite3.Connection):
                # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis_function as a " \
                #         f"inner join analysis_local_info as b on a.id = b.func_id) as c " \
                #         f"where system_func=true and log_name='{log_name}'"
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis_function as a " \
                        f"inner join analysis_local_info as b on a.id = b.func_id " \
                        f"inner join analysis_category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{log_name}' and title='{self.category_name}'"
            else:
                # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis.function as a " \
                #         f"inner join analysis.local_info as b on a.id = b.func_id) as c " \
                #         f"where system_func=true and log_name='{log_name}'"
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis.function as a " \
                        f"inner join analysis.local_info as b on a.id = b.func_id " \
                        f"inner join analysis.category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{log_name}' and title='{self.category_name}'"

            row = dao.execute(query)
            if row is None or len(row) == 0:
                return ResponseForm(res=False, msg=f'Cannot find {log_name} function.')

            target_logs[log_name] = row[0][0]

        cnv_proc = ConvertProcess(self.form['id'], target_logs)
        cnv_proc.start()

        return ResponseForm(res=True, data=self.form['id'])