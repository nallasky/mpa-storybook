# coding:utf-8
'''
---------------------------------------------
No.15 各Shot Pitch / Roll

Update History:
    [2020/09/23] 新規作成

Copyright(C) Canon Inc. All right reserved.
---------------------------------------------
'''


class EachShotPitchRollOffset:
    """ 各Shot Pitch / Roll  取得Class """

    # JSON化する項目
    event_id = 'EachShotPitchRollOffsetEvent'
    # ProcessデータStepタブのPitching[sec]の設定データコード。shot1（0x21F00）からshot36（0x21F46）まで
    PITCHING_SET_CODE = 139008
    # ProcessデータStepタブのRolling[sec]の設定データコード。shot1（0x21F01）からshot36（0x21F47）まで
    ROLLING_SET_CODE = 139009

    def __init__(self):
        """コンストラクタ
        """

    def get_each_shot_pr_offset(
            self, processDict, stepCountList, devprokey):
        """ 各Shot Pitch / Roll 取得

        Args:
            stage_pos_monitor_data: 　　stage_pos_monitorデータ
        """
        # 基準となる時間を取得
        # baseTime = eventTime.split('.')[0]
        # cnt = 0
        outputlist = []
        # if len(processDict) != 0:
        if devprokey in processDict:
            stepPitchDict = {}
            stepRollDict = {}
            # Step数とEachShotのデータを紐づける
            for num in range(1, 37):
                stepPitchDict[num] = hex(
                    self.PITCHING_SET_CODE).replace(
                    '0x', '')
                self.PITCHING_SET_CODE += 2
                stepRollDict[num] = hex(
                    self.ROLLING_SET_CODE).replace(
                    '0x', '')
                self.ROLLING_SET_CODE += 2

            # for devprokey in processDict:
            process_df = processDict[devprokey]
            outputdict = {}
            outputdict['event_id'] = self.event_id
            # outputdict['event_time'] = baseTime + \
            #     '.' + '{0:06d}'.format(cnt) + '+0900'
            # cnt += 1
            [device, process] = devprokey.split(sep='/')
            outputdict['device'] = device
            outputdict['process'] = process
            # DevProに合致するStep数を取得
            stepCount = 0
            for stepData in stepCountList:
                stepCount = 0
                if stepData['device'] == device and \
                        stepData['process'] == process:
                    stepCount = stepData['step_count']
                    break
            for num in range(1, stepCount + 1):
                outputdict['step' +
                           str(num) + '_pitch'] = process_df[process_df['key'] == stepPitchDict[num]]['val'].values[0] / 1000
                outputdict['step' +
                           str(num) + '_roll'] = process_df[process_df['key'] == stepRollDict[num]]['val'].values[0] / 1000

            outputlist.append(outputdict)
        else:
            outputdict = {}
            outputdict['event_id'] = self.event_id
            # outputdict['event_time'] = baseTime + \
            #     '.' + '{0:06d}'.format(cnt) + '+0900'
            # cnt += 1
            for num in range(1, 37):
                outputdict['step' +
                           str(num) + '_pitch'] = 0
                outputdict['step' +
                           str(num) + '_roll'] = 0
            outputlist.append(outputdict)
        return outputlist
