# coding:utf-8
from common.utils import calculator
'''
---------------------------------------------
No.8,16共通 Mask Pre Scan / Plate Pre Scan 補正

Update History:
    [2020/09/23] 新規作成

Copyright(C) Canon Inc. All right reserved.
---------------------------------------------
'''


class MaskPlatePreScanPitchRollZ:
    """  Pre Scan 補正Pitch,Roll 取得Class """

    # JSON化する項目
    event_id = 'MaskPlatePreScanPitchRollZEvent'
    RECALl_KEY = [#'event_time',
                  # 'exposure_start_psz_',
                  # 'exposure_start_pspitch_',
                  # 'exposure_start_psroll_',
                  'expo_start_pos_psz',
                  'expo_start_pos_psp',
                  'expo_start_pos_psr',
                  'device',
                  'process',
                  'lot_id',
                  'plate_no',
                  'step_no']

    def __init__(self):
        """コンストラクタ
        """

    def get_pre_scan_pr_z(
            self, prescan_df):
        """ Pre Scan 補正値取得

        Args:
            prescan_data: 　　prescan_dataデータ
        """
        outputlist = []
        outputcalcDict = {}
        # for devprokey in prescan_data:
        #     for fileCnt in prescan_data[devprokey]:
        #         checkdict = {}
        #         # Recallの1レコードごとの集計
        #         for record in prescan_data[devprokey][fileCnt]:
        #             outputdict = {}
        #             for datakey in prescan_data[devprokey][fileCnt][record].keys(
        #             ):
        #                 # 見づらいので置き換える
        #                 data_dict = prescan_data[devprokey][fileCnt][record]
        #                 current_lotid = data_dict['lot_id_']
        #                 current_plate = data_dict['plate_']
        #                 current_step = data_dict['step_']
        #                 if datakey in self.RECALl_KEY:
        #                     # 他クラスでの計算に必要な補正値を詰め直す
        #                     if datakey == 'expo_start_pos_psz':
        #                         # PreScan補正Z(No.8)
        #                         outputdict['pre_scanz'] = data_dict[datakey]
        #                     elif datakey == 'expo_start_pos_psp':
        #                         # PreScan補正Pitch(No16)
        #                         outputdict['pre_scan_pitch'] = data_dict[datakey]
        #                     elif datakey == 'expo_start_pos_psr':
        #                         # PreScan補正Roll(No16)
        #                         outputdict['pre_scan_roll'] = data_dict[datakey]
        #                     else:
        #                         outputdict[datakey] = data_dict[datakey]
        #                         outputdict['event_id'] = self.event_id
        #             # dictが初期化されていなければ初期化する
        #             if current_lotid not in checkdict.keys():
        #                 checkdict[current_lotid] = {}
        #             if current_plate not in checkdict[current_lotid].keys():
        #                 checkdict[current_lotid][current_plate] = {}
        #             if current_step not in checkdict[current_lotid][current_plate].keys(
        #             ):
        #                 checkdict[current_lotid][current_plate][current_step] = {}
        #             # LotID[Plate[Step[データ]]]の構成でデータを作成
        #             # 同じPlate、Step番号でデータがあった場合、最新のデータで更新する
        #             checkdict[current_lotid][current_plate][current_step] = outputdict
        #
        #             # No13で使用するため、devproをキーにしたdictに結果を設定
        #             outputcalcDict[devprokey] = checkdict
        #         for lot in checkdict:
        #             for plate in checkdict[lot]:
        #                 for step in checkdict[lot][plate]:
        #                     outputlist.append(checkdict[lot][plate][step])
        devprokey = prescan_df['job'].values[0]
        lot_id = prescan_df['lot_id'].values[0]
        df = prescan_df[self.RECALl_KEY]
        df = df.rename(columns={'expo_start_pos_psz': 'pre_scanz',
                                'expo_start_pos_psp': 'pre_scan_pitch',
                                'expo_start_pos_psr': 'pre_scan_roll'})
        df['event_id'] = self.event_id
        df[['pre_scanz', 'pre_scan_pitch', 'pre_scan_roll']] = df[['pre_scanz', 'pre_scan_pitch', 'pre_scan_roll']].apply(calculator.nm_to_um)
        outputlist = df.to_dict('records')

        outputcalcDict = {
            devprokey: {
                lot_id: {}
            }
        }
        plate_group_df = df.groupby('plate_no')
        for plate_no, plate_df in plate_group_df:
            outputcalcDict[devprokey][lot_id][plate_no] = dict()
            step_group_df = plate_df.groupby('step_no')
            for step_no, step_df in step_group_df:
                outputcalcDict[devprokey][lot_id][plate_no][step_no] = step_df.iloc[-1].to_dict()

        return outputlist, outputcalcDict
