# coding:utf-8
from common.utils import calculator
'''
---------------------------------------------
No.6 各 Shot Pitch / Roll 他成分 Z

Update History:
    [2020/09/30] 新規作成

Copyright(C) Canon Inc. All right reserved.
---------------------------------------------
'''
import math


class EachShotPROffsetOtherZ:
    """ Shot Pitch / Roll 他成分 Z 取得Class """

    # JSON化する項目
    event_id = 'EachShotPROffsetOtherZEvent'

    # ProcessデータStepタブのPitching[sec]の設定データコード。shot1（0x21F00）からshot36（0x21F46）まで
    PITCHING_SET_CODE = 139008
    # ProcessデータStepタブのRolling[sec]の設定データコード。shot1（0x21F01）からshot36（0x21F47）まで
    ROLLING_SET_CODE = 139009

    def __init__(self):
        """コンストラクタ
        """

    def get_each_shot_pr_offset_other_z(
            self, process_data, stage_pos_monitor_data, focusUtil):
        """ 各Shot Pitch / Roll 他成分 Z取得

        Args:
            process_data: 　　　　　　　processデータ
            stage_pos_monitor_data: 　 stage_pos_monitorデータ
            focusUtil:                 Focusのユーティリティ
        """
        # Step数とEachShotのデータを紐づける
        stepPitchDict = {}
        stepRollDict = {}
        for num in range(1, 37):
            stepPitchDict[num] = hex(self.PITCHING_SET_CODE).replace('0x', '')
            self.PITCHING_SET_CODE += 2
            stepRollDict[num] = hex(self.ROLLING_SET_CODE).replace('0x', '')
            self.ROLLING_SET_CODE += 2
        # Preのデータ取得
        # ログデータの各Dev/ProのPlate1で尚且つ1番最初のPosがStepの項目のデータをpre位置としてNo1の計算で使用する。
        outputPreDict = {}
        # 1データずつ取り出し
        # for devprokey in stage_pos_monitor_data:
        #     # ファイル数分ループ処理
        #     for fileCnt in stage_pos_monitor_data[devprokey]:
        #         for record in stage_pos_monitor_data[devprokey][fileCnt]:
        #             # StagePositionMonitorの1レコードごとの取得
        #             data_dict = stage_pos_monitor_data[devprokey][fileCnt][record]
        #             data_dict.get('event_time')
        #             pos = data_dict.get('pos_')
        #             if 'Step    ' == pos:
        #                 # Step位置Xの取得
        #                 plate_stage_x = data_dict.get('plate_stage_x_')
        #                 # Step位置Yの取得
        #                 plate_stage_y = data_dict.get('plate_stage_y_')
        #                 plate = data_dict.get('plate_')
        #                 step = data_dict.get('step_')
        #                 drive_amount_pitch = 0
        #                 drive_amount_roll = 0
        #                 # Processデータが無ければ初期値を使用する
        #                 if len(process_data) != 0:
        #                     # Pitch[sec]の取得
        #                     drive_amount_pitch = process_data[devprokey][stepPitchDict[step]]
        #                     # Roll[sec]の取得
        #                     drive_amount_roll = process_data[devprokey][stepRollDict[step]]
        #                 # 各Shot Pitch/Roll他成分[um]+重心位置差を取得
        #                 outputdict = self._get_each_shot_pr_offset_other_z(
        #                     focusUtil, drive_amount_pitch, drive_amount_roll, plate_stage_x, plate_stage_y, data_dict, drive_amount_pitch, 'pre')
        #                 platedict = {}
        #                 platedict[plate] = outputdict
        #                 lotiddict = {}
        #                 lotiddict[outputdict.get('lot_id_')] = platedict
        #                 outputPreDict[devprokey] = lotiddict
        #                 break
        step_df = stage_pos_monitor_data[stage_pos_monitor_data['position'] == 'Step']
        if len(step_df) > 0:
            data_dict = step_df.iloc[0].to_dict()
            devprokey = data_dict.get('job')
            # Step位置Xの取得
            plate_stage_x = calculator.nm_to_um(data_dict.get('ps_x'))
            # Step位置Yの取得
            plate_stage_y = calculator.nm_to_um(data_dict.get('ps_y'))
            plate = data_dict.get('plate_no')
            step = data_dict.get('step_no')
            drive_amount_pitch = 0
            drive_amount_roll = 0
            # Processデータが無ければ初期値を使用する
            if devprokey in process_data:
                process_df = process_data[devprokey]
                # Pitch[sec]の取得
                drive_amount_pitch = process_df[process_df['key'] == stepPitchDict[step]]['val'].values[0]
                # Roll[sec]の取得
                drive_amount_roll = process_df[process_df['key'] == stepRollDict[step]]['val'].values[0]
            # 各Shot Pitch/Roll他成分[um]+重心位置差を取得
            outputdict = self._get_each_shot_pr_offset_other_z(
                focusUtil, drive_amount_pitch, drive_amount_roll, plate_stage_x, plate_stage_y, data_dict, drive_amount_pitch, 'pre')
            platedict = {}
            platedict[plate] = outputdict
            lotiddict = {}
            lotiddict[outputdict.get('lot_id')] = platedict
            outputPreDict[devprokey] = lotiddict

        # Fineのデータ取得
        outputFineList = []
        # 1データずつ取り出し
        # for devprokey in stage_pos_monitor_data:
        #     # ファイル数分ループ処理
        #     for fileCnt in stage_pos_monitor_data[devprokey]:
        #         append_check_dict = {}
        #         first_pitch = None
        #         for record in stage_pos_monitor_data[devprokey][fileCnt]:
        #             # 1st Layerを初期値にする（Stepは2ndでもあるため）
        #             layer_val = 1
        #             if len(process_data) != 0:
        #                 # Processデータから一致するキーのデータを取得
        #                 dict_process = process_data.get(devprokey)
        #                 if len(dict_process) != 0:
        #                     # Layerの値を取得する
        #                     layer_val = dict_process.get('12010')
        #             # StagePositionMonitorの1レコードごとの取得
        #             data_dict = stage_pos_monitor_data[devprokey][fileCnt][record]
        #             data_dict.get('event_time')
        #             plate = data_dict.get('plate_')
        #             pos = data_dict.get('pos_')
        #             step = data_dict.get('step_')
        #             # 1st Layerの場合Pos=Stepを取得
        #             if 1 == layer_val and 'Step    ' == pos:
        #                 # Step位置Xの取得
        #                 plate_stage_x = data_dict.get(
        #                     'plate_stage_x_')
        #                 # Step位置Yの取得
        #                 plate_stage_y = data_dict.get(
        #                     'plate_stage_y_')
        #             # 2nd~ Layerの場合Pos=P2を取得
        #             elif 'P2      ' == pos:
        #                 # Step位置Xの取得
        #                 plate_stage_x = data_dict.get(
        #                     'plate_stage_x_')
        #                 # Step位置Yの取得
        #                 plate_stage_y = data_dict.get(
        #                     'plate_stage_y_')
        #             else:
        #                 # 上記以外はA,Bを算出しない
        #                 continue
        #             if self._append_check(data_dict, append_check_dict):
        #                 # 同じStepでP2が検出されるケースがあるため、すでに登録済みの場合は何もしない
        #                 continue
        #
        #             drive_amount_pitch = 0
        #             drive_amount_roll = 0
        #             # Pitch[sec]の取得
        #             drive_amount_pitch = process_data[devprokey][stepPitchDict[step]]
        #             # Roll[sec]の取得
        #             drive_amount_roll = process_data[devprokey][stepRollDict[step]]
        #             # 最初のStepのdriveを保存（駆動量（他成分Zの計算）で使用する）
        #             if first_pitch is None:
        #                 first_pitch = drive_amount_pitch
        #             # 各Shot Pitch/Roll他成分[um]+重心位置差を取得
        #             outputdict = self._get_each_shot_pr_offset_other_z(
        #                 focusUtil, drive_amount_pitch, drive_amount_roll, plate_stage_x, plate_stage_y, data_dict, first_pitch, 'fine')
        #             outputFineList.append(outputdict)
        devprokey = stage_pos_monitor_data['job'].values[0]
        layer_val = 1
        process_df = None
        if devprokey in process_data:
            # Processデータから一致するキーのデータを取得
            process_df = process_data.get(devprokey)
            if len(process_df) != 0:
                # Layerの値を取得する
                layer_val = process_df[process_df['key'] == '12010']['val'].values[0]

        first_pitch = None
        for plate_no, plate_df in stage_pos_monitor_data.groupby('plate_no'):
            for step_no, step_df in plate_df.groupby('step_no'):
                if layer_val == 1:
                    data_dict = step_df[step_df['position'] == 'Step'].iloc[0].to_dict()
                else:
                    data_dict = step_df[step_df['position'] == 'P2'].iloc[0].to_dict()
                # Step位置Xの取得
                plate_stage_x = calculator.nm_to_um(data_dict.get('ps_x'))
                # Step位置Yの取得
                plate_stage_y = calculator.nm_to_um(data_dict.get('ps_y'))
                drive_amount_pitch = 0
                drive_amount_roll = 0
                if process_df is not None:
                    # Pitch[sec]の取得
                    drive_amount_pitch = process_df[process_df['key'] == stepPitchDict[step_no]]['val'].values[0]
                    # Roll[sec]の取得
                    drive_amount_roll = process_df[process_df['key'] == stepRollDict[step_no]]['val'].values[0]
                # 最初のStepのdriveを保存（駆動量（他成分Zの計算）で使用する）
                if first_pitch is None:
                    first_pitch = drive_amount_pitch
                # 各Shot Pitch/Roll他成分[um]+重心位置差を取得
                outputdict = self._get_each_shot_pr_offset_other_z(
                    focusUtil, drive_amount_pitch, drive_amount_roll, plate_stage_x, plate_stage_y, data_dict,
                    first_pitch, 'fine')
                outputFineList.append(outputdict)

        return outputPreDict, outputFineList

    def _get_each_shot_pr_offset_other_z(self, focusUtil,
                                         drive_amount_pitch, drive_amount_roll, plate_stage_x, plate_stage_y, data_dict, first_pitch, target):
        """各Shot Pitch/Roll他成分[um]+重心位置差を取得

        Args:
            focusUtil:                  Focusのユーティリティ
            drive_amount_pitch:         Pitch[sec]の取得
            drive_amount_roll:  　      Roll[sec]の取得
            plate_stage_x:              Step位置X
            plate_stage_y:              Step位置Y
            data_dict:                  StagePositionMonitorのデータ
            first_pitch:                最初のStepのpitch
            target:                     fine or pre
        """
        # Pitch 他成分Z[um]の計算（Pitching[sec]の値が1→1000で表示されるため1000倍はしない）
        pitch_calc = plate_stage_y * \
            math.tan(drive_amount_pitch / 3600 / 180 * math.pi)

        # Roll 他成分Z[um]（Rolling[sec]の値が1→1000で表示されるため1000倍はしない）
        roll_calc = -(plate_stage_x *
                      math.tan(drive_amount_roll / 3600 / 180 * math.pi))

        # 各Shot Pitch/Roll他成分[um]
        calc_pitch_roll = pitch_calc + roll_calc

        # 中心位置ズレを取得
        center = focusUtil.get_center_position_shift()
        # 他成分Z
        other_z = -(center *
                    math.tan(first_pitch / 180 / 3600 * math.pi))

        outputdict = {}
        outputdict['event_id'] = self.event_id
        # outputdict['event_time'] = data_dict.get('event_time')
        outputdict['device'] = data_dict.get('device')
        outputdict['process'] = data_dict.get('process')
        outputdict['plate_no'] = data_dict.get('plate_no')
        outputdict['step_no'] = data_dict.get('step_no')
        outputdict['lot_id'] = data_dict.get('lot_id')
        # 他成分Z - 各Shot Pitch/Roll他成分[um]で各Shot Pitch/Roll他成分[um]+重心位置差を求める
        calc_result = calc_pitch_roll - other_z
        if 'pre' == target:
            outputdict['each_shot_pr_offset_other_pre'] = calc_result
        else:
            outputdict['each_shot_p_r_other_z_fine'] = calc_result

        return outputdict

    def _append_check(self, data_dict, append_dict):
        """ すでに追加したデータかチェックする"""
        lot_id = str(data_dict.get('lot_id'))
        plate = str(data_dict.get('plate'))
        step = str(data_dict.get('step'))
        key = lot_id + '_' + plate + '_' + step
        if key in append_dict:
            return True
        else:
            # Keyだけ追加する。中身は無し
            append_dict[key] = None
            return False
