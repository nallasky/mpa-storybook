import os
import logging
import sqlite3
import pandas as pd
import traceback

from config import app_config
from common.utils.response import ResponseForm
from dao.dao_file import FileDao
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from controller.converter.converter import create_request_id
from service.converter.convert_process import ConvertProcess
from common.utils import preprocessing
from common.utils import calculator

logger = logging.getLogger(app_config.LOG)


class ServiceFocusPrescan:
    log_list = [app_config.FOCUS_FUNC_PRESCAN, app_config.STATUSMONIOTOR_LOGNAME]
    category_name = 'Focus'
    log_name = 'prescan'
    param_list = [
            'plate_shape_l', 'plate_shape_c', 'plate_shape_r',
            'focus_ofs_l', 'focus_ofs_c', 'focus_ofs_r',
            'prescan_comp_l', 'prescan_comp_c', 'prescan_comp_r',
            'prescan_meas_l', 'prescan_meas_c', 'prescan_meas_r'
    ]

    def __init__(self):
        self.root_path = app_config.root_path
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.log_name
        }

    def file_check(self, files):
        """

        :param files: [files]
        :return: {'log_name': [fids]}
        """
        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        # 最小必要ログチェック
        if app_config.FOCUS_FUNC_PRESCAN not in files:
            return ResponseForm(res=False, msg=f'"{app_config.FOCUS_FUNC_PRESCAN}" Log must be included.')

        if not os.path.exists(self.root_path):
            os.mkdir(self.root_path)

        data = dict()

        for log_name, file_data in files.items():
            if file_data is None:
                continue
            for file in file_data:
                filename = file.filename
                foldername = os.path.join(self.root_path, log_name)
                if not os.path.exists(foldername):
                    os.mkdir(foldername)
                if log_name not in data:
                    data[log_name] = list()
                f = None
                file_index = 1
                while f is None or os.path.exists(f):
                    _filename = f'{file_index}{app_config.UPLOAD_FILE_SEPERATOR}{filename}'
                    f = os.path.join(foldername, _filename)
                    file_index += 1
                file.save(f)
                fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))

                if fid is None:
                    logger.error('failed to store file info')
                    return ResponseForm(res=False, msg='failed to store file info')

                data[log_name].append(fid)

        return ResponseForm(res=True, data=data)

    def convert(self, logs):
        """

        :param logs: { 'log_name': [fids] }
        :return:
        """

        # Create Request ID
        self.form['id'] = create_request_id()

        file_id_list = list()
        for log_name, val in logs.items():
            file_id_list.append(','.join([str(_) for _ in logs[log_name]]))

        self.form['file'] = ','.join(file_id_list)

        # Insert Job info into cnvset.job
        io = DAOJob.instance()
        try:
            io.insert_job(**self.form)
        except Exception as e:
            logger.error('failed to insert job')
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

        # Create sub processor to convert log
        target_logs = dict()
        dao = DAOBaseClass()
        for log_name, val in logs.items():
            # #sqlite
            if isinstance(dao.connect, sqlite3.Connection):
                # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis_function as a " \
                #         f"inner join analysis_local_info as b on a.id = b.func_id) as c " \
                #         f"where system_func=true and log_name='{log_name}'"
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis_function as a " \
                        f"inner join analysis_local_info as b on a.id = b.func_id " \
                        f"inner join analysis_category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{log_name}' and title='{self.category_name}'"
            else:
                # query = f"select c.id from (select a.id, a.system_func, b.log_name from analysis.function as a " \
                #         f"inner join analysis.local_info as b on a.id = b.func_id) as c " \
                #         f"where system_func=true and log_name='{log_name}'"
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis.function as a " \
                        f"inner join analysis.local_info as b on a.id = b.func_id " \
                        f"inner join analysis.category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{log_name}' and title='{self.category_name}'"

            row = dao.execute(query)
            if row is None or len(row) == 0:
                del dao
                return ResponseForm(res=False, msg=f'Cannot find {log_name} function.')

            target_logs[log_name] = row[0][0]

        del dao
        cnv_proc = ConvertProcess(self.form['id'], target_logs)
        cnv_proc.start()

        return ResponseForm(res=True, data=self.form['id'])

    def get_correction_data(self, args):
        """
        Get Correction Data.

        :param files: args
        :return:
        """
        rid = args['rid']
        category = args['category']
        mean_dev_diff = args['mean_dev_diff']

        filter = dict()
        # filter['log_time'] = {'start': args['period'].split(sep='~')[0], 'end': args['period'].split(sep='~')[1]}
        filter['job'] = args['job']
        filter['lot_id'] = args['lot_id']

        log_dict = preprocessing.load_focus_log(rid=rid, log_list=[category], **filter)
        if len(log_dict) == 0:
            return ResponseForm(res=False, msg='No matching data')

        df = log_dict[category]

        df.drop_duplicates(['job', 'lot_id', 'plate_no', 'shot_no', 'mask_stage_y'], keep='last', inplace=True)
        df.reset_index(inplace=True, drop=True)
        df[self.param_list] = df[self.param_list].apply(lambda x: calculator.nm_to_um(x.to_numpy()))
        df['mask_stage_y'] = calculator.nm_to_mm(df['mask_stage_y'].to_numpy())

        if len(mean_dev_diff) > 0:
            df = self.calc_mean_deviation_diff(mean_dev_diff, df)

        data = list()
        for shot_no, shot_df in df.groupby('shot_no'):
            shot_dict = dict()
            shot_dict['shot_no'] = shot_no
            shot_dict['data'] = list()
            for plate_no, plate_df in shot_df.groupby('plate_no'):
                plate_dict = dict()

                plate_df.sort_values(by='mask_stage_y', ascending=True, inplace=True)

                plate_dict['plate_no'] = plate_no
                plate_dict['glass_id'] = plate_df['glass_id'].values[0]
                plate_dict['msy'] = plate_df['mask_stage_y'].values.tolist()
                plate_dict['Plate_Shape_L'] = plate_df['plate_shape_l'].values.tolist()
                plate_dict['Plate_Shape_C'] = plate_df['plate_shape_c'].values.tolist()
                plate_dict['Plate_Shape_R'] = plate_df['plate_shape_r'].values.tolist()
                plate_dict['Focus_Ofs_L'] = plate_df['focus_ofs_l'].values.tolist()
                plate_dict['Focus_Ofs_C'] = plate_df['focus_ofs_c'].values.tolist()
                plate_dict['Focus_Ofs_R'] = plate_df['focus_ofs_r'].values.tolist()
                plate_dict['PreScan_Comp_L'] = plate_df['prescan_comp_l'].values.tolist()
                plate_dict['PreScan_Comp_C'] = plate_df['prescan_comp_c'].values.tolist()
                plate_dict['PreScan_Comp_R'] = plate_df['prescan_comp_r'].values.tolist()
                plate_dict['Prescan_Meas_L'] = plate_df['prescan_meas_l'].values.tolist()
                plate_dict['Prescan_Meas_C'] = plate_df['prescan_meas_c'].values.tolist()
                plate_dict['Prescan_Meas_R'] = plate_df['prescan_meas_r'].values.tolist()

                shot_dict['data'].append(plate_dict)

            data.append(shot_dict)

        return ResponseForm(res=True, data=data)


    def calc_mean_deviation_diff(self, plate_list, df):
        '''
        指定されたPlateの平均値を算出し、各Plateの値から算出した平均値を差し引いてグラフ表示する。 From liplus angular source.

        :param files: args
        :return:
        '''
        mean_dict = dict()

        selected_plate_df = df[df['plate_no'].isin(plate_list)]
        for shot, shot_df in selected_plate_df.groupby('shot_no'):
            mean_df = shot_df.groupby('mask_stage_y')[self.param_list].sum() / len(plate_list)
            mean_dict[shot] = mean_df.to_dict('index')

        for i in range(len(df)):
            mask_stage_y = df['mask_stage_y'].values[i]
            shot_no = df['shot_no'].values[i]
            for col in self.param_list:
                df.at[i, col] = df.at[i, col] - mean_dict[shot_no][mask_stage_y][col]

        return df

