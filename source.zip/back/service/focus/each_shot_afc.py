# coding:utf-8
from common.utils import calculator
"""
---------------------------------------------
Update History:
    No5 各 Shot AFC 補正 (Shot1 基準)
---------------------------------------------
"""


class EachShotAfc:
    """JSONファイルの内容を解析しJSONファイルに書き込む"""
    # JSON化する項目
    event_id_key = 'event_id'
    event_id = 'EachShotAfcEvent'
    event_time = 'event_time'
    device = 'device'
    process = 'process'
    lot_id = 'lot_id'
    plate = 'plate_no'
    step = 'step_no'
    each_shot_afc = 'each_shot'
    drive_height = 'drive_height'
    drive_pitching = 'drive_pitch'
    drive_rolling = 'drive_roll'
    fl = 'zsens_fl'
    fc = 'zsens_fc'
    fr = 'zsens_fr'
    bl = 'zsens_bl'
    bc = 'zsens_bc'
    br = 'zsens_br'
    # P2の設定データコード（10進数）
    P2_SHOT1_SET_CODE = 139316
    # PlateAAタブのPL-Zの設定データコード
    PL_Z_SET_CODE = '22033'
    first_step_dict = {}

    def __init__(self):
        """コンストラクタ
        """

    def calc_each_shot_afc(self, plate_auto_focus_df, processDict):
        outputlist = []
        p2Dict = {}
        # Step数とEachShotのデータを紐づける
        for num in range(1, 37):
            p2Dict[num] = hex(self.P2_SHOT1_SET_CODE).replace('0x', '')
            self.P2_SHOT1_SET_CODE += 1
        # for devprokey in plateAutoFocusCompDict:
        #     for fileCnt in plateAutoFocusCompDict[devprokey]:
        #         # Plate Pre Offset Z(A)を取得
        #         plate_file_offset_z_a = 0
        #         process_param = None
        #         # Processがあればデータ取得。無ければ初期値の0を使用する。
        #         if len(processDict) != 0:
        #             plate_file_offset_z_a = processDict[devprokey][self.PL_Z_SET_CODE] / 1000
        #             process_param = processDict[devprokey]
        #         # 直前のstep
        #         before_step = 0
        #         # 直前のplate
        #         before_plate = 0
        #         # step1の平均
        #         step1_average = 0
        #         # 最初のStep情報
        #         first_step = 0
        #         # 各stepのデータ集計位置を検索
        #         for recordCnt in plateAutoFocusCompDict[devprokey][fileCnt]:
        #             # 長くて見づらいので一時的に置き換える（現在の値）
        #             afc_dict = plateAutoFocusCompDict[devprokey][fileCnt][recordCnt]
        #             # 現在のStepを取得
        #             current_step = afc_dict[self.step]
        #             current_plate = afc_dict[self.plate]
        #             if first_step == 0:
        #                 first_step = current_step
        #             if before_step == 0:
        #                 # 初期値の場合は現在のstepを前回のstepに保存
        #                 before_step = current_step
        #             if before_plate == 0:
        #                 before_plate = current_plate
        #             # stepまたはplateが変化したか？
        #             if current_step != before_step or current_plate != before_plate:
        #                 # データを取得するインデックス
        #                 step_index = -1
        #                 plate_check = -1
        #                 step_check = -1
        #                 # インデックスが範囲外にならないか確認
        #                 if recordCnt - 1 >= 0:
        #                     # 長くて見づらいので一時的に置き換える（1つ前の値）
        #                     afc_dict_one_before = plateAutoFocusCompDict[devprokey][fileCnt][recordCnt - 1]
        #                     plate_check = afc_dict_one_before[self.plate]
        #                     step_check = afc_dict_one_before[self.step]
        #                     # driveの値をチェック
        #                     if self._drive_value_check(afc_dict_one_before):
        #                         # データが0の場合、使用するインデックスを更新
        #                         step_index = recordCnt - 1
        #
        #                 # インデックスが範囲外にならないか確認（ChuckLockの場合があるので2つ上までさかのぼる）
        #                 if recordCnt - 2 >= 0:
        #                     # 長くて見づらいので一時的に置き換える（2つ前の値）
        #                     afc_dict_two_before = plateAutoFocusCompDict[
        #                         devprokey][fileCnt][recordCnt - 2]
        #                     # 同じPlate、Stepの場合しかチェックしない
        #                     if plate_check == afc_dict_two_before[
        #                             self.plate] and step_check == afc_dict_two_before[self.step]:
        #                         # 1つ前と2つ前のplate,stepが同じであれば2つ前のデータも合わせてチェックする
        #                         if afc_dict_one_before[self.plate] == afc_dict_two_before[
        #                                 self.plate] and afc_dict_one_before[self.step] == afc_dict_two_before[self.step]:
        #                             # driveの値をチェック
        #                             if self._drive_value_check(
        #                                     afc_dict_two_before):
        #                                 # 2つ前のデータも0の場合、1つ前のデータはChuckLock後AFCのデータになるため2つ前のデータを使用する
        #                                 step_index = recordCnt - 2
        #
        #                 if step_index == -1:
        #                     # インデックスが見当たらなければスキップ
        #                     continue
        #                 # 長くて見づらいので一時的に置き換える
        #                 afc_dict_target = plateAutoFocusCompDict[devprokey][fileCnt][step_index]
        #                 step1_average = self._append_list(
        #                     afc_dict_target,
        #                     outputlist,
        #                     plate_file_offset_z_a,
        #                     p2Dict,
        #                     process_param,
        #                     step1_average,
        #                     first_step)
        #                 # 現在のstep,plateを保存
        #                 before_step = current_step
        #                 before_plate = current_plate
        #             # 最終行か？
        #             if recordCnt + \
        #                     1 == len(plateAutoFocusCompDict[devprokey][fileCnt]):
        #                 # 長くて見づらいので一時的に置き換える（現在の値）
        #                 afc_dict = plateAutoFocusCompDict[devprokey][fileCnt][recordCnt]
        #                 # driveの値をチェック
        #                 if self._drive_value_check(afc_dict):
        #                     afc_dict_target = plateAutoFocusCompDict[devprokey][fileCnt][recordCnt]
        #                     step1_average = self._append_list(
        #                         afc_dict_target,
        #                         outputlist,
        #                         plate_file_offset_z_a,
        #                         p2Dict,
        #                         process_param,
        #                         step1_average,
        #                         first_step)
        # # fist stepの項目を追加
        # for devpro in self.first_step_dict:
        #     for plate in self.first_step_dict[devpro]:
        #         for step in self.first_step_dict[devpro][plate]:
        #             outputlist.append(
        #                 self.first_step_dict[devpro][plate][step])
        # Plate Pre Offset Z(A)を取得
        devprokey = plate_auto_focus_df['job'].values[0]
        plate_file_offset_z_a = 0
        process_param = None
        # Processがあればデータ取得。無ければ初期値の0を使用する。
        if len(processDict) != 0:
            process_param = processDict[devprokey]
            plate_file_offset_z_a = process_param[process_param['key'] == self.PL_Z_SET_CODE]['val'].values[0] / 1000
            # plate_file_offset_z_a = processDict[devprokey][self.PL_Z_SET_CODE] / 1000

        plate_group_df = plate_auto_focus_df.groupby('plate_no')
        for plate_no, plate_df in plate_group_df:
            # step1の平均
            step1_average = 0
            step_group_df = plate_df.groupby('step_no')
            first_step = plate_df['step_no'].values[0]
            for step_no, step_df in step_group_df:
                afc_dict_target = None
                if len(step_df) > 0:
                    tmp_dict = step_df.iloc[-1].to_dict()
                    if self._drive_value_check(tmp_dict):
                        afc_dict_target = tmp_dict

                if len(step_df) >= 2:
                    tmp_dict = step_df.iloc[-2].to_dict()
                    if self._drive_value_check(tmp_dict):
                        afc_dict_target = tmp_dict

                if afc_dict_target is not None:
                    step1_average = self._append_list(
                        afc_dict_target,
                        outputlist,
                        plate_file_offset_z_a,
                        p2Dict,
                        process_param,
                        step1_average,
                        first_step)
        # fist stepの項目を追加
        for devpro in self.first_step_dict:
            for plate in self.first_step_dict[devpro]:
                for step in self.first_step_dict[devpro][plate]:
                    outputlist.append(
                        self.first_step_dict[devpro][plate][step])

        return outputlist

    def _drive_value_check(self, afc_dict):
        """driveの各値が全て0かチェックする。
           0ならTrue、それ以外ならFalseを返却する
        """
        # データを取得
        drive_height = afc_dict[self.drive_height]
        drive_pitching = afc_dict[self.drive_pitching]
        drive_rolling = afc_dict[self.drive_rolling]
        if drive_height == 0 and drive_pitching == 0 and drive_rolling == 0:
            return True
        return False

    def _append_list(self, afc_dict_target, outputlist,
                     plate_file_offset_z_a, p2Dict, process_data, step1_average, first_step):
        """リストに計算結果を追加する"""
        # 平均値を取得
        average_list = []
        average_list.append(calculator.nm_to_um(afc_dict_target[self.fl]))
        average_list.append(calculator.nm_to_um(afc_dict_target[self.fc]))
        average_list.append(calculator.nm_to_um(afc_dict_target[self.fr]))
        average_list.append(calculator.nm_to_um(afc_dict_target[self.bl]))
        average_list.append(calculator.nm_to_um(afc_dict_target[self.bc]))
        average_list.append(calculator.nm_to_um(afc_dict_target[self.br]))
        # 各plateのfirst_stepなら平均値を保存（最初がStep1じゃない可能性があるため、ログの先頭のStepを基準にする）
        if afc_dict_target[self.step] == first_step:
            step1_average = sum(
                average_list) / len(average_list)
            outputdict = {}
            outputdict[self.event_id_key] = self.event_id
            # outputdict[self.event_time] = afc_dict_target[self.event_time]
            outputdict[self.plate] = afc_dict_target[self.plate]
            outputdict[self.step] = afc_dict_target[self.step]
            outputdict[self.device] = afc_dict_target[self.device]
            outputdict[self.process] = afc_dict_target[self.process]
            outputdict[self.lot_id] = afc_dict_target[self.lot_id]
            # step1との差分のため、step1の場合は必ず0になる
            outputdict[self.each_shot_afc] = step1_average - \
                step1_average
            plate = afc_dict_target[self.plate]
            step = afc_dict_target[self.step]
            jobkey = afc_dict_target[self.device] + \
                '/' + afc_dict_target[self.process]
            step_dict = {}
            if jobkey in self.first_step_dict.keys():
                if plate in self.first_step_dict[jobkey].keys():
                    if step in self.first_step_dict[jobkey][plate].keys():
                        # すでに登録済みの情報だったら削除（PrePreScan対応）
                        del self.first_step_dict[jobkey][plate][step]
                else:
                    # Jobのkeyが作成済みでplateが無い状態なら、新しいplate番号の要素を追加
                    self.first_step_dict[jobkey][plate] = {}
            else:
                # Jobのkeyが未作成だったら新しい要素を追加
                self.first_step_dict[jobkey] = {}
            step_dict[step] = outputdict
            self.first_step_dict[jobkey][plate] = step_dict
        else:
            # first_step以外なら
            average = sum(average_list) / \
                len(average_list)
            outputdict = {}
            outputdict[self.event_id_key] = self.event_id
            # outputdict[self.event_time] = afc_dict_target[self.event_time]
            outputdict[self.plate] = afc_dict_target[self.plate]
            outputdict[self.step] = afc_dict_target[self.step]
            outputdict[self.device] = afc_dict_target[self.device]
            outputdict[self.process] = afc_dict_target[self.process]
            outputdict[self.lot_id] = afc_dict_target[self.lot_id]
            pre_calc = step1_average + plate_file_offset_z_a
            # step数に該当するZ-AA-Offsetの設定データコードを取得
            z_aa_offset_code = p2Dict[afc_dict_target[self.step]]
            # 該当箇所の値を取得
            z_aa_offset_data = 0
            # Processデータあれば設定データコードを使用して値を取得。なければ0固定。
            if process_data is not None:
                z_aa_offset_data = process_data[process_data['key'] == z_aa_offset_code]['val'].values[0] / 1000
            fine_calc = average + z_aa_offset_data
            # step1との差分を計算
            outputdict[self.each_shot_afc] = fine_calc - pre_calc
            outputlist.append(outputdict)
        return step1_average
