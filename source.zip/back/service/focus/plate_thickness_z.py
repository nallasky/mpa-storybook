# coding:utf-8
from common.utils import calculator
'''
---------------------------------------------
No.7 Plate 厚み変動補正

Update History:
    [2020/10/01] 新規作成

Copyright(C) Canon Inc. All right reserved.
---------------------------------------------
'''


class PlateThicknessZ:
    """ Plate 厚み変動補正 取得Class """

    # イベントid
    event_id = 'PlateThicknessZEvent'

    # PlateAFCタブのEach Shot AFC Average Compの設定データコード
    AFC_AVE_COMP_SET_CODE = '12a20'

    def __init__(self):
        """コンストラクタ
        """

    def calc_plate_thickness_z(
            self, plate_focus_interlock, focusUtil, stepCountList):
        """Plate 厚み変動補正の計算
        param plate_focus_interlock PlateFocusInterlockMonitorのログ
        param FocusUtilのインスタンス
        param stepCountList Step数
        """
        # 返却するデータセット
        outputlist = []
        # for devprokey in plate_focus_interlock:
        devprokey = plate_focus_interlock['job'].values[0]
        stepCount = 0
        # JobごとのStep数を取得
        for stepData in stepCountList:
            job = str(stepData.get('device')) + '/' + \
                str(stepData.get('process'))
            if devprokey == job:
                stepCount = stepData.get('step_count')
                break
        file_groups = plate_focus_interlock.groupby('file_cnt')
        for fileCnt, file_df in file_groups:
            # 合計値
            height_sum = 0
            height_cnt = 0
            event_time = 0
            step_dict = {}
            # outputdict = {}
            check_flg = False
            plate_buff = 0
            # 1ファイルごとにplate stageを取得
            for i in range(len(file_df)):
                data_dict = file_df.iloc[i].to_dict()
                pos = data_dict.get('pos')
                current_plate = data_dict.get('plate_no')
                # 時刻は最後に取得したものを使用する
                event_time = data_dict.get('log_time')
                if plate_buff == 0:
                    plate_buff = current_plate
                if current_plate == plate_buff:
                    # posがPLATEのFocus DifferenceのHeight[um]の平均値を算出する
                    if(pos == 'PLATE'):
                        height = calculator.nm_to_um(data_dict.get('focus_diff_height'))
                        step = data_dict.get('step_no')
                        # 平均算出用に加算
                        height_sum += height
                        height_cnt += 1
                        # PLATEのStepの値を保存
                        step_dict[step] = height
                        check_flg = True
                else:
                    # Plateが変わったらリストに追加
                    self._append_list(stepCount, event_time, data_dict, plate_buff, step_dict,
                                      height_sum, height_cnt, check_flg, outputlist)
                    # Plateを更新
                    plate_buff = current_plate
                    # 初期化
                    height_sum = 0
                    height_cnt = 0
            # 最後のPlateはループ内で出力されないため以下で出力
            if check_flg:
                self._append_list(stepCount, event_time, data_dict, plate_buff, step_dict,
                                  height_sum, height_cnt, check_flg, outputlist)

        return outputlist

    def _append_list(self, stepCount, event_time,
                     data_dict, plate_buff, step_dict, height_sum, height_cnt, check_flg, outputlist):
        """ リストに要素を追加する"""
        # time_array = event_time.split('.')
        event_idx = 0
        # Step数分結果を出力する
        for num in range(1, stepCount + 1):
            outputdict = {}
            outputdict['event_id'] = self.event_id
            # outputdict['event_time'] = time_array[0] + \
            #     '.' + format(event_idx, '06') + '+0900'
            outputdict['log_time'] = event_time
            outputdict['device'] = data_dict.get('device')
            outputdict['process'] = data_dict.get('process')
            outputdict['lot_id'] = data_dict.get('lot_id')
            outputdict['plate_no'] = plate_buff
            outputdict['step_no'] = num
            # PosがPLATEの位置があったか？
            if check_flg:
                # Step1か？
                if num == 1:
                    # Step1は0固定
                    outputdict['plate_thick_z'] = 0
                # PosがPLATEのStepか？
                elif num in step_dict.keys():
                    # PosがPLATEのStepはheightの値をそのまま出力
                    outputdict['plate_thick_z'] = step_dict[num]
                else:
                    if height_sum == 0 or height_cnt == 0:
                        outputdict['plate_thick_z'] = 0
                    else:
                        # その他は平均値÷2の値を設定
                        outputdict['plate_thick_z'] = height_sum / \
                            height_cnt / 2
            else:
                outputdict['plate_thick_z'] = 0
            outputlist.append(outputdict)
            # イベントTimeをStep数分ずらしていく
            event_idx = event_idx + 1
