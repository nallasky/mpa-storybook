# coding:utf-8
from common.utils import calculator
'''
---------------------------------------------
Update History:
        No1 FC_基準_PSZ
---------------------------------------------
'''


class FcBasePSZ:
    """JSONファイルの内容を解析しJSONファイルに書き込む"""
    # JSON化する項目
    event_id_key = 'event_id'
    event_id = 'FcBasePSZEvent'
    event_time = 'event_time'
    device = 'device'
    process = 'process'
    lot_id = 'lot_id'
    plate = 'plate_no'
    step = 'step_no'
    drive_height = 'drive_height'
    drive_pitching = 'drive_pitch'
    drive_rolling = 'drive_roll'
    stage_position_height = 'stage_pos_afc_meas_height'
    fc_base_psz = 'afc_base_z'
    # PlateAAタブのPL-Zの設定データコード
    PL_Z_SET_CODE = '22033'
    # 利用する関数が多いため、クラスが呼ばれた時点で必要なデータをクラス変数に持たせる
    PROCESS_DICT = None
    PLATE_AUTO_FOCUS_DF = None
    DATA_NO2_CALC = None
    DATA_NO3_CALC = None
    DATA_NO4_CALC = None
    DATA_NO6_CALC = None
    no6_result = {}

    def __init__(self):
        """コンストラクタ
        """

    def calc_fc_base_psz(
            self, processDict, plate_auto_focus_df, data_no2_calc, data_no3_calc, data_no4_calc, data_no6_calc):
        """
        FC_基準_PSZの計算結果を返す
        param processDict Processデータ
        param plateAutoFocusCompDict plateAutoFocusのログ
        param data_no2_calc No2の計算結果
        param data_no3_calc No3の計算結果
        param data_no4_calc No4の計算結果
        param data_no6_calc No6の計算結果
        """
        self.PROCESS_DICT = processDict
        self.PLATE_AUTO_FOCUS_DF = plate_auto_focus_df
        self.DATA_NO2_CALC = data_no2_calc
        self.DATA_NO3_CALC = data_no3_calc
        self.DATA_NO4_CALC = data_no4_calc
        self.DATA_NO6_CALC = data_no6_calc
        outputlist = []
        # # device/process情報を取得
        # for devprokey in plateAutoFocusCompDict:
        #     # Recallの1レコードごとの集計
        #     for fileCnt in plateAutoFocusCompDict[devprokey]:
        #         # 変数を初期化。0の値をチェックするので初期値を1にする。
        #         before_drive_height_ = 1
        #         before_drive_pitching_ = 1
        #         before_drive_rolling_ = 1
        #         stage_position_height = 0
        #         plate_buff = 0
        #         afc_lot_id = ''
        #         afc_event_time = ''
        #         afc_device = ''
        #         afc_process = ''
        #         afc_plate = ''
        #         afc_step = ''
        #         outputdict = {}
        #         # Recallの1レコードごとの集計
        #         for recordCnt in plateAutoFocusCompDict[devprokey][fileCnt]:
        #             data_dict = plateAutoFocusCompDict[devprokey][fileCnt][recordCnt]
        #             # plate_buffが初期値の場合、現在のPlateを記録する
        #             if plate_buff == 0:
        #                 plate_buff = data_dict[self.plate]
        #             # Plateが変わったら、再度追い込み位置をチェックする。
        #             if plate_buff != data_dict[self.plate]:
        #                 calc_result = self._get_fc_base_psz(
        #                     devprokey,
        #                     afc_lot_id,
        #                     afc_plate,
        #                     stage_position_height)
        #                 outputdict[self.fc_base_psz] = calc_result
        #                 outputlist.append(outputdict)
        #                 outputdict = {}
        #                 plate_buff = data_dict[self.plate]
        #
        #             drive_height_ = data_dict[self.drive_height]
        #             drive_pitching_ = data_dict[self.drive_pitching]
        #             drive_rolling_ = data_dict[self.drive_rolling]
        #             # 現在のレコードのdriveの値が全て0か？
        #             if drive_height_ == 0 and drive_pitching_ == 0 and drive_rolling_ == 0:
        #                 # 現在のレコードと直前のレコードのdriveが全て0か？
        #                 if before_drive_height_ == 0 and before_drive_pitching_ == 0 and before_drive_rolling_ == 0:
        #                     # 現在と直前のレコードが全て0の場合、現在のレコードはChuck Lockのデータになる。
        #                     # Chuck Lockのデータは使用しないのでスキップ
        #                     continue
        #                 else:
        #                     # やり直しがある可能性があるのでStepが切り替わるまで値を更新する
        #                     # AFC追い込み後の値を保存
        #                     stage_position_height = data_dict[self.stage_position_height]
        #                     # LotIDを取得
        #                     afc_lot_id = data_dict[self.lot_id]
        #                     # event_timeを取得
        #                     afc_event_time = data_dict[self.event_time]
        #                     # device/process情報を取得
        #                     afc_device = data_dict[self.device]
        #                     afc_process = data_dict[self.process]
        #                     # plateを取得
        #                     afc_plate = data_dict[self.plate]
        #                     # stepを取得
        #                     afc_step = data_dict[self.step]
        #                     outputdict = {}
        #                     outputdict['event_id'] = self.event_id
        #                     outputdict[self.event_time] = afc_event_time
        #                     outputdict[self.device] = afc_device
        #                     outputdict[self.process] = afc_process
        #                     outputdict[self.lot_id] = afc_lot_id
        #                     outputdict[self.plate] = afc_plate
        #                     outputdict[self.step] = afc_step
        #
        #                     # 直前の値を更新
        #                     before_drive_height_ = drive_height_
        #                     before_drive_pitching_ = drive_pitching_
        #                     before_drive_rolling_ = drive_rolling_
        #             else:
        #                 # 初期値に戻す
        #                 before_drive_height_ = 1
        #                 before_drive_pitching_ = 1
        #                 before_drive_rolling_ = 1
        #         # ファイル読み込み完了後、ループ処理内ではPlateが変化したタイミングで出力しているため、
        #         # 最後のPlateが出力されていない。そのため以下で個別に出力する。
        #         calc_result = self._get_fc_base_psz(
        #             devprokey,
        #             afc_lot_id,
        #             afc_plate,
        #             stage_position_height)
        #         outputdict[self.fc_base_psz] = calc_result
        #         outputlist.append(outputdict)
        #         outputdict = {}
        for plate_no, plate_df in plate_auto_focus_df.groupby('plate_no'):
            plate_df['drive_check'] = plate_df[[self.drive_height, self.drive_pitching, self.drive_rolling]].apply(
                lambda x: 1 if any(x) is True else 0,
                axis=1
            )
            target_df = plate_df[plate_df['drive_check'].shift() - plate_df['drive_check'] == 1]
            if len(target_df) == 0:
                continue

            data_dict = target_df.iloc[-1].to_dict()

            stage_position_height = calculator.nm_to_um(data_dict[self.stage_position_height])
            # LotIDを取得
            afc_lot_id = data_dict[self.lot_id]
            # device/process情報を取得
            afc_device = data_dict[self.device]
            afc_process = data_dict[self.process]
            # plateを取得
            afc_plate = data_dict[self.plate]
            # stepを取得
            afc_step = data_dict[self.step]

            devprokey = data_dict['job']

            outputdict = {}
            outputdict['event_id'] = self.event_id
            outputdict[self.device] = afc_device
            outputdict[self.process] = afc_process
            outputdict[self.lot_id] = afc_lot_id
            outputdict[self.plate] = afc_plate
            outputdict[self.step] = afc_step

            calc_result = self._get_fc_base_psz(
                devprokey,
                afc_lot_id,
                afc_plate,
                stage_position_height)
            outputdict[self.fc_base_psz] = calc_result
            outputlist.append(outputdict)

        return outputlist

    def _get_calc_data(self, data_dict, devprokey, lotid, plate, paramkey):
        """指定されたDev/ProとLotIDから指定されたkeyでデータを取得する
        param data_dict 他クラスの計算結果
        param devprokey DeviceProcessのキー情報
        param lotid LotID
        param paramkey 計算結果から取り出すキー情報
        """
        result = 0
        # データがNoneなら何もせずに終了
        if data_dict is None:
            return result
        # Dev/ProとLotIDが空で無ければデータを取得する
        if data_dict.get(devprokey) is not None:
            if data_dict.get(devprokey).get(lotid) is not None:
                if data_dict.get(devprokey).get(lotid) is not None:
                    # No6だけ例外
                    if "each_shot_pr_offset_other_pre" != paramkey:
                        if data_dict.get(devprokey).get(
                                lotid).get(plate) is not None:
                            result = data_dict.get(devprokey).get(
                                lotid).get(plate).get(paramkey)
                    else:
                        # StagePositionMonitorから取得したNo6の計算結果のPlateと
                        # 本関数のplateの引数が必ずしも一致するとは限らないのでNo6は
                        # Plateのチェック無し
                        key = list(data_dict.get(devprokey).get(lotid).keys())
                        result = data_dict.get(devprokey).get(
                            lotid).get(key[0]).get(paramkey)
                    # 取得結果がNoneなら0にする。None以外ならそのまま
                    result = result if result is not None else 0
        return result

    def _get_fc_base_psz(self, devprokey, afc_lot_id,
                         afc_plate, stage_position_height):
        """FC_基準_PSZの計算結果を返す
        param devprokey DeviceProcessのキー情報
        param afc_lot_id LotID
        param afc_plate Plate
        param stage_position_height AFC追い込み後の値
        """
        no3_result = self._get_calc_data(
            self.DATA_NO3_CALC, devprokey, afc_lot_id, afc_plate, "afc_drive_lips_other_z_base")
        no4_result = self._get_calc_data(
            self.DATA_NO4_CALC, devprokey, afc_lot_id, afc_plate, "lips_z")
        # No6の計算結果には最初のPlateの情報しか入っていないため、最初に取得した情報を使いまわす
        if devprokey not in self.no6_result.keys():
            self.no6_result[devprokey] = self._get_calc_data(
                self.DATA_NO6_CALC, devprokey, afc_lot_id, afc_plate, "each_shot_pr_offset_other_pre")
        psz = 0
        no2_result = 0
        if self.DATA_NO2_CALC is not None and self.DATA_NO2_CALC.get(
                devprokey) is not None:
            no2_result = self.DATA_NO2_CALC.get(devprokey).get(
                'afc_drive_z')
            # 取得結果がNoneなら0にする。None以外ならそのまま
            no2_result = no2_result if no2_result is not None else 0

        # Processデータが無ければpszは初期値の0を使用する。
        if len(self.PROCESS_DICT) != 0:
            if self.PROCESS_DICT.get(devprokey) is not None:
                # psz = self.PROCESS_DICT.get(devprokey).get(
                #     self.PL_Z_SET_CODE) / 1000
                process_df = self.PROCESS_DICT.get(devprokey)
                psz = process_df[process_df['key'] == self.PL_Z_SET_CODE]['val'].values[0]
                # 取得結果がNoneなら0にする。None以外ならそのまま
                psz = psz if psz is not None else 0

        no6_data = 0
        # 念のためkeyチェックしてから値を取得
        if devprokey in self.no6_result.keys():
            no6_data = self.no6_result[devprokey]
        # stage_position_height + No2 + No4 + psz - No3 - No6
        result = stage_position_height + no2_result + \
            no4_result + psz - no3_result - no6_data

        return result
