# coding:utf-8
from common.utils import calculator
'''
---------------------------------------------
Update History:
    No11 Chuck Lock AFC補正
---------------------------------------------
'''


class ChuckLockAfcCorrection:
    """JSONファイルの内容を解析しJSONファイルに書き込む"""
    # JSON化する項目
    event_id_key = 'event_id'
    event_id = 'ChuckLockAfcCorrectionEvent'
    event_time = 'event_time'
    device = 'device'
    process = 'process'
    lot_id = 'lot_id'
    plate = 'plate_no'
    step = 'step_no'
    chuck_lock_afc_z = 'chuck_lock_z'
    drive_height = 'drive_height'
    drive_pitching = 'drive_pitch'
    drive_rolling = 'drive_roll'
    fc = 'zsens_fc'
    fl = 'zsens_fl'
    fr = 'zsens_fr'
    bc = 'zsens_bc'
    bl = 'zsens_bl'
    br = 'zsens_br'
    # PlateAAタブのPL-Zの設定データコード
    PL_Z_SET_CODE = '22033'
    # P2の設定データコード（10進数）
    P2_SHOT1_SET_CODE = 139316

    def __init__(self):
        """コンストラクタ
        """

    def calc_chuck_lock_afc_correction(
            self, plate_auto_focus_df, processDict):
        """
        PlateAutoFocusCompensationのRecallログとprocessデータのEACH SHOTの情報を読み込む。
        Plateごとの最初のStepでdrive_height、drive_pitching、drive_rollingの値が全て0の箇所が追い込み位置、
        次の0の箇所がChuck Lock後AFCになる。
        """
        p2Dict = {}
        # Step数とEachShotのデータを紐づける
        for num in range(1, 37):
            p2Dict[num] = hex(self.P2_SHOT1_SET_CODE).replace('0x', '')
            self.P2_SHOT1_SET_CODE += 1
        outputlist = []
        # device/process情報を取得
        # for devprokey in plateAutoFocusCompDict:
        #     # Recallの1レコードごとの集計
        #     for fileCnt in plateAutoFocusCompDict[devprokey]:
        #         # 変数を初期化。0の値をチェックするので初期値を1にする。
        #         before_drive_height_ = 1
        #         before_drive_pitching_ = 1
        #         before_drive_rolling_ = 1
        #         before_average = 0
        #         plate_buff = 0
        #         step_buff = 0
        #         outputdict = {}
        #         # Recallの1レコードごとの集計
        #         for recordCnt in plateAutoFocusCompDict[devprokey][fileCnt]:
        #             # 見づらいので置き換える
        #             data_dict = plateAutoFocusCompDict[devprokey][fileCnt][recordCnt]
        #             drive_height_ = data_dict[self.drive_height]
        #             drive_pitching_ = data_dict[self.drive_pitching]
        #             drive_rolling_ = data_dict[self.drive_rolling]
        #             current_step = data_dict[self.step]
        #             # 変数が初期値なら現在のstepを設定
        #             if step_buff == 0:
        #                 step_buff = current_step
        #             # Stepが変化したら初期化
        #             if step_buff != current_step:
        #                 before_drive_height_ = 1
        #                 before_drive_pitching_ = 1
        #                 before_drive_rolling_ = 1
        #                 step_buff = current_step
        #             # 現在のレコードのdriveの値が全て0か？
        #             if drive_height_ == 0 and drive_pitching_ == 0 and drive_rolling_ == 0:
        #                 # 現在のレコードと直前のレコードのdriveが全て0か？
        #                 if before_drive_height_ == 0 and before_drive_pitching_ == 0 and before_drive_rolling_ == 0:
        #                     current_plate = data_dict[self.plate]
        #                     current_step = data_dict[self.step]
        #                     # 変数が初期値なら現在のplateを設定
        #                     if plate_buff == 0:
        #                         plate_buff = current_plate
        #                     # plateが変化したら前のplateの情報を出力
        #                     if plate_buff != current_plate:
        #                         if outputdict is not None:
        #                             # 同じPlate番号が複数出力される可能性があるため、最後のデータを出力する
        #                             outputlist.append(outputdict)
        #                             outputdict = {}
        #                         plate_buff = current_plate
        #                         step_buff = current_step
        #
        #                     # Chuck Lockの平均値
        #                     average = self._get_average(data_dict)
        #                     plate_file_offset_z_a = 0
        #                     plateAaStep = 0
        #                     # Processデータが無ければ0を使用する。
        #                     if len(processDict) != 0:
        #                         # Plate Pre Offset Z(A)を取得
        #                         plate_file_offset_z_a = processDict[devprokey][self.PL_Z_SET_CODE] / 1000
        #                         # P2の設定データコードの該当するStepを取得
        #                         plateAaStep = processDict[devprokey][p2Dict[current_step]] / 1000
        #                     # Chuck Lock補正量を計算
        #                     calcResult = (
        #                         average + plateAaStep - (before_average + plate_file_offset_z_a))
        #                     outputdict[self.event_id_key] = self.event_id
        #                     outputdict[self.event_time] = data_dict[self.event_time]
        #                     outputdict[self.plate] = current_plate
        #                     outputdict[self.step] = current_step
        #                     outputdict[self.device] = data_dict[self.device]
        #                     outputdict[self.process] = data_dict[self.process]
        #                     outputdict[self.lot_id] = data_dict[self.lot_id]
        #                     outputdict[self.chuck_lock_afc_z] = calcResult
        #                 else:
        #                     # 直前の値を更新
        #                     before_drive_height_ = drive_height_
        #                     before_drive_pitching_ = drive_pitching_
        #                     before_drive_rolling_ = drive_rolling_
        #                     # 追い込み後の平均値として使用するため計算しておく
        #                     before_average = self._get_average(data_dict)
        #             else:
        #                 # 初期値に戻す
        #                 before_drive_height_ = 1
        #                 before_drive_pitching_ = 1
        #                 before_drive_rolling_ = 1
        #         if outputdict is not None:
        #             # 最後のPlateはループ内で出力されないため以下で出力
        #             outputlist.append(outputdict)
        devprokey = plate_auto_focus_df['job'].values[0]
        process_df = None
        if devprokey in processDict:
            process_df = processDict[devprokey]

        plate_group_df = plate_auto_focus_df.groupby('plate_no')
        for plate_no, plate_df in plate_group_df:
            step_group_df = plate_df.groupby('step_no')
            for step_no, step_df in step_group_df:
                if len(step_df) < 2:
                    continue

                for i in range(-2, -(len(step_df)+1), -1):
                    before = step_df[[self.drive_height, self.drive_pitching, self.drive_rolling]].values[i]
                    cur = step_df[[self.drive_height, self.drive_pitching, self.drive_rolling]].values[i+1]
                    if any(before) is False and any(cur) is False:
                        before_dict = step_df.iloc[i].to_dict()
                        cur_dict = step_df.iloc[i+1].to_dict()
                        before_average = self._get_average(before_dict)
                        # Chuck Lockの平均値
                        average = self._get_average(cur_dict)
                        plate_file_offset_z_a = 0
                        plateAaStep = 0
                        # Processデータが無ければ0を使用する。
                        if process_df is not None:
                            # Plate Pre Offset Z(A)を取得
                            plate_file_offset_z_a = process_df[process_df['key'] == self.PL_Z_SET_CODE]['val'].values[0] / 1000
                            # P2の設定データコードの該当するStepを取得
                            plateAaStep = process_df[process_df['key'] == p2Dict[cur_dict[self.step]]]['val'].values[0] / 1000
                        # Chuck Lock補正量を計算
                        outputdict = dict()
                        calcResult = (
                                average + plateAaStep - (before_average + plate_file_offset_z_a))
                        outputdict[self.event_id_key] = self.event_id
                        # outputdict[self.event_time] = cur_dict[self.event_time]
                        outputdict[self.plate] = cur_dict[self.plate]
                        outputdict[self.step] = cur_dict[self.step]
                        outputdict[self.device] = cur_dict[self.device]
                        outputdict[self.process] = cur_dict[self.process]
                        outputdict[self.lot_id] = cur_dict[self.lot_id]
                        outputdict[self.chuck_lock_afc_z] = calcResult

                        outputlist.append(outputdict)
                        break

        return outputlist

    def _get_average(self, dataDict):
        """ ログのfc,fl,fr,bc,bl,brの平均を取得し、返却する。
        param dataDict AFCのDict
        """
        averagelist = []
        averagelist.append(calculator.nm_to_um(dataDict[self.fc]))
        averagelist.append(calculator.nm_to_um(dataDict[self.fl]))
        averagelist.append(calculator.nm_to_um(dataDict[self.fr]))
        averagelist.append(calculator.nm_to_um(dataDict[self.bc]))
        averagelist.append(calculator.nm_to_um(dataDict[self.bl]))
        averagelist.append(calculator.nm_to_um(dataDict[self.br]))
        average = sum(averagelist) / len(averagelist)

        return average
