import os
import logging
import sqlite3
import pandas as pd
import traceback
import math
import numpy as np

from config import app_config
from common.utils.response import ResponseForm, make_json_response
from dao.dao_file import FileDao
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from controller.converter.converter import create_request_id
from service.converter.convert_process import ConvertProcess
from common.utils import preprocessing


logger = logging.getLogger(app_config.LOG)


class ServiceFocusChuck:
    log_list = app_config.FOCUS_CHUCK_LOG_LIST + ['machine']
    category_name = 'Focus'
    log_name = 'chuck'

    chuck_direct = 'platechuckdirect'
    chuck_scan = 'platechuckscan'
    chuck_range = 'platechuckrangescan'

    graph_all = 'All'
    graph_each = 'Each Shot/Normal'
    graph_free = 'Each Shot/Free Layout'

    current_mode = 'Current'
    predictive_mode = 'Predictive'
    org_mode = 'Original'
    compensate_mode = 'Compensated'
    compensate_avg_mode = 'Compensated- - Average'

    G86MAX_PLATE_SIZE_X = 2400
    EDGE_INTERVAL_20 = 20


    def __init__(self):
        self.root_path = app_config.root_path
        self.form = {
            'id': None,
            'job_type': 'local',
            'file': [],
            'log_name': self.log_name
        }

    def file_check(self, files):
        """
        :param files: [files]
        :return: {'log_name': [fids]}
        """
        # Check file count
        if len(files) == 0:
            return ResponseForm(res=False, msg='Cannot find any file.')

        # 最小必要ログチェック
        if len(list(set(app_config.FOCUS_CHUCK_LOG_LIST) & set(files.keys()))) == 0:
            return ResponseForm(res=False, msg=f'One of "{app_config.FOCUS_CHUCK_LOG_LIST}" Log must be included.')

        if not os.path.exists(self.root_path):
            os.mkdir(self.root_path)

        data = dict()

        for log_name, file_data in files.items():
            if file_data is None:
                continue
            for file in file_data:
                filename = file.filename
                foldername = os.path.join(self.root_path, log_name)
                if not os.path.exists(foldername):
                    os.mkdir(foldername)
                if log_name not in data:
                    data[log_name] = list()
                f = None
                file_index = 1
                while f is None or os.path.exists(f):
                    _filename = f'{file_index}{app_config.UPLOAD_FILE_SEPERATOR}{filename}'
                    f = os.path.join(foldername, _filename)
                    file_index += 1
                file.save(f)
                fid = FileDao.instance().insert_file(os.path.basename(f), os.path.abspath(f))

                if fid is None:
                    logger.error('failed to store file info')
                    return ResponseForm(res=False, msg='failed to store file info')

                data[log_name].append(fid)

        return ResponseForm(res=True, data=data)

    def convert(self, logs):
        """
        :param logs: { 'log_name': [fids] }
        :return:
        """

        # Create Request ID
        self.form['id'] = create_request_id()

        file_id_list = list()
        for log_name, val in logs.items():
            file_id_list.append(','.join([str(_) for _ in logs[log_name]]))

        self.form['file'] = ','.join(file_id_list)

        # Insert Job info into cnvset.job
        io = DAOJob.instance()
        try:
            io.insert_job(**self.form)
        except Exception as e:
            logger.error('failed to insert job')
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))

        # Create sub processor to convert log
        target_logs = dict()
        dao = DAOBaseClass()
        for log_name, val in logs.items():
            # #sqlite
            if isinstance(dao.connect, sqlite3.Connection):
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis_function as a " \
                        f"inner join analysis_local_info as b on a.id = b.func_id " \
                        f"inner join analysis_category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{log_name}' and title='{self.category_name}'"
            else:
                query = f"select d.id from " \
                        f"(select a.id, a.system_func, b.log_name, c.title from analysis.function as a " \
                        f"inner join analysis.local_info as b on a.id = b.func_id " \
                        f"inner join analysis.category as c on a.category_id = c.id) as d " \
                        f"where system_func=true and log_name='{log_name}' and title='{self.category_name}'"

            row = dao.execute(query)
            if row is None or len(row) == 0:
                del dao
                return ResponseForm(res=False, msg=f'Cannot find {log_name} function.')

            target_logs[log_name] = row[0][0]

        del dao
        cnv_proc = ConvertProcess(self.form['id'], target_logs)
        cnv_proc.start()

        return ResponseForm(res=True, data=self.form['id'])

    def get_plate_chuck_data(self, args):
        """
        Get Correction Data.
        :param args
        :return:
        """
        rid = args['rid']
        category = args['category']
        file_name = args['file_select']
        graph_display = args['graph_display']

        filter = dict()
        filter['filename'] = file_name
        log_list = app_config.FOCUS_CHUCK_LOG_LIST
        log_dict = preprocessing.load_platechuck_log(rid=rid, log_list=log_list, **filter)
        if len(log_dict) == 0:
            return make_json_response(status=400, msg='Data Empty.')

        df = pd.DataFrame()
        for key in app_config.FOCUS_CHUCK_LOG_LIST:
            if key in log_dict.keys():
                df = pd.concat([df, log_dict[key]])

        graph_display['category'] = list(log_dict.keys())[0]

        df = log_dict[list(log_dict.keys())[0]]

        graph_data, calc_data, calc_result = self.calc(df, graph_display)

        data = dict()
        data['summary'] = {
            "Average[um]": calc_result['average'],
            "Min[um]": calc_result['min'],
            "Max[um]": calc_result['max'],
            "Range[um]": calc_result['range'],
            "Rolling[sec]": calc_result['roll'],
            "Pitching[sec]": calc_result['pitch']
        }
        if graph_display['category'] == self.chuck_direct:
            calc_data = calc_data.sort_values(by=['y_data', 'x_data'], ascending=[False, True])
            data['graph'] = {
                "x": calc_data['x_data'].drop_duplicates().to_list(),
                "y": calc_data['y_data'].drop_duplicates().to_list(),
                "z": calc_data['z_data'].to_list()
            }
        else:
            graph_data = graph_data.sort_values(by=['y_data', 'x_data'], ascending=[False, True])
            data['graph'] = {
                "x": graph_data['x_data'].drop_duplicates().to_list(),
                "y": graph_data['y_data'].drop_duplicates().to_list(),
                "z": graph_data['z_data'].to_list()
            }

        return ResponseForm(res=True, data=data)

    def calc(self, df, display_setting):
        category = display_setting['category']
        graph_mode = display_setting['mode']
        graph_type = display_setting['data_display']
        calc_result = dict()
        graph_data = pd.DataFrame()
        calc_data = pd.DataFrame()

        df = df.astype({'x_data': float, 'y_data': float, 'z_data': float})
        if 'z_predict' in df.columns:
            df = df.astype({'z_predict': float})
        if 'z_data_org' in df.columns:
            df = df.astype({'z_data_org': float})

        if graph_mode == self.graph_all:
            graph_data = df[['x_data', 'y_data', 'z_data']]
            calc_data = graph_data
            if category == self.chuck_direct:
                temp_df = df[['x_data', 'y_data', 'z_data_org']].rename(columns={'z_data_org': 'z_data'})
                calc_result = self.result_data_calc(data=temp_df, calc_result=calc_result, is_compensated=False)
            else:
                calc_result = self.result_data_calc(data=graph_data, calc_result=calc_result, is_compensated=False)
            if graph_type == self.predictive_mode:
                graph_data = df[['x_data', 'y_data', 'z_predict']].rename(columns={'z_predict': 'z_data'})
                calc_result = self.result_data_calc(data=graph_data, calc_result=calc_result,
                                                    calc_max_min=False, is_compensated=False)

        elif graph_mode == self.graph_each:
            if category == self.chuck_direct:
                map_shot_data = self.create_calc_measpos_for_shim(df)
                df['plate_size_x'] = display_setting['area_setting']['x']
                df['plate_size_y'] = display_setting['area_setting']['y']
            else:
                map_shot_data = self.create_calc_measpos(df)
            df = self.mergeZdata(map_shot_data, df)

            graph_data = self.create_shot_data(display_setting, df)
            if category == self.chuck_direct:
                calc_data = self.calc_graph_data(graph_data)

            if category == self.chuck_direct:
                calc_result = self.result_data_calc(data=calc_data, calc_result=calc_result, is_compensated=False)
            else:
                calc_result = self.result_data_calc(data=graph_data, calc_result=calc_result, is_compensated=False)

            graph_data, calc_data, calc_result = self.calc_each_shot_data_display(
                category=category, graph_type=graph_type, graph_data=graph_data, calc_data=calc_data, calc_result=calc_result)

        elif graph_mode == self.graph_free:
            start_pos_x = display_setting['shot']['x']
            start_pos_y = display_setting['shot']['y']
            width = display_setting['shot']['width']
            height = display_setting['shot']['height']
            end_pos_x = start_pos_x + width
            end_pos_y = start_pos_y - height

            if category == self.chuck_direct:
                map_shot_data = self.create_calc_measpos_for_shim(df)
            else:
                map_shot_data = self.create_calc_measpos(df)
            df = self.mergeZdata(map_shot_data, df)

            graph_data = df[(df['x_data'] > start_pos_x) & (df['x_data'] < end_pos_x)
                            & (df['y_data'] < start_pos_y) & (df['y_data'] > end_pos_y)]

            if category == self.chuck_direct:
                calc_data = self.calc_graph_data(graph_data)

            if category == self.chuck_direct:
                calc_result = self.result_data_calc(data=calc_data, calc_result=calc_result, is_compensated=False)
            else:
                calc_result = self.result_data_calc(data=graph_data, calc_result=calc_result, is_compensated=False)

            graph_data, calc_data, calc_result = self.calc_each_shot_data_display(
                category=category, graph_type=graph_type, graph_data=graph_data, calc_data=calc_data, calc_result=calc_result)

        return graph_data, calc_data, calc_result

    def result_data_calc(self, data, calc_result, calc_max_min=True, calc_pitch_roll=True, is_compensated=True):
        data = data.dropna()
        z_max = data['z_data'].max()
        z_min = data['z_data'].min()
        x_list = sorted(data['x_data'].drop_duplicates().to_list())
        y_list = sorted(data['y_data'].drop_duplicates().to_list(), reverse=True)
        roll_list = list()
        pitch_list = list()
        for y_data in y_list:
            temp_data = data[data['y_data'] == y_data]
            roll_list.append(self.calc_pith_roll(temp_data, target='roll'))

        for x_data in x_list:
            temp_data = data[data['x_data'] == x_data]
            pitch_list.append(self.calc_pith_roll(temp_data, target='pitch'))

        if calc_max_min:
            calc_result['max'] = round(z_max, 3)
            calc_result['min'] = round(z_min, 3)
            calc_result['average'] = round(sum(data['z_data'].to_list()) / len(data['z_data']), 3)
            calc_result['range'] = round((z_max - z_min), 3)

        if calc_pitch_roll:
            if len(roll_list) != 0:
                calc_result['roll_average'] = sum(roll_list) / len(roll_list)
                calc_result['roll'] = round(math.atan(calc_result['roll_average']) / 1000 * 180.0 / math.pi * 3600.0, 3)
            if len(pitch_list) != 0:
                calc_result['pitch_average'] = sum(pitch_list) / len(pitch_list)
                calc_result['pitch'] = round(math.atan(calc_result['pitch_average']) / 1000 * 180.0 / math.pi * 3600.0, 3) * -1

        return calc_result

    def create_calc_measpos_for_shim(self, df):
        map_data = dict()
        map_data['x_data'] = df['x_data'].to_list()
        map_data['y_data'] = df['y_data'].to_list()
        return map_data

    def create_calc_measpos(self, df):
        map_data = dict()
        plate_size_x = float(df['plate_size_x'].drop_duplicates().to_list()[0])
        plate_size_y = float(df['plate_size_y'].drop_duplicates().to_list()[0])
        pitch_x = float(df['pitch_x'].drop_duplicates().to_list()[0])
        pitch_y = float(df['pitch_y'].drop_duplicates().to_list()[0])
        chuck_g86 = eval(df['chuckG86'].drop_duplicates().to_list()[0])

        update_pos_x = chuck_g86 and plate_size_x > self.G86MAX_PLATE_SIZE_X + 2 * self.EDGE_INTERVAL_20
        x_list = list()
        y_list = list()

        if update_pos_x:
            icount_x = math.floor((self.G86MAX_PLATE_SIZE_X / 2.0) / pitch_x) * 2 + 3
        else:
            icount_x = math.floor((plate_size_x / 2 - self.EDGE_INTERVAL_20) / pitch_x) * 2 + 3
        icount_y = math.floor((plate_size_y / 2 - self.EDGE_INTERVAL_20) / pitch_y) * 2 + 3

        if update_pos_x:
            edge_interval_x = (self.G86MAX_PLATE_SIZE_X - pitch_x * (icount_x - 3.0)) / 2.0
        else:
            edge_interval_x = (plate_size_x - self.EDGE_INTERVAL_20 * 2 - pitch_x * (icount_x - 3)) / 2

        edge_interval_y = (plate_size_y - self.EDGE_INTERVAL_20 * 2 - pitch_y * (icount_y - 3)) / 2

        if edge_interval_x == 0:
            icount_x -= 2
            edge_interval_x = pitch_x
        if edge_interval_y == 0:
            icount_y -= 2
            edge_interval_y = pitch_y

        init_pos_x = -(plate_size_x/2 - self.EDGE_INTERVAL_20)
        for index in range(icount_x):
            x_list.append(init_pos_x)
            if index == 0 or index == icount_x-2:
                init_pos_x += edge_interval_x
            else:
                init_pos_x += pitch_x

        init_pos_y = plate_size_y/2 - self.EDGE_INTERVAL_20
        for index in range(icount_y):
            y_list.append(init_pos_y)
            if index == 0 or index == icount_y-2:
                init_pos_y -= edge_interval_y
            else:
                init_pos_y -= pitch_y
        map_data['x_data'] = x_list
        map_data['y_data'] = y_list
        return map_data

    def create_shot_data(self, display_setting, df):
        selected_shot = display_setting['shot_select']
        plate_chuck_arc_direct_h800 = eval(df['plate_chuck_arc_direct_h800'].drop_duplicates().to_list()[0])
        df['shot'] = 0
        plate_x = float(df['plate_size_x'].drop_duplicates().to_list()[0])
        plate_y = float(df['plate_size_y'].drop_duplicates().to_list()[0])
        divide_x = display_setting['divide_setting']['x']
        divide_y = display_setting['divide_setting']['y']
        start_x_list, end_x_list = self.create_shot_pos(plate_x, divide_x)
        start_y_list, end_y_list = self.create_shot_pos(-plate_y, divide_y)
        result_df = pd.DataFrame(columns=df.columns)
        # ShotからX,Yのインデクスを計算
        x_index = (selected_shot - 1) % divide_x
        y_index = ((selected_shot - 1) // divide_x) % divide_y
        if y_index % 2 == 0:
            temp_df = self.calc_divide_shot(
                df=df, start_x=start_x_list[x_index], end_x=end_x_list[x_index],
                start_y=start_y_list[y_index], end_y=end_y_list[y_index],
                plate_chuck_arc_direct_h800=plate_chuck_arc_direct_h800)
            temp_df['shot'] = selected_shot
            result_df = result_df.append(temp_df)
        else:
            reversed_index = len(start_x_list) - x_index - 1
            temp_df = self.calc_divide_shot(
                df=df, start_x=start_x_list[reversed_index], end_x=end_x_list[reversed_index],
                start_y=start_y_list[y_index], end_y=end_y_list[y_index],
                plate_chuck_arc_direct_h800=plate_chuck_arc_direct_h800)
            temp_df['shot'] = selected_shot
            result_df = result_df.append(temp_df)
        return result_df

    def create_shot_pos(self, plate_size, divide):
        shot_size = plate_size / divide
        shot_first_pos = -plate_size/2
        start_pos = [shot_first_pos]
        end_pos = list()
        now_pos = shot_first_pos
        for index in range(divide):
            now_pos = round(now_pos + shot_size, 6)
            if index == divide - 1:
                end_pos.append(-shot_first_pos)
            else:
                end_pos.append(now_pos)
                start_pos.append(now_pos)
        return start_pos, end_pos

    def mergeZdata(self, map_shot_data, df):
        df['check_x_data'] = df['x_data'].apply(lambda x: True if x in map_shot_data['x_data'] else False)
        df.drop(df[df['check_x_data']==False].index, inplace=True)
        df['check_y_data'] = df['y_data'].apply(lambda x: True if x in map_shot_data['y_data'] else False)
        df.drop(df[df['check_y_data']==False].index, inplace=True)
        df.drop(columns=['check_x_data', 'check_y_data'], axis=1, inplace=True)
        df.reset_index()
        return df

    def calc_pith_roll(self, data, target):
        data = data.dropna()
        icount = len(data)
        coefficient = 0
        if target == 'roll':
            coef_b = sum(data['x_data'].apply(lambda x: x ** 2).to_list())
            coef_c = sum(data['z_data'].to_list())
            coef_d = sum((data['x_data'] * data['z_data']).to_list())
            coef_e = sum(data['x_data'].to_list())
        else:
            coef_b = sum(data['y_data'].apply(lambda x: x ** 2).to_list())
            coef_c = sum(data['z_data'].to_list())
            coef_d = sum((data['y_data'] * data['z_data']).to_list())
            coef_e = sum(data['y_data'].to_list())
        d_denominator = icount * coef_b - (coef_e ** 2)
        if d_denominator != 0:
            coefficient = (icount * coef_d - coef_c * coef_e) / d_denominator
        return coefficient

    def calc_graph_data(self, df):
        calc_df = df[['x_data', 'y_data', 'z_data']]
        calc_df['x_data'] = calc_df['x_data'] * 1000
        calc_df['y_data'] = calc_df['y_data'] * 1000
        x_sum = sum(calc_df['x_data'].to_list())
        y_sum = sum(calc_df['y_data'].to_list())
        z_sum = sum(calc_df['z_data'].to_list())
        x_pow_sum = sum(calc_df['x_data'].apply(lambda x: x ** 2).to_list())
        y_pow_sum = sum(calc_df['y_data'].apply(lambda x: x ** 2).to_list())
        xy_sum = sum((calc_df['x_data'] * calc_df['y_data']).to_list())
        xz_sum = sum((calc_df['x_data'] * calc_df['z_data']).to_list())
        yz_sum = sum((calc_df['y_data'] * calc_df['z_data']).to_list())
        count = len(calc_df['x_data'])
        left = np.array([[x_pow_sum, xy_sum, x_sum],
                         [xy_sum, y_pow_sum, y_sum],
                         [x_sum, y_sum, count]])
        right = np.array([[xz_sum],
                          [yz_sum],
                          [z_sum]])
        left = np.linalg.inv(left)
        ans = np.dot(left, right)
        slope_x = ans[0]
        slope_y = ans[1]
        intercept = ans[2]
        # df['z_data'] = df['z_data'].fillna(999999)
        # na_df = df[df['z_data'] == 999999]
        na_df = df[df['z_data'].isnull()]
        if len(na_df) > 0:
            df.drop(na_df.index, inplace=True)
            na_df['z_data'] = (na_df['x_data'] * slope_x) + (
                        na_df['y_data'] * slope_y) + intercept
            df = pd.concat([calc_df, na_df])
        return df

    def calc_each_shot_data_display(self, category ,graph_type, graph_data, calc_data, calc_result):
        if graph_type != self.org_mode:
            if category == self.chuck_direct:
                calc_data = calc_data.astype({'z_data': float})
                calc_data['z_data'] = round(
                    calc_data['z_data'] - (calc_data['x_data'] * calc_result['roll_average'])
                    - (calc_data['y_data'] * calc_result['pitch_average']), 3)
                calc_result = self.result_data_calc(data=calc_data, calc_result=calc_result, calc_pitch_roll=False)
            else:
                graph_data = graph_data.astype({'z_data': float})
                graph_data['z_data'] = round(
                    graph_data['z_data'] - (graph_data['x_data'] * calc_result['roll_average'])
                    - (graph_data['y_data'] * calc_result['pitch_average']), 3)
                calc_result = self.result_data_calc(data=graph_data, calc_result=calc_result, calc_pitch_roll=False)

            if graph_type == self.compensate_avg_mode:
                if category == self.chuck_direct:
                    calc_data['z_data'] = round(calc_data['z_data'] - calc_result['average'])
                    calc_result = self.result_data_calc(data=calc_data, calc_result=calc_result,
                                                        calc_pitch_roll=False, is_compensated=False)
                else:
                    graph_data['z_data'] = round(graph_data['z_data'] - calc_result['average'], 3)
                    calc_result = self.result_data_calc(data=graph_data, calc_result=calc_result,
                                                        calc_pitch_roll=False, is_compensated=False)
        return graph_data, calc_data, calc_result

    def calc_divide_shot(self, df, start_x, end_x, start_y, end_y, plate_chuck_arc_direct_h800=False):
        x_list = sorted(df['x_data'].drop_duplicates().to_list())
        y_list = sorted(df['y_data'].drop_duplicates().to_list(), reverse=True)

        if plate_chuck_arc_direct_h800:
            temp_df = df[(df['x_data'] > start_x) & (df['x_data'] < end_x)
                         & (df['y_data'] < start_y) & (df['y_data'] > end_y)]

            temp_min_x = x_list.index(temp_df['x_data'].min())
            min_x_index = x_list[temp_min_x if temp_min_x == 0 else temp_min_x - 1]
            temp_max_x = x_list.index(temp_df['x_data'].max())
            max_x_index = x_list[temp_max_x if temp_max_x == len(x_list) - 1 else temp_max_x + 1]

            temp_max_y = y_list.index(temp_df['y_data'].max())
            max_y_index = y_list[temp_max_y if temp_max_y == 0 else temp_max_y - 1]
            temp_min_y = y_list.index(temp_df['y_data'].min())
            min_y_index = y_list[temp_min_y if temp_min_y == len(y_list) - 1 else temp_min_y + 1]

            temp_df = df[(df['x_data'] >= min_x_index) & (df['x_data'] <= max_x_index)
                         & (df['y_data'] <= max_y_index) & (df['y_data'] >= min_y_index)]
        else:
            temp_df = df[(df['x_data'] > start_x) & (df['x_data'] < end_x)
                         & (df['y_data'] < start_y) & (df['y_data'] > end_y)]

        return temp_df
