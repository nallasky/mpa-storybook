# coding:utf-8
from common.utils import calculator
'''
---------------------------------------------
Update History:
    No4 Lips補正Z
---------------------------------------------
'''


class LipsCorrectionZ:
    # JSON化する項目
    event_id = 'LipsCorrectionZEvent'
    event_time = 'event_time'
    lips_height = 'lips_height'
    device = 'device'
    process = 'process'
    lot_id = 'lot_id'
    plate = 'plate_no'
    step = 'step_no'
    lips_z = 'lips_z'

    def __init__(self):
        """コンストラクタ
        """

    def calc_afc_drive_offset_z(self, plate_auto_focus_df):
        """Lips補正Z計算処理
        param plateAutoFocusDict AFCのRecallログ
        """
        outputlist = []
        output_no1_dict = {}
        # 各Recallファイルの各PlateごとにLipsHeightを出力する
        # for devprokey in plateAutoFocusDict:
        #     for fileCnt in plateAutoFocusDict[devprokey]:
        #         plate_buff = 0
        #         outputdict = {}
        #         beforelot = ''
        #         # 1ファイルごとにplate stageを取得
        #         for record in plateAutoFocusDict[devprokey][fileCnt]:
        #             # 見づらいので置き換える
        #             data_dict = plateAutoFocusDict[devprokey][fileCnt][record]
        #             current_plate = data_dict[self.plate]
        #             # plate_buffが初期値の場合、データを更新
        #             if plate_buff == 0:
        #                 plate_buff = current_plate
        #             # plateが変化したらデータを更新
        #             if plate_buff != current_plate:
        #                 outputlist.append(outputdict)
        #                 # dictにデータが入っていなければ初期化
        #                 if devprokey not in output_no1_dict.keys():
        #                     output_no1_dict[devprokey] = {}
        #                 if beforelot not in output_no1_dict[devprokey].keys():
        #                     output_no1_dict[devprokey][beforelot] = {}
        #                 # No1の計算式で使用するためdict型に整形
        #                 output_no1_dict[devprokey][beforelot][plate_buff] = outputdict
        #                 outputdict = {}
        #                 plate_buff = current_plate
        #
        #             if '*' not in str(data_dict[self.lips_height]):
        #                 outputdict['event_id'] = self.event_id
        #                 outputdict[self.event_time] = data_dict[self.event_time]
        #                 outputdict[self.device] = data_dict[self.device]
        #                 outputdict[self.process] = data_dict[self.process]
        #                 outputdict[self.lot_id] = data_dict[self.lot_id]
        #                 outputdict[self.plate] = data_dict[self.plate]
        #                 outputdict[self.step] = data_dict[self.step]
        #                 outputdict[self.lips_height] = data_dict[self.lips_height]
        #                 beforelot = data_dict[self.lot_id]
        #         if outputdict is not None:
        #             # 最後のPlateはループ内で出力されないため以下で出力
        #             outputlist.append(outputdict)
        #             # dictにデータが入っていなければ初期化
        #             if devprokey not in output_no1_dict.keys():
        #                 output_no1_dict[devprokey] = {}
        #             if beforelot not in output_no1_dict[devprokey].keys():
        #                 output_no1_dict[devprokey][beforelot] = {}
        #             # No1の計算式で使用するためdict型に整形
        #             output_no1_dict[devprokey][beforelot][plate_buff] = outputdict
        devprokey = plate_auto_focus_df['job'].values[0]
        lot_id = plate_auto_focus_df['lot_id'].values[0]
        output_no1_dict = {
            devprokey: {
                lot_id: {}
            }
        }

        gb = plate_auto_focus_df.groupby(self.plate)
        for plate_no, df in gb:
            outputdict = {}

            df = df[~df[self.lips_height].str.contains('*', regex=False)]
            data_dict = df.iloc[-1].to_dict()
            outputdict['event_id'] = self.event_id
            outputdict[self.device] = data_dict[self.device]
            outputdict[self.process] = data_dict[self.process]
            outputdict[self.lot_id] = data_dict[self.lot_id]
            outputdict[self.plate] = data_dict[self.plate]
            outputdict[self.step] = data_dict[self.step]
            outputdict[self.lips_z] = calculator.nm_to_um(float(data_dict[self.lips_height]))
            outputlist.append(outputdict)
            output_no1_dict[devprokey][lot_id][plate_no] = outputdict

        return outputlist, output_no1_dict
