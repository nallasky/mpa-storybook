##########################################################################
# Application Information
##########################################################################
APP_NAME = 'MPA Analysis Tool'
APP_MAJOR = 2
APP_MINOR = 1
APP_REVISION = 0
APP_VERSION = '%s.%s.%s' % (APP_MAJOR, APP_MINOR, APP_REVISION)
APP_KEY = '502ae868f5651c56f1de7ced0631ffd5ffc5dee7dc01cd8673d394ac157d7818'

APP_COPYRIGHT = 'Copyright (c) 2021-2022 CANON Inc. All rights reserved.'
APP_MODE = 'Desktop'

API_VERSION = APP_VERSION
API_TITLE = 'MPA Analysis Tool - REST API SERVER'
API_DESCRIPTION = 'MPA Analysis ToolのREST APIに対する詳細説明ページです。'
API_LICENSE = APP_COPYRIGHT

##########################################################################
# Debug Mode
##########################################################################
DEBUG = True

##########################################################################
# Log System Settings
##########################################################################
LOG = 'APP_LOG'
LOG_FILENAME = 'log.log'
LOG_FILEPATH = 'logs'
LOG_ERRNAME = 'err.log'
LOG_MAXBYTE = 10 * 1024 * 1024
LOG_BACKUPCOUNT = 100
LOG_FORMAT = '%(asctime)s: %(levelname)s: %(module)s: %(message)s'
LOG_DATEFMT = '%Y-%m-%d %H:%M:%S'

##########################################################################
# PATH
##########################################################################
RESOURCE_PATH = 'resource'
BACKUP_PATH = '.backup'
TEMP_PATH = '.tmp'
SCRIPT_EXEC_PATH = '__script__'
local_cache_root = '.convert'
CNV_RESULT_PATH = '.cnv_result'
root_path = '.files'

DB_CONFIG_PATH = 'config/db_config.conf'
DB_SQLITE_CONFIG_PATH = 'config/db_config_sqlite.conf'

STATIC_PATH = 'web'

RSC_JSON_MAIN = 'json/page_main.json'
RSC_JSON_ABOUT = 'json/page_about.json'
RSC_JSON_MGMT_LOCAL = 'json/page_mgmt_local.json'
RSC_JSON_SETTING_LOCAL_FORM = 'json/setting_local_form.json'
RSC_JSON_SETTING_LOCAL_HIS_FORM = 'json/setting_local_history_form.json'
RSC_JSON_SETTING_REMOTE_FORM = 'json/setting_remote_form.json'
RSC_JSON_SETTING_REMOTE_HIS_FORM = 'json/setting_remote_history_form.json'
RSC_JSON_SETTING_SQL_FORM = 'json/setting_sql_form.json'
RSC_JSON_SETTING_SQL_HIS_FORM = 'json/setting_sql_history_form.json'
RSC_JSON_SETTING_MULTI_LOCAL_FORM = 'json/setting_multi_local_form.json'
RSC_JSON_SETTING_MULTI_LOCAL_HIS_FORM = 'json/setting_multi_local_his_form.json'
RSC_JSON_SETTING_MULTI_REMOTE_FORM = 'json/setting_multi_remote_form.json'
RSC_JSON_SETTING_MULTI_REMOTE_HIS_FORM = 'json/setting_multi_remote_his_form.json'
RSC_JSON_SETTING_MULTI_SQL_FORM = 'json/setting_multi_sql_form.json'
RSC_JSON_SETTING_MULTI_SQL_HIS_FORM = 'json/setting_multi_sql_his_form.json'
RSC_JSON_OPT_AGGREG_FORM = 'json/option_aggregation_form.json'
RSC_JSON_STEP2_LOCAL_FORM = 'json/step2_local_form.json'
RSC_JSON_STEP2_REMOTE_FORM = 'json/step2_remote_form.json'
RSC_JSON_STEP2_SQL_FORM = 'json/step2_sql_form.json'
RSC_JSON_STEP2_LOCAL_EDIT_FORM = 'json/step2_local_edit_form.json'
RSC_JSON_STEP2_REMOTE_EDIT_FORM = 'json/step2_remote_edit_form.json'
RSC_JSON_STEP2_SQL_EDIT_FORM = 'json/step2_sql_edit_form.json'
RSC_JSON_STEP2_MULTI_LOCAL_FORM = 'json/step2_multi_local_form.json'
RSC_JSON_STEP2_MULTI_REMOTE_FORM = 'json/step2_multi_remote_form.json'
RSC_JSON_STEP2_MULTI_SQL_FORM = 'json/step2_multi_sql_form.json'
RSC_COLUMN_ANALYSIS_DEFAULT = 'script/column_analysis.py'
RSC_JSON_LOG_DEFINE_STEP1_FORM = 'json/log_define_step1_form.json'
RSC_JSON_LOG_DEFINE_ADD_RULE_STEP1_FORM = 'json/log_define_add_rule_step1_form.json'

RSC_SETTING_FAB_DEFAULT = 'setting/fab_default.json'
RSC_SETTING_ADC_MEAS_CP_VS_DEFAULT = 'setting/adc_meas_cp_vs_default.json'
RSC_SETTING_CORRECTION_CP_VS_DEFAULT = 'setting/correction_cp_vs_default.json'
RSC_SETTING_CORR_COMP_DEFAULT = 'setting/correction_component_default.json'
RSC_SETTING_OAS_BASELINE_CP_VS_DEFAULT = 'setting/oas_base_cp_vs_default.json'
RSC_SETTING_FOCUS_TOLERANCE = 'setting/fab_focus_tolerance_default.json'

##########################################################################
# DATA CLEAN INTERVAL
##########################################################################
CLEANER_INTERVAL = 60 * 60  # 60min
EXPIRING_DATE_HOUR = 24     # 24Hours

##########################################################################
# DATABASE SCHEMA
##########################################################################
SCHEMA_SETTINGS = 'settings'
SCHEMA_CONVERT = 'convert'
SCHEMA_ANALYSIS = 'analysis'
SCHEMA_PUBLIC = 'public'
SCHEMA_CNVBASE = 'cnvbase'
SCHEMA_CNVSET = 'cnvset'
SCHEMA_HISTORY = 'history'
SCHEMA_GRAPH = 'graph'
SCHEMA_CREATE_LIST = [SCHEMA_PUBLIC, SCHEMA_SETTINGS, SCHEMA_ANALYSIS, SCHEMA_CNVSET, SCHEMA_HISTORY, SCHEMA_GRAPH]
SCHEMA_EXPORT_LIST = [SCHEMA_CNVBASE, SCHEMA_SETTINGS]
SCHEMA_EXPORT_LIST_FOR_TABLES = [SCHEMA_CNVBASE]
SCHEMA_EXPORT_LIST_FOR_MAKE_INIT_DATA = [SCHEMA_CNVBASE, SCHEMA_PUBLIC, SCHEMA_ANALYSIS, SCHEMA_GRAPH]

##########################################################################
# DATABASE TABLE
##########################################################################
TBL_SETTINGS_INFORMATION = 'settings_information'
TBL_SETTINGS_MANAGEMENT_SETTINGS = 'settings_management_setting'
TBL_CNVBASE_INFORMATION = 'cnvbase_information'
TBL_SYSTEM_GRAPH_TYPE = 'graph_system_graph_type'
EXPORT_OMIT_TBL_LIST = [TBL_CNVBASE_INFORMATION, TBL_SYSTEM_GRAPH_TYPE, TBL_SETTINGS_INFORMATION, TBL_SETTINGS_MANAGEMENT_SETTINGS]
EXPORT_OMIT_TBL_LIST_FOR_TABLES = [TBL_CNVBASE_INFORMATION, TBL_SYSTEM_GRAPH_TYPE]
COLUMN_OMIT_LIST = ['id', 'created_time', 'request_id', 'equipment_name', 'log_idx']

##########################################################################
# Remote Server URL
##########################################################################
API_GET_NAMES = '/logmonitor/api/v1/site/name'
API_GET_EQUIPMENTS = '/logmonitor/api/v1/analysis/equipments'
API_GET_DATE = '/logmonitor/api/v1/analysis/date'
API_GET_LOG_LIST = '/logmonitor/api/v1/analysis/loglist'
API_GET_LOG = '/logmonitor/api/v1/analysis/log'
API_GET_CONNECTION = '/logmonitor/api/v1/analysis/connection'


##########################################################################
# MISC.
##########################################################################
CONVERTING_PROCESSES = 4

SAMPLE_LINES = 30

NEW_LOG = 0
ADD_RULE = 1
EDIT_RULE = 2

NA_VALUE = '-99999999999999'

UNCOMPRESSED_SIZE_MAX = 10 * 1024 * 1024 * 1024

UPLOAD_FILE_SEPERATOR = '____'

##########################################################################
# UNIT
##########################################################################
OFFSET_UNIT = 1000
GRP_THREASHOLD = (50 * 2)

##########################################################################
# Coef.
##########################################################################
# plate倍率/回転成分は 1000 倍で表示する
plate_rot_coef = 1.0e3
plate_mag_coef = 1.0e3

##########################################################################
# Map Graph Default Settings.
##########################################################################
MAP_COLUMN_NUM = 4
MAP_SCALE = 50

##########################################################################
# ADC Measurement
##########################################################################
ADC_MEAS_LOGNAME = 'ADCMEASUREMENT'
ADC_MEAS_TABLE_NAME = 'adc_measurement'
dx_list = ['p1_xl', 'p1_xr', 'p2_xl', 'p2_xr', 'p3_xl', 'p3_xr']
dy_list = ['p1_yl', 'p1_yr', 'p2_yl', 'p2_yr', 'p3_yl', 'p3_yr']
inside_dx_list = ['inside_p1_xr', 'inside_p2_xr', 'inside_p3_xr']
inside_dy_list = ['inside_p1_yr', 'inside_p2_yr', 'inside_p3_yr']
meas_column_list = dx_list + dy_list
meas_inside_column_list = inside_dx_list + inside_dy_list

cp_comp_values = ['cp1', 'cp2', 'cp3']
vs_comp_values = ['vs1', 'vs2', 'vs3']
inside_vs_values = ['inside_vs']
cp_vs_list = cp_comp_values + vs_comp_values

pro_file_col_tbl = {
    '22006': 'cp1',
    '22005': 'cp2',
    '22007': 'cp3',
    '2CCF0': 'vs1',
    '22021': 'vs2',
    '2CCF1': 'vs3',
    'N/A': 'inside_vs'
}

# 計測値の変数名
meas_x_rl_ivalue = [['p1_xr', 'p1_xl'],
                    ['p2_xr', 'p2_xl'],
                    ['p3_xr', 'p3_xl']]
meas_y_rl_ivalue = [['p1_yr', 'p1_yl'],
                    ['p2_yr', 'p2_yl'],
                    ['p3_yr', 'p3_yl']]

# Matrix基本列名
base_col = {
    'x': ['X', 'DR_Upper', 'DR_Lower', 'MX', 'MX_Upper', 'MX_Lower'],
    'y': ['Y', 'MY_Upper', 'MY_Lower', 'T', 'Yaw_Upper', 'Yaw_Lower']
}

column_type = {
    'p1_xl': float, 'p1_yl': float, 'p1_xr': float, 'p1_yr': float,
    'p2_xl': float, 'p2_yl': float, 'p2_xr': float, 'p2_yr': float,
    'p3_xl': float, 'p3_yl': float, 'p3_xr': float, 'p3_yr': float,
    'inside_p1_xr': float, 'inside_p1_yr': float,
    'inside_p2_xr': float, 'inside_p2_yr': float,
    'inside_p3_xr': float, 'inside_p3_yr': float,
    'inside_vs': float,
    'logicalposition_x': float, 'logicalposition_y': float,
    'cp1': float, 'cp2': float, 'cp3': float,
    'vs1': float, 'vs2': float, 'vs3': float,
    'plate': int, 'step': int
}

##########################################################################
# ANOVA Default Settings.
##########################################################################
# デフォルト値
DEFAULT_VAL_ANOVA = {
    # VS幅[mm]
    'vs': 750.0,
    # スリット円弧半径[mm]
    'radius': 455.0
}

##########################################################################
# Overlay Correction
##########################################################################
CORRECTION_LOGNAME = 'correction'
AdcCorrectionMeasOffsetEvent = 'AdcCorrectionMeasOffsetEvent'
AdcCorrectionOffsetEvent = 'AdcCorrectionOffsetEvent'
StageCorrectionMapEvent = 'StageCorrectionMapEvent'
AdcCorrectionMeasEvent = 'AdcCorrectionMeasEvent'

# ファイル種別
RECALL_MACHINE = 'machine'
RECALL_ADC_MEAS = 'ADCMEASUREMENT'

# ファイル種別
LOG_SERVER_OFFSET = 'OffsetTable'
LOG_SERVER_CASP_H = 'CASPHeader'
LOG_SERVER_CASP_T = 'CASPTable'
LOG_SERVER_DR_H = 'DRHeader'
LOG_SERVER_DR_T = 'DRTable'
LOG_SERVER_MY_H = 'MYHeader'
LOG_SERVER_MY_T = 'MYTable'
LOG_SERVER_YAW_H = 'YawHeader'
LOG_SERVER_YAW_T = 'YawTable'

LOG_UNKNOWN = 'unknown'

CORRECTION_LOG_LIST = [RECALL_MACHINE, RECALL_ADC_MEAS, LOG_SERVER_OFFSET, LOG_SERVER_CASP_H, LOG_SERVER_CASP_T,
                       LOG_SERVER_DR_H, LOG_SERVER_DR_T, LOG_SERVER_MY_H, LOG_SERVER_MY_T, LOG_SERVER_YAW_H, LOG_SERVER_YAW_T]

UN_USE_CORRECTION_LOG_LIST = [LOG_SERVER_DR_H, LOG_SERVER_MY_H, LOG_SERVER_YAW_H]

ADC_MEAS_LOG_LIST = [RECALL_ADC_MEAS, RECALL_MACHINE]

##########################################################################
# Overlay OASBaseline
##########################################################################
OASBASELINE_LOGNAME = 'OASBASELINEMEASUREMENTMONITOR'
OASBASELINE_TABLE_NAME = 'oas_baseline_measurement_monitor'
oas_meas_column_list_x = ['bl_baseline_x', 'br_baseline_x', 'fl_baseline_x', 'fr_baseline_x']
oas_meas_column_list_y = ['bl_baseline_y', 'br_baseline_y', 'fl_baseline_y', 'fr_baseline_y']
oas_meas_column_list = oas_meas_column_list_x + oas_meas_column_list_y

oas_cp_vs_rename_dict = {
    'cp1': 'back',
    'cp3': 'front',
    'vs1': 'vs_back',
    'vs3': 'vs_front'
}


oas_cp_values = ['back', 'front']
oas_vs_values = ['vs_back', 'vs_front']
oas_cp_vs_list = oas_cp_values + oas_vs_values

OAS_BASELINE_MAP_OMIT_LIST = ['chuck', 'device', 'dummy_lot_id', 'glass_id', 'job',
                              'log_time', 'lot_id', 'process', 'pseudo_lot_id']

OAS_BASELINE_MAP_ADC_OMIT_LIST = ['p1_xl', 'p1_yl', 'p1_xr', 'p1_yr', 'p2_xl', 'p2_yl', 'p2_xr', 'p2_yr',
                                  'p3_xl', 'p3_yl', 'p3_xr', 'p3_yr', 'cp2', 'vs2', 'p1_measnum', 'p2_measnum', 'p3_measnum',
                                  'baselayermachine_no', 'inside_p1_xr', 'inside_p1_yr', 'inside_p2_xr', 'inside_p2_yr',
                                  'inside_p3_xr', 'inside_p3_yr', 'vs_inside']

UN_USE_OAS_BASELINE_COL = ['fl_as_x', 'fl_as_y', 'fl_oas_x', 'fl_oas_y', 'fr_as_x', 'fr_as_y', 'fr_oas_x',
                           'fr_oas_y', 'bl_as_x', 'bl_as_y', 'bl_oas_x', 'bl_oas_y', 'br_as_x', 'br_as_y',
                           'br_oas_x', 'br_oas_y']
OAS_BASELINE_LOG_LIST = [ADC_MEAS_LOGNAME, OASBASELINE_LOGNAME]

OAS_MAP_DISPLAY_DATA_TYPE = ['BaseOffset', 'TempOffset', 'Measured', 'Compensate', 'ShotDiff']

oas_pro_file_col_tbl = {
    '22006': 'back',
    '22007': 'front',
    '2CCF0': 'vs_back',
    '2CCF1': 'vs_front'
}

oas_column_type = {
    'bl_baseline_x': float, 'bl_baseline_y': float, 'br_baseline_x': float, 'br_baseline_y': float,
    'fl_baseline_x': float, 'fl_baseline_y': float, 'fr_baseline_x': float, 'fr_baseline_y': float,
    'plate': int, 'step': int
}

oas_map_column_type = {
    'logicalposition_x': float, 'logicalposition_y': float,
    'back': float, 'front': float,
    'vs_back': float, 'vs_front': float,
    'plate': int, 'step': int
}


##########################################################################
# Tact
##########################################################################
STATUSMONIOTOR_LOGNAME = 'StatusMonitor'
PREDICTION_LOGNAME = 'Prediction'
TSMEMORY_LOGNAME = 'TSMEMDUMP'
THRESHOLD_AUTO_ADJUSTMENT = 5000

PREDICT_CATEGORY_EXEC_TIME = 'Execute Time'
PREDICT_CATEGORY_JOB_INFO = 'JOB Information'
PREDICT_CATEGORY_ADC_PLATE = 'ADC Plate TACT'
PREDICT_CATEGORY_ADC_DETAIL = 'ADC Detail TACT'
PREDICT_CATEGORY_FDC_PLATE = 'FDC Plate TACT'
PREDICT_CATEGORY_FDC_DETAIL = 'FDC Detail TACT'

##########################################################################
# Focus
##########################################################################
FOCUS_FUNC_FOCUS_ANALYSIS = 'focus'
RECALL_PROCESS = 'process'
RECALL_PLATE_AUTO_FOCUS = 'PLATEAUTOFOCUSCOMPENSATION'
RECALL_ILLTABLE = 'ILLUMINANCEMULTITABLE'
RECALL_STAGE_POSITION = 'STAGEPOSITIONMONITOR'
RECALL_PLATE_FOCUS = 'PLATEFOCUSINTERLOCKMONITOR'
RECALL_PRE_SCAN_COMP = 'PRESCANCOMPENSATIONMONITOR'
RECALL_FOCUS_LOG_DETAIL = 'FOCUSLOGDETAIL'
FOCUS_LOG_LIST = [RECALL_PROCESS, RECALL_MACHINE, RECALL_PLATE_AUTO_FOCUS, RECALL_ILLTABLE, RECALL_STAGE_POSITION,
                  RECALL_PLATE_FOCUS, RECALL_PRE_SCAN_COMP, RECALL_FOCUS_LOG_DETAIL, STATUSMONIOTOR_LOGNAME]

FOCUS_FUNC_PRESCAN = 'prescan'

FOCUS_FUNC_RTAF = 'rtaf'

FOCUS_FUNC_CHUCK = 'chuck'

FOCUS_CHUCK_DIRECT = 'platechuckdirect'
FOCUS_CHUCK_SCAN = 'platechuckscan'
FOCUS_CHUCK_RANGE = 'platechuckrangescan'

FOCUS_CHUCK_LOG_LIST = [FOCUS_CHUCK_DIRECT, FOCUS_CHUCK_SCAN, FOCUS_CHUCK_RANGE]

# 機種タイプ
MACHINE_TYPE_H760 = 7
MACHINE_TYPE_H800 = 8
MACHINE_TYPE_E813_G6 = 9
MACHINE_TYPE_E813_G5_5 = 10
MACHINE_TYPE_H1000 = 12
MACHINE_TYPE_E900_G6 = 13

##########################################################################
# Error detail
##########################################################################
ERR_UNKNOWN_COMMAND = "Unknown request"
ERR_FILE_NOT_EXIST = "Not exist files, it may be a conversion failure"
ERR_FILE_MISMATCHED = "Mismatched file format"
ERR_NOT_FIND_PRIMARY_PU = "Could not find the reference pu info"
ERR_NOT_FIND_NAME_PU = "Could not find the name.dat info"
ERR_TSLOG_ANALYSIS_FAILE = "TS Memory Logs Analysis failure."
ERR_TSLOG_NOT_EXIST = "Target Log is empty. Check the log file is correct."
ERR_REGISTER_CONVERT_RULE = 'Upload a script file for converting log or Register the convert rule in "Configuration ' \
                            '-> LogDefine" Setting.'

