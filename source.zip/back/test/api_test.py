import pytest
import os
import requests
import json
import time
from flask import Flask, render_template, g, send_from_directory
from common.utils.response import make_json_response
from config.unit_test_config import *
from flaskapp.mpa_analysis_tool import create_app

URL = 'http://localhost:5000'

@pytest.fixture
def api():
    config_file = '../config/unit_test_config.py'
    app = create_app(config_file)
    app.config['TESTING'] = True
    api = app.test_client()

    return api

def test_convertor_job(api):
    app = Flask(__name__, static_folder='../web/static/', template_folder='../web/static')

    @app.route('/main', methods=['GET'])
    def catch_all():
        g.jinja2_test = 'made by gtttpark!'
        return render_template('index.html')

    @app.route('/main/notsupport', methods=['GET'])
    def nosupport():
        return render_template('notsupport.html')

    @app.route('/main/<path:filename>', methods=['GET'])
    def nosupport_svg(filename):
        root_dir = os.getcwd()
        return send_from_directory(os.path.join(root_dir, STATIC_PATH), filename)

    @app.route('/js/<path:filename>')
    def serve_static_js(filename):
        root_dir = os.getcwd()
        return send_from_directory(os.path.join(root_dir, STATIC_JS_PATH), filename)

    @app.route('/<path:filename>')
    def serve_static(filename):
        root_dir = os.getcwd()
        return send_from_directory(os.path.join(root_dir, STATIC_PATH), filename)

    @app.route('/fonts/<path:filename>')
    def serve_static_fonts(filename):
        root_dir = os.getcwd()
        return send_from_directory(os.path.join(root_dir, STATIC_PONTS_PATH), filename)

    @app.route('/api/resources/main')
    def resources_main():
        print('/api/resources/main')
        response = api.get('http://localhost:5000/api/resources/main')
        resp_body = json.loads(response.data)
        return make_json_response(**resp_body)

    @app.route('/api/resources/about')
    def resources_about():
        print('/api/resources/about')
        response = api.get('http://localhost:5000/api/resources/about')
        resp_body = json.loads(response.data)
        return make_json_response(**resp_body)

    app.run(threaded=True, host='0.0.0.0')


# @pytest.fixture
# def api():
#     app = create_app('../config.py')
#     app.config['TESTING'] = True
#     api = app.test_client()
#
#     return api

# def test_sample():
#     # GET /
#     # HTTP Status Code : 200
#     time.sleep(1)
#     response = requests.get('http://localhost:5000/main')
#     assert response.status_code == 200
