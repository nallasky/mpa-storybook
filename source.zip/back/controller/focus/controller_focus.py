import logging
from flask import request, Response, jsonify, make_response, json
from flask_restx import Resource, Namespace
from werkzeug.datastructures import FileStorage
import traceback

from config import app_config
from common.utils.response import make_json_response, ResponseForm
from service.focus.service_focus import ServiceFocus
from dao.dao_job import DAOJob
from common.utils import preprocessing
from dao.dao_base import DAOBaseClass

logger = logging.getLogger(app_config.LOG)

FOCUS = Namespace(name='FOCUS', description='Focus分析用API。')


@FOCUS.route('/convert')
class FocusConvert(Resource):
    parser = FOCUS.parser()
    parser.add_argument('process', type=FileStorage, location='files', action='append', help='process Files')
    parser.add_argument('PLATEAUTOFOCUSCOMPENSATION', type=FileStorage, location='files', action='append', help='PlateAutoFocusCompensation Log Files')
    parser.add_argument('ILLUMINANCEMULTITABLE', type=FileStorage, location='files', action='append', help='IlluminanceMultiTable Log Files')
    parser.add_argument('STAGEPOSITIONMONITOR', type=FileStorage, location='files', action='append', help='StagePositionMonitor Log Files')
    parser.add_argument('PLATEFOCUSINTERLOCKMONITOR', type=FileStorage, location='files', action='append', help='PlateFocusInterlockMonitor Log Files')
    parser.add_argument('PRESCANCOMPENSATIONMONITOR', type=FileStorage, location='files', action='append', help='PrescanCompensationMonitor log Files')
    parser.add_argument('FOCUSLOGDETAIL', type=FileStorage, location='files', action='append', help='Focus Log Detail Log Files')
    parser.add_argument('StatusMonitor', type=FileStorage, location='files', action='append', help='StatusMonitor Log Files')
    parser.add_argument('machine', type=FileStorage, location='files', action='append', help='machine data Files')

    @FOCUS.expect(parser)
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def post(self):
        """
        Convert Log for Focus Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            obj = ServiceFocus()
            files = dict()
            for log in obj.log_list:
                if log in args.keys() and args[log] is not None:
                    files[log] = args[log]
            resp_form = obj.file_check(files)

            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)
            data = resp_form.data

            resp_form = obj.convert(data)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            rid = resp_form.data

            return make_json_response(**{'rid': rid})

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/status/<string:rid>')
@FOCUS.param('rid', 'Request ID')
class FocusStatus(Resource):
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def get(self, rid):
        """
        Get Converting Status
        """
        logger.info(str(request))

        try:
            io = DAOJob.instance()
            info = io.get_job_info(rid)
            if info is None:
                logger.error(f'invalid rid {rid}')
                return make_json_response(status=400, msg=f'invalid rid {rid}')

            response = make_response(jsonify(info), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/info/<string:rid>')
@FOCUS.param('rid', 'Request ID')
class FocusInfo(Resource):
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def get(self, rid):
        """
        Get Setting information
        """
        logger.info(str(request))

        try:
            io = DAOJob.instance()
            info = io.get_job_info(rid)
            if info is None:
                logger.error(f'invalid rid {rid}')
                return make_json_response(status=400, msg=f'invalid rid {rid}')

            data = dict()
            if info['status'] == 'success':
                _ = preprocessing.add_column_status(rid=rid)
                log_dict = preprocessing.add_column_focus(rid=rid)
                if len(log_dict) == 0:
                    return make_json_response(status=400, msg='Data Empty.')

                min_list = list()
                max_list = list()

                dao_base = DAOBaseClass(table_name='fab.fab')
                fab_df = dao_base.fetch_all(args={'select': 'fab_nm'})

                data = {
                    'period': [min(min_list), max(max_list)],
                    'fab': fab_df['fab_nm'].tolist()
                }

            return make_json_response(**data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/info/lot-id/<string:rid>')
@FOCUS.param('rid', 'Request ID')
class FocusInfoLotID(Resource):
    parser = FOCUS.parser()
    parser.add_argument('start', type=str, required=True, help='Period Start')
    parser.add_argument('end', type=str, required=True, help='Period End')

    @FOCUS.expect(parser)
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def get(self, rid):
        """
        Get lot-id information
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            start = args['start']
            end = args['end']
            filter = dict()
            filter['log_time'] = {'start': start, 'end': end}

            log_list = [app_config.RECALL_PLATE_AUTO_FOCUS, app_config.RECALL_STAGE_POSITION, app_config.RECALL_PLATE_FOCUS,
                        app_config.RECALL_PRE_SCAN_COMP, app_config.RECALL_FOCUS_LOG_DETAIL]
            log_dict = preprocessing.load_focus_log(rid=rid, log_list=log_list, **filter)
            if len(log_dict) == 0:
                return make_json_response(status=400, msg='Data Empty.')

            job_list = list()
            lot_id = dict()
            for log_name in log_dict:
                tmp_df = log_dict[log_name]

                if 'job' in tmp_df.columns:
                    tmp_job_list = tmp_df['job'].unique().tolist()
                    job_list = job_list + tmp_job_list

                    if 'lot_id' in tmp_df.columns and 'pseudo_lot_id' in tmp_df.columns:
                        for job in tmp_job_list:
                            df_job = tmp_df[tmp_df['job'] == job]
                            normal_lot_id = df_job[df_job['pseudo_lot_id'] == False]['lot_id'].unique().tolist()
                            pseudo_lot_id = df_job[df_job['pseudo_lot_id'] == True]['lot_id'].unique().tolist()
                            if job in lot_id:
                                lot_id[job]['normal_lot_id'] = list(set(lot_id[job]['normal_lot_id'] + normal_lot_id))
                                lot_id[job]['pseudo_lot_id'] = list(set(lot_id[job]['pseudo_lot_id'] + pseudo_lot_id))
                            else:
                                lot_id[job] = {
                                    'normal_lot_id': normal_lot_id,
                                    'pseudo_lot_id': pseudo_lot_id
                                }

            data = {
                'job': list(set(job_list)),
                'lot_id': lot_id
            }

            return make_json_response(**data)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))
