import logging
from flask import request, Response, jsonify, make_response, json
from flask_restx import Resource, Namespace
from werkzeug.datastructures import FileStorage
import os
import traceback

from config import app_config
from common.utils.response import make_json_response, ResponseForm
from service.focus.service_focus import ServiceFocus
from service.focus.service_focus_prescan import ServiceFocusPrescan
from service.focus.service_focus_rtaf import ServiceFocusRTAF
from service.focus.service_focus_chuck import ServiceFocusChuck
from dao.dao_job import DAOJob
from common.utils import preprocessing
from dao.dao_base import DAOBaseClass
from service.resources.service_resources import ResourcesService

logger = logging.getLogger(app_config.LOG)

FOCUS = Namespace(name='FOCUS', description='Focus分析用API。')


@FOCUS.route('/convert')
class FocusConvert(Resource):
    parser = FOCUS.parser()
    parser.add_argument('category', type=str, required=True, help='focus/prescan/rtaf/chuck')
    parser.add_argument('process', type=FileStorage, location='files', action='append', help='process Files')
    parser.add_argument('PLATEAUTOFOCUSCOMPENSATION', type=FileStorage, location='files', action='append', help='PlateAutoFocusCompensation Log Files')
    parser.add_argument('ILLUMINANCEMULTITABLE', type=FileStorage, location='files', action='append', help='IlluminanceMultiTable Log Files')
    parser.add_argument('STAGEPOSITIONMONITOR', type=FileStorage, location='files', action='append', help='StagePositionMonitor Log Files')
    parser.add_argument('PLATEFOCUSINTERLOCKMONITOR', type=FileStorage, location='files', action='append', help='PlateFocusInterlockMonitor Log Files')
    parser.add_argument('PRESCANCOMPENSATIONMONITOR', type=FileStorage, location='files', action='append', help='PrescanCompensationMonitor log Files')
    parser.add_argument('FOCUSLOGDETAIL', type=FileStorage, location='files', action='append', help='Focus Log Detail Log Files')
    parser.add_argument('StatusMonitor', type=FileStorage, location='files', action='append', help='StatusMonitor Log Files')
    parser.add_argument('machine', type=FileStorage, location='files', action='append', help='machine data Files')
    parser.add_argument('prescan', type=FileStorage, location='files', action='append', help='PRSCAN Logserver Log Files')
    parser.add_argument('rtaf', type=FileStorage, location='files', action='append', help='RTAF Logserver Log Files')

    @FOCUS.expect(parser)
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def post(self):
        """
        Convert Log for Focus Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            category = args['category']

            if category == app_config.FOCUS_FUNC_FOCUS_ANALYSIS:
                obj = ServiceFocus()
            elif category == app_config.FOCUS_FUNC_PRESCAN:
                obj = ServiceFocusPrescan()
            elif category == app_config.FOCUS_FUNC_RTAF:
                obj = ServiceFocusRTAF()
            elif category == app_config.FOCUS_FUNC_CHUCK:
                obj = ServiceFocusChuck()
            else:
                return make_json_response(status=400, msg=f"Unknown Category : {category}")

            files = dict()
            for log in obj.log_list:
                if log in args.keys() and args[log] is not None:
                    files[log] = args[log]
            resp_form = obj.file_check(files)

            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)
            data = resp_form.data

            resp_form = obj.convert(data)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            rid = resp_form.data

            return make_json_response(**{'rid': rid})

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/status/<string:rid>')
@FOCUS.param('rid', 'Request ID')
class FocusStatus(Resource):
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def get(self, rid):
        """
        Get Converting Status
        """
        logger.info(str(request))

        try:
            io = DAOJob.instance()
            info = io.get_job_info(rid)
            if info is None:
                logger.error(f'invalid rid {rid}')
                return make_json_response(status=400, msg=f'invalid rid {rid}')

            response = make_response(jsonify(info), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/info/<string:category>')
@FOCUS.param('category', 'Category Info')
class FocusInfoDefault(Resource):
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def get(self, category):
        """
        Get Setting information
        """
        logger.info(str(request))

        try:
            resource_service = ResourcesService()

            result = dict()
            resp_form = resource_service.get_log_pattern_info_for_each(category)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)
            result = resp_form.data
            resp_form = resource_service.get_func_common_setting(category)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)
            # 설정 정보
            result['settings'] = resp_form.data

            return make_json_response(**result)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

@FOCUS.route('/info/<string:rid>')
@FOCUS.param('rid', 'Request ID')
class FocusInfo(Resource):
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def get(self, rid):
        """
        Get Setting information for Specific RequestID
        """
        logger.info(str(request))

        try:
            io = DAOJob.instance()
            info = io.get_job_info(rid)
            if info is None:
                logger.error(f'invalid rid {rid}')
                return make_json_response(status=400, msg=f'invalid rid {rid}')

            data = dict()
            if info['status'] == 'success':
                _ = preprocessing.add_column_status(rid=rid)
                preprocessing.add_column_focus(rid=rid)
                log_list = [app_config.RECALL_FOCUS_LOG_DETAIL, app_config.RECALL_PLATE_AUTO_FOCUS,
                            app_config.RECALL_PLATE_FOCUS, app_config.RECALL_PRE_SCAN_COMP,
                            app_config.RECALL_STAGE_POSITION]
                log_dict = preprocessing.load_focus_log(rid=rid, log_list=log_list)
                if len(log_dict) == 0:
                    return make_json_response(status=400, msg='Data Empty.')

                min_list = list()
                max_list = list()
                for log_name in log_dict:
                    tmp_df = log_dict[log_name]

                    if 'log_time' in tmp_df.columns:
                        min_list.append(tmp_df['log_time'].min())
                        max_list.append(tmp_df['log_time'].max())

                dao_base = DAOBaseClass(table_name='fab.fab')
                fab_df = dao_base.fetch_all(args={'select': 'fab_nm'})

                data = {
                    'period': [min(min_list), max(max_list)],
                    'fab': fab_df['fab_nm'].tolist()
                }

            return make_json_response(**data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/info/lot-id/<string:rid>')
@FOCUS.param('rid', 'Request ID')
class FocusInfoLotID(Resource):
    parser = FOCUS.parser()
    parser.add_argument('start', type=str, required=True, help='Period Start')
    parser.add_argument('end', type=str, required=True, help='Period End')

    @FOCUS.expect(parser)
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def get(self, rid):
        """
        Get lot-id information
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            start = args['start']
            end = args['end']
            filter = dict()
            filter['log_time'] = {'start': start, 'end': end}

            # log_list = [app_config.RECALL_FOCUS_LOG_DETAIL, app_config.RECALL_PLATE_AUTO_FOCUS,
            #             app_config.RECALL_PLATE_FOCUS, app_config.RECALL_PRE_SCAN_COMP, app_config.RECALL_STAGE_POSITION]
            log_list = [app_config.RECALL_STAGE_POSITION]
            log_dict = preprocessing.load_focus_log(rid=rid, log_list=log_list, **filter)
            if len(log_dict) == 0:
                return make_json_response(status=400, msg='Data Empty.')

            job_list = list()
            lot_id = dict()
            for log_name in log_dict:
                tmp_df = log_dict[log_name]

                if 'job' in tmp_df.columns:
                    tmp_job_list = tmp_df['job'].unique().tolist()
                    job_list = job_list + tmp_job_list

                    if 'lot_id' in tmp_df.columns and 'pseudo_lot_id' in tmp_df.columns:
                        for job in tmp_job_list:
                            df_job = tmp_df[tmp_df['job'] == job]
                            normal_lot_id = df_job[df_job['pseudo_lot_id'] == False]['lot_id'].unique().tolist()
                            pseudo_lot_id = df_job[df_job['pseudo_lot_id'] == True]['lot_id'].unique().tolist()
                            # if job in lot_id:
                            #     lot_id[job]['normal_lot_id'] = list(set(lot_id[job]['normal_lot_id'] + normal_lot_id))
                            #     lot_id[job]['pseudo_lot_id'] = list(set(lot_id[job]['pseudo_lot_id'] + pseudo_lot_id))
                            # else:
                            lot_id[job] = {
                                'normal_lot_id': normal_lot_id,
                                'pseudo_lot_id': pseudo_lot_id
                            }

            data = {
                'job': sorted(list(set(job_list))),
                'lot_id': lot_id
            }

            return make_json_response(**data)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/analysis')
class FocusAnalysis(Resource):
    parser = FOCUS.parser()
    parser.add_argument('rid', required=True, type=str, location='json', help='Request ID')
    parser.add_argument('fab_nm', required=True, type=str, location='json', help='Fab Name')
    parser.add_argument('job', required=True, type=str, location='json', help='job(device/process) info')
    parser.add_argument('lot_id', required=True, type=str, location='json', help='lot id')

    @FOCUS.expect(parser)
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def post(self):
        """
        Convert Log for Focus Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            service_focus = ServiceFocus()
            resp_form = service_focus.get_focus_log_detail_data(args)
            if resp_form.res:
               return make_json_response(**resp_form.data)

            err_msg = resp_form.msg

            resp_form = service_focus.get_focus_data(args)
            if not resp_form.res:
                return make_json_response(status=400, msg=f'New Version: {err_msg} \n Old Version: {resp_form.msg}')

            focus_old_data = resp_form.data

            return make_json_response(**focus_old_data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/setting/<string:fab_nm>')
@FOCUS.param('fab_nm', 'Fab Name')
class FocusSetting(Resource):
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def get(self, fab_nm):
        """
        Get Setting Info from selected Fab name.
        """
        logger.info(str(request))

        try:
            dao_base = DAOBaseClass(table_name='fab_fab')
            row = dao_base.fetch_one(args={'select': 'fab_nm', 'where': f"fab_nm='{fab_nm}'"})
            if row is None:
                with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_SETTING_FAB_DEFAULT), 'r') as f:
                    fab_default = json.load(f)

                    dao_base.insert(data={'fab_nm': fab_nm, **fab_default})

            dao_base = DAOBaseClass(table_name='fab_focus_tolerance')
            df = dao_base.fetch_all(args={'where': f"fab_nm='{fab_nm}'"})
            if len(df) == 0:
                with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_SETTING_FOCUS_TOLERANCE), 'r') as f:
                    tolerance_default = json.load(f)
                    for item in tolerance_default:
                        dao_base.insert(data={'fab_nm': fab_nm, **item})

                df = dao_base.fetch_all(args={'where': f"fab_nm='{fab_nm}'"})

            data = dict()
            for tab, target_df in df.groupby('tab'):
                data[tab] = dict()
                for i in range(len(target_df)):
                    data[tab][target_df['name'].values[i]] = {
                        "lower_limit": target_df['lower_limit'].values[i],
                        "upper_limit": target_df['upper_limit'].values[i]
                    }

            return make_json_response(tolerance=data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/setting/graph-scale')
class FocusSettingGraphScale(Resource):
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def put(self):
        """
        Save Graph Scale Setting.
        """
        logger.info(str(request))

        try:
            settings = json.loads(request.data)

            dao_base = DAOBaseClass(table_name='settings_func_common')
            for name, data in settings.items():
                for prop, value in data.items():
                    dao_base.update(set={'value': value}, where={'function': app_config.FOCUS_FUNC_FOCUS_ANALYSIS, 'name': name, 'property': prop})

            return Response(status=200)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/setting/<string:fab_nm>/tolerance/<string:tab>')
@FOCUS.param('fab_nm', 'Fab Name')
@FOCUS.param('tab', 'Graph Tab Name')
class FocusSettingTolerance(Resource):
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def put(self, fab_nm, tab):
        """
        Save Graph Tolerance Setting.
        """
        logger.info(str(request))

        try:
            settings = json.loads(request.data)

            dao_base = DAOBaseClass(table_name='fab_focus_tolerance')
            for name, data in settings.items():
                dao_base.update(set=data, where={'fab_nm': fab_nm, 'tab': tab, 'name': name})

            return Response(status=200)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@FOCUS.route('/setting/color/<string:tab>')
@FOCUS.param('tab', 'Graph Tab Name')
class FocusSettingColor(Resource):
    @FOCUS.response(200, 'Success')
    @FOCUS.response(400, 'Bad Request')
    def put(self, tab):
        """
        Save Graph Color Setting.
        """
        logger.info(str(request))

        try:
            settings = json.loads(request.data)

            dao_base = DAOBaseClass(table_name='settings_func_common')
            for legend, data in settings.items():
                for prop, value in data.items():
                    dao_base.update(set={'value': value},
                                    where={'function': app_config.FOCUS_FUNC_FOCUS_ANALYSIS,
                                           'name': 'graph_setting',
                                           'tab': tab,
                                           'legend': legend,
                                           'property': prop})

            return Response(status=200)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))