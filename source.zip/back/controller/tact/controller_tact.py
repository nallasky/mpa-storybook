import logging
import io
import zipfile

from flask import request, Response, jsonify, make_response, json
from flask_restx import Resource, Namespace, fields
import pandas as pd
from werkzeug.datastructures import FileStorage
import traceback

from config import app_config
from common.utils.response import make_json_response, ResponseForm
from service.tact.service_tact_statusmonitor import ServiceStatusMonitor
from service.tact.service_tact_settings import ServiceTactSettings
from service.tact.service_tact_tsmemory import ServiceTsMemory
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from common.utils import preprocessing

logger = logging.getLogger(app_config.LOG)
TACT = Namespace(name='TACT', description='Tact分析用API。')


@TACT.route('/settings/<string:tab_name>')
@TACT.param('tab_name', 'Tab Name')
class TACTSettings(Resource):
    parser = TACT.parser()
    table_dict = {
            "plate_tact": "tact.plate_tact",
            "plate_event": "tact.plate_tact_event",
            "plate_detail": "tact.plate_detail_tact",
            "name_data": "tact.name_dat",
            "primary_pu": "tact.primary_pu",
            "ref_pu": "tact.ref_pu"
        }

    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')
    def get(self, tab_name):
        """
        Get Tact Setting
        """
        logger.info(str(request))
        try:
            dao_base = DAOBaseClass()
            settings_data = dict()
            if tab_name == 'all':
                for key, value in self.table_dict.items():
                    if key == "primary_pu":
                        settings_data[key] = self.primary_pu_get()
                    else:
                        df = dao_base.fetch_all(table=value)
                        settings_data[key] = df.sort_values(by='id').to_dict(orient='records')
            elif tab_name == 'primary_pu':
                 settings_data[tab_name] = self.primary_pu_get()
            elif tab_name == 'download':
                zip_data = self.export_settings()
                return Response(zip_data.getvalue(), headers={
                    'Content-Type': 'application/zip',
                    'Content-Disposition': f'attachment; filename=tact_settings.zip;'
                })

            else:
                df = dao_base.fetch_all(table=self.table_dict[tab_name])
                settings_data[tab_name] = df.sort_values(by='id').to_dict(orient='records')
            return make_json_response(**settings_data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def put(self, tab_name):
        """
        Import Setting Data
        """
        logger.info(str(request))
        try:
            if tab_name == 'all':
                msg = "illegal tab name"
                return make_json_response(status=400, msg=str(msg))
            update_data = request.json
            service_obj = ServiceTactSettings()
            service_obj.update_setting(table=tab_name, update_data=update_data)
            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def primary_pu_get(self, data_type='dict'):
        dao_base = DAOBaseClass()
        primary_dict = dict()
        primary_pu_df = dao_base.fetch_all(table=self.table_dict['primary_pu'])
        primary_pu_dict = primary_pu_df.to_dict(orient='index')
        for index in range(len(primary_pu_dict)):
            primary_pu_id = primary_pu_dict[index]['id']
            primary_pu_name = primary_pu_dict[index]['pu_name']
            temp_result = dao_base.fetch_all(table='tact.primary_pu_item',
                                             args={'select': 'id, puid, name, level',
                                                   'where': f'primary_pu_id={primary_pu_id}'})
            if data_type == 'df':
                primary_dict[primary_pu_name] = temp_result.sort_values(by='id')
            else:
                primary_dict[primary_pu_name] = temp_result.sort_values(by='id').to_dict(orient='records')
        return primary_dict

    def export_settings(self):
        dao_base = DAOBaseClass()
        settings_data = dict()
        zip_buffer = io.BytesIO()
        file_name_dict = {
            "plate_tact": "plate_tact.csv",
            "plate_event": "plate_tact_event.csv",
            "plate_detail": "plate_detail_tact.csv",
            "name_data": "name.dat",
            "ref_pu": "reference_pu.csv"
        }
        with zipfile.ZipFile(zip_buffer, "a", zipfile.ZIP_DEFLATED, False) as zip_file:
            for key, value in self.table_dict.items():
                buf = io.StringIO()
                if key == "primary_pu":
                        settings_data[key] = self.primary_pu_get('df')
                        dao_base = DAOBaseClass()
                        primary_pu_df = dao_base.fetch_all(table=self.table_dict['primary_pu'])
                        primary_pu_dict = primary_pu_df.to_dict(orient='index')
                        for index in range(len(primary_pu_dict)):
                            primary_pu_id = primary_pu_dict[index]['id']
                            primary_pu_name = primary_pu_dict[index]['pu_name']
                            temp_result = dao_base.fetch_all(table='tact.primary_pu_item',
                                                             args={'select': 'id, puid, name, level',
                                                                   'where': f'primary_pu_id={primary_pu_id}'})
                            result = temp_result.sort_values(by='id').drop(columns='id')
                            result.to_csv(buf, sep=',', index=False)
                            file_name = f'primary_pu_{primary_pu_name}.csv'
                            zip_file.writestr(file_name, buf.getvalue())
                            buf.truncate(0)
                            buf.seek(0)
                else:
                    df = dao_base.fetch_all(table=value)
                    result = df.sort_values(by='id').drop(columns='id')
                    if key == 'name_data':
                        result.to_csv(buf, sep=' ', index=False, header=None)
                    else:
                        result.to_csv(buf, sep=',', index=False)
                    zip_file.writestr(file_name_dict[key], buf.getvalue())
        zip_buffer.seek(0)
        return zip_buffer


@TACT.route('/settings/<string:tab_name>/<string:primary_pu_name>')
@TACT.param('tab_name', 'Tab Name')
@TACT.param('primary_pu_name', 'PU Name')
class TACTSettingsPU(Resource):
    parser = TACT.parser()

    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')

    def delete(self, tab_name, primary_pu_name):
        """
        Import Setting Data
        """
        logger.info(str(request))
        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')
            dao = DAOBaseClass()
            dao.delete(table="tact.primary_pu", where_dict={'pu_name': primary_pu_name})
            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def put(self, tab_name, primary_pu_name):
        """
        Import Setting Data
        """
        logger.info(str(request))
        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')
            service_obj = ServiceTactSettings()
            if tab_name == 'primary_pu':
                if len(request.json) > 0:
                    update_data = request.json
                    service_obj.update_setting(table=tab_name, update_data=update_data, primary_pu_name=primary_pu_name)
                else:
                    update_data = [{'id': None, 'pu_name': primary_pu_name}]
                    service_obj.update_setting(table=tab_name, update_data=update_data)

            else :
                msg = "illegal tab name"
                return make_json_response(status=400, msg=str(msg))
            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/settings/import/<string:tab_name>')
@TACT.param('tab_name', 'Tab Name')
class TACTImportSettings(Resource):
    parser = TACT.parser()
    parser.add_argument('files', type=FileStorage, location='files', action='append', help='Log Files', required=True)

    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')
    def post(self, tab_name):
        """
        Import Setting Data
        """
        logger.info(str(request))

        try:
            if tab_name == 'all':
                msg = "illegal tab name"
                return make_json_response(status=400, msg=str(msg))
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')
            files = args['files']
            service_obj = ServiceTactSettings()
            resp_form = service_obj.upload_settings(tab_name, files)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)
            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/settings/import/primary_pu/<string:primary_pu_name>')
@TACT.param('primary_pu_name', 'Primary PU Name')
class TACTImportPuSettings(Resource):
    parser = TACT.parser()
    parser.add_argument('files', type=FileStorage, location='files', action='append', help='Log Files', required=True)

    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')
    def post(self, primary_pu_name):
        """
        Import Setting Data
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')
            files = args['files']
            service_obj = ServiceTactSettings()
            resp_form = service_obj.upload_settings("primary_pu", files, primary_pu_name)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)
            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/settings/preview')
class TactJobInfo(Resource):
    parser = TACT.parser()
    parser.add_argument('files', type=FileStorage, location='files', action='append', help='Log Files', required=True)

    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')
    def post(self):
        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')
            files = args['files']
            df_dict = dict()
            primary_name_list = list()
            for file in files:
                dao = DAOBaseClass()
                df = pd.read_csv(file, index_col=False, encoding='shift_jis')
                column_list = df.columns.values.tolist()
                df.rename(columns={column_list[0]: 'puid', column_list[1]: 'primary_pu_name'}, inplace=True)
                df_dict = df.to_dict(orient='records')
                primary_name_df = dao.fetch_all(table='tact.primary_pu', args={'select': 'pu_name'})
                primary_name_list = primary_name_df['pu_name'].drop_duplicates().tolist()
            for index in range(len(df_dict)):
                if df_dict[index]['primary_pu_name'] not in primary_name_list:
                    df_dict[index]['primary_pu_name'] = None
            return df_dict

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/statusmonitor/convert')
class TactStatusMonitorConvert(Resource):
    parser = TACT.parser()
    parser.add_argument('files', type=FileStorage, location='files', action='append', help='Log Files', required=True)
    parser.add_argument('prediction', type=FileStorage, location='files', action='append', help='Prediction Files')

    @TACT.expect(parser)
    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')
    def post(self):
        """
        Convert Log for TACT Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            files = args['files']
            prediction = args['prediction']
            obj = ServiceStatusMonitor()

            resp_form = obj.file_check(files)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)
            data = resp_form.data

            resp_form = obj.convert(data)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            rid = resp_form.data

            if prediction is not None:
                obj.upload_prediction(prediction, rid)

            return make_json_response(**{'rid': rid})

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/statusmonitor/status/<string:rid>')
@TACT.param('rid', 'Request ID')
class TactStatusMonitorStatus(Resource):
    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')
    def get(self, rid):
        """
        Get Converting Status
        """
        logger.info(str(request))

        try:
            io = DAOJob.instance()
            info = io.get_job_info(rid)
            if info is None:
                logger.error(f'invalid rid {rid}')
                return make_json_response(status=400, msg=f'invalid rid {rid}')

            response = make_response(jsonify(info), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/statusmonitor/info/<string:rid>')
@TACT.param('rid', 'Request ID')
class TactInfo(Resource):
    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')
    def get(self, rid):
        """
        Get job and period information
        """
        logger.info(str(request))

        try:
            io = DAOJob.instance()
            info = io.get_job_info(rid)
            if info is None:
                logger.error(f'invalid rid {rid}')
                return make_json_response(status=400, msg=f'invalid rid {rid}')

            data = dict()
            if info['status'] == 'success':
                df = preprocessing.add_column_status(rid=rid)

                if len(df) == 0:
                    return make_json_response(status=400, msg='Data Empty.')

                if 'log_time' in df.columns:
                    period = [str(df['log_time'].min()), str(df['log_time'].max())]
                else:
                    return make_json_response(status=400, msg='No log_time column')

                if 'job' in df.columns:
                    job_list = df.sort_values(by='job')['job'].unique().tolist()
                else:
                    return make_json_response(status=400, msg='No device/process column')

                data = {
                    'period': period,
                    'job': job_list,
                }

            return make_json_response(**data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/statusmonitor/job/info/<string:rid>/<string:period>')
@TACT.param('rid', 'Request ID')
@TACT.param('period', 'log Period')
class TactJobInfo(Resource):
    parser = TACT.parser()

    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')
    def get(self, rid, period):
        """
        Get job list of selected period
        """
        logger.info(str(request))

        try:
            filter = dict()
            filter['log_time'] = {
                'start': period.split(sep='~')[0],
                'end': period.split(sep='~')[1],
            }
            df = preprocessing.load_status_monitor(rid=rid, **filter)
            job_list = df['job'].unique().tolist()
            return make_json_response(job=job_list)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/statusmonitor/analysis/job-tact')
class TactJobTactAnalysis(Resource):
    parser = TACT.parser()
    parser.add_argument('rid', required=True, type=str, location='json', help='Request ID')
    parser.add_argument('job', required=True, type=list, location='json', help='job(device/process) info')
    parser.add_argument('period', required=True, type=list, location='json', help='Period(YYYY-mm-dd~YYYY-mm-dd)')

    def post(self):
        """
        Job-Tact Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')
            dao_base = DAOBaseClass()
            info = dict()
            info['rid'] = args['rid']
            info['job'] = args['job']
            info['period'] = args['period']
            info["plate_tact"] = dao_base.fetch_all(table="tact.plate_tact")
            info["plate_detail_tact"] = dao_base.fetch_all(table="tact.plate_detail_tact")
            result = self.analysis_job_tact(info)

            return make_json_response(**result)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def analysis_job_tact(self, info):
        try:

            tact_service = ServiceStatusMonitor()
            result = tact_service.job_tact_analysis(info)

            return result

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/statusmonitor/analysis/plate-tact')
class TactPlateTactAnalysis(Resource):
    parser = TACT.parser()
    parser.add_argument('rid', required=True, type=str, location='json', help='Request ID')
    parser.add_argument('job', required=True, type=str, location='json', help='job(device/process) info')
    parser.add_argument('period', required=True, type=list, location='json', help='["YYYY-mm-dd", "YYYY-mm-dd"]')
    parser.add_argument('type', required=True, type=str, location='json', help='Throughput/Working/Waiting')
    parser.add_argument('adc_fdc', required=True, type=str, location='json', help='ALL/ADC/FDC')

    def post(self):
        """
        Plate-Tact Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')
            dao_base = DAOBaseClass()
            info = dict()
            info['rid'] = args['rid']
            info['job'] = args['job']
            info['period'] = args['period']
            info['data_type'] = args['type']
            info['adc_fdc'] = args['adc_fdc']
            info["plate_tact"] = dao_base.fetch_all(table="tact.plate_tact", args={'select': 'category'})
            info["plate_detail_tact"] = dao_base.fetch_all(table="tact.plate_detail_tact",
                                                           args={'select': 'event, category, event_start, event_end'})
            result = self.analysis_plate_tact(info)
            result_dict = dict()
            result_dict['job_name'] = args['job']
            result_dict['type'] = args['type']
            result_dict['adc_fdc'] = args['adc_fdc']
            result_dict.update(result)

            return make_json_response(**result_dict)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def analysis_plate_tact(self, info):
        try:
            tact_service = ServiceStatusMonitor()
            # result = tact_service.tact_analysis("plate", info)
            result = tact_service.plate_tact_analysis(info)

            return result

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/statusmonitor/analysis/plate-detail-tact')
class TactPlateDetailTactAnalysis(Resource):
    parser = TACT.parser()
    parser.add_argument('rid', required=True, type=str, location='json', help='Request ID')
    parser.add_argument('job', required=True, type=str, location='json', help='job(device/process) info')
    parser.add_argument('period', required=True, type=list, location='json', help='Period(YYYY-mm-dd~YYYY-mm-dd)')
    parser.add_argument('type', required=True, type=str, location='json', help='data type')
    parser.add_argument('adc_fdc', required=True, type=str, location='json', help='adc_fdc infomation')
    parser.add_argument('plate', required=True, type=str, location='json', help='selected plate')
    parser.add_argument('lot_id_block', required=True, type=str, location='json', help='selected Lot ID Block')

    def post(self):
        """
        Plate-Tact Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')
            dao_base = DAOBaseClass()
            info = dict()
            info['rid'] = args['rid']
            info['job'] = args['job']
            info['period'] = args['period']
            info['data_type'] = args['type']
            info['adc_fdc'] = args['adc_fdc']
            info['plate'] = args['plate']
            info['lot_id_block'] = args['lot_id_block']
            info["plate_tact"] = dao_base.fetch_all(table="tact.plate_tact")
            info["plate_detail_tact"] = dao_base.fetch_all(table="tact.plate_detail_tact")
            result = self.analysis_plate_detail_tact(info)

            return make_json_response(data=result)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def analysis_plate_detail_tact(self, info):
        try:
            tact_service = ServiceStatusMonitor()
            # result = tact_service.tact_analysis("detail", info)
            result = tact_service.plate_detail_tact_analysis(info)
            return result

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/tsmemory/convert')
class TactTsMemoryConvert(Resource):
    parser = TACT.parser()
    parser.add_argument('files', type=FileStorage, location='files', action='append', help='Log Files', required=True)
    parser.add_argument('log_type', type=str, location='form', help='Log Type')

    @TACT.expect(parser)
    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')

    def post(self):
        """
        Convert Log for TACT Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            files = args['files']
            log_type = args['log_type']

            obj = ServiceTsMemory()
            #obj.set_service_info(log_type=log_type)
            obj.set_service_log_type(log_type=log_type)

            resp_form = obj.file_check(files)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)
            data = resp_form.data

            resp_form = obj.convert(data)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            rid = resp_form.data

            return make_json_response(**{'rid': rid})

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/tsmemory/status/<string:rid>')
@TACT.param('rid', 'Request ID')
class TactTsMemoryStatus(Resource):

    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')
    def get(self, rid):
        """
        Get Converting Status
        """
        logger.info(str(request))

        try:
            io = DAOJob.instance()
            info = io.get_job_info(rid)
            job = io.get_job(rid)
            if info is None:
                logger.error(f'invalid rid {rid}')
                return make_json_response(status=400, msg=f'invalid rid {rid}')
            # コピーファイル時のインフォメーション対応コード
            file_count = len(job['file'].split(','))
            if info['total_files'] == 0 and file_count != 0 and job['status'] == 'success':
                info['total_files'] = file_count
                info['success_files'] = file_count
                info['inserted'] = 0
            logger.debug(f'info[]={info}')
            response = make_response(jsonify(info), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@TACT.route('/tsmemory/analysis/<string:rid>')
@TACT.param('rid', 'Request ID')
class TactTsMemoryAnalysis(Resource):
    parser = TACT.parser()
    parser.add_argument('auto_adjust', type=int, help='Auto Adjust On/Off')

    @TACT.response(200, 'Success')
    @TACT.response(400, 'Bad Request')
    def get(self, rid):
        """
        Job-Tact Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')
            auto_adjust = args['auto_adjust']

            obj = ServiceTsMemory()
            obj.set_service_auto_adjust(adjust=auto_adjust)

            resp_form = obj.analysis_tsmemdmp_tact(rid)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            return make_json_response(data=resp_form.data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))
