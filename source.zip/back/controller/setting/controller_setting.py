import logging
import os
from flask import request, Response, json, make_response, jsonify
from flask_restx import Resource, Namespace
import configparser
import traceback
import shutil

from common.utils.response import make_json_response, ResponseForm
from dao.dao_base import DAOBaseClass
from dao.dao_base_postgres import DAOBaseClass as DAOPostgres
from dao.dao_management_setting import DAOMGMTSetting
from config.app_config import *
from common.utils import migration
from common.utils.cipher import AESCipher

logger = logging.getLogger(LOG)

SETTING = Namespace(name='SETTING', description='Management Setting変更をためのAPI。')


@SETTING.route('/local')
class SETTINGLocal(Resource):
    parser = SETTING.parser()
    parser.add_argument('path', required=True)
    # parser.add_argument('host', required=True)
    # parser.add_argument('port', required=True)
    # parser.add_argument('username', required=True, dest='user')
    # parser.add_argument('dbname', required=True)
    # parser.add_argument('password', required=True)

    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def get(self):
        """
        Get Local Database Information for Management Setting Page.

        :return: Local Database Information in Json
        """
        logger.info(str(request))

        try:
            resp_form = self.get_mgmt_local_resource()
            if resp_form.res:
                return make_json_response(**resp_form.data)
            else:
                logger.debug(f'get local resource failed : {resp_form.msg}')
                return make_json_response(status=400, msg=resp_form.msg)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def put(self):
        """
        Local Database Infoの変更を要請する。
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            # UI화면에서 local DB의 폴더 위치만 표시하는 경우
            db_config = configparser.ConfigParser()
            db_config.read(DB_CONFIG_PATH)
            file_source = db_config.get('DBSETTINGS', 'db_path')
            file_destination = args['path']
            shutil.move(file_source, file_destination)

            # args['target'] = 'local'
            # dao = DAOMGMTSetting(**args)
            # res_form = dao.connection_check()
            #
            # if not res_form.res:
            #     logger.debug(f'connection check error : {res_form.msg}')
            #     return make_json_response(status=400, msg=res_form.msg)
            #
            db_config.read(DB_CONFIG_PATH)
            db_config.set('DBSETTINGS', 'db_path', file_destination + '\\analysistool.db')

            #
            # db_config.set('DBSETTINGS', 'DB_NAME', args['dbname'])
            # db_config.set('DBSETTINGS', 'DB_USER', args['user'])
            # db_config.set('DBSETTINGS', 'DB_HOST', args['host'])
            # db_config.set('DBSETTINGS', 'DB_PASSWORD', args['password'])
            # db_config.set('DBSETTINGS', 'DB_PORT', args['port'])

            with open(DB_CONFIG_PATH, 'w') as configfile:
                db_config.write(configfile)

            # migration.migration_db()
            #
            # res_form = dao.update_db_setting(**args)
            # if not res_form.res:
            #     logger.debug(f'update db setting failed : {res_form.msg}')
            #     return make_json_response(status=400, msg=res_form.msg)

            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def get_mgmt_local_resource(self):
        try:
            json_data = dict()
            db_config = configparser.ConfigParser()
            db_config.read(DB_CONFIG_PATH)
            db_path = db_config.get('DBSETTINGS', 'db_path')

            if db_path == 'db\\\\analysistool.db':
                db_path = os.path.join(os.getcwd(), db_path)  # r'c:\MPA Analysis Tool\db\analysistool.db'
            json_data['local'] = db_path.strip('\\\\analysistool.db')


            # with open(os.path.join(RESOURCE_PATH, RSC_JSON_MGMT_LOCAL), 'r') as f:
            #     json_data = json.load(f)
            #
            # dao_mgmt = DAOMGMTSetting()
            # df = dao_mgmt.fetch_all(args={'where': "target = 'local'"})
            #
            # if 'items' in json_data:
            #     for item in json_data['items']:
            #         target = item['target']
            #         if target in df.columns:
            #             item['content'] = df[target].values[0]
            #             # item['content'] = df.at[0, target]
            #
            return ResponseForm(res=True, data=json_data)


        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))


@SETTING.route('/remote')
class SETTINGRemote(Resource):
    # parser = SETTING.parser()
    # parser.add_argument('host', required=True, help='test')
    # parser.add_argument('port')
    # parser.add_argument('username', dest='user')
    # parser.add_argument('dbname')
    # parser.add_argument('password')
    # parser.add_argument('name')

    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def get(self):
        """
        Get Remote Database Information for Management Setting Page.

        :return: Remote Database Information in Json
        """
        logger.info(str(request))

        try:
            resp_form = self.get_mgmt_remote_resource()
            if resp_form.res:
                return make_json_response(**resp_form.data)
            else:
                logger.debug(f'get remote resource failed : {resp_form.msg}')
                return make_json_response(status=400, msg=resp_form.msg)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    # @SETTING.expect(parser)
    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def post(self):
        """
        Add New Remote Database Information into Table

        :return: status_code
        """
        logger.info(str(request))
        df = None

        try:
            # args = self.parser.parse_args()
            args = json.loads(request.get_data())
            logger.debug(f'args : {args}')

            dao_local = DAOMGMTSetting()
            df = dao_local.fetch_all()

            sql = f"DELETE FROM {dao_local.table_name}"
            dao_local.cursor.execute(sql)
            sql = f"UPDATE sqlite_sequence SET seq=0 where name='{dao_local.table_name}'"
            dao_local.cursor.execute(sql)
            dao_local.connect.commit()

            for arg in args:
                arg['target'] = 'remote'
                encrypted = arg.pop('encrypted')
                if not encrypted:
                    aes = AESCipher(APP_KEY)
                    arg['password'] = aes.encrypt(arg['password'])
                resp_form = dao_local.insert(data=arg, rtn_id=True)

                if resp_form.res:
                    return Response(status=200)
                else:
                    logger.debug(f'insert db setting failed : {resp_form.msg}')
                    sql = f"DELETE FROM {dao_local.table_name}"
                    dao_local.cursor.execute(sql)
                    sql = f"UPDATE sqlite_sequence SET seq=0 where name='{dao_local.table_name}'"
                    dao_local.cursor.execute(sql)
                    dao_local.connect.commit()

                    df.to_sql(dao_local.table_name, dao_local.connect, if_exists='append', index=False)

                    return make_json_response(status=400, msg=resp_form.msg)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            if df is not None:
                dao_local = DAOMGMTSetting()
                df.to_sql(dao_local.table_name, dao_local.connect, if_exists='append', index=False)
            return make_json_response(status=400, msg=str(e))

    def get_mgmt_remote_resource(self):
        try:
            dao_mgmt = DAOMGMTSetting()
            df = dao_mgmt.fetch_all(args={'where': "target = 'remote'"})

            items = list()
            for i in df.index:
                item = dict()
                item['id'] = df['id'].values[i]
                item['host'] = df['host'].values[i]
                item['name'] = df['name'].values[i]

                # connection check
                conf = dict()
                conf['dbname'] = df['dbname'].values[i]
                conf['user'] = df['username'].values[i]
                conf['host'] = df['host'].values[i]
                conf['password'] = df['password'].values[i]
                conf['port'] = df['port'].values[i]
                conf['encrypted'] = True

                dao = DAOPostgres(**conf)
                resp_form = dao.connection_check()
                if resp_form.res:
                    item['sts'] = 'Success'
                else:
                    item['sts'] = 'Error'

                item['port'] = conf['port']
                item['username'] = conf['user']
                item['dbname'] = conf['dbname']
                item['password'] = conf['password']
                item['encrypted'] = conf['encrypted']

                items.append(item)

            return ResponseForm(res=True, data={'items': items})
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))


@SETTING.route('/tables')
class SETTINGTables(Resource):
    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def get(self):
        """
        Get Settings Table List for Management Setting Page.

        :return: List of CNVBASE's Table information in Json
        """
        logger.info(str(request))

        try:
            resp_form = self.get_mgmt_table_list()
            if resp_form.res:
                response = make_response(jsonify(resp_form.data), 200)
                return response
            else:
                logger.debug(f'get table list failed : {resp_form.msg}')
                return make_json_response(status=400, msg=resp_form.msg)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def get_mgmt_table_list(self):
        try:
            dao = DAOBaseClass()
            resp_form = dao.get_table_list_from_schema(SCHEMA_EXPORT_LIST, EXPORT_OMIT_TBL_LIST)
            if resp_form.res:
                return ResponseForm(res=True, data=resp_form.data)
            else:
                return ResponseForm(res=False, msg=resp_form.msg)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))


@SETTING.route('/remote/<int:db_id>/status')
@SETTING.param('db_id', 'Database ID')
class SETTINGTables(Resource):
    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def get(self, db_id):
        """
        Check Each Remote Database Connection.

        :return: Database Status
        """
        logger.info(str(request))

        try:
            dao_mgmt = DAOMGMTSetting()
            df = dao_mgmt.fetch_all(args={'where': f"target = 'remote' and id = {db_id}"})

            if len(df) == 0:
                return make_json_response(status=400, msg='Cannot find any matching db id')

            # connection check
            conf = df.iloc[0].to_dict()
            conf['user'] = conf.pop('username')

            dao = DAOPostgres(**conf)
            resp_form = dao.connection_check()
            if resp_form.res:
                res = dict()
                res['id'] = db_id
                res['sts'] = 'success'
                return make_json_response(**res)
            else:
                logger.debug(f'connection check failed : {resp_form.msg}')
                return make_json_response(status=resp_form.status, msg=resp_form.msg)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@SETTING.route('/remote/<int:db_id>')
@SETTING.param('db_id', 'Database ID')
class SETTINGTables(Resource):
    parser = SETTING.parser()
    parser.add_argument('host', required=True, help='test')
    parser.add_argument('port')
    parser.add_argument('username', dest='user')
    parser.add_argument('dbname')
    parser.add_argument('password')
    parser.add_argument('name')

    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def get(self, db_id):
        """
        Get Specific Remote Database Information.

        :return: {
                    "host": "",
                    "port": ,
                    "username": "",
                    "dbname": "",
                    "password": "",
                    "name": ""
                }
        """
        logger.info(str(request))

        try:
            dao_mgmt = DAOMGMTSetting()
            df = dao_mgmt.fetch_all(args={'where': f"target = 'remote' and id = {db_id}"})

            if len(df) == 0:
                return make_json_response(status=400, msg='Cannot find any matching db id')

            res = df.iloc[0].to_dict()
            return make_json_response(**res)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    @SETTING.expect(parser)
    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def put(self, db_id):
        """
        Update Specific Remote Database Information

        :return: {
                    "id": ,
                    # "name": "xxx@xxx.xxx.xxx.xxx"
                    "name": "",
                    "sts": "success"
                }
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            args['target'] = 'remote'
            dao_remote = DAOMGMTSetting(**args)
            res_form = dao_remote.connection_check()

            if res_form.res:
                dao_local = DAOMGMTSetting()
                res_form = dao_local.update_db_setting(db_id, **args)
            else:
                logger.debug(f'connection check error : {res_form.msg}')
                return make_json_response(status=400, msg=res_form.msg)

            if res_form.res:
                res = dict()
                res['id'] = db_id
                # res['name'] = f"{args['dbname']}@{args['host']}"
                res['name'] = f"{args['name']}"
                res['sts'] = 'success'
                return make_json_response(**res)
            else:
                logger.debug(f'update db setting failed : {res_form.msg}')
                return make_json_response(status=400, msg=res_form.msg)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def delete(self, db_id):
        """
        Delete Specific Remote Database Information

        :return: {
                    "id":
                }
        """
        logger.info(str(request))

        try:
            dao = DAOMGMTSetting()
            resp_form = dao.delete(where_dict={'id': db_id}, rtn_id=True)

            # if resp_form.res and resp_form.data == db_id:
            if resp_form.res:
                return make_json_response(id=db_id)
            else:
                return make_json_response(status=400, msg='Delete Fail.')

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@SETTING.route('/connection-check')
class SETTINGConnectionCheck(Resource):
    parser = SETTING.parser()
    parser.add_argument('host', required=True)
    parser.add_argument('port', required=True)
    parser.add_argument('username', required=True, dest='user')
    parser.add_argument('dbname', required=True)
    parser.add_argument('password', required=True)
    parser.add_argument('encrypted', type=bool, required=True)

    @SETTING.expect(parser)
    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def post(self):
        """
        Connection CheckのためのAPI。
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            for key, val in args.items():
                if val == '':
                    logger.debug(f'{key} : value is empty')
                    return make_json_response(status=400, msg='Fill out all the information.')

            dao = DAOPostgres(**args)
            resp_form = dao.connection_check()

            if resp_form.res:
                return make_json_response(data=resp_form.data)
            else:
                logger.debug(f'connection check failed : {resp_form.msg}')
                return make_json_response(status=resp_form.status, msg=resp_form.msg)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@SETTING.route('/column-define')
class SETTINGLogColumn(Resource):
    parser = SETTING.parser()
    parser.add_argument('id', type=int)

    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def get(self):
        logger.info(str(request))

        try:
            resp_form = self.get_log_column_resource()
            if resp_form.res:
                return make_json_response(**resp_form.data)
            else:
                logger.debug(f'get column define data failed : {resp_form.msg}')
                return make_json_response(status=400, msg=resp_form.msg)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def put(self):
        logger.info(str(request))

        try:
            update_data = request.json
            dao = DAOBaseClass()

            if update_data['id'] is None:
                update_data.pop('id')
                resp_form = dao.insert(data={**update_data}, rtn_id=True, table='settings.column_define')
                if not resp_form.res:
                    return make_json_response(status=400, msg=resp_form.msg)
            else:
                id = update_data['id']
                resp_form = dao.update(table='settings.column_define',
                                       set={**update_data},
                                       where={'id': id})
                if not resp_form.res:
                    return make_json_response(status=400, msg=resp_form.msg)
            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def delete(self):
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')
            id = args['id']
            dao = DAOBaseClass()
            df = dao.fetch_all(table='settings.column_define', args={'select' : 'id'})

            dao.delete(table='settings.column_define', where_dict={'id': id})
            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def get_log_column_resource(self):
            try:
                dao = DAOBaseClass()
                df = dao.fetch_all('settings.column_define')
                items = list()
                for i in df.index:
                    item = dict()
                    item['id'] = df['id'].values[i]
                    item['type'] = df['type'].values[i]
                    item['data'] = df['data'].values[i]
                    item['output_column_name'] = df['output_column_name'].values[i]
                    item['output_column_type'] = df['output_column_type'].values[i]
                    item['default_value'] = df['default_value'].values[i]
                    item['coefficient'] = df['coefficient'].values[i]
                    item['unit'] = df['unit'].values[i]
                    # item['custom_data'] = df['custom_data'].values[i]
                    items.append(item)
                return ResponseForm(res=True, data={'data': items})

            except Exception as e:
                logger.error(str(e))
                logger.error(traceback.format_exc())
                return ResponseForm(res=False, msg=str(e))

@SETTING.route('/logpattern')
class SETTINGLogPattern(Resource):
    parser = SETTING.parser()

    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def get(self):
        logger.info(str(request))

        try:
            resp_form = self.get_log_pattern_resource()
            if resp_form.res:
                return make_json_response(**resp_form.data)
            else:
                logger.debug(f'get remote resource failed : {resp_form.msg}')
                return make_json_response(status=400, msg=resp_form.msg)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


    def put(self):
        logger.info(str(request))

        try:
            add_item_list = list()
            dao = DAOBaseClass()
            data = request.json
            update_data = self.get_func_data(data)

            if update_data['id'] is None:
                add_item_list.append(update_data)
                update_data.pop('id')
                resp_form = dao.insert(data={**update_data}, rtn_id=True, table='settings.log_pattern')
                if not resp_form.res:
                    return make_json_response(status=400, msg=resp_form.msg)
            else:
                id = update_data['id']
                resp_form = dao.update(table='settings.log_pattern',
                                       set={**update_data},
                                       where={'id': id})
                if not resp_form.res:
                    return make_json_response(status=400, msg=resp_form.msg)

            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def get_log_pattern_resource(self):
        try:
            result = list()
            dao = DAOBaseClass()
            func_df = dao.fetch_all(table='cnvbase.log_define_master', args={'select': 'id, log_name'})
            func_dict = func_df.set_index('id').to_dict(orient='index')
            data_df = dao.fetch_all(table='settings.log_pattern')
            data_dict = data_df.to_dict(orient='index')
            for index in data_dict:
                temp_dict = dict()
                temp_dict['id'] = data_dict[index]['id']
                temp_dict['log_name'] = func_dict[data_dict[index]['log_id']]['log_name']

                ignore_pattern = data_dict[index]['ignore_pattern']
                pattern = data_dict[index]['pattern']

                temp_dict['ignore_pattern'] = ignore_pattern.split(':') if len(ignore_pattern) > 0 else []
                temp_dict['pattern'] = pattern.split(':') if len(pattern) > 0 else []
                result.append(temp_dict)

            return ResponseForm(res=True, data={'data': result})

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return ResponseForm(res=False, msg=str(e))


    def get_func_data(self, data):
        result = dict()
        dao = DAOBaseClass()
        log_id = dao.fetch_all(table='cnvbase.log_define_master',
                               args={'select': 'log_name, id'}).set_index('log_name').to_dict(orient='index')
        if data['id'] == "":
            result['id'] = None
        else:
            result['id'] = data['id']
        result['log_id'] = 0
        for key, val in log_id.items():
            data_lower = data['log_name'].lower()
            log_name_lower = key.lower()
            if data_lower == log_name_lower:
                data['log_name'] = key
                result['log_id'] = log_id[data['log_name']]['id']
                break
        if result['log_id'] == 0:
            update_data = {
                "log_name": data['log_name'],
                "input_type": "csv",
                "table_name": data['log_name'].lower()
            }
            temp = dao.insert(data={**update_data}, rtn_id=True, table='cnvbase.log_define_master')
            result['log_id'] = temp.data
        result['ignore_pattern'] = ':'.join(data['ignore_pattern'])
        result['pattern'] = ':'.join(data['pattern'])
        return result


@SETTING.route('/log-define')
class SettingLogDefine(Resource):

    @SETTING.response(200, 'Success')
    @SETTING.response(400, 'Bad Request')
    def get(self):
        """
        Get resources for configuration-log define page

        :return: Information of all logs and rules
        """
        logger.info(str(request))

        try:
            data = {'log_define': list()}
            dao_base = DAOBaseClass()
            log_define_df = dao_base.fetch_all(table='cnvbase.log_define_master')
            rule_df = dao_base.fetch_all(table='cnvbase.convert_rule')
            rule_item_df = dao_base.fetch_all(table='cnvbase.convert_rule_item')

            for i in range(len(log_define_df)):
                log_define = dict()
                log_define['log_name'] = log_define_df['log_name'].values[i]
                log_define['log_id'] = log_define_df['id'].values[i]
                log_define['rules'] = list()

                target_rule_df = rule_df[rule_df['log_id'] == log_define['log_id']]
                for j in range(len(target_rule_df)):
                    rule = dict()
                    rule['rule_id'] = target_rule_df['id'].values[j]
                    rule['rule_name'] = target_rule_df['rule_name'].values[j]
                    rule['header_count'] = len(rule_item_df[(rule_item_df['rule_id'] == rule['rule_id'])
                                                            & (rule_item_df['type'] == 'header')])
                    log_define['rules'].append(rule)

                data['log_define'].append(log_define)

            return make_json_response(**data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))
