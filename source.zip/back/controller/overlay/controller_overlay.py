import os
import logging
from flask import request, Response, jsonify, make_response, json
from flask_restx import Resource, Namespace, fields
import pandas as pd
import numpy as np
from copy import deepcopy
from werkzeug.datastructures import FileStorage
import time
import traceback

from config import app_config
from common.utils.response import make_json_response, ResponseForm
from service.overlay.service_overlay_correction import ServiceCorrection
from service.overlay.service_overlay_AdcMeasurement import ServiceAdcMeasurement
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from common.utils import preprocessing

logger = logging.getLogger(app_config.LOG)

OVERLAY = Namespace(name='OVERLAY', description='Overlay分析用API。')


@OVERLAY.route('/convert')
class OverlayConvert(Resource):
    parser = OVERLAY.parser()
    parser.add_argument('files', type=FileStorage, location='files', action='append', help='Log Files', required=True)
    parser.add_argument('category', type=str, help='Log Category Info.', required=True)

    @OVERLAY.expect(parser)
    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def post(self):
        """
        Convert Log for Overlay Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            files = args['files']
            category = args['category']

            if category == 'ADCMEASUREMENT':
                obj = ServiceAdcMeasurement()
            elif category == 'correction':
                obj = ServiceCorrection()
            else:
                return make_json_response(status=400, msg=f'Unknown Category. ({category})')

            resp_form = obj.file_check(files)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)
            data = resp_form.data

            resp_form = obj.convert(data)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            rid = resp_form.data

            return make_json_response(**{'rid': rid})

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@OVERLAY.route('/status/<string:category>/<string:rid>')
@OVERLAY.param('category', 'Category')
@OVERLAY.param('rid', 'Request ID')
class OverlayStatus(Resource):
    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def get(self, category, rid):
        """
        Get Converting Status and Info
        """
        logger.info(str(request))

        try:
            io = DAOJob.instance()
            info = io.get_job_info(rid)
            if info is None:
                logger.error(f'invalid rid {rid}')
                return make_json_response(status=400, msg=f'invalid rid {rid}')

            if info['status'] == 'success':
                if category == 'ADCMEASUREMENT':
                    df = preprocessing.add_column_adc_meas(rid=rid)
                else:
                    df = None

                if 'log_time' in df.columns:
                    period = [str(df['log_time'].min()), str(df['log_time'].max())]
                else:
                    return make_json_response(status=400, msg='No log_time column')

                if 'job' in df.columns:
                    job_list = df['job'].unique().tolist()
                else:
                    return make_json_response(status=400, msg='No device/process column')

                lot_id = dict()
                if 'lot_id' in df.columns and 'pseudo_lot_id' in df.columns:
                    for job in job_list:
                        df_job = df[df['job'] == job]
                        normal_lot_id = df_job[df_job['pseudo_lot_id'] == False]['lot_id'].unique().tolist()
                        pseudo_lot_id = df_job[df_job['pseudo_lot_id'] == True]['lot_id'].unique().tolist()
                        lot_id[job] = {
                            'normal_lot_id': normal_lot_id,
                            'pseudo_lot_id': pseudo_lot_id
                        }

                info['info'] = {
                    'period': period,
                    'job': job_list,
                    'lot_id': lot_id
                }

            response = make_response(jsonify(info), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


column_type = {
    'p1_xl': float, 'p1_yl': float, 'p1_xr': float, 'p1_yr': float,
    'p2_xl': float, 'p2_yl': float, 'p2_xr': float, 'p2_yr': float,
    'p3_xl': float, 'p3_yl': float, 'p3_xr': float, 'p3_yr': float,
    'logicalposition_x': float, 'logicalposition_y': float,
    'cp1': float, 'cp2': float, 'cp3': float,
    'vs1': float, 'vs2': float, 'vs3': float,
    'plate': int, 'step': int
}


@OVERLAY.route('/analysis')
class OverlayConvert(Resource):
    parser = OVERLAY.parser()
    parser.add_argument('category', required=True, type=str, location='json', help='ADCMEASUREMENT or correction')
    parser.add_argument('rid', required=True, type=str, location='json', help='Request ID')
    parser.add_argument('fab_nm', required=True, type=str, location='json', help='Fab Name')
    parser.add_argument('period', required=True, type=str, location='json', help='Period(YYYY-mm-dd~YYYY-mm-dd)')
    parser.add_argument('job', required=True, type=str, location='json', help='job(device/process) info')
    parser.add_argument('lot_id', required=True, type=list, location='json', help='lot id')
    parser.add_argument('mean_dev_diff', required=True, type=list, location='json', help='Mean Deviation Diff. Setting')
    parser.add_argument('ae_correction', required=True, type=str, location='json', help='AE Correction Setting')
    parser.add_argument('cp_vs', type=dict, location='json', help='cp/vs setting info')

    @OVERLAY.expect(parser)
    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def post(self):
        """
        Convert Log for Overlay Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            res_data = dict()

            dao_base = DAOBaseClass(table_name='fab.fab')
            row = dao_base.fetch_one(args={'select': 'fab_nm', 'where': f"fab_nm='{args.fab_nm}'"})
            if row is None:
                with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_SETTING_FAB_DEFAULT), 'r') as f:
                    fab_default = json.load(f)

                dao_base.insert(data={'fab_nm': args.fab_nm, **fab_default})

            if args.category == 'ADCMEASUREMENT':
                filter = dict()
                filter['log_time'] = {
                    'start': args.period.split(sep='~')[0],
                    'end': args.period.split(sep='~')[1],
                }
                filter['job'] = args.job
                filter['lot_id'] = args.lot_id

                df = preprocessing.load_adc_meas(rid=args.rid, **filter)

                # p1_xl...p3yr, logicalposition_x/y, cp/vs -> float
                # plate, step -> int
                df = df.astype(column_type)

                cp_vs_list = ['cp1', 'cp2', 'cp3', 'vs1', 'vs2', 'vs3']
                cp_vs = args.cp_vs
                if cp_vs is not None and cp_vs['use_from_log'] == False:
                    cp_vs_default = pd.DataFrame(cp_vs['setting']).astype(float)
                    cp_vs_default *= app_config.MM_TO_NM
                    cp_vs_default = cp_vs_default.reset_index().rename(columns={'index': 'step'})
                    cp_vs_default = cp_vs_default.astype({'step': int})
                    for i in range(len(cp_vs_default)):
                        target_step = cp_vs_default['step'].values[i]
                        for col in cp_vs_list:
                            df.loc[df['step'] == target_step, col] = cp_vs_default[col].values[i]
                else:
                    with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_SETTING_ADC_MEAS_CP_VS_DEFAULT),
                              'r') as f:
                        cp_vs_default = json.load(f)

                    ret_cp_vs = dict()
                    ret_cp_vs['included'] = True
                    ret_cp_vs['expo_mode'] = int(df['expo_mode'].values[0])
                    ret_cp_vs['default'] = cp_vs_default
                    ret_cp_vs['shot'] = df['step'].unique().tolist()

                    cp_vs_preset_df = dao_base.fetch_all(table='fab.adc_meas_cp_vs_preset',
                                                         args={'where': f"fab_nm='{args.fab_nm}'"})

                    preset_dict = dict()
                    for i in range(len(cp_vs_preset_df)):
                        preset_dict[int(cp_vs_preset_df['id'].values[i])] = cp_vs_preset_df['name'].values[i]

                    ret_cp_vs['preset'] = preset_dict

                    res_data['cp_vs'] = ret_cp_vs

                    for col in cp_vs_list:
                        if col not in df.columns:
                            df[col] = cp_vs_default[col] * app_config.MM_TO_NM
                        else:
                            df.fillna({col: cp_vs_default[col] * app_config.MM_TO_NM})

                    etc = dict()
                    fab_info = dao_base.fetch_one(table='fab.fab', args={'where': f"fab_nm='{args.fab_nm}'"})
                    if fab_info is None:
                        return make_json_response(status=400, msg='Cannot find Fab name.')

                    etc['display_map'] = {'min': df['plate'].min(), 'max': df['plate'].max()}
                    etc['column_num'] = app_config.MAP_COLUMN_NUM
                    etc['div'] = {'div_upper': fab_info['div_upper'],
                                  'div_lower': fab_info['div_lower'],
                                  'scale': app_config.MAP_SCALE }
                    etc['plate_size'] = {'size_x': fab_info['plate_size_x'], 'size_y': fab_info['plate_size_y']}
                    res_data['etc'] = etc

                # inversion by y-axis
                inverse_list = ['p1_xl', 'p1_xr', 'p2_xl', 'p2_xr', 'p3_xl', 'p3_xr']
                df[inverse_list] = -df[inverse_list]

                service_adc_meas = ServiceAdcMeasurement()

                if len(args.mean_dev_diff) > 0:
                    start = time.time()
                    df = service_adc_meas.mean_deviation(df, args.mean_dev_diff)
                    logger.debug(f'[PROCESS TIME] mean_deviation [{time.time() - start}]')

                # map graph data calculate
                start = time.time()
                resp_form = service_adc_meas.create_map(df)
                logger.debug(f'[PROCESS TIME] create_map [{time.time() - start}]')
                if not resp_form.res:
                    return make_json_response(status=400, msg=resp_form.msg)

                res_data['data'] = resp_form.data

                # Reproducibility Calculate
                start = time.time()
                res_data['reproducibility'] = service_adc_meas.create_reproducibility_data(df)
                logger.debug(f'[PROCESS TIME] create_reproducibility_data [{time.time() - start}]')

                # Rotation/Magnification Calculate
                res_data['variation'] = dict()
                start = time.time()
                res_data['variation']['plate_num'] = service_adc_meas.calc_plate_component(df)
                logger.debug(f'[PROCESS TIME] calc_plate_component [{time.time() - start}]')

                return make_json_response(**res_data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@OVERLAY.route('/cpvs/preset')
class OverlayCPVSPost(Resource):
    parser = OVERLAY.parser()
    parser.add_argument('preset', type=dict, location='json', required=True, help='cp/vs preset info.')
    parser.add_argument('items', type=list, location='json', required=True, help='cp/vs info of each shot.')

    @OVERLAY.expect(parser)
    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def post(self):
        """
        Save CP/VS Settings
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            preset = args['preset']
            dao_base = DAOBaseClass()
            resp_form = dao_base.insert(table='fab.adc_meas_cp_vs_preset', data=preset, rtn_id=True)
            if not resp_form.res:
                return make_json_response(status=400, msg='cp/vs preset insert fail.')

            preset_id = resp_form.data

            items = args['items']
            for item in items:
                resp_form = dao_base.insert(table='fab.adc_meas_cp_vs_preset_item',
                                            data={**item, 'preset_id': preset_id})
                if not resp_form.res:
                    return make_json_response(status=400, msg='cp/vs preset item insert fail.')

            return make_json_response(**{'id': preset_id})

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@OVERLAY.route('/cpvs/preset/<int:preset_id>')
@OVERLAY.param('preset_id', 'CP/VS Preset ID')
class OverlayCPVS(Resource):
    parser = OVERLAY.parser()
    parser.add_argument('preset', type=dict, location='json', required=True, help='cp/vs preset info.')
    parser.add_argument('items', type=list, location='json', required=True, help='cp/vs info of each shot.')

    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def get(self, preset_id):
        """
        Get CP/VS Setting Info.
        """
        logger.info(str(request))

        try:
            dao_base = DAOBaseClass()
            row = dao_base.fetch_one(table='fab.adc_meas_cp_vs_preset', args={'where': f"id={preset_id}"})
            if row is None:
                return make_json_response(status=400, msg='Wrong preset id.')

            data = dict()

            data['mode'] = row['mode']
            df = dao_base.fetch_all(table='fab.adc_meas_cp_vs_preset_item', args={'where': f"preset_id={preset_id}"})
            if len(df) > 0:
                df.drop(['id', 'preset_id'], axis=1, inplace=True)
                df.set_index('shot_no', inplace=True)
                item_dict = df.to_dict(orient='index')
                data['step'] = item_dict

            return make_json_response(**data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def put(self, preset_id):
        """
        Update CP/VS Setting Info.
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            dao_base = DAOBaseClass()
            preset = args['preset']
            resp_form = dao_base.update(table='fab.adc_meas_cp_vs_preset',
                                        set=preset, where={'id': preset_id})
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            items = args['items']
            for item in items:
                shot_no = item.pop('shot_no')
                resp_form = dao_base.update(table='fab.adc_meas_cp_vs_preset_item',
                                            set=item,
                                            where={'preset_id': preset_id, 'shot_no': shot_no})
                if not resp_form.res:
                    return make_json_response(status=400, msg=resp_form.msg)

            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def delete(self, preset_id):
        """
        Update CP/VS Setting Info.
        """
        logger.info(str(request))

        try:
            dao_base = DAOBaseClass()
            dao_base.delete(table='fab.adc_meas_cp_vs_preset', where_dict={'id': preset_id})

            return Response(status=200)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))
