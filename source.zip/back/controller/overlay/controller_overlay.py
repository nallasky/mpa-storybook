import os
import logging
from flask import request, Response, jsonify, make_response, json
from flask_restx import Resource, Namespace, fields
import pandas as pd
import numpy as np
from copy import deepcopy
from werkzeug.datastructures import FileStorage
import time
import traceback

from config import app_config
from common.utils.response import make_json_response, ResponseForm
from service.overlay.service_overlay_correction import ServiceCorrection
from service.overlay.service_overlay_AdcMeasurement import ServiceAdcMeasurement
from dao.dao_job import DAOJob
from dao.dao_base import DAOBaseClass
from common.utils import preprocessing

logger = logging.getLogger(app_config.LOG)

OVERLAY = Namespace(name='OVERLAY', description='Overlay分析用API。')


@OVERLAY.route('/convert')
class OverlayConvert(Resource):
    parser = OVERLAY.parser()
    parser.add_argument('files', type=FileStorage, location='files', action='append', help='Log Files', required=True)
    parser.add_argument('category', type=str, help='Log Category Info.', required=True)

    @OVERLAY.expect(parser)
    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def post(self):
        """
        Convert Log for Overlay Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            files = args['files']
            category = args['category']

            if category == 'ADCMEASUREMENT':
                obj = ServiceAdcMeasurement()
            elif category == 'correction':
                obj = ServiceCorrection()
            else:
                return make_json_response(status=400, msg=f'Unknown Category. ({category})')

            resp_form = obj.file_check(files)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)
            data = resp_form.data

            resp_form = obj.convert(data)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            rid = resp_form.data

            return make_json_response(**{'rid': rid})

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@OVERLAY.route('/status/<string:category>/<string:rid>')
@OVERLAY.param('category', 'Category')
@OVERLAY.param('rid', 'Request ID')
class OverlayStatus(Resource):
    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def get(self, category, rid):
        """
        Get Converting Status and Info
        """
        logger.info(str(request))

        try:
            io = DAOJob.instance()
            info = io.get_job_info(rid)
            if info is None:
                logger.error(f'invalid rid {rid}')
                return make_json_response(status=400, msg=f'invalid rid {rid}')

            if info['status'] == 'success':
                df = preprocessing.add_column_adc_meas(rid=rid)
                if len(df) == 0:
                    return make_json_response(status=400, msg='Data Empty.')

                plate_list = df['plate'].unique().tolist()

                if 'log_time' in df.columns:
                    period = [str(df['log_time'].min()), str(df['log_time'].max())]
                else:
                    return make_json_response(status=400, msg='No log_time column')

                if 'job' in df.columns:
                    job_list = df['job'].unique().tolist()
                else:
                    return make_json_response(status=400, msg='No device/process column')

                lot_id = dict()
                if 'lot_id' in df.columns and 'pseudo_lot_id' in df.columns:
                    for job in job_list:
                        df_job = df[df['job'] == job]
                        normal_lot_id = df_job[df_job['pseudo_lot_id'] == False]['lot_id'].unique().tolist()
                        pseudo_lot_id = df_job[df_job['pseudo_lot_id'] == True]['lot_id'].unique().tolist()
                        lot_id[job] = {
                            'normal_lot_id': normal_lot_id,
                            'pseudo_lot_id': pseudo_lot_id
                        }

                dao_base = DAOBaseClass(table_name='fab.fab')
                fab_df = dao_base.fetch_all(args={'select': 'fab_nm'})

                info['info'] = {
                    'period': period,
                    'job': job_list,
                    'lot_id': lot_id,
                    'plate': plate_list,
                    'fab': fab_df['fab_nm'].tolist()
                }

                if category == 'correction':
                    with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_SETTING_CORR_COMP_DEFAULT), 'r') as f:
                        corr_comp_default = json.load(f)
                    info['info']['stage_correction'] = corr_comp_default['stage_correction']
                    info['info']['adc_correction'] = corr_comp_default['adc_correction']

                    service_correction = ServiceCorrection()
                    service_correction.make_correction_file(rid)

            response = make_response(jsonify(info), 200)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@OVERLAY.route('/analysis')
class OverlayConvert(Resource):
    parser = OVERLAY.parser()
    parser.add_argument('category', required=True, type=str, location='json', help='ADCMEASUREMENT or correction')
    parser.add_argument('rid', required=True, type=str, location='json', help='Request ID')
    parser.add_argument('fab_nm', required=True, type=str, location='json', help='Fab Name')
    parser.add_argument('period', required=True, type=str, location='json', help='Period(YYYY-mm-dd~YYYY-mm-dd)')
    parser.add_argument('job', required=True, type=str, location='json', help='job(device/process) info')
    parser.add_argument('lot_id', required=True, type=list, location='json', help='lot id')
    parser.add_argument('mean_dev_diff', required=True, type=list, location='json', help='Mean Deviation Diff. Setting')
    parser.add_argument('ae_correction', required=True, type=str, location='json', help='AE Correction Setting')
    parser.add_argument('cp_vs', type=dict, location='json', help='cp/vs setting info')
    parser.add_argument('correction_component', type=dict, location='json', help='Correction Component setting info')

    @OVERLAY.expect(parser)
    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def post(self):
        """
        Convert Log for Overlay Analysis
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            dao_base = DAOBaseClass(table_name='fab.fab')
            row = dao_base.fetch_one(args={'select': 'fab_nm', 'where': f"fab_nm='{args.fab_nm}'"})
            if row is None:
                with open(os.path.join(app_config.RESOURCE_PATH, app_config.RSC_SETTING_FAB_DEFAULT), 'r') as f:
                    fab_default = json.load(f)

                dao_base.insert(data={'fab_nm': args.fab_nm, **fab_default})

            if args.category == 'ADCMEASUREMENT':
                resp_form = self.analysis_adc_measurement(args)
            else:
                resp_form = self.analysis_correction(args)

            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            return make_json_response(**resp_form.data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def analysis_adc_measurement(self, args):
        service_adc_meas = ServiceAdcMeasurement()
        org_df, cp_vs_included = service_adc_meas.get_adc_meas_data(args)

        res_data = dict()
        cp_vs_display_list = list()
        cp_vs = args.cp_vs
        if cp_vs is None:
            cp_vs_setting = service_adc_meas.get_cp_vs_disp_settings(args, org_df, cp_vs_included)
            res_data['cp_vs'] = {'adc_measurement': cp_vs_setting}

            resp_form = service_adc_meas.get_etc_settings(args, org_df)
            if not resp_form.res:
                return resp_form

            res_data['etc'] = resp_form.data

            for _ in cp_vs_setting['shot']:
                cp_vs_display_list.append(cp_vs_setting['default']['display'])
        else:
            cp_vs_setting = pd.DataFrame(cp_vs['adc_measurement'])
            cp_vs_default = cp_vs_setting.reset_index().rename(columns={'index': 'step'}).astype({'step': int})
            cp_vs_default.sort_values(by='step', inplace=True)
            cp_vs_display_list = cp_vs_default['display'].tolist()

        df = deepcopy(org_df)
        # Mean Deviation Diff
        if len(args.mean_dev_diff) > 0:
            start = time.time()
            df = service_adc_meas.mean_deviation(df, args.mean_dev_diff)
            logger.debug(f'[PROCESS TIME] mean_deviation [{time.time() - start}]')

        # AE Correction
        if args.ae_correction != 'off':
            display_settings = get_display_mode_from_str(cp_vs_display_list)
            start = time.time()
            df = service_adc_meas.ae_correction(log_data=df,
                                                mode=0 if args.ae_correction == 'mode1' else 1,
                                                display_settings=display_settings)
            logger.debug(f'[PROCESS TIME] ae_correction [{time.time() - start}]')

        # map graph data calculate
        start = time.time()
        resp_form = service_adc_meas.create_map(df)
        logger.debug(f'[PROCESS TIME] create_map [{time.time() - start}]')
        if not resp_form.res:
            return resp_form

        res_data['data'] = resp_form.data

        # Reproducibility Calculate
        start = time.time()
        res_data['reproducibility'] = service_adc_meas.create_reproducibility_data(df)
        logger.debug(f'[PROCESS TIME] create_reproducibility_data [{time.time() - start}]')

        res_3sigma_max = service_adc_meas.get_3sigma_max_pos(df)
        for lot_id in res_3sigma_max.keys():
            res_data['data'][lot_id]['extra_info']['3sigma_max'] = res_3sigma_max[lot_id]

        # Rotation/Magnification Calculate
        res_data['variation'] = dict()
        start = time.time()
        res_data['variation']['plate_num'] = service_adc_meas.calc_plate_component(df)
        logger.debug(f'[PROCESS TIME] calc_plate_component [{time.time() - start}]')

        # ANOVA
        start = time.time()
        res_data['anova'] = service_adc_meas.get_calc_anova_table(org_df)
        logger.debug(f'[PROCESS TIME] get_calc_anova_table [{time.time() - start}]')

        return ResponseForm(res=True, data=res_data)

    def analysis_correction(self, args):
        dao_base = DAOBaseClass(table_name='fab.correction_component_setting')
        dao_base.delete(where_dict={'fab_nm': args.fab_nm})

        stage_correction = args.correction_component['stage_correction']
        if stage_correction is not None:
            for setting, obj in stage_correction.items():
                for item, val in obj.items():
                    dao_base.insert(data={'fab_nm': args.fab_nm,
                                          'category': 'stage_correction',
                                          'setting': setting,
                                          'item': item,
                                          'val': val})

        adc_correction = args.correction_component['adc_correction']
        if adc_correction is not None:
            for setting, obj in adc_correction.items():
                for item, val in obj.items():
                    dao_base.insert(data={'fab_nm': args.fab_nm,
                                          'category': 'adc_correction',
                                          'setting': setting,
                                          'item': item,
                                          'val': val})

        service_adc_meas = ServiceAdcMeasurement()
        org_df, cp_vs_included = service_adc_meas.get_adc_meas_data(args)

        res_data = dict()
        cp_vs_display_list = list()
        cp_vs = args.cp_vs
        if cp_vs is None:
            cp_vs_setting = service_adc_meas.get_cp_vs_disp_settings(args, org_df, cp_vs_included)
            res_data['cp_vs'] = {'adc_measurement': cp_vs_setting}

            resp_form = service_adc_meas.get_etc_settings(args, org_df)
            if not resp_form.res:
                return resp_form

            res_data['etc'] = resp_form.data

            for _ in cp_vs_setting['shot']:
                cp_vs_display_list.append(cp_vs_setting['default']['display'])
        else:
            cp_vs_setting = pd.DataFrame(cp_vs['adc_measurement'])
            cp_vs_default = cp_vs_setting.reset_index().rename(columns={'index': 'step'}).astype({'step': int})
            cp_vs_default.sort_values(by='step', inplace=True)
            cp_vs_display_list = cp_vs_default['display'].tolist()

        df = deepcopy(org_df)
        # Mean Deviation Diff
        if len(args.mean_dev_diff) > 0:
            start = time.time()
            df = service_adc_meas.mean_deviation(df, args.mean_dev_diff)
            logger.debug(f'[PROCESS TIME] mean_deviation [{time.time() - start}]')

        # AE Correction
        if args.ae_correction != 'off':
            display_settings = get_display_mode_from_str(cp_vs_display_list)
            start = time.time()
            df = service_adc_meas.ae_correction(log_data=df,
                                                mode=0 if args.ae_correction == 'mode1' else 1,
                                                display_settings=display_settings)
            logger.debug(f'[PROCESS TIME] ae_correction [{time.time() - start}]')

        # map graph data calculate
        start = time.time()
        resp_form = service_adc_meas.create_map(df)
        logger.debug(f'[PROCESS TIME] create_map [{time.time() - start}]')
        if not resp_form.res:
            return resp_form

        res_data['data'] = resp_form.data

        service_correction = ServiceCorrection()
        org_dict = service_correction.get_correction_data(args)

        if cp_vs is None:
            correction_cp_vs = service_correction.create_expo_width(org_dict[app_config.AdcCorrectionMeasOffsetEvent])
            res_data['cp_vs']['correction'] = correction_cp_vs
        else:
            correction_cp_vs = cp_vs['correction']

        stage_correction = args.correction_component['stage_correction']
        for key in stage_correction.keys():
                stage_correction[key]['selected'] = any(stage_correction[key].values())

        adc_correction = dict()
        for key, val in args.correction_component['adc_correction'].items():
            if val['selected']:
                adc_correction = {**val, 'selected': key}
                break

        params = dict()
        params['mean_deviation'] = args.mean_dev_diff
        params['cp_vs'] = correction_cp_vs
        params['correction_component'] = {'stage_correction': stage_correction,
                                          'adc_correction': adc_correction}

        result = service_correction.corretion_image_aggregateData('correction_image', params, org_dict)
        print(result)


@OVERLAY.route('/setting/<string:fab_nm>')
@OVERLAY.param('fab_nm', 'Fab Name')
class OverlaySetting(Resource):
    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def get(self, fab_nm):
        """
        Get Setting Info from selected Fab name.
        """
        logger.info(str(request))

        try:
            dao_base = DAOBaseClass(table_name='fab.correction_component_setting')
            df = dao_base.fetch_all(args={'where': f"fab_nm='{fab_nm}'"})
            if len(df) == 0:
                return make_json_response(status=400, msg='Data Empty.')

            data = dict()
            category_list = df['category'].unique().tolist()
            for category in category_list:
                data[category] = dict()
                df_category = df[df['category'] == category]
                setting_list = df_category['setting'].unique().tolist()
                for setting in setting_list:
                    data[category][setting] = dict()
                    df_setting = df[df['setting'] == setting]
                    for i in range(len(df_setting)):
                        data[category][setting][df_setting['item'].values[i]] = df_setting['val'].values[i]

            return make_json_response(**data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@OVERLAY.route('/<string:category>/cpvs/preset')
@OVERLAY.param('category', 'ADCMEASUREMENT or correction')
class OverlayCPVSPost(Resource):
    parser = OVERLAY.parser()
    parser.add_argument('preset', type=dict, location='json', required=True, help='cp/vs preset info.')
    parser.add_argument('items', type=list, location='json', required=True, help='cp/vs info of each shot.')

    @OVERLAY.expect(parser)
    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def post(self, category):
        """
        Save CP/VS Settings
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            preset = args['preset']
            dao_base = DAOBaseClass()
            if category == app_config.ADC_MEAS_LOGNAME:
                preset_table = 'fab.adc_meas_cp_vs_preset'
                preset_item_table = 'fab.adc_meas_cp_vs_preset_item'
            else:
                preset_table = 'fab.correction_cp_vs_preset'
                preset_item_table = 'fab.correction_cp_vs_preset_item'

            resp_form = dao_base.insert(table=preset_table, data=preset, rtn_id=True)
            if not resp_form.res:
                return make_json_response(status=400, msg='cp/vs preset insert fail.')

            preset_id = resp_form.data

            items = args['items']
            for item in items:
                resp_form = dao_base.insert(table=preset_item_table, data={**item, 'preset_id': preset_id})
                if not resp_form.res:
                    return make_json_response(status=400, msg='cp/vs preset item insert fail.')

            return make_json_response(**{'id': preset_id})

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


@OVERLAY.route('/<string:category>/cpvs/preset/<int:preset_id>')
@OVERLAY.param('category', 'ADCMEASUREMENT or correction')
@OVERLAY.param('preset_id', 'CP/VS Preset ID')
class OverlayCPVS(Resource):
    parser = OVERLAY.parser()
    parser.add_argument('preset', type=dict, location='json', required=True, help='cp/vs preset info.')
    parser.add_argument('items', type=list, location='json', required=True, help='cp/vs info of each shot.')

    @OVERLAY.response(200, 'Success')
    @OVERLAY.response(400, 'Bad Request')
    def get(self, category, preset_id):
        """
        Get CP/VS Setting Info.
        """
        logger.info(str(request))

        try:
            dao_base = DAOBaseClass()
            if category == app_config.ADC_MEAS_LOGNAME:
                preset_table = 'fab.adc_meas_cp_vs_preset'
                preset_item_table = 'fab.adc_meas_cp_vs_preset_item'
            else:
                preset_table = 'fab.correction_cp_vs_preset'
                preset_item_table = 'fab.correction_cp_vs_preset_item'

            row = dao_base.fetch_one(table=preset_table, args={'where': f"id={preset_id}"})
            if row is None:
                return make_json_response(status=400, msg='Wrong preset id.')

            data = dict()

            data['mode'] = row['mode']
            df = dao_base.fetch_all(table=preset_item_table, args={'where': f"preset_id={preset_id}"})
            if len(df) > 0:
                df.drop(['id', 'preset_id'], axis=1, inplace=True)
                df.set_index('shot_no', inplace=True)
                item_dict = df.to_dict(orient='index')
                data['step'] = item_dict

            return make_json_response(**data)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def put(self, category, preset_id):
        """
        Update CP/VS Setting Info.
        """
        logger.info(str(request))

        try:
            args = self.parser.parse_args()
            logger.debug(f'args : {args}')

            dao_base = DAOBaseClass()
            if category == app_config.ADC_MEAS_LOGNAME:
                preset_table = 'fab.adc_meas_cp_vs_preset'
                preset_item_table = 'fab.adc_meas_cp_vs_preset_item'
            else:
                preset_table = 'fab.correction_cp_vs_preset'
                preset_item_table = 'fab.correction_cp_vs_preset_item'

            preset = args['preset']
            resp_form = dao_base.update(table=preset_table, set=preset, where={'id': preset_id})
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            items = args['items']
            for item in items:
                shot_no = item.pop('shot_no')
                resp_form = dao_base.update(table=preset_item_table,
                                            set=item,
                                            where={'preset_id': preset_id, 'shot_no': shot_no})
                if not resp_form.res:
                    return make_json_response(status=400, msg=resp_form.msg)

            return Response(status=200)

        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))

    def delete(self, category, preset_id):
        """
        Update CP/VS Setting Info.
        """
        logger.info(str(request))

        try:
            dao_base = DAOBaseClass()
            if category == app_config.ADC_MEAS_LOGNAME:
                preset_table = 'fab.adc_meas_cp_vs_preset'
            else:
                preset_table = 'fab.correction_cp_vs_preset'

            dao_base.delete(table=preset_table, where_dict={'id': preset_id})

            return Response(status=200)
        except Exception as e:
            logger.error(str(e))
            logger.error(traceback.format_exc())
            return make_json_response(status=400, msg=str(e))


def get_display_mode_from_str(cp_vs_display_list):
    display_settings = list()
    for disp in cp_vs_display_list:
        if disp == 'P1&P2&P3':
            trans = 0
        elif disp == 'P1&P2':
            trans = 1
        elif disp == 'P2&P3':
            trans = 2
        elif disp == 'P2only':
            trans = 3
        else:
            trans = 4
        display_settings.append(trans)

    return display_settings