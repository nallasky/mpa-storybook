import sqlite3
import logging

from config import app_config

logger = logging.getLogger(app_config.LOG)


class Connect:

    connect = None
    cursor = None

    def __init__(self, config, column=False):
        if config is None or 'dbpath' not in config or config['dbpath'] == '':
            raise RuntimeError('Connect() invalid config')
        self.config = config
        self.column = column

    def __enter__(self):
        self.connect = sqlite3.connect(self.config['dbpath'], isolation_level=None)    # check_same_thread=False
        if self.connect is not None:
            self.connect.execute("PRAGMA busy_timeout=10000")
            self.connect.execute("PRAGMA foreign_keys = 1")

            if self.column:
                self.connect.row_factory = sqlite3.Row

            self.cursor = self.connect.cursor()
        return self

    def __exit__(self, type, val, traceback):
        if self.cursor is not None:
            self.cursor.close()
        if self.connect is not None:
            self.connect.close()
