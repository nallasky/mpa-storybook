class DefaultLogger:

    def info(self, msg):
        print(msg)

    def debug(self, msg):
        print(msg)

    def trace(self, msg):
        print(msg)

    def warn(self, msg):
        print(msg)

    def error(self, msg):
        print(msg)
