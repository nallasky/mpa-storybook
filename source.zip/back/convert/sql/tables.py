import os


def get_table_query_list(schema='public'):
    dependency = ['log_define_master', 'convert_rule', 'convert_rule_item', 'convert_filter',
                  'convert_filter_item', 'convert_error', 'information']
    cur = os.path.abspath(os.path.dirname(__file__))
    files = [os.path.join(cur, _) for _ in os.listdir(cur)]
    lst = dict()
    for file in files:
        if os.path.isfile(file) and file.endswith('.sql'):
            with open(file) as f:
                sql = f.read()
                sql = sql.replace('__schema__', schema)
                lst[os.path.basename(file).replace('.sql', '')] = sql

    ret = []
    for order in dependency:
        if order not in lst:
            raise RuntimeError('failed to create table query')
        ret.append({'name': order, 'sql': lst[order]})
    return ret


