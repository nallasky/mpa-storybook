alter table __schema__.convert_rule_item
	add col_prefix boolean default false not null;
