create table __schema__.information
(
    key     varchar(50) not null constraint information_pk primary key,
    value   varchar(255) not null
);