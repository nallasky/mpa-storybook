from resource.script.convert_base import ConvertBase
import datetime
import pandas as pd

header_list = [
    "evend_id",
    "event_time",
    "log_time",
    "ch_x",
    "ch_x_unit",
    "ch_y",
    "ch_y_unit",
    "height",
    "height_unit"
]


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        info_data_list = list()
        line_cnt = 0
        data_num_cnt = 1
        meas_list = list()
        functionName = "platechuckdirect"

        # Read Log File
        lines = self.readlines()

        for line in lines:
            # 改行コード等を除外した上で分割
            linelog = line.strip().split(',')
            # 1行目はヘッダ
            if line_cnt == 0:
                # event_id
                info_data_list.append(functionName + "Event")
                convert_time = datetime.datetime.strptime(linelog[0], "%Y%m%d%H%M%S")
                convert_time = "{0:%Y-%m-%dT%H:%M:%S.000000+0900}".format(convert_time)
                # event_time = 0
                info_data_list.append(convert_time)
                # log_time
                info_data_list.append(convert_time)
                # 読み込み行数をカウントアップ
                line_cnt += 1
            elif line_cnt == 1:
                # 2行目は計測指示データ
                # 使用しないためスキップ
                line_cnt += 1
            else:
                temp_list = list()
                # 数が不定でデータを取得しずらいためリストの中に設定する
                # その他の行は全て計測データ
                data_cnt = 0
                # ch_x = 0
                temp_list.append(linelog[data_cnt])
                data_cnt += 1
                # ch_x_unit = 1
                temp_list.append(linelog[data_cnt])
                data_cnt += 1
                # ch_y = 2
                temp_list.append(linelog[data_cnt])
                data_cnt += 1
                # ch_y_unit = 3
                temp_list.append(linelog[data_cnt])
                data_cnt += 1
                # height = 4
                temp_list.append(linelog[data_cnt])
                data_cnt += 1
                # height_unit = 5
                temp_list.append(linelog[data_cnt])
                # 残りの項目はDirectでは使用しないためスキップ
                # 読み込み行数をカウントアップ
                line_cnt += 1
                meas_list.append(info_data_list + temp_list)

        df = pd.DataFrame(columns=header_list, data=meas_list)
        df['log_time'] = pd.to_datetime(df['log_time'])

        return df
