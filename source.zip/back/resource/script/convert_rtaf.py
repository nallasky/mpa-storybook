from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "event_id": "event_id",
    "event_time": "event_time",
    "header1": "log_time",
    "header2": "type",
    "header3": "job",
    "header4": "lot_id",
    "header5": "plate_no",
    "header6": "shot_no",
    "header7": "cp",
    "header8": "glass_id",
    "header9": "meas_pos_psy",
    "header10": "meas_pos_chuck_y",
    "header11": "zsensor_meas_l",
    "header12": "zsensor_meas_c",
    "header13": "zsensor_meas_r",
    "header14": "wave_peak_zsens_l",
    "header15": "wave_peak_zsens_c",
    "header16": "wave_peak_zsens_r",
    "header17": "psy_prof",
    "header18": "drive_status_z",
    "header19": "drive_status_pitch",
    "header20": "drive_status_roll",
    "header21": "plate_shape_z",
    "header22": "plate_shape_pitch",
    "header23": "plate_shape_roll",
    "header24": "zsensor_plate_shape_l",
    "header25": "zsensor_plate_shape_c",
    "header26": "zsensor_plate_shape_r",
    "header27": "pos_moment_zsensor_meas_x",
    "header28": "pos_moment_zsensor_meas_z",
    "header29": "pos_moment_zsensor_meas_pitch",
    "header30": "pos_moment_zsensor_meas_roll",
    "header31": "compensation_pos_y",
    "header32": "compensation_pos_chuck_y",
    "header33": "reference_pos_z",
    "header34": "reference_pos_pitch",
    "header35": "reference_pos_roll",
    "header36": "reference_pos_slit_z",
    "header37": "plate_shape_mul_ratio_z",
    "header38": "plate_shape_mul_ratio_pitch",
    "header39": "plate_shape_mul_ratio_roll",
    "header40": "avg_plate_shape_mul_ratio_z",
    "header41": "avg_plate_shape_mul_ratio_pitch",
    "header42": "avg_plate_shape_mul_ratio_roll",
    "header43": "casp_z",
    "header44": "casp_pitch",
    "header45": "casp_roll",
}

# String型として扱いたいkey
forced_string_list = ['header1', 'header2', 'header3', 'header4', 'header8']


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logData = dict()
        resultDate = list()
        time_cnt = 0
        functionName = 'RTAF'

        # Read Log File
        lines = self.readlines()

        for line in lines:

            # 改行コード等を除外した上で分割
            linelog = line.strip().split(',')
            i = 1
            if not re.search('\s*RTDATA\s*', linelog[1]):
                continue

            logData["event_id"] = functionName + "Event"
            for etc in linelog:
                if i == 1:
                    # 2020/03/04 09:03:14　の形式を
                    # 2020-03-04T09:03:14.000000+0900　の形式に変える
                    # 日付と時間にわける
                    date, time = etc.split(" ")
                    # 日付の年月日をわける
                    year, month, day = date.split("/")
                    month = month.rjust(2, "0")
                    day = day.rjust(2, "0")
                    # time = time + ":00"
                    tmp = year + "-" + month + "-" + day + "T" + time
                    # 同じ時間の場合、ずらす（ずらさないとElasticSearchにデータが入らなくなるため）
                    # if time_before == etc:
                    #     time_cnt += 1000
                    # else:
                    #     time_before = etc
                    #     time_cnt = 0
                    time_cnt += 1
                    data_cnt = str(time_cnt).rjust(6, "0")
                    tmp = tmp + "." + data_cnt
                    tmp = tmp + "+0900"
                    logData["event_time"] = tmp

                if '=' in etc:
                    etc = etc[etc.find('=') + 1:]

                if '\"' in etc:
                    etc = etc.replace('\"', '')

                if '\t' in etc:
                    etc = etc.replace('\t', '')

                # 対応するキーが存在しないため、header + 連番をキーにする
                key = "header" + str(i)
                # int型に変換できればintに。intでなければfloat（マイナスもfloatになる）に変換する。
                # その他はstr型
                if is_int(etc) and key not in forced_string_list:
                    logData[key] = int(etc)
                elif is_float(etc) and key not in forced_string_list:
                    logData[key] = float(etc)
                else:
                    logData[key] = etc

                i = i + 1

            resultDate.append(copy.deepcopy(logData))

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)
        df['log_time'] = pd.to_datetime(df['log_time'])

        return df


###############################################################################
# str文字列がfloat()変換できるかどうかを判定する
###############################################################################
def is_float(s):
    try:
        float(s)
    except Exception:
        return False
    return True


###############################################################################
# str文字列がint()変換できるかどうかを判定する
###############################################################################
def is_int(s):
    try:
        int(s)
    except Exception:
        return False
    return True