from resource.script.convert_base import ConvertBase
import datetime
import pandas as pd

header_list = [
    "evend_id",
    "event_time",
    "log_time",
    "position_x",
    "position_x_unit",
    "position_y",
    "position_y_unit",
    "value",
    "value_unit"
]


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        info_data_list = list()
        line_cnt = 0
        data_num_cnt = 1
        meas_list = list()
        functionName = "platechuckrangescan"

        # Read Log File
        lines = self.readlines()

        for line in lines:
            # 改行コード等を除外した上で分割
            linelog = line.strip().split(',')
            # 1行目はヘッダ
            if line_cnt == 0:
                # event_id
                info_data_list.append(functionName + "Event")
                # 13桁のunix timeを10桁にする
                convert_time = int(linelog[1], 16) / 1000
                convert_time = datetime.datetime.fromtimestamp(convert_time)
                convert_time = "{0:%Y-%m-%dT%H:%M:%S.000000+0900}".format(convert_time)
                # event_time = 0
                info_data_list.append(convert_time)
                # log_time
                info_data_list.append(convert_time)
                # 読み込み行数をカウントアップ
                line_cnt += 1
            elif line_cnt == 1:
                # 2行目は計測指示データ
                # 使用しないためスキップ
                # 読み込み行数をカウントアップ
                line_cnt += 1
            else:
                temp_list = list()
                # 数が不定でデータを取得しずらいためリストの中に設定する
                # その他の行は全て計測データ
                data_cnt = 0
                # position_x = 0
                temp_list.append(linelog[data_cnt])
                data_cnt += 1
                # position_x_unit = 1
                temp_list.append(linelog[data_cnt])
                data_cnt += 1
                # position_y = 2
                temp_list.append(linelog[data_cnt])
                data_cnt += 1
                # position_y_unit = 3
                temp_list.append(linelog[data_cnt])
                data_cnt += 1
                # value = 4
                temp_list.append(linelog[data_cnt])
                data_cnt += 1
                # value_unit = 5
                temp_list.append(linelog[data_cnt])
                data_cnt += 1

                # 読み込み行数をカウントアップ
                line_cnt += 1
                meas_list.append(info_data_list + temp_list)

        df = pd.DataFrame(columns=header_list, data=meas_list)
        df['log_time'] = pd.to_datetime(df['log_time'])

        return df
