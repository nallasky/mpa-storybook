from resource.script.script_base import ScriptBase


class PreprocessBase(ScriptBase):
    """
    .. class:: PreprocessBase

    Base Class for Preprocess Script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
