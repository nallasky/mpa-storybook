from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "Table No.": "table_no_",
    "Adj. Mode": "adj_mode_",
    "Base Ill.": "base_ill_",
    "Base Speed": "base_speed_",
    "Mode": "mode_",
    "FlyEye S/D": "fly_eye_s_d_",
    "Slit Pos.": "slit_pos_",
    "Lamp Num.": "lamp_num_",
    "ND Pos.": "nd_pos_"
}

# ログファイルのヘッダ位置を定義
LOG_HEADER = 1


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logDate = dict()
        resultDate = list()
        lineCnt = 1
        linelogkey = ''

        # Read Log File
        lines = self.readlines()

        for line in lines:
            if LOG_HEADER == lineCnt:
                # ヘッダ部の読み込み
                # 改行コード等を除外した上で分割
                linelog = line.strip().strip('#').split(',')
                # 1行目のDev,Pro情報を追加する前にデータ部のヘッダに関連するkey情報を取得
                linelogkey = copy.deepcopy(linelog)
                # ヘッダー部をkeyにしてdictを作成
                for element in linelog:
                    logDate[element.strip()] = 0
            else:
                # データ部の読み込み
                # 改行コード等を除外した上で分割
                linelog = line.strip().split(',')
                cnt = 0
                # ヘッダから先に読み込まれるはずなのでkeyごとに合致する要素の値を設定する
                for key in linelogkey:
                    # int型に変換できればintに。intでなければfloat（マイナスもfloatになる）に変換する。
                    # その他はstr型
                    if is_int(linelog[cnt]) and key:
                        logDate[key] = int(linelog[cnt])
                    else:
                        logDate[key] = linelog[cnt]

                    cnt = cnt + 1

                # for key in logDateEtc.keys():
                #     if is_int(logDateEtc[key]):
                #         logDate[key] = int(logDateEtc[key])
                #     else:
                #         logDate[key] = logDateEtc[key]

                # 複数データ部が存在する場合、ヘッダ部は流用し、データ部だけ差し替えでリストに設定する。
                resultDate.append(copy.deepcopy(logDate))

            lineCnt = lineCnt + 1

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)

        return df


###############################################################################
# str文字列がint()変換できるかどうかを判定する
###############################################################################
def is_int(s):
    try:
        int(s)
    except Exception:
        return False
    return True