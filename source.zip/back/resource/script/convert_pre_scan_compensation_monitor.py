from resource.script.convert_base import ConvertBase

import pandas as pd


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        df = self.execute_system_converter()

        filename = self.get_input_log_file_name()
        if 'lot_id' in df.columns:
            lot_id_list = df['lot_id'].dropna().unique()
            if len(lot_id_list) > 0:
                if df['lot_id'].isnull().values[0]:
                    # example: [None, None, LOTID1, None, ...] -> [LOTID1, LOTID1, LOTID1, None, ...]
                    first_idx = df[df['lot_id'] == lot_id_list[0]].index.tolist()[0]
                    for idx in range(0, first_idx):
                        df.at[idx, 'lot_id'] = lot_id_list[0]

                null_list = df['lot_id'].isnull().values.tolist()
                filled_lot_id = df['lot_id'].values[0]
                for i in range(1, len(null_list)):
                    if null_list[i]:
                        df.at[i, 'lot_id'] = filled_lot_id
                    else:
                        filled_lot_id = df['lot_id'].values[i]
            else:
                df['lot_id'] = filename

        return df
