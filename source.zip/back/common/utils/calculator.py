from datetime import datetime
import time
import numpy as np
import pandas as pd

from service.script.service_script import ScriptService


def period_start_datetime(target_datetime, one_period, adj_period):
    """
    target_datetime が収まるPeriodの開始時刻を取得する

    :param Timestamp target_datetime: 調べる時刻
    :param str one_period: 期間の時間単位(1h, 2h, 4h, 6h, 12h, 24h, 1d～, 1m～)
    :param str adj_period: 期間の節目(0h-23h, 1d-31d, 0d:first day of log_list)
    :rtype: Timestamp
    :return: Period開始時刻
    """

    # 時間単位で無ければ別の関数で処理する
    if one_period[-1] != 'h':
        return period_start_datetime_dm(target_datetime, one_period, adj_period)

    # 時間情報取り出し
    one_period_h = int(one_period[0:-1])
    adj_period_h = int(adj_period[0:-1])

    # Period開始時刻のリストを生成
    period_base_list = (
        one_period_h * x + adj_period_h for x in range(int(24 / one_period_h)))
    period_base_list = [x if x < 24 else x - 24 for x in period_base_list]
    period_base_list.sort()

    # target_datetime の含まれる Period の開始時刻を調べる
    start_hour = period_base_list[-1]
    for period_base in period_base_list:
        if target_datetime.hour < period_base:
            break
        start_hour = period_base
    first_period = target_datetime.replace(
        hour=start_hour, minute=0, second=0, microsecond=0)
    return first_period


def period_start_datetime_dm(target_datetime, one_period, adj_period):
    """
    target_datetime が収まるPeriodの開始時刻を取得する(日/月単位版)
    - one_period, adj_period はこの関数に入る前に時間指定(h)は除かれている必要あり

    :param datetime.datetime target_datetime: 調べる時刻
    :param str one_period: 期間の時間単位(1d～, 1m～)
    :param str adj_period: 期間の節目(1d-31d, 0d:first day of log_list)
    :rtype: Timestamp
    :return: Period開始時刻
    """

    # まず時刻を0クリア
    first_period = target_datetime.replace(hour=0, minute=0, second=0, microsecond=0)

    one_period_unit = one_period[-1]
    adj_period_day = int(adj_period[0:-1])

    # 最初のログのタイムスタンプ基準指定ならここで終わり
    if adj_period_day <= 0:
        # 月指定の場合、28日までで丸める(全ての月で整合が取れるようにする)
        if one_period_unit == 'm' and first_period.day > 28:
            first_period = first_period.replace(day=28)
        return first_period

    # 日付を指定日に変更
    if one_period_unit == 'm':
        # 月指定の場合、28日までで丸める(全ての月で整合が取れるようにする)
        first_period = first_period.replace(
            day=adj_period_day if adj_period_day <= 28 else 28)
    else:
        while True:
            try:
                first_period = first_period.replace(day=adj_period_day)
                break
            except ValueError:
                # この月には存在しないので、１日前にずらしてみる
                adj_period_day -= 1

    # target_datetime の含まれる Period の開始時刻を調べる
    one_period_val = int(one_period[0:-1])
    month_ofs = one_period_val if one_period_unit == 'm' else 0
    day_ofs = one_period_val if one_period_unit == 'd' else 0
    if target_datetime >= first_period:
        # first_periodよりも先に該当領域があるはずなので、Periodを順繰りに辿ってみる
        while True:
            second_period = datetime.fromtimestamp(time.mktime((first_period.year,
                                                                first_period.month + month_ofs,
                                                                first_period.day + day_ofs,
                                                                0, 0, 0, 0, 0, 0)))
            if target_datetime < second_period:
                break
            first_period = second_period
    else:
        # first_periodより前に該当領域があるはずなので、Periodを逆順に辿ってみる
        while True:
            second_period = first_period
            first_period = datetime.fromtimestamp(time.mktime((second_period.year,
                                                               second_period.month - month_ofs,
                                                               second_period.day - day_ofs,
                                                               0, 0, 0, 0, 0, 0)))
            if first_period <= target_datetime:
                break
    return first_period


def calc_formula(formula, build_pd, item_list, groupby=None, script=False, rid=None):
    """
    各演算子を処理する。

    :param str formula:
    :param pd.DataFrame() build_pd:
    :param list item_list:
    :param list groupby:
    :rtype: pd.DataFrame()|None
    :return: 演算結果
    """

    # オプション指定処理
    # - オプション指定部分は、与えられたDataFrameの各要素に対しそのまま処理する

    # 前値との差分を計算
    if formula == 'delta':
        build_pd[item_list] = build_pd[item_list].diff()
        return build_pd
    # プラスマイナス反転
    if formula == 'inv':
        build_pd[item_list] *= -1.0
        return build_pd
    # 絶対値
    if formula == 'abs':
        build_pd[item_list] = build_pd[item_list].abs()
        return build_pd
    # # diff
    # if 'diff' in formula:
    #     # 現状、lot系でplate単位内で処理可能なものしかサポートしてません
    #     # - 実質 IShot 限定と考えてよい。
    #     # - 全体を一気にdiff処理するかたちにすれば何でもサポート出来るが、
    #     #   データ欠けによる広域なデータずれが怖い。いまのところ
    #     #   IGlassID に分割してループさせています。
    #     #   これなら、最悪データずれは当該プレート内に収まる。
    #     m = re.match(r'diff@(.*)@==(.*)', formula)
    #     if m is None:
    #         return None
    #     m_item = m.group(1)
    #     m_val = m.group(2)
    #     try:
    #         m_val = int(m_val)
    #     except ValueError:
    #         # intへ変換できなければ文字のまま使用する
    #         m_val = m.group(2)
    #
    #     # 前記した通り、安全を考えて小分けして処理する
    #     glassid_list = build_pd.iloc[:]['IGlassID'].copy().drop_duplicates().tolist()
    #     for glassid in glassid_list:
    #         # diff 対象 item の値リスト
    #         value_list = build_pd.loc[build_pd.IGlassID == glassid, m_item].copy().drop_duplicates().tolist()
    #         if m_val not in value_list:
    #             # ベースデータがそもそも無いので飛ばす
    #             continue
    #         # m_val 以外の値を差分値へ変換
    #         for sel_val in value_list:
    #             if sel_val == m_val:
    #                 continue
    #             build_pd.loc[(build_pd.IGlassID == glassid) &
    #                          (build_pd[m_item] == sel_val), item_list] -=\
    #                 build_pd.loc[(build_pd.IGlassID == glassid) &
    #                              (build_pd[m_item] == m_val), item_list].values
    #             # m_val を差分値へ変換 -> つまり全部 0 になる
    #
    #         build_pd.loc[(build_pd.IGlassID == glassid) &
    #                      (build_pd[m_item] == m_val), item_list] -= \
    #             build_pd.loc[(build_pd.IGlassID == glassid) &
    #                          (build_pd[m_item] == m_val), item_list].values
    #     return build_pd

    # 主統計指定
    # - 主部分であれば、groupby 単位にまとめる
    # - groupby 未指定の場合は pd.Series になるので、reset_index()
    #   せずそのままにする
    # - groupby 指定の場合はそのままだと groupby 指定列が index に
    #   なってしまうので reset_index()してあげる

    # 最大値
    if formula == 'max':
        if len(item_list) > 1:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].apply(np.nanmax)
                return build_pd.reset_index()
            else:
                build_pd = np.nanmax(build_pd[item_list].values)
                return build_pd
        else:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].max()
                return build_pd.reset_index()
            else:
                build_pd = build_pd[item_list].max()
                return build_pd
    # 平均
    if formula == 'ave':
        if len(item_list) > 1:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].apply(np.nanmean)
                return build_pd.reset_index()
            else:
                build_pd = np.nanmean(build_pd[item_list].values)
                return build_pd
        else:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].apply(np.mean)
                return build_pd.reset_index()
            else:
                build_pd = build_pd[item_list].apply(np.mean)
                return build_pd
    # 3σ
    if formula == '3sigma':
        if len(item_list) > 1:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].apply(np.nanstd) * 3.0
                return build_pd.reset_index()
            else:
                build_pd = np.nanstd(build_pd[item_list].values) * 3.0
                return build_pd
        else:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].apply(np.std) * 3.0
                return build_pd.reset_index()
            else:
                build_pd = build_pd[item_list].apply(np.std) * 3.0
                return build_pd
    # Range
    if formula == 'range':
        if len(item_list) > 1:
            if groupby is not None:
                build_pd = \
                    build_pd.groupby(groupby, sort=False)[item_list].apply(np.nanmax) - \
                    build_pd.groupby(groupby, sort=False)[item_list].apply(np.nanmin)
                return build_pd.reset_index()
            else:
                build_pd = \
                    np.nanmax(build_pd[item_list].values) - \
                    np.nanmin(build_pd[item_list].values)
                return build_pd
        else:
            if groupby is not None:
                build_pd = \
                    build_pd.groupby(groupby, sort=False)[item_list].max() - \
                    build_pd.groupby(groupby, sort=False)[item_list].min()
                return build_pd.reset_index()
            else:
                build_pd = \
                    build_pd[item_list].max() - \
                    build_pd[item_list].min()
                return build_pd

    if formula == 'count':
        if len(item_list) > 1:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].count()
                return build_pd.reset_index()
        else:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].count()
                return build_pd.reset_index()
            else:
                build_pd = build_pd[item_list].count()
                return build_pd

    if formula == 'min':
        if len(item_list) > 1:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].apply(np.nanmin)
                return build_pd.reset_index()
            else:
                build_pd = np.nanmin(build_pd[item_list].values)
                return build_pd
        else:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].min()
                return build_pd.reset_index()
            else:
                build_pd = build_pd[item_list].min()
                return build_pd

    if formula == 'nunique':
        if len(item_list) > 1:
            def def_nunique(x):
                concat_series = pd.Series()
                for col in x.columns:
                    concat_series = pd.concat([concat_series, x[col].dropna()], ignore_index=True)
                return concat_series.nunique()

            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].apply(def_nunique)
                return build_pd.reset_index()
            else:
                build_pd = def_nunique(build_pd[item_list])
                return build_pd
        else:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].nunique()
                return build_pd.reset_index()
            else:
                build_pd = build_pd[item_list].nunique()
                return build_pd

    if formula == 'sum':
        if len(item_list) > 1:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].apply(np.nansum)
                return build_pd.reset_index()
            else:
                build_pd = np.nansum(build_pd[item_list].values)
                return build_pd
        else:
            if groupby is not None:
                build_pd = build_pd.groupby(groupby, sort=False)[item_list].sum()
                return build_pd.reset_index()
            else:
                build_pd = build_pd[item_list].sum()
                return build_pd

    if script:
        script_service = ScriptService()
        return script_service.run_column_analysis_script(formula, build_pd, item_list, groupby, rid)

    # Nop
    # - 指定部分のみ切り出すだけで、演算は何もせずにそのまま返す
    # if formula == 'Nop':
    #     return build_pd[item_list + groupby].reset_index(drop=True)

    # そんな演算子は無い
    return None