import os
import pandas.tseries.offsets as t_offsets
import datetime
import pandas as pd
from config.app_config import *
from common.utils.data_impoter_util import DataImpoterUtil


def divide_by_stats_period(log_df, start, stats_period):
    if stats_period is None:
        return log_df

    stats_period_unit = stats_period[-1].lower()
    stats_period_val = int(stats_period[0:-1])

    start = datetime.datetime.strptime(str(start), '%Y-%m-%d %H:%M:%S')
    log_df['period'] = start

    if stats_period_val <= 0:
        return log_df

    if stats_period_unit not in ['m', 'd', 'h']:
        return log_df

    interval_period = t_offsets.DateOffset(months=stats_period_val if stats_period_unit == 'm' else 0,
                                           days=stats_period_val if stats_period_unit == 'd' else 0,
                                           hours=stats_period_val if stats_period_unit == 'h' else 0)

    # 最終データのタイムスタンプ
    # last_log_time = log_df.iloc[log_df.shape[0] - 1]['log_time']
    last_log_time = log_df['log_time'].max()

    # 順繰りに仕分けして行く
    st = start
    ed = st + interval_period
    while st <= last_log_time:
        log_df.loc[
            (st <= log_df.log_time) &
            (log_df.log_time < ed),
            'period'] = st
        st = ed
        ed = st + interval_period

    return log_df


def load_data(rid, **filters):
    root_dir = os.path.join(CNV_RESULT_PATH, rid)
    if not os.path.exists(root_dir):
        return None

    dfs = list()
    for (root, dirs, files) in os.walk(root_dir):
        for file in files:
            path = os.path.join(root, file)
            # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
            df = pd.read_csv(path, index_col=False)
            dfs.append(df)

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    df = apply_filters(df, filters)

    for col in COLUMN_OMIT_LIST:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    if len(df) > 0 and 'log_time' in df.columns:
        # 時間順序で整列
        df.sort_values(by='log_time', ascending=True, inplace=True)
        df.reset_index(inplace=True, drop=True)

    return df


def apply_filters(df, filters):
    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            """
            {
                "log_time": {
                    "start": "YYYY-mm-dd",
                    "end": "YYYY-mm-dd"
                }
            }
            """
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df[key]) & (df[key] <= end)]
        elif key == 'period':
            """
            {
                "period": "YYYY-mm-dd~YYYY-mm-dd"
            }
            """
            if 'log_time' in df.columns:
                [start, end] = filters[key].split(sep='~')
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        elif key == 'filter':
            """
            {
                "column_name": [
                    {
                        "logical_type": "default", // and, or, default
                        "data_type": "number", // string, date, number
                        "condition": {
                            "filter_type": "over",
                            "filter_value": "0"
                        }
                    }, ...
                ]
            }
            """
            for column_name in val.keys():
                if column_name not in df.columns:
                    df[column_name] = None

                filter_list = val[column_name]
                default_filter_idx = 0
                for i in range(len(filter_list)):
                    if filter_list[i]['logical_type'] == 'default':
                        default_filter_idx = i
                        break
                default_filter = filter_list.pop(default_filter_idx)
                filter_list.insert(0, default_filter)

                total_filter = None
                for filter_item in filter_list:
                    data_type = filter_item['data_type']
                    if data_type == 'number':
                        filter_value = float(filter_item['condition']['filter_value'])
                    elif data_type == 'date':
                        fmt = [
                            '%Y-%m-%d %H:%M:%S',
                            '%Y/%m/%d %H:%M:%S',
                            '%Y-%m-%d',
                            '%m/%d %H:%M:%S',
                            '%m/%d %H:%M:%S:%f',
                            '%Y/%m/%d',
                            '%H:%M:%S',
                            '%Y%m%d%H%M%S',
                            '%Y/%m/%d %H%M%S%f',
                            '%Y/%m/%d %H:%M:%S:%f'
                        ]
                        filter_value = filter_item['condition']['filter_value']
                        if isinstance(filter_value, str):
                            for f in fmt:
                                try:
                                    filter_value = datetime.datetime.strptime(filter_value, f)
                                    break
                                except ValueError:
                                    continue
                    else:
                        filter_value = str(filter_item['condition']['filter_value'])

                    filter_type = filter_item['condition']['filter_type']

                    total_filter = apply_filter_condition(df,
                                                          column_name,
                                                          filter_type,
                                                          filter_value,
                                                          filter_item['logical_type'],
                                                          total_filter)
                df = df[total_filter]
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    val = [str(_) for _ in val]
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == str(val)]

    return df


def apply_filter_condition(df, column_name, type, val, logical, before_filter):
    filter_result = None
    if type == 'more':
        filter_result = df[column_name] >= val
    elif type == 'less':
        filter_result = df[column_name] <= val
    elif type == 'over':
        filter_result = df[column_name] > val
    elif type == 'under':
        filter_result = df[column_name] < val
    elif type == 'match' or type == 'equal':
        filter_result = df[column_name] == val
    elif type == 'not_match':
        filter_result = df[column_name] != val
    elif type == 'include':
        filter_result = df[column_name].str.contains(val)
    elif type == 'start':
        filter_result = df[column_name].str.startswith(val)
    elif type == 'end':
        filter_result = df[column_name].str.endswith(val)

    if logical == 'and':
        filter_result = before_filter & filter_result
    elif logical == 'or':
        filter_result = before_filter | filter_result

    return filter_result


def add_column_overlay(rid, category):
    # category 추가, 함수명칭 변경(add_column_overlay)
    # root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), ADC_MEAS_LOGNAME))
    root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), category))
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()

    # AdcMeasurementの疑似LotID用の変数
    pseudo_lot_cnt = 0

    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
        df['pseudo_lot_id'] = False
        if 'dummy_lot_id' not in df.columns:
            df['dummy_lot_id'] = ''

        before_plate = -1
        ascflg = False
        descflg = False

        for i in range(len(df)):
            # 空白を除去した上でLotIDを取得
            lot_id = df['lot_id'].values[i].strip()

            # LotIDが空か？
            if len(lot_id) == 0:
                dummy_lot_id = df['dummy_lot_id'].values[i].strip()
                # DummyLotIDが空か？
                if len(dummy_lot_id) == 0:
                    # Plate取得
                    plate = int(df['plate'].values[i])
                    # 初回の計測か？
                    if before_plate == -1:

                        before_plate = plate
                    # plateの値が前回と同じ場合は処理無し
                    elif before_plate == plate:
                        pass
                    # Plateの数値が前回より大きい（昇順に並んでいた場合）
                    elif before_plate < plate and not descflg:
                        before_plate = plate
                        ascflg = True
                    # Plateの数が前回より小さい（降順に並んでいた場合）
                    elif before_plate > plate and not ascflg:
                        before_plate = plate
                        descflg = True

                    if ascflg:
                        # 取得したplateの数が小さくなった場合
                        if before_plate > plate:
                            # 疑似LotIDのナンバリングを更新
                            pseudo_lot_cnt += 1
                            ascflg = False
                            before_plate = plate
                    if descflg:
                        # 取得したplateの数が大きくなった場合
                        if before_plate < plate:
                            # 疑似LotIDのナンバリングを更新
                            pseudo_lot_cnt += 1
                            descflg = False
                            before_plate = plate

                    # 疑似Lotフラグを設定
                    df.at[i, 'pseudo_lot_id'] = True
                    # 疑似LotIDを設定（LOTID_日付_ナンバリング）
                    df.at[i, 'lot_id'] = 'LOTID_' + \
                                         str(datetime.date.today()) + \
                                         '_' + str(pseudo_lot_cnt)
                else:
                    # DummyLotIDを設定
                    df.at[i, 'lot_id'] = dummy_lot_id
                    df.at[i, 'pseudo_lot_id'] = True

        df['job'] = df['device'] + '/' + df['process']
        df.to_csv(path, header=True, index=False)
        dfs.append(df)
        pseudo_lot_cnt += 1

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    if len(df) > 0 and 'log_time' in df.columns:
        # 時間順序で整列
        df.sort_values(by='log_time', ascending=True, inplace=True)
        df.reset_index(inplace=True, drop=True)

    return df


def add_column_focus(rid):
    """
    Add extra infomation for focus log. ex) lot_id
    """
    # log_dict = dict()

    # Read StatusMonitor
    status_monitor_df = None
    root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), STATUSMONIOTOR_LOGNAME))
    if os.path.exists(root_dir):
        files = os.listdir(root_dir)
        dfs = list()

        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
            dfs.append(df)

        status_monitor_df = pd.concat(dfs)
        status_monitor_df['log_time'] = pd.to_datetime(status_monitor_df['log_time'])
        status_monitor_df.sort_values(by='log_time', ascending=True, inplace=True)

    log_list = [RECALL_PLATE_AUTO_FOCUS, RECALL_STAGE_POSITION, RECALL_PLATE_FOCUS, RECALL_PRE_SCAN_COMP, RECALL_FOCUS_LOG_DETAIL]
    for log_name in log_list:
        root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), log_name))
        if not os.path.exists(root_dir):
            continue
        add_column_focus_sub(root_dir, status_monitor_df)

    log_list = [RECALL_MACHINE, RECALL_PROCESS]
    util = DataImpoterUtil()
    for log_name in log_list:
        root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), log_name))
        if not os.path.exists(root_dir):
            continue

        files = os.listdir(root_dir)
        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
            df['val'] = df['val'].apply(lambda x: util.conv_hex_dec_minus(x))

            if log_name == RECALL_PROCESS:
                try:
                    [dev, pro] = str(file).replace('.pro', '').split(sep=',')
                except Exception:
                    raise RuntimeError('Process filename must not contain comma(,) charactor.')

                dev = dev.split(sep=UPLOAD_FILE_SEPERATOR)[-1]
                df['job'] = str(dev) + '/' + str(pro)

            df.to_csv(path, header=True, index=False)


def add_column_focus_sub(root_dir, status_monitor_df=None):
    files = os.listdir(root_dir)
    # dfs = list()

    if status_monitor_df is not None and len(status_monitor_df):
        sts_mon_lot_id_blk_df = \
            status_monitor_df.drop(index=status_monitor_df[status_monitor_df['lot_id_block'] == ''].index).groupby(
                'lot_id_block')['log_time'].agg([('start', 'min'), ('end', 'max')]).reset_index()
    else:
        sts_mon_lot_id_blk_df = None

    for file in files:
        path = os.path.join(root_dir, file)
        df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
        df['pseudo_lot_id'] = False
        if 'dummy_lot_id' not in df.columns:
            df['dummy_lot_id'] = ''

        for i in range(len(df)):
            # 空白を除去した上でLotIDを取得
            lot_id = df['lot_id'].values[i].strip()
            dummy_lot_id = df['dummy_lot_id'].values[i].strip()
            pseudo_lot_id = ''
            if sts_mon_lot_id_blk_df is not None:
                log_time = df['log_time'].values[i]
                filtered_df = sts_mon_lot_id_blk_df[
                    (sts_mon_lot_id_blk_df['start'] <= log_time) & (sts_mon_lot_id_blk_df['end'] >= log_time)]
                if len(filtered_df):
                    pseudo_lot_id = filtered_df['lot_id_block'].values[0]

            # 空か？
            if len(lot_id) == 0:
                if len(dummy_lot_id) == 0:
                    # DummyLotIDがないので疑似LotIDを設定
                    # StatusMonitorからLotIDを取得（疑似LotID）
                    df.at[i, 'lot_id'] = pseudo_lot_id
                else:
                    # DummyLotIDはあるのでLotIDに設定
                    df.at[i, 'lot_id'] = dummy_lot_id + '_' + pseudo_lot_id
                df.at[i, 'pseudo_lot_id'] = True
            else:
                # 同じLotIDが割り当てられることがあるので区別するためリワーク処理を行う
                if len(dummy_lot_id) == 0:
                    # ログに入っていたLotID_疑似LotIDで生成する
                    df.at[i, 'lot_id'] = lot_id + '_' + pseudo_lot_id
                else:
                    # ログに入っていたLotID_DummyLotIDで生成する
                    df.at[i, 'lot_id'] = lot_id + '_' + dummy_lot_id

        df['job'] = df['device'] + '/' + df['process']
        df.to_csv(path, header=True, index=False)
        # dfs.append(df)

    # merged_df = pd.concat(dfs)
    # merged_df['log_time'] = pd.to_datetime(merged_df['log_time'])
    # merged_df.sort_values(by='log_time', ascending=True, inplace=True)
    # return merged_df


def add_column_focus_correction(rid):
    """
    Add extra infomation for focus log. ex) lot_id
    """
    # log_dict = dict()

    # Read StatusMonitor
    status_monitor_df = None
    root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), STATUSMONIOTOR_LOGNAME))
    if os.path.exists(root_dir):
        files = os.listdir(root_dir)
        dfs = list()

        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
            dfs.append(df)

        status_monitor_df = pd.concat(dfs)
        status_monitor_df['log_time'] = pd.to_datetime(status_monitor_df['log_time'])
        status_monitor_df.sort_values(by='log_time', ascending=True, inplace=True)

    log_list = [FOCUS_FUNC_PRESCAN, FOCUS_FUNC_RTAF]
    for log_name in log_list:
        root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), log_name))
        if not os.path.exists(root_dir):
            continue

        files = os.listdir(root_dir)
        # dfs = list()

        if status_monitor_df is not None and len(status_monitor_df):
            sts_mon_lot_id_blk_df = \
                status_monitor_df.drop(index=status_monitor_df[status_monitor_df['lot_id_block'] == ''].index).groupby(
                    'lot_id_block')['log_time'].agg([('start', 'min'), ('end', 'max')]).reset_index()
        else:
            sts_mon_lot_id_blk_df = None

        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
            df['pseudo_lot_id'] = False

            for i in range(len(df)):
                # 空白を除去した上でLotIDを取得
                lot_id = df['lot_id'].values[i].strip()
                pseudo_lot_id = ''
                if sts_mon_lot_id_blk_df is not None:
                    log_time = df['log_time'].values[i]
                    filtered_df = sts_mon_lot_id_blk_df[
                        (sts_mon_lot_id_blk_df['start'] <= log_time) & (sts_mon_lot_id_blk_df['end'] >= log_time)]
                    if len(filtered_df):
                        pseudo_lot_id = filtered_df['lot_id_block'].values[0]

                # 空か？
                if len(lot_id) == 0:
                    # 疑似LotIDを追加
                    df.at[i, 'lot_id'] = pseudo_lot_id
                    df.at[i, 'pseudo_lot_id'] = True
                else:
                    # 同じLotIDが割り当てられることがあるので区別するためリワーク処理を行う
                    # ログに入っていたLotID_疑似LotIDで生成する
                    df.at[i, 'lot_id'] = lot_id + '_' + pseudo_lot_id

            if log_name == FOCUS_FUNC_PRESCAN:
                # 計測値の計算
                type_chg_list = ['plate_shape_l', 'focus_ofs_l', 'prescan_comp_l', 'plate_shape_c', 'focus_ofs_c',
                    'prescan_comp_c', 'plate_shape_r', 'focus_ofs_r', 'prescan_comp_r']
                df[type_chg_list] = df[type_chg_list].astype(int)
                df['prescan_meas_l'] = df['plate_shape_l'] - df['focus_ofs_l'] - df['prescan_comp_l']
                df['prescan_meas_c'] = df['plate_shape_c'] - df['focus_ofs_c'] - df['prescan_comp_c']
                df['prescan_meas_r'] = df['plate_shape_r'] - df['focus_ofs_r'] - df['prescan_comp_r']

            df.to_csv(path, header=True, index=False)


def load_adc_meas(rid, **filters):
    root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), ADC_MEAS_LOGNAME)
    # root_dir = os.path.join('..',os.path.join(os.path.join(CNV_RESULT_PATH, rid), "OASBaseLineMeasurement"))
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False, dtype=str)
        dfs.append(df)

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        elif key == 'data_type':
            continue
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    val = [str(_) for _ in val]
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == str(val)]

    for col in COLUMN_OMIT_LIST:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    if len(df) > 0:
        if 'log_time' in df.columns:
            if 'plate' in df.columns and 'step' in df.columns:
                df.sort_values(by=['log_time', 'plate', 'step'], ascending=True, inplace=True)
            else:
                # 時間順序で整列
                df.sort_values(by='log_time', ascending=True, inplace=True)

        df = df.drop_duplicates(subset=['lot_id', 'glass_id', 'step'], keep='last')

        df.reset_index(inplace=True, drop=True)

    return df


def load_machine_data(rid):
    df = pd.DataFrame(columns=['key', 'val'])

    root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), RECALL_MACHINE))
    if not os.path.exists(root_dir):
        return df

    files = os.listdir(root_dir)
    for file in files:
        path = os.path.join(root_dir, file)
        df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
        df['val'] = df['val'].astype('int64')

    return df


def load_oas_base(rid, **filters):
    root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), OASBASELINE_LOGNAME)
    # root_dir = os.path.join('..',os.path.join(os.path.join(CNV_RESULT_PATH, rid), "OASBaseLineMeasurement"))
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False, dtype=str)
        dfs.append(df)

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    if 'plate' in df.columns:
        df = df.astype({"plate": "int"})

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    val = [str(_) for _ in val]
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == str(val)]

    for col in COLUMN_OMIT_LIST:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    if len(df) > 0:
        if 'log_time' in df.columns:
            if 'plate' in df.columns and 'step' in df.columns:
                df.sort_values(by=['log_time', 'plate', 'step'], ascending=True, inplace=True)
            else:
                # 時間順序で整列
                df.sort_values(by='log_time', ascending=True, inplace=True)

        df = df.drop_duplicates(subset=['lot_id', 'glass_id', 'step', 'data_type'], keep='last')

        df.reset_index(inplace=True, drop=True)

    return df


def load_correction_file(rid, to_df=False, **filters):
    root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), CORRECTION_LOGNAME)
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)

    adc_correction_meas_offset_event_list = list()
    adc_correction_offset_event = list()
    adc_correction_meas_event = list()
    stage_correction_map_event = list()

    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        with open(path, mode='r') as f:
            lines = f.readlines()

        for line in lines:
            line_dict = eval(line)
            if line_dict['event_id'] == AdcCorrectionMeasOffsetEvent:
                adc_correction_meas_offset_event_list.append(line_dict)
            elif line_dict['event_id'] == AdcCorrectionOffsetEvent:
                adc_correction_offset_event.append(line_dict)
            elif line_dict['event_id'] == AdcCorrectionMeasEvent:
                adc_correction_meas_event.append(line_dict)
            elif line_dict['event_id'] == StageCorrectionMapEvent:
                stage_correction_map_event.append(line_dict)

    adc_correction_meas_offset_event_df = pd.DataFrame(adc_correction_meas_offset_event_list)
    adc_correction_offset_df = pd.DataFrame(adc_correction_offset_event)
    adc_correction_meas_df = pd.DataFrame(adc_correction_meas_event)
    stage_correction_map_df = pd.DataFrame(stage_correction_map_event)

    df = pd.concat([adc_correction_meas_offset_event_df, adc_correction_offset_df,
                    adc_correction_meas_df, stage_correction_map_df])

    df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass

                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d %H:%M:%S')
                    end = end + '.999999'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    val = [str(_) for _ in val]
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == str(val)]

    if len(df) > 0:
        df.reset_index(drop=True, inplace=True)
        if to_df:
            return df
        else:
            result = dict()
            for event_id in df['event_id'].unique().tolist():
                result[event_id] = list(df[df['event_id'] == event_id].to_dict(orient='index').values())

            return result

    raise Exception('correction data empty.')


def get_data_period(df):
    if 'log_time' in df.columns:
        period = dict()
        period['start'] = df['log_time'].min()
        period['end'] = df['log_time'].max()
        return period
    else:
        return None


def make_dummy_data(column_type_dict):
    data = dict()
    for key, val in column_type_dict.items():
        if val is int:
            data[key] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        elif val is float:
            data[key] = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]
        elif val is str:
            data[key] = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        elif val is datetime:
            data[key] = ['2021-01-01', '2021-02-01', '2021-03-01', '2021-04-01', '2021-05-01',
                         '2021-06-01', '2021-07-01', '2021-08-01', '2021-09-01', '2021-10-01']
        elif val is bool:
            data[key] = [True, False, True, False, True, False, True, False, True, False]
        else:
            data[key] = ['', '', '', '', '', '', '', '', '', '']

    return pd.DataFrame(data)


def add_column_status(rid):
    root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), STATUSMONIOTOR_LOGNAME)
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    df_dict = dict()
    date_time = None

    path = ''
    for file in files:
        path = os.path.join(root_dir, file)
        df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
        os.remove(path)
        df['job'] = df['device'] + '/' + df['process']
        fmt_list = ['%Y-%m-%d %H:%M:%S.%f', '%Y-%m-%d %H:%M:%S']
        for fmt in fmt_list:
            try:
                date_time = datetime.datetime.strptime(df['log_time'].head(1)[0], fmt)
                break
            except Exception as e:
                if fmt == fmt_list[-1]:
                    raise RuntimeError('datetime format mismatch.')

        df_dict[date_time] = list()
        df_dict[date_time].append(df)
        df_dict[date_time].append(path)
        dfs.append(df)

    if len(dfs) > 0:
        org_df = pd.concat(dfs)
    else:
        org_df = pd.DataFrame()

    df_dict = dict(sorted(df_dict.items()))

    before_day = ''
    before_lot_id_block = ''
    before_prediction_id = ''
    before_job = ''
    before_plate = 0
    for date, info in df_dict.items():
        df = info[0]
        path = info[1]
        first_log = True

        if 'log_time' in df.columns:
            df['log_time'] = pd.to_datetime(df['log_time'])

        if len(df) > 0 and 'log_time' in df.columns:
            # 時間順序で整列
            # df.sort_values(by='log_time', ascending=True, inplace=True)
            df.reset_index(inplace=True, drop=True)

        df['lot_id_block'] = ''
        df['prediction_id'] = ''
        df['lot_id_block'] = df['lot_id_block'].astype(str)
        df['prediction_id'] = df['prediction_id'].astype(str)
        lot_id_block_cnt = 0
        prediction_cnt = 0
        lot_id_block = ''
        prediction_id = ''
        before_idx = 0
        idx = 0
        now = datetime.datetime.now()
        now_str = now.strftime("%Y%m%d%H%M%S")
        event_df = df[(df['event'] == 'Lot End') | (df['event'] == 'JOB End')]
        for idx, item in event_df.iterrows():
            date = item['log_time'].strftime('%Y-%m-%d')

            # RecallログのDevPro情報がある最初のログか？
            if (first_log) and before_day != '':
                first_log = False
                date_str = df.loc[df.index.start]['log_time'].strftime('%Y-%m-%d')
                date = datetime.datetime.strptime(date_str, '%Y-%m-%d')
                plate = int(df.loc[df.index.start]['plate'])
                job = df.loc[df.index.start]['job']
                before_day = datetime.datetime.strptime(before_day, '%Y-%m-%d')
                if (date == before_day and job == before_job and plate == before_plate) or ((date - datetime.timedelta(
                        days=1)) == before_day and job == before_job and plate == before_plate):
                    lot_id_block = before_lot_id_block
                    prediction_id = before_prediction_id
                else:
                    date = date.strftime('%Y-%m-%d')
                    before_lot_id_block = lot_id_block = 'LOTID_' + date + '_' + str(lot_id_block_cnt)
                    before_prediction_id = prediction_id = now_str + '_' + str(prediction_cnt)
            else:
                lot_id_block = 'LOTID_' + date + '_' + str(lot_id_block_cnt)
                prediction_id = now_str + '_' + str(prediction_cnt)

            if item['event'] == 'Lot End':
                # Lot Endイベントから次同イベントが同じPlateであれば、同じlot_id_blockとして追加する。
                extra = 1
                while (df.loc[idx + extra]['event'] != 'JOB End') and (
                        df.loc[idx]['plate'] == df.loc[idx + extra]['plate']) and (
                        df.loc[idx]['job'] == df.loc[idx + extra]['job']):
                    extra = extra + 1

                df.loc[before_idx:idx + extra, 'lot_id_block'] = lot_id_block
                df.loc[before_idx:idx + extra, 'prediction_id'] = prediction_id
                before_idx = idx + extra
                before_lot_id_block = lot_id_block
                lot_id_block_cnt = lot_id_block_cnt + 1

            if item['event'] == 'JOB End':
                df.loc[before_idx:idx + 1, 'lot_id_block'] = before_lot_id_block
                df.loc[before_idx:idx + 1, 'prediction_id'] = prediction_id
                before_idx = idx + 1
                prediction_cnt = prediction_cnt + 1

        if df.index.stop - 1 > idx:
            if before_lot_id_block == lot_id_block:
                date = df.loc[idx + 1]['log_time'].strftime('%Y-%m-%d')
                lot_id_block = 'LOTID_' + date + '_' + str(lot_id_block_cnt)
                prediction_id = now_str + '_' + str(prediction_cnt)

            df.loc[idx + 1:, 'lot_id_block'] = lot_id_block
            df.loc[idx + 1:, 'prediction_id'] = prediction_id

        before_day = date
        before_lot_id_block = lot_id_block
        before_prediction_id = prediction_id
        before_plate = int(df.loc[df.index.stop - 1]['plate'])
        before_job = df.loc[df.index.stop - 1]['job']
        df.to_csv(path, header=True, index=False)

    return org_df


def load_status_monitor(rid, **filters):
    root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), STATUSMONIOTOR_LOGNAME)
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False, dtype=str)
        dfs.append(df)

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    if 'plate' in df.columns:
        df['plate'] = df['plate'].astype(int)

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        elif key == 'job':
            dfs = list()
            if 'job' in df.columns:
                jobs = filters[key]
                if isinstance(jobs, list) == True:
                    for job in jobs:
                        dfs.append(df[job == df['job']])
                else:
                    dfs.append(df[jobs == df['job']])
            df = pd.concat(dfs)
        elif key == 'lot_id_block':
            if 'lot_id_block' in df.columns:
                lot_id_block = filters[key]
                df = df[lot_id_block == df['lot_id_block']]
        elif key == 'plate':
            if 'plate' in df.columns:
                plate = int(filters[key])
                df = df[plate == df['plate']]
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    val = [str(_) for _ in val]
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == str(val)]

    for col in COLUMN_OMIT_LIST:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    if len(df) > 0:
        if 'log_time' in df.columns:
            if 'job' in df.columns:
                df.sort_values(by=['log_time', 'job'], ascending=True, inplace=True)
            else:
                # 時間順序で整列
                df.sort_values(by='log_time', ascending=True, inplace=True)

        # df = df.drop_duplicates(subset=['job'], keep='last')
        df['event'] = df['event'].str.strip()
        df['lot_id'] = df['lot_id'].str.strip()
        df.reset_index(inplace=True, drop=True)

    return df


def load_focus_log(rid, log_list=None, **filters):
    log_dict = dict()

    column_type = {
        RECALL_PLATE_AUTO_FOCUS: {
            'drive_height': float, 'drive_pitch': float, 'drive_roll': float,
            'zsens_fl': float, 'zsens_fc': float, 'zsens_fr': float,
            'zsens_bl': float, 'zsens_bc': float, 'zsens_br': float,
            'stage_pos_afc_meas_height': float
        },
        RECALL_STAGE_POSITION: {
            'ps_x': float, 'ps_y': float, 'ps_z': float,
            'ps_pitch': float, 'ps_roll': float
        },
        RECALL_PRE_SCAN_COMP: {
            'expo_start_pos_psz': float, 'expo_start_pos_psp': float, 'expo_start_pos_psr': float
        },
        RECALL_PLATE_FOCUS: {
            'focus_diff_height': float
        }
    }

    if log_list is None:
        log_list = FOCUS_LOG_LIST

    for log_name in log_list:
        root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), log_name))
        if not os.path.exists(root_dir):
            # log_dict[log_name] = pd.DataFrame()
            continue

        files = os.listdir(root_dir)
        dfs = list()
        file_cnt = 0
        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str)
            df['file_cnt'] = file_cnt
            file_cnt += 1
            dfs.append(df)

        if len(dfs) > 0:
            df = pd.concat(dfs)
        else:
            df = pd.DataFrame()

        if 'plate' in df.columns:
            # 24160 Headerがplateとして使用されるため、内部的にplate_noで変更して処理。
            df.rename(columns={'plate': 'plate_no'}, inplace=True)

        if 'plate_no' in df.columns:
            df['plate_no'] = df['plate_no'].astype(int)

        if 'step_no' in df.columns:
            df['step_no'] = df['step_no'].astype(int)

        if 'log_time' in df.columns:
            df['log_time'] = pd.to_datetime(df['log_time'])

        if 'pseudo_lot_id' in df.columns:
            df['pseudo_lot_id'] = df['pseudo_lot_id'].apply(lambda x: True if x == 'True' else False)

        for key, val in filters.items():
            if key == 'log_time':
                if 'log_time' in df.columns:
                    start = filters[key]['start']
                    end = filters[key]['end']
                    try:
                        datetime.datetime.strptime(end, '%Y-%m-%d')
                        end = end + ' 23:59:59'
                    except Exception as e:
                        pass
                    df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
            elif key == 'job':
                dfs = list()
                if 'job' in df.columns:
                    jobs = filters[key]
                    if isinstance(jobs, list) == True:
                        for job in jobs:
                            dfs.append(df[job == df['job']])
                    else:
                        dfs.append(df[jobs == df['job']])
                df = pd.concat(dfs)
            elif key == 'lot_id_block':
                if 'lot_id_block' in df.columns:
                    lot_id_block = filters[key]
                    df = df[lot_id_block == df['lot_id_block']]
            elif key == 'plate':
                if 'plate' in df.columns:
                    plate = int(filters[key])
                    df = df[plate == df['plate']]
            else:
                if key not in df.columns:
                    df[key] = None

                df_copy = df.astype({key: str})

                if isinstance(val, list):
                    if len(val) > 0:
                        val = [str(_) for _ in val]
                        df = df[df_copy[key].isin(val)]
                else:
                    df = df[df_copy[key] == str(val)]

        for col in COLUMN_OMIT_LIST:
            if col in df.columns:
                df.drop(col, axis=1, inplace=True)

        if len(df) > 0:
            if 'log_time' in df.columns:
                if 'job' in df.columns:
                    df.sort_values(by=['log_time', 'job'], ascending=True, inplace=True)
                else:
                    # 時間順序で整列
                    df.sort_values(by='log_time', ascending=True, inplace=True)

            # df = df.drop_duplicates(subset=['job'], keep='last')
            if 'lot_id' in df.columns:
                df['lot_id'] = df['lot_id'].str.strip()

            df.reset_index(inplace=True, drop=True)

            log_dict[log_name] = df

    for log_name, types in column_type.items():
        if log_name in log_dict:
            tmp_astype = dict()
            for col, val in types.items():
                if col in log_dict[log_name].columns:
                    tmp_astype[col] = val
            log_dict[log_name] = log_dict[log_name].astype(tmp_astype)

    return log_dict
