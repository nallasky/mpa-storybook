import os
import pandas.tseries.offsets as t_offsets
import datetime
import pandas as pd
import numpy as np
from config.app_config import *
from common.utils.data_impoter_util import DataImpoterUtil


def divide_by_stats_period(log_df, start, stats_period):
    if stats_period is None:
        return log_df

    stats_period_unit = stats_period[-1].lower()
    stats_period_val = int(stats_period[0:-1])

    start = datetime.datetime.strptime(str(start), '%Y-%m-%d %H:%M:%S')
    log_df['period'] = start

    if stats_period_val <= 0:
        return log_df

    if stats_period_unit not in ['m', 'd', 'h']:
        return log_df

    interval_period = t_offsets.DateOffset(months=stats_period_val if stats_period_unit == 'm' else 0,
                                           days=stats_period_val if stats_period_unit == 'd' else 0,
                                           hours=stats_period_val if stats_period_unit == 'h' else 0)

    # 最終データのタイムスタンプ
    # last_log_time = log_df.iloc[log_df.shape[0] - 1]['log_time']
    last_log_time = log_df['log_time'].max()

    # 順繰りに仕分けして行く
    st = start
    ed = st + interval_period
    while st <= last_log_time:
        log_df.loc[
            (st <= log_df.log_time) &
            (log_df.log_time < ed),
            'period'] = st
        st = ed
        ed = st + interval_period

    return log_df


def load_data(rid, **filters):
    root_dir = os.path.join(CNV_RESULT_PATH, rid)
    if not os.path.exists(root_dir):
        return None

    dfs = list()
    for (root, dirs, files) in os.walk(root_dir):
        for file in files:
            path = os.path.join(root, file)
            # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
            df = pd.read_csv(path, index_col=False)
            dfs.append(df)

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    df = apply_filters(df, filters)

    for col in COLUMN_OMIT_LIST:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    if len(df) > 0 and 'log_time' in df.columns:
        # 時間順序で整列
        df.sort_values(by='log_time', ascending=True, inplace=True)
        df.reset_index(inplace=True, drop=True)

    return df


def apply_filters(df, filters):
    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            """
            {
                "log_time": {
                    "start": "YYYY-mm-dd",
                    "end": "YYYY-mm-dd"
                }
            }
            """
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df[key]) & (df[key] <= end)]
        elif key == 'period':
            """
            {
                "period": "YYYY-mm-dd~YYYY-mm-dd"
            }
            """
            if 'log_time' in df.columns:
                [start, end] = filters[key].split(sep='~')
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        elif key == 'filter':
            """
            {
                "column_name": [
                    {
                        "logical_type": "default", // and, or, default
                        "data_type": "number", // string, date, number
                        "condition": {
                            "filter_type": "over",
                            "filter_value": "0"
                        }
                    }, ...
                ]
            }
            """
            for column_name in val.keys():
                if column_name not in df.columns:
                    df[column_name] = None

                filter_list = val[column_name]
                default_filter_idx = 0
                for i in range(len(filter_list)):
                    if filter_list[i]['logical_type'] == 'default':
                        default_filter_idx = i
                        break
                default_filter = filter_list.pop(default_filter_idx)
                filter_list.insert(0, default_filter)

                total_filter = None
                for filter_item in filter_list:
                    data_type = filter_item['data_type']
                    if data_type == 'number':
                        filter_value = float(filter_item['condition']['filter_value'])
                    elif data_type == 'date':
                        fmt = [
                            '%Y-%m-%d %H:%M:%S',
                            '%Y/%m/%d %H:%M:%S',
                            '%Y-%m-%d',
                            '%m/%d %H:%M:%S',
                            '%m/%d %H:%M:%S:%f',
                            '%Y/%m/%d',
                            '%H:%M:%S',
                            '%Y%m%d%H%M%S',
                            '%Y/%m/%d %H%M%S%f',
                            '%Y/%m/%d %H:%M:%S:%f'
                        ]
                        filter_value = filter_item['condition']['filter_value']
                        if isinstance(filter_value, str):
                            for f in fmt:
                                try:
                                    filter_value = datetime.datetime.strptime(filter_value, f)
                                    break
                                except ValueError:
                                    continue
                    else:
                        filter_value = str(filter_item['condition']['filter_value'])

                    filter_type = filter_item['condition']['filter_type']

                    total_filter = apply_filter_condition(df,
                                                          column_name,
                                                          filter_type,
                                                          filter_value,
                                                          filter_item['logical_type'],
                                                          total_filter)
                df = df[total_filter]
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    val = [str(_) for _ in val]
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == str(val)]

    return df


def apply_filter_condition(df, column_name, type, val, logical, before_filter):
    filter_result = None
    if type == 'more':
        filter_result = df[column_name] >= val
    elif type == 'less':
        filter_result = df[column_name] <= val
    elif type == 'over':
        filter_result = df[column_name] > val
    elif type == 'under':
        filter_result = df[column_name] < val
    elif type == 'match' or type == 'equal':
        filter_result = df[column_name] == val
    elif type == 'not_match':
        filter_result = df[column_name] != val
    elif type == 'include':
        filter_result = df[column_name].str.contains(val)
    elif type == 'start':
        filter_result = df[column_name].str.startswith(val)
    elif type == 'end':
        filter_result = df[column_name].str.endswith(val)

    if logical == 'and':
        filter_result = before_filter & filter_result
    elif logical == 'or':
        filter_result = before_filter | filter_result

    return filter_result


def add_column_overlay(rid, category):
    # category 추가, 함수명칭 변경(add_column_overlay)
    # root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), ADC_MEAS_LOGNAME))
    root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), category))
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()

    # AdcMeasurementの疑似LotID用の変数
    pseudo_lot_cnt = 0

    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
        df['pseudo_lot_id'] = False
        if 'dummy_lot_id' not in df.columns:
            df['dummy_lot_id'] = ''

        before_plate = -1
        ascflg = False
        descflg = False

        for i in range(len(df)):
            # 空白を除去した上でLotIDを取得
            lot_id = df['lot_id'].values[i].strip()

            # LotIDが空か？
            if len(lot_id) == 0:
                dummy_lot_id = df['dummy_lot_id'].values[i].strip()
                # DummyLotIDが空か？
                if len(dummy_lot_id) == 0:
                    # Plate取得
                    plate = int(df['plate'].values[i])
                    # 初回の計測か？
                    if before_plate == -1:

                        before_plate = plate
                    # plateの値が前回と同じ場合は処理無し
                    elif before_plate == plate:
                        pass
                    # Plateの数値が前回より大きい（昇順に並んでいた場合）
                    elif before_plate < plate and not descflg:
                        before_plate = plate
                        ascflg = True
                    # Plateの数が前回より小さい（降順に並んでいた場合）
                    elif before_plate > plate and not ascflg:
                        before_plate = plate
                        descflg = True

                    if ascflg:
                        # 取得したplateの数が小さくなった場合
                        if before_plate > plate:
                            # 疑似LotIDのナンバリングを更新
                            pseudo_lot_cnt += 1
                            ascflg = False
                            before_plate = plate
                    if descflg:
                        # 取得したplateの数が大きくなった場合
                        if before_plate < plate:
                            # 疑似LotIDのナンバリングを更新
                            pseudo_lot_cnt += 1
                            descflg = False
                            before_plate = plate

                    # 疑似Lotフラグを設定
                    df.at[i, 'pseudo_lot_id'] = True
                    # 疑似LotIDを設定（LOTID_日付_ナンバリング）
                    df.at[i, 'lot_id'] = 'LOTID_' + \
                                         str(datetime.date.today()) + \
                                         '_' + str(pseudo_lot_cnt)
                else:
                    # DummyLotIDを設定
                    df.at[i, 'lot_id'] = dummy_lot_id
                    df.at[i, 'pseudo_lot_id'] = True

        df['job'] = df['device'] + '/' + df['process']
        df.to_csv(path, header=True, index=False)
        dfs.append(df)
        pseudo_lot_cnt += 1

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    if len(df) > 0 and 'log_time' in df.columns:
        # 時間順序で整列
        df.sort_values(by='log_time', ascending=True, inplace=True)
        df.reset_index(inplace=True, drop=True)

    return df


def add_column_focus(rid):
    """
    Add extra infomation for focus log. ex) lot_id
    """
    # log_dict = dict()

    # Read StatusMonitor
    status_monitor_df = None
    root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), STATUSMONIOTOR_LOGNAME))
    if os.path.exists(root_dir):
        files = os.listdir(root_dir)
        dfs = list()

        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
            dfs.append(df)

        status_monitor_df = pd.concat(dfs)
        status_monitor_df['log_time'] = pd.to_datetime(status_monitor_df['log_time'])
        status_monitor_df.sort_values(by='log_time', ascending=True, inplace=True)

    log_list = [RECALL_PLATE_AUTO_FOCUS, RECALL_STAGE_POSITION, RECALL_PLATE_FOCUS, RECALL_PRE_SCAN_COMP, RECALL_FOCUS_LOG_DETAIL]
    for log_name in log_list:
        root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), log_name))
        if not os.path.exists(root_dir):
            continue
        add_column_focus_sub(root_dir, status_monitor_df)

    log_list = [RECALL_MACHINE, RECALL_PROCESS]
    util = DataImpoterUtil()
    for log_name in log_list:
        root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), log_name))
        if not os.path.exists(root_dir):
            continue

        files = os.listdir(root_dir)
        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
            df['val'] = df['val'].apply(lambda x: util.conv_hex_dec_minus(x))

            if log_name == RECALL_PROCESS:
                try:
                    [dev, pro] = str(file).replace('.pro', '').split(sep=',')
                except Exception:
                    raise RuntimeError('Process filename must not contain comma(,) charactor.')

                dev = dev.split(sep=UPLOAD_FILE_SEPERATOR)[-1]
                df['job'] = str(dev) + '/' + str(pro)

            df.to_csv(path, header=True, index=False)


def add_column_focus_sub(root_dir, status_monitor_df=None):
    files = os.listdir(root_dir)
    # dfs = list()

    if status_monitor_df is not None and len(status_monitor_df):
        sts_mon_lot_id_blk_df = \
            status_monitor_df.drop(index=status_monitor_df[status_monitor_df['lot_id_block'] == ''].index).groupby(
                'lot_id_block')['log_time'].agg([('start', 'min'), ('end', 'max')]).reset_index()
    else:
        sts_mon_lot_id_blk_df = None

    for file in files:
        path = os.path.join(root_dir, file)
        df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
        df['pseudo_lot_id'] = False
        if 'dummy_lot_id' not in df.columns:
            df['dummy_lot_id'] = ''

        for i in range(len(df)):
            # 空白を除去した上でLotIDを取得
            lot_id = df['lot_id'].values[i].strip()
            dummy_lot_id = df['dummy_lot_id'].values[i].strip()
            pseudo_lot_id = ''
            if sts_mon_lot_id_blk_df is not None:
                log_time = df['log_time'].values[i]
                filtered_df = sts_mon_lot_id_blk_df[
                    (sts_mon_lot_id_blk_df['start'] <= log_time) & (sts_mon_lot_id_blk_df['end'] >= log_time)]
                if len(filtered_df):
                    pseudo_lot_id = filtered_df['lot_id_block'].values[0]

            # 空か？
            if len(lot_id) == 0:
                if len(dummy_lot_id) == 0:
                    # DummyLotIDがないので疑似LotIDを設定
                    # StatusMonitorからLotIDを取得（疑似LotID）
                    df.at[i, 'lot_id'] = pseudo_lot_id
                else:
                    # DummyLotIDはあるのでLotIDに設定
                    df.at[i, 'lot_id'] = dummy_lot_id + '_' + pseudo_lot_id
                df.at[i, 'pseudo_lot_id'] = True
            else:
                # 同じLotIDが割り当てられることがあるので区別するためリワーク処理を行う
                if len(dummy_lot_id) == 0:
                    # ログに入っていたLotID_疑似LotIDで生成する
                    df.at[i, 'lot_id'] = lot_id + '_' + pseudo_lot_id
                else:
                    # ログに入っていたLotID_DummyLotIDで生成する
                    df.at[i, 'lot_id'] = lot_id + '_' + dummy_lot_id

        df['job'] = df['device'] + '/' + df['process']
        df.to_csv(path, header=True, index=False)
        # dfs.append(df)

    # merged_df = pd.concat(dfs)
    # merged_df['log_time'] = pd.to_datetime(merged_df['log_time'])
    # merged_df.sort_values(by='log_time', ascending=True, inplace=True)
    # return merged_df


def add_column_focus_correction(rid):
    """
    Add extra infomation for focus log. ex) lot_id
    """
    # log_dict = dict()

    # Read StatusMonitor
    status_monitor_df = None
    root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), STATUSMONIOTOR_LOGNAME))
    if os.path.exists(root_dir):
        files = os.listdir(root_dir)
        dfs = list()

        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
            dfs.append(df)

        status_monitor_df = pd.concat(dfs)
        status_monitor_df['log_time'] = pd.to_datetime(status_monitor_df['log_time'])
        status_monitor_df.sort_values(by='log_time', ascending=True, inplace=True)

    log_list = [FOCUS_FUNC_PRESCAN, FOCUS_FUNC_RTAF]
    for log_name in log_list:
        root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), log_name))
        if not os.path.exists(root_dir):
            continue

        files = os.listdir(root_dir)
        # dfs = list()

        if status_monitor_df is not None and len(status_monitor_df):
            sts_mon_lot_id_blk_df = \
                status_monitor_df.drop(index=status_monitor_df[status_monitor_df['lot_id_block'] == ''].index).groupby(
                    'lot_id_block')['log_time'].agg([('start', 'min'), ('end', 'max')]).reset_index()
        else:
            sts_mon_lot_id_blk_df = None

        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
            df['pseudo_lot_id'] = False

            for i in range(len(df)):
                # 空白を除去した上でLotIDを取得
                lot_id = df['lot_id'].values[i].strip()
                pseudo_lot_id = ''
                if sts_mon_lot_id_blk_df is not None:
                    log_time = df['log_time'].values[i]
                    filtered_df = sts_mon_lot_id_blk_df[
                        (sts_mon_lot_id_blk_df['start'] <= log_time) & (sts_mon_lot_id_blk_df['end'] >= log_time)]
                    if len(filtered_df):
                        pseudo_lot_id = filtered_df['lot_id_block'].values[0]

                # 空か？
                if len(lot_id) == 0:
                    # 疑似LotIDを追加
                    df.at[i, 'lot_id'] = pseudo_lot_id
                    df.at[i, 'pseudo_lot_id'] = True
                else:
                    # 同じLotIDが割り当てられることがあるので区別するためリワーク処理を行う
                    # ログに入っていたLotID_疑似LotIDで生成する
                    df.at[i, 'lot_id'] = lot_id + '_' + pseudo_lot_id

            if log_name == FOCUS_FUNC_PRESCAN:
                # 計測値の計算
                type_chg_list = ['plate_shape_l', 'focus_ofs_l', 'prescan_comp_l', 'plate_shape_c', 'focus_ofs_c',
                    'prescan_comp_c', 'plate_shape_r', 'focus_ofs_r', 'prescan_comp_r']
                df[type_chg_list] = df[type_chg_list].astype(int)
                df['prescan_meas_l'] = df['plate_shape_l'] - df['focus_ofs_l'] - df['prescan_comp_l']
                df['prescan_meas_c'] = df['plate_shape_c'] - df['focus_ofs_c'] - df['prescan_comp_c']
                df['prescan_meas_r'] = df['plate_shape_r'] - df['focus_ofs_r'] - df['prescan_comp_r']

            df.to_csv(path, header=True, index=False)


def load_adc_meas(rid, **filters):
    root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), ADC_MEAS_LOGNAME)
    # root_dir = os.path.join('..',os.path.join(os.path.join(CNV_RESULT_PATH, rid), "OASBaseLineMeasurement"))
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False, dtype=str)
        dfs.append(df)

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        elif key == 'data_type':
            continue
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    val = [str(_) for _ in val]
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == str(val)]

    for col in COLUMN_OMIT_LIST:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    if len(df) > 0:
        if 'log_time' in df.columns:
            if 'plate' in df.columns and 'step' in df.columns:
                df.sort_values(by=['log_time', 'plate', 'step'], ascending=True, inplace=True)
            else:
                # 時間順序で整列
                df.sort_values(by='log_time', ascending=True, inplace=True)

        df = df.drop_duplicates(subset=['lot_id', 'glass_id', 'step'], keep='last')

        df.reset_index(inplace=True, drop=True)

    return df


def load_machine_data(rid):
    df = pd.DataFrame(columns=['key', 'val'])

    root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), RECALL_MACHINE))
    if not os.path.exists(root_dir):
        return df

    files = os.listdir(root_dir)
    for file in files:
        path = os.path.join(root_dir, file)
        df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
        df['val'] = df['val'].astype('int64')

    return df


def load_oas_base(rid, **filters):
    root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), OASBASELINE_LOGNAME)
    # root_dir = os.path.join('..',os.path.join(os.path.join(CNV_RESULT_PATH, rid), "OASBaseLineMeasurement"))
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False, dtype=str)
        dfs.append(df)

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    if 'plate' in df.columns:
        df = df.astype({"plate": "int"})

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    val = [str(_) for _ in val]
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == str(val)]

    for col in COLUMN_OMIT_LIST:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    if len(df) > 0:
        if 'log_time' in df.columns:
            if 'plate' in df.columns and 'step' in df.columns:
                df.sort_values(by=['log_time', 'plate', 'step'], ascending=True, inplace=True)
            else:
                # 時間順序で整列
                df.sort_values(by='log_time', ascending=True, inplace=True)

        df = df.drop_duplicates(subset=['lot_id', 'glass_id', 'step', 'data_type'], keep='last')

        df.reset_index(inplace=True, drop=True)

    return df


def load_correction_file(rid, to_df=False, **filters):
    root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), CORRECTION_LOGNAME)
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)

    adc_correction_meas_offset_event_list = list()
    adc_correction_offset_event = list()
    adc_correction_meas_event = list()
    stage_correction_map_event = list()

    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        with open(path, mode='r') as f:
            lines = f.readlines()

        for line in lines:
            line_dict = eval(line)
            if line_dict['event_id'] == AdcCorrectionMeasOffsetEvent:
                adc_correction_meas_offset_event_list.append(line_dict)
            elif line_dict['event_id'] == AdcCorrectionOffsetEvent:
                adc_correction_offset_event.append(line_dict)
            elif line_dict['event_id'] == AdcCorrectionMeasEvent:
                adc_correction_meas_event.append(line_dict)
            elif line_dict['event_id'] == StageCorrectionMapEvent:
                stage_correction_map_event.append(line_dict)

    adc_correction_meas_offset_event_df = pd.DataFrame(adc_correction_meas_offset_event_list)
    adc_correction_offset_df = pd.DataFrame(adc_correction_offset_event)
    adc_correction_meas_df = pd.DataFrame(adc_correction_meas_event)
    stage_correction_map_df = pd.DataFrame(stage_correction_map_event)

    df = pd.concat([adc_correction_meas_offset_event_df, adc_correction_offset_df,
                    adc_correction_meas_df, stage_correction_map_df])

    df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass

                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d %H:%M:%S')
                    end = end + '.999999'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    val = [str(_) for _ in val]
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == str(val)]

    if len(df) > 0:
        df.reset_index(drop=True, inplace=True)
        if to_df:
            return df
        else:
            result = dict()
            for event_id in df['event_id'].unique().tolist():
                result[event_id] = list(df[df['event_id'] == event_id].to_dict(orient='index').values())

            return result

    raise Exception('correction data empty.')


def get_data_period(df):
    if 'log_time' in df.columns:
        period = dict()
        period['start'] = df['log_time'].min()
        period['end'] = df['log_time'].max()
        return period
    else:
        return None


def make_dummy_data(column_type_dict):
    data = dict()
    for key, val in column_type_dict.items():
        if val is int:
            data[key] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        elif val is float:
            data[key] = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]
        elif val is str:
            data[key] = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        elif val is datetime:
            data[key] = ['2021-01-01', '2021-02-01', '2021-03-01', '2021-04-01', '2021-05-01',
                         '2021-06-01', '2021-07-01', '2021-08-01', '2021-09-01', '2021-10-01']
        elif val is bool:
            data[key] = [True, False, True, False, True, False, True, False, True, False]
        else:
            data[key] = ['', '', '', '', '', '', '', '', '', '']

    return pd.DataFrame(data)


def add_column_status(rid):
    root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), STATUSMONIOTOR_LOGNAME)
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    df_dict = dict()
    date_time = None

    path = ''
    for file in files:
        path = os.path.join(root_dir, file)
        df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
        os.remove(path)
        df['job'] = df['device'] + '/' + df['process']
        fmt_list = ['%Y-%m-%d %H:%M:%S.%f', '%Y-%m-%d %H:%M:%S']
        for fmt in fmt_list:
            try:
                date_time = datetime.datetime.strptime(df['log_time'].head(1)[0], fmt)
                break
            except Exception as e:
                if fmt == fmt_list[-1]:
                    raise RuntimeError('datetime format mismatch.')

        df_dict[date_time] = list()
        df_dict[date_time].append(df)
        df_dict[date_time].append(path)
        dfs.append(df)

    if len(dfs) > 0:
        org_df = pd.concat(dfs)
    else:
        org_df = pd.DataFrame()

    df_dict = dict(sorted(df_dict.items()))

    before_day = ''
    before_lot_id_block = ''
    before_prediction_id = ''
    before_job = ''
    before_plate = 0
    for date, info in df_dict.items():
        df = info[0]
        path = info[1]
        first_log = True

        if 'log_time' in df.columns:
            df['log_time'] = pd.to_datetime(df['log_time'])

        if len(df) > 0 and 'log_time' in df.columns:
            # 時間順序で整列
            # df.sort_values(by='log_time', ascending=True, inplace=True)
            df.reset_index(inplace=True, drop=True)

        df['lot_id_block'] = ''
        df['prediction_id'] = ''
        df['lot_id_block'] = df['lot_id_block'].astype(str)
        df['prediction_id'] = df['prediction_id'].astype(str)
        lot_id_block_cnt = 0
        prediction_cnt = 0
        lot_id_block = ''
        prediction_id = ''
        before_idx = 0
        idx = 0
        now = datetime.datetime.now()
        now_str = now.strftime("%Y%m%d%H%M%S")
        event_df = df[(df['event'] == 'Lot End') | (df['event'] == 'JOB End')]
        for idx, item in event_df.iterrows():
            date = item['log_time'].strftime('%Y-%m-%d')

            # RecallログのDevPro情報がある最初のログか？
            if (first_log) and before_day != '':
                first_log = False
                date_str = df.loc[df.index.start]['log_time'].strftime('%Y-%m-%d')
                date = datetime.datetime.strptime(date_str, '%Y-%m-%d')
                plate = int(df.loc[df.index.start]['plate'])
                job = df.loc[df.index.start]['job']
                before_day = datetime.datetime.strptime(before_day, '%Y-%m-%d')
                if (date == before_day and job == before_job and plate == before_plate) or ((date - datetime.timedelta(
                        days=1)) == before_day and job == before_job and plate == before_plate):
                    lot_id_block = before_lot_id_block
                    prediction_id = before_prediction_id
                else:
                    date = date.strftime('%Y-%m-%d')
                    before_lot_id_block = lot_id_block = 'LOTID_' + date + '_' + str(lot_id_block_cnt)
                    before_prediction_id = prediction_id = now_str + '_' + str(prediction_cnt)
            else:
                lot_id_block = 'LOTID_' + date + '_' + str(lot_id_block_cnt)
                prediction_id = now_str + '_' + str(prediction_cnt)

            if item['event'] == 'Lot End':
                # Lot Endイベントから次同イベントが同じPlateであれば、同じlot_id_blockとして追加する。
                extra = 1
                while (df.loc[idx + extra]['event'] != 'JOB End') and (
                        df.loc[idx]['plate'] == df.loc[idx + extra]['plate']) and (
                        df.loc[idx]['job'] == df.loc[idx + extra]['job']):
                    extra = extra + 1

                df.loc[before_idx:idx + extra, 'lot_id_block'] = lot_id_block
                df.loc[before_idx:idx + extra, 'prediction_id'] = prediction_id
                before_idx = idx + extra
                before_lot_id_block = lot_id_block
                lot_id_block_cnt = lot_id_block_cnt + 1

            if item['event'] == 'JOB End':
                df.loc[before_idx:idx + 1, 'lot_id_block'] = before_lot_id_block
                df.loc[before_idx:idx + 1, 'prediction_id'] = prediction_id
                before_idx = idx + 1
                prediction_cnt = prediction_cnt + 1

        if df.index.stop - 1 > idx:
            if before_lot_id_block == lot_id_block:
                date = df.loc[idx + 1]['log_time'].strftime('%Y-%m-%d')
                lot_id_block = 'LOTID_' + date + '_' + str(lot_id_block_cnt)
                prediction_id = now_str + '_' + str(prediction_cnt)

            df.loc[idx + 1:, 'lot_id_block'] = lot_id_block
            df.loc[idx + 1:, 'prediction_id'] = prediction_id

        before_day = date
        before_lot_id_block = lot_id_block
        before_prediction_id = prediction_id
        before_plate = int(df.loc[df.index.stop - 1]['plate'])
        before_job = df.loc[df.index.stop - 1]['job']
        df.to_csv(path, header=True, index=False)

    return org_df


def load_status_monitor(rid, **filters):
    root_dir = os.path.join(os.path.join(CNV_RESULT_PATH, rid), STATUSMONIOTOR_LOGNAME)
    if not os.path.exists(root_dir):
        return None

    files = os.listdir(root_dir)
    dfs = list()
    for file in files:
        path = os.path.join(root_dir, file)
        # df = pd.read_csv(path, index_col=False, na_values=NA_VALUE, keep_default_na=False)
        df = pd.read_csv(path, index_col=False, dtype=str)
        dfs.append(df)

    if len(dfs) > 0:
        df = pd.concat(dfs)
    else:
        df = pd.DataFrame()

    if 'plate' in df.columns:
        df['plate'] = df['plate'].astype(int)

    if 'log_time' in df.columns:
        df['log_time'] = pd.to_datetime(df['log_time'])

    for key, val in filters.items():
        if key == 'log_time':
            if 'log_time' in df.columns:
                start = filters[key]['start']
                end = filters[key]['end']
                try:
                    datetime.datetime.strptime(end, '%Y-%m-%d')
                    end = end + ' 23:59:59'
                except Exception as e:
                    pass
                df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
        elif key == 'job':
            dfs = list()
            if 'job' in df.columns:
                jobs = filters[key]
                if isinstance(jobs, list) == True:
                    for job in jobs:
                        dfs.append(df[job == df['job']])
                else:
                    dfs.append(df[jobs == df['job']])
            df = pd.concat(dfs)
        elif key == 'lot_id_block':
            if 'lot_id_block' in df.columns:
                lot_id_block = filters[key]
                df = df[lot_id_block == df['lot_id_block']]
        elif key == 'plate':
            if 'plate' in df.columns:
                plate = int(filters[key])
                df = df[plate == df['plate']]
        else:
            if key not in df.columns:
                df[key] = None

            df_copy = df.astype({key: str})

            if isinstance(val, list):
                if len(val) > 0:
                    val = [str(_) for _ in val]
                    df = df[df_copy[key].isin(val)]
            else:
                df = df[df_copy[key] == str(val)]

    for col in COLUMN_OMIT_LIST:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    if len(df) > 0:
        if 'log_time' in df.columns:
            if 'job' in df.columns:
                df.sort_values(by=['log_time', 'job'], ascending=True, inplace=True)
            else:
                # 時間順序で整列
                df.sort_values(by='log_time', ascending=True, inplace=True)

        # df = df.drop_duplicates(subset=['job'], keep='last')
        df['event'] = df['event'].str.strip()
        df['lot_id'] = df['lot_id'].str.strip()
        df.reset_index(inplace=True, drop=True)

    return df


def load_focus_log(rid, log_list=None, **filters):
    log_dict = dict()

    column_type = {
        RECALL_PLATE_AUTO_FOCUS: {
            'drive_height': float, 'drive_pitch': float, 'drive_roll': float,
            'zsens_fl': float, 'zsens_fc': float, 'zsens_fr': float,
            'zsens_bl': float, 'zsens_bc': float, 'zsens_br': float,
            'stage_pos_afc_meas_height': float
        },
        RECALL_STAGE_POSITION: {
            'ps_x': float, 'ps_y': float, 'ps_z': float,
            'ps_pitch': float, 'ps_roll': float
        },
        RECALL_PRE_SCAN_COMP: {
            'expo_start_pos_psz': float, 'expo_start_pos_psp': float, 'expo_start_pos_psr': float
        },
        RECALL_PLATE_FOCUS: {
            'focus_diff_height': float
        },
        FOCUS_FUNC_PRESCAN: {
            'plate_shape_l': int, 'plate_shape_c': int, 'plate_shape_r': int,
            'focus_ofs_l': int, 'focus_ofs_c': int, 'focus_ofs_r': int,
            'prescan_comp_l': int, 'prescan_comp_c': int, 'prescan_comp_r': int,
            'prescan_meas_l': int, 'prescan_meas_c': int, 'prescan_meas_r': int,
            'mask_stage_y': int
        },
        FOCUS_FUNC_RTAF: {
            'zsensor_meas_l': int, 'zsensor_meas_c': int, 'zsensor_meas_r': int,
            'zsensor_plate_shape_l': int, 'zsensor_plate_shape_c': int, 'zsensor_plate_shape_r': int,
            'reference_pos_slit_z': int,
            "plate_shape_z": int, "plate_shape_pitch": int, "plate_shape_roll": int,
            'drive_status_z': int, 'drive_status_pitch': int, 'drive_status_roll': int,
            'reference_pos_z': int, 'reference_pos_pitch': int, 'reference_pos_roll': int,
            'meas_pos_psy': int
        }
    }

    if log_list is None:
        log_list = FOCUS_LOG_LIST

    for log_name in log_list:
        root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), log_name))
        if not os.path.exists(root_dir):
            # log_dict[log_name] = pd.DataFrame()
            continue

        files = os.listdir(root_dir)
        dfs = list()
        file_cnt = 0
        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str)
            df['file_cnt'] = file_cnt
            file_cnt += 1
            dfs.append(df)

        if len(dfs) > 0:
            df = pd.concat(dfs)
        else:
            df = pd.DataFrame()

        if 'plate' in df.columns:
            # 24160 Headerがplateとして使用されるため、内部的にplate_noで変更して処理。
            df.rename(columns={'plate': 'plate_no'}, inplace=True)

        if 'plate_no' in df.columns:
            df['plate_no'] = df['plate_no'].astype(int)

        if 'step_no' in df.columns:
            df['step_no'] = df['step_no'].astype(int)

        if 'shot_no' in df.columns:
            df['shot_no'] = df['shot_no'].astype(int)

        if 'log_time' in df.columns:
            df['log_time'] = pd.to_datetime(df['log_time'])

        if 'pseudo_lot_id' in df.columns:
            df['pseudo_lot_id'] = df['pseudo_lot_id'].apply(lambda x: True if x == 'True' else False)

        for key, val in filters.items():
            if key == 'log_time':
                if 'log_time' in df.columns:
                    start = filters[key]['start']
                    end = filters[key]['end']
                    try:
                        datetime.datetime.strptime(end, '%Y-%m-%d')
                        end = end + ' 23:59:59'
                    except Exception as e:
                        pass
                    df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
            elif key == 'job':
                dfs = list()
                if 'job' in df.columns:
                    jobs = filters[key]
                    if isinstance(jobs, list) == True:
                        for job in jobs:
                            dfs.append(df[job == df['job']])
                    else:
                        dfs.append(df[jobs == df['job']])
                df = pd.concat(dfs)
            elif key == 'lot_id_block':
                if 'lot_id_block' in df.columns:
                    lot_id_block = filters[key]
                    df = df[lot_id_block == df['lot_id_block']]
            elif key == 'plate':
                if 'plate' in df.columns:
                    plate = int(filters[key])
                    df = df[plate == df['plate']]
            else:
                if key not in df.columns:
                    df[key] = None

                df_copy = df.astype({key: str})

                if isinstance(val, list):
                    if len(val) > 0:
                        val = [str(_) for _ in val]
                        df = df[df_copy[key].isin(val)]
                else:
                    df = df[df_copy[key] == str(val)]

        for col in COLUMN_OMIT_LIST:
            if col in df.columns:
                df.drop(col, axis=1, inplace=True)

        if len(df) > 0:
            if 'log_time' in df.columns:
                if 'job' in df.columns:
                    df.sort_values(by=['log_time', 'job'], ascending=True, inplace=True)
                else:
                    # 時間順序で整列
                    df.sort_values(by='log_time', ascending=True, inplace=True)

            # df = df.drop_duplicates(subset=['job'], keep='last')
            if 'lot_id' in df.columns:
                df['lot_id'] = df['lot_id'].str.strip()

            df.reset_index(inplace=True, drop=True)

            log_dict[log_name] = df

    for log_name, types in column_type.items():
        if log_name in log_dict:
            tmp_astype = dict()
            for col, val in types.items():
                if col in log_dict[log_name].columns:
                    tmp_astype[col] = val
            log_dict[log_name] = log_dict[log_name].astype(tmp_astype)

    return log_dict


def add_column_platechuck(rid):
    """
       Add extra infomation for platechuck log.
       and convert minux hex data to Decimal
       """

    # default machine info
    machine_dict = {
        # Machine Type： [00151]
        "00151": 12,
        # Chuck Attachment Size : [21204]
        "21204": 0,
        # Chuck Groove : [1072C]
        "1072C": 0
    }

    util = DataImpoterUtil()
    root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), RECALL_MACHINE))
    if os.path.exists(root_dir):
        files = os.listdir(root_dir)
        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str, keep_default_na=False)
            df['val'] = df['val'].apply(lambda x: util.conv_hex_dec_minus(x))

            if df[df['key'] == '00151']['key'].any():
                machine_dict['00151'] = df[df['key'] == '00150']['val'].tolist()[0]

            if df[df['key'] == '21204']['key'].any():
                machine_dict['21204'] = df[df['key'] == '21204']['val'].tolist()[0]

            if df[df['key'] == '1072C']['key'].any():
                machine_dict['1072C'] = df[df['key'] == '1072C']['val'].tolist()[0]

            df.to_csv(path, header=True, index=False)

    for log_name in FOCUS_CHUCK_LOG_LIST:
        root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), log_name))
        if not os.path.exists(root_dir):
            continue
        add_column_platechuck_sub(root_dir, log_name, machine_dict)



def add_column_platechuck_sub(root_dir, log_name, machine_dict):
    # 固定値（PlateChuckArcuationScanConst#PITCH_X_DATA_ARRAY）
    PITCH_X_DATA_ARRAY = [30.0, 60.0, 120.0, 240.0, 480.0, 10.0, 20.0]

    # 固定値（PlateChuckArcuationScanConst#PITCH_Y_DATA_ARRAY）
    PITCH_Y_DATA_ARRAY = [25.3125, 50.625, 101.25, 202.5, 405.0, 10.0, 20.0]
    G86MAX_PLATE_SIZE_X = 2400
    EDGE_INTERVAL = 20

    column_type = {
            'platechuckdirect': {
            "ch_x_unit": int,
            "ch_y_unit": int,
            "height_unit": int
        },
        'platechuckscan': {
            'plate_size_x': str,
            'plate_size_y': str,
            'plate_size_x_unit': int,
            'plate_size_y_unit': int,
            "targe_divide_chuck_side_unit": int,
            "the_other_chuck_side_measure_count_unit": int,
            "sensor_kind": int,
            "position_x_unit": int,
            "position_y_unit": int,
            "bl_value_unit": int,
            "br_value_unit": int
        },
        'platechuckrangescan': {
            "position_x_unit": int,
            "position_y_unit": int,
            "value_unit": int
        }
    }
    util = DataImpoterUtil()
    chuck_g86 = util.isChuckG86(machine_dict)
    zsensor_e813_pos = util.isZSensorE813G45Pos(machine_dict)
    direct_h800_enable = util.isPlateChuckArcDirectH800Enable(machine_dict)

    if log_name == 'platechuckdirect':
        files = os.listdir(root_dir)
        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, keep_default_na=False)
            df = df.astype(column_type[log_name])
            info_dict = df.drop(
                columns=['ch_x', 'ch_y', 'height', 'ch_x_unit', 'ch_y_unit', 'height_unit']).drop_duplicates().to_dict()
            df['x_data'] = df['ch_x'].apply(lambda x: util.conv_hex_dec_minus(x)) / df['ch_x_unit']
            df['y_data'] = df['ch_y'].apply(lambda x: util.conv_hex_dec_minus(x)) / df['ch_y_unit']
            df['z_data'] = df['height'].apply(lambda x: util.conv_hex_dec_minus(x)) / df['height_unit']

            graph_pos_df = pd.DataFrame()
            coef = 0

            # H800以外の場合、各計測値の平均を算出処理を行う。
            if not direct_h800_enable:
                graph_pos_df = df.groupby(['x_data', 'y_data'], as_index=False).mean()
                graph_pos_df['z_data'] = graph_pos_df['z_data'].apply(lambda x: round(x, 3))
                graph_pos_df.drop(labels=['ch_x_unit', 'ch_y_unit', 'height_unit'], axis=1)
                x_list = graph_pos_df['x_data'].apply(lambda x: x * 1000).to_list()
                y_list = graph_pos_df['y_data'].apply(lambda x: x * 1000).to_list()
                z_list = graph_pos_df['z_data'].to_list()

                left_matrix = np.zeros((3, 3))
                right_matrix = np.zeros((3, 1))

                if len(x_list) == len(y_list) == len(z_list):
                    for index in range(len(x_list)):
                        input_matrix = np.zeros((3, 1))
                        output_matrix = np.zeros((1, 1))
                        input_matrix[0][0] = x_list[index]
                        input_matrix[1][0] = y_list[index]
                        input_matrix[2][0] = 1
                        output_matrix[0][0] = z_list[index]
                        left_matrix = left_matrix + plate_chuck_multycalc(input_matrix, np.transpose(input_matrix))
                        right_matrix = right_matrix + plate_chuck_multycalc(output_matrix, input_matrix)
                try:
                    inv_matrix = np.linalg.inv(left_matrix)
                    coef = plate_chuck_multycalc(inv_matrix, right_matrix)
                except:
                    coef = np.zeros((3, 1))
            else:
                graph_pos_df = df['x_data', 'y_data', 'z_data']
                x_list = graph_pos_df['x_data'].drop_duplicates().to_list()
                y_list = graph_pos_df['y_data'].drop_duplicates().to_list()
                z_list = graph_pos_df['z_data'].drop_duplicates().to_list()
                data_len = min(len(x_list), len(y_list), len(z_list))

                left_matrix = np.zeros((6, 6))
                right_matrix = np.zeros((6, 1))

                input_matrix = np.zeros((6, 1))
                output_matrix = np.zeros((6, 1))
                for i in range(data_len):
                    input_matrix[0][0] = pow(x_list[i], 2)
                    input_matrix[1][0] = x_list[i] * y_list[i]
                    input_matrix[2][0] = pow(y_list[i], 2)
                    input_matrix[3][0] = x_list[i]
                    input_matrix[6][0] = y_list[i]
                    input_matrix[5][0] = 1
                    output_matrix[0][0] = z_list[i]
                    left_matrix = np.sum(left_matrix, plate_chuck_multycalc(input_matrix, np.transpose(input_matrix)))
                    right_matrix = np.sum(right_matrix, plate_chuck_multycalc(output_matrix, input_matrix))

                try:
                    inv_matrix = np.linalg.inv(left_matrix)
                    coef = plate_chuck_multycalc(inv_matrix, right_matrix)
                except:
                    coef = np.zeros((data_len, 0))

            result_df = pd.DataFrame(columns=['x_data', 'y_data', 'z_data', 'z_data_org'])
            for y_data in df['y_data'].drop_duplicates().tolist():
                for x_data in df['x_data'].drop_duplicates().tolist():
                    if len(graph_pos_df[(graph_pos_df['x_data'] == x_data) & (graph_pos_df['y_data'] == y_data)]) > 0:
                        data = graph_pos_df[(graph_pos_df['x_data'] == x_data) & (graph_pos_df['y_data'] == y_data)][
                            'z_data'].to_list()[0]
                        result_df = result_df.append(pd.DataFrame.from_dict(
                            {'x_data': [x_data], 'y_data': [y_data], 'z_data': [data], 'z_data_org': [data]}))
                    else:
                        data = 0
                        if direct_h800_enable:
                            data = coef[0][0] * pow(x_data, 2) + \
                                   coef[1][0] * x_data * y_data + \
                                   coef[2][0] * pow(y_data, 2) + \
                                   coef[3][0] * x_data + \
                                   coef[4][0] * y_data + \
                                   coef[5][0]
                        else:
                            d_slope_x = coef[0][0]
                            d_slope_y = coef[1][0]
                            d_intercept = coef[2][0]
                            data = d_slope_x * x_data * 1000 + d_slope_y * y_data * 1000 + d_intercept
                        result_df = result_df.append(pd.DataFrame.from_dict(
                            {'x_data': [x_data], 'y_data': [y_data], 'z_data': [data], 'z_data_org': [pd.NA]}))
            result_df = result_df.sort_values(by=['y_data', 'x_data'], ascending=[False, True]).reset_index(drop=True)
            for key in info_dict.keys():
                result_df[key] = info_dict[key][0]

            # TODO: Predict Data 계산
            x_sum = df['x_data'].sum()
            y_sum = df['y_data'].sum()
            z_sum = df['z_data'].sum()
            x_pow_sum = df['x_data'].apply(lambda x: x ** 2).sum()
            y_pow_sum = df['y_data'].apply(lambda x: x ** 2).sum()
            xy_sum = (df['x_data'] * df['y_data']).sum()
            xz_sum = (df['x_data'] * df['z_data']).sum()
            yz_sum = (df['y_data'] * df['z_data']).sum()
            count = len(df['x_data'])

            predict_left = np.array([[x_pow_sum, xy_sum, x_sum],
                      [xy_sum, y_pow_sum, y_sum],
                      [x_sum, y_sum, count]])

            predict_right = np.array([[xz_sum],
                                      [yz_sum],
                                      [z_sum]])

            predict_left = np.linalg.inv(predict_left)
            predict_ans = np.dot(predict_left, predict_right)
            slope_x = predict_ans[0][0]
            slope_y = predict_ans[1][0]
            intercept = predict_ans[2][0]

            result_df['z_predict_tmp'] = result_df['z_data_org']
            result_df['z_predict_tmp'] -= (slope_x * result_df['x_data']) + (slope_y * result_df['y_data']) + intercept


            # TODO: 2차 연산 시작 angular의 calucate 부분 공통화 작업 필요

            predict_tmp_df = result_df.dropna()
            predict_tmp_df = predict_tmp_df.sort_values(by=['x_data', 'y_data'], ascending=[True, False])

            direct_predict_ans = plate_chuck_predict_calc(predict_tmp_df)

            direct_slope_x = direct_predict_ans[0][0]
            direct_slope_y = direct_predict_ans[1][0]
            direct_intercept = direct_predict_ans[2][0]

            # # TODO: 2차 연산 완료 angular의 calucate 부분 공통화 작업 필요

            result_df['z_predict'] = result_df['z_predict_tmp'].fillna(999999)
            result_na_df = result_df[result_df['z_predict'] == 999999]
            result_df.drop(result_na_df.index, inplace=True)
            result_na_df['z_predict'] = (result_na_df['x_data'] * direct_slope_x) + (result_na_df['y_data'] * direct_slope_y) + direct_intercept
            result_df = pd.concat([result_df, result_na_df])

            result_df['pitch_x'] = 0
            result_df['pitch_y'] = 0
            result_df['plate_chuck_arc_direct_h800'] = direct_h800_enable
            result_df['chuckG86'] = chuck_g86
            result_df['scantype'] = 'direct'
            result_df['filename'] = file.split('_')[-1:][0]
            result_df.to_csv(path, header=True, index=False)

    elif log_name == 'platechuckscan':
        files = os.listdir(root_dir)
        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, keep_default_na=False)
            df = df.astype(column_type[log_name])

            df['data_num'] = df['data_num'].apply(lambda x: int(x, 16)).astype(int)
            df['pitch_x'] = PITCH_X_DATA_ARRAY[df['pitch_x'].drop_duplicates().to_list()[0]]
            df['pitch_y'] = PITCH_Y_DATA_ARRAY[df['pitch_y'].drop_duplicates().to_list()[0]]
            df['plate_size_x'] = int(df['plate_size_x'].drop_duplicates().to_list()[0], 16) / df['plate_size_x_unit']
            df['plate_size_y'] = int(df['plate_size_y'].drop_duplicates().to_list()[0], 16) / df['plate_size_y_unit']
            df['targe_divide_chuck_side'] = df['targe_divide_chuck_side']
            df['the_other_chuck_side_measure_count'] = df['the_other_chuck_side_measure_count']

            df['x_data'] = df['position_x'].apply(lambda x: util.conv_hex_dec_minus(x)) / df['position_x_unit']
            df['y_data'] = df['position_y'].apply(lambda x: util.conv_hex_dec_minus(x)) / df['position_y_unit']
            br_df = df[df['sensor_kind'] == 1]
            br_df['z_data'] = br_df['br_value'].apply(lambda x: util.conv_hex_dec_minus(x)) / df['br_value_unit']
            br_df['pos_x_error'] = True
            bl_df = df[df['sensor_kind'] == 0]
            bl_df['z_data'] = bl_df['bl_value'].apply(lambda x: util.conv_hex_dec_minus(x)) / df['bl_value_unit']
            bl_df['pos_x_error'] = False
            # df = pd.concat([br_df, bl_df]).sort_values(by=['position_y', 'position_x'], ascending=[True, False])
            df = pd.concat([br_df, bl_df]).sort_index()
            # TODO: 데이터 필터링 코드 -> 1차 실장
            df = pd.concat([df, df.index.to_frame(name='cnt') + 1], axis=1)
            df['adjust_data'] = (df['targe_divide_chuck_side'] != 0) & (
                        df['cnt'] > (df['data_num'] - df['the_other_chuck_side_measure_count']))
            df['x_flag'] = (df['x_data'] == 0) & (not zsensor_e813_pos)
            df['z_data'] = df['z_data'].apply(lambda x: pd.NA if (x == 0) | (x == 9999) else x)

            # TODO: 확인 필요
            df.drop(df[df['adjust_data'] == True].index, inplace=True)

            # TODO: 오차 계산에 상용될 data 추출 liplus와 비교 필요
            d_zero_bl = df[(df['x_flag']) & (df['sensor_kind'] == 0) & (df['z_data'] != 99999)]['z_data']
            d_zero_br = df[(df['x_flag']) & (df['sensor_kind'] == 1) & (df['z_data'] != 99999)]['z_data']

            # TODO:오차계산
            d_sensor_error = 0
            if not zsensor_e813_pos:
                # TODO: 1. ERROR_DATA(99999) 제외  -> 데이터 산출 단계에서 처리
                # TODO: Liplus의 경우 d_zero_bl의 길이로 for 문을 동작 시킴, d_zero_br, d_zero_bl의 길이가 다른 경우는 없는건지?
                sensor_count = len(d_zero_bl)
                # TODO: 2. d_sensor_error = d_zero_br - d_zero_bl  -> 1차 실장
                # TODO: 3. d_sensor_error.mean() -> 1차 실장
                d_sensor_error = (d_zero_br.sum() - d_zero_bl.sum()) / sensor_count

            # Xの計測ポイント州を計算（G8.6でサイズがrange overだったらPlate Size2440mmとしてCalcする）
            plate_size_x = df['plate_size_x'].drop_duplicates().to_list()[0]
            pitch_x = df['pitch_x'].drop_duplicates().to_list()[0]
            if chuck_g86 and (plate_size_x > G86MAX_PLATE_SIZE_X + EDGE_INTERVAL * 2):
                count_x = int(G86MAX_PLATE_SIZE_X / 2.0 / pitch_x) * 2 + 3
                edge_interval_x = (G86MAX_PLATE_SIZE_X - pitch_x * (count_x - 3.0)) / 2.0
                if edge_interval_x == 0:
                    x_data_list = df['x_data'].drop_duplicates().to_list().sort()
                    x_start = x_data_list[0]
                    x_end = x_data_list[-1]
                    df.drop(df[(df['x_data'] == x_start) | (df['x_data'] == x_end)].index, inplace=True)

            sensor_error_df = df[(df['z_data'] != pd.NA) & (df['z_data'] != 0) & (df['pos_x_error'])]
            if not zsensor_e813_pos and len(sensor_error_df) != 0:
                df.drop(sensor_error_df.index, inplace=True)
                sensor_error_df['z_data'] -= d_sensor_error
                sensor_error_df.reset_index(drop=True)
                df = pd.concat([df, sensor_error_df])

            df.sort_values(by=['y_data', 'x_data'], ascending=[False, True], inplace=True)
            error_df = df[(df['sensor_kind'] == 1) & (df['x_flag'])]
            df.drop(error_df.index, inplace=True)
            df.reset_index(drop=True)


            # Predict data 計算
            df['z_predict_tmp'] = df['z_data']
            predict_df = df[['x_data', 'y_data', 'z_predict_tmp']]
            predict_df['x_data'] *= 1000
            predict_df['y_data'] *= 1000
            predict_df['z_predict_tmp'] = df['z_predict_tmp'].apply(lambda x: round(x, 3))
            predict_ans = plate_chuck_predict_calc(predict_df)
            slope_x = predict_ans[0]
            slope_y = predict_ans[1]
            intercept = predict_ans[2]

            df['z_predict'] = df['z_data']
            df['z_predict'] = round((df['z_predict'] - (slope_x * df['x_data'] * 1000 + slope_y * df['y_data'] *1000 + intercept)),3)

            df['scantype'] = 'scan'
            df['filename'] = file.split('_')[-1:][0]
            df.drop(columns=['plate_size_x_unit', 'plate_size_y_unit', 'direction', 'targe_divide_chuck_side',
                     'targe_divide_chuck_side_unit', 'the_other_chuck_side_measure_count',
                     'the_other_chuck_side_measure_count_unit', 'position_x', 'position_x_unit', 'position_y',
                     'position_y_unit', 'bl_value', 'bl_value_unit', 'br_value', 'br_value_unit',
                     'pos_x_error', 'cnt', 'adjust_data', 'x_flag', 'sensor_kind', 'z_predict_tmp'], inplace=True)

            df.to_csv(path, header=True, index=False)


    elif log_name == 'platechuckrangescan':
        files = os.listdir(root_dir)
        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, keep_default_na=False)
            df = df.astype(column_type[log_name])
            df['x_data'] = df['position_x'].apply(lambda x: util.conv_hex_dec_minus(x)) / df['position_x_unit']
            df['y_data'] = df['position_x'].apply(lambda x: util.conv_hex_dec_minus(x)) / df['position_y_unit']
            df['z_data'] = (df['value'].apply(lambda x: util.conv_hex_dec_minus(x)) / df['value_unit']).apply(
                lambda x: pd.NA if ((x == 99999) | (x == 0)) else x)
            df = df.drop(
                columns=['position_x', 'position_y', 'value', 'position_x_unit', 'position_y_unit', 'value_unit', ])
            df.sort_values(by=['x_data', 'y_data'], ascending=[True, False], inplace=True)
            df['scantype'] = 'rangescan'
            df['filename'] = file.split('_')[-1:][0]
            df.to_csv(path, header=True, index=False)


def plate_chuck_multycalc(left, right):
    right_row, right_col = right.shape
    left_row, left_col = left.shape

    # 上三角行列作成
    if left_col != right_row:
        if 1 == right_row and 1 == right_col:
            return np.dot(right[0][0], left)
        elif 1 == left_row and 1 == left_col:
            return np.dot(left[0][0], right)
        else:
            return
    else:
        return np.dot(left, right)


def load_platechuck_log(rid, log_list=None, **filters):
    log_dict = dict()

    column_type = {
        'platechuckdirect': {
            "ch_x_unit": int,
            "ch_y_unit": int,
            "height_unit": int
        },
        'platechuckscan': {
            'plate_size_x': str,
            'plate_size_y': str,
            'plate_size_x_unit': int,
            'plate_size_y_unit': int,
            "targe_divide_chuck_side_unit": int,
            "the_other_chuck_side_measure_count_unit": int,
            "sensor_kind": int,
            "position_x_unit": int,
            "position_y_unit": int,
            "bl_value_unit": int,
            "br_value_unit": int
        },
        'platechuckrangescan': {
            "position_x_unit": int,
            "position_y_unit": int,
            "bl_value_unit": int,
            "br_value_unit": int,
        }
    }

    if log_list == None:
        log_list = FOCUS_CHUCK_LOG_LIST

    for log_name in log_list:
        root_dir = os.path.join(os.path.join(os.path.join(CNV_RESULT_PATH, rid), log_name))
        if not os.path.exists(root_dir):
            # log_dict[log_name] = pd.DataFrame()
            continue
        files = os.listdir(root_dir)
        dfs = list()
        file_cnt = 0
        for file in files:
            path = os.path.join(root_dir, file)
            df = pd.read_csv(path, index_col=False, dtype=str)
            df['file_cnt'] = file_cnt
            file_cnt += 1
            dfs.append(df)

        df = pd.DataFrame()
        if len(dfs) > 0:
            df = pd.concat(dfs)

        if 'log_time' in df.columns:
            df['log_time'] = pd.to_datetime(df['log_time'], format='%Y-%m-%d')

        for key, val in filters.items():
            if key == 'log_time':
                if 'log_time' in df.columns:
                    start = filters[key]['start']
                    end = filters[key]['end']
                    try:
                        datetime.datetime.strptime(end, '%Y-%m-%d')
                        end = end + ' 23:59:59'
                    except Exception as e:
                        pass
                    df = df[(start <= df['log_time']) & (df['log_time'] <= end)]
            elif key == 'scantype':
                scan_type = filters[key]
                df = df[df['scantype'] == scan_type]
            elif key == 'filename':
                file_name = filters[key]
                df = df[df['filename'] == file_name]
            else:
                #TODO: 필요 내용인지 검토 필요
                if key not in df.columns:
                    df[key] = None
                df_copy = df.astype({key: str})
                if isinstance(val, list):
                    if len(val) > 0:
                        val = [str(_) for _ in val]
                        df = df[df_copy[key].isin(val)]
                else:
                    df = df[df_copy[key] == str(val)]

        for col in COLUMN_OMIT_LIST:
            if col in df.columns:
                df.drop(col, axis=1, inplace=True)

        if len(df) > 0:
            # 時間順序で整列
            df.sort_values(by='log_time', ascending=True, inplace=True)
            df.reset_index(inplace=True, drop=True)
            log_dict[log_name] = df

    for log_name, types in column_type.items():
        if log_name in log_dict:
            tmp_astype = dict()
            for col, val in types.items():
                if col in log_dict[log_name].columns:
                    tmp_astype[col] = val
            log_dict[log_name] = log_dict[log_name].astype(tmp_astype)

    return log_dict


def plate_chuck_predict_calc(df):


    x_sum = df['x_data'].sum()
    y_sum = df['y_data'].sum()
    z_sum = df['z_predict_tmp'].sum()
    x_pow_sum = df['x_data'].apply(lambda x: x ** 2).sum()
    y_pow_sum = df['y_data'].apply(lambda x: x ** 2).sum()
    xy_sum = (df['x_data'] * df['y_data']).sum()
    xz_sum = (df['x_data'] * df['z_predict_tmp']).sum()
    yz_sum = (df['y_data'] * df['z_predict_tmp']).sum()
    count = len(df['x_data'])

    predict_left = np.array([[x_pow_sum, xy_sum, x_sum],
                                    [xy_sum, y_pow_sum, y_sum],
                                    [x_sum, y_sum, count]])

    predict_right = np.array([[xz_sum],
                                     [yz_sum],
                                     [z_sum]])

    predict_left = np.linalg.inv(predict_left)
    predict_ans = np.dot(predict_left, predict_right)

    return predict_ans