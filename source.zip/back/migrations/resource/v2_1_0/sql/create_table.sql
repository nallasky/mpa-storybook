CREATE TABLE IF NOT EXISTS fab_oasbaseline_cp_vs_preset
(
    id     integer constraint fab_adc_meas_cp_vs_preset_pk primary key autoincrement default 1,
    name   text        not null,
    fab_nm text not NULL constraint fab_adc_meas_cp_vs_preset_fab_nm_fk references fab_fab (fab_nm) on update cascade on delete cascade,
    mode   text        not null
);

CREATE UNIQUE INDEX fab_oasbaseline_cp_vs_preset_id_uindex on fab_adc_meas_cp_vs_preset (id);

CREATE TABLE IF NOT EXISTS fab_oasbaseline_cp_vs_preset_item
(
    preset_id integer  not NULL constraint fab_oasbaseline_cp_vs_preset_item_preset_id_fk references fab_oasbaseline_cp_vs_preset(id) on update cascade on delete cascade,
    shot_no   integer not null,
    back       real,
    front       real,
    vs_back       real,
    vs_front       real,
    display   text
);

CREATE TABLE IF NOT EXISTS settings_func_common
(
    id  integer constraint settings_func_common_pk primary key autoincrement default 1,
    function    text not null,
    name    text not null,
    tab text,
    legend  text,
    property    text,
    value   text
);
CREATE UNIQUE INDEX settings_func_common_uindex on settings_func_common (id);


create table if not exists fab_focus_tolerance
(
    id          INTEGER default 1
        constraint fab_focus_tolerance_pk
            primary key autoincrement,
    fab_nm      TEXT  not null
        references fab_fab
            on update cascade on delete cascade,
    name        TEXT  not null,
    tab         TEXT  not null,
    lower_limit float not null,
    upper_limit float not null
);

create unique index fab_focus_tolerance_uindex
    on fab_focus_tolerance (id);