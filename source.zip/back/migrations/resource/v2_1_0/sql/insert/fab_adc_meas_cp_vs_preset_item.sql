alter table fab_adc_meas_cp_vs_preset_item
	add inside_vs REAL default 0;