UPDATE cnvbase_log_define_master set tag='plateafc' where log_name='PLATEAUTOFOCUSCOMPENSATION';
UPDATE cnvbase_log_define_master set tag='prescancompmon' where log_name='PRESCANCOMPENSATIONMONITOR';