UPDATE cnvbase_convert_rule_item set name='18822', data_type='integer', coef=1000000, unit='mm', skip=0, col_prefix=1 where output_column='inside_p1_xr';
UPDATE cnvbase_convert_rule_item set name='18823', data_type='integer', coef=1000000, unit='mm', skip=0, col_prefix=1 where output_column='inside_p1_yr';
UPDATE cnvbase_convert_rule_item set name='18826', data_type='integer', coef=1000000, unit='mm', skip=0, col_prefix=1 where output_column='inside_p2_xr';
UPDATE cnvbase_convert_rule_item set name='18827', data_type='integer', coef=1000000, unit='mm', skip=0, col_prefix=1 where output_column='inside_p2_yr';
UPDATE cnvbase_convert_rule_item set name='1882A', data_type='integer', coef=1000000, unit='mm', skip=0, col_prefix=1 where output_column='inside_p3_xr';
UPDATE cnvbase_convert_rule_item set name='1882B', data_type='integer', coef=1000000, unit='mm', skip=0, col_prefix=1 where output_column='inside_p3_yr';
UPDATE cnvbase_convert_rule_item set name='24279', data_type='integer', coef=1000000, unit='mm', skip=0, col_prefix=1 where output_column='vs_inside';