UPDATE cnvbase_convert_rule_item set name='18822', data_type='integer', coef=1000, unit='nm', skip=0, col_prefix=1 where output_column='inside_p1_xr';
UPDATE cnvbase_convert_rule_item set name='18823', data_type='integer', coef=1000, unit='nm', skip=0, col_prefix=1 where output_column='inside_p1_yr';
UPDATE cnvbase_convert_rule_item set name='18826', data_type='integer', coef=1000, unit='nm', skip=0, col_prefix=1 where output_column='inside_p2_xr';
UPDATE cnvbase_convert_rule_item set name='18827', data_type='integer', coef=1000, unit='nm', skip=0, col_prefix=1 where output_column='inside_p2_yr';
UPDATE cnvbase_convert_rule_item set name='1882A', data_type='integer', coef=1000, unit='nm', skip=0, col_prefix=1 where output_column='inside_p3_xr';
UPDATE cnvbase_convert_rule_item set name='1882B', data_type='integer', coef=1000, unit='nm', skip=0, col_prefix=1 where output_column='inside_p3_yr';
UPDATE cnvbase_convert_rule_item set output_column='inside_vs', name='24279', data_type='integer', coef=1000000, unit='nm', skip=0, col_prefix=1 where output_column='vs_inside';
UPDATE cnvbase_convert_rule_item set unit='nm' where output_column='vs1';
UPDATE cnvbase_convert_rule_item set unit='nm' where output_column='vs2';
UPDATE cnvbase_convert_rule_item set unit='nm' where output_column='vs3';
UPDATE cnvbase_convert_rule_item set unit='nm' where output_column='cp1';
UPDATE cnvbase_convert_rule_item set unit='nm' where output_column='cp2';
UPDATE cnvbase_convert_rule_item set unit='nm' where output_column='cp3';
UPDATE cnvbase_convert_rule_item as r_i SET output_column='plate'
    FROM cnvbase_convert_rule as r INNER JOIN cnvbase_log_define_master as l ON r.log_id=l.id
    WHERE r_i.rule_id=r.id and l.log_name IN ('PLATEAUTOFOCUSCOMPENSATION', 'PRESCANCOMPENSATIONMONITOR') and r_i.output_column='plate_no';

UPDATE analysis_analysis_items AS a_i SET source_col='plate'
    FROM analysis_function AS f
        INNER JOIN analysis_local_info AS l_i
            ON f.id=l_i.func_id
    WHERE a_i.func_id=f.id and a_i.source_col='plate_no'
        and l_i.log_name in ('PLATEAUTOFOCUSCOMPENSATION', 'PRESCANCOMPENSATIONMONITOR');