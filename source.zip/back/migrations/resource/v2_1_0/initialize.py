import os
import logging
import json

from dao.utils import get_db_config
from convert.sqlite_datasource import Connect
from dao.dao_base import DAOBaseClass
from config import app_config
from dao.dao_function import DAOFunction
from service.resources.service_resources import ResourcesService


logger = logging.getLogger(app_config.LOG)

APP_VERSION = '2.1.0'

INSERT_SQL = 'migrations/resource/v2_1_0/sql/insert'
CREATE_TBL_SQL = 'migrations/resource/v2_1_0/sql/create_table.sql'

def init_db_v2_1_0():
    try:
        dao = DAOBaseClass()
        dao.update(table='settings_information', set={'value': APP_VERSION}, where={'key': 'version'})

    except Exception as e:
        logger.info(str(e))


def create_table():
    try:
        config = get_db_config()

        with Connect(config) as conn:
            conn.cursor.executescript(open(CREATE_TBL_SQL, 'r').read())
    except Exception as e:
        logger.info(str(e))


def insert_data():
    config = get_db_config()
    file_list = {file_name: False for file_name in os.listdir(INSERT_SQL)}

    idx = 0
    loop_cnt = 0
    complete = False
    while not complete:
        if loop_cnt >= 10:
            logger.info('Retry too many times.')
            return
        try:
            with Connect(config) as conn:
                (file_name, value) = list(file_list.items())[idx]

                # Table生成
                if os.path.isdir(os.path.join(INSERT_SQL, file_name)) is False and value is False:
                    file_path = os.path.join(INSERT_SQL, file_name)
                    logger.info(f'trying insert {file_path}')
                    conn.cursor.executescript(open(file_path, 'r', encoding='utf-8').read())
                    logger.info(file_name + ' data insert OK.')

                    file_list[file_name] = True

            if False in file_list.values():
                idx += 1
                if idx == len(list(file_list.items())):
                    idx = 0
                    loop_cnt += 1
                    logger.info('Retry...')
            else:
                complete = True

        except Exception as e:
            logger.info('Initialize Fail')
            logger.info(e)
            idx += 1
            if idx == len(list(file_list.items())):
                idx = 0
                loop_cnt += 1
                logger.info('Retry...')


def import_logs():
    try:
        path = 'migrations/resource/v2_1_0/data/new_logs.json'
        with open(path, 'r') as f:
            log_list = json.load(f)

        dao = DAOBaseClass()

        for log in log_list:
            log_define_master = log.pop('log_define_master')
            convert_rule_list = log.pop('convert_rule')

            resp_form = dao.insert(table='cnvbase.log_define_master', data=log_define_master, rtn_id=True)
            if not resp_form.res:
                logger.info(resp_form.msg)
                return

            log_id = resp_form.data

            for convert_rule in convert_rule_list:
                convert_rule_item_list = convert_rule.pop('convert_rule_item')
                resp_form = dao.insert(table='cnvbase.convert_rule', data={**convert_rule, 'log_id': log_id},
                                       rtn_id=True)
                if not resp_form.res:
                    logger.info(resp_form.msg)
                    return

                rule_id = resp_form.data

                for convert_rule_item in convert_rule_item_list:
                    dao.insert(table='cnvbase.convert_rule_item', data={**convert_rule_item, 'rule_id': rule_id})

    except Exception as e:
        logger.info(str(e))

def import_rules():
    try:
        path = 'migrations/resource/v2_1_0/data/rules.json'
        with open(path, 'r') as f:
            log_list = json.load(f)

        dao = DAOBaseClass()

        for log in log_list:
            log_define_master = log.pop('log_define_master')
            convert_rule_list = log.pop('convert_rule')

            id_dict = dao.fetch_one(table='cnvbase.log_define_master',
                                      args={'select': 'id', 'where': f"log_name='{log_define_master['log_name']}'"})
            if id_dict is None:
                continue

            log_id = id_dict['id']

            for convert_rule in convert_rule_list:
                convert_rule_item_list = convert_rule.pop('convert_rule_item')
                rule_name_dict = dao.fetch_one(table='cnvbase.convert_rule',
                                        args={'select': 'rule_name', 'where': f"rule_name='{convert_rule['rule_name']}' and "
                                                                              f"log_id={log_id}"})
                if rule_name_dict is None:
                    resp_form = dao.insert(table='cnvbase.convert_rule', data={**convert_rule, 'log_id': log_id},
                                           rtn_id=True)
                    if not resp_form.res:
                        logger.info(resp_form.msg)
                        return

                    rule_id = resp_form.data

                    for convert_rule_item in convert_rule_item_list:
                        dao.insert(table='cnvbase.convert_rule_item', data={**convert_rule_item, 'rule_id': rule_id})

    except Exception as e:
        logger.info(str(e))


def import_function():
    try:
        path = 'migrations/resource/v2_1_0/data/functions.json'
        with open(path, 'r', encoding='utf-8') as f:
            func_list = json.load(f)

        dao_func = DAOFunction()
        resources = ResourcesService()

        for function in func_list:
            category = function['category']
            func = function['func']
            convert = function['convert']
            analysis = function['analysis']
            visualization = function['visualization']

            resp_form = dao_func.insert_category_info(category)
            if not resp_form.res:
                logger.info(resp_form.msg)
                return

            category_id = resp_form.data

            resp_form = dao_func.insert_func_info({**func,
                                                   'category_id': category_id,
                                                   'analysis_type': analysis['type']})
            if not resp_form.res:
                logger.info(resp_form.msg)
                return

            func_id = resp_form.data

            if func['source_type'] == 'local':
                resp_form = dao_func.insert_convert_script(convert['script'], func_id=func_id)
                if not resp_form.res:
                    resources.delete_id(func_id=func_id)
                    logger.info(resp_form.msg)
                    return

            resp_form = dao_func.insert_analysis_info(analysis, func_id)
            if not resp_form.res:
                resources.delete_id(func_id=func_id)
                logger.info(resp_form.msg)
                return

            resp_form = dao_func.insert_visual_info(visualization, func_id)
            if not resp_form.res:
                resources.delete_id(func_id=func_id)
                logger.info(resp_form.msg)
                return

        logger.info('function import success')

    except Exception as e:
        logger.info(str(e))
