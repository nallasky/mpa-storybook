import os
from dao import get_dbinfo
import psycopg2 as pg2
import logging
import json
from dao.dao_base import DAOBaseClass
from config import app_config

logger = logging.getLogger(app_config.LOG)

APP_VERSION = '1.4.1'


def init_db_v1_4_1():
    config = get_dbinfo()

    with pg2.connect(**config) as conn:
        conn.autocommit = True
        with conn.cursor() as cur:
            cur.execute(f"update settings.information set value='{APP_VERSION}' where key='version'")


def import_rules():
    try:
        path = 'migrations/resource/v1_4_1/data/rules.json'
        with open(path, 'r') as f:
            log_list = json.load(f)

        dao = DAOBaseClass()

        for log in log_list:
            log_define_master = log.pop('log_define_master')
            convert_rule_list = log.pop('convert_rule')

            id_dict = dao.fetch_one(table='cnvbase.log_define_master',
                                      args={'select': 'id', 'where': f"log_name='{log_define_master['log_name']}'"})
            if id_dict is None:
                continue

            log_id = id_dict['id']

            for convert_rule in convert_rule_list:
                convert_rule_item_list = convert_rule.pop('convert_rule_item')
                rule_name_dict = dao.fetch_one(table='cnvbase.convert_rule',
                                        args={'select': 'rule_name', 'where': f"rule_name='{convert_rule['rule_name']}' and "
                                                                              f"log_id={log_id}"})
                if rule_name_dict is None:
                    resp_form = dao.insert(table='cnvbase.convert_rule', data={**convert_rule, 'log_id': log_id},
                                           rtn_id=True)
                    if not resp_form.res:
                        logger.info(resp_form.msg)
                        return

                    rule_id = resp_form.data

                    for convert_rule_item in convert_rule_item_list:
                        dao.insert(table='cnvbase.convert_rule_item', data={**convert_rule_item, 'rule_id': rule_id})

    except Exception as e:
        logger.info(str(e))
