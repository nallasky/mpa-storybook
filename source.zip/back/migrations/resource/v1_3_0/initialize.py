import os
from dao import get_dbinfo
import psycopg2 as pg2

APP_VERSION = '1.3.0'


def init_db_v1_3_0():
    config = get_dbinfo()

    with pg2.connect(**config) as conn:
        conn.autocommit = True
        with conn.cursor() as cur:
            cur.execute(f"insert into public.analysis_type(type) values('org')")
            cur.execute(f"insert into public.source_type(type) values('multi')")

            sql = '''
            create table analysis.multi_info
            (
                id             serial  not null
                    constraint multi_info_pk
                        primary key,
                func_id        integer not null
                    constraint multi_info_function_id_fk
                        references analysis.function
                        on update cascade on delete cascade,
                sub_func_id    integer not null
                    constraint multi_info_function_id_fk_2
                        references analysis.function
                        on update cascade on delete cascade,
                source_type    text    not null,
                tab_name       text    not null,
                rid            text    not null
                    constraint multi_info_job_id_fk
                        references cnvset.job
                        on update cascade on delete cascade,
                fid            text,
                db_id          integer,
                table_name     text,
                equipment_name text,
                period_start   text,
                period_end     text,
                sql            text
            );
            
            alter table analysis.multi_info
                owner to postgres;
            
            create unique index multi_info_id_uindex
                on analysis.multi_info (id);
            '''
            cur.execute(sql)

            cur.execute(f"update settings.information set value='{APP_VERSION}' where key='version'")



