CREATE TABLE IF NOT EXISTS settings_platechuck_free_layout_preset
(
    id     integer constraint settings_platechuck_free_layout_preset_pk primary key autoincrement default 1,
    name   text        not null
);

CREATE UNIQUE INDEX settings_platechuck_free_layout_preset_id_uindex on settings_platechuck_free_layout_preset (id);

CREATE TABLE IF NOT EXISTS settings_platechuck_free_layout_preset_item
(
    preset_id integer  not NULL constraint settings_platechuck_free_layout_preset_fk references settings_platechuck_free_layout_preset(id) on update cascade on delete cascade,
    shot_no   integer not null,
    x_pos       real,
    y_pos       real,
    width       real,
    height       real
);