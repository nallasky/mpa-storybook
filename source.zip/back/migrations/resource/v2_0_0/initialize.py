import os
import logging
import numpy as np
from sqlalchemy import create_engine

from dao.utils import get_db_config, get_db_config_postgres
from convert.sqlite_datasource import Connect
from dao.dao_base import DAOBaseClass
from dao.dao_base_postgres import DAOBaseClass as PGBaseClass
from migrations.resource.v2_0_0.script.dao_function import DAOFunction
from dao.dao_function import DAOFunction as SQDaoFunction
from config import app_config
from service.tact.service_tact_settings import ServiceTactSettings
from werkzeug.datastructures import FileStorage
from service.resources.service_resources import ResourcesService
from common.utils.cipher import AESCipher


logger = logging.getLogger(app_config.LOG)

APP_VERSION = '2.0.0'

CREATE_TBL_SQL = 'migrations/resource/v2_0_0/sql/create_table.sql'
CREATE_TYPE_SQL = 'migrations/resource/v2_0_0/sql/create_type.sql'
INSERT_SQL = 'migrations/resource/v2_0_0/sql/insert'


def init_db_v2_0_0():
    try:
        config = get_db_config()

        with Connect(config) as conn:
            conn.cursor.executescript(open(CREATE_TYPE_SQL, 'r').read())
            conn.cursor.executescript(open(CREATE_TBL_SQL, 'r').read())

        dao = DAOBaseClass()
        dao.insert(table='settings_information', data={'key': 'version', 'value': APP_VERSION})

    except Exception as e:
        logger.info(str(e))


def insert_data():
    config = get_db_config()
    file_list = {file_name: False for file_name in os.listdir(INSERT_SQL)}

    idx = 0
    loop_cnt = 0
    complete = False
    while not complete:
        if loop_cnt >= 10:
            logger.info('Retry too many times.')
            return
        try:
            with Connect(config) as conn:
                (file_name, value) = list(file_list.items())[idx]

                # Table生成
                if os.path.isdir(os.path.join(INSERT_SQL, file_name)) is False and value is False:
                    file_path = os.path.join(INSERT_SQL, file_name)
                    logger.info(f'trying insert {file_path}')
                    conn.cursor.executescript(open(file_path, 'r', encoding='utf-8').read())
                    logger.info(file_name + ' data insert OK.')

                    file_list[file_name] = True

            if False in file_list.values():
                idx += 1
                if idx == len(list(file_list.items())):
                    idx = 0
                    loop_cnt += 1
                    logger.info('Retry...')
            else:
                complete = True

        except Exception as e:
            logger.info('Initialize Fail')
            logger.info(e)
            idx += 1
            if idx == len(list(file_list.items())):
                idx = 0
                loop_cnt += 1
                logger.info('Retry...')


def import_tact_settings():
    root_dir = 'migrations/resource/v2_0_0/data/tact_settings/'

    files = os.listdir(root_dir)

    service_obj = ServiceTactSettings()

    for file in files:
        table_name = file.split(sep='.')[0]

        try:
            with open(os.path.join(root_dir, file), 'rb') as f:
                buf = FileStorage(f)
                if table_name == 'primary_pu':
                    primary_pu_name = file.split(sep='.')[1]
                    resp_form = service_obj.upload_settings(table_name, [buf], primary_pu_name=primary_pu_name)
                else:
                    resp_form = service_obj.upload_settings(table_name, [buf])
                if not resp_form.res:
                    logger.error(resp_form.msg)
                else:
                    logger.info(f'{table_name} setting table import success.')
        except Exception as e:
            logger.error(str(e))
            logger.error(f'Import Fail While importing {file}!!')


def export_cnvbase_schema(pg_dao):
    log_define_list = list()

    log_define_df = pg_dao.fetch_all(table='cnvbase.log_define_master').replace({np.nan: None})
    rule_df = pg_dao.fetch_all(table='cnvbase.convert_rule').replace({np.nan: None})
    rule_item_df = pg_dao.fetch_all(table='cnvbase.convert_rule_item').replace({np.nan: None})
    filter_df = pg_dao.fetch_all(table='cnvbase.convert_filter').replace({np.nan: None})
    filter_item_df = pg_dao.fetch_all(table='cnvbase.convert_filter_item').replace({np.nan: None})


    for i in range(len(log_define_df)):
        log_id = log_define_df['id'].values[i]

        matches_rule_df = rule_df[rule_df['log_id'] == log_id]
        convert_rule_list = list()
        for j in range(len(matches_rule_df)):
            rule_id = matches_rule_df['id'].values[j]

            matches_item_df = rule_item_df[rule_item_df['rule_id'] == rule_id]
            matches_item_dict = matches_item_df[['coef', 'col_index', 'data_type', 'def_type', 'def_val',
                                                 'name', 'output_column', 'row_index', 'skip', 'type', 'unit']]\
                .to_dict(orient='records')

            tmp_dict = {'convert_rule_item': matches_item_dict,
                        'rule_name': matches_rule_df['rule_name'].values[j],
                        'commit': bool(matches_rule_df['commit'].values[j])}

            convert_rule_list.append(tmp_dict)

        matches_filter_df = filter_df[filter_df['log_id'] == log_id]
        convert_filter_list = list()
        for j in range(len(matches_filter_df)):
            filter_id = matches_filter_df['id'].values[j]

            matches_item_df = filter_item_df[filter_item_df['filter_id'] == filter_id]
            matches_item_dict = matches_item_df[['name', 'type', 'condition']] \
                .to_dict(orient='records')

            tmp_dict = {'convert_filter_item': matches_item_dict,
                        'commit': bool(matches_filter_df['commit'].values[j])}

            convert_filter_list.append(tmp_dict)

        tmp_log_dict = {
            'log_define_master': {
                'input_type': log_define_df['input_type'].values[i],
                'log_name': log_define_df['log_name'].values[i],
                'table_name': log_define_df['table_name'].values[i]
            },
            'convert_rule': convert_rule_list,
            'convert_filter': convert_filter_list
        }

        log_define_list.append(tmp_log_dict)

    return log_define_list


def import_rules(log_list):
    dao = DAOBaseClass()
    for log in log_list:
        log_define_master = log.pop('log_define_master')
        convert_rule_list = log.pop('convert_rule')
        convert_filter_list = log.pop('convert_filter')

        id_dict = dao.fetch_one(table='cnvbase.log_define_master',
                                  args={'select': 'id', 'where': f"log_name='{log_define_master['log_name']}'"})
        if id_dict is None:
            resp_form = dao.insert(table='cnvbase.log_define_master',
                                   data={'log_name':log_define_master['log_name'],
                                         'input_type': log_define_master['input_type'],
                                         'table_name': log_define_master['table_name']},
                                   rtn_id=True)
            if not resp_form.res:
                continue

            log_id = resp_form.data
        else:
            log_id = id_dict['id']

        for convert_rule in convert_rule_list:
            convert_rule_item_list = convert_rule.pop('convert_rule_item')
            rule_name_dict = dao.fetch_one(table='cnvbase.convert_rule',
                                    args={'select': 'rule_name', 'where': f"rule_name='{convert_rule['rule_name']}' and "
                                                                          f"log_id={log_id}"})
            if rule_name_dict is None:
                convert_rule["'commit'"] = convert_rule.pop('commit')
                resp_form = dao.insert(table='cnvbase.convert_rule', data={**convert_rule, 'log_id': log_id},
                                       rtn_id=True)
                if not resp_form.res:
                    logger.info(resp_form.msg)
                    continue

                logger.info(f'{convert_rule["rule_name"]} Rule Inserted.')

                rule_id = resp_form.data

                for convert_rule_item in convert_rule_item_list:
                    dao.insert(table='cnvbase.convert_rule_item', data={**convert_rule_item, 'rule_id': rule_id})

        for convert_filter in convert_filter_list:
            convert_filter_item_list = convert_filter.pop('convert_filter_item')
            filter_dict = dao.fetch_one(table='cnvbase.convert_filter',
                                    args={'where': f"log_id={log_id}"})
            if filter_dict is None:
                convert_filter["'commit'"] = convert_filter.pop('commit')
                resp_form = dao.insert(table='cnvbase.convert_filter', data={**convert_filter, 'log_id': log_id, },
                                       rtn_id=True)
                if not resp_form.res:
                    logger.info(resp_form.msg)
                    continue

                filter_id = resp_form.data

                for convert_filter_item in convert_filter_item_list:
                    dao.insert(table='cnvbase.convert_filter_item', data={**convert_filter_item, 'filter_id': filter_id})


def export_function():

    conf = get_db_config_postgres()
    dao_func = DAOFunction(**conf)
    ret_list = list()

    resp_form = dao_func.connection_check()
    if not resp_form.res:
        return ret_list

    func_df = dao_func.fetch_all(args={'where': 'system_func=false'})
    for i in range(len(func_df)):
        ret_dict = dict()
        func_id = func_df['id'].values[i]

        resp_form = dao_func.get_category_info(func_id)
        if not resp_form.res:
            logger.info(f'get_category_info() : {resp_form.msg}')
            continue

        ret_dict['category'] = resp_form.data

        resp_form = dao_func.get_function_info(func_id)
        if not resp_form.res:
            logger.info(f'get_function_info() : {resp_form.msg}')
            continue

        analysis_type = resp_form.data.pop('analysis_type')
        ret_dict['func'] = resp_form.data

        source_type = resp_form.data['source_type']
        if source_type == 'multi':
            logger.info(f'Not support exporting multi function.')
            continue

        resp_form = dao_func.get_source_info(func_id)
        if not resp_form.res:
            logger.info(f'get_source_info() : {resp_form.msg}')
            continue

        ret_dict['func']['info'] = resp_form.data

        resp_form = dao_func.get_script(table='analysis.preprocess_script', func_id=func_id)
        if not resp_form.res:
            preprocess_script = {'file_name': None, 'use_script': False}
        else:
            preprocess_script = resp_form.data

        ret_dict['func']['script'] = preprocess_script

        ret_dict['convert'] = dict()
        if ret_dict['func']['source_type'] == 'local':
            resp_form = dao_func.get_script(table='analysis.convert_script', func_id=func_id)
            if not resp_form.res:
                convert_script = {'file_name': None, 'use_script': False}
            else:
                convert_script = resp_form.data

            ret_dict['convert']['script'] = convert_script

        analysis_items = list()
        resp_form = dao_func.get_analysis_items_info(func_id)
        if resp_form.res:
            analysis_items = resp_form.data

        ret_dict['analysis'] = dict()
        ret_dict['analysis']['type'] = analysis_type
        ret_dict['analysis']['setting'] = dict()
        ret_dict['analysis']['setting']['items'] = analysis_items

        # 2022.P3 Deleted Filter Setting
        # resp_form = dao_func.get_filter_default_info(func_id)
        # if not resp_form.res:
        #     filter_default = []
        # else:
        #     filter_default = resp_form.data

        filter_default = list()
        ret_dict['analysis']['setting']['filter_default'] = filter_default

        resp_form = dao_func.get_aggregation_default_info(func_id)
        if not resp_form.res:
            aggregation_default = dict()
        else:
            aggregation_default = resp_form.data

        ret_dict['analysis']['setting']['aggregation_default'] = aggregation_default

        resp_form = dao_func.get_script(table='analysis.analysis_script', func_id=func_id)
        if not resp_form.res:
            analysis_script = {'db_id': None, 'sql': None, 'file_name': None, 'use_script': False}
        else:
            analysis_script = resp_form.data

        ret_dict['analysis']['script'] = analysis_script

        resp_form = dao_func.get_function_graph_type(func_id)
        if not resp_form.res:
            continue

        ret_dict['visualization'] = dict()
        ret_dict['visualization']['function_graph_type'] = resp_form.data

        resp_form = dao_func.get_visualization_default_info(func_id)
        if not resp_form.res:
            items = []
        else:
            items = resp_form.data

        ret_dict['visualization']['items'] = items

        ret_list.append(ret_dict)

    return ret_list


def import_function(func_list):
    try:
        dao_func = SQDaoFunction()
        resources = ResourcesService()

        for function in func_list:
            category = function['category']
            func = function['func']
            convert = function['convert']
            analysis = function['analysis']
            visualization = function['visualization']

            resp_form = dao_func.insert_category_info(category)
            if not resp_form.res:
                continue

            category_id = resp_form.data

            resp_form = dao_func.insert_func_info({**func,
                                                   'category_id': category_id,
                                                   'analysis_type': analysis['type']})
            if not resp_form.res:
                continue

            func_id = resp_form.data

            if func['source_type'] == 'local':
                resp_form = dao_func.insert_convert_script(convert['script'], func_id=func_id)
                if not resp_form.res:
                    resources.delete_id(func_id=func_id)
                    continue

            resp_form = dao_func.insert_analysis_info(analysis, func_id)
            if not resp_form.res:
                resources.delete_id(func_id=func_id)
                continue

            resp_form = dao_func.insert_visual_info(visualization, func_id)
            if not resp_form.res:
                resources.delete_id(func_id=func_id)
                continue

            logger.info(f'{func["title"]} is Added')

    except Exception as e:
        logger.error(str(e))


def export_import_overlay_settings(pg_dao, sqlite_engine):
    # fab_dict = dict()
    #
    # fab_dict['fab'] = pg_dao.fetch_all(table='fab.fab')
    # fab_dict['adc_meas_cp_vs_preset'] = pg_dao.fetch_all(table='fab.adc_meas_cp_vs_preset')
    # fab_dict['adc_meas_cp_vs_preset_item'] = pg_dao.fetch_all(table='fab.adc_meas_cp_vs_preset_item')
    # fab_dict['correction_component_setting'] = pg_dao.fetch_all(table='fab.correction_component_setting')
    # fab_dict['correction_cp_vs_preset'] = pg_dao.fetch_all(table='fab.correction_cp_vs_preset')
    # fab_dict['correction_cp_vs_preset_item'] = pg_dao.fetch_all(table='fab.correction_cp_vs_preset_item')
    #
    # return fab_dict
    table_list = ['fab.fab', 'fab.adc_meas_cp_vs_preset', 'fab.adc_meas_cp_vs_preset_item',
                  'fab.correction_cp_vs_preset', 'fab.correction_cp_vs_preset_item', 'fab.correction_component_setting']

    for table in table_list:
        df = pg_dao.fetch_all(table=table)
        df.to_sql(table.replace('.', '_'), sqlite_engine, if_exists='append', index=False)


def import_overlay_settings(fab_dict):

    if len(fab_dict) == 0:
        return

    if len(fab_dict['fab']) == 0:
        return

    dao_base = DAOBaseClass()

    fab_df = fab_dict['fab'].astype({'plate_size_x': int, 'plate_size_y': int})
    adc_preset_df = fab_dict['adc_meas_cp_vs_preset']
    adc_preset_item_df = fab_dict['adc_meas_cp_vs_preset_item']
    corr_comp_df = fab_dict['correction_component_setting']
    corr_preset_df = fab_dict['correction_cp_vs_preset']
    corr_preset_item_df = fab_dict['correction_cp_vs_preset_item']

    for fab_nm in fab_df['fab_nm'].unique():
        target_fab_df = fab_df[fab_df['fab_nm'] == fab_nm]
        data = dict()
        data['fab_nm'] = target_fab_df['fab_nm'].values[0]
        data['plate_size_x'] = int(target_fab_df['plate_size_x'].values[0])
        data['plate_size_y'] = int(target_fab_df['plate_size_y'].values[0])
        data['div_upper'] = target_fab_df['div_upper'].values[0]
        data['div_lower'] = target_fab_df['div_lower'].values[0]

        dao_base.insert(table='fab_fab', data=data)
        target_preset_df = adc_preset_df[adc_preset_df['fab_nm'] == fab_nm]
        for i in range(len(target_preset_df)):
            data = target_preset_df.iloc[i].to_dict()
            preset_id = data.pop('id')
            target_preset_item_df = adc_preset_item_df[adc_preset_item_df['preset_id'] == preset_id]

            resp_form = dao_base.insert(table='fab_adc_meas_cp_vs_preset', data=data, rtn_id=True)
            if not resp_form.res:
                logger.error(resp_form.msg)
                return
            new_preset_id = resp_form.data
            for j in range(len(target_preset_item_df)):
                data_dict = target_preset_item_df.iloc[j].to_dict()
                data_dict['preset_id'] = new_preset_id
                data_dict['shot_no'] = int(data_dict['shot_no'])
                dao_base.insert(table='fab_adc_meas_cp_vs_preset_item', data=data_dict)

        target_preset_df = corr_preset_df[corr_preset_df['fab_nm'] == fab_nm]
        for i in range(len(target_preset_df)):
            data = target_preset_df.iloc[i].to_dict()
            preset_id = data.pop('id')
            target_preset_item_df = corr_preset_item_df[corr_preset_item_df['preset_id'] == preset_id]
            resp_form = dao_base.insert(table='fab_correction_cp_vs_preset', data=data,
                                            rtn_id=True)
            if not resp_form.res:
                logger.error(resp_form.msg)
                return
            new_preset_id = resp_form.data
            for j in range(len(target_preset_item_df)):
                data_dict = target_preset_item_df.iloc[j].to_dict()
                data_dict['preset_id'] = new_preset_id
                data_dict['shot_no'] = int(data_dict['shot_no'])
                data_dict['cp1_chk'] = int(data_dict['cp1_chk'])
                data_dict['cp12d_chk'] = int(data_dict['cp12d_chk'])
                data_dict['cp1d_chk'] = int(data_dict['cp1d_chk'])
                data_dict['cp21d_chk'] = int(data_dict['cp21d_chk'])
                data_dict['cp2_chk'] = int(data_dict['cp2_chk'])
                data_dict['cp23d_chk'] = int(data_dict['cp23d_chk'])
                data_dict['cp3d_chk'] = int(data_dict['cp3d_chk'])
                data_dict['cp32d_chk'] = int(data_dict['cp32d_chk'])
                data_dict['cp3_chk'] = int(data_dict['cp3_chk'])
                data_dict['vs1l_chk'] = int(data_dict['vs1l_chk'])
                data_dict['vs2l_chk'] = int(data_dict['vs2l_chk'])
                data_dict['vs3l_chk'] = int(data_dict['vs3l_chk'])
                data_dict['vs4l_chk'] = int(data_dict['vs4l_chk'])
                data_dict['vsc_chk'] = int(data_dict['vsc_chk'])
                data_dict['vs4r_chk'] = int(data_dict['vs4r_chk'])
                data_dict['vs3r_chk'] = int(data_dict['vs3r_chk'])
                data_dict['vs2r_chk'] = int(data_dict['vs2r_chk'])
                data_dict['vs1r_chk'] = int(data_dict['vs1r_chk'])
                dao_base.insert(table='fab_correction_cp_vs_preset_item', data=data_dict)

        target_df = corr_comp_df[corr_comp_df['fab_nm'] == fab_nm]
        for i in range(len(target_df)):
            data_dict = target_df.iloc[i].to_dict()
            data_dict['val'] = int(data_dict['val'])
            dao_base.insert(table='fab_correction_component_setting', data=data_dict)


def export_mgmt_setting(pg_dao):
    mgmt_list = list()

    df = pg_dao.fetch_all(table='settings.management_setting', args={'where': "target='remote'"})
    df = df.replace({np.nan: None})
    for i in range(len(df)):
        item = dict()
        item['target'] = df['target'].values[i]
        item['host'] = df['host'].values[i]
        item['username'] = df['username'].values[i]
        item['password'] = df['password'].values[i]
        item['dbname'] = df['dbname'].values[i]
        item['port'] = df['port'].values[i]
        item['name'] = df['name'].values[i]
        mgmt_list.append(item)

    return mgmt_list


def import_mgmt_setting(mgmt_list):
    dao_base = DAOBaseClass()

    for item in mgmt_list:
        aes = AESCipher(app_config.APP_KEY)
        item['password'] = aes.encrypt(str(item['password']))
        dao_base.insert(table='settings.management_setting', data=item)


def export_import_tact_setting(pg_dao, sqlite_engine):

    table_list = ['tact.primary_pu', 'tact.primary_pu_item', 'tact.ref_pu', 'tact.plate_tact', 'tact.plate_detail_tact',
                  'tact.plate_tact_event', 'tact.name_dat']

    for table in table_list:
        df = pg_dao.fetch_all(table=table)
        df.to_sql(table.replace('.', '_'), sqlite_engine, if_exists='append', index=False)


def migration_postgres():
    if check_version():
        try:
            conf = get_db_config_postgres()
            dao = PGBaseClass(**conf)
            resp_form = dao.connection_check()
            if not resp_form.res:
                return False

            config = get_db_config()
            engine = create_engine(f"sqlite:///{config['dbpath']}")

            log_list = export_cnvbase_schema(dao)
            import_rules(log_list)

            func_list = export_function()
            import_function(func_list)

            export_import_overlay_settings(dao, engine)

            mgmt_list = export_mgmt_setting(dao)
            import_mgmt_setting(mgmt_list)

            export_import_tact_setting(dao, engine)

            return True
        except Exception as e:
            logger.error(str(e))

    return False


def check_version():
    try:
        conf = get_db_config_postgres()
        dao_base = PGBaseClass(**conf)
        resp_form = dao_base.connection_check()
        if resp_form.res:
            row = dao_base.fetch_one(table='settings.information', args={'select': 'value', 'where': f"key='version'"})
            if row is None:
                return False
            else:
                [major, minor, revision] = row['value'].split(sep='.')
                if int(minor) >= 4:
                    return True
                else:
                    return False
        else:
            return False
    except Exception as e:
        logger.error(str(e))
        return False
