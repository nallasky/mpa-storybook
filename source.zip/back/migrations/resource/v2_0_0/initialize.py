import os
import logging

from dao.utils import get_db_config
from convert.sqlite_datasource import Connect
from dao.dao_base import DAOBaseClass
from config import app_config
from service.tact.service_tact_settings import ServiceTactSettings
from werkzeug.datastructures import FileStorage


logger = logging.getLogger(app_config.LOG)

APP_VERSION = '2.0.0'

CREATE_TBL_SQL = 'migrations/resource/v2_0_0/sql/create_table.sql'
CREATE_TYPE_SQL = 'migrations/resource/v2_0_0/sql/create_type.sql'
INSERT_SQL = 'migrations/resource/v2_0_0/sql/insert'


def init_db_v2_0_0():
    try:
        config = get_db_config()

        with Connect(config) as conn:
            conn.cursor.executescript(open(CREATE_TYPE_SQL, 'r').read())
            conn.cursor.executescript(open(CREATE_TBL_SQL, 'r').read())

        dao = DAOBaseClass()
        dao.insert(table='settings_information', data={'key': 'version', 'value': APP_VERSION})

    except Exception as e:
        logger.info(str(e))


def insert_data():
    config = get_db_config()
    file_list = {file_name: False for file_name in os.listdir(INSERT_SQL)}

    idx = 0
    loop_cnt = 0
    complete = False
    while not complete:
        if loop_cnt >= 5:
            logger.info('Retry too many times.')
            return
        try:
            with Connect(config) as conn:
                (file_name, value) = list(file_list.items())[idx]

                # Table生成
                if os.path.isdir(os.path.join(INSERT_SQL, file_name)) is False and value is False:
                    file_path = os.path.join(INSERT_SQL, file_name)
                    logger.info(f'trying insert {file_path}')
                    conn.cursor.executescript(open(file_path, 'r', encoding='utf-8').read())
                    logger.info(file_name + ' data insert OK.')

                    file_list[file_name] = True

            if False in file_list.values():
                idx += 1
                if idx == len(list(file_list.items())):
                    idx = 0
                    loop_cnt += 1
                    logger.info('Retry...')
            else:
                complete = True

        except Exception as e:
            logger.info('Initialize Fail')
            logger.info(e)
            idx += 1
            if idx == len(list(file_list.items())):
                idx = 0
                loop_cnt += 1
                logger.info('Retry...')


def import_tact_settings():
    root_dir = 'migrations/resource/v2_0_0/data/tact_settings/'

    files = os.listdir(root_dir)

    service_obj = ServiceTactSettings()

    for file in files:
        table_name = file.split(sep='.')[0]

        try:
            with open(os.path.join(root_dir, file), 'rb') as f:
                buf = FileStorage(f)
                if table_name == 'primary_pu':
                    primary_pu_name = file.split(sep='.')[1]
                    resp_form = service_obj.upload_settings(table_name, [buf], primary_pu_name=primary_pu_name)
                else:
                    resp_form = service_obj.upload_settings(table_name, [buf])
                if not resp_form.res:
                    logger.error(resp_form.msg)
                else:
                    logger.info(f'{table_name} setting table import success.')
        except Exception as e:
            logger.error(str(e))
            logger.error(f'Import Fail While importing {file}!!')