create table analysis_aggregation_default
(
    id		integer constraint analysis_aggregation_default_pk primary key autoincrement default 1,
    func_id integer not null constraint analysis_aggregation_default_function_id_fk references analysis_function on update cascade on delete cascade,
    type  text not null,
    val     text
);

create table analysis_analysis_items
(
    id          		integer constraint analysis_analysis_items_pk primary key autoincrement default 1,
    func_id				integer not null constraint analysis_analysis_items_function_id_fk references analysis_function on update cascade on delete cascade,
    source_col          text    not null,
    group_analysis      text    not null,
    total_analysis      text,
    group_analysis_type text    not null,
    total_analysis_type text,
    disp_order          integer not null,
    title               text    not null
);

create table analysis_category
(
    id		integer constraint analysis_category_pk primary key autoincrement default 1,
    title	text not null
);
create unique index analysis_category_id_uindex on analysis_category (id);
create unique index analysis_category_title_uindex on analysis_category (title);

--   # 2022.P3 Deleted Filter Setting
--create table analysis_filter_default
--(
--    id		integer constraint analysis_filter_default_pk primary key autoincrement default 1,
--    func_id integer not null constraint analysis_filter_default_function_id_fk references analysis_function on update cascade on delete cascade,
--    key	text    not null,
--    val     text
--);

create table analysis_function
(
    id          integer constraint analysis_function_pk primary key autoincrement default 1,
    category_id integer not null constraint analysis_function_category_id_fk references analysis_category on update cascade on delete cascade,
    title       text not null,
    source_type text not null constraint function_source_type_fk references public_source_type (type) on update cascade on delete cascade,
  	analysis_type text not null constraint analysis_function_analysis_type_fk	references public_analysis_type (type) on update cascade on delete cascade,
  	system_func integer default 0 not null
);
create unique index analysis_function_id_uindex on analysis_function (id);

create table analysis_visualization_default
(
    id          integer constraint analysis_visualization_default_pk primary key autoincrement default 1,
    func_id     integer not null constraint analysis_visualization_default_function_id_fk references analysis_function(id) on update cascade on delete cascade,
    title       text not null,
    type      text not null,
    x_axis		text,
    y_axis      text not null,
    z_axis      text,
    x_range_max text,
    x_range_min text,
    y_range_max text,
    y_range_min text,
    z_range_max text,
    z_range_min text
);

create table cnvset_file
(
    id       integer constraint cnvset_file_pk primary key autoincrement default 1,
    filename text not null,
    path   text not null,
    created  text default (STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW', 'localtime')) not null
);

create unique index cnvset_file_id_uindex
    on cnvset_file (id);

create table cnvset_job
(
    id              text not null  constraint cnvset_job_pk primary key,
    file            text not null,
    equipment_names text,
    start         text not null,
    status          text not null constraint cnvset_job_status_fk references public_request_status(status) on update cascade on delete cascade default 'idle',
    log_name        text,
    job_type        text not null constraint cnvset_job_job_type_fk references public_request_type(type) on update cascade on delete cascade,
    rapid_info      text,
    site            text
);
create unique index cnvset_job_id_uindex on cnvset_job (id);

create table cnvset_working_log_status
(
    status text not null constraint cnvset_working_log_status_pk primary key
);
create unique index cnvset_working_log_status_status_uindex on cnvset_working_log_status (status);

create table cnvset_working_logs
(
    id              integer constraint cnvset_working_logs_pk  primary key autoincrement default 1,
    job_id          text not null   constraint cnvset_working_logs_job_id_fk references cnvset_job on update cascade on delete cascade,
    log_name        text not null,
    file            text not null,
    status          text not null   constraint cnvset_working_logs_working_log_status_status_fk references cnvset_working_log_status on update cascade on delete cascade,
    equipment_names text,
    no            integer not null default 0,
    insert_rows     integer default 0,
    reserved        text
);
create unique index cnvset_working_logs_id_uindex on cnvset_working_logs (id);

create table cnvset_rapid_job_history
(
    id      	integer constraint cnvset_rapid_job_history_pk primary key autoincrement default 1,
    type    	text not null,
    result 	text not null,
    created 	text default (STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW', 'localtime')) not null,
    log     	text
);

create unique index cnvset_rapid_job_history_id_uindex on cnvset_rapid_job_history (id);

create table cnvset_rapid_collector_config
(
    id             	integer constraint cnvset_rapid_collector_config_pk primary key autoincrement default 1,
    addr           	text not null,
    port           	integer default 80,
    username       	text not null,
    pass           	text not null,
    plans          	text not null,
    convert_history integer default null constraint cnvset_rapid_collector_config_and_history_fk1 references cnvset_rapid_job_history(id) on update cascade on delete set default,
    summary_history integer default null constraint cnvset_rapid_collector_config_and_history_fk2 references cnvset_rapid_job_history(id) on update cascade on delete set default,
    cras_history    integer default null constraint cnvset_rapid_collector_config_and_history_fk3 references cnvset_rapid_job_history(id) on update cascade on delete set default,
    version_history integer default null constraint cnvset_rapid_collector_config_and_history_fk4 references cnvset_rapid_job_history(id) on update cascade on delete set default
);

create unique index cnvset_rapid_collector_config_id_uindex on cnvset_rapid_collector_config (id);

create table history_aggregation_history
(
    history_id integer not null constraint history_aggregation_history_history_id_fk references history_history(id) on update cascade on delete cascade,
    type     text not null,
    val        text
);

create table history_filter_history
(
    history_id  integer not null constraint filter_history_history_id_fk references history_history(id) on update cascade on delete cascade,
    key 		text not null,
    val       	text
);

create table history_history
(
    id           integer constraint history_history_pk primary key autoincrement default 1,
    func_id      integer   not null constraint history_history_function_id_fk references analysis_function(id) on update cascade on delete cascade,
    period_start text not null,
    period_end   text,
    source     text not null,
    title        text not null
);
create unique index history_history_title_uindex on history_history (title);

create table history_history_from_local
(
    history_id integer not null constraint history_history_from_local_history_id_fk references history_history(id) on update cascade on delete cascade,
    rid        text    not null
);

create table history_history_from_remote
(
    history_id     	integer not null constraint history_history_from_remote_history_id_fk references history_history(id) on update cascade on delete cascade,
    equipment_name 	text    not null,
    rid        	   	text    not null,
    db_id 			integer not null,
    time_column     text default 'log_time' not null
);

create table history_visualization_history
(
    history_id  integer not null constraint history_visualization_history_history_id_fk references history_history(id) on update cascade on delete cascade,
    title       text not null,
    type      text not null,
    x_axis      text not null,
    y_axis      text not null,
    z_axis      text,
    x_range_max text,
    x_range_min text,
    y_range_max text,
    y_range_min text,
    z_range_max text,
    z_range_min text
);

create table settings_information
(
    key text not null constraint settings_information_pk primary key,
    value text
);

create table settings_management_setting
(
    target   text not null,
    host     text not null,
    username text not null,
    password text not null,
    dbname   text not null,
    port     text not null,
    name     text,
    id     integer  constraint settings_management_setting_pk primary key autoincrement default 1
);
create unique index settings_management_setting_id_uindex  on settings_management_setting (id);



create table cnvbase_convert_error
(
    id     		integer  constraint convert_error_pk primary key autoincrement default 1,
    log_id 		integer not null constraint cnvbase_convert_error_log_id_fk references cnvbase_log_define_master(id) on delete cascade,
    file   		text    not null,
    row   	integer,
    msg    		text default '',
    created 	text default (STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW', 'localtime'))
);

create table cnvbase_convert_filter
(
    id      integer constraint cnvbase_convert_filter_pk primary key autoincrement default 1,
    log_id  integer not null constraint cnvbase_convert_filter_log_id_fk references cnvbase_log_define_master(id) on delete cascade,
    'commit'    integer   default 0 not null
);

create table cnvbase_convert_filter_item
(
    id          	integer constraint cnvbase_convert_filter_item_pk   primary key autoincrement default 1,
    name       		text not null,
    filter_id   	integer not null constraint cnvbase_convert_filter_item_filter_id_fk references cnvbase_convert_filter(id) on delete cascade,
    type			text not null,
    condition		text
);


create table cnvbase_convert_rule
(
    id        integer  constraint cnvbase_convert_rule_pk primary key autoincrement default 1,
    log_id    integer not null constraint cnvbase_convert_rule_log_id_fk references cnvbase_log_define_master(id) on delete cascade,
    rule_name text not null,
    created   text default (STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW', 'localtime')),
    modified  text default (STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW', 'localtime')),
    'commit'  integer default 0 not null
);

create table cnvbase_convert_rule_item
(
    id            integer constraint cnvbase_column_convert_rule_pk primary key autoincrement default 1,
    rule_id       integer not null constraint cnvbase_convert_rule_item_rule_id_fk references cnvbase_convert_rule(id) on delete cascade ,
    type        text,
    row_index     integer,
    col_index     integer,
    name          text not null,
    output_column text default '',
    data_type     text not null,
    coef          real,
    def_val       text,
    def_type      text,
    unit          text,
    prefix        text,
    regex         text,
    re_group      integer default 0,
    skip		  integer default 0
    
);

create table cnvbase_information
(
    key   text not null constraint cnvbase_information_pk primary key,
    value   text not null
);

create table cnvbase_log_define_master
(
    id         integer  constraint cnvbase_log_define_pk primary key autoincrement default 1,
    log_name   text not null,
    input_type text default '' ,
    table_name text,
    fab        text not null default'',
    tag        text not null default '',
    ignore text default '' not null,
   	retention integer default 0 not null
);

create unique index cnvbase_log_define_master_log_name_uindex on cnvbase_log_define_master (log_name);

create table analysis_analysis_script
(
    id             integer constraint analysis_analysis_script_pk primary key autoincrement default 1,
    func_id        integer not null constraint analysis_analysis_script_function_id_fk references analysis_function(id) on update cascade on delete cascade,
    file_name      text,
    use_script     integer default 1 not null,
    script         text,
    db_id          integer,
    sql          text
);

create unique index analysis_analysis_script_id_uindex on analysis_analysis_script (id);

create table analysis_convert_script
(
    id             integer constraint analysis_convert_script_pk primary key autoincrement default 1,
    func_id        integer not null constraint analysis_convert_script_function_id_fk references analysis_function(id) on update cascade on delete cascade,
    file_name      text,
    use_script     integer default 1 not null,
    script         text
);

create unique index analysis_convert_script_id_uindex on analysis_convert_script (id);

create table analysis_local_info
(
    id       integer constraint analysis_local_info_pk primary key autoincrement default 1,
    func_id  integer not null constraint analysis_local_info_function_id_fk references analysis_function(id) on update cascade on delete cascade,
    log_name text    not null
);

create unique index analysis_local_info_id_uindex on analysis_local_info (id);

   create table analysis_preprocess_script
(
    id             integer constraint analysis_preprocess_script_pk primary key autoincrement default 1,
    func_id        integer not null constraint analysis_preprocess_script_function_id_fk references analysis_function(id) on update cascade on delete cascade,
    file_name      text,
    use_script     integer default 1 not null,
    script         text
);

create unique index analysis_preprocess_script_id_uindex on analysis_preprocess_script (id);

create table analysis_remote_info
(
    id             integer constraint analysis_remote_info_pk primary key autoincrement default 1,
    func_id        integer not null constraint analysis_remote_info_function_id_fk references analysis_function(id) on update cascade on delete cascade,
    db_id          integer not null,
    table_name     text    not null,
    equipment_name text    not null,
    period_start   text    not null,
    period_end     text    not null,
    time_column    text default 'log_time' not null
);

create unique index analysis_remote_info_id_uindex on analysis_remote_info (id);
   
create table analysis_sql_info
(
    id      integer constraint analysis_sql_info_pk primary key autoincrement default 1,
    func_id integer not null constraint analysis_sql_info_function_id_fk references analysis_function(id) on update cascade on delete cascade,
    db_id   integer not null,
    sql     text    not null
);

create unique index analysis_sql_info_id_uindex on analysis_sql_info (id);

create table graph_function_graph_type
(
    id             integer constraint graph_custom_graph_type_pk primary key autoincrement default 1,
    func_id        integer not null constraint graph_custom_graph_type_function_id_fk references analysis_function(id) on update cascade on delete cascade,
    name           text    not null,
    script         text    not null,
    type           text    not null
);

create unique index graph_custom_graph_type_id_uindex on graph_function_graph_type (id);

   create table graph_system_graph_type
(
    id             integer constraint graph_system_graph_type_pk primary key autoincrement default 1,
    name           text   not null,
    script         text   not null
);

create unique index graph_system_graph_type_id_uindex on graph_system_graph_type (id);
   
   create table history_history_from_sql
(
    history_id integer not null constraint history_history_from_sql_history_id_fk references history_history(id) on update cascade on delete cascade,
    db_id      integer not null,
    rid        text    not null,
    sql        text    not null
);
   
create table migration_alembic_version
(
	version_num text not null constraint migration_alembic_version_pk primary key
);
   
create table if not exists analysis_multi_info
(
    id             integer constraint analysis_multi_info_pk primary key autoincrement default 1,
    func_id        integer not null constraint analysis_multi_info_function_id_fk references analysis_function(id) on update cascade on delete cascade,
    sub_func_id    integer not null constraint analysis_multi_info_function_id_fk_2 references analysis_function(id) on update cascade on delete cascade,
    source_type    text    not null,
    tab_name       text    not null,
    rid            text    not null constraint analysis_multi_info_job_id_fk references cnvset_job(id) on update cascade on delete cascade,
    fid            text,
    db_id          integer,
    table_name     text,
    equipment_name text,
    period_start   text,
    period_end     text,
    sql            text,
    time_column    text
);
            
create unique index if not exists analysis_multi_info_id_uindex on analysis_multi_info (id);

create table if not exists fab_fab
(
    fab_nm       text not NULL constraint fab_fab_pk primary key,
    plate_size_x smallint    not null,
    plate_size_y smallint    not null,
    div_upper    real,
    div_lower    real
);
            
create unique index if not exists fab_fab_fab_nm_uindex on fab_fab (fab_nm);
    
create table if not exists fab_adc_meas_cp_vs_preset
(
    id     integer constraint fab_adc_meas_cp_vs_preset_pk primary key autoincrement default 1,
    name   text        not null,
    fab_nm text not NULL constraint fab_adc_meas_cp_vs_preset_fab_nm_fk references fab_fab (fab_nm) on update cascade on delete cascade,
    mode   text        not null
);

create unique index if not exists fab_adc_meas_cp_vs_preset_id_uindex on fab_adc_meas_cp_vs_preset (id);
                
create table if not exists fab_adc_meas_cp_vs_preset_item
(
    preset_id integer  not NULL constraint fab_adc_meas_cp_vs_preset_item_preset_id_fk references fab_adc_meas_cp_vs_preset(id) on update cascade on delete cascade,
    shot_no   smallint not null,
    cp1       real,
    cp2       real,
    cp3       real,
    vs1       real,
    vs2       real,
    vs3       real,
    display   text
);
                      
create table if not exists fab_correction_component_setting
(
    fab_nm   text not null constraint fab_correction_component_setting_fab_nm_fk references fab_fab(fab_nm) on update cascade on delete cascade,
    category text        not null,
    setting  text        not null,
    item     text        not null,
    val      integer     default 1 not null
);

create table if not exists fab_correction_cp_vs_preset
(
    id     integer constraint fab_correction_cp_vs_preset_pk primary key autoincrement default 1,
    name   text        not null,
    fab_nm text not NULL constraint fab_correction_cp_vs_preset_fab_nm_fk  references fab_fab(fab_nm) on update cascade on delete cascade,
    mode   text        not null
);
            
create table if not exists fab_correction_cp_vs_preset_item
(
    preset_id integer  not null constraint fab_correction_cp_vs_preset_item_preset_id_fk references fab_correction_cp_vs_preset(id) on update cascade on delete cascade,
    shot_no   smallint not null,
    cpmode    text,
    cp1       real,
    cp12d     real,
    cp1d      real,
    cp21d     real,
    cp2       real,
    cp23d     real,
    cp3d      real,
    cp32d     real,
    cp3       real,
    vsmode    text,
    vs1l      real,
    vs2l      real,
    vs3l      real,
    vs4l      real,
    vsc       real,
    vs4r      real,
    vs3r      real,
    vs2r      real,
    vs1r      real,
    cp1_chk   integer default 1 not null,
    cp12d_chk integer default 1 not null,
    cp1d_chk  integer default 1 not null,
    cp21d_chk integer default 1 not null,
    cp2_chk   integer default 1 not null,
    cp23d_chk integer default 1 not null,
    cp3d_chk  integer default 1 not null,
    cp32d_chk integer default 1 not null,
    cp3_chk   integer default 1 not null,
    vs1l_chk  integer default 1 not null,
    vs2l_chk  integer default 1 not null,
    vs3l_chk  integer default 1 not null,
    vs4l_chk  integer default 1 not null,
    vsc_chk   integer default 1 not null,
    vs4r_chk  integer default 1 not null,
    vs3r_chk  integer default 1 not null,
    vs2r_chk  integer default 1 not null,
    vs1r_chk  integer default 1 not null
);
            
create table if not exists history_history_from_multi
(
    history_id     integer not null constraint history_history_from_multi_history_id_fk references history_history(id) on update cascade on delete cascade,
    sub_func_id    integer not null constraint history_history_from_multi_sub_func_id_fk references analysis_function(id) on update cascade on delete cascade,
    source_type    text    not null,
    tab_name       text    not null,
    rid            text    not null,
    fid            text,
    db_id          integer,
    table_name     text,
    equipment_name text,
    period_start   text,
    period_end     text,
    sql          text,
    time_column    text
);
           
create table if not exists tact_name_dat
(
    id   integer constraint tact_name_dat_pk primary key autoincrement default 1,
    puid text  not null,
    name text not null
);
    
create unique index if not exists tact_name_dat_id_uindex on tact_name_dat (id);
                                
                
create table if not exists tact_plate_detail_tact
(
    id             integer constraint tact_plate_detail_tact_pk primary key autoincrement default 1,
    event          text         not null,
    event_start    text         not null,
    event_end      text         not null,
    category	   text         not null,
    display        integer default 1 not null
);
                
create unique index if not exists tact_plate_detail_tact_id_uindex on tact_plate_detail_tact (id);
              

create table if not exists tact_plate_tact
(
    id             integer constraint tact_plate_tact_pk primary key autoincrement default 1,                    
    category text not null,                       
    display_order  integer      not null
);
                               
create unique index if not exists tact_plate_tact_id_uindex on tact_plate_tact (id);
                
                
create table if not exists tact_plate_tact_event
(
    id    integer constraint tact_plate_tact_event_pk primary key autoincrement default 1,
    event_kind text not null
);
                
create unique index if not exists tact_plate_tact_event_id_uindex on tact_plate_tact_event (id);
                
                
create table if not exists tact_primary_pu
(
    id      integer constraint tact_primary_pu_pk primary key autoincrement default 1,
    pu_name text not null
);

create unique index tact_primary_pu_pu_name_uindex on tact_primary_pu (pu_name);

create unique index tact_primary_pu_id_uindex on tact_primary_pu (id);
                    
                
create table if not exists tact_primary_pu_item
(
    id            integer constraint tact_primary_pu_item_pk primary key autoincrement default 1,
    primary_pu_id integer      not null constraint tact_primary_pu_item_primary_pu_id_fk references tact_primary_pu(id) on update cascade on delete cascade,
    puid          text  not null,
    name          text not null,
    level         integer      not null
);
                
create unique index tact_primary_pu_item_id_uindex on tact_primary_pu_item (id);
    

create table if not exists tact_ref_pu
(
    id              integer  constraint ref_pu_pk primary key autoincrement default 1,
    puid            text  not null,
    primary_pu_name text not null constraint tact_ref_pu_primary_pu_name_fk references tact_primary_pu (pu_name) on update cascade on delete cascade
);
                
create unique index tact_ref_pu_id_uindex on tact_ref_pu (id);

CREATE TABLE if not exists settings_column_define
(
	id integer constraint settings_column_define_pk primary key autoincrement default 1,
	type text,
	data text,
	output_column_name text,
	output_column_type text,
	default_value text,
	coefficient text,
	unit text
);
