INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (1, 1, 'preprocess_casp_header.py', true, 'from resource.script.preprocess_base import PreprocessBase


class PreprocessScript(PreprocessBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> list:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: List of String
        """
        lines = self.readlines()

        ret_lines = list()

        for line in lines:
            if ''\"'' in line:
                line = line.replace(''\"'', '''')
            ret_lines.append(line)

        return ret_lines
');
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (2, 2, 'preprocess_casp_table.py', true, 'from resource.script.preprocess_base import PreprocessBase


class PreprocessScript(PreprocessBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> list:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: List of String
        """
        lines = self.readlines()

        ret_lines = list()

        for line in lines:
            if ''\"'' in line:
                line = line.replace(''\"'', '''')
            ret_lines.append(line)

        return ret_lines
');
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (3, 3, 'preprocess_dr_header.py', true, 'from resource.script.preprocess_base import PreprocessBase


class PreprocessScript(PreprocessBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> list:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: List of String
        """
        lines = self.readlines()

        ret_lines = list()

        for line in lines:
            if ''\"'' in line:
                line = line.replace(''\"'', '''')
            ret_lines.append(line)

        return ret_lines
');
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (4, 4, 'preprocess_dr_table.py', true, 'from resource.script.preprocess_base import PreprocessBase


class PreprocessScript(PreprocessBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> list:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: List of String
        """
        lines = self.readlines()

        ret_lines = list()

        for line in lines:
            if ''\"'' in line:
                line = line.replace(''\"'', '''')
            ret_lines.append(line)

        return ret_lines
');
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (5, 5, 'preprocess_my_header.py', true, 'from resource.script.preprocess_base import PreprocessBase


class PreprocessScript(PreprocessBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> list:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: List of String
        """
        lines = self.readlines()

        ret_lines = list()

        for line in lines:
            if ''\"'' in line:
                line = line.replace(''\"'', '''')
            ret_lines.append(line)

        return ret_lines
');
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (6, 6, 'preprocess_my_table.py', true, 'from resource.script.preprocess_base import PreprocessBase


class PreprocessScript(PreprocessBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> list:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: List of String
        """
        lines = self.readlines()

        ret_lines = list()

        for line in lines:
            if ''\"'' in line:
                line = line.replace(''\"'', '''')
            ret_lines.append(line)

        return ret_lines
');
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (7, 7, 'preprocess_offset_table.py', true, 'from resource.script.preprocess_base import PreprocessBase


class PreprocessScript(PreprocessBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> list:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: List of String
        """
        lines = self.readlines()

        ret_lines = list()

        for line in lines:
            if ''\"'' in line:
                line = line.replace(''\"'', '''')
            ret_lines.append(line)

        return ret_lines
');
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (8, 8, 'preprocess_yaw_header.py', true, 'from resource.script.preprocess_base import PreprocessBase


class PreprocessScript(PreprocessBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> list:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: List of String
        """
        lines = self.readlines()

        ret_lines = list()

        for line in lines:
            if ''\"'' in line:
                line = line.replace(''\"'', '''')
            ret_lines.append(line)

        return ret_lines
');
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (9, 9, 'preprocess_yaw_table.py', true, 'from resource.script.preprocess_base import PreprocessBase


class PreprocessScript(PreprocessBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> list:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: List of String
        """
        lines = self.readlines()

        ret_lines = list()

        for line in lines:
            if ''\"'' in line:
                line = line.replace(''\"'', '''')
            ret_lines.append(line)

        return ret_lines
');
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (10, 10, null, false, null);
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (11, 11, 'preprocess_adc_measurement.py', true, 'from resource.script.preprocess_base import PreprocessBase


class PreprocessScript(PreprocessBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> list:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: List of String
        """
        lines = self.readlines()

        ret_lines = list()

        replace_list = [''2427A_'', ''2427B_'', ''2427C_'', ''2427D_'', ''2427E_'', ''2427F_'']

        for line in lines:
            for replace in replace_list:
                line = line.replace(replace, '''')
            ret_lines.append(line)

        return ret_lines
');
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (12, 12, null, false, null);
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (13, 13, null, false, null);
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (14, 14, null, false, null);
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (15, 15, null, false, null);
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (16, 16, null, false, null);
INSERT INTO analysis_preprocess_script (id, func_id, file_name, use_script, script) VALUES (17, 17, null, false, null);