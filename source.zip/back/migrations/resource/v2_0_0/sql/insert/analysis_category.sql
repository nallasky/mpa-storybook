INSERT INTO analysis_category (id, title) VALUES (1, 'Overlay');
INSERT INTO analysis_category (id, title) VALUES (2, 'Tact');
INSERT INTO analysis_category (id, title) VALUES (3, 'Focus');