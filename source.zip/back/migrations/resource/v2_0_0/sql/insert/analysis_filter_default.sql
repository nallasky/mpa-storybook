INSERT INTO analysis_filter_default (id, func_id, key, val) VALUES (1, 12, 'device', null);
INSERT INTO analysis_filter_default (id, func_id, key, val) VALUES (2, 12, 'process', null);
INSERT INTO analysis_filter_default (id, func_id, key, val) VALUES (3, 13, 'device', null);
INSERT INTO analysis_filter_default (id, func_id, key, val) VALUES (4, 13, 'process', null);
INSERT INTO analysis_filter_default (id, func_id, key, val) VALUES (5, 13, 'step_no', null);
INSERT INTO analysis_filter_default (id, func_id, key, val) VALUES (6, 16, 'status', 'Job');