INSERT INTO public_calc_type (id, type) VALUES (1, 'max');
INSERT INTO public_calc_type (id, type) VALUES (2, 'min');
INSERT INTO public_calc_type (id, type) VALUES (3, 'ave');
INSERT INTO public_calc_type (id, type) VALUES (4, 'sum');
INSERT INTO public_calc_type (id, type) VALUES (5, '3sigma');
INSERT INTO public_calc_type (id, type) VALUES (6, 'sequential');
INSERT INTO public_calc_type (id, type) VALUES (7, 'script');