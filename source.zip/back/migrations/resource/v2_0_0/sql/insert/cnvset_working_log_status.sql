INSERT INTO cnvset_working_log_status (status) VALUES ('wait');
INSERT INTO cnvset_working_log_status (status) VALUES ('convert');
INSERT INTO cnvset_working_log_status (status) VALUES ('error');
INSERT INTO cnvset_working_log_status (status) VALUES ('success');