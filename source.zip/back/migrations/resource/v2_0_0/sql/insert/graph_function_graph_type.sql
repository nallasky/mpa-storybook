INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (1, 1, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (2, 2, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (3, 3, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (4, 4, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (5, 5, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (6, 6, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (7, 7, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (8, 8, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (9, 9, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (10, 10, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (11, 11, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, []);

                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                tmpData = Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, []);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (12, 12, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, tmpData);
				
                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (13, 13, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, tmpData);
				
                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (14, 13, 'x_y_pair', 'function renderGraph(Plotly, element, params) {
  let tmpData = [];
  let key_list = Object.keys(params.y);

  if (Object.values(params.x).length) {
    for (let cnt = 0; cnt < Object.values(params.x)[0].length; cnt++) {
      let x = [];
      let y = [];
      for (var order = 0; order < key_list.length; order++) {
        if(order % 2 == 0){
          x.push(params.y[key_list[order]][cnt]);
        } else {
          y.push(params.y[key_list[order]][cnt]);
        }
      }

      let tmp_arr = [];
      for (let i = 0; i < x.length; i++) {
        tmp_arr.push({ x: x[i], y: y[i] });
      }

      tmp_arr.sort(function (a, b) {
        return a.x - b.x;
      });

      x = [];
      y = [];
      for (let j = 0; j < tmp_arr.length; j++) {
        x.push(tmp_arr[j].x);
        y.push(tmp_arr[j].y);
      }

      tmpData.push({
        x: x,
        y: y,
        type: ''scatter'',
        name: Object.values(params.x)[0][cnt],
      });
    }
  }

  let figure = tmpData;
  let layout = {
    title: params.title,
    showlegend: true,
    xaxis: {
      range: params.range.x,
    },
    yaxis: {
      range: params.range.y,
    },
    zaxis: {
      range: params.range.z,
    },
  };

  Plotly.newPlot(element, figure, layout);

  if (params.func) {
    element.on(''plotly_relayout'', params.func);
  }
}
', 'user');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (15, 14, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, tmpData);
				
                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (16, 15, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, tmpData);
				
                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (17, 16, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, tmpData);
				
                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');
INSERT INTO graph_function_graph_type (id, func_id, name, script, type) VALUES (18, 17, 'default', 'function renderGraph(Plotly, element, params) {
    let tmpGraphProp = {};

    const createPropData = (obj, type, params) => {
        let tmpRange = {},
            tmpDensityRange = {},
            tmpData = [];

        if (params.range.x.length > 0) {
            tmpRange[''xaxis''] = {
                range: params.range.x,
            };
        }

        if (params.range.y.length > 0) {
            tmpRange[''yaxis''] = {
                range: params.range.y,
            };
        }

        switch (type.toLowerCase()) {
            case ''bar'':
            default:
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''bar'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''line'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        type: ''scatter'',
                        name: v,
                    });
                    return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''box plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        y: params.y[v],
                        type: ''box'',
                        name: v,
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''density plot'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push(
                        {
                            x: params.x[v],
                            y: params.y[v],
                            mode: ''markers'',
                            name: v,
                            marker: {
                                color: ''rgb(245,245,245)'',
                                size: 1.5,
                                opacity: 0.7,
                            },
                            type: ''scatter'',
                        },
                        {
                            x: params.x[v],
                            y: params.y[v],
                            name: v,
                            ncontours: 20,
                            colorscale: ''Blues'',
                            reversescale: true,
                            showscale: false,
                            type: ''histogram2dcontour'',
                        },
                    );
		                return acc;
                }, tmpData);
				
                if (params.range.x.length > 0) {
                    tmpDensityRange[''xaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.x,
                    };
                }

                if (params.range.y.length > 0) {
                    tmpDensityRange[''yaxis''] = {
                        showgrid: false,
                        zeroline: false,
                        range: params.range.y,
                    };
                }

                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            showlegend: false,
                            hovermode: ''closest'',
                            bargap: 0,
                            ...tmpDensityRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;

            case ''bubble chart'':
                Object.keys(params.y).reduce((acc, v) => {
                    acc.push({
                        x: params.x[v],
                        y: params.y[v],
                        mode: ''markers'',
                        name: v,
                        marker: {
                            color: ''rgb(93, 164, 214)'',
                            size: params.z,
                        },
                    });
		                return acc;
                }, tmpData);
                if (Object.keys(obj).length === 0) {
                    obj = {
                        data: tmpData,
                        layout: {
                            title: params.title,
                            font: {
                                family: "Saira, ''Nunito Sans''",
                            },
                            ...tmpRange,
                        },
                    };
                } else {
                    obj = {
                        ...obj,
                        data: obj.data.concat(tmpData),
                    };
                }
                break;
        }
        return obj;
    };

    params.type.forEach((v) => {
        tmpGraphProp = createPropData(tmpGraphProp, v, params);
    });

    Plotly.newPlot(element, tmpGraphProp.data, tmpGraphProp.layout);

    if (params.func) {
        element.on(''plotly_relayout'', params.func);
    }
}
', 'system');