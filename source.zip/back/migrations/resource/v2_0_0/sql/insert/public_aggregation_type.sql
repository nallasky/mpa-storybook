INSERT INTO public_aggregation_type (id, type) VALUES (1, 'period');
INSERT INTO public_aggregation_type (id, type) VALUES (2, 'column');
INSERT INTO public_aggregation_type (id, type) VALUES (3, 'all');