INSERT INTO public_graph_type (id, type) VALUES (1, 'bar');
INSERT INTO public_graph_type (id, type) VALUES (2, 'line');
INSERT INTO public_graph_type (id, type) VALUES (3, 'box plot');
INSERT INTO public_graph_type (id, type) VALUES (4, 'density plot');
INSERT INTO public_graph_type (id, type) VALUES (5, 'bubble chart');