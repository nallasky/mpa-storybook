INSERT INTO public_analysis_type (id, type) VALUES (1, 'setting');
INSERT INTO public_analysis_type (id, type) VALUES (2, 'script');
INSERT INTO public_analysis_type (id, type) VALUES (3, 'none');
INSERT INTO public_analysis_type (id, type) VALUES (4, 'org');