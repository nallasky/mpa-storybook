INSERT INTO public_source_type (id, type) VALUES (1, 'local');
INSERT INTO public_source_type (id, type) VALUES (2, 'remote');
INSERT INTO public_source_type (id, type) VALUES (3, 'sql');
INSERT INTO public_source_type (id, type) VALUES (4, 'multi');