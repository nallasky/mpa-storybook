INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (1, 1, 'convert_casp_header.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "event_id": "event_id",
    "event_time": "event_time",
    "header1": "log_time",
    "header2": "type",
    "header3": "job_name",
    "header4": "lot_id",
    "header5": "plate_no",
    "header6": "shot_no",
    "header7": "cp",
    "header8": "glass_id",
    "header9": "mode",
    "header10": "dir",
    "header11": "start_psy",
    "header12": "start_msy",
    "header13": "start_smby",
    "header14": "target_psy",
    "header15": "target_msy",
    "header16": "target_smby",
    "header17": "mp_offset",
    "header18": "expo_position_start",
    "header19": "expo_position_finish",
    "header20": "valid_tolerance_psy",
    "header21": "valid_tolerance_msy",
    "header22": "valid_tolerance_smby",
    "header23": "smb_start_pos",
    "header24": "msy_delay_time",
    "header25": "expo_speed",
    "header26": "smb_speed"
}


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logDate = dict()
        resultDate = list()
        time_before = 0
        time_cnt = 0
        functionName = ''CASPHeader''

        # Read Log File
        lines = self.readlines()

        for line in lines:

            # 改行コード等を除外した上で分割
            linelog = line.strip().split('','')
            i = 1
            if not re.search(''\s*CASPHD\s*'', linelog[1]):
                continue

            logDate["event_id"] = functionName + "Event"
            for etc in linelog:
                if i == 1:
                    # 2020/03/04 09:03:14　の形式を
                    # 2020-03-04T09:03:14.000000+0900　の形式に変える
                    # 日付と時間にわける
                    date, time = etc.split(" ")
                    # 日付の年月日をわける
                    year, month, day = date.split("/")
                    month = month.rjust(2, "0")
                    day = day.rjust(2, "0")
                    time = time + ":00"
                    tmp = year + "-" + month + "-" + day + "T" + time
                    # 同じ時間の場合、ずらす（ずらさないとElasticSearchにデータが入らなくなるため）
                    if time_before == etc:
                        time_cnt += 1000
                    else:
                        time_before = etc
                        time_cnt = 0
                    data_cnt = str(time_cnt).rjust(6, "0")
                    tmp = tmp + "." + data_cnt
                    tmp = tmp + "+0900"
                    logDate["event_time"] = tmp

                if ''='' in etc:
                    etc = etc[etc.find(''='') + 1:]

                if ''\"'' in etc:
                    etc = etc.replace(''\"'', '''')

                if ''\t'' in etc:
                    etc = etc.replace(''\t'', '''')
                # 対応するキーが存在しないため、header + 連番をキーにする
                key = "header" + str(i)
                logDate[key] = etc
                i = i + 1

            resultDate.append(copy.deepcopy(logDate))

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)
        df[''log_time''] = pd.to_datetime(df[''log_time''])

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (2, 2, 'convert_casp_table.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "event_id": "event_id",
    "event_time": "event_time",
    "header1": "log_time",
    "header2": "type",
    "header3": "job_name",
    "header4": "lot_id",
    "header5": "plate_no",
    "header6": "shot_no",
    "header7": "cp",
    "header8": "glass_id",
    "header9": "psy",
    "header10": "dr",
    "header11": "my",
    "header12": "yaw",
    "header13": "z",
    "header14": "pitch",
    "header15": "roll"
}


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logDate = dict()
        resultDate = list()
        time_before = 0
        time_cnt = 0
        functionName = ''CASPTable''

        # Read Log File
        lines = self.readlines()

        for line in lines:

            # 改行コード等を除外した上で分割
            linelog = line.strip().split('','')
            i = 1
            if not re.search(''\s*CASPTB\s*'', linelog[1]):
                continue

            logDate["event_id"] = functionName + "Event"
            for etc in linelog:
                if i == 1:
                    # 2020/03/04 09:03:14　の形式を
                    # 2020-03-04T09:03:14.000000+0900　の形式に変える
                    # 日付と時間にわける
                    date, time = etc.split(" ")
                    # 日付の年月日をわける
                    year, month, day = date.split("/")
                    month = month.rjust(2, "0")
                    day = day.rjust(2, "0")
                    time = time + ":00"
                    tmp = year + "-" + month + "-" + day + "T" + time
                    # 同じ時間の場合、ずらす（ずらさないとElasticSearchにデータが入らなくなるため）
                    if time_before == etc:
                        time_cnt += 1000
                    else:
                        time_before = etc
                        time_cnt = 0
                    data_cnt = str(time_cnt).rjust(6, "0")
                    tmp = tmp + "." + data_cnt
                    tmp = tmp + "+0900"
                    logDate["event_time"] = tmp

                if ''='' in etc:
                    etc = etc[etc.find(''='') + 1:]

                if ''\"'' in etc:
                    etc = etc.replace(''\"'', '''')

                if ''\t'' in etc:
                    etc = etc.replace(''\t'', '''')
                # 対応するキーが存在しないため、header + 連番をキーにする
                key = "header" + str(i)
                logDate[key] = etc
                i = i + 1

            resultDate.append(copy.deepcopy(logDate))

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)
        df[''log_time''] = pd.to_datetime(df[''log_time''])

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (3, 3, 'convert_dr_header.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "event_id": "event_id",
    "event_time": "event_time",
    "header1": "log_time",
    "header2": "type",
    "header3": "job_name",
    "header4": "lot_id",
    "header5": "plate_no",
    "header6": "shot_no",
    "header7": "cp",
    "header8": "glass_id",
    "header9": "expo_ready_psy",
    "header10": "mpofs",
    "header11": "final_aapsy",
    "header12": "final_aapst",
    "header13": "final_aamsy",
    "header14": "auto_dr",
    "header15": "auto_mr",
    "header16": "final_aavs",
    "header17": "interfero_of_sx",
    "header18": "base",
    "header19": "bdc_x",
    "header20": "sdc_dr",
    "header21": "adc_dr",
    "header22": "sdc_yaw",
    "header23": "bdc_yaw",
    "header24": "adc_yaw",
    "header25": "vs_comp",
    "header26": "interferospan",
    "header27": "yaw_dr",
    "header28": "bar_rotate",
    "header29": "mag_tilt_comp",
    "header30": "mag_tilt_diffx"
}


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logDate = dict()
        resultDate = list()
        time_before = 0
        time_cnt = 0
        functionName = ''DRHeader''

        # Read Log File
        lines = self.readlines()

        for line in lines:

            # 改行コード等を除外した上で分割
            linelog = line.strip().split('','')
            i = 1
            if not re.search(''\s*DRHD\s*'', linelog[1]):
                continue

            logDate["event_id"] = functionName + "Event"
            for etc in linelog:

                if i == 1:
                    # 2020/03/04 09:03:14　の形式を
                    # 2020-03-04T09:03:14.000000+0900　の形式に変える
                    # 日付と時間にわける
                    date, time = etc.split(" ")
                    # 日付の年月日をわける
                    year, month, day = date.split("/")
                    month = month.rjust(2, "0")
                    day = day.rjust(2, "0")
                    time = time + ":00"
                    tmp = year + "-" + month + "-" + day + "T" + time
                    # 同じ時間の場合、ずらす（ずらさないとElasticSearchにデータが入らなくなるため）
                    if time_before == etc:
                        time_cnt += 1000
                    else:
                        time_before = etc
                        time_cnt = 0
                    data_cnt = str(time_cnt).rjust(6, "0")
                    tmp = tmp + "." + data_cnt
                    tmp = tmp + "+0900"
                    logDate["event_time"] = tmp

                if ''='' in etc:
                    etc = etc[etc.find(''='') + 1:]

                if ''\"'' in etc:
                    etc = etc.replace(''\"'', '''')

                if ''\t'' in etc:
                    etc = etc.replace(''\t'', '''')
                # 対応するキーが存在しないため、header + 連番をキーにする
                key = "header" + str(i)
                logDate[key] = etc
                i = i + 1

            resultDate.append(copy.deepcopy(logDate))

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)
        df[''log_time''] = pd.to_datetime(df[''log_time''])

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (4, 4, 'convert_dr_table.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "event_id": "event_id",
    "event_time": "event_time",
    "header1": "log_time",
    "header2": "type",
    "header3": "job_name",
    "header4": "lot_id",
    "header5": "plate_no",
    "header6": "shot_no",
    "header7": "cp",
    "header8": "glass_id",
    "header9": "psy",
    "header10": "comp",
    "header11": "bdc_x",
    "header12": "sdc_dr",
    "header13": "adc_dr",
    "header14": "yaw_dr",
    "header15": "auto_dr",
    "header16": "bar_rotation",
    "header17": "mag_tilt_comp",
    "header18": "mag_tilt_diffx"
}


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logDate = dict()
        resultDate = list()
        time_before = 0
        time_cnt = 0
        functionName = ''DRTable''

        # Read Log File
        lines = self.readlines()

        for line in lines:

            # 改行コード等を除外した上で分割
            linelog = line.strip().split('','')
            i = 1
            if not re.search(''\s*DRTB\s*'', linelog[1]):
                continue

            logDate["event_id"] = functionName + "Event"
            for etc in linelog:

                if i == 1:
                    # 2020/03/04 09:03:14　の形式を
                    # 2020-03-04T09:03:14.000000+0900　の形式に変える
                    # 日付と時間にわける
                    date, time = etc.split(" ")
                    # 日付の年月日をわける
                    year, month, day = date.split("/")
                    month = month.rjust(2, "0")
                    day = day.rjust(2, "0")
                    time = time + ":00"
                    tmp = year + "-" + month + "-" + day + "T" + time
                    # 同じ時間の場合、ずらす（ずらさないとElasticSearchにデータが入らなくなるため）
                    if time_before == etc:
                        time_cnt += 1000
                    else:
                        time_before = etc
                        time_cnt = 0
                    data_cnt = str(time_cnt).rjust(6, "0")
                    tmp = tmp + "." + data_cnt
                    tmp = tmp + "+0900"
                    logDate["event_time"] = tmp

                if ''='' in etc:
                    etc = etc[etc.find(''='') + 1:]

                if ''\"'' in etc:
                    etc = etc.replace(''\"'', '''')

                if ''\t'' in etc:
                    etc = etc.replace(''\t'', '''')
                # 対応するキーが存在しないため、header + 連番をキーにする
                key = "header" + str(i)
                logDate[key] = etc
                i = i + 1

            resultDate.append(copy.deepcopy(logDate))

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)
        df[''log_time''] = pd.to_datetime(df[''log_time''])

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (5, 5, 'convert_my_header.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "event_id": "event_id",
    "event_time": "event_time",
    "header1": "log_time",
    "header2": "type",
    "header3": "job_name",
    "header4": "lot_id",
    "header5": "plate_no",
    "header6": "shot_no",
    "header7": "cp",
    "header8": "glass_id",
    "header9": "expo_ready_psx",
    "header10": "expo_ready_psy",
    "header11": "final_aapsy",
    "header12": "final_aapst",
    "header13": "final_aamsy",
    "header14": "arc_my",
    "header15": "interfero_ofsy",
    "header16": "mp_ofs",
    "header17": "base",
    "header18": "bdc_y",
    "header19": "sdc_my",
    "header20": "adc_my",
    "header21": "sdc_yaw",
    "header22": "bdc_yaw",
    "header23": "adc_yaw",
    "header24": "yaw_my",
    "header25": "mag_x",
    "header26": "mag_y",
    "header27": "magxy_shift",
    "header28": "magyy_shift",
    "header29": "mag_tilt_comp",
    "header30": "mag_tilt_diffy"
}


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logDate = dict()
        resultDate = list()
        time_before = 0
        time_cnt = 0
        functionName = ''MYHeader''

        # Read Log File
        lines = self.readlines()

        for line in lines:

            # 改行コード等を除外した上で分割
            linelog = line.strip().split('','')
            i = 1
            if not re.search(''\s*MYHD\s*'', linelog[1]):
                continue

            logDate["event_id"] = functionName + "Event"
            for etc in linelog:

                if i == 1:
                    # 2020/03/04 09:03:14　の形式を
                    # 2020-03-04T09:03:14.000000+0900　の形式に変える
                    # 日付と時間にわける
                    date, time = etc.split(" ")
                    # 日付の年月日をわける
                    year, month, day = date.split("/")
                    month = month.rjust(2, "0")
                    day = day.rjust(2, "0")
                    time = time + ":00"
                    tmp = year + "-" + month + "-" + day + "T" + time
                    # 同じ時間の場合、ずらす（ずらさないとElasticSearchにデータが入らなくなるため）
                    if time_before == etc:
                        time_cnt += 1000
                    else:
                        time_before = etc
                        time_cnt = 0
                    data_cnt = str(time_cnt).rjust(6, "0")
                    tmp = tmp + "." + data_cnt
                    tmp = tmp + "+0900"
                    logDate["event_time"] = tmp

                if ''='' in etc:
                    etc = etc[etc.find(''='') + 1:]

                if ''\"'' in etc:
                    etc = etc.replace(''\"'', '''')

                if ''\t'' in etc:
                    etc = etc.replace(''\t'', '''')
                # 対応するキーが存在しないため、header + 連番をキーにする
                key = "header" + str(i)
                logDate[key] = etc
                i = i + 1

            resultDate.append(copy.deepcopy(logDate))

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)
        df[''log_time''] = pd.to_datetime(df[''log_time''])

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (6, 6, 'convert_my_table.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "event_id": "event_id",
    "event_time": "event_time",
    "header1": "log_time",
    "header2": "type",
    "header3": "job_name",
    "header4": "lot_id",
    "header5": "plate_no",
    "header6": "shot_no",
    "header7": "cp",
    "header8": "glass_id",
    "header9": "psy",
    "header10": "comp",
    "header11": "bdc_y",
    "header12": "sdc_my",
    "header13": "adc_my",
    "header14": "yaw_my",
    "header15": "mag_x",
    "header16": "mag_y",
    "header17": "magxy_shift",
    "header18": "magyy_shift",
    "header19": "mag_tilt_comp",
    "header20": "mag_tilt_diffy"
}


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logDate = dict()
        resultDate = list()
        time_before = 0
        time_cnt = 0
        functionName = ''MYTable''

        # Read Log File
        lines = self.readlines()

        for line in lines:

            # 改行コード等を除外した上で分割
            linelog = line.strip().split('','')
            i = 1
            if not re.search(''\s*MYTB\s*'', linelog[1]):
                continue

            logDate["event_id"] = functionName + "Event"
            for etc in linelog:

                if i == 1:
                    # 2020/03/04 09:03:14　の形式を
                    # 2020-03-04T09:03:14.000000+0900　の形式に変える
                    # 日付と時間にわける
                    date, time = etc.split(" ")
                    # 日付の年月日をわける
                    year, month, day = date.split("/")
                    month = month.rjust(2, "0")
                    day = day.rjust(2, "0")
                    time = time + ":00"
                    tmp = year + "-" + month + "-" + day + "T" + time
                    # 同じ時間の場合、ずらす（ずらさないとElasticSearchにデータが入らなくなるため）
                    if time_before == etc:
                        time_cnt += 1000
                    else:
                        time_before = etc
                        time_cnt = 0
                    data_cnt = str(time_cnt).rjust(6, "0")
                    tmp = tmp + "." + data_cnt
                    tmp = tmp + "+0900"
                    logDate["event_time"] = tmp

                if ''='' in etc:
                    etc = etc[etc.find(''='') + 1:]

                if ''\"'' in etc:
                    etc = etc.replace(''\"'', '''')

                if ''\t'' in etc:
                    etc = etc.replace(''\t'', '''')
                # 対応するキーが存在しないため、header + 連番をキーにする
                key = "header" + str(i)
                logDate[key] = etc
                i = i + 1

            resultDate.append(copy.deepcopy(logDate))

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)
        df[''log_time''] = pd.to_datetime(df[''log_time''])

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (7, 7, 'convert_offset_table.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "event_id": "event_id",
    "event_time": "event_time",
    "header1": "log_time",
    "header2": "type",
    "header3": "job_name",
    "header4": "lot_id",
    "header5": "plate_no",
    "header6": "shot_no",
    # "header7": "cp",
    "header8": "glass_id",
    "header9": "pos",
    "header10": "offset_xl",
    "header11": "offset_yl",
    "header12": "offset_xr",
    "header13": "offset_yr",
    "header14": "offset_arc",
    "header15": "xmag_pitch",
    "header16": "xmag_roll",
    "header17": "imag_pitch",
    "header18": "imag_roll",
    "header19": "ymag_pitch",
    "header20": "ymag_roll",
    "header21": "mag_tilt_xl",
    "header22": "mag_tilt_yl",
    "header23": "mag_tilt_xr",
    "header24": "mag_tilt_yr",
    "header25": "mag_tilt_mx",
    "header26": "mag_tilt_arc",
    "header27": "cp",
    "header28": "vs",
    "header29": "mode",
    "header30": "expo_left",
    "header31": "expo_right",
    "header32": "il_mode",
    "header33": "logical_posx",
    "header34": "logical_posy",
    "header35": "logical_post"
}


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logDate = dict()
        resultDate = list()
        time_before = 0
        time_cnt = 0
        functionName = ''OffsetTable''

        # Read Log File
        lines = self.readlines()

        for line in lines:

            # 改行コード等を除外した上で分割
            linelog = line.strip().split('','')
            i = 1
            if not re.search(''\s*OFSTB\s*'', linelog[1]):
                continue

            logDate["event_id"] = functionName + "Event"
            for etc in linelog:

                if i == 1:
                    # 2020/03/04 09:03:14　の形式を
                    # 2020-03-04T09:03:14.000000+0900　の形式に変える
                    # 日付と時間にわける
                    date, time = etc.split(" ")
                    # 日付の年月日をわける
                    year, month, day = date.split("/")
                    month = month.rjust(2, "0")
                    day = day.rjust(2, "0")
                    time = time + ":00"
                    tmp = year + "-" + month + "-" + day + "T" + time
                    # 同じ時間の場合、ずらす（ずらさないとElasticSearchにデータが入らなくなるため）
                    if time_before == etc:
                        time_cnt += 1000
                    else:
                        time_before = etc
                        time_cnt = 0
                    data_cnt = str(time_cnt).rjust(6, "0")
                    tmp = tmp + "." + data_cnt
                    tmp = tmp + "+0900"
                    logDate["event_time"] = tmp

                if ''='' in etc:
                    etc = etc[etc.find(''='') + 1:]

                if ''\"'' in etc:
                    etc = etc.replace(''\"'', '''')

                if ''\t'' in etc:
                    etc = etc.replace(''\t'', '''')

                # 対応するキーが存在しないため、header + 連番をキーにする
                key = "header" + str(i)
                logDate[key] = etc
                i = i + 1

            resultDate.append(copy.deepcopy(logDate))

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)
        df[''log_time''] = pd.to_datetime(df[''log_time''])

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (8, 8, 'convert_yaw_header.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "event_id": "event_id",
    "event_time": "event_time",
    "header1": "log_time",
    "header2": "type",
    "header3": "job_name",
    "header4": "lot_id",
    "header5": "plate_no",
    "header6": "shot_no",
    "header7": "cp",
    "header8": "glass_id",
    "header9": "expo_ready_psx",
    "header10": "expo_ready_psy",
    "header11": "expo_ready_msy",
    "header12": "base",
    "header13": "sdc_yaw",
    "header14": "adc_yaw",
    "header15": "bdc_t"
}


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logDate = dict()
        resultDate = list()
        time_before = 0
        time_cnt = 0
        functionName = ''YawHeader''

        # Read Log File
        lines = self.readlines()

        for line in lines:

            # 改行コード等を除外した上で分割
            linelog = line.strip().split('','')
            i = 1
            if not re.search(''\s*YAWHD\s*'', linelog[1]):
                continue

            logDate["event_id"] = functionName + "Event"
            for etc in linelog:

                if i == 1:
                    # 2020/03/04 09:03:14　の形式を
                    # 2020-03-04T09:03:14.000000+0900　の形式に変える
                    # 日付と時間にわける
                    date, time = etc.split(" ")
                    # 日付の年月日をわける
                    year, month, day = date.split("/")
                    month = month.rjust(2, "0")
                    day = day.rjust(2, "0")
                    time = time + ":00"
                    tmp = year + "-" + month + "-" + day + "T" + time
                    # 同じ時間の場合、ずらす（ずらさないとElasticSearchにデータが入らなくなるため）
                    if time_before == etc:
                        time_cnt += 1000
                    else:
                        time_before = etc
                        time_cnt = 0
                    data_cnt = str(time_cnt).rjust(6, "0")
                    tmp = tmp + "." + data_cnt
                    tmp = tmp + "+0900"
                    logDate["event_time"] = tmp

                if ''='' in etc:
                    etc = etc[etc.find(''='') + 1:]

                if ''\"'' in etc:
                    etc = etc.replace(''\"'', '''')

                if ''\t'' in etc:
                    etc = etc.replace(''\t'', '''')
                # 対応するキーが存在しないため、header + 連番をキーにする
                key = "header" + str(i)
                logDate[key] = etc
                i = i + 1

            resultDate.append(copy.deepcopy(logDate))

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)
        df[''log_time''] = pd.to_datetime(df[''log_time''])

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (9, 9, 'convert_yaw_table.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd
import copy
import re

convert_columns = {
    "event_id": "event_id",
    "event_time": "event_time",
    "header1": "log_time",
    "header2": "type",
    "header3": "job_name",
    "header4": "lot_id",
    "header5": "plate_no",
    "header6": "shot_no",
    "header7": "cp",
    "header8": "glass_id",
    "header9": "psy",
    "header10": "comp",
    "header11": "sdc_yaw",
    "header12": "adc_yaw",
    "header13": "bdc_t"
}


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        logDate = dict()
        resultDate = list()
        time_before = 0
        time_cnt = 0
        functionName = ''YawTable''

        # Read Log File
        lines = self.readlines()

        for line in lines:

            # 改行コード等を除外した上で分割
            linelog = line.strip().split('','')
            i = 1
            if not re.search(''\s*YAWTB\s*'', linelog[1]):
                continue

            logDate["event_id"] = functionName + "Event"
            for etc in linelog:

                if i == 1:
                    # 2020/03/04 09:03:14　の形式を
                    # 2020-03-04T09:03:14.000000+0900　の形式に変える
                    # 日付と時間にわける
                    date, time = etc.split(" ")
                    # 日付の年月日をわける
                    year, month, day = date.split("/")
                    month = month.rjust(2, "0")
                    day = day.rjust(2, "0")
                    time = time + ":00"
                    tmp = year + "-" + month + "-" + day + "T" + time
                    # 同じ時間の場合、ずらす（ずらさないとElasticSearchにデータが入らなくなるため）
                    if time_before == etc:
                        time_cnt += 1000
                    else:
                        time_before = etc
                        time_cnt = 0
                    data_cnt = str(time_cnt).rjust(6, "0")
                    tmp = tmp + "." + data_cnt
                    tmp = tmp + "+0900"
                    logDate["event_time"] = tmp

                if ''='' in etc:
                    etc = etc[etc.find(''='') + 1:]

                if ''\"'' in etc:
                    etc = etc.replace(''\"'', '''')

                if ''\t'' in etc:
                    etc = etc.replace(''\t'', '''')
                # 対応するキーが存在しないため、header + 連番をキーにする
                key = "header" + str(i)
                logDate[key] = etc
                i = i + 1

            resultDate.append(copy.deepcopy(logDate))

        df = pd.DataFrame(resultDate)
        df.rename(columns=convert_columns, inplace=True)
        df[''log_time''] = pd.to_datetime(df[''log_time''])

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (10, 10, 'convert_machine.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """

        result_list = list()

        # Read Log File
        lines = self.readlines()

        for line in lines:
            linelog = line.strip().split('','')

            if len(linelog) == 2:
                result_list.append({''key'': linelog[0], ''val'': linelog[1]})

        df = pd.DataFrame(result_list)

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (11, 11, null, false, null);
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (12, 12, 'convert_auto_focus_compensation.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        df = self.execute_system_converter()

        filename = self.get_input_log_file_name()
        if ''lot_id'' in df.columns:
            lot_id_list = df[''lot_id''].dropna().unique()
            if len(lot_id_list) > 0:
                if df[''lot_id''].isnull().values[0]:
                    # example: [None, None, LOTID1, None, ...] -> [LOTID1, LOTID1, LOTID1, None, ...]
                    first_idx = df[df[''lot_id''] == lot_id_list[0]].index.tolist()[0]
                    for idx in range(0, first_idx):
                        df.at[idx, ''lot_id''] = lot_id_list[0]
                
                null_list = df[''lot_id''].isnull().values.tolist()
                filled_lot_id = df[''lot_id''].values[0] 
                for i in range(1, len(null_list)):
                    if null_list[i]:
                        df.at[i, ''lot_id''] = filled_lot_id
                    else:
                        filled_lot_id = df[''lot_id''].values[i]
            else:
                df[''lot_id''] = filename

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (13, 13, 'convert_pre_scan_compensation_monitor.py', true, 'from resource.script.convert_base import ConvertBase

import pandas as pd


class ConvertScript(ConvertBase):
    """
    .. class:: ConvertScript

        This class is for converting input file by user script.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def run(self) -> pd.DataFrame:
        """
        This method will be called by sub process(convert process). Fix this method as you want.

        :return: DataFrame
        """
        df = self.execute_system_converter()

        filename = self.get_input_log_file_name()
        if ''lot_id'' in df.columns:
            lot_id_list = df[''lot_id''].dropna().unique()
            if len(lot_id_list) > 0:
                if df[''lot_id''].isnull().values[0]:
                    # example: [None, None, LOTID1, None, ...] -> [LOTID1, LOTID1, LOTID1, None, ...]
                    first_idx = df[df[''lot_id''] == lot_id_list[0]].index.tolist()[0]
                    for idx in range(0, first_idx):
                        df.at[idx, ''lot_id''] = lot_id_list[0]
                
                null_list = df[''lot_id''].isnull().values.tolist()
                filled_lot_id = df[''lot_id''].values[0] 
                for i in range(1, len(null_list)):
                    if null_list[i]:
                        df.at[i, ''lot_id''] = filled_lot_id
                    else:
                        filled_lot_id = df[''lot_id''].values[i]
            else:
                df[''lot_id''] = filename

        return df
');
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (14, 14, null, false, null);
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (15, 15, null, false, null);
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (16, 16, null, false, null);
INSERT INTO analysis_convert_script (id, func_id, file_name, use_script, script) VALUES (17, 17, null, false, null);