create table public_request_type
(
	type text not null
);

create unique index public_request_type_type_uindex on public_request_type (type);

INSERT INTO public_request_type (type) VALUES
	('local'),
	('rapid');

create table public_request_status
(
	status text not null
);

create unique index public_request_status_status_uindex on public_request_status (status);

INSERT INTO public_request_status (status) VALUES
	('idle'),
	('running'),
	('error'),
	('success'),
	('cancel');

create table public_aggregation_type
(
    id		integer constraint public_aggregation_type_pk primary key autoincrement default 1,
    "type"	text not null
);

create unique index public_aggregation_type_type_uindex on public_aggregation_type ("type");

create unique index public_aggregation_type_id_uindex on public_aggregation_type (id);

create table public_calc_type
(
    id		integer constraint public_calc_type_pk primary key autoincrement default 1,
    "type"	text not null
);

create unique index public_calc_type_id_uindex on public_calc_type (id);

create unique index public_calc_type_type_uindex on public_calc_type (type);

create table public_analysis_type
(
    id   integer constraint public_analysis_type_pk primary key autoincrement default 1,
    "type" text   not null
);

create unique index public_analysis_type_id_uindex on public_analysis_type (id);

create unique index public_analysis_type_type_uindex on public_analysis_type ("type");

create table public_source_type
(
    id   integer constraint public_source_type_pk primary key autoincrement default 1,
    "type" text   not null
);

create unique index public_source_type_id_uindex on public_source_type (id);

create unique index public_source_type_type_uindex on public_source_type ("type");

CREATE TABLE public_graph_type (
	id            integer constraint public_graph_type_pk primary key autoincrement default 1,
	"type" text NOT NULL
);

CREATE UNIQUE INDEX graph_type_id_uindex ON public_graph_type (id);

CREATE UNIQUE INDEX graph_type_type_uindex ON public_graph_type (type);