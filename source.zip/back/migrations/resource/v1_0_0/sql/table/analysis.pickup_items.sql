create table analysis.pickup_items
(
    log_name     text,
    column_name  text,
    cell_formula text,
    all_formula  text,
    disp_order   integer,
    disp_str     text,
    disp_graph_f boolean
);