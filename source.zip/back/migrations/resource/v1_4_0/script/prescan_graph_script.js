function renderGraph(Plotly, element, params) {
  let tmpData = [];
  let key_list = Object.keys(params.y);

  for (let cnt = 0; cnt < Object.values(params.x)[0].length; cnt++) {
    let x = [];
    let y = [];
    for (var order = 0; order < key_list.length; order++) {
      if(order % 2 == 0){
        x.push(params.y[key_list[order]][cnt]);
      } else {
        y.push(params.y[key_list[order]][cnt]);
      }
    }

    let tmp_arr = [];
    for (let i = 0; i < x.length; i++) {
      tmp_arr.push({ x: x[i], y: y[i] });
    }

    tmp_arr.sort(function (a, b) {
      return a.x - b.x;
    });

    x = [];
    y = [];
    for (let j = 0; j < tmp_arr.length; j++) {
      x.push(tmp_arr[j].x);
      y.push(tmp_arr[j].y);
    }

    tmpData.push({
      x: x,
      y: y,
      type: 'scatter',
      name: Object.values(params.x)[0][cnt],
    });
  }

  let figure = tmpData;
  let layout = {
    title: params.title,
    showlegend: true,
    xaxis: {
      range: params.range.x,
    },
    yaxis: {
      range: params.range.y,
    },
    zaxis: {
      range: params.range.z,
    },
  };

  Plotly.newPlot(element, figure, layout);

  if (params.func) {
    element.on('plotly_relayout', params.func);
  }
}
