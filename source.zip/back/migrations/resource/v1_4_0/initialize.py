import os
from dao import get_dbinfo
from dao.dao_function import DAOFunction
from dao.dao_base import DAOBaseClass
from service.resources.service_resources import ResourcesService
import psycopg2 as pg2
from config import app_config
import json
import logging

logger = logging.getLogger(app_config.LOG)

APP_VERSION = '1.4.0'

RESOURCE_PATH = 'migrations/resource/v1_4_0'
RSC_SYSTEM_GRAPH_SCRIPT = 'script/system_graph_script.js'


def init_db_v1_4_0():
    try:
        config = get_dbinfo()

        with pg2.connect(**config) as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                sql = """
                create schema if not exists tact;

                create table if not exists tact.name_dat
                (
                    id   serial
                        constraint name_dat_pk
                            primary key,
                    puid varchar(50)  not null,
                    name varchar(100) not null
                );
                
                create unique index if not exists name_dat_id_uindex
                    on tact.name_dat (id);
                
                create unique index if not exists name_dat_puid_uindex
                    on tact.name_dat (puid);
                
                
                create table if not exists tact.plate_detail_tact
                (
                    id             serial
                        constraint plate_detail_tact_pk
                            primary key,
                    event          varchar(100)         not null,
                    start          varchar(100)         not null,
                    "end"          varchar(100)         not null,
                    classification varchar(100)         not null,
                    display        boolean default true not null
                );
                
                create unique index if not exists plate_detail_tact_id_uindex
                    on tact.plate_detail_tact (id);
                
                create unique index if not exists plate_detail_tact_event_uindex
                    on tact.plate_detail_tact (event);
                
                
                create table if not exists tact.plate_tact
                (
                    id             serial
                        constraint plate_tact_pk
                            primary key,
                    display_order  integer      not null,
                    classification varchar(100) not null
                );
                
                create unique index if not exists plate_tact_display_order_uindex
                    on tact.plate_tact (display_order);
                
                create unique index if not exists plate_tact_id_uindex
                    on tact.plate_tact (id);
                
                create unique index if not exists plate_tact_classification_uindex
                    on tact.plate_tact (classification);
                
                
                create table if not exists tact.plate_tact_event
                (
                    id    serial
                        constraint plate_tact_event_pk
                            primary key,
                    event varchar(100) not null
                );
                
                create unique index if not exists plate_tact_event_id_uindex
                    on tact.plate_tact_event (id);
                
                create unique index if not exists plate_tact_event_event_uindex
                    on tact.plate_tact_event (event);
                
                
                create table if not exists tact.primary_pu
                (
                    id      serial       not null
                        constraint primary_pu_pk
                            primary key,
                    pu_name varchar(100) not null
                );
                
                create unique index primary_pu_name_uindex
                    on tact.primary_pu (pu_name);
                
                create unique index primary_pu_id_uindex
                    on tact.primary_pu (id);
                    
                
                create table if not exists tact.primary_pu_item
                (
                    id            serial       not null
                        constraint primary_pu_item_pk
                            primary key,
                    primary_pu_id integer      not null
                        constraint primary_pu_item_primary_pu_id_fk
                            references tact.primary_pu
                            on update cascade on delete cascade,
                    puid          varchar(50)  not null,
                    name          varchar(100) not null,
                    level         integer      not null
                );
                
                create unique index primary_pu_item_id_uindex
                    on tact.primary_pu_item (id);
                
                create table if not exists tact.ref_pu
                (
                    id              serial       not null
                        constraint ref_pu_pk
                            primary key,
                    puid            varchar(50)  not null,
                    primary_pu_name varchar(100) not null
                        constraint ref_pu_primary_pu_pu_name_fk
                            references tact.primary_pu (pu_name)
                            on update cascade on delete cascade
                );
                
                create unique index ref_pu_id_uindex
                    on tact.ref_pu (id);
                
                create unique index ref_pu_puid_uindex
                    on tact.ref_pu (puid);
                """

                cur.execute(sql)

        dao = DAOBaseClass()

        with open(os.path.join(RESOURCE_PATH, RSC_SYSTEM_GRAPH_SCRIPT), 'r') as f:
            data = f.read()

        dao.update(table='graph.system_graph_type', set={'script': data}, where={'name': 'default'})
        dao.update(table='graph.function_graph_type', set={'script': data}, where={'type': 'system'})
        dao.update(table='settings.information', set={'value': APP_VERSION}, where={'key': 'version'})
    except Exception as e:
        logger.info(str(e))

    # config = get_dbinfo()
    #
    # with pg2.connect(**config) as conn:
    #     conn.autocommit = True
    #     with conn.cursor() as cur:
    #         cur.execute(f"update settings.information set value='{APP_VERSION}' where key='version'")


def import_rules():
    try:
        path = 'migrations/resource/v1_4_0/data/rules.json'
        with open(path, 'r') as f:
            log_list = json.load(f)

        dao = DAOBaseClass()

        for log in log_list:
            log_define_master = log.pop('log_define_master')
            convert_rule_list = log.pop('convert_rule')

            resp_form = dao.insert(table='cnvbase.log_define_master', data=log_define_master, rtn_id=True)
            if not resp_form.res:
                logger.info(resp_form.msg)
                return

            log_id = resp_form.data

            for convert_rule in convert_rule_list:
                convert_rule_item_list = convert_rule.pop('convert_rule_item')
                resp_form = dao.insert(table='cnvbase.convert_rule', data={**convert_rule, 'log_id': log_id},
                                       rtn_id=True)
                if not resp_form.res:
                    logger.info(resp_form.msg)
                    return

                rule_id = resp_form.data

                for convert_rule_item in convert_rule_item_list:
                    dao.insert(table='cnvbase.convert_rule_item', data={**convert_rule_item, 'rule_id': rule_id})

    except Exception as e:
        logger.info(str(e))


def import_function():
    try:
        path = 'migrations/resource/v1_4_0/data/function_export.json'
        with open(path, 'r', encoding='utf-8') as f:
            func_list = json.load(f)

        dao_func = DAOFunction()
        resources = ResourcesService()

        for function in func_list:
            category = function['category']
            func = function['func']
            convert = function['convert']
            analysis = function['analysis']
            visualization = function['visualization']

            resp_form = dao_func.insert_category_info(category)
            if not resp_form.res:
                logger.info(resp_form.msg)
                return

            category_id = resp_form.data

            resp_form = dao_func.insert_func_info({**func,
                                                   'category_id': category_id,
                                                   'analysis_type': analysis['type']})
            if not resp_form.res:
                logger.info(resp_form.msg)
                return

            func_id = resp_form.data

            if func['source_type'] == 'local':
                resp_form = dao_func.insert_convert_script(convert['script'], func_id=func_id)
                if not resp_form.res:
                    resources.delete_id(func_id=func_id)
                    logger.info(resp_form.msg)
                    return

            resp_form = dao_func.insert_analysis_info(analysis, func_id)
            if not resp_form.res:
                resources.delete_id(func_id=func_id)
                logger.info(resp_form.msg)
                return

            resp_form = dao_func.insert_visual_info(visualization, func_id)
            if not resp_form.res:
                resources.delete_id(func_id=func_id)
                logger.info(resp_form.msg)
                return

        logger.info('function import success')

    except Exception as e:
        logger.info(str(e))
