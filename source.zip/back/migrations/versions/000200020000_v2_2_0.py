import logging

from config import app_config
from migrations.resource.v2_2_0.initialize import init_db_v2_2_0, insert_data, import_logs, import_function


logger = logging.getLogger(app_config.LOG)

# revision identifiers, used by Alembic.
revision = '000200020000'
down_revision = '000200010000'
branch_labels = None
depends_on = None


def upgrade():
    logger.info(f'upgrade start {revision}')
    insert_data()
    import_logs()
    # import_rules()
    import_function()
    init_db_v2_2_0()

    logger.info(f'upgrade end {revision}')


def downgrade():
    pass
