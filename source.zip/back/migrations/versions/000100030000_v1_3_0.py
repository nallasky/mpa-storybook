"""v1_3_0

Revision ID: 1cd667fe64ce
Revises: 53108c5a7235
Create Date: 2022-01-10 14:31:05.072516

"""
from alembic import op
import sqlalchemy as sa
from migrations.resource.v1_3_0.initialize import init_db_v1_3_0


# revision identifiers, used by Alembic.
revision = '000100030000'
down_revision = '000100020001'
branch_labels = None
depends_on = None


def upgrade():
    init_db_v1_3_0()


def downgrade():
    pass
