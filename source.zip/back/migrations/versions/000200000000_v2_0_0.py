from alembic import op
import sqlalchemy as sa
import logging

from config import app_config
from migrations.resource.v2_0_0.initialize import init_db_v2_0_0, insert_data, import_tact_settings


logger = logging.getLogger(app_config.LOG)

# revision identifiers, used by Alembic.
revision = '000200000000'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    logger.info(f'upgrade start {revision}')
    init_db_v2_0_0()
    insert_data()
    import_tact_settings()
    logger.info(f'upgrade end {revision}')


def downgrade():
    pass
