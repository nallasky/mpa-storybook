from alembic import op
import sqlalchemy as sa
import logging

from config import app_config

logger = logging.getLogger(app_config.LOG)

# revision identifiers, used by Alembic.
revision = '000100040002'
down_revision = '000100040001'
branch_labels = None
depends_on = None


def upgrade():
    logger.info(f'upgrade end {revision}')


def downgrade():
    pass
