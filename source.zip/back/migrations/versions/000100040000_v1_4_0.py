from alembic import op
import sqlalchemy as sa
import logging

from config import app_config
from migrations.resource.v1_4_0.initialize import init_db_v1_4_0, import_rules, import_function, import_tact_settings


logger = logging.getLogger(app_config.LOG)

# revision identifiers, used by Alembic.
revision = '000100040000'
down_revision = '000100030000'
branch_labels = None
depends_on = None


def upgrade():
    logger.info(f'upgrade start {revision}')
    init_db_v1_4_0()
    import_rules()
    import_function()
    import_tact_settings()
    logger.info(f'upgrade end {revision}')


def downgrade():
    pass
