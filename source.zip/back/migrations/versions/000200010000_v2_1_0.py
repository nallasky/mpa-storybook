import logging

from config import app_config
from migrations.resource.v2_1_0.initialize import init_db_v2_1_0, insert_data, import_rules, import_logs, import_function



logger = logging.getLogger(app_config.LOG)

# revision identifiers, used by Alembic.
revision = '000200010000'
down_revision = '000200000000'
branch_labels = None
depends_on = None


def upgrade():
    logger.info(f'upgrade start {revision}')
    import_logs()
    import_rules()
    import_function()
    init_db_v2_1_0()
    insert_data()

    logger.info(f'upgrade end {revision}')


def downgrade():
    pass
