from script.script_base import ScriptBase


class PreprocessScript(ScriptBase):
    """
    .. class:: PreprocessScript

        This class is for preprocessing input file by user script.
    """

    def run(self, file_path) -> str:
        """
        This method will call by main process. Fix this method as you want.

        :param file_path: Input file path.
        :return: File path(str) after preprocessing ends.
        """
        new_lines = list()

        with open(file_path, mode='r+', encoding='utf-8') as f:
            lines = f.readlines()
            for line in lines:
                new_lines.append(line)

            f.seek(0)
            f.writelines(new_lines)

        return file_path
