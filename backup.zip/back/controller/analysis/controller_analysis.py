import os
import logging
from flask import request, Response
from flask_restx import Resource, Namespace, fields
import requests
import pandas as pd
from io import StringIO

from config import app_config
from service.analysis.service_analysis import AnalysisService
from dao.dao_management_setting import DAOMGMTSetting
from dao.dao_base import DAOBaseClass
from dao.dao_function import DAOFunction
from common.utils.response import make_json_response, ResponseForm
from common.utils import parameter
from controller.converter.converter import create_request_id
from dao.dao_history import DAOHistory
import convert as lc

logger = logging.getLogger(app_config.LOG)

ANALYSIS = Namespace(name='ANALYSIS', description='ログ分析用API。')

analysis_body = ANALYSIS.model('analysis_body', {
    'log_name': fields.String(description='ログ名', example='PLATEAUTOFOCUSCOMPENSATION'),
    'source': fields.String(description='[local, DB]', example='local'),
    'target_path': fields.String(description='フォルダ経路',
                                 example='P:/log_sample/server_log_path/BSOT/s2/SBPCN480/PLATEAUTOFOCUSCOMPENSATION'),
    'model': fields.String(description='ログフォーマット区分のためのモデル名', example='E813'),
    'one_period': fields.String(description='指定時間を1個のperiodで区分 [12, 24]', example='24'),
    'adjust_period': fields.String(description='periodを区分するための基準時間', example='0'),
    'first_half_year': fields.String(description='ログにyear情報がない場合、1～6月のデータのyear設定', example='2021'),
    'second_half_year': fields.String(description='ログにyear情報がない場合、7～12月のデータのyear設定. [Same Year, Last Year]',
                                      example='Same Year'),
})

analysis_list_response = ANALYSIS.model('analysis_list_response', {
    'items': fields.List(fields.Raw(example={'target': 'one_period',
                                             'title': 'One Period(hour)',
                                             'type': 'select',
                                             'mode': 'singular',
                                             'options': ['12h', '24h'],
                                             'selected': '24h'}, description='target:파라미터명, title:타이틀, '
                                                                              'type:옵션 아이템타입, mode:옵션 아이템 모드, '
                                                                              'options:선택옵션, selected:선택된 옵션'),
                         description='설정 가능한 아이템 리스트'),
    'data': fields.List(fields.Raw(description='start:시작날짜, end:종료날짜, job_list:장치리스트',
                                   example={'start': '2017-05-11 00:00:00',
                                            'end': '2017-05-11 23:59:59',
                                            'job_list': ['SCAN3X2/SCANDBG']}),
                        description='기간별 데이터를 리스트로 반환'),
})

analysis_summary_response = ANALYSIS.model('analysis_summary_response', {
    'items': fields.List(fields.Raw(example={'target': 'valid_interval_minutes',
                                             'title': 'Valid Interval(Min)',
                                             'type': 'select',
                                             'mode': 'singular',
                                             'options': ['1', '2'],
                                             'selected': None}, description='target:파라미터명, title:타이틀, '
                                                                              'type:옵션 아이템타입, mode:옵션 아이템 모드, '
                                                                              'options:선택옵션, selected:선택된 옵션'),
                        description='설정 가능한 아이템 리스트'),
    'data': fields.Raw(example={'disp_order': [], 'summary': {'index 0~ALL': {'column名': '値'}}},
                       description='disp_order:컬럼표시순서, summary:표시 데이터'),
})

analysis_detail_response = ANALYSIS.model('analysis_detail_response', {
    'data': fields.Raw(example={'disp_order': [], 'detail': {'index 0~': {'column名': '値'}}},
                       description='disp_order:컬럼표시순서, detail:표시 데이터'),
})

analysis_remote_response = ANALYSIS.model('analysis_remote_response', {
    'rid': fields.String(description='Request ID', example='request_YYYYMMDD_hhmmssssssss')
})


@ANALYSIS.route('/default/local/<int:func_id>/<string:rid>')
@ANALYSIS.route('/default/remote/<int:func_id>/<string:rid>')
@ANALYSIS.param('func_id', 'Function ID')
@ANALYSIS.param('rid', 'Request ID')
class GetAnalyisDefault(Resource):
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    def get(self, func_id, rid):
        """
        Get Log Period(Start, End) and Filter Setting Information
        """
        logger.info(str(request))

        try:
            analysis = AnalysisService()
            resp_form = analysis.get_show_org(func_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            show_org = resp_form.data

            resp_form = analysis.get_options(func_id, rid)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            period_filter = resp_form.data

            resp_form = analysis.get_aggregation_default(func_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            aggregation = resp_form.data

            resp_form = analysis.get_visualization_default(func_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            visualization = resp_form.data

            options = {**show_org, **period_filter, **aggregation, **visualization}

            return make_json_response(**options)
        except Exception as e:
            return make_json_response(status=400, msg=str(e))


@ANALYSIS.route('/default/history/<int:func_id>/<int:history_id>')
@ANALYSIS.param('func_id', 'Function ID')
@ANALYSIS.param('history_id', 'History ID')
class GetHistoryDefault(Resource):
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    def get(self, func_id, history_id):
        """
        Get Log Period(Start, End) and Filter Setting Information
        """
        logger.info(str(request))

        try:
            dao_history = DAOHistory()
            resp_form = dao_history.get_rid(history_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            rid = resp_form.data

            analysis = AnalysisService()
            # resp_form = analysis.get_options(func_id, rid)
            # if not resp_form.res:
            #     return make_json_response(status=400, msg=resp_form.msg)
            #
            # period_filter = resp_form.data
            resp_form = analysis.get_show_org(func_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            show_org = resp_form.data

            resp_form = dao_history.get_period(history_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            period_selected = resp_form.data
            # period_filter['period']['selected'] = period_selected

            resp_form = dao_history.get_filter_info(history_id)
            if not resp_form.res:
                filter_selected = None
            else:
                filter_selected = resp_form.data
            # for filter_item in period_filter['filter']:
            #     key = filter_item['target']
            #     if key in filter_selected:
            #         filter_item['selected'] = filter_selected[key]

            # resp_form = analysis.get_aggregation_default(func_id)
            # if not resp_form.res:
            #     return make_json_response(status=400, msg=resp_form.msg)
            #
            # aggregation = resp_form.data

            resp_form = dao_history.get_aggregation_info(history_id)
            if not resp_form.res:
                aggregation = dict()
            else:
                aggregation = resp_form.data
            # aggregation_type = resp_form.data['type']
            # aggregation_val = resp_form.data['val']

            # aggregation['aggregation']['selected'] = aggregation_type
            # aggregation['aggregation']['subItem'][aggregation_type]['selected'] = aggregation_val

            resp_form = dao_history.get_visualization_info(history_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            visualization = resp_form.data

            infos = dict()
            filter_info = dict()
            filter_info['log_time'] = {'start': period_selected[0], 'end': period_selected[1]}
            if filter_selected is not None:
                filter_info = {**filter_info, **filter_selected}

            infos['filter'] = filter_info

            infos['aggregation'] = aggregation

            resp_form = analysis.get_analysis(func_id, rid, **infos)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            options = {**show_org, **resp_form.data['option'], **visualization, 'data': resp_form.data['data']}
            return make_json_response(**options)
        except Exception as e:
            return make_json_response(status=400, msg=str(e))


@ANALYSIS.route('/lists/<string:log_name>/<string:job_id>')
@ANALYSIS.param('job_id', 'Job ID')
@ANALYSIS.param('log_name', 'Log Name')
class AnalysisLists(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('one_period', help='期間の時間単位(1h, 2h, 4h, 6h, 12h, 24h, 1d～, 1m～)')
    parser.add_argument('adj_period', help='期間の節目(0h-23h, 1d-31d, 0d:first day of log_list)')
    parser.add_argument('list_group', help='グループ表示方式(job, none)')

    @ANALYSIS.expect(parser)
    @ANALYSIS.doc(model=analysis_list_response)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    @ANALYSIS.response(500, 'Internal Server Error')
    def get(self, log_name, job_id):
        """
        Logデータを期間/グループで分類してリストで返還するAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        # todo 파라미터 default값을 가져와서 설정해줘야한다.
        default_setting = get_default_setting(log_name)
        if args['one_period'] is None:
            args['one_period'] = default_setting['one_period']
        if args['adj_period'] is None:
            args['adj_period'] = default_setting['adj_period']
        if args['list_group'] is None:
            args['list_group'] = default_setting['list_group']

        logger.debug(f'args: {args}')

        # パラメータの妥当性チェック
        res, msg = parameter.is_period_valid(args['one_period'], args['adj_period'])
        if not res:
            logger.debug(msg)
            return make_json_response(msg=msg, status=400)

        analysis = AnalysisService()
        res_form = analysis.get_list(log_name, job_id, args['one_period'], args['adj_period'], args['list_group'])
        if res_form.res:
            data = res_form.data[0]
            job_info_contained = res_form.data[1]
            items = self.get_list_items().data
            for item in items:
                item['selected'] = args[item['target']]
                if item['mode'] == 'subItem':
                    item['subItem']['selected'] = args[item['subItem']['target']]

                if item['target'] == 'list_group':
                    if job_info_contained:
                        item['options'].append('job')

            return make_json_response(items=items, data=data)
        else:
            logger.debug(f'get list failed : {res_form.msg}')
            return make_json_response(status=500, msg=res_form.msg)

    def get_list_items(self):
        return ResponseForm(res=True, data=
        [
            {
                'target': 'one_period',
                'title': 'One Period',
                'type': 'select',
                'mode': 'subItem',
                'options': ['12h', '24h', '7d', '14d', '1m'],
                'subItem': {
                    'target': 'adj_period',
                    'title': 'Adjust Period',
                    'type': 'select',
                    'mode': 'singular',
                    'options': [
                        {'12h': ['0h', '1h', '2h', '3h', '4h', '5h', '6h', '7h', '8h', '9h', '10h', '11h',
                                 '12h', '13h', '14h', '15h', '16h', '17h', '18h', '19h', '20h', '21h', '22h',
                                 '23h']},
                        {'24h': ['0h', '1h', '2h', '3h', '4h', '5h', '6h', '7h', '8h', '9h', '10h', '11h',
                                 '12h', '13h', '14h', '15h', '16h', '17h', '18h', '19h', '20h', '21h', '22h',
                                 '23h']},
                        {
                            '7d': ['0d', '1d', '2d', '3d', '4d', '5d', '6d', '7d', '8d', '9d', '10d',
                                   '11d', '12d', '13d', '14d', '15d', '16d', '17d', '18d', '19d', '20d',
                                   '21d', '22d', '23d', '24d', '25d', '26d', '27d', '28d', '29d', '30d', '31d']
                        },
                        {
                            '14d': ['0d', '1d', '2d', '3d', '4d', '5d', '6d', '7d', '8d', '9d', '10d',
                                    '11d', '12d', '13d', '14d', '15d', '16d', '17d', '18d', '19d', '20d',
                                    '21d', '22d', '23d', '24d', '25d', '26d', '27d', '28d', '29d', '30d', '31d']
                        },
                        {
                            '1m': ['0d', '1d', '2d', '3d', '4d', '5d', '6d', '7d', '8d', '9d', '10d',
                                   '11d', '12d', '13d', '14d', '15d', '16d', '17d', '18d', '19d', '20d',
                                   '21d', '22d', '23d', '24d', '25d', '26d', '27d', '28d', '29d', '30d', '31d']
                        }
                    ],
                    'selected': None
                },
                'selected': None
            },
            {
                'target': 'list_group',
                'title': 'List Group',
                'type': 'select',
                'mode': 'singular',
                'options': [],
                'selected': None
            }
        ])


@ANALYSIS.route('/<int:func_id>/<string:rid>')
@ANALYSIS.param('func_id', 'Fuction ID')
@ANALYSIS.param('rid', 'Request ID')
class GetAnalysis(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('start', required=True, help='期間の開始時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('end', required=True, help='期間の終了時間(YYYY-MM-DD hh:mm:ss)')

    @ANALYSIS.expect(parser)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(500, 'Internal Server Error')
    def get(self, func_id, rid):
        """
        期間/グループ別LOGデータの分析結果を返還するAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()
        param_dict = request.args.to_dict(flat=False)  # flat: to get list values

        for key in ['start', 'end']:
            if key in param_dict:
                param_dict.pop(key)

        filter = dict()
        filter['log_time'] = args

        if 'filter_key' in param_dict:
            for key in param_dict['filter_key']:
                if key in param_dict:
                    param_dict[key] = [val for val in param_dict[key] if val != '' and val != 'null']
                    if len(param_dict[key]) > 0:
                        filter[key] = param_dict[key]

        infos = dict()
        infos['filter'] = filter

        aggregation = dict()
        if 'aggregation_key' in param_dict:
            if 'aggregation_val' in param_dict:
                aggregation['type'] = param_dict['aggregation_key'][0]
                aggregation['val'] = param_dict['aggregation_val'][0]
            else:
                aggregation['type'] = param_dict['aggregation_key'][0]
                aggregation['val'] = None

        infos['aggregation'] = aggregation

        analysis = AnalysisService()

        res_form = analysis.get_analysis(func_id, rid, **infos)
        if res_form.res:
            return make_json_response(**res_form.data)
        else:
            logger.debug(f'get summary failed : {res_form.msg}')
            return make_json_response(status=500, msg=res_form.msg)


@ANALYSIS.route('/summaries/<string:log_name>/<string:job_id>')
@ANALYSIS.param('job_id', 'Job ID')
@ANALYSIS.param('log_name', 'Log Name')
class AnalysisSummaries(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('jobname', help='選択したジョブ名')
    parser.add_argument('start', required=True, help='期間の開始時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('end', required=True, help='期間の終了時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('valid_interval_minutes', help='設定間隔(Min)未満の連続したLogデータをSKIP.')
    parser.add_argument('filter_key', help='Logのフィルタリング情報')
    parser.add_argument('filter_value', help='Logのフィルタリング値')
    parser.add_argument('group_by', help='統計演算を適用させるグループ情報')
    parser.add_argument('group_value', help='統計演算グループを分類する基準値')

    @ANALYSIS.expect(parser)
    @ANALYSIS.doc(model=analysis_summary_response)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(500, 'Internal Server Error')
    def get(self, job_id, log_name):
        """
        期間/グループ別LOGデータの分析結果を返還するAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        # job_name = args['jobname'] if 'jobname' in args else None
        # valid_interval_minutes = args['valid_interval_minutes'] if 'valid_interval_minutes' in args else None
        # stats_period = args['stats_period'] if 'stats_period' in args else None
        # filter_key = args['filter_key'] if 'filter_key' in args else None
        # filter_value = args['filter_value'] if 'filter_value' in args else None
        # group_by = args['group_by'] if 'group_by' in args else None

        # todo 파라미터 default값을 가져와서 설정해줘야한다.
        default_setting = get_default_setting(log_name)
        if args['valid_interval_minutes'] is None:
            args['valid_interval_minutes'] = default_setting['valid_interval_minutes']
        if args['filter_key'] is None:
            args['filter_key'] = default_setting['filter_key']
        if args['filter_value'] is None:
            args['filter_value'] = default_setting['filter_value']
        if args['group_by'] is None:
            args['group_by'] = default_setting['group_by']
        if args['group_value'] is None:
            args['group_value'] = default_setting['group_value']

        logger.debug(f'args : {args}')

        analysis = AnalysisService()

        res_form = analysis.get_summary(log_name, job_id, **args)
        if res_form.res:
            group_columns = analysis.get_group_avail_columns(log_name)
            filter_kv = analysis.get_filter_key_value(log_name)

            items = self.get_summary_items().data
            for item in items:
                item['selected'] = args[item['target']]
                if item['mode'] == 'subItem':
                    item['subItem']['selected'] = args[item['subItem']['target']]

                if item['target'] == 'group_by':
                    if len(group_columns) > 0:
                        item['options'].append('column')
                        item['subItem']['options'].append({'column': group_columns})

                    if item['selected'] == 'period':
                        item['options'].append('period')
                        if item['subItem']['selected'][-1] == 'h':
                            item['subItem']['options'].append({'period': ['1h', '2h', '4h']})
                        elif item['subItem']['selected'][-1] == 'd':
                            item['subItem']['options'].append({'period': ['1d', '7d']})

                if item['target'] == 'filter_key':
                    item['options'].extend(filter_kv['key'])
                    item['subItem']['options'].extend(filter_kv['value'])

            return make_json_response(items=items, data=res_form.data)
        else:
            logger.debug(f'get summary failed : {res_form.msg}')
            return make_json_response(status=500, msg=res_form.msg)

    def get_summary_items(self):
        return ResponseForm(res=True, data=
        [
            {
                'target': 'valid_interval_minutes',
                'title': 'Valid Interval(Min)',
                'type': 'select',
                'mode': 'singular',
                'options': ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10',
                            '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
                            '21', '22', '23', '24', '25', '26', '27', '28', '29', '30',
                            '31', '32', '33', '34', '35', '36', '37', '38', '39', '40',
                            '41', '42', '43', '44', '45', '46', '47', '48', '49', '50',
                            '51', '52', '53', '54', '55', '56', '57', '58', '59', '60'],
                'selected': None
            },
            {
                'target': 'group_by',
                'title': 'Group By',
                'type': 'select',
                'mode': 'subItem',
                'options': [],
                'subItem': {
                    'target': 'group_value',
                    'title': 'Group Value',
                    'type': 'select',
                    'mode': 'singular',
                    'options': [],
                    'selected': None
                },
                'selected': None
            },
            {
                'target': 'filter_key',
                'title': 'Filter Key',
                'type': 'select',
                'mode': 'subItem',
                'options': [],
                'subItem': {
                    'target': 'filter_value',
                    'title': 'Filter Value',
                    'type': 'select',
                    'mode': 'singular',
                    'options': [],
                    'selected': None
                },
                'selected': None
            }
        ])


# @ANALYSIS.route('/details/<string:log_name>/<string:job_id>')
# @ANALYSIS.param('job_id', 'Job ID')
# @ANALYSIS.param('log_name', 'Log Name')
# class AnalysisDetail(Resource):
#     parser = ANALYSIS.parser()
#     parser.add_argument('jobname', help='選択したジョブ名')
#     parser.add_argument('start', required=True, help='期間の開始時間(YYYY-MM-DD hh:mm:ss)')
#     parser.add_argument('end', required=True, help='期間の終了時間(YYYY-MM-DD hh:mm:ss)')
#     parser.add_argument('valid_interval_minutes', help='設定間隔(Min)未満の連続したLogデータをSKIP.')
#     parser.add_argument('filter_key', help='Logのフィルタリング情報')
#     parser.add_argument('filter_value', help='Logのフィルタリング値')
#     parser.add_argument('group_by', required=True, help='統計演算を適用させるグループ情報')
#     parser.add_argument('group_value', required=True, help='統計演算グループを分類する基準値')
#     parser.add_argument('group_selected', required=True, help='選択されたグループ区分情報', action='append')
#
#     @ANALYSIS.expect(parser)
#     @ANALYSIS.doc(model=analysis_detail_response)
#     @ANALYSIS.response(200, 'Success')
#     @ANALYSIS.response(500, 'Internal Server Error')
#     def get(self, job_id, log_name):
#         """
#         期間/グループ別全体LOGデータを返還するAPI。
#         """
#         logger.info(str(request))
#
#         args = self.parser.parse_args()
#
#         # job_name = args['jobname'] if 'jobname' in args else None
#         # valid_interval_minutes = args['valid_interval_minutes'] if 'valid_interval_minutes' in args else None
#         # stats_period = args['stats_period'] if 'stats_period' in args else None
#         # filter_key = args['filter_key'] if 'filter_key' in args else None
#         # filter_value = args['filter_value'] if 'filter_value' in args else None
#         # group_by = args['group_by'] if 'group_by' in args else None
#
#         logger.debug(f'args : {args}')
#
#         analysis = AnalysisService()
#
#         res_form = analysis.get_detail(log_name, job_id, **args)
#         if res_form.res:
#             return make_json_response(data=res_form.data)
#         else:
#             logger.debug(f'get detail failed : {res_form.msg}')
#             return make_json_response(status=500, msg=res_form.msg)


@ANALYSIS.route('/data/<int:func_id>/<string:rid>')
@ANALYSIS.param('func_id', 'Function ID')
@ANALYSIS.param('rid', 'Request ID')
class AnalysisDetail(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('start', required=True, help='期間の開始時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('end', required=True, help='期間の終了時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('aggregation_key', required=True, help='One of column/period/All')
    parser.add_argument('aggregation_val', required=True, help='Select/Input value for aggregation key')
    parser.add_argument('selected', required=True, help='Selected Value of each row')

    @ANALYSIS.expect(parser)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(500, 'Internal Server Error')
    def get(self, func_id, rid):
        """
        期間/グループ別全体LOGデータを返還するAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()
        param_dict = request.args.to_dict(flat=False)  # flat: to get list values

        for key in ['start', 'end']:
            if key in param_dict:
                param_dict.pop(key)

        filter = dict()
        filter['log_time'] = {'start': args['start'], 'end': args['end']}

        if 'filter_key' in param_dict:
            for key in param_dict['filter_key']:
                if key in param_dict:
                    param_dict[key] = [val for val in param_dict[key] if val != '' and val != 'null']
                    if len(param_dict[key]) > 0:
                        filter[key] = param_dict[key]

        infos = dict()
        infos['filter'] = filter

        aggregation = dict()
        if 'aggregation_key' in param_dict and 'aggregation_val' in param_dict and 'selected' in param_dict:
            aggregation['type'] = param_dict['aggregation_key'][0]
            aggregation['val'] = param_dict['aggregation_val'][0]
            aggregation['selected'] = param_dict['selected']

        infos['aggregation'] = aggregation

        analysis = AnalysisService()

        res_form = analysis.get_detail(func_id, rid, **infos)
        if res_form.res:
            return make_json_response(**res_form.data)
        else:
            logger.debug(f'get detail failed : {res_form.msg}')
            return make_json_response(status=500, msg=res_form.msg)

def get_default_setting(log_name):
    if log_name == 'PLATEAUTOFOCUSCOMPENSATION':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': 'job',
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'column', 'group_value': 'lot_id'}
    elif log_name == 'PRESCANCOMPENSATIONMONITOR':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': 'job',
                # 'valid_interval_minutes': None, 'filter_key': 'step_no', 'filter_value': '1',
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'column', 'group_value': 'lot_id'}
    elif log_name == 'LiPSFocus':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': None,
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'period', 'group_value': '4h'}
    elif log_name == 'TiltMeasurementLog':
        return {'one_period': '1m', 'adj_period': '0d', 'list_group': None,
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'period', 'group_value': '1d'}
    elif log_name == 'MountPressLog':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': None,
                'valid_interval_minutes': None, 'filter_key': 'status', 'filter_value': 'Job',
                'group_by': 'period', 'group_value': '4h'}


@ANALYSIS.route('/remote/<int:func_id>/<string:equipment_name>')
@ANALYSIS.param('func_id', 'Function ID')
@ANALYSIS.param('equipment_name', '装置名')
class AnalysisRemote(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('period', required=True, help='LOG取得期間(YYYY-MM-DD~YYYY-MM-DD)')

    @ANALYSIS.expect(parser)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    @ANALYSIS.response(500, 'Internal Server Error')
    def post(self, func_id, equipment_name):
        """
        遠隔LOGを取得して内部DBに格納する。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        logger.debug(f'args : {args}')

        if '~' not in args['period']:
            return make_json_response(status=500, msg='Please Check period. It must be contained "~"')

        [start, end] = args['period'].split('~')
        dao = DAOFunction()
        resp_form = dao.get_log_name(func_id)
        if not resp_form.res:
            return make_json_response(status=400, msg='Cannot Find Log Name')

        log_name = resp_form.data

        res_form = self.get_remote_log(log_name, equipment_name, start, end)
        if res_form.res:
            dao = DAOBaseClass(table_name='cnvbase.log_define_master')
            row = dao.fetch_one(args={'select': 'table_name', 'where': f"log_name='{log_name}'"})

            dao = DAOBaseClass(table_name=f"convert.{row['table_name']}")
            columns = dao.get_columns()

            buf = StringIO(res_form.data['data'])

            df = pd.read_csv(buf, sep='\t')

            for col in df.columns:
                if col not in columns:
                    df.drop([col], axis=1, inplace=True)

            rid = create_request_id()
            logger.debug(f'create request id : {rid}')
            df['request_id'] = rid

            dao.insert_from_stringio(df)

            return make_json_response(rid=rid)
        else:
            logger.debug(f'get remote log failed : {res_form.msg}')
            return make_json_response(status=500, msg=res_form.msg)

    def get_remote_log(self, log_name, equipment_name, start, end):
        try:
            dao_mgmt = DAOMGMTSetting()
            mgmt_df = dao_mgmt.fetch_all()
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

        db_remote_df = mgmt_df[mgmt_df['target'] == 'remote'].reset_index()
        isnull = db_remote_df['host'].isnull().values.any()
        if not isnull:
            host = db_remote_df['host'][0]
            while host[-1] == '/':
                host = host[:-1]

            url = host + app_config.API_GET_LOG + f'/{equipment_name}/{log_name}'
            params = {'start': start, 'end': end}

            try:
                response = requests.get(url, params=params)
                if response.status_code == 200:
                    return ResponseForm(res=True, data=response.json())
                else:
                    return ResponseForm(res=False, msg=response.text, status=response.status_code)

            except Exception as e:
                return ResponseForm(res=False, msg=str(e), status=400)

        else:
            return ResponseForm(res=False, msg='Set remote server info first.', status=400)


@ANALYSIS.route('/history/<int:func_id>/<int:history_id>')
@ANALYSIS.param('func_id', 'Function ID')
@ANALYSIS.param('history_id', 'History ID')
class AnalysisHistory(Resource):
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    def get(self, func_id, history_id):
        """
        Return Request ID
        """
        logger.info(str(request))

        try:
            dao_history = DAOHistory()
            resp_form = dao_history.get_rid(history_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            rid = resp_form.data

            return make_json_response(rid=rid)

        except Exception as e:
            return make_json_response(status=400, msg=str(e))

@ANALYSIS.route('/history/new')
class SaveHistory(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('func_id', type=int, location='json', required=True, help='Function ID')
    parser.add_argument('log_from', type=str, location='json', required=True, help='local/remote')
    parser.add_argument('title', type=str, location='json', required=True, help='Title Info')
    parser.add_argument('period', type=dict, location='json', required=True, help='Period(Start~End)')
    parser.add_argument('filter', type=dict, location='json', required=True, help='Filter Info')
    parser.add_argument('aggregation', type=dict, location='json', required=True, help='Aggregation Info')
    parser.add_argument('visualization', type=dict, location='json', required=True, help='Visualization Info')
    parser.add_argument('local', type=dict, location='json', help='It contains Request ID.')
    parser.add_argument('remote', type=dict, location='json', help='It contains user_fab, equipment info.')

    @ANALYSIS.expect(parser)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    def post(self):
        """
        Save History Info.
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        history_id = None

        try:
            log_from = args['log_from']
            if log_from not in args:
                return make_json_response(status=400, msg=f"{log_from} key doesn't exist")

            dao_history = DAOHistory()

            infos = dict()
            infos['func_id'] = args['func_id']
            infos['period_start'] = args['period']['start']
            infos['period_end'] = args['period']['end']
            infos['log_from'] = args['log_from']
            infos['title'] = args['title']

            resp_form = dao_history.insert_history(**infos)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            history_id = resp_form.data

            infos = dict()
            infos['history_id'] = history_id

            subinfo = dict()
            if log_from == 'local':
                subinfo['rid'] = args['local']['rid']
                resp_form = dao_history.insert_history_from_local(**{**infos, **subinfo})
            else:
                subinfo['equipment_name'] = args['remote']['equipment_name']
                # subinfo['user_fab'] = args['remote']['user_fab']
                subinfo['rid'] = args['remote']['rid']
                resp_form = dao_history.insert_history_from_remote(**{**infos, **subinfo})

            if not resp_form.res:
                dao_history.delete_history_id(history_id)
                return make_json_response(status=400, msg=resp_form.msg)

            filter = args['filter']
            for key, val in filter.items():
                if len(val) > 0:
                    for i in range(len(val)):
                        subinfo = dict()
                        subinfo['key'] = key
                        subinfo['val'] = val[i]
                        resp_form = dao_history.insert_filter_history(**{**infos, **subinfo})
                        if not resp_form.res:
                            dao_history.delete_history_id(history_id)
                            return make_json_response(status=400, msg=resp_form.msg)
                else:
                    subinfo = dict()
                    subinfo['key'] = key
                    # subinfo['val'] = None
                    resp_form = dao_history.insert_filter_history(**{**infos, **subinfo})
                    if not resp_form.res:
                        dao_history.delete_history_id(history_id)
                        return make_json_response(status=400, msg=resp_form.msg)

            aggregation = args['aggregation']
            for key, val in aggregation.items():
                subinfo = dict()
                subinfo['type'] = key
                subinfo['val'] = val
                resp_form = dao_history.insert_aggregation_history(**{**infos, **subinfo})
                if not resp_form.res:
                    dao_history.delete_history_id(history_id)
                    return make_json_response(status=400, msg=resp_form.msg)

            visualization = args['visualization']
            for item in visualization['items']:
                subinfo = dict()
                subinfo['title'] = item['title']
                subinfo['type'] = ','.join(item['type'])
                subinfo['x_axis'] = item['x_axis']
                subinfo['y_axis'] = item['y_axis']
                subinfo['z_axis'] = item['z_axis']
                subinfo['x_range_min'] = item['x_range_min']
                subinfo['x_range_max'] = item['x_range_max']
                subinfo['y_range_min'] = item['y_range_min']
                subinfo['y_range_max'] = item['y_range_max']
                subinfo['z_range_min'] = item['z_range_min']
                subinfo['z_range_max'] = item['z_range_max']
                resp_form = dao_history.insert_visualization_history(**{**infos, **subinfo})
                if not resp_form.res:
                    dao_history.delete_history_id(history_id)
                    return make_json_response(status=400, msg=resp_form.msg)

            return Response(status=200)
        except Exception as e:
            if history_id is not None:
                dao_history.delete_history_id(history_id)
            return make_json_response(status=400, msg=str(e))
