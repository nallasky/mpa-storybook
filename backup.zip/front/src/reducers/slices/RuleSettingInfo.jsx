import { createSlice } from '@reduxjs/toolkit';
const initialState = {
  config: [],
  func: {},
  convert: { log_define: {}, info: [], header: [], custom: [] },
  filter: [],
  analysis: { items: [], filter_default: [], aggregation_default: {} },
  visualization: { items: [] , setting:{}},
};
const RuleSettingInfo = createSlice({
  name: 'RuleSettingInfo',
  initialState,
  reducers: {
    initialReducer: () => initialState,
    UpdateStepConfigReducer: (state, action) => {
      state.config = action.payload;
    },

    UpdateFuncStepReducer: (state, action) => {
      state.func = action.payload;
    },
    UpdateConvertStepInfoReducer: (state, action) => {
      state.convert = action.payload;
    },
    UpdateFilterStepInfoReducer: (state, action) => {
      state.filter = action.payload;
    },
    UpdateAnalysisStepInfoReducer: (state, action) => {
      state.analysis = action.payload;
    },
    UpdateVisualStepInfoReducer: (state, action) => {
      state.visualization = action.payload;
    },
  },
});

//reducer's action
export const {
  initialReducer: initialAction,
  UpdateStepConfigReducer,
  UpdateFuncStepReducer,
  UpdateConvertStepInfoReducer,
  UpdateFilterStepInfoReducer,
  UpdateAnalysisStepInfoReducer,
  UpdateVisualStepInfoReducer,
} = RuleSettingInfo.actions;

export const getStepConfig = (state) => state.RuleSettingInfo.config;
export const getFuncStepInfo = (state) => state.RuleSettingInfo.func;
export const getConvertStepInfo = (state) => state.RuleSettingInfo.convert;
export const getFilterStepInfo = (state) => state.RuleSettingInfo.filter;
export const getAnalysisStepInfo = (state) => state.RuleSettingInfo.analysis;
export const getVisualStepInfo = (state) => state.RuleSettingInfo.visualization;

export default RuleSettingInfo.reducer;
