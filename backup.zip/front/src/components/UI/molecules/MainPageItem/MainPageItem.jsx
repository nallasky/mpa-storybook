import React from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import ItemCard from '../../atoms/ItemCard/ItemCard';
import Button from '../../atoms/Button/Button';
import { Button as Button2, Menu, Dropdown } from 'antd';

import {
  DeleteOutlined,
  EditOutlined,
  MoreOutlined,
  PlusOutlined,
} from '@ant-design/icons';
import styled from '@emotion/styled';

const MainPageItem = ({
  isEditMode,
  mainText,
  subText,
  buttonText,
  onClick,
}) => {
  const menu = (
    <Menu onClick={onClick}>
      <Menu.Item key="EDIT" icon={<EditOutlined />}>
        EDIT
      </Menu.Item>
      <Menu.Item key="DELETE" icon={<DeleteOutlined />}>
        DELETE
      </Menu.Item>
    </Menu>
  );
  return isEditMode === true ? (
    <div>
      <ItemCard style={mainText === null ? { justifyContent: 'center' } : {}}>
        {mainText !== null ? (
          <>
            <div css={{ padding: '0 25px' }}>
              <Dropdown overlay={menu}>
                <Button2
                  type="dashed"
                  css={Button2Style}
                  icon={<MoreOutlined />}
                />
              </Dropdown>
              <p css={mainTextStyle}>{mainText}</p>
              <p css={subTextStyle}>{subText}</p>
            </div>
            <Button width={'80%'} style={buttonTextStyle} disabled>
              {buttonText}
            </Button>
          </>
        ) : (
          <>
            <Button3 type="text" onClick={onClick}>
              <PlusOutlined style={{ fontSize: '70px' }} />
            </Button3>
          </>
        )}
      </ItemCard>
    </div>
  ) : (
    <ItemCard>
      <div css={contentStyle}>
        <p css={mainTextStyle}>{mainText}</p>
        <p css={subTextStyle}>{subText}</p>
      </div>
      <Button width={'80%'} onClick={onClick} style={buttonTextStyle}>
        {buttonText}
      </Button>
    </ItemCard>
  );
};

MainPageItem.displayName = 'MainPageItem';
MainPageItem.propTypes = {
  isEditMode: PropTypes.bool,
  mainText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  subText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  buttonText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  onClick: PropTypes.func,
};
MainPageItem.defaultProps = {
  mainText: 'Main text',
  subText: 'Sub text',
  buttonText: 'Button',
};

const mainTextStyle = css`
  text-align: center;
  font-size: 24px;
  font-weight: 600;
  color: #002766;
`;

const subTextStyle = css`
  text-align: center;
  font-size: 18px;
  font-weight: 600;
  color: #1890ff;
`;

const buttonTextStyle = css`
  font-weight: 400;
`;

const contentStyle = css`
  padding: 0 25px;
`;

const Button2Style = css`
  position: absolute;
  right: 0.5rem;
  top: 0.5rem;
  border-radius: 1rem;
  border-color: #1890ff;
  color: #2f54eb;
`;

const Button3 = styled.button`
  position: relative;
  background: transparent;
  border: transparent;
  transition: box-shadow 0.1s ease, transform 0.1s ease;
  border-radius: 50%;
  padding: 1rem;
  &:hover {
    cursor: pointer;
    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.4);
  }
  &:active {
    box-shadow: none;
    transform: translateY(2px);
  }
  & svg {
    filter: drop-shadow(2px 4px 4px rgba(0, 0, 0, 0.4));
  }
`;
export default MainPageItem;
