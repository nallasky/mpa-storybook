import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Badge, Descriptions, Spin, Upload, Table, message } from 'antd';
import Button from '../../atoms/Button';
import { CloudUploadOutlined } from '@ant-design/icons/lib/icons';
import { LoadingOutlined } from '@ant-design/icons';
import {
  exportFile,
  reqZipFileUpload,
} from '../../../../lib/api/axios/requests';
import {
  MSG_APPLY,
  MSG_CANCEL,
  MSG_EXPORT,
  MSG_IMPORT,
  MSG_UPLOAD_EXCEL_ONLY,
} from '../../../../lib/api/Define/Message';
import { URL_EXPORT_DBTABLE, URL_IMPORT } from '../../../../lib/api/Define/URL';
import { RESPONSE_OK } from '../../../../lib/api/Define/etc';
const columns = [
  {
    title: 'No',
    dataIndex: 'no',
    key: 'no',
  },
  {
    title: 'Table name',
    dataIndex: 'table_name',
    key: 'table_name',
    width: 350,
  },
];
const IMPORT_FUNC = 'import';
const EXPORT_FUNC = 'export';
const DEFAULT_FUNC = EXPORT_FUNC;
const EXCEL_TYPE =
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const init_data = {
  file: undefined,
  status: undefined,
  message: undefined,
};
const DBTable = ({ info, update, key }) => {
  const [isMode, setMode] = useState(DEFAULT_FUNC);
  const [uploadFile, setUploadFile] = useState(init_data);
  const [isLoading, setLoading] = useState(false);
  const [TableData, setTableData] = useState(null);

  useEffect(() => {
    console.log('DBTable update', info);
    if (info)
      setTableData(
        info.items.map((obj, idx) => {
          return { key: idx, no: idx + 1, table_name: obj };
        }),
      );
    return () => {
      console.log('DBTable unmount');
      setLoading(false);
    };
  }, []);

  const setImportfile = (file) => {
    console.log('setImportfile', file);
    setUploadFile((prevState) => ({
      ...prevState,
      file: file,
    }));
  };

  const importZipFile = async () => {
    if (uploadFile.file ?? false) {
      try {
        const { status } = await reqZipFileUpload(URL_IMPORT, uploadFile.file);
        if (status.toString() === RESPONSE_OK) {
          setUploadFile(init_data);
          update(key);
        }
      } catch (e) {
        const { status: errCode, statusText: errMsg } = e.response;
        console.log('e.response', e.response);
        setUploadFile((prevState) => ({
          ...prevState,
          status: 'NG',
          message: `[${errCode}] ${errMsg}`,
        }));
      }
      console.log('===file upload completed====');
    }
  };
  const eventClick = (mode) => {
    setMode(mode);
    if (mode === EXPORT_FUNC)
      exportFile(URL_EXPORT_DBTABLE, 'file.xlsx').then((_) => _);
  };
  const exceptType = (type) => {
    console.log('exceptType: ', type);
    return Boolean(type === EXCEL_TYPE);
  };
  const ZipUploadProps = {
    name: 'files',
    beforeUpload: (file) => {
      if (exceptType(file.type) === false) {
        message.error(`${file.name} is not a excel file`);
        return Upload.LIST_IGNORE;
      } else {
        const formData = new FormData();
        formData.append('files', file);
        setImportfile(formData);
        return false;
      }
    },
    onRemove: (file) => {
      console.log('onRemove', file);
      setImportfile(undefined);
    },
  };
  const onClickCancel = () => {
    setUploadFile(init_data);
    setMode(DEFAULT_FUNC);
  };
  if (info == null) return <>{'DB Table empty'}</>;

  console.log('uploadFile', uploadFile);
  return (
    <>
      {isMode === DEFAULT_FUNC ? (
        <Descriptions
          title={info.title}
          column={2}
          layout="vertical"
          extra={
            <>
              <Button
                onClick={() => setMode(IMPORT_FUNC)}
                style={{ marginLeft: '8px', fontWeight: 400 }}
              >
                {MSG_IMPORT}
              </Button>
              <Button
                theme={'white'}
                onClick={() => eventClick(EXPORT_FUNC)}
                style={{ marginLeft: '8px', fontWeight: 400 }}
              >
                {MSG_EXPORT}
              </Button>
            </>
          }
        >
          <Descriptions.Item>
            <div>
              <Table
                bordered
                pagination={false}
                columns={columns}
                dataSource={TableData}
                size="middle"
                rowKey="key"

              />
            </div>
          </Descriptions.Item>
        </Descriptions>
      ) : (
        <Descriptions
          title={info.title}
          layout="vertical"
          extra={
            <>
              <Button
                onClick={() => onClickCancel()}
                style={{ marginLeft: '8px', fontWeight: 400 }}
              >
                {MSG_CANCEL}
              </Button>
              <Button
                theme={'white'}
                disabled={uploadFile.file === undefined}
                onClick={() => importZipFile()}
                style={{ marginLeft: '8px', fontWeight: 400 }}
              >
                {MSG_APPLY}
              </Button>
            </>
          }
        >
          <Descriptions.Item>
            <div>
              <Upload {...ZipUploadProps} maxCount={1}>
                <div css={{ display: 'flex', alignItems: 'center' }}>
                  <Button
                    icon={<CloudUploadOutlined />}
                    style={{ marginLeft: '8px', marginRight: '10px', fontWeight: 400 }}
                  >
                    {MSG_UPLOAD_EXCEL_ONLY}
                  </Button>
                  {uploadFile.status === 'NG' ? (
                    <div css={{ display: 'flex', fontWeight: 700, color:'#00a1ff' }}>
                      <Badge
                        status="error"
                        text={uploadFile.status}
                        style={{ left: '10px' }}
                      />
                      <div css={{ fontsize: '12px', paddingLeft: '24px' }}>
                        {uploadFile.message}
                      </div>
                    </div>
                  ) : (
                    <></>
                  )}
                </div>
              </Upload>
            </div>
            {uploadFile.file !== undefined ? (
              <>
                {isLoading === true ? (
                  <Spin
                    style={{ left: '10px' }}
                    indicator={
                      <LoadingOutlined style={{ fontSize: 24 }} spin />
                    }
                  />
                ) : (
                  <></>
                )}
              </>
            ) : (
              <></>
            )}
          </Descriptions.Item>
        </Descriptions>
      )}
    </>
  );
};

DBTable.propTypes = {
  info: PropTypes.object,
  key: PropTypes.string,
  update: PropTypes.func,
};

export default DBTable;
