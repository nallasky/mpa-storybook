import { createXvalue, dateValidateCheck } from '../SettingGraph/functionGroup';
import { useEffect, useRef } from 'react';
import dayjs from 'dayjs';
import { DATE_FORMAT } from '../../../../lib/api/Define/etc';

export const createData = (x, y, z, row) => {
  const tmpX = [],
    tmpZ = [];

  Object.keys(row).map((key) => {
    if (row[key]['No.'] !== 'ALL') {
      if (row[key][x] !== undefined) {
        tmpX.push(row[key][x]);
      }
      if (row[key][z] !== undefined) {
        tmpZ.push(row[key][z]);
      }
    }
  });

  return {
    x: tmpX,
    y: createYdata(y, row),
    z: tmpZ,
  };
};

export const createXZdata = (value, row) => {
  const tmpArray = [];

  Object.keys(row).map((key) => {
    if (row[key]['No.'] !== 'ALL' && row[key][value] !== undefined) {
      tmpArray.push(row[key][value]);
    }
  });

  return tmpArray;
};

export const createYdata = (arr, row) => {
  const tmpObj = {};

  arr.map((v) => {
    const tmp = [];
    Object.keys(row).map((key) => {
      if (row[key]['No.'] !== 'ALL' && row[key][v] !== undefined) {
        tmp.push(row[key][v]);
      }
    });

    if (tmp.length > 0) {
      tmpObj[v] = tmp;
    }
  });

  return tmpObj;
};

export const initEnableZ = (info, graphType) => {
  let isEnable = false;

  if (info.length > 0 && graphType.length > 0) {
    info.map((v) => {
      graphType.map((i) => {
        if (i.type === v && i.z_axis) {
          isEnable = true;
        }
      });
    });
  }

  return isEnable;
};

export const createHistoryGraphData = (graphList, type, x, z) => {
  const tmpArr = [];

  graphList.length > 0 &&
    graphList.map((v) => {
      const tmpObj = {
        title: v,
        type: type,
        x_axis: x,
        y_axis: v,
        z_axis: z === '' || z === null || z === undefined ? 'None' : z,
      };
      tmpArr.push(tmpObj);
    });

  return tmpArr;
};

export const createHistoryFilterData = (keys, originalFilterData, axisData) => {
  const tmpArr = [];
  if (keys.length > 0) {
    const xMinMax =
      axisData.x.length > 0 && axisData.x[0] !== undefined
        ? createXvalue(axisData.x)
        : {};
    const zMinMax = {
      min:
        axisData.z.length > 0 && axisData.z[0] !== undefined
          ? Math.min(...axisData.z)
          : 0,
      max:
        axisData.z.length > 0 && axisData.z[0] !== undefined
          ? Math.max(...axisData.z)
          : 0,
    };
    keys.map((v) => {
      const findOriginalData = originalFilterData.find((j) => j.title === v);
      if (findOriginalData === undefined) {
        tmpArr.push(
          Object.assign(
            {},
            {
              title: v,
              x_range_min:
                Object.keys(xMinMax).length === 0
                  ? 0
                  : xMinMax.date.length > 0
                  ? xMinMax.date[0].format(DATE_FORMAT)
                  : xMinMax.min.toString().indexOf('.') !== -1
                  ? parseFloat(xMinMax.min)
                  : parseInt(xMinMax.min),
              x_range_max:
                Object.keys(xMinMax).length === 0
                  ? 0
                  : xMinMax.date.length > 0
                  ? xMinMax.date[1].format(DATE_FORMAT)
                  : xMinMax.max.toString().indexOf('.') !== -1
                  ? parseFloat(xMinMax.max)
                  : parseInt(xMinMax.max),
              y_range_min:
                Object.keys(axisData.y).length > 0 &&
                axisData.y[v] !== undefined &&
                axisData.y[v].length > 0 &&
                axisData.y[v][0] !== undefined
                  ? Math.min(...axisData.y[v])
                  : 0,
              y_range_max:
                Object.keys(axisData.y).length > 0 &&
                axisData.y[v] !== undefined &&
                axisData.y[v].length > 0 &&
                axisData.y[v][0] !== undefined
                  ? Math.max(...axisData.y[v])
                  : 0,
              z_range_min: zMinMax.min,
              z_range_max: zMinMax.max,
            },
          ),
        );
      } else {
        const isDate =
          findOriginalData.x_range_min === null ||
          findOriginalData.x_range_min === undefined
            ? false
            : dateValidateCheck(
                findOriginalData.x_range_min
                  .toString()
                  .substr(
                    0,
                    findOriginalData.x_range_min.toString().indexOf('.') !== -1
                      ? findOriginalData.x_range_min.toString().indexOf('.')
                      : findOriginalData.x_range_min.toString().length,
                  ),
                DATE_FORMAT,
              );
        tmpArr.push(
          Object.assign(
            {},
            {
              title: findOriginalData.title,
              x_range_min: isDate
                ? dayjs(findOriginalData.x_range_min.toString()).format(
                    DATE_FORMAT,
                  )
                : findOriginalData.x_range_min.toString().indexOf('.') !== -1
                ? parseFloat(findOriginalData.x_range_min)
                : parseInt(findOriginalData.x_range_min),
              x_range_max: isDate
                ? dayjs(findOriginalData.x_range_max.toString()).format(
                    DATE_FORMAT,
                  )
                : findOriginalData.x_range_max.toString().indexOf('.') !== -1
                ? parseFloat(findOriginalData.x_range_max)
                : parseInt(findOriginalData.x_range_max),
              y_range_min:
                findOriginalData.y_range_min.toString().indexOf('.') !== -1
                  ? parseFloat(findOriginalData.y_range_min)
                  : parseInt(findOriginalData.y_range_min),
              y_range_max:
                findOriginalData.y_range_max.toString().indexOf('.') !== -1
                  ? parseFloat(findOriginalData.y_range_max)
                  : parseInt(findOriginalData.y_range_max),
              z_range_min:
                findOriginalData.z_range_min.toString().indexOf('.') !== -1
                  ? parseFloat(findOriginalData.z_range_min)
                  : parseInt(findOriginalData.z_range_min),
              z_range_max:
                findOriginalData.z_range_max.toString().indexOf('.') !== -1
                  ? parseFloat(findOriginalData.z_range_max)
                  : parseInt(findOriginalData.z_range_max),
            },
          ),
        );
      }
    });
  }
  return tmpArr;
};

export const usePrevious = (v) => {
  const ref = useRef();
  useEffect(() => {
    ref.current = v;
  });
  return ref.current;
};
