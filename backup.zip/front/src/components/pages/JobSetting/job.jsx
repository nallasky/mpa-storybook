import React, { useEffect, useState } from 'react';
import { Focus } from '../../UI/organisms';
import ProgressModal from '../../UI/organisms/ProgressModal';
import { useHistory, useLocation } from 'react-router';
import {
  reqFileUpload,
  initFocusJob,
  getStatusFocusJob,
  reqPostFocusJob,
  reqDeleteFocusJob,
  updateDate,
  getRequest,
} from '../../../lib/api/axios/requests';
import useFocusJob from '../../../hooks/useFocusJob';
import {
  arrayRemove,
  arrayShift,
  arrayUnshift,
  getParseData,
} from '../../../lib/util/Util';
import {
  ANALYSIS,
  MAIN,
  URL_ANALYSIS_HISTORY,
} from '../../../lib/api/Define/URL';
import { RESPONSE_OK } from '../../../lib/api/Define/etc';
import { notification } from 'antd';
import NotificationBox from '../../UI/molecules/NotificationBox/Notification';

const JobCreatePage = () => {
  const [isRemoteId, setRemoteId] = useState(null);
  const [isProcessJob, setProcessJob] = useState(false);
  const history = useHistory();
  const location = useLocation();
  const {
    isOpenCreateJob,
    closeCreateJob,
    openCreateJob,
    isSettingInfo,
    setSettingInfo,
    isErrorStatus,
    setErrorStatus,
    isLoading,
    loadStart,
    loadCompleted,
    JobInfo,
    setJobInfo,
    initValidPeriod,
    setValidPeriod,
    currentPath,
    setCurrentPath,
    urlList,
  } = useFocusJob();

  let JobUrl = 0;
  const goAnalysisPage = (jobPath) => {
    if (jobPath.func !== '') {
      const newPath = currentPath.slice(currentPath.indexOf(MAIN));
      newPath.unshift(jobPath.func);
      newPath.unshift(ANALYSIS);
      setCurrentPath(newPath);
    }
  };

  const startAnalysis = async () => {
    console.log('JobInfo', JobInfo);
    const { src_file } = JobInfo;
    const { formList } = isSettingInfo;

    let response;
    if ((JobInfo?.source || 'local') === 'local') {
      closeJobModal('/process');
      try {
        response = await reqFileUpload(src_file).then(
          console.log('==========file upload complete==============='),
        );
        if (response.status === 200) {
          if (response.jobId.length > 0) {
            await reqPostFocusJob(JobInfo, response.jobId).then((res) => {
              res.status === 200
                ? setRemoteId(res.jobId)
                : console.log('status', res.status);
            });
          }
        }
      } catch (e) {
        if (e.response) {
          const {
            data: { msg },
          } = e.response;
          console.log(e.response);
          NotificationBox('ERROR', msg, 4.5);
        }
      }
      console.log(response);
      setProcessJob(true);
    } else {
      closeCreateJob();
      const job = currentPath.find((obj) =>
        urlList.find((obj2) => obj2.func === obj),
      );
      if (JobInfo.source === 'remote') {
        try {
          await reqPostFocusJob(JobInfo, 0).then((res) => {
            const jobPath =
              job !== undefined
                ? urlList.find((obj2) => obj2.func === job)
                : { func: '', path: [] };
            console.log('[startAnalysis]jobPath', jobPath);
            const jobTypeInfo = formList.find(
              (obj) => obj.key === JobInfo.source,
            );
            goAnalysisPage(jobPath);
            if (res.jobId !== 0) {
              setRemoteId(res.jobId);
              history.push({
                pathname: ANALYSIS,
                state: {
                  history_id: jobTypeInfo?.history_id ?? undefined,
                  equipment_name: `${JobInfo.equipment_name}`,
                  job_type: `${jobTypeInfo.type}`,
                  func_id: `${JobInfo.func_id}`,
                  job_id: `${res.jobId}`,
                  path: jobPath?.path ?? [],
                },
              });
            }
          });
        } catch (e) {
          if (e.response) {
            const {
              data: { msg },
            } = e.response;
            console.log(e.response);
            NotificationBox('ERROR', msg, 4.5);
          }
        }
      } else {
        const request = async () => {
          const jobTypeInfo = formList.find(
            (obj) => obj.key === JobInfo.source,
          );
          const { status, info } = await getRequest(
            `${URL_ANALYSIS_HISTORY}/${JobInfo.func_id}/${jobTypeInfo?.history_id}`,
          );
          if (status.toString() === RESPONSE_OK) {
            history.push({
              pathname: ANALYSIS,
              state: {
                job_id: `${info.rid}`,
                history_id: `${jobTypeInfo?.history_id}`,
                job_type: `${jobTypeInfo.type}`,
                func_id: `${JobInfo.func_id}`,
              },
            });
          }
        };
        await request();
      }
    }
  };

  const closeJobModal = (next) => {
    closeCreateJob();
    Array.isArray(next)
      ? setCurrentPath(next)
      : next === 0
      ? setCurrentPath(arrayShift(currentPath))
      : setCurrentPath(arrayUnshift(currentPath, next));
  };

  const endProcessModal = async (status, rows) => {
    const job = currentPath.find((obj) =>
      urlList.find((obj2) => obj2.func === obj),
    );
    const jobPath =
      job !== undefined
        ? urlList.find((obj2) => obj2.func === job)
        : { func: '', path: [] };
    console.log('[endProcessModal]jobPath', jobPath);
    if (jobPath.func !== undefined) {
      const newPath = currentPath.slice(currentPath.indexOf(MAIN));
      newPath.unshift(jobPath.func);
      newPath.unshift(ANALYSIS);
      setCurrentPath(newPath);
    }
    setProcessJob(false);
    if (status === 'success') {
      const jobTypeInfo = isSettingInfo?.formList.find(
        (obj) => obj.key === JobInfo.source,
      );
      rows > 0
        ? history.push({
            pathname: ANALYSIS,
            state: {
              job_type: `${jobTypeInfo?.type ?? 'local'}`,
              func_id: `${JobInfo.func_id}`,
              job_id: `${isRemoteId}`,
              path: jobPath?.path ?? [],
            },
          })
        : setCurrentPath(arrayRemove(currentPath, location.pathname));
    } else if (status !== 'success') {
      await reqDeleteFocusJob(isRemoteId).then((res) =>
        console.log(' delete job response', res),
      );
      setCurrentPath(arrayRemove(currentPath, location.pathname));
    }
  };

  const contentChange = async (event) => {
    const item = getParseData(event);

    if (item.id === 'equipment_name') {
      try {
        const { date } = await updateDate(JobInfo.log_name, item.value);
        setValidPeriod(date);
        setJobInfo((prevState) => ({
          ...prevState,
          [item.id]: item.value,
          ['period']: `${date.start}~${date.end}`,
        }));
      } catch (e) {
        initValidPeriod();
      }
    } else {
      setJobInfo((prevState) => ({
        ...prevState,
        [item.id]: item.value,
      }));
    }
  };

  const checkAnalysisStatus = async (
    setStatusFunc,
    setPercentFunc,
    contentsFunc,
  ) => {
    try {
      if (isRemoteId !== null) {
        const { status, percent, detail } = await getStatusFocusJob(isRemoteId);
        setStatusFunc(status);
        setPercentFunc(percent);
        contentsFunc(detail);
      }
    } catch (e) {
      console.log(e);
      setErrorStatus(e);
    }
  };
  const openNotificationWithIcon = (type, msg) => {
    console.log('[openNotificationWithIcon] msg', msg);
    notification[type]({
      message: 'ERROR',
      description: msg,
      duration: 4.5,
    });
  };
  const fetchInfos = async () => {
    loadStart();
    try {
      const res = await initFocusJob(currentPath[0]);
      console.log(res);
      setSettingInfo(res, currentPath[0]);
    } catch (e) {
      if (e.response) {
        const {
          data: { msg },
        } = e.response;
        console.log(e.response);
        openNotificationWithIcon('error', msg);
      }
    }
    loadCompleted();
    openCreateJob();
    initValidPeriod();
  };

  useEffect(() => {
    JobUrl =
      currentPath.length > 0 &&
      urlList.find((obj) => obj.func === currentPath[0]) !== undefined
        ? currentPath[0]
        : 0;
    if (JobUrl) {
      fetchInfos().then(console.log('=====intialize completed ===='));
    }
  }, [currentPath]);

  if (isLoading) return <></>;
  if (isErrorStatus) return <div>{isErrorStatus}</div>;
  if (isSettingInfo === null) return <></>;

  return (
    <>
      {' '}
      <Focus
        isOpen={isOpenCreateJob}
        startFunc={startAnalysis}
        closeFunc={closeJobModal}
        changefunc={contentChange}
        info={isSettingInfo}
      />
      <ProgressModal
        isOpen={isProcessJob}
        closeFunc={endProcessModal}
        statusFunc={checkAnalysisStatus}
      />
    </>
  );
};

export default JobCreatePage;
