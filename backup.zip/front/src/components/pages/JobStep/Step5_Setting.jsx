import React from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { Table } from 'antd';
const tableWrapper = css`
  display: contents;
`;
const ContentsForm = () => {};

const PreviewForm = ({ data }) => {
  if (data == null) return <></>;

  const { analysis_header, analysis_data, analysis_error } = data;

  if (
    analysis_header === undefined &&
    analysis_data === undefined &&
    analysis_error === undefined
  )
    return <></>;

  return (
    <div css={tableWrapper}>
      {analysis_error !== undefined ? (
        <>{analysis_error}</>
      ) : (
        <Table
          bordered
          pagination={false}
          columns={analysis_header}
          dataSource={analysis_data}
          size="middle"
          rowKey="key"
          scroll={{ x: 'max-content' }}
        />
      )}
    </div>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const Step5_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step5_Setting.propTypes = {
  children: PropTypes.node,
};
Step5_Setting.contents = ContentsForm;
Step5_Setting.preview = PreviewForm;

export default Step5_Setting;
