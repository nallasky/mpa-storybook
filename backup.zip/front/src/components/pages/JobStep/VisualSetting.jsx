import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import React, { useEffect, useState } from 'react';
import { Collapse, Table, Select, Checkbox } from 'antd';
import {
  MSG_AXIS_X,
  MSG_AXIS_Y,
  MSG_AXIS_Z,
  MSG_PREVIOUS_TABLE,
  MSG_STEP6_GRAPTH_TYPE,
  MSG_STEP6_VISUAL_SET,
} from '../../../lib/api/Define/Message';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { createXvalue } from '../../UI/molecules/SettingGraph/functionGroup';
import { DATE_FORMAT, E_STEP_ANALYSIS } from '../../../lib/api/Define/etc';

const { Panel } = Collapse;
const { Option } = Select;

const tableWrapper = css`
  margin: 10px;
  display: flex;
  justify-content: center;
  & table {
    font-size: 14px;
    &:first-of-type > thead > tr > th {
      background: #f0f5ff;
    }
  }
`;

const x = (names) => names.filter((v, i) => names.indexOf(v) === i);
const getArr = (row, key) => {
  return Object.entries(row)
    .filter(([, obj]) => obj['No.'] !== 'ALL')
    .map(([, item]) => item[key]);
};
const VisualSetting = ({ data, onChange }) => {
  const {
    ruleStepConfig,
    updateVisualInfo,
    visualStepInfo,
  } = useRuleSettingInfo();

  const [enableZ, setEnableZ] = useState(false);
  const [optionAll, setOptionAll] = useState(true);
  const [config, setConfig] = useState(null);
  const [visualSetting, updateVisualSetting] = useState({});
  const { analysis_header, analysis_data } = data;

  useEffect(() => {
    console.log('[STEP6]data: ', data);
    const ruleConfig = ruleStepConfig.find(
      (item) =>
        item?.config?.visualization !== undefined ||
        item?.data?.graph_type !== undefined,
    );
    const configData =
      ruleStepConfig.find((item) => item.step === E_STEP_ANALYSIS)?.data ?? {};
    const yAxisData = x(visualStepInfo.items.map((obj) => obj.y_axis));

    setConfig({
      disp_graph: configData?.disp_graph ?? [],
      row: configData?.row ?? {},
      graph_type:
        ruleConfig?.config?.visualization.graph_type ??
        ruleConfig?.data?.graph_type ??
        [],
    });
    setOptionAll(configData?.disp_graph?.length === yAxisData.length);
    updateVisualSetting({
      items: visualStepInfo.items,
      setting: {
        graph: visualStepInfo.items?.[0]?.type ?? [],
        x_axis: visualStepInfo.items?.[0]?.x_axis ?? '',
        y_axis: visualStepInfo.items?.map((obj) => obj.y_axis),
        z_axis: visualStepInfo.items?.map((obj) => obj.z_axis) ?? '',
      },
    });
  }, []);

  useEffect(() => {
    updateVisualInfo(visualSetting);
  }, [visualSetting]);

  const changeType = (value) => {
    let isEnable = false,
      i = 0;
    const { graph_type } = config;
    console.log('changeType: ', value);

    while (i < value.length) {
      if (
        graph_type[graph_type.findIndex((v) => v.type === value[i])]?.z_axis ??
        false
      ) {
        isEnable = true;
        break;
      }
      i++;
    }
    const dispOrder = config.disp_graph.filter(
      (v) =>
        (visualSetting.setting?.y_axis?.findIndex((x) => x === v) ?? -1) !== -1,
    );
    updateVisualSetting((prevState) => ({
      ...prevState,
      items:
        value.length > 0
          ? prevState.items.length > 0
            ? prevState.items.map((obj) => {
                return {
                  ...obj,
                  type: value,
                  z_axis: isEnable ? obj?.z_axis ?? '' : '',
                };
              })
            : dispOrder.map((y) => {
                const fObj = prevState.items.find((obj) => obj.title === y);
                return (
                  fObj ??
                  newItemObjs(
                    value,
                    prevState.setting?.x_axis ?? '',
                    y,
                    prevState.setting?.z_axis ?? '',
                  )
                );
              })
          : [],
    }));

    updateVisualSetting((prevState) => {
      return {
        ...prevState,
        setting: {
          ...prevState.setting,
          graph: value,
        },
      };
    });
    setEnableZ(isEnable);
    onChange({ enableZ: isEnable });
  };

  const newItemObjs = (type, x, y, z) => {
    const minMaxX = createXvalue(getArr(config.row, x));
    const minMaxY = createXvalue(getArr(config.row, y));
    const minMaxZ = createXvalue(getArr(config.row, z));

    return {
      title: y,
      type: type,
      x_axis: x,
      y_axis: y,
      z_axis: z,
      x_range_max:
        minMaxX.date.length > 0
          ? minMaxX.date[1].format(DATE_FORMAT)
          : minMaxX.max,
      x_range_min:
        minMaxX.date.length > 0
          ? minMaxX.date[0].format(DATE_FORMAT)
          : minMaxX.min,
      y_range_max: minMaxY.max,
      y_range_min: minMaxY.min,
      z_range_max: minMaxZ.max,
      z_range_min: minMaxZ.min,
    };
  };

  const changeXYZ = (type, value) => {
    switch (type) {
      case 'y_axis':
        updateVisualSetting((prevState) => ({
          ...prevState,
          setting: {
            ...prevState.setting,
            y_axis: value,
          },
          items:
            value.length === 0
              ? []
              : value.map((y) => {
                  const fObj = prevState.items.find((obj) => obj.title === y);
                  return (
                    fObj ??
                    newItemObjs(
                      prevState.setting?.graph ?? [],
                      prevState.setting?.x_axis ?? '',
                      y,
                      prevState.setting?.z_axis ?? '',
                    )
                  );
                }),
        }));
        setOptionAll(value.length === config.disp_graph.length);
        break;
      case 'z_axis':
        updateVisualSetting((prevState) => ({
          ...prevState,
          items:
            prevState.setting?.y_axis?.map((y) => {
              return newItemObjs(
                prevState.setting?.graph ?? [],
                prevState.setting?.x_axis ?? '',
                y,
                value,
              );
            }) ?? [],
          setting: { ...prevState.setting, [type]: value },
        }));
        break;
      case 'x_axis':
        updateVisualSetting((prevState) => ({
          ...prevState,
          items:
            prevState.setting?.y_axis?.map((y) => {
              return newItemObjs(
                prevState.setting?.graph ?? [],
                value,
                y,
                prevState.setting?.z_axis ?? '',
              );
            }) ?? [],
          setting: {
            ...prevState.setting,
            [type]: value,
          },
        }));
        break;
      default:
        break;
    }
  };
  const changeAll = () => {
    setOptionAll(!optionAll);
    updateVisualSetting((prevState) => {
      return {
        ...prevState,
        setting: {
          ...prevState.setting,
          y_axis: !optionAll ? config.disp_graph : [],
        },
      };
    });
    changeXYZ('y_axis', !optionAll ? config.disp_graph : []);
  };
  console.log('visualSetting', visualSetting);
  if (config === null) return <></>;
  return (
    <div css={{ maxWidth: '85%', minWidth: '75%' }}>
      <Collapse defaultActiveKey={[1, 2]}>
        <Panel header={MSG_PREVIOUS_TABLE} key="1">
          <div css={tableWrapper}>
            {analysis_header !== undefined ? (
              <Table
                bordered
                pagination={false}
                columns={analysis_header}
                dataSource={analysis_data ?? []}
                size="middle"
                rowKey="key"
                scroll={{ x: 'max-content' }}
              />
            ) : (
              <></>
            )}
          </div>
        </Panel>
        <Panel header={MSG_STEP6_VISUAL_SET} key="2">
          <div css={settingWrapper}>
            <div>
              <span css={spanStyle}>{`${MSG_STEP6_GRAPTH_TYPE} :`}</span>
              <Select
                mode="multiple"
                maxTagCount="responsive"
                showArrow
                value={visualSetting.setting?.graph ?? []}
                style={{ width: '85%' }}
                dropdownStyle={{ fontFamily: 'Saira' }}
                onChange={changeType}
              >
                {config?.graph_type?.map((v, i) => (
                  <Option value={v.type} key={i}>
                    {v.type}
                  </Option>
                )) ?? <></>}
              </Select>
            </div>
            <div>
              <div>
                <span css={spanStyle}>{`${MSG_AXIS_X} :`}</span>
                <Select
                  name={'x_axis'}
                  value={visualSetting.setting?.x_axis ?? ''}
                  style={{ width: 519 }}
                  onChange={(v) => changeXYZ('x_axis', v)}
                >
                  {analysis_header?.map((v, i) => (
                    <Option value={v.title} key={i}>
                      {v.title}
                    </Option>
                  )) ?? <></>}
                </Select>
              </div>
              <div>
                <span css={spanStyle}>{`${MSG_AXIS_Y} :`}</span>
                <Select
                  name={'y_axis'}
                  mode="multiple"
                  maxTagCount="responsive"
                  showArrow
                  value={visualSetting.setting?.y_axis ?? []}
                  style={{ width: 520 }}
                  dropdownStyle={{ fontFamily: 'Saira' }}
                  onChange={(v) => changeXYZ('y_axis', v)}
                >
                  {config?.disp_graph.map((v, i) => (
                    <Option value={v} key={i}>
                      {v}
                    </Option>
                  )) ?? <></>}
                </Select>
                <Checkbox
                  checked={optionAll}
                  onChange={changeAll}
                  style={{ paddingLeft: '1rem' }}
                >
                  All
                </Checkbox>
              </div>
              <div>
                <span css={spanStyle}>{`${MSG_AXIS_Z} :`}</span>
                <Select
                  value={visualSetting.setting?.z_axis ?? ''}
                  style={{ width: 519 }}
                  dropdownStyle={{ fontFamily: 'Saira' }}
                  disabled={!enableZ}
                  onChange={(v) => changeXYZ('z_axis', v)}
                >
                  {config?.disp_graph.map((v, i) => (
                    <Option value={v} key={i}>
                      {v}
                    </Option>
                  )) ?? <></>}
                </Select>
              </div>
            </div>
          </div>
        </Panel>
      </Collapse>
    </div>
  );
};

const settingWrapper = css`
  position: relative;
  display: grid;
  grid-template-columns: 1fr 1fr;
  justify-items: center;
  column-gap: 1rem;
  & > div {
    width: 100%;
    &:last-of-type {
      display: grid;
      grid-template-rows: 1fr 1fr 1fr;
      row-gap: 1rem;
    }
  }
`;

const spanStyle = css`
  margin-right: 0.5rem;
`;

VisualSetting.propTypes = {
  data: PropTypes.object,
  onChange: PropTypes.func,
};
export default VisualSetting;
