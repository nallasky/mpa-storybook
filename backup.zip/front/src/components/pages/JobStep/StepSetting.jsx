import React from 'react';
import PropTypes from 'prop-types';
import {
  E_STEP_1,
  E_STEP_2,
  E_STEP_3,
  E_STEP_4,
  E_STEP_5,
  E_STEP_6,
} from '../../../lib/api/Define/etc';
import ConvertSetting from './ConvertSetting';
import FilterSetting from './FilterSetting';
import AnalysisSetting from './AnalysisSetting';
import VisualSetting from './VisualSetting';
import Step1_Setting from './Step1_Setting';
import Step2_Setting from './Step2_Setting';
import Step3_Setting from './Step3_Setting';
import Step4_Setting from './Step4_Setting';
import Step5_Setting from './Step5_Setting';
import Step6_Setting from './Step6_Setting';

/*============================================================================
==                         STEP Setting Page                                ==
============================================================================*/

const Contents = ({ current, data, changeFunc }) => {
  return (
    <>
      {current === E_STEP_1 ? (
        <Step1_Setting.contents onChange={changeFunc} />
      ) : current === E_STEP_2 ? (
        <Step2_Setting.contents data={data} onChange={changeFunc} />
      ) : current === E_STEP_3 ? (
        <ConvertSetting data={data} />
      ) : current === E_STEP_4 ? (
        <FilterSetting data={data} />
      ) : current === E_STEP_5 ? (
        <AnalysisSetting data={data} onChange={changeFunc} />
      ) : current === E_STEP_6 ? (
        <VisualSetting data={data} onChange={changeFunc} />
      ) : (
        <div>{'contentscontentscontentscontentscontents'}</div>
      )}
    </>
  );
};
Contents.propTypes = {
  current: PropTypes.number,
  data: PropTypes.object,
  changeFunc: PropTypes.func,
};

const Preview = ({ current, data }) => {
  return (
    <>
      {current === E_STEP_1 ? (
        <Step1_Setting.preview data={data} />
      ) : current === E_STEP_2 ? (
        <Step2_Setting.preview data={data} />
      ) : current === E_STEP_3 ? (
        <Step3_Setting.preview data={data} />
      ) : current === E_STEP_4 ? (
        <Step4_Setting.preview data={data} />
      ) : current === E_STEP_5 ? (
        <Step5_Setting.preview data={data} />
      ) : current === E_STEP_6 ? (
        <Step6_Setting.preview />
      ) : (
        <div />
      )}
    </>
  );
};
Preview.propTypes = {
  current: PropTypes.number,
  data: PropTypes.object,
};

const StepSetting = ({ children }) => {
  return <div>{children}</div>;
};

StepSetting.propTypes = {
  children: PropTypes.node,
};
StepSetting.preview = Preview;
StepSetting.contents = Contents;
export default StepSetting;
