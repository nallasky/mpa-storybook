import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Collapse, Form, Table, Button, Checkbox } from 'antd';
import {
  MSG_REQUIRED_TOOLTIP,
  MSG_STEP3_CUSTOM,
  MSG_STEP3_DEFINE,
  MSG_STEP3_HEADERS,
  MSG_STEP3_INFO,
  MSG_STEP3_LOG_DEFINE,
  MSG_STEP3_SELECT,
  MSG_TABLE_TITLE_COEFFICIENT,
  MSG_TABLE_TITLE_COLUMN,
  MSG_TABLE_TITLE_DATA,
  MSG_TABLE_TITLE_DEFAULT,
  MSG_TABLE_TITLE_DELETE,
  MSG_TABLE_TITLE_INDEX,
  MSG_TABLE_TITLE_NAME,
  MSG_TABLE_TITLE_OUTPUT,
  MSG_TABLE_TITLE_ROW,
  MSG_TABLE_TITLE_TYPE,
  MSG_TABLE_TITLE_UNIT,
} from '../../../lib/api/Define/Message';
import InputForm from '../../UI/atoms/Input/InputForm';
import PropTypes from 'prop-types';
import { MenuOutlined } from '@ant-design/icons';
import update from 'immutability-helper';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { E_STEP_3, RESPONSE_OK } from '../../../lib/api/Define/etc';
import { css } from '@emotion/react';
import TableComponent from './TableComponents';
import { useDebouncedCallback } from 'use-debounce';
import { getParseData, sortArrayOfObjects } from '../../../lib/util/Util';
import { getRequest } from '../../../lib/api/axios/requests';
import NotificationBox from '../../UI/molecules/NotificationBox/Notification';
import { URL_RESOURCE } from '../../../lib/api/Define/URL';

const { Panel } = Collapse;
const { Column } = Table;

const DEFINE_TYPE = 'DraggableBodyRow';
const DEFINE_INFO_TYPE = 'info';
const DEFINE_HEADER_TYPE = 'header';
const DEFINE_CUSTOM_TYPE = 'custom';
const CUSTOM_SELECT = 'custom';
const TEXT_SELECT = 'text';
const LAMBDA_SELECT = 'lambda';

const tableWrapper = css`
  display: flex;
  & table {
    font-size: 12px;
    &:first-of-type > thead > tr > th {
      background: #f0f5ff;
    }
  }
`;
const formWrapper = css`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: auto;
  justify-items: center;
  & > div > .ant-form {
    width: 500px;
  }
`;
const DraggableBodyRow = ({
  index,
  moveRow,
  className,
  style,
  ...restProps
}) => {
  const ref = useRef();
  const [{ isOver, dropClassName }, drop] = useDrop({
    accept: DEFINE_TYPE,
    collect: (monitor) => {
      const { index: dragIndex } = monitor.getItem() || {};
      if (dragIndex === index) {
        return {};
      }
      return {
        isOver: monitor.isOver(),
        dropClassName:
          dragIndex < index ? ' drop-over-downward' : ' drop-over-upward',
      };
    },
    drop: (item) => {
      moveRow(item.index, index);
    },
  });
  const [, drag] = useDrag({
    type: DEFINE_TYPE,
    item: { index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });
  drop(drag(ref));

  return (
    <tr
      ref={ref}
      className={`${className}${isOver ? dropClassName : ''}`}
      style={{ cursor: 'move', ...style }}
      {...restProps}
    />
  );
};
DraggableBodyRow.propTypes = {
  index: PropTypes.number,
  moveRow: PropTypes.func,
  className: PropTypes.string,
  style: PropTypes.object,
};
const SelectDisable = (record, type) => {
  switch (record[type]) {
    case CUSTOM_SELECT:
    case TEXT_SELECT:
    case LAMBDA_SELECT:
      return false;
  }
  return true;
};

const InfoConvertTable = ({
  dataSource,
  deleteHandler,
  dataOptions,
  typeOptions,
  columnOptions,
  onChangeText,
  moveInfoRow,
  components,
  log_data,
  isEdit,
}) => {
  return (
    <div>
      <Table
        bordered
        components={components}
        pagination={false}
        size="small"
        rowKey="key"
        dataSource={dataSource}
        scroll={{ x: 'max-content' }}
        onRow={(record, index) => ({
          index,
          moveRow: moveInfoRow,
        })}
      >
        <Column
          title={'Sort'}
          dataIndex="sort"
          key="idx"
          width="30"
          className="drag-visible"
          render={() => (
            <MenuOutlined style={{ cursor: 'grab', color: '#999' }} />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_INDEX}
          dataIndex="idx"
          key="idx"
          render={(_, row, index) => {
            return <>{index + 1}</>;
          }}
        />
        <Column
          title={MSG_TABLE_TITLE_ROW}
          dataIndex="row_index"
          key="row_index"
          render={(_, record) => (
            <TableComponent.inputNumber
              target={'row_index'}
              record={record}
              onChange={onChangeText}
              type={DEFINE_INFO_TYPE}
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_DATA}
          dataIndex="data"
          key="data"
          render={(_, row, index) => {
            return <>{log_data?.[`data_${index + 1}`] ?? ''}</>;
          }}
        />
        <Column
          title={MSG_TABLE_TITLE_NAME}
          dataIndex="name"
          key="name"
          render={(_, record) => (
            <TableComponent.input
              target={'name'}
              record={record}
              onChange={onChangeText}
              type={DEFINE_INFO_TYPE}
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_OUTPUT}
          dataIndex="output_column"
          key="output_column"
          render={(_, record) =>
            isEdit ? (
              <div css={{ display: 'flex' }}>
                <TableComponent.input
                  target={'output_column'}
                  record={record}
                  type={DEFINE_INFO_TYPE}
                  onChange={onChangeText}
                  disabled={
                    !(
                      record.rec_type === 'DB' &&
                      record.output_column_val === 'custom'
                    )
                  }
                />
                <TableComponent.select
                  target={'output_column_val'}
                  record={record}
                  type={DEFINE_INFO_TYPE}
                  onChange={onChangeText}
                  options={columnOptions}
                />
              </div>
            ) : (
              <TableComponent.input
                target={'output_column'}
                record={record}
                type={DEFINE_INFO_TYPE}
                onChange={onChangeText}
                size={'middle'}
              />
            )
          }
        />
        <Column
          title={MSG_TABLE_TITLE_TYPE}
          dataIndex="data_type"
          key="data_type"
          render={(_, record) => (
            <TableComponent.select
              target={'data_type'}
              record={record}
              options={dataOptions}
              onChange={onChangeText}
              type={DEFINE_INFO_TYPE}
              disabled={
                isEdit &&
                !(
                  record?.rec_type === 'DB' &&
                  record.output_column_val === 'custom'
                )
              }
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_DEFAULT}
          dataIndex="def_type"
          key="def_type"
          render={(_, record) => (
            <div css={{ display: 'flex' }}>
              <TableComponent.input
                target={'def_val'}
                record={record}
                onChange={onChangeText}
                type={DEFINE_INFO_TYPE}
                disabled={SelectDisable(record, 'def_type')}
              />
              <TableComponent.select
                target={'def_type'}
                record={record}
                options={typeOptions}
                onChange={onChangeText}
                type={DEFINE_INFO_TYPE}
              />
            </div>
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_DELETE}
          dataIndex="delete"
          key="delete"
          render={(_, record) => (
            <TableComponent.delete
              record={record}
              onChange={onChangeText}
              deleteHandler={deleteHandler}
              type={DEFINE_INFO_TYPE}
            />
          )}
        />
      </Table>
    </div>
  );
};
InfoConvertTable.propTypes = {
  dataSource: PropTypes.array,
  deleteHandler: PropTypes.func,
  dataOptions: PropTypes.array,
  typeOptions: PropTypes.array,
  onChangeText: PropTypes.func,
  moveInfoRow: PropTypes.func,
  components: PropTypes.object,
  log_data: PropTypes.array,
  columnOptions: PropTypes.array,
  isEdit: PropTypes.bool,
};
const HeaderConvertTable = ({
  dataSource,
  deleteHandler,
  dataOptions,
  typeOptions,
  columnOptions,
  onChangeText,
  moveHeaderRow,
  components,
  log_data,
  col_data,
  isEdit,
}) => {
  const enableCoefficient = (record) => {
    return record.data_type === 'float' || record.data_type === 'integer';
  };
  return (
    <div>
      <Table
        bordered
        components={components}
        pagination={false}
        size="small"
        rowKey="key"
        dataSource={dataSource}
        scroll={{ x: 'max-content' }}
        onRow={(record, index) => ({
          index,
          moveRow: moveHeaderRow,
        })}
      >
        <Column
          title={'Sort'}
          dataIndex="sort"
          key="idx"
          width="30"
          className="drag-visible"
          render={() => (
            <MenuOutlined style={{ cursor: 'grab', color: '#999' }} />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_INDEX}
          dataIndex="idx"
          key="idx"
          render={(_, row, index) => {
            return <>{index + 1}</>;
          }}
        />
        <Column
          title={MSG_TABLE_TITLE_COLUMN}
          dataIndex="column"
          key="column"
          render={(_, row, index) => {
            return <>{log_data?.[`data_${index + 1}`] ?? ''}</>;
          }}
        />
        <Column
          title={MSG_TABLE_TITLE_DATA}
          dataIndex="data"
          key="data"
          render={(_, row, index) => {
            return <>{col_data?.[`data_${index + 1}`] ?? ''}</>;
          }}
        />
        <Column
          title={MSG_TABLE_TITLE_NAME}
          dataIndex="name"
          key="name"
          render={(_, record) => (
            <TableComponent.input
              target={'name'}
              record={record}
              onChange={onChangeText}
              type={DEFINE_HEADER_TYPE}
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_OUTPUT}
          dataIndex="output_column"
          key="output_column"
          render={(_, record) =>
            isEdit ? (
              <div css={{ display: 'flex' }}>
                <TableComponent.input
                  target={'output_column'}
                  record={record}
                  type={DEFINE_HEADER_TYPE}
                  onChange={onChangeText}
                  disabled={
                    !(
                      record.rec_type === 'DB' &&
                      record.output_column_val === 'custom'
                    )
                  }
                />
                <TableComponent.select
                  target={'output_column_val'}
                  record={record}
                  type={DEFINE_HEADER_TYPE}
                  onChange={onChangeText}
                  options={columnOptions}
                />
              </div>
            ) : (
              <TableComponent.input
                target={'output_column'}
                record={record}
                type={DEFINE_HEADER_TYPE}
                onChange={onChangeText}
                size={'middle'}
              />
            )
          }
        />
        <Column
          title={MSG_TABLE_TITLE_TYPE}
          dataIndex="data_type"
          key="data_type"
          render={(_, record) => (
            <TableComponent.select
              target={'data_type'}
              record={record}
              options={dataOptions}
              onChange={onChangeText}
              type={DEFINE_HEADER_TYPE}
              disabled={
                isEdit &&
                !(
                  record?.rec_type === 'DB' &&
                  (record?.output_column_val ?? '') === 'custom'
                )
              }
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_DEFAULT}
          dataIndex="def_type"
          key="def_type"
          render={(_, record) => (
            <div css={{ display: 'flex' }}>
              <TableComponent.input
                target={'def_val'}
                record={record}
                disabled={SelectDisable(record, 'def_type')}
                onChange={onChangeText}
                type={DEFINE_HEADER_TYPE}
              />
              <TableComponent.select
                target={'def_type'}
                record={record}
                options={typeOptions}
                onChange={onChangeText}
                type={DEFINE_HEADER_TYPE}
              />
            </div>
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_COEFFICIENT}
          dataIndex="coef"
          key="coef"
          render={(_, record) => (
            <TableComponent.input
              target={'coef'}
              record={record}
              onChange={onChangeText}
              type={DEFINE_HEADER_TYPE}
              disabled={!enableCoefficient(record)}
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_UNIT}
          dataIndex="unit"
          key="unit"
          render={(_, record) => (
            <TableComponent.input
              target={'DEFINE_HEADER_TYPE'}
              record={record}
              onChange={onChangeText}
              type={DEFINE_HEADER_TYPE}
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_DELETE}
          dataIndex="delete"
          key="delete"
          render={(_, record) => (
            <TableComponent.delete
              record={record}
              deleteHandler={deleteHandler}
              type={DEFINE_HEADER_TYPE}
            />
          )}
        />
      </Table>
    </div>
  );
};
HeaderConvertTable.propTypes = {
  dataSource: PropTypes.array,
  deleteHandler: PropTypes.func,
  dataOptions: PropTypes.array,
  typeOptions: PropTypes.array,
  onChangeText: PropTypes.func,
  moveHeaderRow: PropTypes.func,
  components: PropTypes.object,
  log_data: PropTypes.array,
  col_data: PropTypes.array,
  columnOptions: PropTypes.array,
  isEdit: PropTypes.bool,
};
const CustomConvertTable = ({
  dataSource,
  deleteHandler,
  dataOptions,
  typeOptions,
  columnOptions,
  onChangeText,
  isEdit,
}) => {
  return (
    <div>
      <Table
        bordered
        pagination={false}
        size="small"
        rowKey="key"
        dataSource={dataSource}
        scroll={{ x: 'max-content' }}
      >
        <Column
          title={MSG_TABLE_TITLE_INDEX}
          dataIndex="idx"
          key="idx"
          render={(_, row, index) => {
            return <>{index + 1}</>;
          }}
        />
        <Column
          title={MSG_TABLE_TITLE_NAME}
          dataIndex="name"
          key="name"
          render={(_, record) => (
            <TableComponent.input
              target={'name'}
              record={record}
              type={DEFINE_CUSTOM_TYPE}
              onChange={onChangeText}
              size={'middle'}
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_OUTPUT}
          dataIndex="output_column"
          key="output_column"
          render={(_, record) =>
            isEdit ? (
              <div css={{ display: 'flex' }}>
                <TableComponent.input
                  target={'output_column'}
                  record={record}
                  type={DEFINE_CUSTOM_TYPE}
                  onChange={onChangeText}
                  disabled={
                    !(
                      record.rec_type === 'DB' &&
                      record.output_column_val === 'custom'
                    )
                  }
                />
                <TableComponent.select
                  target={'output_column_val'}
                  record={record}
                  type={DEFINE_CUSTOM_TYPE}
                  onChange={onChangeText}
                  options={columnOptions}
                />
              </div>
            ) : (
              <TableComponent.input
                target={'output_column'}
                record={record}
                type={DEFINE_CUSTOM_TYPE}
                onChange={onChangeText}
                size={'middle'}
              />
            )
          }
        />
        <Column
          title={MSG_TABLE_TITLE_TYPE}
          dataIndex="data_type"
          key="data_type"
          render={(_, record) => (
            <TableComponent.select
              target={'data_type'}
              record={record}
              options={dataOptions}
              type={DEFINE_CUSTOM_TYPE}
              onChange={onChangeText}
              disabled={
                isEdit &&
                !(
                  record?.rec_type === 'DB' &&
                  record.output_column_val === 'custom'
                )
              }
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_DEFAULT}
          dataIndex="def_type"
          key="def_type"
          render={(_, record) => (
            <div css={{ display: 'flex' }}>
              <TableComponent.input
                target={'def_val'}
                record={record}
                type={DEFINE_CUSTOM_TYPE}
                onChange={onChangeText}
                disabled={SelectDisable(record, 'def_type')}
              />
              <TableComponent.select
                target={'def_type'}
                record={record}
                options={typeOptions}
                type={DEFINE_CUSTOM_TYPE}
                onChange={onChangeText}
              />
            </div>
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_DELETE}
          dataIndex="delete"
          key="delete"
          render={(_, record) => (
            <TableComponent.delete
              record={record}
              deleteHandler={deleteHandler}
              type={DEFINE_CUSTOM_TYPE}
            />
          )}
        />
      </Table>
    </div>
  );
};
CustomConvertTable.propTypes = {
  dataSource: PropTypes.array,
  deleteHandler: PropTypes.func,
  dataOptions: PropTypes.array,
  typeOptions: PropTypes.array,
  onChangeText: PropTypes.func,
  columnOptions: PropTypes.array,
  isEdit: PropTypes.bool,
};
const custom_Basic = [
  'name',
  'output_column',
  'data_type',
  'def_val',
  'def_type',
].reduce((obj, cur) => {
  return { ...obj, [cur]: '' };
}, {});
const info_Basic = [
  'name',
  'output_column',
  'data_type',
  'def_val',
  'def_type',
  'row_index',
].reduce((obj, cur) => {
  return { ...obj, [cur]: '' };
}, {});
const headerBasic = [
  'name',
  'output_column',
  'data_type',
  'coef',
  'def_val',
  'def_type',
  'unit',
].reduce((obj, cur) => {
  return { ...obj, [cur]: '' };
}, {});
const basicColumn = (type) =>
  type === DEFINE_HEADER_TYPE
    ? headerBasic
    : type === DEFINE_INFO_TYPE
    ? info_Basic
    : custom_Basic;

const ConvertSetting = ({ data }) => {
  const {
    ruleStepConfig,
    updateConvertInfo,
    convertStepInfo,
  } = useRuleSettingInfo();
  const [config, setConfig] = useState(null);
  const [convertData, setConvertData] = useState({
    log_define: {},
    info: [],
    header: [],
    custom: [],
  });
  const { log_header, log_data } = data;
  const [form] = Form.useForm();
  const [selectRows, setSelectRows] = useState(undefined);
  const [ruleBase, setRuleBase] = useState({});
  const [columnOptions, setColumnOptions] = useState({
    info: [],
    header: [],
    custom: [],
  });

  const setDeboundcedText = useDebouncedCallback(
    ({ target, record, value, type }) =>
      onInputChange({ target, record, value, type }),
    100,
  );

  const onChangeText = ({ record, target, value, type }) => {
    setDeboundcedText({ record, target, value, type });
  };
  useEffect(() => {
    updateConvertInfo(convertData);
  }, [convertData]);
  const handleCheck = (record, type) => {
    let tmpDataSource = [];
    if (record.key !== selectRows[type]) {
      let fIdx = 0;
      tmpDataSource = Object.values(record)
        .map((item, idx) => {
          fIdx = type === DEFINE_INFO_TYPE && item === null ? fIdx : idx;
          return type === DEFINE_HEADER_TYPE
            ? { ['key']: idx, ...basicColumn(type) }
            : {
                ...basicColumn(type),
                ['row_index']: parseInt(record.key) + 1,
                ['key']: idx,
              };
        })
        .filter((item, idx) => idx > 0 && fIdx >= idx);
      setSelectRows((prev) => ({ ...prev, [type]: record.key }));
    } else {
      setSelectRows((prev) => ({ ...prev, [type]: '' }));
    }
    setConvertData((prev) => ({
      ...prev,
      [type]: tmpDataSource,
      selectRows: {
        ...prev.selectRows,
        [type]: record.key !== selectRows[type] ? record.key : '',
      },
    }));
  };
  const handleDelete = (key, type) => {
    const modified = convertData[type].filter((item) => item.key !== key);
    setConvertData((prev) => ({
      ...prev,
      [type]: modified,
    }));
  };
  const handleAdd = (type) => {
    const newData = { ['key']: '', ...basicColumn(type) };
    const keyList = convertData[type]?.map((obj) => obj.key);
    const maxKeyValue =
      keyList.length === 0
        ? 0
        : Math.max(...convertData[type]?.map((obj) => obj.key));
    newData.key = maxKeyValue + 1;
    setConvertData((prev) => ({
      ...prev,
      [type]: [...convertData[type], newData],
    }));
  };
  const checkBox = (record, type) => {
    return (
      <Checkbox
        checked={selectRows[type] === record.key}
        onChange={() => handleCheck(record, type)}
        style={{ width: 30, margin: '0 8px' }}
      />
    );
  };
  const onInputChange = ({ target, record, value, type }) => {
    const updateColumn =
      target === 'output_column_val'
        ? config.columns?.find((obj) => obj.column_name === value) ?? undefined
        : undefined;
    const modifiedDataSource =
      type === 'log_define'
        ? { ...convertData[type], [target]: value }
        : convertData[type].map((obj) =>
            obj.key === record.key
              ? target === 'def_type' &&
                value !== 'custom' &&
                value !== 'text' &&
                value !== 'lambda'
                ? { ...obj, ['def_val']: value, [target]: value }
                : target === 'output_column_val'
                ? {
                    ...obj,
                    ['rec_type']: updateColumn === undefined ? '' : 'DB',
                    [target]: value,
                    ['output_column']: value === 'custom' ? '' : value,
                    ['data_type']:
                      value === 'custom'
                        ? ''
                        : updateColumn?.data_type ?? record.data_type,
                  }
                : { ...obj, [target]: value }
              : obj,
          );
    setConvertData((prevState) => ({
      ...prevState,
      [type]: modifiedDataSource,
    }));
    if (target === 'rule_selected') {
      const request = async (log_name) => {
        const findObj =
          convertStepInfo?.log_define?.rule_base?.find(
            (obj) => obj.rule_name === value,
          ) ?? {};
        try {
          const { info, status } = await getRequest(
            `${URL_RESOURCE}/${log_name}/${findObj.id}`,
          );

          if (status.toString() === RESPONSE_OK) {
            setConvertData((prevState) => ({
              ...prevState,
              info:
                sortArrayOfObjects(info?.convert?.info ?? [], 'col_index').map(
                  (obj, index) => {
                    return { ...obj, key: index + 1 };
                  },
                ) ?? [],
              header:
                sortArrayOfObjects(
                  info?.convert?.header ?? [],
                  'col_index',
                ).map((obj, index) => {
                  return { ...obj, key: index + 1 };
                }) ?? [],
              custom:
                info?.convert?.custom?.map((obj, index) => {
                  return { ...obj, key: index + 1 };
                }) ?? [],
            }));
            setConfig((prev) => ({
              ...prev,
              data_type: info.convert?.data_type ?? [],
              def_type: info.convert?.def_type ?? [],
              columns: info.convert?.columns ?? [],
            }));
            console.log(info);
          }
        } catch (e) {
          if (e.response) {
            const {
              data: { msg },
            } = e.response;
            console.log(e.response);
            NotificationBox('ERROR', msg, 4.5);
          }
        }
      };
      const { log_name } = convertStepInfo.log_define;
      if (log_name ?? false) {
        request(log_name).then(console.log('=============='));
      }
      setRuleBase((prevState) => ({
        ...prevState,
        selected: value,
      }));
    }
  };
  const samplelogColumns = [
    {
      title: MSG_STEP3_INFO,
      dataIndex: 'info',
      key: 'info',
      // eslint-disable-next-line react/display-name
      render: (_, record) => checkBox(record, DEFINE_INFO_TYPE),
    },
    {
      title: MSG_STEP3_HEADERS,
      dataIndex: 'header',
      key: 'header',
      // eslint-disable-next-line react/display-name
      render: (_, record) => checkBox(record, DEFINE_HEADER_TYPE),
    },
  ];

  useEffect(() => {
    const clone = { ...convertStepInfo };
    console.log('[STEP3]data: ', data);
    const step3 = ruleStepConfig.find((item) => item.step === E_STEP_3);
    setConfig(step3.config.convert);
    setColumnOptions({
      info: [
        ...(step3.config?.convert?.info?.map((obj) => {
          return { column_name: obj.output_column, data_type: obj.data_type };
        }) ?? []),
        { column_name: 'custom', data_type: '' },
      ],
      header: [
        ...(step3.config?.convert?.header?.map((obj) => {
          return { column_name: obj.output_column, data_type: obj.data_type };
        }) ?? []),
        { column_name: 'custom', data_type: '' },
      ],
      custom: [
        ...(step3.config?.convert?.custom?.map((obj) => {
          return { column_name: obj.output_column, data_type: obj.data_type };
        }) ?? []),
        { column_name: 'custom', data_type: '' },
      ],
    });
    if (clone?.selectRows ?? false) {
      setSelectRows(clone.selectRows);
    } else {
      setSelectRows({ DEFINE_INFO_TYPE: '', DEFINE_HEADER_TYPE: '' });
    }
    setConvertData(clone);
    setRuleBase({
      options:
        convertStepInfo?.log_define?.rule_base?.map((opt) => opt.rule_name) ??
        [],
      selected: convertStepInfo?.log_define?.rule_selected ?? '',
    });
  }, []);

  const moveHeaderRow = useCallback(
    (dragIndex, hoverIndex) => {
      const dragRow = convertData.header[dragIndex];
      setConvertData(
        update(convertData, {
          header: {
            $splice: [
              [dragIndex, 1],
              [hoverIndex, 0, dragRow],
            ],
          },
        }),
      );
    },
    [convertData.header],
  );
  const moveInfoRow = useCallback(
    (dragIndex, hoverIndex) => {
      const dragRow = convertData.info[dragIndex];
      setConvertData(
        update(convertData, {
          info: {
            $splice: [
              [dragIndex, 1],
              [hoverIndex, 0, dragRow],
            ],
          },
        }),
      );
    },
    [convertData.info],
  );
  const components = {
    body: {
      row: DraggableBodyRow,
    },
  };
  if (config === null) return <></>;
  return (
    <div css={{ maxWidth: '85%', minWidth: '75%' }}>
      <Collapse defaultActiveKey={[1, 2, 3]}>
        <Panel header={MSG_STEP3_LOG_DEFINE} key="1">
          <div css={formWrapper}>
            <div>
              <InputForm.input
                formLabel={'Log Name'}
                formName={'log_name'}
                disabled={
                  (convertStepInfo?.mode ?? 'new') === 'add' ||
                  (convertStepInfo?.mode ?? 'new') === 'edit'
                }
                changeFunc={(e) =>
                  onChangeText({
                    target: 'log_name',
                    type: 'log_define',
                    value: getParseData(e).value,
                  })
                }
                value={convertStepInfo.log_define?.log_name ?? ''}
              />
            </div>
            <div>
              <InputForm.input
                formLabel={'Table Name'}
                formName={'table_name'}
                disabled={
                  (convertStepInfo?.mode ?? 'new') === 'add' ||
                  (convertStepInfo?.mode ?? 'new') === 'edit'
                }
                changeFunc={(e) =>
                  onChangeText({
                    target: 'table_name',
                    type: 'log_define',
                    value: getParseData(e).value,
                  })
                }
                value={convertStepInfo.log_define?.table_name ?? ''}
              />
            </div>
            <div>
              <InputForm.input
                formLabel={'Rule Name'}
                formName={'rule_name'}
                changeFunc={(e) =>
                  onChangeText({
                    target: 'rule_name',
                    type: 'log_define',
                    value: getParseData(e).value,
                  })
                }
                value={convertStepInfo.log_define?.rule_name ?? ''}
              />
            </div>
            <div>
              {convertStepInfo.mode === 'add' ? (
                <InputForm.select
                  formLabel={'Rule Base'}
                  formName={'rule_base'}
                  options={ruleBase?.options ?? []}
                  required={false}
                  disabled={(convertStepInfo?.mode ?? 'new') === 'edit'}
                  changeFunc={(e) =>
                    onChangeText({
                      target: 'rule_selected',
                      type: 'log_define',
                      value: getParseData(e).value,
                    })
                  }
                  defaultV={ruleBase?.selected ?? ''}
                />
              ) : (
                <></>
              )}
            </div>
          </div>
        </Panel>
        <Panel header={MSG_STEP3_SELECT} key="2">
          {log_header !== undefined ? (
            <div
              style={{
                fontWeight: '14px',
                margin: '10px',
                display: 'flex',
                justifyContent: 'space-around',
              }}
            >
              <Table
                bordered
                pagination={false}
                columns={[...samplelogColumns, ...log_header]}
                dataSource={log_data ?? []}
                size="small"
                rowKey="key"
                scroll={{ x: true }}
              />
            </div>
          ) : (
            <div></div>
          )}
        </Panel>
        <Panel header={MSG_STEP3_DEFINE} key="3">
          <Form form={form} layout="vertical">
            <Form.Item
              label={MSG_STEP3_INFO}
              required
              tooltip={MSG_REQUIRED_TOOLTIP}
            >
              <Button
                onClick={() => handleAdd(DEFINE_INFO_TYPE)}
                type="primary"
                style={{
                  marginBottom: 16,
                }}
              >
                Add a row
              </Button>
              <div css={tableWrapper}>
                <DndProvider backend={HTML5Backend}>
                  <InfoConvertTable
                    dataSource={convertData.info}
                    typeOptions={config?.def_type ?? []}
                    dataOptions={config?.data_type ?? []}
                    columnOptions={
                      columnOptions?.info.map((obj) => obj.column_name) ?? []
                    }
                    moveInfoRow={moveInfoRow}
                    components={components}
                    deleteHandler={handleDelete}
                    onChangeText={onChangeText}
                    isEdit={Boolean(convertStepInfo.mode === 'edit')}
                    log_data={log_data?.find(
                      (row) => row.key === selectRows[DEFINE_INFO_TYPE],
                    )}
                  />
                </DndProvider>
              </div>
            </Form.Item>
            <Form.Item
              label={MSG_STEP3_HEADERS}
              required
              tooltip={MSG_REQUIRED_TOOLTIP}
            >
              <Button
                onClick={() => handleAdd(DEFINE_HEADER_TYPE)}
                type="primary"
                style={{
                  marginBottom: 16,
                }}
              >
                Add a row
              </Button>
              <div css={tableWrapper}>
                <DndProvider backend={HTML5Backend}>
                  <HeaderConvertTable
                    dataSource={convertData.header}
                    typeOptions={config?.def_type ?? []}
                    dataOptions={config?.data_type ?? []}
                    columnOptions={
                      columnOptions?.header.map((obj) => obj.column_name) ?? []
                    }
                    moveHeaderRow={moveHeaderRow}
                    components={components}
                    deleteHandler={handleDelete}
                    onChangeText={onChangeText}
                    log_data={log_data?.find(
                      (row) => row.key === selectRows[DEFINE_HEADER_TYPE],
                    )}
                    col_data={
                      log_data?.[
                        log_data?.findIndex(
                          (row) => row.key === selectRows[DEFINE_HEADER_TYPE],
                        ) + 1
                      ] ?? []
                    }
                    isEdit={Boolean(convertStepInfo.mode === 'edit')}
                  />
                </DndProvider>
              </div>
            </Form.Item>
            <Form.Item label={MSG_STEP3_CUSTOM}>
              <Button
                onClick={() => handleAdd(DEFINE_CUSTOM_TYPE)}
                type="primary"
                style={{
                  marginBottom: 16,
                }}
              >
                Add a row
              </Button>
              <div css={tableWrapper}>
                <CustomConvertTable
                  dataSource={convertData.custom}
                  typeOptions={config?.def_type ?? []}
                  dataOptions={config?.data_type ?? []}
                  columnOptions={
                    columnOptions?.custom.map((obj) => obj.column_name) ?? []
                  }
                  deleteHandler={handleDelete}
                  onChangeText={onChangeText}
                  isEdit={Boolean(convertStepInfo.mode === 'edit')}
                />
              </div>
            </Form.Item>
          </Form>
        </Panel>
      </Collapse>
    </div>
  );
};
ConvertSetting.propTypes = {
  data: PropTypes.object,
};
export default ConvertSetting;
