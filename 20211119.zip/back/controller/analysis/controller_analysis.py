import os
import logging
from flask import request, Response
from flask_restx import Resource, Namespace, fields
import requests
import pandas as pd
from io import StringIO

from config.app_config import *
from service.analysis.service_analysis import AnalysisService
from service.script.service_script import ScriptService
from dao.dao_management_setting import DAOMGMTSetting
from dao.dao_base import DAOBaseClass
from dao.dao_function import DAOFunction
from common.utils.response import make_json_response, ResponseForm
from common.utils import parameter
from controller.converter.converter import create_request_id
from dao.dao_history import DAOHistory
from dao.dao_job import DAOJob
import convert as lc

logger = logging.getLogger(LOG)

ANALYSIS = Namespace(name='ANALYSIS', description='ログ分析用API。')

analysis_body = ANALYSIS.model('analysis_body', {
    'log_name': fields.String(description='ログ名', example='PLATEAUTOFOCUSCOMPENSATION'),
    'source': fields.String(description='[local, DB]', example='local'),
    'target_path': fields.String(description='フォルダ経路',
                                 example='P:/log_sample/server_log_path/BSOT/s2/SBPCN480/PLATEAUTOFOCUSCOMPENSATION'),
    'model': fields.String(description='ログフォーマット区分のためのモデル名', example='E813'),
    'one_period': fields.String(description='指定時間を1個のperiodで区分 [12, 24]', example='24'),
    'adjust_period': fields.String(description='periodを区分するための基準時間', example='0'),
    'first_half_year': fields.String(description='ログにyear情報がない場合、1～6月のデータのyear設定', example='2021'),
    'second_half_year': fields.String(description='ログにyear情報がない場合、7～12月のデータのyear設定. [Same Year, Last Year]',
                                      example='Same Year'),
})

analysis_list_response = ANALYSIS.model('analysis_list_response', {
    'items': fields.List(fields.Raw(example={'target': 'one_period',
                                             'title': 'One Period(hour)',
                                             'type': 'select',
                                             'mode': 'singular',
                                             'options': ['12h', '24h'],
                                             'selected': '24h'}, description='target:파라미터명, title:타이틀, '
                                                                              'type:옵션 아이템타입, mode:옵션 아이템 모드, '
                                                                              'options:선택옵션, selected:선택된 옵션'),
                         description='설정 가능한 아이템 리스트'),
    'data': fields.List(fields.Raw(description='start:시작날짜, end:종료날짜, job_list:장치리스트',
                                   example={'start': '2017-05-11 00:00:00',
                                            'end': '2017-05-11 23:59:59',
                                            'job_list': ['SCAN3X2/SCANDBG']}),
                        description='기간별 데이터를 리스트로 반환'),
})

analysis_summary_response = ANALYSIS.model('analysis_summary_response', {
    'items': fields.List(fields.Raw(example={'target': 'valid_interval_minutes',
                                             'title': 'Valid Interval(Min)',
                                             'type': 'select',
                                             'mode': 'singular',
                                             'options': ['1', '2'],
                                             'selected': None}, description='target:파라미터명, title:타이틀, '
                                                                              'type:옵션 아이템타입, mode:옵션 아이템 모드, '
                                                                              'options:선택옵션, selected:선택된 옵션'),
                        description='설정 가능한 아이템 리스트'),
    'data': fields.Raw(example={'disp_order': [], 'summary': {'index 0~ALL': {'column名': '値'}}},
                       description='disp_order:컬럼표시순서, summary:표시 데이터'),
})

analysis_detail_response = ANALYSIS.model('analysis_detail_response', {
    'data': fields.Raw(example={'disp_order': [], 'detail': {'index 0~': {'column名': '値'}}},
                       description='disp_order:컬럼표시순서, detail:표시 데이터'),
})

analysis_remote_response = ANALYSIS.model('analysis_remote_response', {
    'rid': fields.String(description='Request ID', example='request_YYYYMMDD_hhmmssssssss')
})


@ANALYSIS.route('/default/local/<int:func_id>/<string:rid>')
@ANALYSIS.route('/default/remote/<int:func_id>/<string:rid>')
@ANALYSIS.route('/default/sql/<int:func_id>/<string:rid>')
@ANALYSIS.param('func_id', 'Function ID')
@ANALYSIS.param('rid', 'Request ID')
class GetAnalyisDefault(Resource):
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    def get(self, func_id, rid):
        """
        Get Log Period(Start, End) and Filter Setting Information
        """
        logger.info(str(request))

        try:
            analysis = AnalysisService()
            resp_form = analysis.get_analysis_type(func_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            analysis_type = resp_form.data

            resp_form = analysis.get_options(func_id, rid)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            period_filter = resp_form.data

            aggregation = dict()
            if analysis_type['analysis_type'] == "setting":
                resp_form = analysis.get_aggregation_default(func_id, rid)
                if not resp_form.res:
                    return make_json_response(status=400, msg=resp_form.msg)

                aggregation = resp_form.data

            resp_form = analysis.get_visualization_default(func_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            visualization = resp_form.data

            options = {**analysis_type, **period_filter, **aggregation, **visualization}

            return make_json_response(**options)
        except Exception as e:
            return make_json_response(status=400, msg=str(e))


@ANALYSIS.route('/default/history/<int:func_id>/<int:history_id>')
@ANALYSIS.param('func_id', 'Function ID')
@ANALYSIS.param('history_id', 'History ID')
class GetHistoryDefault(Resource):
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    def get(self, func_id, history_id):
        """
        Get Log Period(Start, End) and Filter Setting Information
        """
        logger.info(str(request))

        try:
            dao_history = DAOHistory()
            resp_form = dao_history.get_rid(history_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            rid = resp_form.data

            analysis = AnalysisService()
            # resp_form = analysis.get_options(func_id, rid)
            # if not resp_form.res:
            #     return make_json_response(status=400, msg=resp_form.msg)
            #
            # period_filter = resp_form.data
            resp_form = analysis.get_analysis_type(func_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            analysis_type = resp_form.data

            resp_form = dao_history.get_period(history_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            period_selected = resp_form.data
            # period_filter['period']['selected'] = period_selected

            resp_form = dao_history.get_filter_info(history_id)
            if not resp_form.res:
                filter_selected = None
            else:
                filter_selected = resp_form.data
            # for filter_item in period_filter['filter']:
            #     key = filter_item['target']
            #     if key in filter_selected:
            #         filter_item['selected'] = filter_selected[key]

            # resp_form = analysis.get_aggregation_default(func_id)
            # if not resp_form.res:
            #     return make_json_response(status=400, msg=resp_form.msg)
            #
            # aggregation = resp_form.data

            resp_form = dao_history.get_aggregation_info(history_id)
            if not resp_form.res:
                aggregation = dict()
            else:
                aggregation = resp_form.data
            # aggregation_type = resp_form.data['type']
            # aggregation_val = resp_form.data['val']

            # aggregation['aggregation']['selected'] = aggregation_type
            # aggregation['aggregation']['subItem'][aggregation_type]['selected'] = aggregation_val

            resp_form = dao_history.get_visualization_info(history_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            visualization = resp_form.data

            infos = dict()
            filter_info = dict()
            filter_info['log_time'] = period_selected
            if filter_selected is not None:
                filter_info = {**filter_info, **filter_selected}

            infos['filter'] = filter_info

            infos['aggregation'] = aggregation

            resp_form = analysis.get_analysis(func_id, rid, **infos)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            options = {**analysis_type, **resp_form.data['option'], **visualization, 'data': resp_form.data['data']}
            return make_json_response(**options)
        except Exception as e:
            return make_json_response(status=400, msg=str(e))


@ANALYSIS.route('/lists/<string:log_name>/<string:job_id>')
@ANALYSIS.param('job_id', 'Job ID')
@ANALYSIS.param('log_name', 'Log Name')
class AnalysisLists(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('one_period', help='期間の時間単位(1h, 2h, 4h, 6h, 12h, 24h, 1d～, 1m～)')
    parser.add_argument('adj_period', help='期間の節目(0h-23h, 1d-31d, 0d:first day of log_list)')
    parser.add_argument('list_group', help='グループ表示方式(job, none)')

    @ANALYSIS.expect(parser)
    @ANALYSIS.doc(model=analysis_list_response)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    @ANALYSIS.response(500, 'Internal Server Error')
    def get(self, log_name, job_id):
        """
        Logデータを期間/グループで分類してリストで返還するAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        # todo 파라미터 default값을 가져와서 설정해줘야한다.
        default_setting = get_default_setting(log_name)
        if args['one_period'] is None:
            args['one_period'] = default_setting['one_period']
        if args['adj_period'] is None:
            args['adj_period'] = default_setting['adj_period']
        if args['list_group'] is None:
            args['list_group'] = default_setting['list_group']

        logger.debug(f'args: {args}')

        # パラメータの妥当性チェック
        res, msg = parameter.is_period_valid(args['one_period'], args['adj_period'])
        if not res:
            logger.debug(msg)
            return make_json_response(msg=msg, status=400)

        analysis = AnalysisService()
        res_form = analysis.get_list(log_name, job_id, args['one_period'], args['adj_period'], args['list_group'])
        if res_form.res:
            data = res_form.data[0]
            job_info_contained = res_form.data[1]
            items = self.get_list_items().data
            for item in items:
                item['selected'] = args[item['target']]
                if item['mode'] == 'subItem':
                    item['subItem']['selected'] = args[item['subItem']['target']]

                if item['target'] == 'list_group':
                    if job_info_contained:
                        item['options'].append('job')

            return make_json_response(items=items, data=data)
        else:
            logger.debug(f'get list failed : {res_form.msg}')
            return make_json_response(status=500, msg=res_form.msg)

    def get_list_items(self):
        return ResponseForm(res=True, data=
        [
            {
                'target': 'one_period',
                'title': 'One Period',
                'type': 'select',
                'mode': 'subItem',
                'options': ['12h', '24h', '7d', '14d', '1m'],
                'subItem': {
                    'target': 'adj_period',
                    'title': 'Adjust Period',
                    'type': 'select',
                    'mode': 'singular',
                    'options': [
                        {'12h': ['0h', '1h', '2h', '3h', '4h', '5h', '6h', '7h', '8h', '9h', '10h', '11h',
                                 '12h', '13h', '14h', '15h', '16h', '17h', '18h', '19h', '20h', '21h', '22h',
                                 '23h']},
                        {'24h': ['0h', '1h', '2h', '3h', '4h', '5h', '6h', '7h', '8h', '9h', '10h', '11h',
                                 '12h', '13h', '14h', '15h', '16h', '17h', '18h', '19h', '20h', '21h', '22h',
                                 '23h']},
                        {
                            '7d': ['0d', '1d', '2d', '3d', '4d', '5d', '6d', '7d', '8d', '9d', '10d',
                                   '11d', '12d', '13d', '14d', '15d', '16d', '17d', '18d', '19d', '20d',
                                   '21d', '22d', '23d', '24d', '25d', '26d', '27d', '28d', '29d', '30d', '31d']
                        },
                        {
                            '14d': ['0d', '1d', '2d', '3d', '4d', '5d', '6d', '7d', '8d', '9d', '10d',
                                    '11d', '12d', '13d', '14d', '15d', '16d', '17d', '18d', '19d', '20d',
                                    '21d', '22d', '23d', '24d', '25d', '26d', '27d', '28d', '29d', '30d', '31d']
                        },
                        {
                            '1m': ['0d', '1d', '2d', '3d', '4d', '5d', '6d', '7d', '8d', '9d', '10d',
                                   '11d', '12d', '13d', '14d', '15d', '16d', '17d', '18d', '19d', '20d',
                                   '21d', '22d', '23d', '24d', '25d', '26d', '27d', '28d', '29d', '30d', '31d']
                        }
                    ],
                    'selected': None
                },
                'selected': None
            },
            {
                'target': 'list_group',
                'title': 'List Group',
                'type': 'select',
                'mode': 'singular',
                'options': [],
                'selected': None
            }
        ])


@ANALYSIS.route('/<int:func_id>/<string:rid>')
@ANALYSIS.param('func_id', 'Fuction ID')
@ANALYSIS.param('rid', 'Request ID')
class GetAnalysis(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('start', required=True, help='期間の開始時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('end', required=True, help='期間の終了時間(YYYY-MM-DD hh:mm:ss)')

    @ANALYSIS.expect(parser)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(500, 'Internal Server Error')
    def get(self, func_id, rid):
        """
        期間/グループ別LOGデータの分析結果を返還するAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()
        param_dict = request.args.to_dict(flat=False)  # flat: to get list values

        for key in ['start', 'end']:
            if key in param_dict:
                param_dict.pop(key)

        filter = dict()
        filter['log_time'] = args

        if 'filter_key' in param_dict:
            for key in param_dict['filter_key']:
                if key in param_dict:
                    param_dict[key] = [val for val in param_dict[key] if val != '' and val != 'null']
                    if len(param_dict[key]) > 0:
                        filter[key] = param_dict[key]

        infos = dict()
        infos['filter'] = filter

        aggregation = dict()
        if 'aggregation_key' in param_dict:
            if 'aggregation_val' in param_dict:
                aggregation['type'] = param_dict['aggregation_key'][0]
                aggregation['val'] = param_dict['aggregation_val'][0]
            else:
                aggregation['type'] = param_dict['aggregation_key'][0]
                aggregation['val'] = None

        infos['aggregation'] = aggregation

        analysis = AnalysisService()

        res_form = analysis.get_analysis(func_id, rid, **infos)
        if res_form.res:
            return make_json_response(**res_form.data)
        else:
            logger.debug(f'get summary failed : {res_form.msg}')
            return make_json_response(status=500, msg=res_form.msg)


@ANALYSIS.route('/data/<int:func_id>/<string:rid>')
@ANALYSIS.param('func_id', 'Function ID')
@ANALYSIS.param('rid', 'Request ID')
class AnalysisDetail(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('start', required=True, help='期間の開始時間(YYYY-MM-DD hh:mm:ss)')
    parser.add_argument('end', required=True, help='期間の終了時間(YYYY-MM-DD hh:mm:ss)')

    @ANALYSIS.expect(parser)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(500, 'Internal Server Error')
    def get(self, func_id, rid):
        """
        期間/グループ別全体LOGデータを返還するAPI。
        """
        logger.info(str(request))

        args = self.parser.parse_args()
        param_dict = request.args.to_dict(flat=False)  # flat: to get list values

        for key in ['start', 'end']:
            if key in param_dict:
                param_dict.pop(key)

        filter = dict()
        filter['log_time'] = {'start': args['start'], 'end': args['end']}

        if 'filter_key' in param_dict:
            for key in param_dict['filter_key']:
                if key in param_dict:
                    param_dict[key] = [val for val in param_dict[key] if val != '' and val != 'null']
                    if len(param_dict[key]) > 0:
                        filter[key] = param_dict[key]

        infos = dict()
        infos['filter'] = filter

        aggregation = dict()
        if 'aggregation_key' in param_dict and 'aggregation_val' in param_dict and 'selected' in param_dict:
            aggregation['type'] = param_dict['aggregation_key'][0]
            aggregation['val'] = param_dict['aggregation_val'][0]
            aggregation['selected'] = param_dict['selected']

        infos['aggregation'] = aggregation

        analysis = AnalysisService()

        res_form = analysis.get_detail(func_id, rid, **infos)
        if res_form.res:
            return make_json_response(**res_form.data)
        else:
            logger.debug(f'get detail failed : {res_form.msg}')
            return make_json_response(status=500, msg=res_form.msg)

def get_default_setting(log_name):
    if log_name == 'PLATEAUTOFOCUSCOMPENSATION':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': 'job',
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'column', 'group_value': 'lot_id'}
    elif log_name == 'PRESCANCOMPENSATIONMONITOR':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': 'job',
                # 'valid_interval_minutes': None, 'filter_key': 'step_no', 'filter_value': '1',
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'column', 'group_value': 'lot_id'}
    elif log_name == 'LiPSFocus':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': None,
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'period', 'group_value': '4h'}
    elif log_name == 'TiltMeasurementLog':
        return {'one_period': '1m', 'adj_period': '0d', 'list_group': None,
                'valid_interval_minutes': None, 'filter_key': None, 'filter_value': None,
                'group_by': 'period', 'group_value': '1d'}
    elif log_name == 'MountPressLog':
        return {'one_period': '24h', 'adj_period': '0h', 'list_group': None,
                'valid_interval_minutes': None, 'filter_key': 'status', 'filter_value': 'Job',
                'group_by': 'period', 'group_value': '4h'}


@ANALYSIS.route('/remote/<int:func_id>')
@ANALYSIS.param('func_id', 'Function ID')
class AnalysisRemote(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('db_id', required=True, location='json', help='Database ID')
    parser.add_argument('equipment_name', required=True, location='json', help='Equipment Name')
    parser.add_argument('period', required=True, location='json', help='LOG取得期間(YYYY-MM-DD~YYYY-MM-DD)')

    @ANALYSIS.expect(parser)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    @ANALYSIS.response(500, 'Internal Server Error')
    def post(self, func_id):
        """
        遠隔LOGを取得して内部Fileに格納する。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        logger.debug(f'args : {args}')

        try:
            res_form = AnalysisService().get_remote_log(func_id, **{**args, 'source': 'remote'})
            if res_form.res:
                df_out = res_form.data

                rid = create_request_id()
                logger.debug(f'create request id : {rid}')

                io = DAOJob.instance()
                form = {
                    'id': rid,
                    'file': '0',
                    'log_name': None,
                    'job_type': 'local'
                }
                io.insert_job(**form)

                if not os.path.exists(CNV_RESULT_PATH):
                    os.mkdir(CNV_RESULT_PATH)

                result_path = os.path.join(CNV_RESULT_PATH, rid)
                if not os.path.exists(result_path):
                    os.mkdir(result_path)

                path = os.path.join(result_path, 'log.csv')
                df_out.to_csv(path, header=True, index=False)

                script_service = ScriptService()
                script_service.make_script_file(func_id, rid)

                use_pre_script = script_service.get_use_pre_script(func_id)
                if use_pre_script:
                    resp_form = ScriptService().run_preprocess_script(file_path=path, rid=rid)
                    if not resp_form.res:
                        return make_json_response(status=400, msg=resp_form.msg)

                return make_json_response(rid=rid)
            else:
                logger.debug(f'get remote log failed : {res_form.msg}')
                return make_json_response(status=500, msg=res_form.msg)
        except Exception as e:
            return make_json_response(status=400, msg=str(e))


@ANALYSIS.route('/sql/<int:func_id>')
@ANALYSIS.param('func_id', 'Function ID')
class AnalysisRemote(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('db_id', required=True, location='json', help='Database ID')

    @ANALYSIS.expect(parser)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    @ANALYSIS.response(500, 'Internal Server Error')
    def post(self, func_id):
        """
        遠隔LOGを取得して内部Fileに格納する。
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        logger.debug(f'args : {args}')

        try:
            res_form = AnalysisService().get_remote_log(func_id, **{**args, 'source': 'sql'})
            if res_form.res:
                df_out = res_form.data

                rid = create_request_id()
                logger.debug(f'create request id : {rid}')

                io = DAOJob.instance()
                form = {
                    'id': rid,
                    'file': '0',
                    'log_name': None,
                    'job_type': 'local'
                }
                io.insert_job(**form)

                if not os.path.exists(CNV_RESULT_PATH):
                    os.mkdir(CNV_RESULT_PATH)

                result_path = os.path.join(CNV_RESULT_PATH, rid)
                if not os.path.exists(result_path):
                    os.mkdir(result_path)

                path = os.path.join(result_path, 'log.csv')
                df_out.to_csv(path, header=True, index=False)

                script_service = ScriptService()
                script_service.make_script_file(func_id, rid)

                use_pre_script = script_service.get_use_pre_script(func_id)
                if use_pre_script:
                    resp_form = ScriptService().run_preprocess_script(file_path=path, rid=rid)
                    if not resp_form.res:
                        return make_json_response(status=400, msg=resp_form.msg)

                return make_json_response(rid=rid)
            else:
                logger.debug(f'get remote log failed : {res_form.msg}')
                return make_json_response(status=500, msg=res_form.msg)
        except Exception as e:
            return make_json_response(status=400, msg=str(e))

@ANALYSIS.route('/history/<int:func_id>/<int:history_id>')
@ANALYSIS.param('func_id', 'Function ID')
@ANALYSIS.param('history_id', 'History ID')
class AnalysisHistory(Resource):
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    def get(self, func_id, history_id):
        """
        Return Request ID
        """
        logger.info(str(request))

        try:
            dao_history = DAOHistory()
            resp_form = dao_history.get_rid(history_id)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            rid = resp_form.data

            return make_json_response(rid=rid)

        except Exception as e:
            return make_json_response(status=400, msg=str(e))

@ANALYSIS.route('/history/new')
class SaveHistory(Resource):
    parser = ANALYSIS.parser()
    parser.add_argument('func_id', type=int, location='json', required=True, help='Function ID')
    parser.add_argument('log_from', type=str, location='json', required=True, help='local/remote')
    parser.add_argument('title', type=str, location='json', required=True, help='Title Info')
    parser.add_argument('period', type=dict, location='json', required=True, help='Period(Start~End)')
    parser.add_argument('filter', type=dict, location='json', required=True, help='Filter Info')
    parser.add_argument('aggregation', type=dict, location='json', required=True, help='Aggregation Info')
    parser.add_argument('visualization', type=dict, location='json', required=True, help='Visualization Info')
    parser.add_argument('local', type=dict, location='json', help='It contains Request ID.')
    parser.add_argument('remote', type=dict, location='json', help='It contains user_fab, equipment info.')

    @ANALYSIS.expect(parser)
    @ANALYSIS.response(200, 'Success')
    @ANALYSIS.response(400, 'Bad Request')
    def post(self):
        """
        Save History Info.
        """
        logger.info(str(request))

        args = self.parser.parse_args()

        history_id = None

        try:
            log_from = args['log_from']
            if log_from not in args:
                return make_json_response(status=400, msg=f"{log_from} key doesn't exist")

            dao_history = DAOHistory()

            infos = dict()
            infos['func_id'] = args['func_id']
            infos['period_start'] = args['period']['start']
            infos['period_end'] = args['period']['end']
            infos['log_from'] = args['log_from']
            infos['title'] = args['title']

            resp_form = dao_history.insert_history(**infos)
            if not resp_form.res:
                return make_json_response(status=400, msg=resp_form.msg)

            history_id = resp_form.data

            infos = dict()
            infos['history_id'] = history_id

            subinfo = dict()
            if log_from == 'local':
                subinfo['rid'] = args['local']['rid']
                resp_form = dao_history.insert_history_from_local(**{**infos, **subinfo})
            else:
                subinfo['equipment_name'] = args['remote']['equipment_name']
                # subinfo['user_fab'] = args['remote']['user_fab']
                subinfo['rid'] = args['remote']['rid']
                resp_form = dao_history.insert_history_from_remote(**{**infos, **subinfo})

            if not resp_form.res:
                dao_history.delete_history_id(history_id)
                return make_json_response(status=400, msg=resp_form.msg)

            filter = args['filter']
            for key, val in filter.items():
                if len(val) > 0:
                    for i in range(len(val)):
                        subinfo = dict()
                        subinfo['key'] = key
                        subinfo['val'] = val[i]
                        resp_form = dao_history.insert_filter_history(**{**infos, **subinfo})
                        if not resp_form.res:
                            dao_history.delete_history_id(history_id)
                            return make_json_response(status=400, msg=resp_form.msg)
                else:
                    subinfo = dict()
                    subinfo['key'] = key
                    # subinfo['val'] = None
                    resp_form = dao_history.insert_filter_history(**{**infos, **subinfo})
                    if not resp_form.res:
                        dao_history.delete_history_id(history_id)
                        return make_json_response(status=400, msg=resp_form.msg)

            aggregation = args['aggregation']
            for key, val in aggregation.items():
                subinfo = dict()
                subinfo['type'] = key
                subinfo['val'] = val
                resp_form = dao_history.insert_aggregation_history(**{**infos, **subinfo})
                if not resp_form.res:
                    dao_history.delete_history_id(history_id)
                    return make_json_response(status=400, msg=resp_form.msg)

            visualization = args['visualization']
            for item in visualization['items']:
                subinfo = dict()
                subinfo['title'] = item['title']
                subinfo['type'] = ','.join(item['type'])
                subinfo['x_axis'] = item['x_axis']
                subinfo['y_axis'] = item['y_axis']
                subinfo['z_axis'] = item['z_axis']
                subinfo['x_range_min'] = item['x_range_min']
                subinfo['x_range_max'] = item['x_range_max']
                subinfo['y_range_min'] = item['y_range_min']
                subinfo['y_range_max'] = item['y_range_max']
                subinfo['z_range_min'] = item['z_range_min']
                subinfo['z_range_max'] = item['z_range_max']
                resp_form = dao_history.insert_visualization_history(**{**infos, **subinfo})
                if not resp_form.res:
                    dao_history.delete_history_id(history_id)
                    return make_json_response(status=400, msg=resp_form.msg)

            return Response(status=200)
        except Exception as e:
            if history_id is not None:
                dao_history.delete_history_id(history_id)
            return make_json_response(status=400, msg=str(e))
