
# /api/resources
## :white\_check\_mark: GET /api/resources/new/step2  @신규추가 STEP2
front <<< back
```json
{
    "formList": [
        "local",
        "remote",
        "sql"
    ],
    "form": {
        "remote": [
            {
                "title": "1. Select Source",
                "items": [
                    {
                        "target": "source",
                        "title": "From",
                        "type": "select",
                        "mode": "singular",
                        "options": [
                            "local",
                            "remote",
                            "sql"
                        ]
                    }
                ]
            },
            {
                "title": "2. Select Data Source",
                "items": [
                    {
                        "target": "db_id",
                        "title": "From",
                        "type": "select",
                        "mode": "singular",
                        "options": [
                            {
                                "id": 1,
                                "name": ""
                            },
                            {
                                "id": 2,
                                "name": ""
                            }
                        ]
                     },
                     {
                         "target": "table_name",
                         "title": "",
                         "type": "select",
                         "mode": "singular",
                         "options": [

                         ]
                     }
                ]
            },
            {
                "target": "select_equipment",
                "title": "3. Select Equipment",
                "items": [
                    {
                        "target": "user_fab",
                        "title": "User/Fab",
                        "type": "select",
                        "mode": "subItem",
                        "options": [

                        ],
                        "subItem": {
                            "target": "equipment_name",
                            "title": "Equipment",
                            "type": "select",
                            "mode": "singular",
                            "options": [

                            ]
                        }
                    }
                ]
            },
            {
                "title": "4. Select Start/End Date",
                "items": [
                    {
                        "target": "period",
                        "title": "Period",
                        "type": "DatePicker"
                    }
                ]
            },
            {
                "title": "5. Select Preprocessing Script",
                "items": [
                    {
                        "target": "script",
                        "title": "Script File",
                        "type": "file"
                    },
                    {
                        "target": "use_script",
                        "title": "use script",
                        "type": "switch",
                        "value": false
                    }
                ]
            }
        ],
        "local": [
            {
                "title": "1. Select Source",
                "items": [
                    {
                        "target": "source",
                        "title": "From",
                        "type": "select",
                        "mode": "singular",
                        "options": [
                            "local",
                            "remote",
                            "sql"
                        ]
                    }
                ]
            },
            {
                "title": "2. Select Source Files",
                "items": [
                    {
                        "target": "src_file",
                        "title": "Log Files",
                        "type": "files",
                        "enable": true
                    }
                ]
            },
            {
                "title": "3. Select Log Type",
                "items": [
                    {
                        "target": "log_name",
                        "title": "Log Name",
                        "type": "select",
                        "content": "",
                        "mode": "singular",
                        "options": [
                            "TiltMeasurementLog"
                        ]
                    },
                    {
                        "target": "new_rule",
                        "title": "Add New Rule",
                        "type": "checkbox"
                    }
                ]
            },
            {
                "title": "4. Select Preprocessing Script",
                "items": [
                    {
                        "target": "script",
                        "title": "Script File",
                        "type": "file"
                    },
                    {
                        "target": "use_script",
                        "title": "use script",
                        "type": "switch",
                        "value": false
                    }
                ]
            }
        ],
        "sql": [
            {
                "title": "1. Select Source",
                "items": [
                    {
                        "target": "source",
                        "title": "From",
                        "type": "select",
                        "mode": "singular",
                        "options": [
                            "local",
                            "remote",
                            "sql"
                        ]
                    }
                ]
            },
            {
                "title": "2. Select Data Source",
                "items": [
                    {
                        "target": "db_id",
                        "title": "From",
                        "type": "select",
                        "mode": "singular",
                        "options": [
                            {
                                "id": 1,
                                "name": ""
                            },
                            {
                                "id": 2,
                                "name": ""
                            }
                        ]
                    }
                ]
            },
            {
                "title": "3. Input SQL",
                "items": [
                    {
                        "target": "sql",
                        "title": "",
                        "type": "textarea",
                        "content": ""
                    }
                ]
            },
            {
                "title": "4. Select Preprocessing Script",
                "items": [
                    {
                        "target": "script",
                        "title": "Script File",
                        "type": "file"
                    },
                    {
                        "target": "use_script",
                        "title": "use script",
                        "type": "switch",
                        "value": false
                    }
                ]
            }
        ]
    }
}
```

## GET /api/resources/new/step3  @신규추가 STEP3(신규 로그 추가)
front <<< back
```json
{
    "convert": {
        "data_type": [
            "integer",
            "float",
            "text",
            "varchar(10)",
            "varchar(30)",
            "varchar(50)",
            "timestamp",
            "boolean"
        ],
        "def_type": [
            "null",
            "text",
            "equipment_type",
            "now",
            "custom",
            "method"
        ]
    },
    "filter": {
        "filter_type": [
            "base_sampler",
            "time_sampler",
            "custom"
        ]
    },
    "analysis": {
        "calc_type": [
            "max",
            "min",
            "ave",
            "sum",
            "3sigma",
            "sequential",
            "custom"
        ],
        "aggregation_type": [
            "period",
            "column",
            "all"
        ]
    },
    "visualization": {
        "function_graph_type": [
            {
                "name": "default",
                "script": "",
                "type": "system"
            }
        ],
        "graph_list": [
            {
                "name": "Bar",
                "type": "system"
            },
            {
                "type": "Line",
                "type": "system"
            },
            {
                "type": "Box Plot",
                "type": "system"
            },
            {
                "type": "Density Plot",
                "type": "system"
            },
            {
                "type": "Bubble Chart",
                "type": "system"
            }
        ]
    }
}
```

## GET /api/resources/new/step3/:log_name  @신규추가 STEP3(기존 로그에 신규 룰 추가)
front <<< back
```json
{
    "convert": {
        "log_define": {
            "log_name": "TiltMeasurementLog",
            "table_name": "tilt_measurement_log",
            "rule_base": [
                {
                    "id": "1",
                    "rule_name": "TYPE30"
                }
            ]
        },
        "data_type": [
            "integer",
            "float",
            "text",
            "varchar(10)",
            "varchar(30)",
            "varchar(50)",
            "timestamp",
            "boolean"
        ],
        "def_type": [
            "null",
            "equipment_type",
            "now",
            "custom"
        ],
        "filter_type": [
            "base_sampler",
            "time_sampler",
            "custom"
        ]
    },
    "filter": {
        "items": [
            {
                "name": "filter1",
                "type": "base_sampler",
                "condition": "3"
            },
            {
                "name": "filter2",
                "type": "time_sampler",
                "condition": "5"
            }
        ],
        "filter_type": [
            "base_sampler",
            "time_sampler",
            "custom"
        ]
    },
    "analysis": {
        "calc_type": [
            "max",
            "min",
            "ave",
            "sum",
            "3sigma",
            "sequential",
            "custom"
        ],
        "aggregation_type": [
            "period",
            "column",
            "All Log"
        ]
    },
    "visualization": {
        "function_graph_type": [
            {
                "name": "default",
                "script": "",
                "type": "system"
            }
        ],
        "graph_list": [
            {
                "name": "Bar",
                "type": "system"
            },
            {
                "type": "Line",
                "type": "system"
            },
            {
                "type": "Box Plot",
                "type": "system"
            },
            {
                "type": "Density Plot",
                "type": "system"
            },
            {
                "type": "Bubble Chart",
                "type": "system"
            }
        ]
    }
}
```

## POST /api/resources/new  @신규추가 최종 저장
front >>> back
```json
{
    "func": {
        "category_id": 1,
        "title": "Tilt Meas."
    },
    "log_data":{
        //local
        "source": "local", // remote, sql
        "log_name":
        "use_script": true,
        "script_file": "filename"

        //remote
        "source": "remote", // remote, sql
        "db_id": 1,
        "cnv_tbl": "",
        "user_fab": "",
        "equipment_name": "",
        "period_start": "",
        "period_end": "",
        "use_script": true,
        "script_file": "filename"       

         //sql
        "source": "sql",
        "db_id": 1,
        "sql": "",
        "use_script": true,
        "script_file": "filename"
    },
    "convert": {
        "mode": "new", // 룰 추가시 add, 기존룰에 분석기능만 추가시 empty
        "log_define": {
            "log_name": "TiltMeasurementLog1",
            "table_name": "test_measurement_log",
            "rule_name": "TYPE30",
            "input_type": "csv"
        },
        "info": [
            {
                "index": 1,
                "row_index": 1,
                "col_index": 1,
                "name": "info1",
                "output_column": "info1",
                "data_type": "text",
                "coef": null,
                "def_val": "null",
                "def_type": "null",
                "unit": ""
            },
            {
                "index": 2,
                "row_index": 1,
                "col_index": 2,
                "name": "info2",
                "output_column": "info2",
                "data_type": "text",
                "coef": null,
                "def_val": "null",
                "def_type": "null",
                "unit": ""
            }
        ],
        "header": [
            {
                "index": 1,
                "row_index": null,
                "col_index": 1,
                "name": "log_time",
                "output_column": "log_time",
                "data_type": "timestamp",
                "coef": null,
                "def_val": "null",
                "def_type": "null",
                "unit": ""
            },
            {
                "index": 2,
                "row_index": null,
                "col_index": 2,
                "name": "device",
                "output_column": "device",
                "data_type": "text",
                "coef": null,
                "def_val": "null",
                "def_type": "null",
                "unit": ""
            },
            {
                "index": 3,
                "row_index": null,
                "col_index": 3,
                "name": "process",
                "output_column": "process",
                "data_type": "text",
                "coef": null,
                "def_val": "null",
                "def_type": "null",
                "unit": ""
            }
        ],
        "custom": [
            {
                "index": 1,
                "row_index": null,
                "col_index": null,
                "name": "job",
                "output_column": "job",
                "data_type": "text",
                "coef": null,
                "def_val": "device+'/'+process",
                "def_type": "custom",
                "unit": ""
            }
        ]
    },
    "filter": {
        "items": [
            {
                "name": "filter1",
                "type": "base_sampler",
                "condition": "3"
            },
            {
                "name": "filter2",
                "type": "time_sampler",
                "condition": "5"
            }
        ]
    },
    "analysis": {
        "show_org": false,
        "items": [
            {
                "disp_order": "1",
                "source_col": "flt",
                "title": "FLT Delta Max",
                "group_analysis": "delta.abs.max",
                "group_analysis_type": "sequencial",
                "total_analysis": "max",
                "total_analysis_type": "max"
            },
            {
                "disp_order": "2",
                "source_col": "blt",
                "title": "BLT Sum",
                "group_analysis": "data.sum()*100",
                "group_analysis_type": "custom",
                "total_analysis": "max",
                "total_analysis_type": "max"
            }
        ],
        "filter_default": [
            {
                "key": "device",
                "val": ["device1"]
            },
            {
                "key": "process",
                "val": ["process1"]
            }
        ],
        "aggregation_default": {
            "type": "period",
            "val": "4h"
        }
    },
    "visualization": {
	"function_graph_type": [
	    {              
	        "id": null,
                "name": "default",
		"script": "",
		"type": "system"
	    },
	    {              
		"id": null,
		"name": "User Graph1",
		"script": "",
		"type": "user"
	    }
	],
        "items": [
            {
                "id" : null,
                "type": [
                    "bar",
                    "line"
                ],
                "x_axis": "test",
                "y_axis": ["test"],
                "z_axis": "test",
                "title": "",
                "x_range_max": 1,
                "x_range_min": 0,
                "y_range_max": 1,
                "y_range_min": 0,
                "z_range_max": 1,
                "z_range_min": 0				
            },
            {
                "id": null,
                "type": [
                    "User Graph1"
                ],
                "x_axis": "test",
                "y_axis": ["test"],
                "z_axis": "test",
                "title": "",
                "x_range_max": 1,
                "x_range_min": 0,
                "y_range_max": 1,
                "y_range_min": 0,
                "z_range_max": 1,
                "z_range_min": 0				
            }
        ]
    }
}
```

front <<< back
```json
{
   "result": true,
   "func_id": 1
}
```

## POST /api/resources/scripts/:func_id  @스크립트 파일 업로드
null이면 SKIP, 파일이 존재하면 덮어쓴다.
front >>> back
```json
{
    "preprocess": null,
    "convert": 파일업로드,
    "analysis": 파일업로드    
}
```

## :white\_check\_mark: GET /api/resources/edit/step2/:func_id  @편집모드 STEP2
### local
front <<< back
```json
{
    "items": [
        {
            "title": "1. Select Source",
            "items": [
                {
                    "target": "source",
                    "title": "From",
                    "type": "input",
                    "content": "local"
                }
            ]
        },
        {
            "title": "2. Select Source Files",
            "items": [
                {
                    "target": "src_file",
                    "title": "Log Files",
                    "type": "files",
                    "enable": true
                }
            ]
        },
        {
            "title": "3. Select Log Type",
            "items": [
                {
                    "target": "log_name",
                    "title": "Log Name",
                    "type": "input",
                    "content": "TiltMeasurementLog"
                },
                {
                    "target": "rule_name",
                    "title": "Rule Name",
                    "type": "select",
                    "mode": "singular",
                    "options": [
                        {
                            "id": 1,
                            "rule_name": "TYPE30"
                        },
                        {
                            "id": null,
                            "rule_name": "Add New.."
                        }
                    ],
                    "selected": null
                }
            ]
        },
        {
            "title": "4. Select Preprocessing Script",
            "items": [
                {
                    "target": "script",
                    "title": "Script File",
                    "type": "file",
                    "file_name": "filename"
                },
                {
                    "target": "use_script",
                    "title": "use script",
                    "type": "switch",
                    "value": true
                }
            ]
        }
    ]
}
```

### remote
front <<< back
```json
{
    "items": [
        {
            "title": "1. Select Source",
            "items": [
                {
                    "target": "source",
                    "title": "From",
                    "type": "input",
                    "content": "remote"
                }
            ]
        },
        {
            "title": "2. Select Data Source",
            "items": [
                {
                    "target": "db_id",
                    "title": "From",
                    "type": "select",
                    "mode": "singular",
                    "options": [
                        {
                            "id": 1,
                            "name": ""
                        },
                        {
                            "id": 2,
                            "name": ""
                        }
                    ],
                    "selected": 1
                },
                {
                    "target": "table_name",
                    "title": "",
                    "type": "input",
                    "content": "lips_focus"
                }
            ]
        },
        {
            "title": "3. Select Equipment",
            "items": [
                {
                    "target": "user_fab",
                    "title": "User/Fab",
                    "type": "select",
                    "mode": "subItem",
                    "options": [
                        "BSOT/FAB1"
                    ],
                    "selected": "BSOT/FAB1",
                    "subItem": {
                        "target": "equipment_name",
                        "title": "Equipment",
                        "type": "select",
                        "mode": "singular",
                        "options": {
                            "BSOT/FAB1": ["",""],
                            "BSOT/FAB2": ["",""]
                        },
                        "selected": ""
                    }
                }
            ]
        },
        {
            "title": "4. Select Start/End Date",
            "items": [
                {
                    "target": "period",
                    "title": "Period",
                    "type": "DatePicker",
                    "period": {
                        "start": "",
                        "end": ""
                    },
                    "selected" : {
                        "start": "",
                        "end": ""
                    }
                }
            ]
        },
        {
            "title": "5. Select Preprocessing Script",
            "items": [
                {
                    "target": "script",
                    "title": "Script File",
                    "type": "file",
                    "file_name": "filename"
                },
                {
                    "target": "use_script",
                    "title": "use script",
                    "type": "switch",
                    "value": true
                }
            ]
        }
    ]
}
```

### sql
front <<< back
```json
{
    "items": [
        {
            "title": "1. Select Source",
            "items": [
                {
                    "target": "source",
                    "title": "From",
                    "type": "input",
                    "content": "sql"
                }
            ]
        },
        {
            "title": "2. Select Data Source",
            "items": [
                {
                    "target": "db_id",
                    "title": "From",
                    "type": "select",
                    "mode": "singular",
                    "options": [
                        {
                            "id": 1,
                            "name": ""
                        },
                        {
                            "id": 2,
                            "name": ""
                        }
                    ],
                    "selected": 1
                }
            ]
        },
        {
            "title": "3. Input SQL",
            "items": [
                {
                    "target": "sql",
                    "title": "",
                    "type": "textarea",
                    "content": ""
                }
            ]
        },
        {
            "title": "4. Select Preprocessing Script",
            "items": [
                {
                    "target": "script",
                    "title": "Script File",
                    "type": "file",
                    "file_name": "filename"
                },
                {
                    "target": "use_script",
                    "title": "use script",
                    "type": "switch",
                    "value": true
                }
            ]
        }
    ]
}
```

## GET /api/resources/edit/step3/:log_name/:rule_id?func_id=  @편집모드 STEP3(기존룰편집)
front <<< back
```json
{
    "convert": {
        "info": [],
        "header": [
            {
                "row_index": 3,
                "col_index": 1,
                "name": "Device",
                "output_column": "device",
                "data_type": "text",
                "coef": 1.0,
                "def_val": "",
                "def_type": "",
                "unit": "None"
            },
            {
                "row_index": 3,
                "col_index": 2,
                "name": "Process",
                "output_column": "process",
                "data_type": "text",
                "coef": 1.0,
                "def_val": "",
                "def_type": "",
                "unit": "None"
            },
            {
                "row_index": 3,
                "col_index": 3,
                "name": "Chuck",
                "output_column": "chuck",
                "data_type": "text",
                "coef": 1.0,
                "def_val": "",
                "def_type": "",
                "unit": "None"
            },
            {
                "row_index": 3,
                "col_index": 4,
                "name": "24160",
                "output_column": "plate_no",
                "data_type": "integer",
                "coef": 1.0,
                "def_val": "",
                "def_type": "",
                "unit": "None"
            },
            {
                "row_index": 3,
                "col_index": 5,
                "name": "24161",
                "output_column": "step_no",
                "data_type": "integer",
                "coef": 1.0,
                "def_val": "",
                "def_type": "",
                "unit": "None"
            },
            {
                "row_index": 3,
                "col_index": 6,
                "name": "24049",
                "output_column": "zsens_fl",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 7,
                "name": "240F5",
                "output_column": "zsens_fc",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 8,
                "name": "2404A",
                "output_column": "zsens_fr",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 9,
                "name": "2404B",
                "output_column": "zsens_bl",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 10,
                "name": "240F6",
                "output_column": "zsens_bc",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 11,
                "name": "2404C",
                "output_column": "zsens_br",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 12,
                "name": "2404D",
                "output_column": "drive_height",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 13,
                "name": "2404E",
                "output_column": "drive_pitch",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "ms"
            },
            {
                "row_index": 3,
                "col_index": 14,
                "name": "2404F",
                "output_column": "drive_roll",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "ms"
            },
            {
                "row_index": 3,
                "col_index": 15,
                "name": "241C1",
                "output_column": "lips_height",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 16,
                "name": "241C2",
                "output_column": "mask_bend_height",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 17,
                "name": "241C3",
                "output_column": "mask_bend_pitch",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "ms"
            },
            {
                "row_index": 3,
                "col_index": 18,
                "name": "241C4",
                "output_column": "mask_bend_roll",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "ms"
            },
            {
                "row_index": 3,
                "col_index": 19,
                "name": "2408B",
                "output_column": "chuck_pos_afc_meas_height",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 20,
                "name": "2408C",
                "output_column": "chuck_pos_afc_meas_pitch",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "ms"
            },
            {
                "row_index": 3,
                "col_index": 21,
                "name": "2408D",
                "output_column": "chuck_pos_afc_meas_roll",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "ms"
            },
            {
                "row_index": 3,
                "col_index": 22,
                "name": "2408E",
                "output_column": "stage_pos_afc_meas_height",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 23,
                "name": "2408F",
                "output_column": "stage_pos_afc_meas_pitch",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "ms"
            },
            {
                "row_index": 3,
                "col_index": 24,
                "name": "24090",
                "output_column": "stage_pos_afc_meas_roll",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "ms"
            },
            {
                "row_index": 3,
                "col_index": 25,
                "name": "241C5",
                "output_column": "stage_pos_afc_meas_z1",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 26,
                "name": "241C6",
                "output_column": "stage_pos_afc_meas_z2",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 27,
                "name": "241C7",
                "output_column": "stage_pos_afc_meas_z3",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 28,
                "name": "241C8",
                "output_column": "stage_pos_afc_meas_z4",
                "data_type": "integer",
                "coef": 1000.0,
                "def_val": "",
                "def_type": "",
                "unit": "nm"
            },
            {
                "row_index": 3,
                "col_index": 29,
                "name": "GlassID",
                "output_column": "glass_id",
                "data_type": "text",
                "coef": 1.0,
                "def_val": "",
                "def_type": "",
                "unit": "None"
            },
            {
                "row_index": 3,
                "col_index": 30,
                "name": "LotID",
                "output_column": "lot_id",
                "data_type": "text",
                "coef": 1.0,
                "def_val": "",
                "def_type": "",
                "unit": "None"
            },
            {
                "row_index": 3,
                "col_index": 31,
                "name": "Date Time",
                "output_column": "log_time",
                "data_type": "timestamp",
                "coef": 1.0,
                "def_val": "",
                "def_type": "",
                "unit": "None"
            }
        ],
        "custom": [],
        "log_define": {
            "log_name": "PLATEAUTOFOCUSCOMPENSATION",
            "table_name": "plate_auto_focus_compensation",
            "rule_name": "HEADER"
        },
        "data_type": [
            "integer",
            "float",
            "text",
            "varchar(10)",
            "varchar(30)",
            "varchar(50)",
            "timestamp",
            "time",
            "boolean"
        ],
        "def_type": [
            "null",
            "text",
            "now",
            "lambda"
        ],
        "columns": [
            {
                "column_name": "device",
                "data_type": "text"
            },
            {
                "column_name": "process",
                "data_type": "text"
            },
            {
                "column_name": "chuck",
                "data_type": "text"
            },
            {
                "column_name": "plate_no",
                "data_type": "integer"
            },
            {
                "column_name": "step_no",
                "data_type": "integer"
            },
            {
                "column_name": "zsens_fl",
                "data_type": "integer"
            },
            {
                "column_name": "zsens_fc",
                "data_type": "integer"
            },
            {
                "column_name": "zsens_fr",
                "data_type": "integer"
            },
            {
                "column_name": "zsens_bl",
                "data_type": "integer"
            },
            {
                "column_name": "zsens_bc",
                "data_type": "integer"
            },
            {
                "column_name": "zsens_br",
                "data_type": "integer"
            },
            {
                "column_name": "drive_height",
                "data_type": "integer"
            },
            {
                "column_name": "drive_pitch",
                "data_type": "integer"
            },
            {
                "column_name": "drive_roll",
                "data_type": "integer"
            },
            {
                "column_name": "lips_height",
                "data_type": "integer"
            },
            {
                "column_name": "mask_bend_height",
                "data_type": "integer"
            },
            {
                "column_name": "mask_bend_pitch",
                "data_type": "integer"
            },
            {
                "column_name": "mask_bend_roll",
                "data_type": "integer"
            },
            {
                "column_name": "chuck_pos_afc_meas_height",
                "data_type": "integer"
            },
            {
                "column_name": "chuck_pos_afc_meas_pitch",
                "data_type": "integer"
            },
            {
                "column_name": "chuck_pos_afc_meas_roll",
                "data_type": "integer"
            },
            {
                "column_name": "stage_pos_afc_meas_height",
                "data_type": "integer"
            },
            {
                "column_name": "stage_pos_afc_meas_pitch",
                "data_type": "integer"
            },
            {
                "column_name": "stage_pos_afc_meas_roll",
                "data_type": "integer"
            },
            {
                "column_name": "stage_pos_afc_meas_z1",
                "data_type": "integer"
            },
            {
                "column_name": "stage_pos_afc_meas_z2",
                "data_type": "integer"
            },
            {
                "column_name": "stage_pos_afc_meas_z3",
                "data_type": "integer"
            },
            {
                "column_name": "stage_pos_afc_meas_z4",
                "data_type": "integer"
            },
            {
                "column_name": "glass_id",
                "data_type": "text"
            },
            {
                "column_name": "lot_id",
                "data_type": "text"
            },
            {
                "column_name": "log_time",
                "data_type": "timestamp"
            },
            {
                "column_name": "equipment_name",
                "data_type": "text"
            },
            {
                "column_name": "log_idx",
                "data_type": "integer"
            },
            {
                "column_name": "request_id",
                "data_type": "varchar(50)"
            },
            {
                "column_name": "created_time",
                "data_type": "timestamp"
            }
        ]
    },
    "filter": {
        "filter_type": [
            "base_sampler",
            "time_sampler",
            "lambda"
        ]
    },
    "analysis": {
        "calc_type": [
            "max",
            "min",
            "ave",
            "sum",
            "3sigma",
            "sequential",
            "custom"
        ],
        "aggregation_type": [
            "period",
            "column",
            "all"
        ],
        "show_org": false,
        "items": [
            {
                "disp_order": 4,
                "source_col": "mask_bend_height",
                "title": "MASK BEND Height Range",
                "group_analysis": "range.max",
                "group_analysis_type": "sequential",
                "total_analysis": "max",
                "total_analysis_type": "max"
            },
            {
                "disp_order": 5,
                "source_col": "mask_bend_pitch",
                "title": "MASK BEND Pitching AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 6,
                "source_col": "mask_bend_pitch",
                "title": "MASK BEND Picthing Range",
                "group_analysis": "range.max",
                "group_analysis_type": "sequential",
                "total_analysis": "max",
                "total_analysis_type": "max"
            },
            {
                "disp_order": 7,
                "source_col": "mask_bend_roll",
                "title": "MASK BEND Rolling AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 8,
                "source_col": "mask_bend_roll",
                "title": "MASK BEND Rolling Range",
                "group_analysis": "range.max",
                "group_analysis_type": "sequential",
                "total_analysis": "max",
                "total_analysis_type": "max"
            },
            {
                "disp_order": 9,
                "source_col": "chuck_pos_afc_meas_height",
                "title": "Chuck Posture Height AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 10,
                "source_col": "chuck_pos_afc_meas_height",
                "title": "Chuck Posture Height 3sigma",
                "group_analysis": "3sigma",
                "group_analysis_type": "3sigma",
                "total_analysis": "max",
                "total_analysis_type": "max"
            },
            {
                "disp_order": 11,
                "source_col": "chuck_pos_afc_meas_pitch",
                "title": "Chuck Posture Pitching AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 12,
                "source_col": "chuck_pos_afc_meas_pitch",
                "title": "Chuck Posture Pitching 3sigma",
                "group_analysis": "3sigma",
                "group_analysis_type": "3sigma",
                "total_analysis": "ave",
                "total_analysis_type": "ave"
            },
            {
                "disp_order": 13,
                "source_col": "chuck_pos_afc_meas_roll",
                "title": "Chuck Posture Rolling AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 14,
                "source_col": "chuck_pos_afc_meas_roll",
                "title": "Chuck Posture Rolling 3sigma",
                "group_analysis": "3sigma",
                "group_analysis_type": "3sigma",
                "total_analysis": "max",
                "total_analysis_type": "max"
            },
            {
                "disp_order": 15,
                "source_col": "stage_pos_afc_meas_height",
                "title": "Stage Pos. Height AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 16,
                "source_col": "stage_pos_afc_meas_height",
                "title": "Stage Pos. Height 3sigma",
                "group_analysis": "3sigma.abs",
                "group_analysis_type": "sequential",
                "total_analysis": "ave",
                "total_analysis_type": "ave"
            },
            {
                "disp_order": 17,
                "source_col": "stage_pos_afc_meas_pitch",
                "title": "Stage Pos. Pitching AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 18,
                "source_col": "stage_pos_afc_meas_roll",
                "title": "Stage Pos. Rolling AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 19,
                "source_col": "stage_pos_afc_meas_z1",
                "title": "Stage Pos. Z1 AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 20,
                "source_col": "stage_pos_afc_meas_z2",
                "title": "Stage Pos. Z2 AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 21,
                "source_col": "stage_pos_afc_meas_z3",
                "title": "Stage Pos. Z3 AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 22,
                "source_col": "stage_pos_afc_meas_z4",
                "title": "Stage Pos. Z4 AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": "delta.abs.max",
                "total_analysis_type": "sequential"
            },
            {
                "disp_order": 2,
                "source_col": "lips_height",
                "title": "LIPS Height Range",
                "group_analysis": "range.max",
                "group_analysis_type": "sequential",
                "total_analysis": null,
                "total_analysis_type": null
            },
            {
                "disp_order": 1,
                "source_col": "lips_height",
                "title": "LIPS Height AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": null,
                "total_analysis_type": null
            },
            {
                "disp_order": 3,
                "source_col": "mask_bend_height",
                "title": "MASK BEND Height AVE",
                "group_analysis": "ave",
                "group_analysis_type": "ave",
                "total_analysis": null,
                "total_analysis_type": null
            }
        ],
        "filter_default": [
            {
                "key": "device",
                "val": null
            }
        ],
        "aggregation_default": {
            "type": "period",
            "val": "4h"
        }
    },
    "visualization": {
        "function_graph_type": [
            {
                "id": 1,
                "name": "default",
                "script": "",
                "type": "system"
            },
            {
                "id": 2,
                "name": "User Graph1",
                "script": "",
                "type": "user"
            }
        ],
        "graph_list": [
            {
                "name": "Bar",
                "type": "system"
            },
            {
                "name": "Line",
                "type": "system"
            },
            {
                "name": "Box Plot",
                "type": "system"
            },
            {
                "name": "Density Plot",
                "type": "system"
            },
            {
                "name": "Bubble Chart",
                "type": "system"
            },
            {
                "name": "User Graph1",
                "type": "user"
            }
        ],
        "items": [
            {
                "id": 1,
                "type": [
                    "bar",
                    "line"
                ],
                "x_axis": "test",
                "y_axis": ["test"],
                "z_axis": "test",
                "title": "",
                "x_range_max": 1,
                "x_range_min": 0,
                "y_range_max": 1,
                "y_range_min": 0,
                "z_range_max": 1,
                "z_range_min": 0,
            },
            {
                "id": 2,
                "type": [
                    "User Graph1"
                ],
                "x_axis": null,
                "y_axis": ["test"],
                "z_axis": null,
                "title": "",
                "x_range_max": 1,
                "x_range_min": 0,
                "y_range_max": 1,
                "y_range_min": 0,
                "z_range_max": 1,
                "z_range_min": 0,
            }
        ]
    }
}

```
## GET /api/resources/edit/step3/:log_name/new/:func_id  @편집모드 STEP3(신규룰추가)
front <<< back
```json
{
    "convert": {
        "log_define": {
            "log_name": "PLATEAUTOFOCUSCOMPENSATION",
            "table_name": "plate_auto_focus_compensation",
            "rule_base": [
                {
                    "id": "5",
                    "rule_name": "HEADER"
                },
                {
                    "id": "6",
                    "rule_name": "TYPE30"
                },
                {
                    "id": "7",
                    "rule_name": "TYPE20"
                },
                {
                    "id": "8",
                    "rule_name": "TYPE11"
                },
                {
                    "id": "9",
                    "rule_name": "TYPE10"
                }
            ]
        },
        "data_type": [
            "integer",
            "float",
            "text",
            "varchar(10)",
            "varchar(30)",
            "varchar(50)",
            "timestamp",
            "time",
            "boolean"
        ],
        "def_type": [
            "null",
            "text",
            "now",
            "lambda"
        ],
        "filter_type": [
            "base_sampler",
            "time_sampler",
            "lambda"
        ]
    },
    "filter": {
        "filter_type": [
            "base_sampler",
            "time_sampler",
            "lambda"
        ]
    },
    "analysis": {
        "calc_type": [
            "max",
            "min",
            "ave",
            "sum",
            "3sigma",
            "sequential",
            "custom"
        ],
        "aggregation_type": [
            "period",
            "column",
            "all"
        ]
    },
    "visualization": {
        "function_graph_type": [
            {
                "id": 1,
                "name": "default",
                "script": "",
                "type": "system"
            },
            {
                "id": 2,
                "name": "User Graph1",
                "script": "",
                "type": "user"
            }
        ],
        "graph_list": [
            {
                "name": "Bar",
                "type": "system"
            },
            {
                "name": "Line",
                "type": "system"
            },
            {
                "name": "Box Plot",
                "type": "system"
            },
            {
                "name": "Density Plot",
                "type": "system"
            },
            {
                "name": "Bubble Chart",
                "type": "system"
            },
            {
                "name": "User Graph1",
                "type": "user"
            }
        ],
        "items": [
            {
                "id": 1,
                "type": [
                    "bar",
                    "line"
                ],
                "x_axis": "test",
                "y_axis": ["test"],
                "z_axis": "test",
                "title": "",
                "x_range_max": 1,
                "x_range_min": 0,
                "y_range_max": 1,
                "y_range_min": 0,
                "z_range_max": 1,
                "z_range_min": 0,                
            },
            {
                "id": 2,
                "type": [
                    "User Graph1"
                ],
                "x_axis": null,
                "y_axis": ["test"],
                "z_axis": null,
                "title": "",
                "x_range_max": 1,
                "x_range_min": 0,
                "y_range_max": 1,
                "y_range_min": 0,
                "z_range_max": 1,
                "z_range_min": 0,                
            }
        ]
    }
}

```

## POST /api/resources/edit/:func_id  @편집모드 최종 저장
front >>> back
```json
{
    "func": {
        "category_id": 1,
        "title": "test"
    },

    "log_data":{
        //local
        "source": "local", // remote, sql
        "log_name":
        "use_script": true,
        "script_file": "filename"

        //remote
        "source": "remote", // remote, sql
        "db_id": 1,
        "cnv_tbl": "",
        "user_fab": "",
        "equipment_name": "",
        "period_start": "",
        "period_end": "",
        "use_script": true,
        "script_file": "filename"       

         //SQL
        "source": "sql",
        "db_id": 1,
        "sql": "",
        "use_script": true,
        "script_file": "filename"
    },
    "convert": {
        "mode": "add", // 기존룰 편집시는 edit
        "log_define": {
            "log_name": "TiltMeasurementLog",
            "table_name": "tilt_measurement_log",
            "rule_name": "NEWRULE",
            "rule_id": null
        },
        "info": [],
        "header": [
            {
                "index": 1,
                "row_index": null,
                "col_index": 1,
                "name": "status",
                "output_column": "status",
                "data_type": "integer",
                "coef": 1,
                "def_val": "null",
                "def_type": "null",
                "unit": ""
            }
        ],
        "custom": []
    },
    "filter": [
        {
            "name": "Sampling",
            "type": "Sampling",
            "condition": "3"
        },
        {
            "name": "HPF",
            "type": "custom",
            "condition": "glass_id<3 && lot_id != \"\""
        }
    ],
    "analysis": {
        "show_org": false,
        "items": [
            {
                "disp_order": "1",
                "source_col": "flt",
                "title": "FLT Delta Max",
                "group_analysis": "delta.abs.max",
                "group_analysis_type": "custom",
                "total_analysis": "max",
                "total_analysis_type": "max"
            },
            {
                "disp_order": "2",
                "source_col": "blt",
                "title": "BLT Sum",
                "group_analysis": "data.sum()*100",
                "group_analysis_type": "custom",
                "total_analysis": "max",
                "total_analysis_type": "max"
            }
        ],
        "filter_default": [
            {
                "key": "device",
                "val": ["device1"]
            },
            {
                "key": "process",
                "val": ["process1"]
            }
        ],
        "aggregation_default": {
            "type": "period",
            "val": "4h"
        }
    },
    "visualization": {
	"function_graph_type": [
	    {              
		"id": 1,
		"name": "default",
		"script": "",
		"type": "system",
		"modified": false
	    },
	    {              
		"id": 2,
		"name": "User Graph1",
		"script": "",
		"type": "user",
		"modified": true
	    }
	],
        "items": [
            {
                "id": 1,
                "type": [
                    "bar",
                    "line"
                ],
                "x_axis": "test",
                "y_axis": ["test"],
                "z_axis": "test",
                "title": "",
                "x_range_max": 1,
                "x_range_min": 0,
                "y_range_max": 1,
                "y_range_min": 0,
                "z_range_max": 1,
                "z_range_min": 0,
                "modified": false				
            },
            {
                "id": null,
                "type": [
                    "User Graph1"
                ],
                "x_axis": "test",
                "y_axis": ["test"],
                "z_axis": "test",
                "title": "",
                "x_range_max": 1,
                "x_range_min": 0,
                "y_range_max": 1,
                "y_range_min": 0,
                "z_range_max": 1,
                "z_range_min": 0,
                "modified": true				
            }
        ]
    }
}

```

# STEP2 화면 내부용
## :white\_check\_mark: GET /api/resources/remote/tables/:db_id  @Data Source 선택시, 테이블 리스트 획득
front <<< back
```json
[
   "lips_focus",
   "afc"
]
```

## :white\_check\_mark: GET /api/resources/remote/equipments/:db_id/:table_name  @Data Source의 테이블명 선택 시, Equipment 리스트 획득
front <<< back
```json
{
    "user_fab": [
        "BSOT_FAB1",
        "BSOT_FAB2"
    ],
    "equipment_name": {
        "BSOT_FAB1": [
            "BSOT_FAB1_equipment1",
            "BSOT_FAB1_equipment2"
        ],
        "BSOT_FAB2": [

        ]
    }
}
```

## :white\_check\_mark: GET /api/resources/date/:table_name/:equipment_name  @ 로그 기간 획득
front <<< back
```json
{
    "start": "",
    "end": ""
}
```

# User Graph Management관련
## :white\_check\_mark: POST /api/resources/graph/:func_id  @신규 그래프 추가시
front >>> back
```json
{
    "name": "User Graph1",
    "script": ""
}
```

front <<< back
```json
{
    "id": 2
}
```

## :white\_check\_mark: PUT /api/resources/graph/:func_id/:graph_id  @기존 그래프 편집시
front >>> back
```json
{
    "name": "User Graph1",
    "script": ""
}
```

front <<< back
200

400
```json
{
    "msg": ""
}
```

## :white\_check\_mark: DELETE /api/resources/graph/:func_id/:graph_id  @기존 그래프 삭제시
front <<< back
200

400
```json
{
    "msg": ""
}
```

# IMPORT/EXPORT

# /api/analysis

# /api/preview
## :black\_square\_button: POST /api/preview/samplelog  @STEP2 프리뷰
front >>> end
### local 파일의 경우
form-data 방식
* "source": "local",
* "files": "파일",   //파일
* "script_file": //파일, 없을경우 null

### remote의 경우
form-data 방식
* "source": "remote",
* "db_id": 1,
* "table_name": "",
* "equipment_name": "GKC_G1_BF8_G220",
* "start": "",
* "end": "",
* "script_file": //파일, 없을경우 null

### SQL의 경우
form-data 방식
* "source": "sql",
* "db_id": 1,
* "sql": "",
* "script_file": //파일 업로드

# /api/converter

# Mangement Setting화면 관련
## :white\_check\_mark: GET api/setting/local  @로컬DB세팅정보
front <<< back
```json
{
    "items": [
        {
            "target": "host",
            "type": "input",
            "title": "Host",
            "content": ""
        },
        {
            "target": "port",
            "type": "input",
            "title": "Port",
            "content": ""
        },
        {
            "target": "username",
            "type": "input",
            "title": "UserName",
            "content": ""
        },
        {
            "target": "dbname",
            "type": "input",
            "title": "DBName",
            "content": ""
        },
        {
            "target": "password",
            "type": "password",
            "title": "Password",
            "content": ""
        }
    ]
}
```

## :white\_check\_mark: GET api/setting/remote  @Remote DB세팅정보
front <<< back
```json
{
    "items": [
        {
            "id": 1,
            "name": "",
            "sts": "success"
        },
        {
            "id": 1,
            "name": "",
            "sts": "success"
        }
    ]
}
```

## :white\_check\_mark: GET api/setting/tables  @룰 관리 테이블 정보
front <<< back
```json
[
        "analysis.pickup_items",
        "cnvbase.convert_columns_define",
        "cnvbase.equipment_types",
        "cnvbase.equipments",
        "cnvbase.log_define"
]
```

## :white\_check\_mark: GET /api/setting/remote/:db_id/status  @리모트 DB별 refresh버튼 클릭시 상태체크
front <<< back
200
```json
{
    "id": 2,
    "sts": "success"
}
```

400
```json
{
    "msg": ""
}
```

## :white\_check\_mark: POST /api/setting/remote  @DB 신규추가
front >>> back
```json
{
    "host": "",
    "port": 0,
    "username",
    "dbname": "",
    "password": ""
}
```

front <<< back
```json
{
    "id": 2,
    "name": "",
    "sts": "success"
}
```

## :white\_check\_mark: GET /api/setting/remote/:db_id  @특정 Remote DB 상세정보 획득
front <<< back
```json
{
    "host": "",
    "port": 0,
    "username",
    "dbname": "",
    "password": ""
}
```

## :white\_check\_mark: PUT /api/setting/remote/:db_id  @특정 Remote DB 정보 업데이트
front >>> back
```json
{
    "host": "",
    "port": 5432,
    "username",
    "dbname": "",
    "password": ""
}
```

front <<< back
```json
{
    "id": 2,
    "name": "",
    "sts": "success"
}
```

## :white\_check\_mark: DELETE /api/setting/remote/:db_id  @특정 Remote DB 정보 삭제
front <<< back
```json
{
    "id": 2
}
```

## :white\_check\_mark: POST /api/setting/connection-check  @DB 접속상태 체크
front >>> back
```json
{
    "host": "",
    "port": 5432,
    "username": "",
    "dbname": "",
    "password": ""
}
```

front <<< back
200
```json
{
    "data": ""
}
```

400
```json
{
   "msg": ""
}
```

## :white\_check\_mark: PUT/api/setting/local  @로컬 DB 정보 갱신
front >>> back
```json
{
    "host": "",
    "port": 5432,
    "username": "",
    "dbname": "",
    "password": ""
}
```

front <<< back
200