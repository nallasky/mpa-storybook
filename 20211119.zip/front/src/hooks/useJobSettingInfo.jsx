import { useState, useCallback } from 'react';
import {
  getValidPeriod,
  initialSettingAction,
  UpdateDurationReducer,
} from '../reducers/slices/SettingInfo';
import { useDispatch, useSelector } from 'react-redux';
import {
  getCurrentPath,
  getSupportUrl,
  UpdateCurrentPathReducer,
} from '../reducers/slices/BasicInfo';
import { getFindData } from '../lib/util/Util';
import { MSG_LOCAL, MSG_REMOTE, MSG_SQL } from '../lib/api/Define/Message';

const initialState = {
  log_name: '',
  source: '',
  target_path: [],
  equipment_type: '',
};

const useJobSettingInfo = () => {
  const [isOpenCreateJob, setCreateJob] = useState(false);
  const [jobResource, setJobResource] = useState(null);
  const [jobSettingInfo, setJobSettingInfo] = useState(initialState);
  const dispatch = useDispatch();
  const validPeriod = useSelector(getValidPeriod);
  const currentPath = useSelector(getCurrentPath);
  const urlList = useSelector(getSupportUrl);

  const setValidPeriod = useCallback(
    (value) => {
      dispatch(UpdateDurationReducer(value));
    },
    [dispatch],
  );
  const initValidPeriod = useCallback(() => {
    dispatch(initialSettingAction());
  }, [dispatch]);

  const setCurrentPath = useCallback(
    (value) => {
      dispatch(UpdateCurrentPathReducer(value));
    },
    [dispatch],
  );

  const openCreateJob = useCallback(() => {
    setCreateJob(true);
  }, [setCreateJob]);

  const closeCreateJob = useCallback(() => {
    setCreateJob(false);
  }, [setCreateJob]);

  const setJobSettingResource = useCallback(
    (setting, func_id) => {
      const source = setting.formList[0].key;
      setJobResource(setting);
      setJobSettingInfo(
        source === MSG_LOCAL
          ? {
              job_type: setting.formList[0].type,
              source: source,
              log_name: getFindData(setting.form[MSG_LOCAL], 'log_name'),
              func_id: func_id,
            }
          : source === MSG_REMOTE
          ? {
              job_type: setting.formList[0].type,
              source: source,
              db_id: getFindData(setting.form[MSG_REMOTE], 'db_id'),
              table_name: getFindData(setting.form[MSG_REMOTE], 'table_name'),
              user_fab: getFindData(setting.form[MSG_REMOTE], 'user_fab'),
              period: getFindData(
                setting.form[MSG_REMOTE],
                'period',
              ),
              func_id: func_id,
            }
          : {
              job_type: setting.formList[0].type,
              source: source,
              db_id: getFindData(setting.form[MSG_SQL], 'db_id'),
              sql: getFindData(setting.form[MSG_SQL], 'sql'),
              func_id: func_id,
            },
      );
    },
    [setJobResource],
  );
  const clearSettingInfo = useCallback(() => {
    setJobSettingResource(null);
    initJobInfo();
  }, [setJobSettingResource]);

  const initJobInfo = useCallback(() => {
    setJobSettingInfo(initialState);
  }, [setJobSettingInfo]);

  return {
    isOpenCreateJob,
    openCreateJob,
    closeCreateJob,
    jobResource,
    setJobSettingResource,
    clearSettingInfo,
    jobSettingInfo,
    setJobSettingInfo,
    validPeriod,
    setValidPeriod,
    initValidPeriod,
    currentPath,
    setCurrentPath,
    urlList,
  };
};

export default useJobSettingInfo;
