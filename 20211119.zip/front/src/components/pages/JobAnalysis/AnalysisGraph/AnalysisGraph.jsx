import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Button, Empty, Popconfirm } from 'antd';
import {
  CloseCircleFilled,
  LineChartOutlined,
  SettingFilled,
} from '@ant-design/icons';
import * as sg from './styleGroup';
import GraphAddEdit from '../../../UI/organisms/GraphAddEdit/GraphAddEdit';
import useResultInfo from '../../../../hooks/useResultInfo';

const AnalysisGraph = (backData, info, type) => {
  const {
    analysisGraphInfo,
    setAnalysisGraphInfo,
    originalGraphInfo,
    setOriginalGraphInfo,
  } = useResultInfo();
  const [isOpen, setIsOpen] = useState(false);
  const [currentIdx, setCurrentIdx] = useState('');

  const onEdit = (idx) => {
    setCurrentIdx(idx);
    setIsOpen(true);
  };

  const onDelete = (idx) => {
    if (type === 'analysis') {
      setAnalysisGraphInfo(
        analysisGraphInfo.map((v, i) => {
          return i !== idx;
        }),
      );
    } else {
      setOriginalGraphInfo(
        originalGraphInfo.map((v, i) => {
          return i !== idx;
        }),
      );
    }
  };

  if (info.length < 1) return '';

  return (
    <>
      <div css={sg.mainWrapper}>
        <div>
          <span>Visualization</span>
          <Button type="dashed" icon={<LineChartOutlined />}>
            Add Graph
          </Button>
        </div>
        <div>
          <div css={info.length > 0 ? sg.graphBodyStyle : sg.emptyWrapper}>
            {info.length > 0 ? (
              info.map((k, i) => {
                return (
                  <div key={i} css={sg.graphWrapper}>
                    <div>
                      <Button
                        type="dashed"
                        shape="round"
                        icon={<SettingFilled />}
                        onClick={() => onEdit(i)}
                      >
                        Edit
                      </Button>
                      <Popconfirm
                        title="Are you sure you want to delete this graph?"
                        onConfirm={() => onDelete(i)}
                      >
                        <Button
                          type="dashed"
                          shape="round"
                          icon={<CloseCircleFilled />}
                        >
                          Delete
                        </Button>
                      </Popconfirm>
                    </div>
                    <div id={`graph_${i}`} />
                  </div>
                );
              })
            ) : (
              <Empty description="No graphs to display." />
            )}
          </div>
        </div>
      </div>
      <GraphAddEdit
        closer={() => setIsOpen(false)}
        isOpen={isOpen}
        mode="edit"
        index={currentIdx}
      />
    </>
  );
};
AnalysisGraph.propTypes = {
  backData: PropTypes.object.isRequired,
  info: PropTypes.array.isRequired,
  type: PropTypes.string,
};
AnalysisGraph.defaultProps = {
  type: 'analysis',
};

export default AnalysisGraph;
