import React, { useState } from 'react';
import { FormCard, Modal } from '../../UI/atoms/Modal';
import PropTypes from 'prop-types';
import Button from '../../UI/atoms/Button';
import { css } from '@emotion/react';
import InputForm from '../atoms/Input/InputForm';
import { getParseData } from '../../../lib/util/Util';

const footerStyle = css`
  display: flex;
  justify-content: flex-end;
  align-items: center;
`;
const directoryStyle = css`
  & .ant-upload-list {
    max-height: 150px;
    overflow-y: auto;
  }
`;

const ModalFooter = ({ startFunc, closeFunc }) => {
  return (
    <div css={footerStyle}>
      <Button
        theme={'white'}
        onClick={startFunc}
        style={{ marginLeft: '8px', fontWeight: 400 }}
      >
        {'Start Analysis'}
      </Button>
      <Button
        theme={'blue'}
        onClick={() => closeFunc(0)}
        style={{ marginLeft: '8px', fontWeight: 400 }}
      >
        {'Cancel'}
      </Button>
    </div>
  );
};

ModalFooter.propTypes = {
  startFunc: PropTypes.func.isRequired,
  closeFunc: PropTypes.func.isRequired,
};

export const JobSettingInputForm = ({ item, changefunc, info }) => {
  const { title, type, mode, options } = item;
  const changeEvent = (e) => {
    const update = changefunc(e);
    if (update !== undefined) {
      console.log(update);
    }
  };
  const start_analysis_style = css`
    & .ant-form-item-label {
      text-align: left;
    }
  `;

  return (
    <div css={start_analysis_style}>
      {type === 'select' ? (
        mode === 'singular' ? (
          <InputForm.select
            formLabel={title}
            formName={item.target}
            options={item.options}
            changeFunc={changeEvent}
            defaultV={info?.[item.target] ?? ''}
          />
        ) : mode === 'subItem' ? (
          <>
            <InputForm.subItem
              formLabel={title}
              formName={item.target}
              options={
                info?.info?.[item.target] ?? info?.[item.target] ?? item.options
              }
              subItem={{
                ...item.subItem,
                options:
                  info?.info?.[item.subItem.target] ?? item.subItem.option,
                selected:
                  info?.info?.[item.subItem.target] ??
                  item?.subItem.selected ??
                  '',
              }}
              changeFunc={changeEvent}
            />
          </>
        ) : (
          <></>
        )
      ) : type.toLowerCase() === 'datepicker' ? (
        <InputForm.datePicker
          formLabel={title}
          formName={item.target}
          start={
            info?.[item.target]?.start ??
            (Array.isArray(options) ? options?.[0].start ?? 0 : 0)
          }
          end={
            info?.[item.target]?.end ??
            (Array.isArray(options) ? options?.[0].end ?? 0 : 0)
          }
          changeFunc={changeEvent}
          disabled={item?.enable === false ?? false}
        />
      ) : type === 'directory' ? (
        <InputForm.directory
          formLabel={title}
          formName={item.target}
          changeFunc={changeEvent}
        />
      ) : type === 'files' ? (
        <InputForm.files
          formLabel={title}
          formName={item.target}
          changeFunc={changefunc}
          enable={item.enable}
        />
      ) : type === 'file' ? (
        <InputForm.file
          formLabel={title}
          formName={item.target}
          changeFunc={changefunc}
        />
      ) : type === 'text' || type === 'input' ? (
        <InputForm.text
          formLabel={title}
          formName={item.target}
          changeFunc={changefunc}
          value={info?.[item.target] ?? item.content}
        />
      ) : (
        <div>{title}</div>
      )}
    </div>
  );
};

JobSettingInputForm.propTypes = {
  item: PropTypes.object.isRequired,
  changefunc: PropTypes.func.isRequired,
  info: PropTypes.object,
};

const titlestyle = css`
  font-weight: 400;
`;

const ModalContents = ({ form, changeFunc, info }) => {
  const [source, setSource] = useState(info?.source ?? undefined);

  const change = (event) => {
    changeFunc(event);
    const item = getParseData(event);
    if (item.id === 'source' && source !== item.value) {
      setSource(item.value);
    }
  };
  if (form === null) return <></>;

  return form[source].map((item, idx) => (
    <div key={idx}>
      <FormCard title={item.title} titleStyle={titlestyle}>
        {item.items.map((idx2, i) => (
          <JobSettingInputForm
            key={i}
            item={item.items[i]}
            changefunc={change}
            info={info}
          />
        ))}
      </FormCard>
    </div>
  ));
};

ModalContents.propTypes = {
  form: PropTypes.object.isRequired,
  changeFunc: PropTypes.func.isRequired,
  info: PropTypes.object,
};

const JobSettingModal = ({
  isOpen,
  info,
  closeFunc,
  startFunc,
  changeFunc,
  resource,
}) => {
  if (resource === null) return <></>;
  return (
    <>
      <Modal
        width={'550px'}
        isOpen={isOpen}
        header={<div>{resource?.title ?? 'loading.....'}</div>}
        content={
          <ModalContents
            form={resource?.form ?? null}
            changeFunc={changeFunc}
            info={info}
          />
        }
        footer={<ModalFooter startFunc={startFunc} closeFunc={closeFunc} />}
        closeIcon={false}
        style={directoryStyle}
      />
    </>
  );
};

JobSettingModal.propTypes = {
  isOpen: PropTypes.bool,
  startFunc: PropTypes.func,
  closeFunc: PropTypes.func,
  changeFunc: PropTypes.func,
  info: PropTypes.object,
  resource: PropTypes.shape({
    title: PropTypes.string,
    formList: PropTypes.array,
    form: PropTypes.object,
  }),
};
export default JobSettingModal;
