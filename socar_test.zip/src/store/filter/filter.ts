import { create } from 'zustand';
import { persist } from "zustand/middleware";

import { IChangeSavedFilter } from "../../pages/carList/type";
import { FilterState } from "./type";
import { CAR_SAVED_FILTER_INITIAL_VALUE } from "../../pages/carList/constant";

export const useFilterStore = create(
  persist<FilterState>(
    (set) => ({
      savedFilter: CAR_SAVED_FILTER_INITIAL_VALUE,
      changeSavedFilter: (info: IChangeSavedFilter) => {
        set((state: FilterState) => {
          const { key, value } = info;
          state.savedFilter[key] = [...value];
        })
      },
      initializeSavedFilter: () => {
        set((state: FilterState) => {
          state.savedFilter = CAR_SAVED_FILTER_INITIAL_VALUE;
        })
      }
    }),
    {
      name: 'filter-storage'
    }
  )
);