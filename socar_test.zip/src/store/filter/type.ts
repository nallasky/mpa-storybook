import { IChangeSavedFilter, ISavedFilter } from "../../pages/carList/type";

export interface FilterState {
  savedFilter: ISavedFilter,
  changeSavedFilter: (info: IChangeSavedFilter) => void,
  initializeSavedFilter: () => void,
}