import * as React from "react";
import styled from "styled-components";

const CarListWrapper = styled.main`
  position: relative;
  width: 420px;
  min-height: 100vh;
  margin: 0 auto;
  border: 1px solid #dadada;
`;

const CarListHeader = styled.header`
  position: sticky;
  top: 0;
  height: 100%;
  background-color: white;
  z-index: 100;
  & > h1 {
    margin: 0;
    padding: 2rem 0;
    font-size: 2rem;
  }
`;

const CarListFilter = styled.div`
  padding: 0.5rem;
  border-top: 1px solid #dadada;
  border-bottom: 1px solid #dadada;
`;

const CarListItems = styled.ul`
  list-style: none;
  margin: 0.5rem;
  padding: 0;
`;

const CarListItem = styled.li`
  & + li {
    margin-top: 0.5rem;
  }
  & > .car-list-item {
    text-align: left;
    border: 1px solid #dadada;
    border-radius: 4px;
    & > div + div {
      margin-top: 0.25rem;
    }
    & > .car-list-item__image {
      position: relative;
      overflow: hidden;
      width: 100%;
      padding-top: 50%;
      border-bottom: 1px solid #dadada;
      & > img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: contain;   
      }
    }
    & > .car-list-item__info {
      padding: 0.5rem;
      & > div + div {
        margin-top: 0.5rem;
      }
      & > .car-list-item__info__name-and-tag {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        row-gap: 0.25rem;
        & > .car-list-item__info__name-and-tag__name {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        & > .car-list-item__info__name-and-tag__tag {
          display: flex;
          column-gap: 0.25rem;
        }
      }
    }
  }
`;

const FilterTag = styled.span`
  display: block;
  border: 1px solid #dadada;
  padding: 0.25rem;
  white-space: nowrap;
`;

const FilterWrapper = styled.div`
  position: relative;
  & > .filter-item-list {
    display: flex;
    align-items: center;
    column-gap: 0.25rem;
    overflow-x: auto;  
  }
  & > .filter-item-detail {
    position: absolute;
    top: 42px;
    left: 0;
    width: calc(100% - 0.5rem - 2px);
    background-color: white;
    z-index: 1000;
    display: flex;
    column-gap: 0.5rem;
    padding: 0.25rem;
    border: 1px solid #dadada;
    & > .filter-item-detail__list {
      flex-grow: 2;
      display: flex;
    }
  }
`;

export default function CarList () {
  return (
    <CarListWrapper>
      <CarListHeader>
        <h1>차량 리스트</h1>
        <CarListFilter>
          <FilterWrapper>
            <div className="filter-item-list">
              <FilterTag>초기화</FilterTag>
              <FilterTag>차종</FilterTag>
              <FilterTag>대여지역</FilterTag>
              <FilterTag>가격</FilterTag>
              <FilterTag>인기</FilterTag>
              <FilterTag>특가</FilterTag>
              <FilterTag>신차급</FilterTag>
              <FilterTag>빠른대여</FilterTag>
            </div>
            <div className="filter-item-detail">
              <div className="filter-item-detail__list">
                <FilterTag>초기화</FilterTag>
                <FilterTag>차종</FilterTag>
                <FilterTag>대여지역</FilterTag>
                <FilterTag>가격</FilterTag>
              </div>
              <button className="filter-item-detail__close-button">닫기</button>
            </div>
          </FilterWrapper>
        </CarListFilter>
      </CarListHeader>
      <CarListItems>
        <CarListItem>
          <div className="car-list-item">
            <div className="car-list-item__image">
              <img src="https://image.socar.kr/car_image/car086_detail1.png" alt="car_image" />
            </div>
            <div className="car-list-item__info">
              <div className="car-list-item__info__name-and-tag">
                <div className="car-list-item__info__name-and-tag__name">아반떼</div>
                <div className="car-list-item__info__name-and-tag__tag">
                  <FilterTag>인기</FilterTag>
                  <FilterTag>특가</FilterTag>
                </div>
              </div>
              <div className="car-list-item__info__price">120,000원</div>
              <div className="car-list-item__info__etc">
                2020년 | 2만km | 서울
              </div>
            </div>
          </div>
        </CarListItem>
        <CarListItem>
          <div className="car-list-item">
            <div className="car-list-item__image">
              <img src="https://image.socar.kr/car_image/car024_detail1.png" alt="car_image" />
            </div>
            <div className="car-list-item__info">
              <div className="car-list-item__info__name-and-tag">
                <div className="car-list-item__info__name-and-tag__name">스포티지</div>
                <div className="car-list-item__info__name-and-tag__tag">
                  <FilterTag>인기</FilterTag>
                  <FilterTag>특가</FilterTag>
                  <FilterTag>빠른대여</FilterTag>
                  <FilterTag>신차</FilterTag>
                </div>
              </div>
              <div className="car-list-item__info__price">120,000원</div>
              <div className="car-list-item__info__etc">
                2020년 | 2만km | 서울
              </div>
            </div>
          </div>
        </CarListItem>
        <CarListItem>
          <div className="car-list-item">
            <div className="car-list-item__image">
              <img src="https://image.socar.kr/car_image/car024_detail1.png" alt="car_image" />
            </div>
            <div className="car-list-item__info">
              <div className="car-list-item__info__name-and-tag">
                <div className="car-list-item__info__name-and-tag__name">스포티지</div>
                <div className="car-list-item__info__name-and-tag__tag">
                  <FilterTag>인기</FilterTag>
                  <FilterTag>특가</FilterTag>
                  <FilterTag>빠른대여</FilterTag>
                  <FilterTag>신차</FilterTag>
                </div>
              </div>
              <div className="car-list-item__info__price">120,000원</div>
              <div className="car-list-item__info__etc">
                2020년 | 2만km | 서울
              </div>
            </div>
          </div>
        </CarListItem>
        <CarListItem>
          <div className="car-list-item">
            <div className="car-list-item__image">
              <img src="https://image.socar.kr/car_image/car024_detail1.png" alt="car_image" />
            </div>
            <div className="car-list-item__info">
              <div className="car-list-item__info__name-and-tag">
                <div className="car-list-item__info__name-and-tag__name">스포티지</div>
                <div className="car-list-item__info__name-and-tag__tag">
                  <FilterTag>인기</FilterTag>
                  <FilterTag>특가</FilterTag>
                  <FilterTag>빠른대여</FilterTag>
                  <FilterTag>신차</FilterTag>
                </div>
              </div>
              <div className="car-list-item__info__price">120,000원</div>
              <div className="car-list-item__info__etc">
                2020년 | 2만km | 서울
              </div>
            </div>
          </div>
        </CarListItem>
        <CarListItem>
          <div className="car-list-item">
            <div className="car-list-item__image">
              <img src="https://image.socar.kr/car_image/car024_detail1.png" alt="car_image" />
            </div>
            <div className="car-list-item__info">
              <div className="car-list-item__info__name-and-tag">
                <div className="car-list-item__info__name-and-tag__name">스포티지</div>
                <div className="car-list-item__info__name-and-tag__tag">
                  <FilterTag>인기</FilterTag>
                  <FilterTag>특가</FilterTag>
                  <FilterTag>빠른대여</FilterTag>
                  <FilterTag>신차</FilterTag>
                </div>
              </div>
              <div className="car-list-item__info__price">120,000원</div>
              <div className="car-list-item__info__etc">
                2020년 | 2만km | 서울
              </div>
            </div>
          </div>
        </CarListItem>
        <CarListItem>
          <div className="car-list-item">
            <div className="car-list-item__image">
              <img src="https://image.socar.kr/car_image/car024_detail1.png" alt="car_image" />
            </div>
            <div className="car-list-item__info">
              <div className="car-list-item__info__name-and-tag">
                <div className="car-list-item__info__name-and-tag__name">스포티지</div>
                <div className="car-list-item__info__name-and-tag__tag">
                  <FilterTag>인기</FilterTag>
                  <FilterTag>특가</FilterTag>
                  <FilterTag>빠른대여</FilterTag>
                  <FilterTag>신차</FilterTag>
                </div>
              </div>
              <div className="car-list-item__info__price">120,000원</div>
              <div className="car-list-item__info__etc">
                2020년 | 2만km | 서울
              </div>
            </div>
          </div>
        </CarListItem>
        <CarListItem>
          <div className="car-list-item">
            <div className="car-list-item__image">
              <img src="https://image.socar.kr/car_image/car024_detail1.png" alt="car_image" />
            </div>
            <div className="car-list-item__info">
              <div className="car-list-item__info__name-and-tag">
                <div className="car-list-item__info__name-and-tag__name">스포티지</div>
                <div className="car-list-item__info__name-and-tag__tag">
                  <FilterTag>인기</FilterTag>
                  <FilterTag>특가</FilterTag>
                  <FilterTag>빠른대여</FilterTag>
                  <FilterTag>신차</FilterTag>
                </div>
              </div>
              <div className="car-list-item__info__price">120,000원</div>
              <div className="car-list-item__info__etc">
                2020년 | 2만km | 서울
              </div>
            </div>
          </div>
        </CarListItem>
      </CarListItems>
    </CarListWrapper>
  );
};