import React from "react";
import { useNavigate } from "react-router-dom";

import { PageLayout, LoadingAndErrorWrapper } from "../../styles/common";
import { RefreshButton } from './style';

export const PageError = () => {
  const navigate = useNavigate();

  return (
    <PageLayout>
      <LoadingAndErrorWrapper>
        <p>에러가 발생하여 페이지를 불러오지 못했습니다.</p>
        <RefreshButton onClick={() => navigate(0)}>다시 시도</RefreshButton>
      </LoadingAndErrorWrapper>
    </PageLayout>
  );
};

export default PageError;