export const CAR_FILTER_MODEL_KEY = 'carModel';
export const CAR_FILTER_REGION_KEY = 'regionGroups';
export const CAR_FILTER_PRICE_KEY = 'price';
export const CAR_FILTER_TYPE_TAG_KEY = 'carTypeTags';

export const CAR_DISCOUNT_PERCENT_KEY = 'discountPercent';

export const CAR_FILTER_MODEL = '차종';
export const CAR_FILTER_REGION = '대여지역';
export const CAR_FILTER_PRICE = '가격'
export const CAR_FILTER_HOT = '인기';
export const CAR_FILTER_SPECIAL_PRICE = '특가';
export const CAR_FILTER_GOOD_CONDITION = '신차급';
export const CAR_FILTER_FAST_RENTAL = '빠른대여';

export const CAR_MODEL_SMALL = '경형/소형';
export const CAR_MODEL_MEDIUM = '준중형';
export const CAR_MODEL_LARGE = ' 중형/대형';
export const CAR_MODEL_IMPORT = '수입';
export const CAR_MODEL_SUV = 'SUV';

export const CAR_REGION_SEOUL = '서울/경기/인천';
export const CAR_REGION_BUSAN = '부산/창원';
export const CAR_REGION_JEJU = '제주';
export const CAR_REGION_DAEGU = '대구/경북';
export const CAR_REGION_DAEJEON = '대전';
export const CAR_REGION_GWANGJU = '광주';

export const CAR_PRICE_LOW = '낮은 가격순';
export const CAR_PRICE_HIGH = '높은 가격순';

export const CAR_MODEL_INFO = [
  CAR_MODEL_SMALL,
  CAR_MODEL_MEDIUM,
  CAR_MODEL_LARGE,
  CAR_MODEL_IMPORT,
  CAR_MODEL_SUV
] as const;

export const CAR_REGION_INFO = [
  CAR_REGION_SEOUL,
  CAR_REGION_BUSAN,
  CAR_REGION_JEJU,
  CAR_REGION_DAEGU,
  CAR_REGION_DAEJEON,
  CAR_REGION_GWANGJU,
] as const;

export const CAR_PRICE_INFO = [
  CAR_PRICE_LOW,
  CAR_PRICE_HIGH,
] as const;

export const CAR_FILTER_USE_DETAIL_INFO = [
  {
    title: CAR_FILTER_MODEL,
    key: CAR_FILTER_MODEL_KEY,
    detailList: CAR_MODEL_INFO
  },
  {
    title: CAR_FILTER_REGION,
    key: CAR_FILTER_REGION_KEY,
    detailList: CAR_REGION_INFO
  },
  {
    title: CAR_FILTER_PRICE,
    key: CAR_FILTER_PRICE_KEY,
    detailList: CAR_PRICE_INFO
  }
] as const;

export const CAR_TYPE_TAG_INFO = [
  {
    title: CAR_FILTER_HOT,
    key: CAR_FILTER_TYPE_TAG_KEY,
  },
  {
    title: CAR_FILTER_SPECIAL_PRICE,
    key: CAR_FILTER_TYPE_TAG_KEY
  },
  {
    title: CAR_FILTER_GOOD_CONDITION,
    key: CAR_FILTER_TYPE_TAG_KEY
  },
  {
    title: CAR_FILTER_FAST_RENTAL,
    key: CAR_FILTER_TYPE_TAG_KEY
  }
] as const;

export const CAR_FILTER_INFO = [
  ...CAR_FILTER_USE_DETAIL_INFO,
  ...CAR_TYPE_TAG_INFO
] as const;

export const CAR_FILTER_USE_DETAIL_KEY_INFO = [
  CAR_FILTER_USE_DETAIL_INFO.map(({ key }) => key),
] as const;

export const CAR_FILTER_TITLE_INFO = [
  ...CAR_FILTER_USE_DETAIL_INFO.map(({ title }) => title),
  ...CAR_TYPE_TAG_INFO.map(({ title }) => title),
] as const;

export const CAR_SAVED_FILTER_INITIAL_VALUE = {
  [CAR_FILTER_MODEL_KEY]: [],
  [CAR_FILTER_REGION_KEY]: [],
  [CAR_FILTER_PRICE_KEY]: [],
  [CAR_FILTER_TYPE_TAG_KEY]: []
}

export const CAR_FILTER_KEY_TITLE_INFO = Object.keys(CAR_SAVED_FILTER_INITIAL_VALUE) as const;
