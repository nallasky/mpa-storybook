import * as Constant from "./constant";

export type TCarModel = typeof Constant.CAR_MODEL_INFO[number];
export type TCarRegion = typeof Constant.CAR_REGION_INFO[number];
export type TCarPrice = typeof Constant.CAR_PRICE_INFO[number];
export type TCarTypeTag = typeof Constant.CAR_TYPE_TAG_INFO[number];
export type TCarSavedFilterValue = TCarModel[] | TCarRegion[] | TCarPrice[] | TCarTypeTag[];
export type TCarDetailFilterList = TCarModel[] | TCarRegion[] | TCarPrice[];
export type TCarDetailFilterTitle = TCarModel | TCarRegion | TCarPrice;
export type TCarFilterUseDetailKey = typeof Constant.CAR_FILTER_USE_DETAIL_KEY_INFO[number];

export interface IChangeSavedFilter {
  key: typeof Constant.CAR_FILTER_KEY_TITLE_INFO[number],
  value: TCarSavedFilterValue
}

export interface ICarFilterItem {
  title: typeof Constant.CAR_FILTER_TITLE_INFO[number],
  key: typeof Constant.CAR_FILTER_KEY_TITLE_INFO[number],
  detailList?: TCarDetailFilterList
}

export interface ISavedFilter {
  [Constant.CAR_FILTER_MODEL_KEY]: TCarModel[],
  [Constant.CAR_FILTER_REGION_KEY]: TCarRegion[],
  [Constant.CAR_FILTER_PRICE_KEY]: TCarPrice[],
  [Constant.CAR_FILTER_TYPE_TAG_KEY]: TCarTypeTag[]
}