import React from "react";
import { useQuery } from "@tanstack/react-query";

import { fetchCarClasses } from "../../api/carList/api";
import CarListFilter from "../../components/carList/carListFilter/carListFilter";
import ListPage from "../../components/layout/listPage";
import CarListItems from "../../components/carList/carListItems/carListItems";


export default function CarList () {
  const { data } = useQuery(
    ['carClasses'],
    fetchCarClasses,
    { suspense: true }
  );

  return (
    <ListPage
      title="차량 리스트"
      header={<CarListFilter />}
    >
      <CarListItems data={data} />
    </ListPage>
  );
};