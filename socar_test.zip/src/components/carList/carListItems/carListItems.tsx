import React from "react";

import { ICarClass } from "../../../types/response";
import { TCarTypeTag } from "../../../pages/carList/type";
import { CarListItemsWrapper, CarListItem } from "./style";
import { ICarListItems } from "./type";
import Tag from "../../tag/tag";

const CarListItems = ({ data }: ICarListItems) => {
  return (
    <CarListItemsWrapper>
      {data.map((item: ICarClass) => {
        const { carClassId, carClassName, image, price, carTypeTags, year, drivingDistance, regionGroups } = item;
        return (
          <CarListItem key={carClassId}>
            <div className="car-list-item">
              <div className="car-list-item__image">
                <img src={image} alt="car_image" />
              </div>
              <div className="car-list-item__info">
                <div className="car-list-item__info__name-and-tag">
                  <div className="car-list-item__info__name-and-tag__name">{carClassName}</div>
                  <div className="car-list-item__info__name-and-tag__tag">
                    {carTypeTags.map((title: TCarTypeTag, i: number) => {
                      return (
                        <Tag key={i} title={title} />
                      );
                    })}
                  </div>
                </div>
                <div className="car-list-item__info__price">{`${price.toLocaleString()}원`}</div>
                <div className="car-list-item__info__etc">
                  {`${year}년 | ${drivingDistance}km | ${regionGroups.join(', ')}`}
                </div>
              </div>
            </div>
          </CarListItem>
        )
      })}
    </CarListItemsWrapper>
  )
};

export default CarListItems;