import { ICarClass } from "../../../types/response";

export interface ICarListItems {
  data: ICarClass[]
}