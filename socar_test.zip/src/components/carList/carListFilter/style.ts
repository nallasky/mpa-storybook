import styled from "styled-components";

export const CarListFilterWrapper = styled.div`
  position: relative;
  border-top: var(--default-border);
  border-bottom: var(--default-border);
`;


export const CarListFilterItems = styled.ul`
  display: flex;
  align-items: center;
  margin: 0;
  padding: 0.5rem;
  column-gap: 0.5rem;
  overflow-x: auto;
`;

export const CarFilterDetailPopUp = styled.div`
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  background-color: white;
  z-index: 1000;
  border: var(--default-border);
  & > .filter-item-detail__content {
    display: flex;
    padding: 0.5rem;
    column-gap: 0.5rem;
    & > .filter-item-detail__content__list {
      flex-grow: 2;
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 0.5rem;
    }
    & > .filter-item-detail__content__close-button {
      align-self: self-start;
      font-size: 16px;
      white-space: pre;
      font-size: 20px;
      font-weight: bold;
      color: #9b9b9b;
      cursor: pointer;
    }
  }
`;

export const CarFilterDetailPopUpBg = styled.div`
  position: fixed;
  top: 0;
  width: var(--default-page-width);
  height: 100%;
  z-index: 999;
  background-color: rgba(0,0,0,0.25);
`;

