import React, { useState } from "react";

import { ICarFilterItem, TCarDetailFilterTitle, TCarFilterUseDetailKey } from "../../../pages/carList/type";
import { CAR_FILTER_INFO } from "../../../pages/carList/constant";
import { CarListFilterWrapper, CarListFilterItems, CarFilterDetailPopUp, CarFilterDetailPopUpBg } from "./style";
import ActiveTag from "../../activeTag/activeTag";
import ButtonCheckBox from "../../buttonCheckBox/buttonCheckBox";


const CarListFilter = () => {
  const [selectedDetailFilter, setSelectedDetailFilter] = useState<TCarFilterUseDetailKey | undefined>(undefined);

  return (
    <CarListFilterWrapper>
      <CarListFilterItems>
        <li>
          <ActiveTag title="초기화" disableCloseButton onTagClickHandler={() => {}} onCloseHandler={() => {}} />
        </li>
        {CAR_FILTER_INFO.map((v: ICarFilterItem, i: number) => {
          return (
            <li key={i}>
              <ActiveTag
                title={v.title}
                onTagClickHandler={() => {}}
                onCloseHandler={() => {}}
              />
            </li>
          );
        })}
        {!!CAR_FILTER_INFO[selectedDetailFilter]?.detailList &&
        <>
          <CarFilterDetailPopUp>
            <div className="filter-item-detail__content">
              <ul className="filter-item-detail__content__list">
                {CAR_FILTER_INFO[selectedDetailFilter].detailList.map((v: TCarDetailFilterTitle, i: number) => {
                  return (
                    <li key={i}>
                      <ButtonCheckBox
                        title={v}
                        checked={false}
                        onChangeHandler={() => {}}
                      />
                    </li>
                  )
                })}
              </ul>
              <a className="filter-item-detail__content__close-button" href="#" role="button">X</a>
            </div>
          </CarFilterDetailPopUp>
          <CarFilterDetailPopUpBg />
        </>
        }
      </CarListFilterItems>
    </CarListFilterWrapper>
  )
};

export default CarListFilter;