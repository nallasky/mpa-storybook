import React from "react";

import { CheckBoxWrapper } from "./style";
import { IButtonCheckBox } from "./type";

const ButtonCheckBox = ({
  title,
  checked,
  onChangeHandler,
}: IButtonCheckBox) => {
  return (
    <CheckBoxWrapper>
      <input
        type="checkbox"
        checked={checked}
        onChange={() => onChangeHandler(!checked)}
      />
      <span className="checkbox-title">{title}</span>
    </CheckBoxWrapper>
  );
};

export default ButtonCheckBox;

