import styled from "styled-components";

export const ListPageHeader = styled.header`
  position: sticky;
  top: 0;
  height: 100%;
  background-color: white;
  z-index: 100;
  & > h1 {
    margin: 0;
    padding: 2rem 0;
    font-size: 2rem;
  }
`;

export const ListPageBody = styled.div`
  padding: 0.5rem;
`;