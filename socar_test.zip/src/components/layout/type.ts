export interface IPageLayout {
  title: string,
  header?: () => JSX.Element,
  children: () => JSX.Element
}