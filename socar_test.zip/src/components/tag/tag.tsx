import React from "react";

import { ITag } from "./type";
import { TagWrapper } from "./style";

const Tag = ({ title }: ITag) => {
  return (
    <TagWrapper>{title}</TagWrapper>
  );
};

export default Tag;