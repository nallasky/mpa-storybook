import * as React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import { URL_CAR_LIST_PAGE } from "./constants/url";
import CarList from "./pages/carList";

import "./App.css";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to={URL_CAR_LIST_PAGE} replace />} />
        <Route path={URL_CAR_LIST_PAGE} element={<CarList />} />
      </Routes>
    </Router>
  );
}

export default App;
