import type { TCarModel, TCarRegion, TCarTypeTag } from "../pages/carList/type";

export interface ICarClass {
  carClassId: number,
  carClassName: string,
  carModal: TCarModel,
  image: string,
  drivingDistance: number,
  year: number,
  price: number,
  discountPercent: number,
  regionGroups: TCarRegion[],
  carTypeTags: TCarTypeTag[],
}