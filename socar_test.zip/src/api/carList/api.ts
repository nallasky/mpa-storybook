import axios, { AxiosResponse } from "axios";

import { GET_CAR_CLASSES } from "../../constants/url";

export async function fetchCarClasses () {
  return await axios(GET_CAR_CLASSES).then((res) => res.data);
}