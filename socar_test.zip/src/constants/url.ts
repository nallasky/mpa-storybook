export const URL_CAR_LIST_PAGE = "/list";
export const GET_CAR_CLASSES = 'http://localhost:8080/carClasses';