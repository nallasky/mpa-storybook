class RapidConnectionError(Exception):
    pass
