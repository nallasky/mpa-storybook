create table analysis.function
(
    id            serial  not null
        constraint function_pk
            primary key,
    category_id   integer not null
        constraint function_category_id_fk
            references analysis.category
            on update cascade on delete cascade,
    title         text    not null,
    source_type   text    not null
        constraint function_source_type_type_fk
            references source_type (type)
            on update cascade on delete cascade,
    analysis_type text    not null
        constraint function_analysis_type_type_fk
            references analysis_type (type)
            on update cascade on delete cascade
);

create unique index function_id_uindex
    on analysis.function (id);

