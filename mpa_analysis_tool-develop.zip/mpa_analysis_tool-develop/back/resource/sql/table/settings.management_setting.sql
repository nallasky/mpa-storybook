create table settings.management_setting
(
    id       serial not null
        constraint management_setting_pk
            primary key,
    target   text   not null,
    host     text   not null,
    username text   not null,
    password text   not null,
    dbname   text   not null,
    port     text   not null
);

create unique index management_setting_id_uindex
    on settings.management_setting (id);