import os

from config import app_config
from common.utils.response import ResponseForm


class ScriptBase:
    def __init__(self, **kwargs):
        if 'file_path' in kwargs:
            self.input_log_file = kwargs['file_path']

    def __del__(self):
        pass

    def readlines(self):
        with open(self.input_log_file, mode='r+', encoding='utf-8') as f:
            lines = f.readlines()

        lines = [line.rstrip('\n') for line in lines]

        return lines

    def save_file(self, file, filename):
        # try:
        #     if not os.path.exists(app_config.TEMP_PATH):
        #         os.mkdir(app_config.TEMP_PATH)
        #
        #     file_path = os.path.join(app_config.TEMP_PATH, filename)
        #     file.save(file_path)
        #
        #     return ResponseForm(res=True)
        # except Exception as e:
        #     return ResponseForm(res=False, msg=str(e))
        print('super method')
