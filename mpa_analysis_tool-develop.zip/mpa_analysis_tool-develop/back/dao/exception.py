class DatabaseQueryException(Exception):
    pass