from dao.dao_base import DAOBaseClass


class DAOAnalysisItems(DAOBaseClass):
    TABLE_NAME = 'analysis.analysis_items'

    def __init__(self, func_id=None, df=None):
        super().__init__(table_name=DAOAnalysisItems.TABLE_NAME)
        if func_id is not None:
            self.df = self.fetch_all(args={'where': f"func_id='{func_id}'"})
        elif df is not None:
            self.df = df

    def __del__(self):
        super().__del__()
        print('__del__', __class__)

    def get_columns_comma_separated(self):
        columns = self.df['source_col'].unique().tolist()

        return ', '.join(columns)

    # def get_operation_list(self):
    #     return self.df['op_type'].dropna(axis=0).unique().tolist()

    def get_unique_cell_formula_list(self):
        cell_formula = self.df['cell_formula'].dropna(axis=0)
        # cell_list = full_unit.apply(lambda x: x.split('|')[0])

        return cell_formula.unique()

    def get_unique_all_formula_list(self, cell_form=None):
        if cell_form is None:
            all_formula = self.df['all_formula'].dropna(axis=0)
            # full_unit = self.df[operation].dropna(axis=0)
            # all_list = full_unit.apply(lambda x: x.split('|')[1])

        else:
            all_formula = self.df[self.df['cell_formula'] == cell_form]['all_formula'].dropna(axis=0)
            # cell_list = full_unit.apply(lambda x: x.split('|')[0])
            # all_list = full_unit[cell_list == cell_unit].apply(lambda x: x.split('|')[1])

        return all_formula.unique()

    def get_seq_group_analysis_list(self):
        group_analysis = self.df[['group_analysis', 'group_analysis_type']].dropna(axis=0)
        # cell_list = full_unit.apply(lambda x: x.split('|')[0])

        group_analysis = group_analysis.drop_duplicates(subset=['group_analysis'])

        return group_analysis.to_dict(orient='records')

    def get_seq_total_analysis_list(self, group_analysis):
        total_analysis = self.df[self.df['group_analysis'] == group_analysis]
        total_analysis = total_analysis[['total_analysis', 'total_analysis_type']].dropna(axis=0)

        total_analysis = total_analysis.drop_duplicates(subset=['total_analysis'])

        return total_analysis.to_dict(orient='records')

    def get_column_list(self, group_analysis=None, total_analysis=None):
        select_df = self.df

        if group_analysis is not None:
            select_df = select_df[select_df['group_analysis'] == group_analysis]

        if total_analysis is not None:
            select_df = select_df[select_df['total_analysis'] == total_analysis]

        # select_df = self.df[(self.df['op_type'] == op_type) & (self.df['cell_formula'] == cell_form)]
        # select_df = self.df[['column_name', operation]].dropna(axis=0)
        # cell_list = select_df[operation].apply(lambda x: x.split('|')[0])

        columns = select_df['source_col'].dropna(axis=0).unique().tolist()

        return columns

    def get_disp_str_dict(self, col_list, group_analysis=None):
        if group_analysis is None:
            select_df = self.df[self.df['source_col'].isin(col_list)]
        else:
            select_df = self.df[(self.df['group_analysis'] == group_analysis) & (self.df['source_col'].isin(col_list))]

        dict = {}
        for i in range(len(select_df)):
            dict[select_df.iloc[i]['source_col']] = select_df.iloc[i]['title']

        return dict

    # def get_detail_disp_str_dict(self, col_list):
    #     select_df = self.df[self.df['column_name'].isin(col_list)]
    #
    #     dict = dict()
    #     for i in range(len(select_df)):
    #         dict[select_df.iloc[i]]['column_name'] = select_df.iloc[i]['detail_disp_str']
    #
    #     return dict

    def sort_by_disp_order(self, columns, group_name):
        df = self.df.sort_values(by='disp_order', ascending=True)

        disp_order = []
        for i in range(len(df)):
            if df.iloc[i]['title'] in columns:
                disp_order.append(df.iloc[i]['title'])

        # if 'Process' in columns:
        #     disp_order.insert(0, 'Process')
        #
        # if 'Device' in columns:
        #     disp_order.insert(0, 'Device')
        #
        # if 'Date' in columns:
        #     disp_order.insert(0, 'Date')
        if 'process' in columns:
            disp_order.insert(0, 'process')

        if 'device' in columns:
            disp_order.insert(0, 'device')

        if 'log_time' in columns:
            disp_order.insert(0, 'log_time')

        if group_name in columns:
            disp_order.insert(0, group_name)

        if 'No.' in columns:
            disp_order.insert(0, 'No.')

        return disp_order

    def sort_by_column_order(self, columns, group_name):
        df = self.df.sort_values(by='disp_order', ascending=True)
        column_list = df['source_col'].unique().tolist()

        disp_order = []
        for column in column_list:
            if column in columns:
                disp_order.append(column)

        if 'process' in columns:
            disp_order.insert(0, 'process')

        if 'device' in columns:
            disp_order.insert(0, 'device')

        if 'log_time' in columns:
            disp_order.insert(0, 'log_time')

        if group_name not in disp_order and group_name in columns:
            disp_order.insert(0, group_name)

        if 'index' in columns:
            disp_order.insert(0, 'index')

        return disp_order

    def get_disp_srt_vs_disp_graph_f_dict(self, columns):
        df = self.df.sort_values(by='disp_order', ascending=True)

        disp_graph_dict = dict()
        for i in range(len(df)):
            disp_graph_dict[df.iloc[i]['title']] = df.iloc[i]['disp_graph_f']

        if 'Process' in columns:
            disp_graph_dict['Process'] = False

        if 'Device' in columns:
            disp_graph_dict['Device'] = False

        if 'Date' in columns:
            disp_graph_dict['Date'] = False

        if 'No.' in columns:
            disp_graph_dict['No.'] = False

        return disp_graph_dict

    def get_column_name_vs_disp_graph_f_dict(self, columns):
        df = self.df.sort_values(by='disp_order', ascending=True)

        disp_graph_dict = dict()
        for i in range(len(df)):
            disp_graph_dict[df.iloc[i]['column_name']] = df.iloc[i]['disp_graph_f']

        if 'process' in columns:
            disp_graph_dict['process'] = False

        if 'device' in columns:
            disp_graph_dict['device'] = False

        if 'log_time' in columns:
            disp_graph_dict['log_time'] = False

        if 'period' in columns:
            disp_graph_dict['period'] = False

        if 'index' in columns:
            disp_graph_dict['index'] = False

        return disp_graph_dict

    def get_analysis_list_by_order(self):
        self.df.sort_values(by='disp_order', ascending=True, inplace=True)
        return self.df.to_dict(orient='records')
