import pytest
import requests
import json
import time

URL = 'http://localhost:5000'

# @pytest.fixture
# def api():
#     app = create_app('../config.py')
#     app.config['TESTING'] = True
#     api = app.test_client()
#
#     return api

# def test_sample():
#     # GET /
#     # HTTP Status Code : 200
#     time.sleep(1)
#     response = requests.get('http://localhost:5000/main')
#     assert response.status_code == 200
