

def is_period_valid(one_period, adj_period):
    """
    one_period と adj_period の妥当性チェック

    - 0h, 0d, 0m は term 向けの特殊定義。lot の場合は None と同意。
    - term の場合、何もしないと Period が無い状態の場合の統計処理がログ先頭timestampからの
      統計間隔になってしまう。0[hdm]設定する場合、それ以下の単位をクリアし、奇麗な統計区間にする。

    :param str|None one_period: 期間の時間単位(0h, 1h, 2h, 4h, 6h, 12h, 24h, 0d～, 0m～) or None
    :param str|None adj_period: 期間の節目(0h-23h, 1d-31d, 0d:first day of log_list) or None
    :rtype: bool
    :return: True:妥当である, False:NG
    """
    period_hour_list = (1, 2, 3, 4, 6, 12, 24)

    # if one_period is None:
    #     # 期間を使用しない設定であればそのままOKとする
    #     return True, ''

    if one_period in ('0h', '0d', '0m'):
        return False, 'Illegal Period : {0}, {1}.'.format(one_period, adj_period)

    if len(one_period) < 2 or len(adj_period) < 2:
        return False, 'Illegal Period : {0}, {1}.'.format(one_period, adj_period)

    try:
        one_period_val, one_period_unit = int(one_period[0:-1]), one_period[-1]
        adj_period_val, adj_period_unit = int(adj_period[0:-1]), adj_period[-1]
    except ValueError:
        return False, 'Illegal Period Val : {0}, {1}.'.format(one_period, adj_period)

    if one_period_unit not in ('h', 'd', 'm'):
        return False, 'Illegal Period Unit : {0}, {1}.'.format(one_period, adj_period)

    if one_period_unit == 'h' and adj_period_unit != 'h':
        return False, 'Unmatch Period Unit : {0}, {1}.'.format(one_period, adj_period)

    if one_period_unit != 'h' and adj_period_unit != 'd':
        return False, 'Unmatch Period Unit : {0}, {1}.'.format(one_period, adj_period)

    # pariod_hourは1日を割れる時間しか受け入れない（周期性を前提とする実装)
    if one_period_unit == 'h' and one_period_val not in period_hour_list:
        return False, 'Illegal Period : {0}, {1}.'.format(one_period, adj_period)

    if one_period_val <= 0:
        return False, 'Illegal Period : {0}, {1}.'.format(one_period, adj_period)

    if adj_period_unit == 'h' and (adj_period_val < 0 or adj_period_val > 23):
        return False, 'Illegal Adjust Period : {0}, {1}.'.format(one_period, adj_period)

    if adj_period_unit == 'd' and (adj_period_val < 0 or adj_period_val > 31):
        return False, 'Illegal Adjust Period : {0}, {1}.'.format(one_period, adj_period)

    return True, ''
