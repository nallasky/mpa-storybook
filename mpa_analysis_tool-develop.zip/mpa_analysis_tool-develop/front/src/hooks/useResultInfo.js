import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import * as slice from '../reducers/slices/ResultInfo';

const useResultInfo = () => {
  const dispatch = useDispatch();

  const setAnalysisInfo = useCallback(
    (v) => {
      dispatch(slice.UpdateAnalysisReducer(v));
    },
    [dispatch],
  );

  const setOriginalInfo = useCallback(
    (v) => {
      dispatch(slice.UpdateOriginalReducer(v));
    },
    [dispatch],
  );

  const setGraphType = useCallback(
    (v) => {
      dispatch(slice.UpdateGraphTypeReducer(v));
    },
    [dispatch],
  );

  const setSelectedRow = useCallback(
    (v) => {
      dispatch(slice.UpdateSelectedRowReducer(v));
    },
    [dispatch],
  );

  const setOriginalGraphData = useCallback(
    (v) => {
      dispatch(slice.UpdateOriginalGraphDataReducer(v));
    },
    [dispatch],
  );

  const setAnalysisGraphInfo = useCallback(
    (v) => {
      dispatch(slice.UpdateAnalysisGraphDataReducer(v));
    },
    [dispatch],
  );

  const setHistoryGraphData = useCallback(
    (v) => {
      dispatch(slice.UpdateHistoryGraphDataReducer(v));
    },
    [dispatch],
  );

  const setHistoryGraphFilter = useCallback(
    (v) => {
      dispatch(slice.UpdateHistoryGraphFilterReducer(v));
    },
    [dispatch],
  );

  const setSavedAnalysisAggregation = useCallback(
    (v) => {
      dispatch(slice.UpdateSavedAnalysisAggregationReducer(v));
    },
    [dispatch],
  );

  const initializing = useCallback(() => {
    dispatch(slice.initialAction());
  }, [dispatch]);

  return {
    analysisData: useSelector((state) => state.ResultInfo.analysis),
    originalData: useSelector((state) => state.ResultInfo.original),
    graphType: useSelector((state) => state.ResultInfo.graphType),
    selectedRow: useSelector((state) => state.ResultInfo.selectedRow),
    originalGraphData: useSelector(
      (state) => state.ResultInfo.originalGraphData,
    ),
    analysisGraphInfo: useSelector(
      (state) => state.ResultInfo.analysisGraphInfo,
    ),
    historyGraphData: useSelector((state) => state.ResultInfo.historyGraphData),
    historyGraphFilter: useSelector(
      (state) => state.ResultInfo.historyGraphFilter,
    ),
    savedAnalysisAggregation: useSelector(
      (state) => state.ResultInfo.savedAnalysisAggregation,
    ),
    setAnalysisInfo,
    setOriginalInfo,
    setGraphType,
    setSelectedRow,
    setOriginalGraphData,
    setAnalysisGraphInfo,
    setHistoryGraphData,
    setHistoryGraphFilter,
    setSavedAnalysisAggregation,
    initializing,
  };
};

export default useResultInfo;
