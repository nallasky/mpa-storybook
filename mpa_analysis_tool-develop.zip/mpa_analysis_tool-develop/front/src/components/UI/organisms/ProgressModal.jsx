import React, { useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { Modal } from '../atoms/Modal';
import Button from '../atoms/Button';
import { css } from '@emotion/react';
import { Spin, Progress } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';

const contentStyle = css`
  display: block;
`;

const gridContentWrapper = css`
  display: grid;
  grid-template-columns: 1fr 1fr;
  justify-items: center;
  & > div > div:last-of-type > p {
    margin-bottom: 0;
  }
  margin: 1rem 0;
`;

const ProcessIconStyle = css`
  display: flex;
  align-items: center;
  justify-contents: center;
`;

const footerStyle = css`
  display: flex;
  justify-content: flex-end;
  align-items: center;
`;
const useInterval = (callback, delay) => {
  const savedCallback = useRef();

  // Remember the latest callback.
  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  // Set up the interval.
  useEffect(() => {
    function tick() {
      savedCallback.current();
    }
    if (delay !== null) {
      let id = setInterval(tick, delay);
      return () => clearInterval(id);
    }
  }, [delay]);
};
/*****************************************************************************
 *              Main Modal
 *****************************************************************************/

const ProgressModal = ({ isOpen, closeFunc, statusFunc }) => {
  const [status, setStatus] = useState('idle');
  const [percent, setPercent] = useState(0);
  const [contents, setContents] = useState(null);
  const total = contents?.total_files ?? 0;
  const completed = contents?.error_files ?? 0 + contents?.success_files ?? 0;
  const status_msg = status === 'error' || (total>0 && completed === total && contents?.converted === 0)
      ? 'ERROR'
      : status === 'success'
      ? 'COMPLETE'
      : 'PROCESS';

  useInterval(
    () => {
      // Your custom logic here
      statusFunc(setStatus, setPercent, setContents);
    },
    isOpen && status_msg === 'PROCESS' ? 1000 : null,
  );

  const closeModal = () => {
    closeFunc(completed !== total ? status : 'success', 0);
  };
  useEffect(() => {
    console.log('=======useEffect========');
    if (status === 'success') {
      closeFunc(status_msg, contents.converted);
    }
  }, [status, contents?.converted ?? undefined]);
  if (isOpen === false) return <></>;

  return (
    <>
      <Modal
        isOpen={isOpen}
        header={
          <div>
            {
              status_msg /*status === 'error'
              ? 'ERROR'
              : status === 'success'
              ? 'COMPLETE'
              : completed === total && contents?.converted === 0
              ? 'ERROR'
              : 'PROCESS'*/
            }
          </div>
        }
        content={
          <Contents type={status_msg} percent={percent} contents={contents} />
        }
        footer={
          <ModalFooter
            closeFunc={closeModal}
            btnText={
              status === 'success' || completed === total ? 'Close' : 'Cancel'
            }
          />
        }
        closeIcon={false}
      />
    </>
  );
};

ProgressModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  closeFunc: PropTypes.func.isRequired,
  statusFunc: PropTypes.func.isRequired,
};

/*****************************************************************************
 *              Modal Contents
 *****************************************************************************/
const ErrorContents = css`
  flex: none;
  order: 0;
  flex-grow: 1;
  margin: 0px 10px;
`;

const ItemDiv = css`
  color: rgba(0, 0, 0, 0.65);
  font-size: 14px;
  & > p {
    margin-right: 0.5rem;
  }
`;

const ItemLabel = css`
  display: inline-block;
  color: rgba(0, 0, 0, 0.85);
  margin-left: 1rem;
`;

const Contents = ({ type, percent, contents }) => {
  if (contents === null) {
    const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;
    return (
      <div css={contentStyle}>
        {
          <div css={ErrorContents}>
            <div css={ItemDiv}>
              <Spin indicator={antIcon} />
              <div css={ItemLabel}>File uploading</div>
            </div>
          </div>
        }
      </div>
    );
  }

  return (
    <div css={gridContentWrapper}>
      <div>
        <div css={ItemDiv}>
          <p css={ItemLabel}>Error Files:</p>
          {contents.error_files}
        </div>
        <div css={ItemDiv}>
          <p css={ItemLabel}>Success Files:</p>
          {contents.success_files}
        </div>
        <div css={ItemDiv}>
          <p css={ItemLabel}>Total Files:</p>
          {contents.total_files}
        </div>
        <div css={ItemDiv}>
          <p css={ItemLabel}>Converted rows:</p>
          {contents.converted}
        </div>
      </div>
      {type === 'COMPLETE' ? (
        <Progress type="circle" percent={100} css={ProcessIconStyle} />
      ) : type === 'PROCESS' ? (
        <Progress type="circle" percent={percent} css={ProcessIconStyle} />
      ) : (
        <Progress
          type="circle"
          percent={percent}
          status="exception"
          css={ProcessIconStyle}
        />
      )}
    </div>
  );
};
Contents.propTypes = {
  type: PropTypes.string,
  percent: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  contents: PropTypes.object,
};

/*****************************************************************************
 *              Modal Footer
 *****************************************************************************/

const ModalFooter = ({ btnText, closeFunc }) => {
  return (
    <div css={footerStyle}>
      <Button
        theme={'blue'}
        onClick={closeFunc}
        style={{ marginLeft: '8px', fontWeight: 400 }}
      >
        {btnText ? btnText : 'Close'}
      </Button>
    </div>
  );
};

ModalFooter.propTypes = {
  btnText: PropTypes.string,
  closeFunc: PropTypes.func.isRequired,
};

export default ProgressModal;
