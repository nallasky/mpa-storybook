export { default } from './VersionInfo';
