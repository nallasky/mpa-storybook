export { default } from './Divider';
