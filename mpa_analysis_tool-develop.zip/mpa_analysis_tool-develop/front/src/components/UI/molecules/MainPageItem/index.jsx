export { default } from './MainPageItem';
