import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Select, Checkbox, Empty } from 'antd';
import SettingGraph from '../SettingGraph';
import * as fn from './functionGroup';
import * as sg from './styleGroup';
import useResultInfo from '../../../../hooks/useResultInfo';

const { Option } = Select;

const Visualization = React.memo(
  ({ gType, data, order, graphList, type }) => {
    const {
      setHistoryGraphData,
      setHistoryGraphFilter,
      historyGraphFilter,
      analysisGraphInfo,
    } = useResultInfo();
    const prevProps = fn.usePrevious({
      gType,
      data,
      order,
      graphList,
      analysisGraphInfo,
    });
    const [graphType, setGraphType] = useState([]);
    const [dataInfo, setDataInfo] = useState({
      x: [],
      y: {},
      z: [],
    });
    const [optionInfo, setOptionInfo] = useState({
      x: '',
      y: [],
      z: '',
    });
    const [enableZ, setEnableZ] = useState(false);
    const [optionAll, setOptionAll] = useState(false);

    const updateHistoryDataAll = (dInfo, filterInfo) => {
      setHistoryGraphData(
        fn.createHistoryGraphData(
          dInfo.graphList,
          dInfo.graphType,
          dInfo.x,
          dInfo.z,
        ),
      );
      setHistoryGraphFilter(
        fn.createHistoryFilterData(
          filterInfo.graphList,
          filterInfo.baseFilter,
          filterInfo.axisInfo,
        ),
      );
    };

    const changeType = (value) => {
      let isEnable = false;

      if (value.length > 0) {
        isEnable = value.some(
          (v) =>
            gType[
              gType.findIndex((i) => i.type.toLowerCase() === v || i.type === v)
            ].z_axis,
        );
      }

      setGraphType(value);
      setEnableZ(isEnable);
      if (type === 'analysis') {
        setHistoryGraphData(
          fn.createHistoryGraphData(
            optionInfo.y,
            value.length > 0 ? value.map((v) => v.toLowerCase()) : [],
            optionInfo.x,
            optionInfo.z,
          ),
        );
      }
    };

    const changeX = (value) => {
      const newX = fn.createXZdata(value, data);
      setOptionInfo((prevState) => {
        return {
          ...prevState,
          x: value,
        };
      });
      setDataInfo((prevState) => {
        return {
          ...prevState,
          x: newX,
        };
      });
      if (type === 'analysis') {
        updateHistoryDataAll(
          {
            graphList: optionInfo.y,
            graphType: graphType,
            x: value,
            z: optionInfo.z,
          },
          {
            graphList: optionInfo.y,
            baseFilter: historyGraphFilter,
            axisInfo: {
              x: newX,
              y: dataInfo.y,
              z: dataInfo.z,
            },
          },
        );
      }
    };

    const changeY = (values) => {
      const newGraphList = graphList.filter(
        (v) => values.findIndex((y) => v === y) !== -1,
      );
      const newYinfo =
        newGraphList.length === 0 ? {} : fn.createYdata(newGraphList, data);
      setOptionInfo((prevState) => {
        return {
          ...prevState,
          y: newGraphList,
        };
      });
      setDataInfo((prevState) => {
        return {
          ...prevState,
          y: newYinfo,
        };
      });

      setOptionAll(values.length === graphList.length);
      if (type === 'analysis') {
        updateHistoryDataAll(
          {
            graphList: newGraphList,
            graphType: graphType,
            x: optionInfo.x,
            z: optionInfo.z,
          },
          {
            graphList: newGraphList,
            baseFilter: historyGraphFilter,
            axisInfo: {
              x: dataInfo.x,
              y: newYinfo,
              z: dataInfo.z,
            },
          },
        );
      }
    };

    const changeZ = (value) => {
      const newZ = fn.createXZdata(value, data);
      setOptionInfo((prevState) => {
        return {
          ...prevState,
          z: value,
        };
      });
      setDataInfo((prevState) => {
        return {
          ...prevState,
          z: newZ,
        };
      });

      if (type === 'analysis') {
        updateHistoryDataAll(
          {
            graphList: optionInfo.y,
            graphType: graphType,
            x: optionInfo.x,
            z: value,
          },
          {
            graphList: optionInfo.y,
            baseFilter: historyGraphFilter,
            axisInfo: {
              x: dataInfo.x,
              y: dataInfo.y,
              z: newZ,
            },
          },
        );
      }
    };

    const changeAll = () => {
      setOptionAll(!optionAll);
      changeY(!optionAll ? graphList : []);
    };

    useEffect(() => {
      const isFirst = prevProps === undefined;
      if (type === 'analysis') {
        let newOptionInfo = {},
          newGraphType = [],
          baseFilter = historyGraphFilter;
        if (analysisGraphInfo.length > 0) {
          if (
            !isFirst &&
            JSON.stringify(prevProps.analysisGraphInfo) !==
              JSON.stringify(analysisGraphInfo)
          ) {
            newGraphType = analysisGraphInfo[0].type.map((v) =>
              v.toLowerCase(),
            );
            newOptionInfo = {
              x: analysisGraphInfo[0].x_axis,
              y: analysisGraphInfo.map((v) => v.title),
              z: analysisGraphInfo[0].z_axis,
            };
            baseFilter = analysisGraphInfo;
          }
        }

        if (Object.keys(newOptionInfo).length === 0) {
          const listChange =
            !isFirst &&
            JSON.stringify(prevProps.graphList) !== JSON.stringify(graphList);
          newOptionInfo = {
            x:
              !isFirst &&
              JSON.stringify(prevProps.order) !== JSON.stringify(order)
                ? order[1]
                : optionInfo.x,
            y: listChange ? graphList : optionInfo.y,
            z: listChange ? graphList[0] : optionInfo.z,
          };
        }

        if (newGraphType.length === 0) {
          newGraphType =
            !isFirst &&
            JSON.stringify(prevProps.gType) !== JSON.stringify(gType)
              ? [gType[0].type.toLowerCase()]
              : graphType;
        }

        setGraphType(newGraphType);
        const newDataInfo = fn.createData(
          newOptionInfo.x,
          newOptionInfo.y,
          newOptionInfo.z,
          data,
        );
        setOptionInfo(newOptionInfo);
        setEnableZ(fn.initEnableZ(newOptionInfo.y, newGraphType));
        setOptionAll(newOptionInfo.y.length === graphList.length);
        setDataInfo(newDataInfo);
        updateHistoryDataAll(
          {
            graphList: newOptionInfo.y,
            graphType: newGraphType,
            x: newOptionInfo.x === '' ? 'None' : newOptionInfo.x,
            z: newOptionInfo.z === '' ? 'None' : newOptionInfo.z,
          },
          {
            graphList: newOptionInfo.y,
            baseFilter: baseFilter,
            axisInfo: newDataInfo,
          },
        );
      } else {
        const newOptionInfo = {
          x: isFirst ? order[1] : optionInfo.x,
          y: isFirst ? graphList : optionInfo.y,
          z: isFirst ? graphList[0] : optionInfo.z,
        };
        if (isFirst) {
          setGraphType([gType[0].type.toLowerCase()]);
          setOptionAll(true);
          setEnableZ(fn.initEnableZ(newOptionInfo.y, gType));
          setOptionInfo(newOptionInfo);
        }

        if (
          isFirst ||
          JSON.stringify(prevProps.data) !== JSON.stringify(data)
        ) {
          setDataInfo(
            fn.createData(
              newOptionInfo.x,
              newOptionInfo.y,
              newOptionInfo.z,
              data,
            ),
          );
        }
      }
    }, [
      JSON.stringify(analysisGraphInfo),
      JSON.stringify(gType),
      JSON.stringify(data),
      JSON.stringify(order),
      JSON.stringify(graphList),
    ]);

    useEffect(() => {
      return () => {
        return null;
      };
    }, []);

    return Object.keys(data).length > 0 ? (
      <div css={sg.mainWrapper}>
        <div css={sg.settingWrapper}>
          <div css={sg.settingStyle}>
            <div>
              <span css={sg.spanStyle}>Graph Type:</span>
              <Select
                mode="multiple"
                maxTagCount="responsive"
                showArrow
                value={graphType}
                style={{ width: 200, fontSize: '12px' }}
                dropdownStyle={{ fontFamily: 'Saira', fontSize: '12px' }}
                onChange={changeType}
              >
                {gType.map((v) => (
                  <Option value={v.type.toLowerCase()} key={v.type}>
                    {v.type.toLowerCase()}
                  </Option>
                ))}
              </Select>
            </div>
            <div>
              <span css={sg.spanStyle}>Axis (X):</span>
              <Select
                value={optionInfo.x}
                style={{ width: 260, fontSize: '12px' }}
                dropdownStyle={{ fontFamily: 'Saira', fontSize: '12px' }}
                onChange={changeX}
              >
                {order.map((v) => (
                  <Option value={v} key={v}>
                    {v}
                  </Option>
                ))}
              </Select>
            </div>
            <div>
              <span css={sg.spanStyle}>Axis (Y):</span>
              <Select
                mode="multiple"
                maxTagCount="responsive"
                showArrow
                value={optionInfo.y}
                style={{ width: 380, fontSize: '12px' }}
                dropdownStyle={{ fontFamily: 'Saira', fontSize: '12px' }}
                onChange={changeY}
              >
                {graphList.map((v) => (
                  <Option value={v} key={v}>
                    {v}
                  </Option>
                ))}
              </Select>
              <Checkbox checked={optionAll} onChange={changeAll}>
                All
              </Checkbox>
            </div>
            <div>
              <span css={sg.spanStyle}>Axis (Z):</span>
              <Select
                value={optionInfo.z}
                style={{ width: 260, fontSize: '12px' }}
                dropdownStyle={{ fontFamily: 'Saira', fontSize: '12px' }}
                disabled={!enableZ}
                onChange={changeZ}
              >
                {graphList.map((v) => (
                  <Option value={v} key={v}>
                    {v}
                  </Option>
                ))}
              </Select>
            </div>
          </div>
        </div>
        <div css={sg.graphWrapper}>
          {graphType.length > 0 &&
          optionInfo.y.length > 0 &&
          optionInfo.x !== '' ? (
            <div css={sg.graphBodyStyle}>
              {optionInfo.y.map((v) => {
                return (
                  <div key={v}>
                    <SettingGraph
                      data={{
                        graphType: graphType,
                        x: dataInfo.x,
                        y: dataInfo.y[v] === undefined ? [] : dataInfo.y[v],
                        z: enableZ ? dataInfo.z : [],
                        currentFilter:
                          type === 'analysis' ? historyGraphFilter : undefined,
                      }}
                      title={v}
                      useRedux={type === 'analysis'}
                    />
                  </div>
                );
              })}
            </div>
          ) : (
            <div css={sg.emptyWrapper}>
              <Empty />
            </div>
          )}
        </div>
      </div>
    ) : (
      ''
    );
  },
  (prevProps, nextProps) =>
    JSON.stringify(prevProps) === JSON.stringify(nextProps),
);

Visualization.displayName = 'Visualization';
Visualization.propTypes = {
  gType: PropTypes.array.isRequired,
  data: PropTypes.object.isRequired,
  order: PropTypes.array.isRequired,
  graphList: PropTypes.array.isRequired,
  type: PropTypes.string.isRequired,
  savedData: PropTypes.array,
};

export default Visualization;
