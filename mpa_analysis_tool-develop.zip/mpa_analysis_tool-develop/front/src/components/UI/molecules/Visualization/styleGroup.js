import { css } from '@emotion/react';

export const mainWrapper = css`
  display: grid;
  grid-template-rows: auto;
  row-gap: 2rem;
  min-width: 1440px;
  background: white;
`;

export const settingWrapper = css`
  position: relative;
`;

export const settingStyle = css`
  display: flex;
  justify-content: space-between;
  font-family: saira;
  & > div:nth-of-type(3) > div {
    margin-right: 0.5rem;
  }
`;

export const spanStyle = css`
  margin-right: 0.5rem;
`;

export const graphWrapper = css`
  font-family: saira;
  width: 100%;
`;

export const graphBodyStyle = css`
  display: grid;
  position: relative;
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: auto;
  gap: 1rem;
`;

export const emptyWrapper = css`
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  & > div {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }
`;
