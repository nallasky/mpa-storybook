import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { Table, Select, Empty } from 'antd';
import { DatabaseOutlined } from '@ant-design/icons';
import useAnalysisInfo from '../../../../hooks/useAnalysisInfo';
import InputForm from '../../atoms/Input/InputForm';

const componentWrapper = css`
  width: 100%;
  & > div + div {
    margin-top: 1rem;
  }
`;
const titleStyle = css`
  font-weight: 500;
  font-size: 14px;
  margin-left: 1rem;
`;
const headerStyle = css`
  display: flex;
  justify-content: space-between;
`;
const titleWrapper = css`
  display: flex;
  align-items: center;
`;
const requireTag = css`
  color: red;
`;
const inlineSelectStyle = css`
  & > form {
    width: 390px;
    display: flex;
    justify-content: space-between;
    flex-wrap: nowrap;
    & > div:last-child {
      margin-right: 0;
    }
  }
`;

const FocusTable = React.memo(
  ({ titleIcon, titleText, tableProps, data, optionInfo }) => {
    const { disp_order, summary, detail } = data;
    const type = summary === undefined ? 'detail' : 'summary';
    const selectedData = summary === undefined ? detail : summary;
    const {
      columnInfo,
      dataSource,
      setDataSource,
      setColumnInfo,
      SummarySubItem,
      SummaryArgs,
      setSummaryArgs,
      setDetailOptions,
    } = useAnalysisInfo();
    const [optValue, setOptValue] = useState([]);

    useEffect(() => {
      const tempColumn = [];

      disp_order.map((item) => {
        const str = replaceString(item);

        tempColumn.push({
          title: item,
          dataIndex: str,
          key: str,
          ellipsis: true,
        });
      });

      setColumnInfo(type, tempColumn);
      setDataSource(type, createInitDataSource(selectedData));
    }, [data]);

    useEffect(() => {
      if (optionInfo !== undefined) {
        setOptValue(optionInfo.value);
      }
    }, [optionInfo]);

    const filteringData = (values) => {
      const exceptZero = values.filter((value) => value !== 0);

      if (
        !optValue.includes(0) &&
        (values.includes(0) ||
          exceptZero.length === optionInfo.option.length - 1)
      ) {
        setDataSource(type, createInitDataSource(selectedData));
        setOptValue(optionInfo.value);
        setDetailOptions(optionInfo.option.map((v) => v.label));
      } else {
        const labels = [],
          tempData = [],
          optionValue =
            optValue.includes(0) && !values.includes(0) ? [] : exceptZero;
        let index = 0;

        if (optionValue.length > 0) {
          optionValue.map((value) => {
            if (value !== 0) {
              const { label } = optionInfo.option.find(
                (item) => item.value === value,
              );

              if (label !== undefined) {
                labels.push(label);
              }
            }
          });

          const fKey =
            SummarySubItem.selected === 'period'
              ? 'period'
              : SummarySubItem.subItem.selected;
          Object.keys(selectedData).map((key) => {
            if (labels.includes(selectedData[key][fKey])) {
              tempData.push(createRowData(selectedData[key], index));
              index++;
            }
          });
        }
        setOptValue(optionValue);
        setDataSource(type, tempData);
        setDetailOptions(labels);
      }
    };

    const createRowData = (data, index) => {
      const rowData = { key: index };

      Object.keys(data).map((itemKey) => {
        rowData[replaceString(itemKey)] = data[itemKey];
      });

      return rowData;
    };

    const createInitDataSource = (data) => {
      const tempArray = [];

      Object.keys(data).map((itemsKey, i) => {
        tempArray.push(createRowData(data[itemsKey], i));
      });

      return tempArray;
    };

    const changeSubItem = (e) => {
      const copy = Object.assign({}, SummaryArgs, e);
      Object.keys(copy).includes(SummarySubItem.target) === false
        ? Object.assign(copy, {
            [SummarySubItem.target]: SummarySubItem.selected,
          })
        : '';
      setSummaryArgs(copy);
    };

    return (
      <div css={componentWrapper}>
        <div css={headerStyle}>
          <div css={titleWrapper}>
            {titleIcon}
            <span css={titleStyle}>{titleText}</span>
          </div>
          {summary === undefined ? (
            <div>
              <span>
                <span css={requireTag}>*</span> {optionInfo.title + ':'}
              </span>
              <Select
                mode="multiple"
                maxTagCount="responsive"
                style={{ marginLeft: '1rem', width: '300px' }}
                value={optValue}
                options={optionInfo.option}
                onChange={filteringData}
                placeholder="Select option"
              />
            </div>
          ) : SummarySubItem ? (
            <div css={inlineSelectStyle}>
              <InputForm.subItem
                formLabel={SummarySubItem.title}
                formName={SummarySubItem.target}
                options={SummarySubItem.options}
                subItem={SummarySubItem.subItem}
                defaultV={SummarySubItem.selected}
                formStyle={'inline'}
                changeFunc={changeSubItem}
              />
            </div>
          ) : (
            ''
          )}
        </div>
        <div>
          {detail === undefined || optValue.length > 0 ? (
            <Table
              {...tableProps}
              dataSource={dataSource(type)}
              columns={columnInfo(type)}
            />
          ) : (
            <Empty />
          )}
        </div>
      </div>
    );
  },
);

const replaceString = (s) => {
  return s.toLowerCase().replaceAll(/\./g, '').replaceAll(/\s/g, '_');
};

FocusTable.displayName = 'FocusTable';
FocusTable.propTypes = {
  titleIcon: PropTypes.node,
  titleText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  tableProps: PropTypes.object,
  data: PropTypes.object.isRequired,
  optionInfo: PropTypes.object,
};
FocusTable.defaultProps = {
  titleIcon: <DatabaseOutlined />,
  text: 'Title',
};

export default FocusTable;
