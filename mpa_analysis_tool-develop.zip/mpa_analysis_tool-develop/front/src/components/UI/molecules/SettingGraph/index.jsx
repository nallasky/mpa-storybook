export { default } from './SettingGraph';
