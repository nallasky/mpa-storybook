import useCommonJob from '../../../hooks/useBasicInfo';
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router';
import { arrayUnshift } from '../../../lib/util/Util';
import { css } from '@emotion/react';
import { EDIT, NEW, URL_RESOURCE_FUNC } from '../../../lib/api/Define/URL';
import { message, Modal, Popconfirm } from 'antd';
import {
  MSG_CANCEL,
  MSG_CONFIRM_CANCEL,
  MSG_CONFIRM_DELETE,
  MSG_LOCAL,
  MSG_REMOTE,
  MSG_SAVE_SETTING,
} from '../../../lib/api/Define/Message';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import {
  deleteRequest,
  updateCategoryList,
} from '../../../lib/api/axios/requests';
import { RESPONSE_OK } from '../../../lib/api/Define/etc';
import { NotificationBox } from '../../UI/molecules/NotificationBox';
import ImportExport from '../../UI/organisms/ImportExport';
import Button from '../../UI/atoms/Button';
import TitleBar from '../../UI/molecules/TitleBar';
import MainPageItem from '../../UI/molecules/MainPageItem';
import Divider from '../../UI/atoms/Divider';
import { PlusCircleOutlined } from '@ant-design/icons';
import { QUERY_KEY } from '../../../lib/api/Define/QueryKey';
import { useQueryClient } from 'react-query';
const MenuBarWrapper = css`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
`;
const MenuButton = css`
  font-weight: 400;
  margin-left: 8px;
`;

const itemWrapper = css`
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  grid-template-rows: auto;
  gap: 2rem;
  justify-items: center;
  margin: 2rem 0;
`;
const deleteModalWrapper = css`
  height: 50px;
  display: flex;
  justify-content: center;
  padding: 15px;
`;

const MainPage = () => {
  const {
    currentPath,
    setCurrentPath,
    MenuInfo,
    isEdit,
    setEditPage,
    categories,
  } = useCommonJob();
  const { body } = MenuInfo;
  const [category, updateCategory] = useState([]);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [visible, setVisible] = useState(false);
  const history = useHistory();
  const queryClient = useQueryClient();
  const jobSelect = (id) => {
    setCurrentPath(arrayUnshift(currentPath, id));
  };

  useEffect(() => {
    if (body !== undefined) {
      updateCategory(categories);
      console.log('[init - updateCategory]:', categories);
    }
  }, []);
  const addCategory = () => {
    updateCategory((category) => [
      ...category,
      {
        idx: category.length,
        id: null,
        value: '',
      },
    ]);
  };

  const deleteCategory = (idx) => {
    updateCategory(
      category
        .filter((v) => v.idx !== idx)
        .map((obj, index) => {
          return { ...obj, idx: index };
        }),
    );
  };

  const changeCategory = (index, value) => {
    if (value !== undefined) {
      const tempCategory = category.map((item, i) => {
        return index === i
          ? { idx: item.idx, id: item.id, value: value }
          : item;
      });
      updateCategory(tempCategory);
      console.log('[updateCategory]:', tempCategory);
    }
  };

  const ClickEventByItem = (mode, id) => {
    switch (mode.key) {
      case 'EDIT':
        history.push({ pathname: `${EDIT}/${id}` });
        break;
      case 'DELETE':
        Modal.confirm({
          title: MSG_CONFIRM_DELETE,
          content: (
            <div css={deleteModalWrapper}>
              <FontAwesomeIcon icon={faTrashAlt} size="2x" />
            </div>
          ),
          okButtonProps: { loading: confirmLoading },
          onOk() {
            const deleteItem = async (item) => {
              const { status, info } = await deleteRequest(
                URL_RESOURCE_FUNC,
                item,
              );
              if (status.toString() === RESPONSE_OK) {
                setConfirmLoading(false);
                queryClient.invalidateQueries([QUERY_KEY.MAIN_INIT]);
              } else {
                message.error(info);
              }
            };
            deleteItem(id).then('================================');
          },
        });
        break;
      default:
        break;
    }
  };
  const saveSetting = () => {
    const reqInfos = async (categories) => {
      try {
        const { menu, status } = await updateCategoryList(categories);
        console.log('[saveSetting]:', menu);
        if (status === 'OK') {
          queryClient.invalidateQueries([QUERY_KEY.MAIN_INIT]);
          setEditPage(false);
        }
      } catch (e) {
        if (e.reponse) {
          const { data } = e.reponse;
          NotificationBox(data.status, data.msg);
        }
      }
    };
    if (isEdit === true) {
      const afterCategory = category.filter((item) => item.value !== '');
      if (JSON.stringify(categories) !== JSON.stringify(afterCategory)) {
        let list = [];
        afterCategory.map((item) =>
          list.push({ category_id: item.id, title: item.value }),
        );
        reqInfos({ ['category']: list }).then();
      } else {
        setEditPage(false);
      }
    }
  };

  return (
    <>
      <div css={MenuBarWrapper}>
        {isEdit === false ? (
          <>
            <ImportExport isOpen={visible} closeable={setVisible} />
            <Button
              theme={'white'}
              style={MenuButton}
              onClick={() => setVisible(true)}
            >
              {'Import/export'}
            </Button>
            <Button
              theme={'blue'}
              style={MenuButton}
              onClick={() => setEditPage(true)}
            >
              {'Add/Edit'}
            </Button>
          </>
        ) : (
          <>
            <Popconfirm
              title={MSG_CONFIRM_CANCEL}
              onConfirm={() => setEditPage(false)}
            >
              <Button theme={'white'} style={MenuButton}>
                {MSG_CANCEL}
              </Button>
            </Popconfirm>
            <Button theme={'blue'} style={MenuButton} onClick={saveSetting}>
              {MSG_SAVE_SETTING}
            </Button>
          </>
        )}
      </div>
      <div>
        {category.map((item, i) => {
          const menu = body[i];
          return menu !== undefined ? (
            <div key={`category_${i}`}>
              <div>
                <TitleBar
                  text={menu.title}
                  isEditMode={isEdit}
                  changeFunc={(value) => changeCategory(i, value)}
                  deleteFunc={() => deleteCategory(i)}
                />
                {isEdit === true ? (
                  <div css={itemWrapper}>
                    {menu.subfunc.map((submenu, idx) => {
                      const tableStr =
                        submenu.info?.Source === MSG_LOCAL
                          ? `LogName: ${submenu.info?.['Log Name']}`
                          : submenu.info?.Source === MSG_REMOTE
                          ? `Table: ${submenu.info?.['Table']}`
                          : '';
                      return (
                        <MainPageItem
                          isEditMode={true}
                          key={`subfunc_${idx}`}
                          mainText={submenu.title}
                          subText={
                            <div
                              title={`Source: ${submenu.info?.Source}\n${tableStr}`}
                            >
                              <div
                                css={{
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  fontSize: '18px',
                                  cursor: 'default',
                                }}
                              >
                                Source: {submenu.info?.Source}
                              </div>
                              <div
                                css={{
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  fontSize: '16px',
                                  cursor: 'default',
                                }}
                              >
                                {tableStr === '' ? '\u00A0' : tableStr}
                              </div>
                            </div>
                          }
                          buttonText={submenu.btn_msg}
                          onClick={(e) => ClickEventByItem(e, submenu.func_id)}
                        />
                      );
                    })}
                    <MainPageItem
                      isEditMode={true}
                      key={`subfunc_new`}
                      mainText={null}
                      onClick={() =>
                        history.push({ pathname: `${NEW}/${menu.category_id}` })
                      }
                    />
                  </div>
                ) : (
                  <div css={itemWrapper}>
                    {menu.subfunc.map((submenu, idx) => {
                      const tableStr =
                        submenu.info?.Source === MSG_LOCAL
                          ? `LogName: ${submenu.info?.['Log Name']}`
                          : submenu.info?.Source === MSG_REMOTE
                          ? `Table: ${submenu.info?.['Table']}`
                          : '';
                      return (
                        <MainPageItem
                          isEditMode={false}
                          key={idx}
                          mainText={submenu.title}
                          subText={
                            <div
                              title={`Source: ${submenu.info?.Source}\n${tableStr}`}
                            >
                              <div
                                css={{
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  fontSize: '18px',
                                  cursor: 'default',
                                }}
                              >
                                Source: {submenu.info?.Source}
                              </div>
                              <div
                                css={{
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  fontSize: '16px',
                                  cursor: 'default',
                                }}
                              >
                                {tableStr === '' ? '\u00A0' : tableStr}
                              </div>
                            </div>
                          }
                          buttonText={submenu.btn_msg}
                          onClick={() => jobSelect(submenu.func_id)}
                        />
                      );
                    })}
                  </div>
                )}
              </div>
              <Divider />
            </div>
          ) : (
            <div key={`category_${i}`}>
              <TitleBar
                style={{ marginTop: '3rem', marginBottom: '2rem' }}
                text={category.value}
                isEditMode={isEdit}
                changeFunc={(value) => changeCategory(i, value)}
                deleteFunc={() => deleteCategory(i)}
              />
              <Divider />
            </div>
          );
        })}
        {isEdit === true ? (
          <Button
            iconOnly
            size="md"
            theme={'white'}
            onClick={addCategory}
            style={{ marginTop: '1rem' }}
          >
            <PlusCircleOutlined />
          </Button>
        ) : (
          <></>
        )}
      </div>
    </>
  );
};

export default MainPage;
