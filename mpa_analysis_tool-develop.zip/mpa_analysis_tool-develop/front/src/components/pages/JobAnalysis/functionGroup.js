import { notification } from 'antd';
import { jsonToCSV } from '../../../lib/util/plotly-test';
import Plotly from 'plotly.js';

export const getTableData = (row, column) => {
  const jsonArr = [];
  Object.keys(row).map((v) => {
    const tmpObj = {};
    column.map((i) => {
      Object.assign(tmpObj, { [i]: row[v][i] });
    });
    jsonArr.push(tmpObj);
  });
  return jsonToCSV(jsonArr);
};

export const createGraphImage = async (info) => {
  const imgArr = [];
  const components = document.querySelectorAll('div[class^="js-plotly-plot"]');

  for (let i = 0; i < components.length; i++) {
    const data = components[i];
    const title = components[i].querySelector('text[class^="gtitle"]')
      .innerHTML;
    const nameHeader =
      info.findIndex((v) => v === title) !== -1 ? 'analysis' : 'data';

    await Plotly.toImage(data, {
      format: 'png',
      filename: `graph_${title}`,
    }).then((url) => {
      imgArr.push({
        url: url,
        filename: `${nameHeader}.${title}.png`,
      });
    });
  }

  return imgArr;
};

export const createVisualizationItems = (data, filter) => {
  const tmpArr = [];
  data.map((v) => {
    const findFilter = filter.find((i) => i.title === v.title);
    const tmpObj = {
      title: v.title,
      type: v.type,
      x_axis: v.x_axis,
      y_axis: v.y_axis,
      z_axis: v.z_axis,
      x_range_min: findFilter.x_range_min,
      x_range_max: findFilter.x_range_max,
      y_range_min: findFilter.y_range_min,
      y_range_max: findFilter.y_range_max,
      z_range_min: findFilter.z_range_min,
      z_range_max: findFilter.z_range_max,
    };
    tmpArr.push(tmpObj);
  });
  return tmpArr;
};

export const displayNotification = (args) => {
  notification.open(args);
};
