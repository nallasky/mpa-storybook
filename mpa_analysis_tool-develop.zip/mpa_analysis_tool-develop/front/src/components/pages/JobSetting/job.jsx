import React, { useState } from 'react';
import { JobSetting } from '../../UI/organisms';
import ProgressModal from '../../UI/organisms/ProgressModal';
import { useHistory, useLocation } from 'react-router';
import {
  reqPostFocusJob,
  getRequest,
  getEquipmentValidDate, getEquipmentList,
} from '../../../lib/api/axios/requests';
import useJobSettingInfo from '../../../hooks/useJobSettingInfo';
import {
  arrayRemove,
  arrayShift,
  arrayUnshift,
  getParseData,
} from '../../../lib/util/Util';
import {
  ANALYSIS,
  MAIN,
  PROCESS,
  URL_ANALYSIS_HISTORY,
} from '../../../lib/api/Define/URL';
import { RESPONSE_OK } from '../../../lib/api/Define/etc';
import NotificationBox from '../../UI/molecules/NotificationBox/Notification';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { QUERY_KEY } from '../../../lib/api/Define/QueryKey';
import {
  convert_JobSetting,
  deleteConvertJob,
  getConvertJobStatus, getRequestId_remoteJobSetting,
  getResource_JobSetting,
  uploadFiles_JobSetting,
} from '../../../lib/api/axios/useJobSettingRequest';
import dayjs from "dayjs";

const Job = () => {
  const [isProcessJob, setProcessJob] = useState(false);
  const history = useHistory();
  const location = useLocation();
  const queryClient = useQueryClient();
  const {
    isOpenCreateJob,
    closeCreateJob,
    openCreateJob,
    setJobSettingResource,
    jobSettingInfo,
    setJobSettingInfo,
    currentPath,
    setCurrentPath,
    urlList,
    jobResource,
  } = useJobSettingInfo();

  const jobSettingResource = useQuery(
    [QUERY_KEY.JOBSETTING_INIT, currentPath[0]],
    () => getResource_JobSetting({ func_id: currentPath[0] }),
    {
      enabled: !!(
        urlList?.map((obj) => obj.func).includes(currentPath[0]) ?? false
      ),
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: ({ info }) => {
        openCreateJob();
        setJobSettingResource(info, currentPath[0]);
      },
    },
  );
  useQuery(
    [
      QUERY_KEY.JOBSETTING_USER_FAB_EQUIPMENT_LIST,
      jobSettingInfo?.db_id,
      jobSettingInfo?.table_name,
    ],
    () =>
      getEquipmentList({
        db_id: jobSettingInfo?.db_id,
        table_name: jobSettingInfo?.table_name,
      }),
    {
      enabled: !!jobSettingInfo?.db_id && !!jobSettingInfo?.table_name,
      onSuccess: ({ info }) => {
        setJobSettingInfo({ ...jobSettingInfo, info: info });
      },
    },
  );

  useQuery(
    [
      QUERY_KEY.JOBSETTING_EQUIPMENT_VALID_DATE,
      jobSettingInfo?.db_id,
      jobSettingInfo?.table_name,
    ],
    () =>
      getEquipmentValidDate({
        db_id: jobSettingInfo?.db_id,
        table_name: jobSettingInfo?.table_name,
        equipment_name: jobSettingInfo?.equipment_name,
      }),
    {
      enabled:
        !!jobSettingInfo?.db_id &&
        !!jobSettingInfo?.table_name &&
        !!jobSettingInfo?.equipment_name,
      onSuccess: ({ info }) => {
        setJobSettingInfo({
          ...jobSettingInfo,
          period: {
            ['start']: dayjs(info.start).format('YYYY-MM-DD'),
            ['end']: dayjs(info.end).format('YYYY-MM-DD'),
          },
        });
      },
    },
  );

  const convertJobStatus = useQuery(
    [QUERY_KEY.JOBSETTING_CONVERT_JOB_STATUS, jobSettingInfo?.job_id],
    () => getConvertJobStatus({ jobId: jobSettingInfo?.job_id }),
    {
      enabled: !!(jobSettingInfo?.job_id ?? false),
      refetchInterval: 1000,
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
    },
  );

  const localJobConvert = useMutation(
    [QUERY_KEY.JOBSETTING_LOCAL_JOB],
    ({ upload_id }) =>
      convert_JobSetting({ object: jobSettingInfo, files: upload_id }),
    {
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: ({ jobId }) => {
        console.log('[jobConvert]JobId', jobId);
        setJobSettingInfo({ ...jobSettingInfo, job_id: jobId });
      },
    },
  );
  const jobFileUpload = useMutation(
    [QUERY_KEY.JOBSETTING_FILE_UPLOAD],
    (src_file) => uploadFiles_JobSetting(src_file),
    {
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: ({ upload_id }) => {
        console.log('[getResource_JobSetting]upload_id', upload_id);
        localJobConvert.mutate({ upload_id: upload_id });
      },
    },
  );

  useQuery(
    [QUERY_KEY.JOBSETTING_REMOTE_JOB],
    () => getRequestId_remoteJobSetting({func_id:jobSettingInfo.func_id}),
    {
      enabled: false,
      onError: (error) => {
        NotificationBox('ERROR', error.message, 4.5);
      },
      onSuccess: ({ JobId }) => {
        console.log('[jobConvert]JobId', JobId);
        setJobSettingInfo({ ...jobSettingInfo, job_id: JobId });
        closeCreateJob();
      },
    },
  );
  const deleteJob = useMutation(
    [QUERY_KEY.JOBSETTING_CONVERT_NG],
    ({ jobId }) => deleteConvertJob({ jobId: jobId }),
    {
      onSuccess: () => {
        setCurrentPath(arrayRemove(currentPath, location.pathname));
        setJobSettingInfo(undefined);
        setProcessJob(false);
      },
    },
  );
  const goAnalysisPage = (jobPath) => {
    if (jobPath.func !== '') {
      const newPath = currentPath.slice(currentPath.indexOf(MAIN)); //
      newPath.unshift(jobPath.func); //
      newPath.unshift(ANALYSIS); //
      setCurrentPath(newPath);
    }
  };

  const startAnalysis = async () => {
    console.log('jobSettingInfo', jobSettingInfo);
    const { src_file } = jobSettingInfo;
    const { formList } = jobResource;

    if ((jobSettingInfo?.source || 'local') === 'local') {
      closeJobModal(PROCESS);
      setProcessJob(true);
      jobFileUpload.mutate(src_file);
    } else {
      closeCreateJob();
      const job = currentPath.find((obj) =>
        urlList.find((obj2) => obj2.func === obj),
      );
      if (jobSettingInfo.source === 'remote') {

        try {
          await reqPostFocusJob(jobSettingInfo, 0).then((res) => {
            const jobPath =
              job !== undefined
                ? urlList.find((obj2) => obj2.func === job)
                : { func: '', path: [] };
            console.log('[startAnalysis]jobPath', jobPath);
            const jobTypeInfo = formList.find(
              (obj) => obj.key === jobSettingInfo.source,
            );
            goAnalysisPage(jobPath);
            if (res.jobId !== 0) {
              history.push({
                pathname: ANALYSIS,
                state: {
                  history_id: jobTypeInfo?.history_id ?? undefined,
                  equipment_name: `${jobSettingInfo.equipment_name}`,
                  job_type: `${jobTypeInfo.type}`,
                  func_id: `${jobSettingInfo.func_id}`,
                  job_id: `${res.jobId}`,
                  path: jobPath?.path ?? [],
                },
              });
            }
          });
        } catch (e) {
          if (e.response) {
            const {
              data: { msg },
            } = e.response;
            console.log(e.response);
            NotificationBox('ERROR', msg, 4.5);
          }
        }
      } else {
        const request = async () => {
          const jobTypeInfo = formList.find(
            (obj) => obj.key === jobSettingInfo.source,
          );
          const { status, info } = await getRequest(
            `${URL_ANALYSIS_HISTORY}/${jobSettingInfo.func_id}/${jobTypeInfo?.history_id}`,
          );
          if (status.toString() === RESPONSE_OK) {
            history.push({
              pathname: ANALYSIS,
              state: {
                job_id: `${info.rid}`,
                history_id: `${jobTypeInfo?.history_id}`,
                job_type: `${jobTypeInfo.type}`,
                func_id: `${jobSettingInfo.func_id}`,
              },
            });
          }
        };
        await request();
      }
    }
  };

  const closeJobModal = (next) => {
    closeCreateJob();
    Array.isArray(next)
      ? setCurrentPath(next)
      : next === 0
      ? setCurrentPath(arrayShift(currentPath))
      : setCurrentPath(arrayUnshift(currentPath, next));
  };

  const endProcessModal = async (status) => {
    const job = currentPath.find((obj) =>
      urlList.find((obj2) => obj2.func === obj),
    );
    const jobPath =
      job !== undefined
        ? urlList.find((obj2) => obj2.func === job)
        : { func: '', path: [] };
    console.log('[endProcessModal]jobPath', jobPath);
    if (jobPath.func !== undefined) {
      const newPath = currentPath.slice(currentPath.indexOf(MAIN));
      newPath.unshift(jobPath.func);
      newPath.unshift(ANALYSIS);
      setCurrentPath(newPath);
    }
    if (status === 'COMPLETE') {
      setProcessJob(false);
      history.push({
        pathname: ANALYSIS,
        state: {
          job_type: `${jobSettingInfo?.type ?? 'local'}`,
          func_id: `${jobSettingInfo.func_id}`,
          job_id: `${jobSettingInfo.job_id}`,
          path: jobPath?.path ?? [],
        },
      });
      setJobSettingInfo(undefined);
    } else if (status === 'ERROR') {
      setCurrentPath(arrayRemove(currentPath, location.pathname));
      setJobSettingInfo(undefined);
    } else {
      //PROCESS
      deleteJob.mutate({ jobId: jobSettingInfo.job_id });
    }
  };

  const contentChange = async (event) => {
    const item = getParseData(event);
    setJobSettingInfo((prevState) => ({
      ...prevState,
      [item.id]: item.value,
    }));
    /* if (item.id === 'equipment_name') {
      try {
        const { date } = await updateDate(jobSettingInfo.log_name, item.value);
        setValidPeriod(date);
        setJobSettingInfo((prevState) => ({
          ...prevState,
          [item.id]: item.value,
          ['period']: `${date.start}~${date.end}`,
        }));
      } catch (e) {
        initValidPeriod();
      }
    } else {
      setJobSettingInfo((prevState) => ({
        ...prevState,
        [item.id]: item.value,
      }));
    }*/
  };

  const checkAnalysisStatus = async (
    setStatusFunc,
    setPercentFunc,
    contentsFunc,
  ) => {
    const { status, percent, detail } = convertJobStatus.data;
    console.log('convertJobStatus', convertJobStatus);
    if (status === 'success') {
      queryClient.removeQueries([
        QUERY_KEY.JOBSETTING_CONVERT_JOB_STATUS,
        jobSettingInfo?.job_id,
      ]);
    }
    setStatusFunc(status);
    setPercentFunc(percent);
    contentsFunc(detail);
  };

  if (jobSettingResource.isLoading) return <></>;
  console.log('jobSettingInfo', jobSettingInfo);
  return (
    <>
      {' '}
      <JobSetting
        isOpen={isOpenCreateJob}
        startFunc={startAnalysis}
        closeFunc={closeJobModal}
        changeFunc={contentChange}
        resource={jobResource}
        info={jobSettingInfo}
      />
      <ProgressModal
        isOpen={isProcessJob}
        closeFunc={endProcessModal}
        statusFunc={checkAnalysisStatus}
      />
    </>
  );
};

export default Job;
