import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Plotly from 'plotly.js-dist';
import { Empty, Button, Popconfirm } from 'antd';
import { css } from '@emotion/react';
import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import * as sg from '../../UI/molecules/Visualization/styleGroup';
import { SettingFilled, CloseCircleFilled } from '@ant-design/icons';
import GraphAddEdit from '../../UI/organisms/GraphAddEdit/GraphAddEdit';

const graphWrapper = css`
  position: relative;
  &:hover > div:first-of-type {
    opacity: 1;
  }
  & > div {
    &:first-of-type {
      position: absolute;
      opacity: 0;
      transition: all 0.3s;
      z-index: 1;
      & > button + button {
        margin-left: 1rem;
      }
    }
    &:last-of-type {
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
`;

const ContentsForm = () => {};

const PreviewForm = () => {
  const { visualStepInfo, updateVisualInfo, ruleStepConfig } = useRuleSettingInfo();
  const [isOpen, setIsOpen] = useState(false);
  const [currentIdx, setCurrentIdx] = useState('');

  const openEdit = (idx) => {
    setCurrentIdx(idx);
    setIsOpen(true);
  };

  const onDelete = (idx) => {
    updateVisualInfo({
      ...visualStepInfo,
      items: visualStepInfo.items.filter((v, i) => {
        return i !== idx;
      }),
    });
  };

  useEffect(() => {
    console.log('[useEffect]visualStepInfo', visualStepInfo);
    const currentRows = ruleStepConfig.find((v) => v.step === 4).data.row;
    visualStepInfo.items.some((v, i) => {
      const currentInfo = visualStepInfo.graph_list.find(
        (z) => z.name === v.type[0],
      );
      const currentScript = visualStepInfo.function_graph_type.find((x) => {
        return currentInfo.type === 'user'
          ? x.name === currentInfo.name
          : x.type === currentInfo.type;
      }).script;
      const newFunc = new Function('return ' + currentScript)();
      const tmpObj = {};

      if (v.y_axis.length > 0) {
        v.y_axis.reduce((acc, v) => {
          acc[v] = Object.values(currentRows).map((z) => z[v]);
          return acc;
        }, tmpObj);
      }

      const params = {
        type: v.type,
        x:
          v.x_axis.length === 0
            ? []
            : Object.values(currentRows).map((z) => z[v.x_axis]),
        y: tmpObj,
        z:
          v.z_axis.length === 0
            ? []
            : Object.values(currentRows).map((z) => z[v.z_axis]),
        title: v.title,
        range: {
          x: v.x_range_min !== '' ? [v.x_range_min, v.x_range_max] : [],
          y: v.y_range_min !== '' ? [v.y_range_min, v.y_range_max] : [],
          z: v.z_range_min !== '' ? [v.z_range_min, v.z_range_max] : [],
        },
      };
      newFunc(Plotly, document.getElementById(`graph_${i}`), params);
    });
  }, [visualStepInfo]);

  return (
    <>
      <div css={sg.graphWrapper}>
        <div
          css={
            visualStepInfo.items.length > 0
              ? sg.graphBodyStyle
              : sg.emptyWrapper
          }
        >
          {visualStepInfo.items.length > 0 ? (
            visualStepInfo.items.map((k, i) => {
              return (
                <div key={i} css={graphWrapper}>
                  <div>
                    <Button
                      type="dashed"
                      shape="round"
                      icon={<SettingFilled />}
                      onClick={() => openEdit(i)}
                    >
                      Edit
                    </Button>
                    <Popconfirm
                      title="Are you sure you want to delete this graph?"
                      onConfirm={() => onDelete(i)}
                    >
                      <Button
                        type="dashed"
                        shape="round"
                        icon={<CloseCircleFilled />}
                      >
                        Delete
                      </Button>
                    </Popconfirm>
                  </div>
                  <div id={`graph_${i}`} />
                </div>
              );
            })
          ) : (
            <Empty description="No graphs to display." />
          )}
        </div>
      </div>
      <GraphAddEdit
        closer={() => setIsOpen(false)}
        isOpen={isOpen}
        mode="edit"
        index={currentIdx}
      />
    </>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const Step6_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step6_Setting.propTypes = {
  children: PropTypes.node,
};
Step6_Setting.contents = ContentsForm;
Step6_Setting.preview = PreviewForm;

export default Step6_Setting;
