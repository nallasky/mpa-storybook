import React from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { Table } from 'antd';
import { MSG_REMOTE, MSG_SQL } from '../../../lib/api/Define/Message';
import { E_STEP_LOG_SELECT } from '../../../lib/api/Define/etc';
const tableWrapper = css`
  display: contents;
`;

const NextButtonEvent = () => {};
const PreviewButtonEvent = () => {};
const PreviousButtonEvent = (funcStepInfo) => {
  return funcStepInfo.source_type === MSG_REMOTE ||
    funcStepInfo.source_type === MSG_SQL
    ? { step: E_STEP_LOG_SELECT, status: 'pass' }
    : { step: 0, status: 'false' };
};
const EnableCheck = (analysisStepInfo) => {
  if ((analysisStepInfo?.type ?? 'setting') === 'none') {
    return true;
  } else if ((analysisStepInfo?.type ?? 'setting') === 'script') {
    return Boolean(analysisStepInfo?.script?.file_name ?? false);
  } else {
    return (
      (analysisStepInfo?.items?.length > 0 &&
        ((analysisStepInfo?.aggregation_default?.type !== undefined &&
          analysisStepInfo?.aggregation_default?.type !== '' &&
          analysisStepInfo?.aggregation_default?.val !== '') ||
          analysisStepInfo?.aggregation_default?.type === 'all')) ??
      false
    );
  }
};

const ContentsForm = () => {};

const PreviewForm = ({ data }) => {
  if (data == null) return <></>;

  const { analysis_header, analysis_data, analysis_error } = data;

  if (
    analysis_header === undefined &&
    analysis_data === undefined &&
    analysis_error === undefined
  )
    return <></>;

  return (
    <div css={tableWrapper}>
      {analysis_error !== undefined ? (
        <>{analysis_error}</>
      ) : (
        <Table
          bordered
          pagination={false}
          columns={analysis_header}
          dataSource={analysis_data}
          size="middle"
          rowKey="key"
          scroll={{ x: 'max-content' }}
        />
      )}
    </div>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const Step5_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step5_Setting.propTypes = {
  children: PropTypes.node,
};

Step5_Setting.btn_next = NextButtonEvent;
Step5_Setting.btn_previous = PreviousButtonEvent;
Step5_Setting.btn_preview = PreviewButtonEvent;
Step5_Setting.check_next = EnableCheck;
Step5_Setting.check_preview = EnableCheck;
Step5_Setting.view_contents = ContentsForm;
Step5_Setting.view_preview = PreviewForm;

export default Step5_Setting;
