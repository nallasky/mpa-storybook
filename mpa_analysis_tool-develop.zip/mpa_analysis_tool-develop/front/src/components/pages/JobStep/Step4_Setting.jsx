import React from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { Table } from 'antd';
const tableWrapper = css`
  display: contents;
`;
const ContentsForm = () => {};

const PreviewForm = ({ data }) => {
  if (data == null) return <></>;

  const { filter_header, filter_data, filter_error } = data;

  if (
    filter_header === undefined &&
    filter_data === undefined &&
    filter_error === undefined
  )
    return <></>;

  return (
    <div css={tableWrapper}>
      {filter_error !== undefined ? (
        <>{filter_error}</>
      ) : (
        <Table
          bordered
          pagination={false}
          columns={filter_header}
          dataSource={filter_data}
          size="middle"
          rowKey="key"
          scroll={{ x: 'max-content' }}
        />
      )}
    </div>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const Step4_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step4_Setting.propTypes = {
  children: PropTypes.node,
};
Step4_Setting.view_contents = ContentsForm;
Step4_Setting.view_preview = PreviewForm;

export default Step4_Setting;
