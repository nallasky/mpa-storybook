import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import { css } from '@emotion/react';
import {
  MSG_ADD_NEW,
  MSG_DISABLE,
  MSG_LOCAL,
} from '../../../lib/api/Define/Message';
import { useParams } from 'react-router';
import { E_STEP_2 } from '../../../lib/api/Define/etc';
import {getFileName, getFindData, getParseData} from '../../../lib/util/Util';
import { Table } from 'antd';
import { NotificationBox } from '../../UI/molecules/NotificationBox';
import { FormCard } from '../../UI/atoms/Modal';
import { StepInputForm } from '../../UI/organisms/StepInputForm';
import { E_JOBSTEP } from '../../../lib/api/Define/JobStepEnum';
import { useMutation, useQuery } from 'react-query';
import { QUERY_KEY } from '../../../lib/api/Define/QueryKey';
import {
  deleteRuleName,
  getStep2ResourceUpdate,
  getTableList,
} from '../../../lib/api/axios/useJobStepRequest';
import dayjs from 'dayjs';
import {
  getEquipmentValidDate,
  getEquipmentList,
} from '../../../lib/api/axios/requests';
const tableWrapper = css`
  display: contents;
`;
const titlestyle = css`
  font-weight: 400;
`;

const nextClick = () => {
  return true;
};

const previewCheck = (data, isEditMode) => {
  const { convertStepInfo } = useRuleSettingInfo();
  return Boolean(
    isEditMode
      ? convertStepInfo?.log_define?.log_name && (data?.rule_name ?? false)
      : data.log_name ?? false,
  );
};
const remote_info_initial = {
  ['db_id']: undefined,
  ['table_name']: undefined,
  ['equipment_name']: undefined,
  ['period_start']: undefined,
  ['period_end']: undefined,
};
/*============================================================================
==                         STEP 2 CONTENTS                                  ==
============================================================================*/
const STEP2_MSG_ADD = 'add';
const STEP2_MSG_NEW = 'new';
const STEP2_MSG_LOG_SELECT = 'empty';
const INPUT_TYPE_CSV = 'csv';

const ContentsForm = ({ data, onChange }) => {
  const {
    ruleStepConfig,
    updateConvertInfo,
    updateFuncInfo,
    funcStepInfo,
    convertStepInfo,
    setRuleStepConfig,
  } = useRuleSettingInfo();
  const { func_id } = useParams();
  const [config, setConfig] = useState(null);
  const [newRule, setNewRule] = useState(false);
  const [deleteRule, setDeleteRule] = useState(undefined);

  /*
   *  1. DB_ID가 설정되면 요청 된다. (DB_ID가 변경되어도 요청)
   *  2. Edit 로 들어온 경우에는 TableName의 요청은 필요없다.
   * */
  useQuery(
    [QUERY_KEY.STEP2_DB_TABLE_LIST, funcStepInfo?.info?.db_id],
    () => getTableList({ db_id: funcStepInfo?.info?.db_id }),
    {
      enabled: !!funcStepInfo?.info?.db_id && func_id === undefined,
      onSuccess: ({ info }) => {
        onChange({ table_name: info });
        console.log('[getDBDetailQuery]info', info);
      },
    },
  );

  /*
   *  1. DB_ID & Table Name이 하나라도 변경 되면, 요청을 한다.
   *  2. Edit 로 들어온 경우에도 user/Fab/Equipment가 필요하다.
   * */

  useQuery(
    [
      QUERY_KEY.STEP2_USER_FAB_EQUIPMENT_LIST,
      funcStepInfo?.info?.db_id,
      funcStepInfo?.info?.table_name,
    ],
    () =>
      getEquipmentList({
        db_id: funcStepInfo?.info?.db_id,
        table_name: funcStepInfo?.info?.table_name,
      }),
    {
      enabled: !!funcStepInfo?.info?.db_id && !!funcStepInfo?.info?.table_name,
      onSuccess: ({ info }) => {
        onChange(info);
        console.log('[getDBDetailQuery]info', info);
      },
    },
  );

  /*
   *  1. DB_ID /TABLE_NAME/EQUIPMENT_NAME 이 설정 되면 Equipment의 유효한 정보를 가져온다.
   * */

  useQuery(
    [
      QUERY_KEY.STEP2_EQUIPMENT_VALID_DATE,
      funcStepInfo?.info?.db_id,
      funcStepInfo?.info?.table_name,
      funcStepInfo?.info?.equipment_name,
    ],
    () =>
      getEquipmentValidDate({
        db_id: funcStepInfo?.info?.db_id,
        table_name: funcStepInfo?.info?.table_name,
        equipment_name: funcStepInfo?.info?.equipment_name,
      }),
    {
      enabled:
        !!funcStepInfo?.info?.db_id &&
        !!funcStepInfo?.info?.table_name &&
        !!funcStepInfo?.info?.equipment_name,
      onSuccess: ({ info }) => {
        updateFuncInfo({
          ...funcStepInfo,
          info: {
            ...funcStepInfo.info,
            ['period_start']: dayjs(info.start).format('YYYY-MM-DD'),
            ['period_end']: dayjs(info.end).format('YYYY-MM-DD'),
          },
        });
      },
    },
  );

  useQuery(
    [QUERY_KEY.STEP2_RESOURCE_UPDATE, func_id, deleteRule],
    () => getStep2ResourceUpdate({ func_id: func_id }),
    {
      enabled: !!func_id && !!deleteRule,
      onSuccess: ({ info }) => {
        setDeleteRule(undefined);
        console.log('info', info);
        storeStepConfig(info);
      },
    },
  );

  //============================================================================
  const storeStepConfig = (info) => {
    const cloneStep = ruleStepConfig.slice();
    const existIdx = ruleStepConfig.findIndex((obj) => obj.step === E_STEP_2);
    if (existIdx !== -1) {
      cloneStep.splice(existIdx, 1, {
        ...ruleStepConfig[existIdx],
        config: info,
      });
      setRuleStepConfig(cloneStep);
    }
  };
  const deleteMuation = useMutation(
    [QUERY_KEY.MGMT_DB_DELETE],
    (rule_id) => deleteRuleName({ rule_id: rule_id }),
    {
      onError: (error) => {
        NotificationBox(error.statusText, error.message);
        setDeleteRule(undefined);
      },
      onSuccess: ({ info, rule_id }) => {
        setDeleteRule(rule_id);
        updateConvertInfo({
          ...convertStepInfo,
          rule_list: info?.options ?? [],
          log_define: {
            ...convertStepInfo.log_define,
            rule_id:
              convertStepInfo.log_define.rule_id === rule_id
                ? null
                : convertStepInfo.log_define.rule_id,
            rule_name:
              convertStepInfo.log_define.rule_id === rule_id
                ? ''
                : convertStepInfo.log_define.rule_name,
          },
        });
      },
    },
  );
  const LocalConfigChange = (event) => {
    const item = getParseData(event);
    switch (item.id) {
      case E_JOBSTEP.STEP2_RULE_NAME:
        onChange({
          new_rule: item.value.rule_name === MSG_ADD_NEW,
          [E_JOBSTEP.STEP2_RULE_NAME]: item.value.rule_name,
        });
        updateConvertInfo({
          ...convertStepInfo,
          mode: item.value.rule_name === MSG_ADD_NEW ? STEP2_MSG_ADD : 'edit',
          log_define: {
            ...convertStepInfo.log_define,
            rule_id:
              item.value.rule_name === MSG_ADD_NEW ? null : item.value.id,
            rule_name:
              item.value.rule_name === MSG_ADD_NEW ? '' : item.value.rule_name,
          },
        });
        break;
      case E_JOBSTEP.STEP2_LOG_NAME:
        if (item.value === MSG_ADD_NEW) {
          onChange({
            new_rule: func_id ? true : MSG_DISABLE,
            [item.id]: item.value,
          });
          updateConvertInfo({
            ...convertStepInfo,
            mode: STEP2_MSG_NEW,
            log_define: {
              ...convertStepInfo.log_define,
              log_name: '',
              table_name: '',
              rule_id: 'null',
              rule_name: '',
              input_type: INPUT_TYPE_CSV,
            },
          });
        } else if (data?.new_rule === MSG_DISABLE) {
          onChange({ new_rule: newRule, [item.id]: item.value });
          updateConvertInfo({
            ...convertStepInfo,
            mode: newRule === true ? STEP2_MSG_ADD : STEP2_MSG_LOG_SELECT,
            log_define: {
              ...convertStepInfo.log_define,
              log_name: item.value,
              input_type: INPUT_TYPE_CSV,
            },
          });
        } else {
          onChange(event);
          updateConvertInfo({
            ...convertStepInfo,
            mode:
              data?.new_rule === true
                ? STEP2_MSG_ADD
                : func_id !== undefined
                ? 'edit'
                : STEP2_MSG_LOG_SELECT,
            log_define: {
              ...convertStepInfo.log_define,
              log_name: item.value,
              input_type: INPUT_TYPE_CSV,
            },
          });
        }
        break;
      case 'new_rule':
        if ((data?.new_rule ?? false) !== item.value) {
          setNewRule(item.value);
          onChange(event);
          updateConvertInfo({
            ...convertStepInfo,
            mode: item.value === true ? STEP2_MSG_ADD : STEP2_MSG_LOG_SELECT,
          });
        }
        break;
      case 'src_file': {
        const fileName = getFileName(item.value);
        updateFuncInfo({
          ...funcStepInfo,
          src_file: fileName,
        });
        onChange({src_file: item.value});
      }
        break;
    }
  };
  const RemoteConfigChange = (event) => {
    const item = getParseData(event);

    switch (item.id) {
      case 'table_name':
        updateFuncInfo({
          ...funcStepInfo,
          info: {
            ...funcStepInfo.info,
            [item.id]: item.value,
            ['equipment_name']: '',
            ['user_fab']: '',
            ['period_start']: '',
            ['period_end']: '',
          },
        });
        break;
      case 'equipment_name':
        updateFuncInfo({
          ...funcStepInfo,
          info: {
            ...funcStepInfo.info,
            [item.id]: item.value,
            ['period_start']: '',
            ['period_end']: '',
          },
        });
        break;
      case 'db_id':
        updateFuncInfo({
          ...funcStepInfo,
          info:
            func_id ?? false
              ? {
                  ...funcStepInfo.info,
                  [item.id]: item.value,
                }
              : {
                  ...remote_info_initial,
                  [item.id]: item.value,
                },
        });
        break;
      case 'user_fab':
        updateFuncInfo({
          ...funcStepInfo,
          info: {
            ...funcStepInfo.info,
            [item.id]: item.value,
            ['equipment_name']: '',
            ['period_start']: '',
            ['period_end']: '',
          },
        });
        break;
      case 'period':
        {
          updateFuncInfo({
            ...funcStepInfo,
            info: {
              ...funcStepInfo.info,
              ['period_start']: item.value.start,
              ['period_end']: item.value.end,
            },
          });
        }
        break;
    }
  };
  const SQLConfigChange = (event) => {
    const item = getParseData(event);

    switch (item.id) {
      case 'sql':
        updateFuncInfo({
          ...funcStepInfo,
          info: {
            ...funcStepInfo.info,
            [item.id]: item.value,
          },
        });
        break;
    }
  };

  const change = (event) => {
    const item = getParseData(event);
    switch (item.id) {
      case 'source':
        if (funcStepInfo.source_type !== item.value) {
          updateConvertInfo({
            ...convertStepInfo,
            mode:
              item.value === 'remote'
                ? STEP2_MSG_LOG_SELECT
                : convertStepInfo.mode,
          });
          updateFuncInfo({ ...funcStepInfo, source_type: item.value });
        }
        break;
      case 'file_name':
        {
          const fileName = getFileName(item.value);
          console.log("[STEP2]2fileName", fileName);
          updateFuncInfo({
            ...funcStepInfo,
            script: {
              file_name: fileName,
              use_script: item.value === null ? false : true,
            },
          });
          onChange({ step2_script: item.value });
        }
        break;
      case 'use_script':
        updateFuncInfo({
          ...funcStepInfo,
          script: {
            ...funcStepInfo.script,
            use_script: item.value,
          },
        });
        break;
      case 'src_file':
      case 'new_rule':
      case 'log_name':
      case 'rule_name':
        LocalConfigChange(event);
        break;
      case 'equipment_name':
      case 'db_id':
      case 'table_name':
      case 'user_fab':
      case 'period':
        RemoteConfigChange(event);
        break;
      case 'sql':
        SQLConfigChange(event);
        break;
      case 'DELETE':
        deleteMuation.mutate(item.value.id);
        break;
      default:
        onChange(event);
        break;
    }
  };
  //============================================================================
  useEffect(() => {
    console.log('contents componets mount', func_id);
    const step2 = ruleStepConfig.find((step) => step.step === E_STEP_2).config;
    setConfig(step2);
    const { form, data: stepData } = step2;
    //Edit 화면으로 들어왔을때. step2 데이터에서 정보를 가져와서 REDUX에 저장해줘야한다.
    if (func_id) {
      const source =
        funcStepInfo?.source_type ?? getFindData(stepData, 'source');
      console.log('source', source);
      const obj =
        source === 'remote'
          ? {
              db_id:
                funcStepInfo?.info?.db_id ??  getFindData(stepData, 'db_id'),
              table_name:
                funcStepInfo?.info?.table_name ??
                getFindData(stepData, 'table_name'),
              equipment_name:
                funcStepInfo?.info?.equipment_name ??
                getFindData(stepData, 'equipment_name'),
            }
          : source === 'sql'
          ? {
              db_id:
                funcStepInfo?.info?.db_id ??  getFindData(stepData, 'db_id'),
              sql: funcStepInfo?.info?.sql ?? getFindData(stepData, 'sql'),
            }
          : {
            };
      console.log('Edit', obj);
      updateFuncInfo({ ...funcStepInfo, source_type: source, info: obj });
    }
    const ruleNameItem =
      form?.[MSG_LOCAL]?.find((obj) =>
        obj?.title.includes('Log Type'),
      )?.items?.find((item) => item.target === 'rule_name') ?? {};
    updateConvertInfo({
      ...convertStepInfo,
      mode: convertStepInfo?.mode ?? STEP2_MSG_NEW,
      rule_list: convertStepInfo?.rule_list ?? ruleNameItem?.options ?? [],
      log_define: convertStepInfo?.log_define ?? {},
    });
    setNewRule(func_id ? true: data?.new_rule === true ?? false);
    return () => {
      console.log('contents componets unmount');
    };
  }, []);

  useEffect(() => {
    if (func_id !== undefined) {
      if (convertStepInfo?.mode ?? true) {
        updateConvertInfo({
          ...convertStepInfo,
          mode: convertStepInfo?.mode ?? 'edit',
        });
      }
    }
  }, [func_id]);

  //============================================================================
  if (config === null) return <></>;

  return (
    <div css={{ width: '500px' }}>
      {(
        config?.form?.[funcStepInfo?.source_type ?? MSG_LOCAL] ?? config.data
      ).map((item, idx) => (
        <div key={idx}>
          <FormCard title={item.title} titleStyle={titlestyle}>
            <div>
              {item.items.map((idx2, i) => (
                <StepInputForm
                  key={i}
                  data={data}
                  item={item.items[i]}
                  changefunc={change}
                />
              ))}
            </div>
          </FormCard>
        </div>
      ))}
    </div>
  );
};
ContentsForm.propTypes = {
  data: PropTypes.object,
  onChange: PropTypes.func,
};

const PreviewForm = ({ data }) => {
  if (data == null) return <></>;
  const { log_header, log_data } = data;

  if (log_header === undefined || log_data === undefined) return <></>;

  return (
    <div css={tableWrapper}>
      <Table
        bordered
        pagination={false}
        columns={log_header}
        dataSource={log_data}
        size="middle"
        rowKey="key"
        scroll={{ x: 'max-content' }}
      />
    </div>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const Step2_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step2_Setting.propTypes = {
  children: PropTypes.node,
};

Step2_Setting.next = nextClick;
Step2_Setting.check = previewCheck;
Step2_Setting.contents = ContentsForm;
Step2_Setting.preview = PreviewForm;

export default Step2_Setting;
