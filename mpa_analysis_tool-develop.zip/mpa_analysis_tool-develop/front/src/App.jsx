import React from 'react';
import 'antd/dist/antd.css';
import Router from './components/pages/Main/Router';
import { Switch, Route } from 'react-router-dom';
import { MAIN, ANALYSIS } from './lib/api/Define/URL';

const App = () => {
  return (
    <>
      <Switch>
        <Route path={[MAIN, ANALYSIS]}>
          <Router />
        </Route>
      </Switch>
    </>
  );
};

export default App;
