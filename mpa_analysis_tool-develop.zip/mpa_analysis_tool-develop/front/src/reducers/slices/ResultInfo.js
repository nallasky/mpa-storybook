import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  graphType: [],
  selectedRow: [],
  originalGraphData: {},
  analysisGraphInfo: [],
  historyGraphData: [],
  historyGraphFilter: [],
  analysis: {
    period: {},
    filter: [],
    aggregation: {},
    dispOrder: [],
    dispGraph: [],
    data: {},
  },
  original: {
    period: {},
    filter: [],
    aggregation: {},
    dispOrder: [],
    dispGraph: [],
    data: {},
  },
  savedAnalysisAggregation: {},
};

const ResultInfo = createSlice({
  name: 'ResultInfo',
  initialState,
  reducers: {
    initialReducer: () => initialState,
    UpdateAnalysisReducer: (state, action) => {
      state.analysis = action.payload;
    },
    UpdateOriginalReducer: (state, action) => {
      state.original = action.payload;
    },
    UpdateGraphTypeReducer: (state, action) => {
      state.graphType = action.payload;
    },
    UpdateSelectedRowReducer: (state, action) => {
      state.selectedRow = action.payload;
    },
    UpdateOriginalGraphDataReducer: (state, action) => {
      state.originalGraphData = action.payload;
    },
    UpdateAnalysisGraphDataReducer: (state, action) => {
      state.analysisGraphInfo = action.payload;
    },
    UpdateHistoryGraphDataReducer: (state, action) => {
      state.historyGraphData = action.payload;
    },
    UpdateHistoryGraphFilterReducer: (state, action) => {
      state.historyGraphFilter = action.payload;
    },
    UpdateSavedAnalysisAggregationReducer: (state, action) => {
      state.savedAnalysisAggregation = action.payload;
    },
  },
});

export const {
  initialReducer: initialAction,
  UpdateAnalysisReducer,
  UpdateOriginalReducer,
  UpdateGraphTypeReducer,
  UpdateSelectedRowReducer,
  UpdateHistoryGraphDataReducer,
  UpdateHistoryGraphFilterReducer,
  UpdateOriginalGraphDataReducer,
  UpdateAnalysisGraphDataReducer,
  UpdateSavedAnalysisAggregationReducer,
} = ResultInfo.actions;

export default ResultInfo.reducer;
