# Release notes

## Version 1.1.0 (2021.09.10)

* Universal Analysis Function
  - Add/Edit/Delete Category
  - Add/Edit/Delete Analysis Function
  - Add/Edit/Delete Convert/Analysis Rule
  - Save Analysis History
  - Analysis Function Import/Export
  - New Graph Type Support(Box Plot/Density Plot/Bubble Chart)
  
## Version 1.0.0 (2021.06.09)

* Initial Release