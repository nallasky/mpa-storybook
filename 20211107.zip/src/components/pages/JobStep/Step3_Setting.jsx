import React from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/react';
import { Table } from 'antd';

const tableWrapper = css`
  display: contents;
`;

const nextClick = () => {
  return true;
};

const previewCheck = (data) => {
  const { convertStepInfo } = data;
  return Boolean(
    convertStepInfo?.log_define?.log_name &&
      convertStepInfo?.log_define?.table_name &&
      convertStepInfo?.log_define?.rule_name,
  );
};
const ContentsForm = () => {};

const PreviewForm = ({ data }) => {
  if (data == null) return <></>;

  const { convert_header, convert_data, convert_error } = data;

  if (
    convert_header === undefined &&
    convert_data === undefined &&
    convert_error === undefined
  )
    return <></>;

  return (
    <div css={tableWrapper}>
      {convert_error !== undefined ? (
        <>{convert_error}</>
      ) : (
        <Table
          bordered
          pagination={false}
          columns={convert_header}
          dataSource={convert_data}
          size="middle"
          rowKey="key"
          scroll={{ x: 'max-content' }}
        />
      )}
    </div>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const Step3_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step3_Setting.propTypes = {
  children: PropTypes.node,
};

Step3_Setting.next = nextClick;
Step3_Setting.check = previewCheck;
Step3_Setting.contents = ContentsForm;
Step3_Setting.preview = PreviewForm;

export default Step3_Setting;
