import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import { css } from '@emotion/react';
import { MSG_ADD_NEW, MSG_DISABLE } from '../../../lib/api/Define/Message';
import { useParams } from 'react-router';
import { E_STEP_2, RESPONSE_OK } from '../../../lib/api/Define/etc';
import { getParseData } from '../../../lib/util/Util';
import { Table } from 'antd';
import { deleteRequest, getRequest } from '../../../lib/api/axios/requests';
import {
  URL_RESOURCE_EDIT_STEP1,
  URL_RESOURCE_RULE,
  URL_RESOURCE_SETTING_DATE,
} from '../../../lib/api/Define/URL';
import { NotificationBox } from '../../UI/molecules/NotificationBox';
import { FormCard } from '../../UI/atoms/Modal';
import { StepInputForm } from '../../UI/organisms/StepInputForm';
const tableWrapper = css`
  display: contents;
`;
const titlestyle = css`
  font-weight: 400;
`;

const nextClick = () => {
  return true;
};

const previewCheck = (data) => {
  const { convertStepInfo, isEditMode } = data;
  return Boolean(
    isEditMode
      ? convertStepInfo?.log_define?.log_name && (data.rule_name ?? false)
      : data.log_name ?? false,
  );
};
/*============================================================================
==                         STEP 2 CONTENTS                                  ==
============================================================================*/
const STEP2_MSG_ADD = 'add';
const STEP2_MSG_NEW = 'new';
const STEP2_MSG_LOG_SELECT = 'empty';
const INPUT_TYPE_CSV = 'csv';
const ContentsForm = ({ data, onChange }) => {
  const {
    ruleStepConfig,
    updateConvertInfo,
    convertStepInfo,
    setRuleStepConfig,
  } = useRuleSettingInfo();
  const { func_id } = useParams();
  const [reload, setreload] = useState(false);
  const [config, setConfig] = useState(null);
  const [newRule, setNewRule] = useState(false);
  const [convert, setConvert] = useState({});

  //============================================================================
  const storeStepConfig = (current, info, step) => {
    const existIdx = ruleStepConfig.findIndex(
      (obj) => obj.step === step ?? current,
    );
    const cloneStep = ruleStepConfig.slice();
    if (existIdx !== -1) {
      cloneStep.splice(
        existIdx,
        1,
        Object.assign({}, ruleStepConfig[existIdx], {
          data: info,
        }),
      );
    } else {
      cloneStep.push({ step: step ?? current, data: info });
    }
    setRuleStepConfig(cloneStep);
  };
  const change = (event) => {
    const item = getParseData(event);
    const request = async (obj) => {
      console.log('change : ', obj);
      const { status, info } = await getRequest(
        `${URL_RESOURCE_SETTING_DATE}/${obj.log_name}/${obj.equipment_name}`,
      );
      if (status.toString() === RESPONSE_OK) {
        onChange(Object.assign({}, obj, { start: info.start, end: info.end }));
      }
    };
    switch (item.id) {
      case 'source':
        if ((data?.source ?? '') !== item.value) {
          onChange({ ...event, log_name: '' });
          setConvert((prevState) => ({
            mode:
              item.value === 'remote' ? STEP2_MSG_LOG_SELECT : prevState.mode,
            log_define: { ...prevState.log_define, log_name: '' },
          }));
        }
        break;
      case 'equipment_name':
        onChange(event);
        request({ log_name: data.log_name, equipment_name: item.value }).then(
          console.log('==============='),
        );
        break;
      case 'rule_name':
        if (item.value === MSG_ADD_NEW) {
          onChange({ new_rule: true, ...event });
        } else {
          onChange({ new_rule: false, ...event });
        }
        setConvert((prevState) => ({
          ...prevState,
          mode: item.value === MSG_ADD_NEW ? STEP2_MSG_ADD : 'edit',
          log_define: {
            ...prevState.log_define,
            rule_name: item.value === MSG_ADD_NEW ? '' : item.value,
          },
        }));
        break;
      case 'log_name':
        {
          if ((data?.source || 'local') === 'local') {
            if (item.value === MSG_ADD_NEW) {
              onChange({ new_rule: MSG_DISABLE, [item.id]: item.value });
              setConvert((prevState) => ({
                ...prevState,
                mode: STEP2_MSG_NEW,
                log_define: {
                  ...prevState.log_define,
                  log_name: '',
                  table_name: '',
                  rule_name: '',
                  input_type: INPUT_TYPE_CSV,
                },
              }));
            } else if (data?.new_rule === MSG_DISABLE) {
              onChange({ new_rule: newRule, [item.id]: item.value });
              setConvert((prevState) => ({
                ...prevState,
                mode: newRule === true ? STEP2_MSG_ADD : STEP2_MSG_LOG_SELECT,
                log_define: {
                  ...prevState.log_define,
                  log_name: item.value,
                  input_type: INPUT_TYPE_CSV,
                },
              }));
            } else {
              onChange(event);
              setConvert((prevState) => ({
                ...prevState,
                mode:
                  data?.new_rule === true
                    ? STEP2_MSG_ADD
                    : func_id !== undefined
                    ? 'edit'
                    : STEP2_MSG_LOG_SELECT,
                log_define: {
                  ...prevState.log_define,
                  log_name: item.value,
                  input_type: INPUT_TYPE_CSV,
                },
              }));
            }
            break;
          } else if (data?.equipment_name ?? false) {
            setConvert((prevState) => ({
              ...prevState,
              mode: STEP2_MSG_LOG_SELECT,
              log_define: {
                ...prevState.log_define,
                log_name: item.value,
                input_type: INPUT_TYPE_CSV,
              },
            }));
            request({
              log_name: item.value,
              equipment_name: data.equipment_name,
            }).then(console.log('==============='));
          }
        }
        onChange(event);
        break;
      case 'new_rule':
        if ((data?.new_rule ?? false) !== item.value) {
          setNewRule(item.value);
          onChange(event);
          setConvert((prevState) => ({
            ...prevState,
            mode: item.value === true ? STEP2_MSG_ADD : STEP2_MSG_LOG_SELECT,
          }));
        }
        break;
      case 'DELETE':
        {
          const request = async () => {
            const findObj =
              convertStepInfo?.rule_list?.find(
                (obj) => obj.rule_name === item.value,
              ) ?? {};
            console.log('findObj', findObj);
            try {
              const { info, status } = await deleteRequest(
                URL_RESOURCE_RULE,
                findObj.id,
              );
              if (status.toString() === RESPONSE_OK) {
                const { info, status } = await getRequest(
                  `${URL_RESOURCE_EDIT_STEP1}/${func_id}`,
                );
                if (status.toString() === RESPONSE_OK) {
                  storeStepConfig(undefined, info.data, E_STEP_2);
                }
              }
              setConvert((prevState) => ({
                ...prevState,
                rule_list:
                  info?.options ??
                  convertStepInfo.rule_list.filter(
                    (obj) => obj.rule_name !== item.value,
                  ),
              }));
            } catch (e) {
              if (e.reponse) {
                const { data } = e.reponse;
                NotificationBox(data.status, data.msg);
              }
            }
          };
          request().then(console.log('=============='));
        }
        break;
      default:
        onChange(event);
        break;
    }
  };
  const configSetting = (step2) => {
    const { formList, form } = step2.config;

    const ruleNameItem =
      form[formList[0]]
        ?.find((obj) => obj?.title.includes('Log Type'))
        ?.items?.find((item) => item.target === 'rule_name') ?? {};

    setConvert({
      mode: convertStepInfo?.mode ?? STEP2_MSG_NEW,
      rule_list: convertStepInfo?.rule_list ?? ruleNameItem?.options ?? [],
      log_define: convertStepInfo?.log_define ?? {},
    });
  };
  //============================================================================
  useEffect(() => {
    const step2 = ruleStepConfig.find((step) => step.step === E_STEP_2);
    setConfig(step2.config);
    const {formList, form, data: configData} = step2.config;

    const ruleNameItem =
        form?.[formList?.[0] ?? 0]
            ?.find((obj) => obj?.title.includes('Log Type'))
            ?.items?.find((item) => item.target === 'rule_name') ?? {};

    if (Object.keys(convertStepInfo.log_define).length === 0) {
      change({log_name: data?.log_name ?? MSG_ADD_NEW});
      change({source: formList?.[0] ?? configData.find(obj => obj.items[0].target === 'source').items[0].content});
    }
    setConvert({
      mode: convertStepInfo?.mode ?? STEP2_MSG_NEW,
      rule_list: convertStepInfo?.rule_list ?? ruleNameItem?.options ?? [],
      log_define: convertStepInfo?.log_define ?? {},
    });
    setNewRule(data?.new_rule === true ?? false);
  }, []);

  useEffect(() => {
    if (reload === true) {
      configSetting();
      setreload(false);
    }
  }, [reload]);
  useEffect(() => {
    if (func_id !== undefined) {
      if (convertStepInfo?.mode ?? true) {
        setConvert((prevState) => ({
          ...prevState,
          mode: convertStepInfo?.mode ?? 'edit',
        }));
      }
    }
  }, [func_id]);
  useEffect(() => {
    const clone = {...convertStepInfo};
    updateConvertInfo({...clone, ...convert});
  }, [convert]);

  //============================================================================
  if (config === null) return <></>;

  return (
      <div css={{width: '500px'}}>
        {(config?.form?.[data?.source || 'local'] ?? config.data).map((item, idx) => (
            <div key={idx}>
              <FormCard title={item.title} titleStyle={titlestyle}>
                {item.items.map((idx2, i) => (
                    <StepInputForm
                        key={i}
                        data={data}
                        item={item.items[i]}
                        changefunc={change}
                    />
                ))}
              </FormCard>
            </div>
        ))}
      </div>
  );
};
ContentsForm.propTypes = {
  data: PropTypes.object,
  onChange: PropTypes.func,
};

const PreviewForm = ({ data }) => {
  if (data == null) return <></>;
  const { log_header, log_data } = data;

  if (log_header === undefined || log_data === undefined) return <></>;

  return (
    <div css={tableWrapper}>
      <Table
        bordered
        pagination={false}
        columns={log_header}
        dataSource={log_data}
        size="middle"
        rowKey="key"
        scroll={{ x: 'max-content' }}
      />
    </div>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const Step2_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step2_Setting.propTypes = {
  children: PropTypes.node,
};

Step2_Setting.next = nextClick;
Step2_Setting.check = previewCheck;
Step2_Setting.contents = ContentsForm;
Step2_Setting.preview = PreviewForm;

export default Step2_Setting;
