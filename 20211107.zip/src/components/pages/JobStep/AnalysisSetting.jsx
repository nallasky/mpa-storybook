import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import React, { useEffect, useState } from 'react';
import { Collapse, Table, Button, Input, Select, Checkbox, Form } from 'antd';
import {
  MSG_PREVIOUS_TABLE,
  MSG_STEP4_SHOW_ORIGINAL,
  MSG_STEP5_AGGREGATION,
  MSG_STEP5_ANALYSIS,
  MSG_STEP5_FILTER,
  MSG_STEP5_FILTER_KEY,
  MSG_TABLE_TITLE_DELETE,
  MSG_TABLE_TITLE_DISP_ORDER,
  MSG_TABLE_TITLE_GROUP,
  MSG_TABLE_TITLE_SOURCE_COLUMN,
  MSG_TABLE_TITLE_TILE,
  MSG_TABLE_TITLE_TOTAL,
} from '../../../lib/api/Define/Message';
import PropTypes from 'prop-types';
import { E_STEP_4 } from '../../../lib/api/Define/etc';
import { css } from '@emotion/react';
import { getParseData } from '../../../lib/util/Util';
import TableComponent from './TableComponents';
import { useDebouncedCallback } from 'use-debounce';
const { Column } = Table;

const { Panel } = Collapse;
const { Option } = Select;
const tableWrapper = css`
  display: flex;
  & table {
    &:first-of-type > thead > tr > th {
      background: #f0f5ff;
    }
  }
  & > form {
    & > div {
      margin-bottom: 0;
      &:first-of-type .ant-form-item {
        margin-bottom: 0;
      }
      &:last-of-type {
        height: 32.46px;
      }
    }
  }
`;
const filterWrapper = css`
  display: grid;
  width: 100%;
  grid-template-columns: 1fr 1fr;
  grid-template-rows: auto;
  gap: 1rem;
  margin: 1rem 0;
  & .ant-form-item-label {
    display: block;
    text-align: left;
  }
  & .ant-form-item-control {
    display: block;
    max-width: 100%;
    width: 100%;
  }
  & .ant-form-item {
    margin-bottom: 0;
  }
  & .ant-col-20,
  & .ant-col-8 {
    flex: none;
  }
`;
const tailLayout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 20 },
};
const DEFINE_MAX_SELECT = 4;
const CUSTOM_SELECT = 'custom';
const SEQUENTIAL_SELECT = 'sequential';
const DEFINE_GROUP_BY_PERIOD = 'period';
const DEFINE_GROUP_BY_COLUMN = 'column';

const AnalysisTable = ({
  dataSource,
  deleteHandler,
  options,
  typeOptions,
  onChangeText,
  show_org,
}) => {
  const SelectDisable = (record, type) => {
    switch (record[type]) {
      case SEQUENTIAL_SELECT:
      case CUSTOM_SELECT:
        return false;
    }
    return true;
  };
  return (
    <div>
      <Table
        bordered
        pagination={false}
        size="small"
        rowKey="key"
        dataSource={dataSource}
        scroll={{ x: 'max-content' }}
      >
        <Column
          title={MSG_TABLE_TITLE_DISP_ORDER}
          dataIndex="idx"
          key="idx"
          render={(_, row, index) => {
            return <>{index + 1}</>;
          }}
        />
        <Column
          title={MSG_TABLE_TITLE_SOURCE_COLUMN}
          dataIndex="source_col"
          key="source_col"
          render={(_, record) => (
            <TableComponent.select
              target={'source_col'}
              record={record}
              options={options}
              onChange={onChangeText}
              disabled={show_org}
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_TILE}
          dataIndex="title"
          key="title"
          render={(_, record) => (
            <TableComponent.input
              target={'title'}
              record={record}
              onChange={onChangeText}
              disabled={show_org}
              size={'middle'}
            />
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_GROUP}
          dataIndex="group_analysis"
          key="group_analysis"
          render={(_, record) => (
            <div css={{ display: 'flex' }}>
              <TableComponent.input
                target={'group_analysis'}
                record={record}
                onChange={onChangeText}
                disabled={
                  show_org || SelectDisable(record, 'group_analysis_type')
                }
              />
              <TableComponent.select
                target={'group_analysis_type'}
                record={record}
                options={typeOptions}
                onChange={onChangeText}
                disabled={show_org}
              />
            </div>
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_TOTAL}
          dataIndex="total_analysis"
          key="total_analysis"
          render={(_, record) => (
            <div css={{ display: 'flex' }}>
              <TableComponent.input
                target={'total_analysis'}
                record={record}
                onChange={onChangeText}
                disabled={
                  show_org || SelectDisable(record, 'total_analysis_type')
                }
              />
              <TableComponent.select
                target={'total_analysis_type'}
                record={record}
                options={typeOptions}
                onChange={onChangeText}
                disabled={show_org}
              />
            </div>
          )}
        />
        <Column
          title={MSG_TABLE_TITLE_DELETE}
          dataIndex="delete"
          key="delete"
          render={(_, record) => (
            <TableComponent.delete
              record={record}
              deleteHandler={deleteHandler}
              type={'custom'}
              disabled={show_org}
            />
          )}
        />
      </Table>
    </div>
  );
};
AnalysisTable.propTypes = {
  dataSource: PropTypes.array,
  deleteHandler: PropTypes.func,
  options: PropTypes.array,
  typeOptions: PropTypes.array,
  onChangeText: PropTypes.func,
  show_org: PropTypes.bool,
};

const AnalysisSetting = ({ data, onChange }) => {
  const {
    ruleStepConfig,
    updateAnalysisInfo,
    analysisStepInfo,
  } = useRuleSettingInfo();
  const [config, setConfig] = useState({});
  const [filterCSelect, setFilterCSelect] = useState([]);
  const [filterKey, setFilterKey] = useState([]);
  const { filter_header, filter_data, show_org } = data;
  const [form] = Form.useForm();
  const [analysisInfo, setAnalysisInfo] = useState();
  const setDeboundcedText = useDebouncedCallback(
    ({ target, record, value }) => onInputChange({ target, record, value }),
    100,
  );

  const onChangeText = ({ record, target, value }) => {
    setDeboundcedText({ record, target, value });
  };

  const handleDelete = (key) => {
    const dataSource = [...analysisInfo.items];
    setAnalysisInfo((prev) => ({
      ...prev,
      items: dataSource.filter((item) => item.key !== key),
    }));
  };
  const handleAdd = () => {
    const dataSource = [...analysisInfo?.items] ?? [];
    let newData = { ['key']: '' };
    newData.key =
      dataSource.length === 0 ? 1 : dataSource[dataSource.length - 1].key + 1;
    setAnalysisInfo((prev) => ({
      ...prev,
      items: [...dataSource, newData],
    }));
  };
  const updateFilter = (filter_list) => {
    const step4 =
      ruleStepConfig.find((obj) => obj.step === E_STEP_4)?.data ?? [];
    setFilterKey(filter_list);
    setFilterCSelect(
      filter_list.map((v1) => {
        const opt = Object.entries(step4?.row ?? []).map((obj) => obj[1][v1]);
        return {
          label: v1,
          options: opt.filter((i, j) => opt.indexOf(i) === j) ?? [],
        };
      }),
    );
  };

  const onInputChange = ({ record, target, value }) => {
    const dataSource = [...analysisInfo.items];
    const checkType = (target) => {
      if (target === 'total_analysis_type') {
        return value === CUSTOM_SELECT || value === SEQUENTIAL_SELECT
          ? { [target]: value, ['total_analysis']: '' }
          : { [target]: value, ['total_analysis']: value };
      }
      if (target === 'group_analysis_type') {
        return value === CUSTOM_SELECT || value === SEQUENTIAL_SELECT
          ? { [target]: value, ['group_analysis']: '' }
          : { [target]: value, ['group_analysis']: value };
      }
      return undefined;
    };
    setAnalysisInfo((prevState) => ({
      ...prevState,
      items: dataSource.map((obj) =>
        obj.key === record.key
          ? Object.assign({}, obj, checkType(target) ?? { [target]: value })
          : obj,
      ),
    }));
  };

  useEffect(() => {
    console.log('[STEP5]data: ', data);
    const ruleConfig = ruleStepConfig.find(
      (item) =>
        item?.config?.src_col_list !== undefined ||
        item?.data?.src_col_list !== undefined ||
        item.config?.analysis?.calc_type !== undefined ||
        item.data?.analysis?.calc_type !== undefined ||
        item.data?.calc_type !== undefined
    );
    console.log('[STEP5]ruleConfig: ', ruleConfig);
    setConfig(
      Object.assign(
        {},
        {
          src_col_list: ruleConfig?.data?.src_col_list ?? [],
          filter_key_list: ruleConfig?.data?.filter_key_list ?? [],
          aggregation_type:
            ruleConfig?.config?.analysis?.aggregation_type ??
            ruleConfig?.data?.analysis?.aggregation_type ??
            ruleConfig?.data?.aggregation_type ??
            [],
          calc_type:
            ruleConfig?.config?.analysis?.calc_type ??
            ruleConfig?.data?.analysis?.calc_type ??
            ruleConfig?.data?.calc_type ??
            [],
        },
      ),
    );
    updateFilter(analysisStepInfo?.filter_default?.map((obj) => obj.key) ?? []);
    setAnalysisInfo(analysisStepInfo);
  }, []);

  useEffect(() => {
    console.log('[useEffect]analysisInfo', analysisInfo);
    updateAnalysisInfo(analysisInfo);
  }, [analysisInfo]);

  if (config === null || analysisInfo === undefined) return <></>;
  const filteredOptions =
    config?.filter_key_list.filter((o) => !filterKey.includes(o)) ?? [];

  const onFormLayoutChange = (e) => {
    console.log(e);
    const v = getParseData(e);
    switch (v.id) {
      case 'filter_key':
        {
          const filter_list = [...analysisInfo.filter_default];
          updateFilter(v.value);
          if (v.value.length < filter_list.length) {
            const copy =
              filter_list.filter((obj) => v.value.includes(obj.key)) ?? [];
            console.log('copy', copy);
            setAnalysisInfo((prevState) => ({
              ...prevState,
              filter_default: copy,
            }));
          }
        }
        break;
      case 'group_by':
        onChange({ ['group_value']: '' });
        form.setFieldsValue({ ['group_value']: '' });
        setAnalysisInfo((prevState) => ({
          ...prevState,
          aggregation_default: {
            ['type']: v.value,
            ['val']: '',
          },
        }));
        break;
      case 'group_value':
        setAnalysisInfo((prevState) => ({
          ...prevState,
          aggregation_default: {
            ...prevState.aggregation_default,
            ['val']: form.getFieldValue('group_value'),
          },
        }));
        break;
      default:
        {
          const copy =
            analysisInfo?.filter_default?.filter((obj) => obj.key !== v.id) ??
            [];
          copy.push({ ['key']: v.id, ['val']: v.value });

          setAnalysisInfo((prevState) => ({
            ...prevState,
            filter_default: copy,
          }));
        }

        break;
    }
    onChange(e);
  };

  return (
    <div css={{ maxWidth: '85%', minWidth: '75%' }}>
      <Collapse defaultActiveKey={[1, 2, 3]}>
        <Panel header={MSG_PREVIOUS_TABLE} key="1">
          {filter_header !== undefined ? (
            <div
              style={{
                fontWeight: '14px',
                margin: '10px',
                display: 'flex',
                justifyContent: 'center',
              }}
            >
              <Table
                bordered
                pagination={false}
                columns={filter_header}
                dataSource={filter_data}
                size="middle"
                rowKey="key"
                scroll={{ x: 'max-content' }}
              />
            </div>
          ) : (
            <div />
          )}
        </Panel>
        <Panel header={MSG_STEP5_ANALYSIS} key="2">
          <div>
            <Checkbox
              name={'show_org'}
              checked={show_org ?? false}
              onChange={(e) => {
                onChange({ ['show_org']: e.target.checked });
              }}
            >
              {MSG_STEP4_SHOW_ORIGINAL}
            </Checkbox>
            <Button
              onClick={() => handleAdd()}
              type="primary"
              style={{
                marginBottom: 16,
              }}
              disabled={show_org ?? false}
            >
              Add a row
            </Button>
          </div>
          <div css={tableWrapper} style={{ fontWeight: '12px' }}>
            <AnalysisTable
              dataSource={analysisInfo?.items ?? []}
              options={config?.src_col_list ?? []}
              typeOptions={config?.calc_type ?? []}
              deleteHandler={handleDelete}
              onChangeText={onChangeText}
              show_org={show_org ?? false}
            />
          </div>
        </Panel>
        <Panel header={MSG_STEP5_FILTER} key="3">
          <div css={tableWrapper} style={{ fontWeight: '12px' }}>
            <Form
              {...{ labelCol: { span: 5 }, wrapperCol: { span: 35 } }}
              form={form}
              onValuesChange={onFormLayoutChange}
            >
              <Form.Item
                label={MSG_STEP5_FILTER_KEY}
                style={{ width: '1000px' }}
              >
                <Form.Item name={'filter_key'} style={{ display: 'flex' }}>
                  {
                    <Select
                      placeholder="Please select"
                      defaultValue={filterKey ?? []}
                      mode="multiple"
                      maxTagTextLength={10}
                      maxTagCount={'responsive'}
                    >
                      {filteredOptions?.map((item, idx) => {
                        return (
                          <Option
                            key={idx}
                            value={item}
                            disabled={
                              filterKey.length === DEFINE_MAX_SELECT ?? true
                            }
                          >
                            {item}
                          </Option>
                        );
                      }) ?? <></>}
                    </Select>
                  }
                </Form.Item>
                <div css={filterWrapper}>
                  {filterCSelect.length > 0 ? (
                    filterCSelect.map((item, index) => {
                      const tmp = analysisInfo?.filter_default.find(
                        (obj) => obj.key === item.label,
                      );
                      console.log('tmp:', tmp);
                      return (
                        <Form.Item
                          {...tailLayout}
                          name={item.label}
                          label={item.label}
                          key={`fs_${index}`}
                        >
                          <Select
                            mode={'multiple'}
                            defaultValue={tmp?.val ?? []}
                            maxTagCount={'responsive'}
                            maxTagTextLength={10}
                            allowClear
                          >
                            {item.options.map((opt, idx) => {
                              return (
                                <Option key={idx} value={opt}>
                                  {opt}
                                </Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      );
                    })
                  ) : (
                    <></>
                  )}
                </div>
              </Form.Item>
              <Form.Item label={MSG_STEP5_AGGREGATION}>
                <Form.Item
                  name={'group_by'}
                  style={{ display: 'inline-block' }}
                >
                  <Select
                    style={{ width: '120px' }}
                    defaultValue={analysisInfo?.aggregation_default?.type ?? ''}
                    disabled={show_org ?? false}
                    allowClear
                  >
                    {
                      // eslint-disable-next-line react/jsx-key
                      config.aggregation_type.map((item, idx) => {
                        return (
                          <Option key={idx} value={item}>
                            {item}
                          </Option>
                        );
                      })
                    }
                  </Select>
                </Form.Item>
                <Form.Item
                  name={'group_value'}
                  style={{
                    display: 'inline-block',
                    marginLeft: '1rem',
                    minWidth: '200px',
                  }}
                >
                  {(analysisInfo?.aggregation_default?.type ?? '') ===
                  DEFINE_GROUP_BY_PERIOD ? (
                    <Input
                      allowClear
                      defaultValue={analysisInfo?.aggregation_default?.val}
                      disabled={show_org ?? false}
                      placeholder={`with input ${DEFINE_GROUP_BY_PERIOD}`}
                    />
                  ) : (analysisInfo?.aggregation_default?.type ?? '') ===
                    DEFINE_GROUP_BY_COLUMN ? (
                    <Select
                      allowClear
                      defaultValue={
                        analysisInfo?.aggregation_default?.val ??
                        config?.filter_key_list[0] ??
                        ''
                      }
                      disabled={show_org ?? false}
                      placeholder={`with select ${DEFINE_GROUP_BY_COLUMN}`}
                    >
                      {config.filter_key_list.map((item, idx) => {
                        return (
                          <Option key={idx} value={item}>
                            {item}
                          </Option>
                        );
                      })}
                    </Select>
                  ) : (
                    <></>
                  )}
                </Form.Item>
              </Form.Item>
            </Form>
          </div>
        </Panel>
      </Collapse>
    </div>
  );
};
AnalysisSetting.propTypes = {
  data: PropTypes.object,
  onChange: PropTypes.func,
};
export default AnalysisSetting;
