import React, { useEffect, useState } from 'react';
import { Drawer, Collapse } from 'antd';
import PropTypes from 'prop-types';
import useMgmtInfo from '../../../hooks/useMgmtInfo';
import { getRequest } from '../../../lib/api/axios/requests';
import { css } from '@emotion/react';
import { DBSetting, DBTable } from '../../UI/molecules/DrawerSetting';
import {
  URL_SETTING_GET_LOCAL,
  URL_SETTING_GET_REMOTE,
  URL_SETTING_GET_TABLES,
} from '../../../lib/api/Define/URL';
import { useQuery } from 'react-query';
import {
  MSG_MGMT_LOCAL_TITLE,
  MSG_MGMT_MAIN_TITLE,
  MSG_MGMT_REMOTE_TITLE,
  MSG_MGMT_TABLE_TITLE,
} from '../../../lib/api/Define/Message';
import {QUERY_KEY} from "../../../lib/api/Define/QueryKey";
import {LOCAL_INFO, REMOTE_INFO, TABLE_INFO} from "../../../lib/api/Define/etc";


const { Panel } = Collapse;

const MainTitleDiv = css`
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 16px 24px;
  color: #f0f0f0;
  background: #000000;
`;
const mgmt = [
  { id: LOCAL_INFO, title: MSG_MGMT_LOCAL_TITLE, url: URL_SETTING_GET_LOCAL },
  {
    id: REMOTE_INFO,
    title: MSG_MGMT_REMOTE_TITLE,
    url: URL_SETTING_GET_REMOTE,
  },
  { id: TABLE_INFO, title: MSG_MGMT_TABLE_TITLE, url: URL_SETTING_GET_TABLES },
];
const MgmtPage = ({ show, closeFunc }) => {
  const [openPanel, setOpenPanel] = useState([]);
  const {
    ManagementInfo,
    setMgmtInfo,
    isUpdate,
   // changeDBInfo,
    clearUpdateFlag,
  } = useMgmtInfo();

  const mgmt_init = async () => {
    const { info: localInfo } = await getRequest(URL_SETTING_GET_LOCAL);
    const { info: remoteInfo } = await getRequest(URL_SETTING_GET_REMOTE);
    const { info: tableInfo } = await getRequest(URL_SETTING_GET_TABLES);
    const settings = mgmt.map((obj) => {
      return {
        target: obj.id,
        title: obj.title,
        items:
          obj.id === LOCAL_INFO
            ? localInfo.items
            : obj.id === REMOTE_INFO
            ? remoteInfo.items
            : tableInfo,
      };
    });
    setMgmtInfo(settings);
  };
  const { error, isLoading } = useQuery([QUERY_KEY.MGMT_INIT], mgmt_init);

  useEffect(() => {
    return () => clearUpdateFlag();
  }, []);
  useEffect(() => {
    const isUpdateFunc = () => {
      setMgmtInfo(null);
    };
    if (isUpdate === true) {
      isUpdateFunc();
    }
  }, [isUpdate]);

  const updateFunc = () => {
    console.log('updateInfo');
   // changeDBInfo();
  };

  const CollapseContents = () => {
    return (
      <Collapse onChange={(e) => setOpenPanel(e)} defaultActiveKey={openPanel}>
        {ManagementInfo.map((obj, i) => {
          return (
            <Panel header={obj.title} key={i}>
              {obj.target === TABLE_INFO ? (
                <DBTable info={obj} />
              ) : obj.target === LOCAL_INFO ? (
                <DBSetting
                  info={obj}
                  update={updateFunc}
                  db_type={LOCAL_INFO}
                />
              ) : (
                <DBSetting
                  info={obj}
                  update={updateFunc}
                  db_type={REMOTE_INFO}
                />
              )}
            </Panel>
          );
        })}
      </Collapse>
    );
  };
  if (show === false && (ManagementInfo ?? true)) return <></>;
  if (isLoading) return <div> Waiting... </div>;
  if (error) {
    return <span>Error: {error?.message ?? 'undefined Error'}</span>;
  }

  return (
    <>
      <Drawer
        title={<div css={MainTitleDiv}>{MSG_MGMT_MAIN_TITLE}</div>}
        width={600}
        closable={false}
        onClose={closeFunc}
        visible={show}
        placement="right"
      >
        <CollapseContents />
      </Drawer>
    </>
  );
};

MgmtPage.propTypes = {
  show: PropTypes.bool,
  closeFunc: PropTypes.func,
};

export default MgmtPage;
