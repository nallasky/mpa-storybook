import React, { useRef, useState, useEffect } from 'react';
import { Form, Select, Button, Input, DatePicker } from 'antd';
import { CSSTransition } from 'react-transition-group';
import Plotly from 'plotly.js-dist';
import PropTypes from 'prop-types';
import dayjs from 'dayjs';
import * as SG from './styleGroup';
import { backgroundStyle } from '../GraphManagement/styleGroup';
import useRuleSettingInfo from '../../../../hooks/useRuleSettingInfo';
import * as Dummy from './../GraphManagement/dummyData';
import {
  dateValidateCheck,
  compareErrorCheck,
} from '../../molecules/SettingGraph/functionGroup';
import { DATE_FORMAT } from '../../../../lib/api/Define/etc';
import { displayNotification } from '../../../pages/JobAnalysis/functionGroup';

const { Option } = Select;
const { Item } = Form;
const { RangePicker } = DatePicker;
const defaultErrorMsg = `
  There is a problem with the setting.
  Please check the settings again.
`;
const regex = /^[-]?(\d{0,20})(\.\d{0,20})?$/;
const titleRegex = /^([a-zA-Z])$|^([a-zA-Z])[a-zA-Z0-9_]{0,18}([a-zA-Z])$/;

const { xData, yData, zData } = Dummy;

const GraphAddEdit = ({ closer, isOpen, mode, index }) => {
  const { visualStepInfo, updateVisualInfo } = useRuleSettingInfo();
  const graphArea = useRef();
  const [graphData, setGraphData] = useState({
    type: [],
    x: '0',
    y: [],
    z: '0',
  });
  const [title, setTitle] = useState('');
  const [xRange, setXrange] = useState({
    min: '',
    max: '',
  });
  const [yRange, setYrange] = useState({
    min: '',
    max: '',
  });
  const [zRange, setZrange] = useState({
    min: '',
    max: '',
  });
  const [errorMsg, setErrorMsg] = useState('');
  const [isPreview, setIsPreview] = useState(false);

  const renderGraph = (info, init) => {
    try {
      const currentScript = visualStepInfo.function_graph_type.find((v) => {
        return info.graphInfo.type === 'user'
          ? v.name === info.graphInfo.name
          : v.type === info.graphInfo.type;
      }).script;
      const newFunc = new Function('return ' + currentScript)();
      const tmpObj = {};

      if (info.y.length > 0) {
        info.y.reduce((acc, v) => {
          acc[v] = yData[v];
          return acc;
        }, tmpObj);
      }

      const params = {
        type: info.type,
        x: info.x === '0' ? [] : xData[info.x],
        y: tmpObj,
        z: info.z === '0' ? [] : zData[info.z],
        title: info.title,
        range: {
          x: info.xRange.min !== '' ? [info.xRange.min, info.xRange.max] : [],
          y: info.yRange.min !== '' ? [info.yRange.min, info.yRange.max] : [],
          z: info.zRange.min !== '' ? [info.zRange.min, info.zRange.max] : [],
        },
      };
      newFunc(Plotly, graphArea.current, params);
      setErrorMsg('');
      if (!init) {
        setIsPreview(true);
      }
    } catch (e) {
      console.log(e);
      setErrorMsg(defaultErrorMsg);
      setIsPreview(false);
    }
  };

  const changeGraphData = (type, v) => {
    let newData = graphData;
    newData[type] = v;
    setGraphData(Object.assign({}, newData));
    if (type === 'x' && checkXrange) {
      setXrange({
        min: '',
        max: '',
      });
    }
  };

  const checkXrange = () => {
    return (
      graphData.x !== '0' &&
      dateValidateCheck(xData[graphData.x][0], DATE_FORMAT)
    );
  };

  const disablePreview = () => {
    return graphData.type.length === 0 || graphData.y.length === 0;
  };

  const closeAddEdit = () => {
    closer();
    setGraphData({
      type: [],
      x: '0',
      y: [],
      z: '0',
    });
    setTitle('');
    setXrange({
      min: '',
      max: '',
    });
    setYrange({
      min: '',
      max: '',
    });
    setZrange({
      min: '',
      max: '',
    });
    setIsPreview(false);
    graphArea.current.removeAttribute('class');
    graphArea.current.firstChild?.remove();
  };

  const onAddEdit = () => {
    let message =
        mode === 'add' ? 'Add graph completed' : 'Edit graph completed',
      description = '',
      style = { borderLeft: '8px solid green' };

    if (graphData.type.length === 0) {
      description = 'Graph type is not set. Please check the graph type.';
    } else if (graphData.y.length === 0) {
      description =
        'No data has been selected for reference in the graph. Please select data.';
    } else if (
      graphArea.current.getElementsByClassName('plot-container').length === 0
    ) {
      description = `The graph has not been drawn yet. Please ${mode} again after the graph is drawn.`;
    } else if (title.length > 0 && !titleRegex.test(title)) {
      description = 'The title is incorrect. Please check the range setting.';
    } else if (
      xRange.min.length > 0 ||
      xRange.max.length > 0 ||
      yRange.min.length > 0 ||
      yRange.max.length > 0 ||
      zRange.min.length > 0 ||
      zRange.max.length > 0
    ) {
      if (
        (!dateValidateCheck(xRange.min, DATE_FORMAT) &&
          (!regex.test(xRange.min) ||
            !regex.test(xRange.max) ||
            compareErrorCheck(xRange.min, xRange.max))) ||
        !regex.test(yRange.min) ||
        !regex.test(yRange.max) ||
        compareErrorCheck(yRange.min, yRange.max) ||
        !regex.test(zRange.min) ||
        !regex.test(zRange.max) ||
        compareErrorCheck(zRange.min, zRange.max)
      ) {
        description =
          'The range setting is incorrect. Please check the range setting.';
      }
    } else if (!isPreview) {
      description =
        'Save is not executed because the graph has not been changed.';
    }

    if (description === '') {
      description =
        mode === 'add'
          ? 'Add a graph has been completed.'
          : 'Edit a graph has been completed.';
      const graphInfo = visualStepInfo.function_graph_type.find(
        (v) =>
          v.type ===
          visualStepInfo.graph_list.find((z) => z.name === graphData.type[0])
            .type,
      );

      const newItems = {
        id: mode === 'add' ? null : visualStepInfo.items[index].id,
        type: graphData.type,
        x_axis: graphData.x === '0' ? '' : graphData.x,
        y_axis: graphData.y,
        z_axis: graphData.z === '0' ? '' : graphData.z,
        title: title,
        x_range_min:
          xRange.min.length > 0
            ? dateValidateCheck(xRange.min, DATE_FORMAT)
              ? dayjs(xRange.min.toString())
              : xRange.min
            : '',
        x_range_max:
          xRange.min.length > 0
            ? dateValidateCheck(xRange.max, DATE_FORMAT)
              ? dayjs(xRange.max.toString())
              : xRange.max
            : '',
        y_range_min: yRange.min.length > 0 ? yRange.min : '',
        y_range_max: yRange.max.length > 0 ? yRange.max : '',
        z_range_min: zRange.min.length > 0 ? zRange.min : '',
        z_range_max: zRange.max.length > 0 ? zRange.max : '',
        script_info: {
          script: graphInfo.script,
          type: graphInfo.type,
        },
      };

      updateVisualInfo({
        ...visualStepInfo,
        items:
          mode === 'add'
            ? [...visualStepInfo.items, newItems]
            : visualStepInfo.items.map((v, i) => {
                return i !== index ? v : newItems;
              }),
      });
    } else {
      message = mode === 'add' ? 'Add graph failed' : 'Edit graph failed';
      style = { borderLeft: '8px solid red' };
    }

    displayNotification({
      message: message,
      description: description,
      duration: 3,
      style: style,
    });
    setIsPreview(false);
  };

  useEffect(() => {
    if (mode !== 'add') {
      const currentInfo = visualStepInfo.items[index];

      if (currentInfo) {
        setGraphData({
          type: currentInfo.type,
          x: currentInfo.x_axis === '' ? '0' : currentInfo.x_axis,
          y: currentInfo.y_axis,
          z: currentInfo.z_axis === '' ? '0' : currentInfo.z_axis,
        });
        setTitle(currentInfo.title);
        setXrange({
          min: currentInfo.x_range_min,
          max: currentInfo.x_range_max,
        });
        setYrange({
          min: currentInfo.y_range_min,
          max: currentInfo.y_range_max,
        });
        setZrange({
          min: currentInfo.z_range_min,
          max: currentInfo.z_range_max,
        });
        setIsPreview(false);

        renderGraph(
          {
            graphInfo: visualStepInfo.graph_list.find(
              (v) => v.name === currentInfo.type[0],
            ),
            type: currentInfo.type,
            x: currentInfo.x_axis,
            y: currentInfo.y_axis,
            z: currentInfo.z_axis,
            title: currentInfo.title,
            xRange: {
              min: currentInfo.x_range_min,
              max: currentInfo.x_range_max,
            },
            yRange: {
              min: currentInfo.y_range_min,
              max: currentInfo.y_range_max,
            },
            zRange: {
              min: currentInfo.z_range_min,
              max: currentInfo.z_range_max,
            },
          },
          true,
        );
      }
    }
  }, [isOpen]);

  return (
    <CSSTransition in={isOpen} classNames="modal" unmountOnExit timeout={100}>
      <>
        <div css={backgroundStyle} />
        <div css={SG.mainStyle}>
          <div>
            <div>{mode === 'add' ? 'Add Graph' : 'Edit Graph'}</div>
            <div>
              <Button onClick={closeAddEdit}>Close</Button>
              <Button type="primary" onClick={onAddEdit}>
                {mode === 'add' ? 'Add' : 'Save'}
              </Button>
            </div>
          </div>
          <div>
            <div>
              <Form labelAlign="left">
                <Item label="Graph Type">
                  <Select
                    mode="multiple"
                    value={graphData.type}
                    onChange={(v) => changeGraphData('type', v)}
                  >
                    {visualStepInfo.graph_list.map((v) => {
                      return (
                        <Option
                          value={v.name}
                          key={v.name}
                          disabled={
                            graphData.type.length > 0 &&
                            ((visualStepInfo.graph_list.find(
                              (z) => z.name === graphData.type[0],
                            ).type === 'user' &&
                              v.type === 'system') ||
                              (visualStepInfo.graph_list.find(
                                (z) => z.name === graphData.type[0],
                              ).type === 'system' &&
                                v.type === 'user'))
                          }
                        >
                          {v.name}
                        </Option>
                      );
                    })}
                  </Select>
                </Item>
                <Item label="Axis(X)">
                  <Select
                    value={graphData.x}
                    onChange={(v) => changeGraphData('x', v)}
                  >
                    <Option value="0">None</Option>
                    {Object.keys(xData).map((v) => {
                      return (
                        <Option value={v} key={v}>
                          {v}
                        </Option>
                      );
                    })}
                  </Select>
                </Item>
                <Item label="Axis(Y)">
                  <Select
                    mode="multiple"
                    value={graphData.y}
                    onChange={(v) => changeGraphData('y', v)}
                  >
                    {Object.keys(yData).map((v) => {
                      return (
                        <Option value={v} key={v}>
                          {v}
                        </Option>
                      );
                    })}
                  </Select>
                </Item>
                <Item label="Axis(Z)">
                  <Select
                    value={graphData.z}
                    onChange={(v) => changeGraphData('z', v)}
                  >
                    <Option value="0">None</Option>
                    {Object.keys(zData).map((v) => {
                      return (
                        <Option value={v} key={v}>
                          {v}
                        </Option>
                      );
                    })}
                  </Select>
                </Item>
                <Item label="Title">
                  <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    maxLength="20"
                  />
                </Item>
                <Item label="X Range">
                  {checkXrange() === false ? (
                    <div className="multi-input">
                      <Input
                        value={xRange.min}
                        onChange={(e) =>
                          setXrange((prevState) => {
                            return { ...prevState, min: e.target.value };
                          })
                        }
                      />
                      <Input
                        value={xRange.max}
                        onChange={(e) =>
                          setXrange((prevState) => {
                            return { ...prevState, max: e.target.value };
                          })
                        }
                      />
                    </div>
                  ) : (
                    <RangePicker
                      showTime
                      allowClear={false}
                      style={{ width: '100%' }}
                      onChange={(v) =>
                        setXrange({
                          min: v[0],
                          max: v[1],
                        })
                      }
                    />
                  )}
                </Item>
                <Item label="Y Range">
                  <div className="multi-input">
                    <Input
                      value={yRange.min}
                      onChange={(e) =>
                        setYrange((prevState) => {
                          return { ...prevState, min: e.target.value };
                        })
                      }
                    />
                    <Input
                      value={yRange.max}
                      onChange={(e) =>
                        setYrange((prevState) => {
                          return { ...prevState, max: e.target.value };
                        })
                      }
                    />
                  </div>
                </Item>
                <Item label="Z Range">
                  <div className="multi-input">
                    <Input
                      value={zRange.min}
                      onChange={(e) =>
                        setZrange((prevState) => {
                          return { ...prevState, min: e.target.value };
                        })
                      }
                    />
                    <Input
                      value={zRange.max}
                      onChange={(e) =>
                        setZrange((prevState) => {
                          return { ...prevState, max: e.target.value };
                        })
                      }
                    />
                  </div>
                </Item>
              </Form>
            </div>
            <div>
              <Button
                type="primary"
                disabled={disablePreview()}
                onClick={() =>
                  renderGraph(
                    {
                      graphInfo: visualStepInfo.graph_list.find(
                        (v) => v.name === graphData.type[0],
                      ),
                      x: graphData.x,
                      y: graphData.y,
                      z: graphData.z,
                      type: graphData.type,
                      title: title,
                      xRange: xRange,
                      yRange: yRange,
                      zRange: zRange,
                    },
                    false,
                  )
                }
              >
                Preview
              </Button>
              <div ref={graphArea}>{errorMsg.length > 0 ? errorMsg : ''}</div>
            </div>
          </div>
        </div>
      </>
    </CSSTransition>
  );
};

GraphAddEdit.propTypes = {
  closer: PropTypes.func.isRequired,
  isOpen: PropTypes.bool.isRequired,
  mode: PropTypes.string,
  index: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
GraphAddEdit.defaultProps = {
  mode: 'add',
};

export default GraphAddEdit;
