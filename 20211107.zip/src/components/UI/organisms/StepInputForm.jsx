import InputForm from '../atoms/Input/InputForm';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { MSG_ADD_NEW, MSG_DISABLE } from '../../../lib/api/Define/Message';
import { Button, Popconfirm, Select, Spin } from 'antd';
import { DeleteOutlined, LoadingOutlined } from '@ant-design/icons';
import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
const { Option } = Select;

const Contents = ({ options, target, defaultV, actionFunc }) => {
  const [loading, setLoading] = useState(false);
  const onClickEvent = (value, type) => {
    actionFunc({ [type]: value });
    if (type === 'DELETE') {
      setLoading(true);
    }
  };
  useEffect(() => {
    setLoading(false);
  }, [options]);
  if (options.length === 0) return <></>;
  return (
    <>
      <Spin
        tip="Deleting..."
        indicator={<LoadingOutlined style={{ fontSize: 24 }} spin />}
        spinning={loading}
      >
        <Select
          value={defaultV}
          onChange={(e) => {
            onClickEvent(e, target);
          }}
        >
          {options.map((item, idx) => {
            return (
              <Option key={idx} value={item} >
                {
                  <>
                    {''}
                    {item}
                    {item === MSG_ADD_NEW ? (
                      <></>
                    ) : (
                      <Popconfirm
                        title={`Are you sure to delete Rule ${item}`}
                        onConfirm={(e) => {
                          e.stopPropagation();
                          onClickEvent(item, 'DELETE');
                        }}
                      >
                        <Button
                          type="text"
                          icon={<DeleteOutlined />}
                          style={{ float: 'right' }}
                          onClick={(e) => e.stopPropagation()}
                        />
                      </Popconfirm>
                    )}
                  </>
                }
              </Option>
            );
          })}
        </Select>
      </Spin>
    </>
  );
};
Contents.propTypes = {
  options: PropTypes.array,
  defaultV: PropTypes.string,
  target: PropTypes.string,
  actionFunc: PropTypes.func,
};
export const StepInputForm = ({ item, data, changefunc }) => {
  const { title, type, mode } = item;
  const [date, setDate] = useState({ start: 0, end: 0 });
  const [selectOptions, setSelectOptions] = useState({});
  const { convertStepInfo } = useRuleSettingInfo();
  const changeEvent = (e) => {
    console.log('changeEvent:', e);
    changefunc(e);
  };
  useEffect(() => {
    if (data?.start !== undefined && data?.end !== undefined) {
      if (data.start !== date.start || data.end !== date.end) {
        setDate({
          start: data.start,
          end: data.end,
        });
      }
    }
    if (
      Object.keys(selectOptions).length > 0 &&
      data?.rule_name !== selectOptions.selected
    ) {
      setSelectOptions((prevState) => ({
        ...prevState,
        selected: data?.rule_name,
      }));
    }
  }, [data]);

  useEffect(() => {
    if (item.target === 'rule_name' && type === 'select') {
      setSelectOptions({
        options: item.options.map((obj) => obj.rule_name),
        selected: data?.rule_name ?? '',
      });
    }
  }, []);

  useEffect(() => {
    if (
      (convertStepInfo?.rule_list?.length ?? 0) !==
      (selectOptions?.options?.length ?? 0)
    ) {
      setSelectOptions({
        options: convertStepInfo.rule_list.map((obj) => obj.rule_name),
        selected: '',
      });
    }
  }, [convertStepInfo.rule_list]);

  return (
    <div>
      {type === 'select' ? (
        mode === 'singular' ? (
          item.target === 'rule_name' ? (
            <InputForm.select
              formLabel={title}
              formName={item.target}
              options={[]}
              optionNode={
                <Contents
                  options={selectOptions?.options ?? []}
                  defaultV={selectOptions?.selected ?? ''}
                  actionFunc={changeEvent}
                  target={item.target}
                />
              }
              changeFunc={changeEvent}
              defaultV={selectOptions?.selected ?? ''}
            />
          ) : (
            <InputForm.select
              formLabel={title}
              formName={item.target}
              options={item.options}
              changeFunc={changeEvent}
              defaultV={data?.[item.target] ?? item.options[0]}
            />
          )
        ) : mode === 'subItem' ? (
          <>
            <InputForm.subItem
              formLabel={title}
              formName={item.target}
              options={item.options}
              subItem={item.subItem}
              changeFunc={changeEvent}
            />
          </>
        ) : (
          <></>
        )
      ) : type === 'file' ? (
        <InputForm.file
          formLabel={title}
          formName={item.target}
          file={data?.['uploadedFile'] ?? []}
          changeFunc={changefunc}
        />
      ) : type === 'checkbox' ? (
        <InputForm.checkbox
          formName={item.target}
          context={title}
          changeFunc={changefunc}
          value={data?.[item.target] === 'true'}
          disabled={data?.[item.target] === MSG_DISABLE}
        />
      ) : type === 'text' ? (
        <InputForm.text
          formLabel={title}
          formName={item.target}
          changeFunc={changefunc}
          value={item.content}
        />
      ) : type === 'input' ? (
        <InputForm.text
          formLabel={title}
          formName={item.target}
          changeFunc={changefunc}
          value={item.content}
        />
      ) : type === 'datePicker' ? (
        <InputForm.datePicker
          formLabel={title}
          formName={item.target}
          start={date?.start ?? item.options?.start ?? 0}
          end={date?.end ?? item.options?.end ?? 0}
          changeFunc={changeEvent}
          disabled={item?.enable ?? false}
        />
      ) : (
        <div>{title}</div>
      )}
    </div>
  );
};

StepInputForm.propTypes = {
  data: PropTypes.object,
  item: PropTypes.object.isRequired,
  changefunc: PropTypes.func.isRequired,
};
