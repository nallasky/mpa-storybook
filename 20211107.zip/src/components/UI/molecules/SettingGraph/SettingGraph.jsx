import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import dayjs from 'dayjs';
import { Button, Input, DatePicker, Empty, Form } from 'antd';
import { SettingFilled } from '@ant-design/icons';
import Graph from '../../atoms/Graph';
import * as fn from './functionGroup';
import * as sg from './styleGroup';
import useResultInfo from '../../../../hooks/useResultInfo';
import { DATE_FORMAT } from '../../../../lib/api/Define/etc';

const { RangePicker } = DatePicker;
const regex = /^[-]?(\d{0,20})(\.\d{0,20})?$/;

const SettingGraph = React.memo(
  ({ data, title, onApply, useRedux }) => {
    const { setHistoryGraphFilter } = useResultInfo();
    const prevProps = fn.usePrevious(data);
    const [showPopup, setShowPopup] = useState(false);
    const [errorInfo, setErrorInfo] = useState({
      minx: false,
      maxx: false,
      miny: false,
      maxy: false,
    });
    const [axisY, setAxisY] = useState({ min: '', max: '' });
    const [axisX, setAxisX] = useState({ min: '', max: '', date: [] });
    const [beforeInfo, setBeforeInfo] = useState({
      axisX: {},
      axisY: {},
    });
    const [graphProp, setGraphProp] = useState({});

    const updateRangeInfo = (e) => {
      let tmpX = undefined,
        tmpY = undefined;

      if (e['xaxis.range[0]'] !== undefined) {
        const isDate =
          e['xaxis.range[0]'] === null || e['xaxis.range[0]'] === undefined
            ? false
            : fn.dateValidateCheck(
                e['xaxis.range[0]']
                  .toString()
                  .substr(
                    0,
                    e['xaxis.range[0]'].toString().indexOf('.') !== -1
                      ? e['xaxis.range[0]'].toString().indexOf('.')
                      : e['xaxis.range[0]'].toString().length,
                  ),
                DATE_FORMAT,
              );
        tmpX = {
          min: isDate ? 0 : e['xaxis.range[0]'],
          max: isDate ? 0 : e['xaxis.range[1]'],
          date: isDate
            ? [
                dayjs(e['xaxis.range[0]'].toString()),
                dayjs(e['xaxis.range[1]'].toString()),
              ]
            : [],
        };
        setAxisX(tmpX);
      }

      if (e['yaxis.range[0]'] !== undefined) {
        tmpY = {
          min: e['yaxis.range[0]'],
          max: e['yaxis.range[1]'],
        };
        setAxisY(tmpY);
      }

      if (tmpX === undefined && tmpY === undefined) {
        tmpX = fn.createXvalue(data.x);
        tmpY = {
          min: Math.min(...data.y),
          max: Math.max(...data.y),
        };
        setAxisX(tmpX);
        setAxisY(tmpY);
      }
      setBeforeInfo({
        axisX: tmpX,
        axisY: tmpY,
      });
      saveGraphFilter(tmpX, tmpY);
    };

    const saveGraphFilter = (x, y) => {
      let xData = {},
        yData = {};
      if (useRedux || onApply !== undefined) {
        const { findHistory, historyIsDate } = fn.setHistoryInfo(
          data.currentFilter,
          title,
        );
        xData =
          x !== undefined
            ? x
            : (axisX.min === '' || axisX.min === null) &&
              axisX.date.length === 0
            ? {
                min: historyIsDate ? 0 : findHistory.x_range_min,
                max: historyIsDate ? 0 : findHistory.x_range_max,
                date: historyIsDate
                  ? [
                      dayjs(findHistory.x_range_min),
                      dayjs(findHistory.x_range_max),
                    ]
                  : [],
              }
            : axisX;
        yData =
          y !== undefined
            ? y
            : axisY.min === ''
            ? {
                min: findHistory.y_range_min,
                max: findHistory.y_range_max,
              }
            : axisY;
        const tmpObj = {
          title: title,
          x_range_max:
            xData.date.length > 0
              ? xData.date[1].format(DATE_FORMAT)
              : fn.convertValue(xData.max),
          x_range_min:
            xData.date.length > 0
              ? xData.date[0].format(DATE_FORMAT)
              : fn.convertValue(xData.min),
          y_range_min: fn.convertValue(yData.min),
          y_range_max: fn.convertValue(yData.max),
          z_range_max: findHistory ? findHistory.z_range_min : 0,
          z_range_min: findHistory ? findHistory.z_range_max : 0,
        };
        if (onApply !== undefined) {
          onApply({
            minX:
              xData.date.length > 0
                ? xData.date[0].format(DATE_FORMAT)
                : fn.convertValue(xData.min),
            maxX:
              xData.date.length > 0
                ? xData.date[1].format(DATE_FORMAT)
                : fn.convertValue(xData.max),
            minY: fn.convertValue(yData.min),
            maxY: fn.convertValue(yData.max),
          });
        } else {
          setHistoryGraphFilter(
            data.currentFilter.map((v) => {
              return v.title === title ? tmpObj : v;
            }),
          );
        }
      } else {
        xData = x !== undefined ? x : axisX;
        yData = y !== undefined ? y : axisY;
      }
      filteringGraphAxis(xData, yData);
    };

    const filteringGraphAxis = (xFilter, yFilter) => {
      const rangeObj = {
        xRange:
          xFilter.date.length > 0
            ? xFilter.date.map((v) => dayjs(v).format(DATE_FORMAT))
            : [xFilter.min, xFilter.max],
        yRange: [yFilter.min, yFilter.max],
      };

      setGraphProp(
        fn.createGraphProp(
          data.graphType,
          data.x,
          data.y,
          data.z,
          title,
          rangeObj,
        ),
      );
    };

    const changeMinY = (value) => {
      setAxisY((prevState) => {
        return {
          ...prevState,
          min: value,
        };
      });
    };

    const changeMaxY = (value) => {
      setAxisY((prevState) => {
        return {
          ...prevState,
          max: value,
        };
      });
    };

    const changeMinX = (value) => {
      setAxisX((prevState) => {
        return {
          ...prevState,
          min: value,
        };
      });
    };

    const changeMaxX = (value) => {
      setAxisX((prevState) => {
        return {
          ...prevState,
          max: value,
        };
      });
    };

    const changeDateX = (value) => {
      setAxisX((prevState) => {
        return {
          ...prevState,
          date: value,
        };
      });
    };

    const applySetting = () => {
      const errorMinx =
        axisX.date.length > 0 ? false : fn.regexCheck(regex, axisX.min);
      const errorMaxx =
        axisX.date.length > 0
          ? false
          : fn.regexCheck(regex, axisX.max) ||
            fn.compareErrorCheck(axisX.min, axisX.max);
      const errorMiny = fn.regexCheck(regex, axisY.min);
      const errorMaxy =
        fn.regexCheck(regex, axisY.max) ||
        fn.compareErrorCheck(axisY.min, axisY.max);

      if (errorMinx || errorMaxx || errorMiny || errorMaxy) {
        setErrorInfo({
          minx: errorMinx,
          maxx: errorMaxx,
          miny: errorMiny,
          maxy: errorMaxy,
        });
      } else {
        if (onApply !== undefined && !useRedux) {
          onApply({
            minX:
              axisX.date.length > 0
                ? axisX.date[0].format(DATE_FORMAT)
                : axisX.min,
            maxX:
              axisX.date.length > 0
                ? axisX.date[1].format(DATE_FORMAT)
                : axisX.max,
            minY: axisY.min,
            maxY: axisY.max,
          });
        }

        saveGraphFilter(axisX, axisY);
        setShowPopup(false);
        setErrorInfo({
          minx: false,
          maxx: false,
          miny: false,
          maxy: false,
        });
        setBeforeInfo({
          axisX: axisX,
          axisY: axisY,
        });
      }
    };

    const closePopup = () => {
      setShowPopup(false);
      setAxisX(beforeInfo.axisX);
      setAxisY(beforeInfo.axisY);
    };

    useEffect(() => {
      let tmpAxisX =
          (axisX.min === null || axisX.min === '') && axisX.date.length === 0
            ? {}
            : axisX,
        tmpAxisY = axisY.min === '' ? {} : axisY;
      if (prevProps === undefined) {
        const findHistory =
          data.currentFilter === undefined
            ? undefined
            : data.currentFilter.find((v) => v.title === title);
        if (findHistory === undefined) {
          tmpAxisX = fn.createXvalue(data.x);
          tmpAxisY = {
            min: Math.min(...data.y),
            max: Math.max(...data.y),
          };
        } else {
          const historyIsDate = fn.dateValidateCheck(
            findHistory.x_range_min
              .toString()
              .substr(
                0,
                findHistory.x_range_min.toString().indexOf('.') !== -1
                  ? findHistory.x_range_min.toString().indexOf('.')
                  : findHistory.x_range_min.toString().length,
              ),
            DATE_FORMAT,
          );

          tmpAxisX = {
            min: historyIsDate ? 0 : findHistory.x_range_min,
            max: historyIsDate ? 0 : findHistory.x_range_max,
            date: historyIsDate
              ? [dayjs(findHistory.x_range_min), dayjs(findHistory.x_range_max)]
              : [],
          };
          tmpAxisY = {
            min: findHistory.y_range_min,
            max: findHistory.y_range_max,
          };
        }
        setAxisX(tmpAxisX);
        setAxisY(tmpAxisY);
      } else {
        if (JSON.stringify(prevProps.x) !== JSON.stringify(data.x)) {
          tmpAxisX = fn.createXvalue(data.x);
          setAxisX(tmpAxisX);
        }

        if (JSON.stringify(prevProps.y) !== JSON.stringify(data.y)) {
          tmpAxisY = {
            min: Math.min(...data.y),
            max: Math.max(...data.y),
          };
          setAxisY(tmpAxisY);
        }
      }
      setBeforeInfo({
        axisX: tmpAxisX,
        axisY: tmpAxisY,
      });
      filteringGraphAxis(tmpAxisX, tmpAxisY);
    }, [
      JSON.stringify(data.x),
      JSON.stringify(data.y),
      JSON.stringify(data.z),
      JSON.stringify(data.graphType),
    ]);

    useEffect(() => {
      if (
        prevProps !== undefined &&
        JSON.stringify(prevProps.currentFilter) !==
          JSON.stringify(data.currentFilter)
      ) {
        const { findHistory, historyIsDate } = fn.setHistoryInfo(
          data.currentFilter,
          title,
        );
        const tmpAxisX = {
          min: historyIsDate ? 0 : findHistory.x_range_min,
          max: historyIsDate ? 0 : findHistory.x_range_max,
          date: historyIsDate
            ? [dayjs(findHistory.x_range_min), dayjs(findHistory.x_range_max)]
            : [],
        };
        const tmpAxisY = {
          min: findHistory.y_range_min,
          max: findHistory.y_range_max,
        };
        setAxisX(tmpAxisX);
        setAxisY(tmpAxisY);
        setBeforeInfo({
          axisX: tmpAxisX,
          axisY: tmpAxisY,
        });
        filteringGraphAxis(tmpAxisX, tmpAxisY);
      }
    }, [JSON.stringify(data.currentFilter)]);

    useEffect(() => {
      return () => {
        return null;
      };
    }, []);

    return data.graphType.length > 0 ? (
      <>
        <div css={sg.buttonWrapper}>
          <Button
            type="dashed"
            shape="round"
            icon={<SettingFilled />}
            onClick={() => setShowPopup(!showPopup)}
          >
            Range Setting
          </Button>
          <div
            style={showPopup ? { display: 'block' } : {}}
            onClick={() => closePopup()}
            onKeyDown={() => closePopup()}
            role="button"
            tabIndex="0"
          />
          <div css={[sg.popupStyle, showPopup ? { display: 'block' } : '']}>
            <div>Range Setting</div>
            <div>
              <div>
                <div>Axis (X)</div>
                {axisX.date.length > 0 ? (
                  <div css={sg.selectWrapper}>
                    <RangePicker
                      value={axisX.date}
                      showTime
                      onChange={changeDateX}
                      allowClear={false}
                    />
                  </div>
                ) : (
                  <div css={sg.inputWrapper}>
                    <div>
                      <Form.Item
                        label="Min"
                        validateStatus={errorInfo.minx ? 'error' : 'success'}
                        help={errorInfo.minx ? 'Invalid value.' : ''}
                      >
                        <Input
                          value={axisX.min}
                          onChange={(e) => changeMinX(e.target.value)}
                        />
                      </Form.Item>
                    </div>
                    <div>
                      <Form.Item
                        label="Max"
                        validateStatus={errorInfo.maxx ? 'error' : 'success'}
                        help={errorInfo.maxx ? 'Invalid value.' : ''}
                      >
                        <Input
                          value={axisX.max}
                          onChange={(e) => changeMaxX(e.target.value)}
                        />
                      </Form.Item>
                    </div>
                  </div>
                )}
              </div>
              <div>
                <div>Axis (Y)</div>
                <div css={sg.inputWrapper}>
                  <div>
                    <Form.Item
                      label="Min"
                      validateStatus={errorInfo.miny ? 'error' : 'success'}
                      help={errorInfo.miny ? 'Invalid value.' : ''}
                    >
                      <Input
                        value={axisY.min}
                        onChange={(e) => changeMinY(e.target.value)}
                      />
                    </Form.Item>
                  </div>
                  <div>
                    <Form.Item
                      label="Max"
                      validateStatus={errorInfo.maxy ? 'error' : 'success'}
                      help={errorInfo.maxy ? 'Invalid value.' : ''}
                    >
                      <Input
                        value={axisY.max}
                        onChange={(e) => changeMaxY(e.target.value)}
                      />
                    </Form.Item>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <Button type="primary" onClick={applySetting}>
                Save
              </Button>
              <Button onClick={() => closePopup()}>Cancel</Button>
            </div>
          </div>
        </div>
        <Graph
          plotProps={{
            ...graphProp,
            onRelayout: (e) => updateRangeInfo(e),
          }}
        />
      </>
    ) : (
      <Empty />
    );
  },
  (prevProps, nextProps) =>
    JSON.stringify(prevProps) === JSON.stringify(nextProps),
);

SettingGraph.displayName = 'SettingGraph';
SettingGraph.propTypes = {
  data: PropTypes.object.isRequired,
  title: PropTypes.string,
  onApply: PropTypes.func,
  useRedux: PropTypes.bool,
};
SettingGraph.defaultProps = {
  useRedux: false,
};

export default SettingGraph;
