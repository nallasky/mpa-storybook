import { useEffect, useRef } from 'react';
import dayjs from 'dayjs';
import { DATE_FORMAT } from '../../../../lib/api/Define/etc';

export const regexCheck = (regex, v) => {
  return !regex.test(v) || v.length === 0;
};

export const compareErrorCheck = (min, max) => {
  if (min.toString().length === 0 && max.toString().length === 0) return false;
  const parseMin =
    typeof min === 'number'
      ? min
      : min.indexOf('.') !== -1
      ? parseFloat(min)
      : parseInt(min);
  const parseMax =
    typeof max === 'number'
      ? max
      : max.indexOf('.') !== -1
      ? parseFloat(max)
      : parseInt(max);

  return isNaN(parseMin) || isNaN(parseMax) ? true : parseMax <= parseMin;
};

export const convertValue = (v) => {
  return typeof v === 'number'
    ? v
    : v.toString().indexOf('.') !== -1
    ? parseFloat(v)
    : parseInt(v);
};

export const setHistoryInfo = (filter, title) => {
  const history = filter.find((v) => v.title === title);
  const dateCheck = dateValidateCheck(
    history.x_range_min
      .toString()
      .substr(
        0,
        history.x_range_min.toString().indexOf('.') !== -1
          ? history.x_range_min.toString().indexOf('.')
          : history.x_range_min.toString().length,
      ),
    DATE_FORMAT,
  );

  return {
    findHistory: history,
    historyIsDate: dateCheck,
  };
};

export const createXvalue = (arr) => {
  const tmpArr = arr.sort();
  if (arr.length > 0) {
    const isDate =
      tmpArr[0] === null || tmpArr[0] === undefined
        ? false
        : dateValidateCheck(
            tmpArr[0]
              .toString()
              .substr(
                0,
                tmpArr[0].toString().indexOf('.') !== -1
                  ? tmpArr[0].toString().indexOf('.')
                  : tmpArr[0].toString().length,
              ),
            DATE_FORMAT,
          );
    const minValue = isDate
      ? 0
      : isNaN(parseFloat(tmpArr[0])) || isNaN(parseInt(tmpArr[0]))
      ? 0
      : Math.min(...tmpArr);
    const maxValue = isDate
      ? 0
      : isNaN(parseFloat(tmpArr[0])) || isNaN(parseInt(tmpArr[0]))
      ? 0
      : Math.max(...tmpArr);

    return {
      min: minValue,
      max: maxValue,
      date: isDate ? [dayjs(tmpArr[0]), dayjs(tmpArr[tmpArr.length - 1])] : [],
    };
  } else {
    return {
      min: 0,
      max: 0,
      date: [],
    };
  }
};

export const dateValidateCheck = (date, format) => {
  return dayjs(date, format).format(format) === date;
};

export const usePrevious = (v) => {
  const ref = useRef();
  useEffect(() => {
    ref.current = v;
  });
  return ref.current;
};

export const createPropData = (obj, v, x, y, z, title, range) => {
  let tmpRange = {},
    tmpDensityRange = {};

  if (range.xRange !== undefined) {
    tmpRange['xaxis'] = {
      range: range.xRange,
    };
  }

  if (range.yRange !== undefined) {
    tmpRange['yaxis'] = {
      range: range.yRange,
    };
  }

  switch (v.toLowerCase()) {
    case 'bar':
    default:
      if (Object.keys(obj).length === 0) {
        obj = {
          data: [
            {
              x: x,
              y: y,
              type: 'bar',
            },
          ],
          layout: {
            title: title,
            font: {
              family: "Saira, 'Nunito Sans'",
            },
            ...tmpRange,
          },
        };
      } else {
        obj = {
          ...obj,
          data: [
            ...obj.data,
            {
              x: x,
              y: y,
              type: 'bar',
            },
          ],
        };
      }
      break;

    case 'line':
      if (Object.keys(obj).length === 0) {
        obj = {
          data: [
            {
              x: x,
              y: y,
              type: 'scatter',
              name: title,
            },
          ],
          layout: {
            title: title,
            font: {
              family: "Saira, 'Nunito Sans'",
            },
            ...tmpRange,
          },
        };
      } else {
        obj = {
          ...obj,
          data: [
            ...obj.data,
            {
              x: x,
              y: y,
              type: 'scatter',
              name: title,
            },
          ],
        };
      }
      break;

    case 'box plot':
      if (Object.keys(obj).length === 0) {
        obj = {
          data: [
            {
              y: y,
              name: title,
              type: 'box',
            },
          ],
          layout: {
            title: title,
            font: {
              family: "Saira, 'Nunito Sans'",
            },
            ...tmpRange,
          },
        };
      } else {
        obj = {
          data: [
            ...obj.data,
            {
              y: y,
              name: title,
              type: 'box',
            },
          ],
        };
      }
      break;

    case 'density plot':
      if (range.xRange !== undefined) {
        tmpDensityRange['xaxis'] = {
          showgrid: false,
          zeroline: false,
          range: range.xRange,
        };
      }

      if (range.yRange !== undefined) {
        tmpDensityRange['yaxis'] = {
          showgrid: false,
          zeroline: false,
          range: range.yRange,
        };
      }

      if (Object.keys(obj).length === 0) {
        obj = {
          data: [
            {
              x: x,
              y: y,
              mode: 'markers',
              name: 'points',
              marker: {
                color: 'rgb(245,245,245)',
                size: 1.5,
                opacity: 0.7,
              },
              type: 'scatter',
            },
            {
              x: x,
              y: y,
              name: 'density',
              ncontours: 20,
              colorscale: 'Blues',
              reversescale: true,
              showscale: false,
              type: 'histogram2dcontour',
            },
          ],
          layout: {
            title: title,
            font: {
              family: "Saira, 'Nunito Sans'",
            },
            showlegend: false,
            hovermode: 'closest',
            bargap: 0,
            ...tmpDensityRange,
          },
        };
      } else {
        obj = {
          ...obj,
          data: [
            ...obj.data,
            {
              x: x,
              y: y,
              mode: 'markers',
              name: 'points',
              marker: {
                color: 'rgb(245,245,245)',
                size: 1.5,
                opacity: 0.7,
              },
              type: 'scatter',
            },
            {
              x: x,
              y: y,
              name: 'density',
              ncontours: 20,
              colorscale: 'Blues',
              reversescale: true,
              showscale: false,
              type: 'histogram2dcontour',
            },
          ],
          layout: {
            ...obj.layout,
            showlegend: false,
            hovermode: 'closest',
            bargap: 0,
            ...tmpDensityRange,
          },
        };
      }
      break;

    case 'bubble chart':
      if (Object.keys(obj).length === 0) {
        obj = {
          data: [
            {
              x: x,
              y: y,
              mode: 'markers',
              marker: {
                color: 'rgb(93, 164, 214)',
                size: z,
              },
            },
          ],
          layout: {
            title: title,
            font: {
              family: "Saira, 'Nunito Sans'",
            },
            ...tmpRange,
          },
        };
      } else {
        obj = {
          ...obj,
          data: [
            ...obj.data,
            {
              x: x,
              y: y,
              mode: 'markers',
              marker: {
                color: 'rgb(93, 164, 214)',
                size: z,
              },
            },
          ],
        };
      }
      break;
  }

  return obj;
};

export const createGraphProp = (type, x, y, z, title, range) => {
  let tmpGraphProp = {};

  if (Array.isArray(type)) {
    type.map((v) => {
      tmpGraphProp = createPropData(tmpGraphProp, v, x, y, z, title, range);
    });
  } else {
    tmpGraphProp = createPropData(tmpGraphProp, type, x, y, z, title, range);
  }

  return tmpGraphProp;
};
