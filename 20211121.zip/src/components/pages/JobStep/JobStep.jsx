import React, { useEffect, useState } from 'react';
import { css } from '@emotion/react';
import Button2 from '../../UI/atoms/Button';
import Divider from '../../UI/atoms/Divider';
import { Button, notification, Popconfirm, Spin, Steps } from 'antd';
import {
  MSG_CANCEL,
  MSG_CONFIRM_CANCEL,
  MSG_FINISHED,
  MSG_LOCAL,
  MSG_NEXT,
  MSG_PREVIEW,
  MSG_PREVIOUS,
  MSG_PROGRESS,
  MSG_REMOTE,
  MSG_SAVE_SETTING,
  MSG_SQL,
  MSG_WAITING,
} from '../../../lib/api/Define/Message';
import {
  LeftCircleFilled,
  ReadFilled,
  RightCircleFilled,
  WarningOutlined,
  LineChartOutlined,
} from '@ant-design/icons';
import {
  getFormdataFiles,
  getParseJsonData,
  sortArrayOfObjects,
} from '../../../lib/util/Util';
import StepSetting from './StepSetting';
import {
  MAIN,
  URL_PREVIEW_CONVERTED,
  URL_RESOURCE_SCRIPT,
} from '../../../lib/api/Define/URL';
import {
  getRequest,
  getRequestParam,
  postRequestFormData,
  postRequestJsonData,
} from '../../../lib/api/axios/requests';
import {
  E_STEP_1,
  E_STEP_2,
  E_STEP_3,
  E_STEP_4,
  E_STEP_5,
  E_STEP_6,
  E_STEP_ANALYSIS,
  RESPONSE_OK,
} from '../../../lib/api/Define/etc';
import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import { useHistory, useParams } from 'react-router';

const { Step } = Steps;
import { JobStepConf as steps } from '../../../hooks/useJobStepInfo';
import Step1_Setting from './Step1_Setting';
import Step2_Setting from './Step2_Setting';
import { QUERY_KEY } from '../../../lib/api/Define/QueryKey';
import { useQueryClient } from 'react-query';
import GraphAddEdit from '../../UI/organisms/GraphAddEdit/GraphAddEdit';
import Step5_Setting from './Step5_Setting';
import Step3_Setting from './Step3_Setting';
import { createGraphItems } from '../JobAnalysis/functionGroup';

const TABLE_MAX_ROWS = 5;
const MenuBarWrapper = css`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
`;
const MenuButton = css`
  font-weight: 400;
  margin-left: 8px;
`;
const bodyFrame = css`
  background: #ffffff;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 1px;

  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 12px;
  margin: 15px 0px;
`;

const dividerStyle = css`
  display: flex;
  border: 2px solid #8c8c8c;
`;
const StepFrameStyle = css`
  display: contents;
  justify-content: space-between;
  align-items: center;
`;

const directionButton = css`
  font-weight: 400;
  margin-left: 8px;
  box-sizing: border-box;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 8px;
`;
const TitleFrameStyle = css`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;

  flex: none;
  order: 2;
  align-self: stretch;
  flex-grow: 0;

  margin-top: 10px;
  margin-bottom: 10px;
`;
const ContentsFrameStyle = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 0px 4px 4px;

  flex: none;
  order: 2;
  align-self: stretch;
  flex-grow: 0;
  margin: 12px 0px;
  & .ant-form-item-label {
    text-align: left;
    max-width: 130px;
  }
`;

const PreviewFrameStyle = css`
  background: #fafafa;
  display: flex;
  flex-direction: column;

  flex: none;
  order: 3;
  align-self: stretch;
  flex-grow: 0;

  border: 1px solid #d9d9d9;
  box-sizing: border-box;
  border-radius: 8px;

  min-height: 300px;
`;
const PreviewTitleStyle = css`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-height: 32px;
  align-items: center;
  margin: 10px 10px 0px 10px;
  padding: 0px 10px 0px 10px;
`;
const graphFrameStyle = css`
  background-color: white;
  margin: 0;
  padding: 1rem;
  border-radius: 8px;
  min-height: 300px;
`;
const getTableForm = (info) => {
  const { disp_order, row } = info;
  const header_data = disp_order.map((item) => ({
    ['title']: item,
    ['dataIndex']: `data_${item}`,
    ['key']: `data_${item}`,
  }));
  const row_data = Object.entries(row ?? [])
    .map((item, i) => {
      const obj = { ['key']: `${i}` };
      Object.entries(item[1]).map(([idx, value]) => {
        Object.assign(obj, { [`data_${idx}`]: value });
      });
      return obj;
    })
    .filter((_, idx) => idx < TABLE_MAX_ROWS);
  return { columns: header_data, dataSource: row_data };
};

const getArray = (list, col_idx) => {
  return list.map((obj, idx) => {
    const tmp = Object.assign(
      {},
      obj,
      col_idx ? { index: idx, col_index: idx + 1 } : { index: idx },
    );
    delete tmp['key'];
    delete tmp['rec_type'];
    delete tmp['output_column_val'];
    return tmp;
  });
};
const getArray2 = (list) => {
  return list.map((obj, idx) => {
    const tmp = Object.assign({}, obj, { disp_order: idx });
    delete tmp['key'];
    return tmp;
  });
};

const openNotificationWithIcon = (type, msg) => {
  console.log('[openNotificationWithIcon] msg', msg);
  notification[type]({
    message: 'ERROR',
    description: msg,
    duration: 0,
    icon: <WarningOutlined style={{ color: '#ff4d4f' }} />,
  });
};

const notificationWrapper = css`
  & > p:not(:first-of-type) {
    margin-bottom: 0;
  }
  & > p:first-of-type {
    font-weight: bold;
  }
  & > p > span {
    color: #1890ff;
    font-weight: bold;
    margin-right: 0.5rem;
  }
`;

const TableErrorMsg = (info) => {
  const table = Object.keys(info.err);
  const idx = table.findIndex((item) => info.err[item].length !== 0);
  const contents = info.err[table[idx]][0];
  const columnName = contents.msg[0].key;
  const errMsg = `[${contents.msg[0].name}]: ${contents.msg[0].reason}`;
  return (
    <div css={notificationWrapper}>
      <p>[{table[idx]} Columns ] SETTING ERROR</p>
      <p>
        <span>Index:</span> {contents.index + 1}
      </p>
      <p>
        <span>Columns:</span> {columnName}
      </p>
      <p>
        <span>ErrorMsg:</span> {errMsg}
      </p>
    </div>
  );
};
const JobStep = () => {
  const [current, setCurrent] = useState(0);
  const [data, setData] = useState(null);
  const [isEditMode, setEditMode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const history = useHistory();
  let { func_id, category_id } = useParams();
  const {
    initialRuleSetting,
    updateFuncInfo,
    updateConvertInfo,
    updateAnalysisInfo,
    updateFilterInfo,
    updateVisualInfo,
  } = useRuleSettingInfo();
  const {
    setRuleStepConfig,
    ruleStepConfig,
    convertStepInfo,
    filterStepInfo,
    analysisStepInfo,
    funcStepInfo,
    visualStepInfo,
  } = useRuleSettingInfo();
  const queryClient = useQueryClient();

  useEffect(() => {
    console.log('===============JobStep2===============');
    return () => {
      initialRuleSetting();
    };
  }, []);

  useEffect(() => {
    const initialData = async () => {
      if (func_id ?? false) {
        try {
          const { info, status } = await getRequestParam(
            steps[current].edit_init,
            func_id,
          );
          if (status.toString() === RESPONSE_OK) {
            console.log('info', info);
            updateFuncInfo(info);
            setRuleStepConfig([
              ...ruleStepConfig,
              { step: current, config: info },
            ]);
          }
        } catch (e) {
          if (e.response) {
            const {
              data: { msg },
            } = e.response;
            console.log(e.response);
            openNotificationWithIcon('error', msg);
          }
        }
      }
    };
    if (func_id !== undefined) {
      console.log('func_id', func_id);
      setEditMode(true);
      initialData().then(console.log('================================='));
    }
  }, [func_id]);

  useEffect(() => {
    const initialData = async () => {
      if (category_id ?? false) {
        try {
          const { info, status } = await getRequest(steps[current].new_init);
          if (status.toString() === RESPONSE_OK) {
            console.log('category_id', category_id);
            const { category } = info;
            if (category?.selected === undefined) {
              const Obj = {
                category: {
                  options: category.options,
                  selected: category_id,
                },
                title: info?.title ?? '',
                source_type: funcStepInfo.source_type,
              };
              updateFuncInfo(Obj);
              setRuleStepConfig([
                ...ruleStepConfig,
                { step: current, config: Obj },
              ]);
            } else {
              updateFuncInfo(info);
              setRuleStepConfig([
                ...ruleStepConfig,
                { step: current, config: info },
              ]);
            }
          }
        } catch (e) {
          if (e.response) {
            const {
              data: { msg },
            } = e.response;
            console.log(e.response);
            openNotificationWithIcon('error', msg);
          }
        }
      }
    };
    if (category_id !== undefined) {
      console.log('category_id', category_id);
      initialData().then(console.log('================================='));
    }
  }, [category_id]);

  const saveSetting = () => {
    {
      console.log('saveSetting start');
      const postRequest = async () => {
        const convertTmp = { ...convertStepInfo };
        const analysisTmp = { ...analysisStepInfo };
        const filterTmp = [...filterStepInfo];
        const visualTmp = { ...visualStepInfo };
        const funcTemp = { ...funcStepInfo };
        const rule_id = isEditMode
          ? convertStepInfo?.log_define?.rule_id ?? undefined
          : undefined;
        console.log('rule_id', rule_id);

        const obj = Object.assign(
          {},
          {
            func: {
              category_id: funcTemp.category.selected,
              title: funcTemp.title,
              source_type: funcTemp.source_type,
              info:
                funcTemp.source_type === MSG_REMOTE
                  ? {
                      db_id: funcTemp.info.db_id,
                      table_name: funcTemp.info.table_name,
                      equipment_name: funcTemp.info.equipment_name,
                      period_start: funcTemp.info.period_start,
                      period_end: funcTemp.info.period_end,
                    }
                  : funcTemp.source_type === MSG_SQL
                  ? {
                      db_id: funcTemp.info.db_id,
                      sql: funcTemp.info.sql,
                    }
                  : {},
              script: {
                file_name: funcTemp?.script?.file_name ?? null,
                use_script: funcTemp?.script?.use_script ?? false,
              },
            },
            convert: {
              mode: convertStepInfo.mode,
              log_define: convertStepInfo?.log_define,
              info: getArray(convertTmp?.info ?? [], true),
              header: getArray(convertTmp?.header ?? [], true),
              custom: getArray(convertTmp?.custom ?? [], false),
              script: {
                file_name: convertTmp?.script?.file_name ?? null,
                use_script: convertTmp?.script?.use_script ?? false,
              },
            },
            filter: {
              items: getArray(filterTmp, false),
            },
            analysis: {
              type: analysisTmp?.type ?? 'setting',
              setting: {
                items: getArray2(analysisTmp.items) ?? [],
                filter_default: analysisTmp.filter_default ?? [],
                aggregation_default: analysisTmp.aggregation_default ?? {},
              },
              script: {
                db_id: analysisTmp?.script?.db_id ?? null,
                sql: analysisTmp?.script?.sql ?? null,
                file_name: analysisTmp?.script?.file_name ?? null,
                use_script: analysisTmp?.script?.use_script ?? false,
              },
            },
            visualization: {
              function_graph_type: visualTmp.function_graph_type,
              items: visualTmp.items.map((v) => {
                return {
                  id: v.id,
                  title: v.title,
                  type: v.type,
                  x_axis: v.x_axis,
                  y_axis: v.y_axis,
                  z_axis: v.z_axis,
                  x_range_min: v.x_range_min,
                  x_range_max: v.x_range_max,
                  y_range_min: v.y_range_min,
                  y_range_max: v.y_range_max,
                  z_range_min: v.z_range_min,
                  z_range_max: v.z_range_max,
                };
              }),
            },
          },
        );
        try {
          console.log('isEditMode', isEditMode);
          const url = isEditMode
            ? steps[current].edit_save
            : steps[current].new_save;
          const { status, info } = await postRequestJsonData(
            isEditMode ? `${url}/${func_id}` : url,
            undefined,
            JSON.stringify(obj),
          );
          if (status.toString() === RESPONSE_OK) {
            console.log('info', info);
            const param = getParseJsonData({
              analysis:
                analysisTmp?.script?.file_name ?? false
                  ? getFormdataFiles(data?.step5_script ?? null)
                  : null,
              convert:
                convertTmp?.script?.file_name ?? false
                  ? getFormdataFiles(data?.step3_script ?? null)
                  : null,
              preprocess:
                funcTemp?.script?.file_name ?? false
                  ? getFormdataFiles(data?.step2_script ?? null)
                  : null,
            }).filter((obj) => obj.value !== null);
            const FormObj = new FormData();
            if (param.length > 0) {
              param.map((obj) => FormObj.append(obj.id, obj.value));
              const {
                info: info2,
                status: status2,
              } = await postRequestFormData(
                `${URL_RESOURCE_SCRIPT}/${info.func_id}`,
                FormObj,
              );
              if (status2.toString() === RESPONSE_OK) {
                console.log('info2: ', info2);
                queryClient.invalidateQueries([QUERY_KEY.MAIN_INIT]);

                history.push({
                  pathname: MAIN,
                });
                setLoading(false);
              }
            } else {
              queryClient.invalidateQueries([QUERY_KEY.MAIN_INIT]);

              history.push({
                pathname: MAIN,
              });
              setLoading(false);
            }
          }
        } catch (e) {
          if (e.response) {
            const {
              data: { msg, err },
            } = e.response;
            console.log(e.response);
            if (msg !== undefined) {
              openNotificationWithIcon('error', msg);
            } else if (err !== undefined) {
              if (typeof err === 'object') {
                openNotificationWithIcon(
                  'error',
                  TableErrorMsg(e.response.data),
                );
              } else {
                openNotificationWithIcon('error', err);
              }
            }
          }
          setLoading(false);
        }
      };
      setLoading(true);
      postRequest().then(console.log('================================='));
    }
  };
  const getEditParam = () => {
    let ret = '';
    switch (current) {
      case E_STEP_1:
        ret = `${func_id}`;
        break;
      case E_STEP_2:
        console.log('func_id', func_id);
        console.log(
          'convertStepInfo.log_define.log_name',
          convertStepInfo.log_define.log_name,
        );
        console.log('data?.new_rule', data?.new_rule);
        console.log(
          'convertStepInfo?.log_define?.rule_id',
          convertStepInfo?.log_define?.rule_id,
        );
        ret = `${func_id}/${convertStepInfo.log_define.log_name}`;
        if ((data?.new_rule ?? true) === false) {
          ret += `/${convertStepInfo?.log_define?.rule_id}`;
        }
        break;
      default:
        break;
    }
    return ret;
  };

  const nextButton = () => {
    console.log('nextButton');
    const nextRequest = async () => {
      const EditParam = getEditParam();
      try {
        const { info, status } = isEditMode
          ? await getRequestParam(steps[current].edit, EditParam)
          : current > E_STEP_1 &&
            (convertStepInfo?.log_define?.log_name ?? false)
          ? await getRequestParam(
              steps[current].new,
              convertStepInfo.log_define.log_name,
            )
          : await getRequest(steps[current].new);
        if (status.toString() === RESPONSE_OK) {
          if (updateEditSetting(info)) {
            const clone = [...ruleStepConfig];
            const obj = { step: current + 1, config: info };

            const existIdx = ruleStepConfig.findIndex(
              (obj) => obj.step === current + 1,
            );
            if (existIdx !== -1) {
              setRuleStepConfig(
                clone.map((i, j) =>
                  j === existIdx ? Object.assign({}, i, { config: info }) : i,
                ),
              );
            } else {
              setRuleStepConfig([...clone, obj]);
            }
            setCurrent(current + 1);
          }
        }
      } catch (e) {
        if (e.response) {
          const {
            data: { msg },
          } = e.response;
          console.log(e.response);
          openNotificationWithIcon('error', msg);
        }
      }
      setLoading(false);
    };
    const preAnalysisRequest = async (nextStep) => {
      const LogFileStep = ruleStepConfig.find((item) => item.step === E_STEP_2);
      const obj = {
        data: LogFileStep?.data ?? {},
        log_name: data?.log_name ?? '',
      };
      try {
        const { info, status } = await postRequestJsonData(
          URL_PREVIEW_CONVERTED,
          undefined,
          JSON.stringify(obj),
        );
        if (status.toString() === RESPONSE_OK) {
          if (info.result === true) {
            const tableData = getTableForm(info.data);
            setData((prevState) => ({
              ...prevState,
              ['filter_header']: tableData.columns,
              ['filter_data']: tableData.dataSource,
              ['filter_error']: undefined,
            }));
            storeStepConfig(
              current,
              Object.assign(
                {},
                info.data,
                info?.analysis ?? {},
                info?.visualization ?? {},
              ),
              E_STEP_4,
            );
            setCurrent(nextStep);
          } else {
            openNotificationWithIcon('error', info.err);
          }
        }
      } catch (e) {
        if (e.response) {
          const { data } = e.response;
          openNotificationWithIcon('error', data.msg);
        }
      }
      setLoading(false);
    };

    if (nextStepValid()) {
      const result = jumpToStep('next', current);
      console.log('result', result);
      switch (result.status) {
        case 'false':
          if (steps[current].new !== undefined) {
            setLoading(true);
            nextRequest().then(
              console.log('================================='),
            );
          } else {
            setCurrent(current + 1);
          }
          break;
        case 'pass':
          setCurrent(result.step);
          setData((prevState) => ({
            ...prevState,
            ['filter_header']: data.log_header,
            ['filter_data']: data.log_data,
          }));
          break;
        case 'confirm':
          setLoading(true);
          preAnalysisRequest(result.step).then(
            console.log('================================='),
          );
          break;
        default:
          break;
      }
    }
  };

  const nextStepValid = () => {
    let ret = true;
    switch (current) {
      case E_STEP_1:
        ret = Step1_Setting.next();
        break;
      case E_STEP_2:
        ret = Step2_Setting.next(convertStepInfo);
        break;
      case E_STEP_3:
        ret = Step3_Setting.check_next(convertStepInfo);
        break;
      case E_STEP_5:
        ret = Step5_Setting.check_next(analysisStepInfo);
        break;
      default:
        break;
    }
    return ret;
  };
  const onChange = (e) => {
    console.log('[jobStep ]', e);
    setData((prev) => {
      return { ...prev, ...e };
    });
  };
  const jumpToStep = (type, step) => {
    let ret = { step: 0, status: 'false' };
    if (step === E_STEP_2 && type === 'next') {
      const { source_type } = funcStepInfo;
      if (source_type === MSG_REMOTE || source_type === MSG_SQL) {
        ret.step = E_STEP_ANALYSIS;
        ret.status = 'pass';
      }
    } else if (step === E_STEP_5 && type === 'previous') {
      return Step5_Setting.btn_previous(funcStepInfo);
    }
    return ret;
  };
  const storeStepConfig = (current, info, step) => {
    const existIdx = ruleStepConfig.findIndex(
      (obj) => obj.step === step ?? current,
    );
    const cloneStep = ruleStepConfig.slice();
    if (existIdx !== -1) {
      cloneStep.splice(
        existIdx,
        1,
        Object.assign({}, ruleStepConfig[existIdx], {
          data: info,
        }),
      );
    } else {
      cloneStep.push({ step: step ?? current, data: info });
    }
    setRuleStepConfig(cloneStep);
  };
  const previewBtn = () => {
    let ret = true;
    if (steps[current].preview === undefined) {
      ret = false;
    }
    if (current === E_STEP_1) {
      ret = false;
    }
    if (current === E_STEP_2) {
      ret =
        funcStepInfo.source_type === MSG_LOCAL ?? true
          ? Boolean(data.uploadedFile && (data?.src_file ?? false))
          : true;
    }
    if (current === E_STEP_5) {
      ret = Step5_Setting.check_preview(analysisStepInfo);
    }
    return ret;
  };
  const updateEditSetting = (info) => {
    if (current === E_STEP_2) {
      console.log('setting update START1');
      if (info?.convert?.log_define ?? false) {
        console.log('update convert ');
        updateConvertInfo({
          ...convertStepInfo,
          log_define: {
            ...convertStepInfo.log_define,
            ...info?.convert?.log_define,
          },
          info:
            sortArrayOfObjects(info?.convert?.info ?? [], 'col_index').map(
              (obj, index) => {
                return {
                  ...obj,
                  key: index + 1,
                  rec_type: 'DB',
                  output_column_val: obj?.output_column ?? '',
                };
              },
            ) ?? [],
          header:
            sortArrayOfObjects(info?.convert?.header ?? [], 'col_index').map(
              (obj, index) => {
                return {
                  ...obj,
                  key: index + 1,
                  rec_type: 'DB',
                  output_column_val: obj?.output_column ?? '',
                };
              },
            ) ?? [],
          custom:
            info?.convert?.custom?.map((obj, index) => {
              return {
                ...obj,
                key: index + 1,
                rec_type: 'DB',
                output_column_val: obj?.output_column ?? '',
              };
            }) ?? [],
        });
      }
      console.log('update convert completed');

      if (
        (info?.analysis?.filter_default ||
          info?.analysis?.aggregation_default) ??
        false
      ) {
        console.log('update analysis ');

        updateAnalysisInfo({
          ...analysisStepInfo,
          filter_default: info?.analysis?.filter_default,
          aggregation_default: info?.analysis?.aggregation_default,
          items: info?.analysis?.items.map((obj, index) => {
            return { ...obj, key: index + 1 };
          }),
        });
      }
      console.log('update analysis completed');

      if (info?.filter?.items ?? false) {
        console.log('update filter ');
        updateFilterInfo(
          info?.filter?.items.map((obj, index) => {
            return {
              ...obj,
              key: index + 1,
            };
          }) ?? [],
        );
      }
      console.log('update filter completed');

      if (info?.visualization ?? false) {
        console.log('update visualization ');
        createGraphItems(info.visualization, updateVisualInfo);
        console.log('update visualization completed');
      }
    }
    return true;
  };
  const PreviousOnClick = () => {
    console.log('steps[current].Previous');
    const result = jumpToStep('previous', current);
    if (result.status === 'pass') {
      setCurrent(result.step);
    } else {
      setCurrent(current - 1);
    }
  };
  const previewOnClick = () => {
    console.log('steps[current].preview', steps[current].preview);
    switch (current) {
      case E_STEP_2:
        {
          const source = funcStepInfo.source_type;
          const postRequest = async () => {
            const originLogData = data?.src_file ?? null;

            if (source === MSG_LOCAL && !!originLogData === false) {
              console.log('file is empty');
            } else {
              try {
                const param = getParseJsonData(
                  source === MSG_REMOTE
                    ? {
                        source: funcStepInfo.source_type,
                        equipment_name: funcStepInfo.info.equipment_name,
                        table_name: funcStepInfo.info.table_name,
                        db_id: funcStepInfo.info.db_id,
                        start: funcStepInfo.info.period_start,
                        end: funcStepInfo.info.period_end,
                        func_id: func_id ?? null,
                        script_file: getFormdataFiles(
                          data?.step2_script ?? null,
                        ),
                        use_script: funcStepInfo?.script?.use_script ?? false,
                      }
                    : source === MSG_LOCAL
                    ? {
                        source: funcStepInfo.source_type,
                        use_script: funcStepInfo?.script?.use_script ?? false,
                        func_id: func_id ?? null,
                        files: getFormdataFiles(data?.src_file ?? null),
                        script_file: getFormdataFiles(
                          data?.step2_script ?? null,
                        ),
                      }
                    : source === MSG_SQL
                    ? {
                        source: funcStepInfo.source_type,
                        db_id: funcStepInfo.info.db_id,
                        sql: funcStepInfo.info.sql,
                        use_script: funcStepInfo?.script?.use_script ?? false,
                        func_id: func_id ?? null,
                        script_file: getFormdataFiles(
                          data?.step2_script ?? null,
                        ),
                      }
                    : {},
                ).filter((obj) => obj.value !== null);
                const FormObj = new FormData();
                param.map((obj) => FormObj.append(obj.id, obj.value));
                const { info, status } = await postRequestFormData(
                  steps[current].preview,
                  FormObj,
                );
                if (status.toString() === RESPONSE_OK) {
                  if (info.result) {
                    const tableData = getTableForm(info.data);
                    if (source === MSG_SQL || source === MSG_REMOTE) {
                      setData((prevState) => ({
                        ...prevState,
                        ['log_header']: tableData.columns,
                        ['log_data']: tableData.dataSource,
                        ['log_error']: undefined,
                        ['filter_header']: tableData.columns,
                        ['filter_data']: tableData.dataSource,
                        ['filter_error']: undefined,
                      }));
                      if (info.visualization) {
                        createGraphItems(info.visualization, updateVisualInfo);
                      }
                      storeStepConfig(current, info.data, current);
                      storeStepConfig(
                        current,
                        Object.assign(
                          {},
                          info.data,
                          info?.analysis ?? {},
                          info?.visualization ?? {},
                        ),
                        E_STEP_4,
                      );
                    } else {
                      setData((prevState) => ({
                        ...prevState,
                        ['log_header']: tableData.columns,
                        ['log_data']: tableData.dataSource,
                        ['log_error']: undefined,
                      }));
                      storeStepConfig(current, info.data, current);
                    }
                  } else {
                    openNotificationWithIcon('error', info.err);
                  }
                }
              } catch (e) {
                if (e.response) {
                  const {
                    data: { msg },
                  } = e.response;
                  console.log(e.response);
                  openNotificationWithIcon('error', msg);
                }
              }
            }
          };
          postRequest().then(console.log('================================='));
        }
        break;
      case E_STEP_3:
        {
          const postRequest = async () => {
            const convertTmp = { ...convertStepInfo };
            const LogFileStep = ruleStepConfig.find(
              (item) => item.step === E_STEP_2,
            );
            const getArray = (list, col_idx) => {
              return list.map((obj, idx) => {
                const tmp = Object.assign(
                  {},
                  obj,
                  col_idx ? { index: idx, col_index: idx + 1 } : { index: idx },
                );
                delete tmp['key'];
                delete tmp['rec_type'];
                delete tmp['output_column_val'];
                return tmp;
              });
            };
            const infoArr = getArray(convertTmp?.info ?? [], true);
            const customArr = getArray(convertTmp?.custom ?? [], false);
            const headerArr = getArray(convertTmp?.header ?? [], true);
            const originLog = LogFileStep['data'];
            console.log('infoArr', infoArr);
            console.log('customArr', customArr);
            console.log('headerArr', headerArr);
            console.log('originLog', originLog);

            {
              const obj = Object.assign(
                {},
                {
                  data: originLog ?? [],
                  convert: {
                    log_define:
                      convertStepInfo.mode === 'empty'
                        ? {
                            log_name: convertStepInfo.log_define.log_name,
                            table_name: convertStepInfo.log_define.table_name,
                          }
                        : {
                            log_name: convertStepInfo.log_define.log_name,
                            table_name: convertStepInfo.log_define.table_name,
                            rule_name: convertStepInfo.log_define.rule_name,
                          },
                    info: infoArr ?? [],
                    header: headerArr ?? [],
                    custom: customArr ?? [],
                  },
                },
              );
              const reqestObj = getParseJsonData({
                json_data: new Blob([JSON.stringify(obj)], {
                  type: 'application/json',
                }),
                script_file: getFormdataFiles(data?.step3_script ?? null),
                use_script: convertStepInfo?.script?.use_script ?? false,
              }).filter((obj) => obj.value !== null);
              const FormObj = new FormData();
              reqestObj.map((obj) => FormObj.append(obj.id, obj.value));
              try {
                const { info, status } = await postRequestFormData(
                  convertStepInfo.mode !== 'empty'
                    ? steps[current].preview
                    : URL_PREVIEW_CONVERTED,
                  FormObj,
                );
                console.log('info', info);
                console.log('status', status);
                if (status.toString() === RESPONSE_OK) {
                  if (info.result === true) {
                    const tableData = getTableForm(info.data);
                    setData((prevState) => ({
                      ...prevState,
                      ['convert_header']: tableData.columns,
                      ['convert_data']: tableData.dataSource,
                      ['convert_error']: undefined,
                    }));
                    storeStepConfig(current, info.data, current);
                  } else {
                    console.log('info.result === false');
                    if (typeof info.err === 'object') {
                      openNotificationWithIcon('error', TableErrorMsg(info));
                    } else {
                      openNotificationWithIcon('error', info.err);
                    }
                  }
                }
              } catch (e) {
                if (e.response) {
                  const {
                    data: { msg },
                  } = e.response;
                  console.log(e.response);
                  openNotificationWithIcon('error', msg);
                }
              }
            }
          };
          postRequest().then(console.log('================================='));
        }
        break;
      case E_STEP_4:
        {
          const postRequest = async () => {
            const filterTmp = [...filterStepInfo];
            const getArray = (list) => {
              return list.map((obj, idx) => {
                const tmp = Object.assign({}, obj, { index: idx });
                delete tmp['key'];
                return tmp;
              });
            };
            const LogFileStep = ruleStepConfig.find(
              (item) => item.step === E_STEP_3,
            );
            const filterArr = getArray(filterTmp);
            const originLog = LogFileStep['data'];

            if (originLog === undefined || originLog === null) {
              console.log('data is empty');
            } else {
              const obj = Object.assign(
                {},
                {
                  data: {
                    row: originLog.row,
                    disp_order: originLog.disp_order,
                  },
                  filter: { items: filterArr },
                },
              );
              try {
                const { info, status } = await postRequestJsonData(
                  steps[current].preview,
                  undefined,
                  JSON.stringify(obj),
                );
                if (status.toString() === RESPONSE_OK) {
                  if (info.result === true) {
                    const tableData = getTableForm(info.data);
                    setData((prevState) => ({
                      ...prevState,
                      ['filter_header']: tableData.columns,
                      ['filter_data']: tableData.dataSource,
                      ['filter_error']: undefined,
                    }));
                    storeStepConfig(current, info.data, current);
                  } else {
                    if (typeof info.err === 'object') {
                      openNotificationWithIcon('error', TableErrorMsg(info));
                    } else {
                      openNotificationWithIcon('error', info.err);
                    }
                  }
                }
              } catch (e) {
                if (e.response) {
                  const { data } = e.response;
                  openNotificationWithIcon('error', data.msg);
                  setData((prevState) => ({
                    ...prevState,
                    ['filter_error']: data.msg,
                    ['filter_header']: undefined,
                    ['filter_data']: undefined,
                  }));
                }
              }
            }
          };
          postRequest().then(console.log('================================='));
        }
        break;

      case E_STEP_5:
        {
          const postRequest = async () => {
            const analysisTmp = { ...analysisStepInfo };
            const getArray = (list) => {
              return list.map((obj, idx) => {
                const tmp = Object.assign({}, obj, { disp_order: idx });
                delete tmp['key'];
                return tmp;
              });
            };
            const LogFileStep = ruleStepConfig.find(
              (item) => item.step === E_STEP_4,
            );
            const originLog = LogFileStep['data'];
            const { items, filter_default, aggregation_default } = analysisTmp;

            if (originLog === undefined || originLog === null) {
              console.log('data is empty');
            } else {
              const obj = Object.assign(
                {},
                {
                  data: {
                    row: originLog.row,
                    disp_order: originLog.disp_order,
                  },
                  analysis:
                    (analysisStepInfo?.type ?? 'setting') === 'setting'
                      ? {
                          type: 'setting',
                          items: items === undefined ? [] : getArray(items),
                          filter_default:
                            filter_default === undefined ? [] : filter_default,
                          aggregation_default:
                            aggregation_default === undefined
                              ? {}
                              : aggregation_default,
                        }
                      : (analysisStepInfo?.type ?? 'setting') === 'script'
                      ? {
                          type: 'script',
                          script: {
                            db_id: analysisStepInfo.script.db_id,
                            sql: analysisStepInfo.script.sql,
                            file_name: analysisStepInfo.script.file_name,
                            use_script: analysisStepInfo.script.use_script,
                          },
                        }
                      : {
                          type: 'none',
                          filter_default:
                            filter_default === undefined ? [] : filter_default,
                        },
                },
              );
              try {
                const reqestObj = getParseJsonData({
                  json_data: new Blob([JSON.stringify(obj)], {
                    type: 'application/json',
                  }),
                  script_file: getFormdataFiles(data?.step5_script ?? null),
                  use_script: analysisStepInfo?.script?.use_script ?? false,
                }).filter((obj) => obj.value !== null);
                const FormObj = new FormData();
                reqestObj.map((obj) => FormObj.append(obj.id, obj.value));

                const { info, status } = await postRequestFormData(
                  steps[current].preview,
                  FormObj,
                );
                console.log('info', info);
                console.log('status', status);
                if (status.toString() === RESPONSE_OK) {
                  if (info.result === true || info.result === undefined) {
                    const tableData = getTableForm(info.data);
                    console.log('info', info);
                    setData((prevState) => ({
                      ...prevState,
                      ['analysis_header']: tableData.columns,
                      ['analysis_data']: tableData.dataSource,
                      ['analysis_error']: undefined,
                    }));
                    storeStepConfig(current, info.data, current);
                  } else {
                    openNotificationWithIcon(info.err);
                  }
                }
              } catch (e) {
                if (e.response) {
                  const { data } = e.response;
                  openNotificationWithIcon('error', data.msg);
                  setData((prevState) => ({
                    ...prevState,
                    ['analysis_error']: data.msg,
                    ['analysis_header']: undefined,
                    ['analysis_data']: undefined,
                  }));
                }
              }
            }
          };
          postRequest().then(console.log('================================='));
        }
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    console.log('UseEffect DATA', data);
  }, [data]);

  return (
    <>
      <div>
        <div css={MenuBarWrapper}>
          <Spin spinning={loading && current === E_STEP_6} tip="Applying...">
            <Popconfirm
              title={MSG_CONFIRM_CANCEL}
              onConfirm={() => history.goBack()}
            >
              <Button2 theme={'white'} style={MenuButton}>
                {MSG_CANCEL}
              </Button2>
            </Popconfirm>
            <Button2
              theme={'blue'}
              disabled={current !== E_STEP_6}
              style={MenuButton}
              onClick={saveSetting}
            >
              {MSG_SAVE_SETTING}
            </Button2>
          </Spin>
        </div>
        <div css={bodyFrame}>
          <Divider style={dividerStyle} />
          <div css={StepFrameStyle}>
            <Steps current={current} css={{ marginTop: '10px' }}>
              {steps.map((item, idx) => {
                return (
                  <Step
                    key={`STEP_${idx + 1}`}
                    title={
                      current === idx
                        ? MSG_PROGRESS
                        : current > idx
                        ? MSG_FINISHED
                        : MSG_WAITING
                    }
                    description={item.description}
                  />
                );
              })}
            </Steps>
          </div>
          <Divider style={dividerStyle} />
          <div css={TitleFrameStyle}>
            <Button
              type="dashed"
              css={directionButton}
              onClick={PreviousOnClick}
              disabled={current === 0}
            >
              <LeftCircleFilled /> {MSG_PREVIOUS}
            </Button>
            <div
              css={{
                textAlign: 'center',
                fontSize: '24px',
                lineHeight: '32px',
              }}
            >
              {steps[current].description}
            </div>
            <Button
              type="dashed"
              css={directionButton}
              onClick={nextButton}
              loading={loading && current !== E_STEP_6}
              disabled={!nextStepValid() || current === steps.length - 1}
            >
              {MSG_NEXT} <RightCircleFilled />
            </Button>
          </div>
          <div css={ContentsFrameStyle}>
            <StepSetting.contents
              current={current}
              data={data}
              changeFunc={(e) => onChange(e)}
            />
          </div>
          <div css={PreviewFrameStyle}>
            <div
              css={PreviewTitleStyle}
              style={{ fontWeight: '500', textTransform: 'uppercase' }}
            >
              {MSG_PREVIEW}
              {current !== E_STEP_6 ? (
                <Button
                  type="dashed"
                  icon={<ReadFilled />}
                  disabled={!previewBtn()}
                  onClick={previewOnClick}
                >
                  {MSG_PREVIEW}
                </Button>
              ) : (
                ''
              )}
              {current === E_STEP_6 &&
              ruleStepConfig.find((v) => v.step === E_STEP_5)?.data?.row ? (
                <Button
                  type="dashed"
                  icon={<LineChartOutlined />}
                  onClick={() => setIsAddOpen(true)}
                >
                  Add Graph
                </Button>
              ) : (
                ''
              )}
            </div>
            <Divider
              height={'1'}
              type={'solid'}
              style={{ marginBottom: '0' }}
            />
            <div
              css={[
                ContentsFrameStyle,
                current === E_STEP_6 ? graphFrameStyle : '',
              ]}
            >
              <StepSetting.preview current={current} data={data} />
            </div>
          </div>
        </div>
      </div>
      {current === E_STEP_6 ? (
        <GraphAddEdit closer={() => setIsAddOpen(false)} isOpen={isAddOpen} />
      ) : (
        ''
      )}
    </>
  );
};
export default JobStep;
