import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Empty, Button, Popconfirm } from 'antd';
import { css } from '@emotion/react';
import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import { SettingFilled, CloseCircleFilled } from '@ant-design/icons';
import { E_STEP_5 } from '../../../lib/api/Define/etc';
import GraphAddEdit from '../../UI/organisms/GraphAddEdit/GraphAddEdit';
import {
  graphWrapper,
  graphBodyStyle,
  emptyWrapper,
} from '../JobAnalysis/AnalysisGraph/styleGroup';
import { drawGraph } from '../JobAnalysis/AnalysisGraph/functionGroup';

const mainWrapper = css`
  font-family: saira;
  width: 100%;
`;

const ContentsForm = () => {};

const PreviewForm = () => {
  const {
    visualStepInfo,
    updateVisualInfo,
    ruleStepConfig,
  } = useRuleSettingInfo();
  const [isOpen, setIsOpen] = useState(false);
  const [currentIdx, setCurrentIdx] = useState('');

  const openEdit = (idx) => {
    setCurrentIdx(idx);
    setIsOpen(true);
  };

  const onDelete = (idx) => {
    updateVisualInfo({
      ...visualStepInfo,
      items: visualStepInfo.items.filter((v, i) => {
        return i !== idx;
      }),
    });
  };

  useEffect(() => {
    console.log('[useEffect]visualStepInfo', visualStepInfo);
    drawGraph(
      ruleStepConfig.find((v) => v.step === E_STEP_5)?.data?.row,
      visualStepInfo.items,
      visualStepInfo,
    );
  }, [visualStepInfo]);

  return (
    <>
      <div css={mainWrapper}>
        <div
          css={visualStepInfo.items.length > 0 ? graphBodyStyle : emptyWrapper}
        >
          {visualStepInfo.items.length > 0 ? (
            visualStepInfo.items.map((k, i) => {
              return (
                <div key={i} css={graphWrapper}>
                  <div>
                    <Button
                      type="dashed"
                      shape="round"
                      icon={<SettingFilled />}
                      onClick={() => openEdit(i)}
                    >
                      Edit
                    </Button>
                    <Popconfirm
                      title="Are you sure you want to delete this graph?"
                      onConfirm={() => onDelete(i)}
                    >
                      <Button
                        type="dashed"
                        shape="round"
                        icon={<CloseCircleFilled />}
                      >
                        Delete
                      </Button>
                    </Popconfirm>
                  </div>
                  <div id={`graph_${i}`} />
                </div>
              );
            })
          ) : (
            <Empty description="No graphs to display." />
          )}
        </div>
      </div>
      {ruleStepConfig.find((v) => v.step === E_STEP_5)?.data?.row ? (
        <GraphAddEdit
          closer={() => setIsOpen(false)}
          isOpen={isOpen}
          mode="edit"
          index={currentIdx}
        />
      ) : (
        ''
      )}
    </>
  );
};
PreviewForm.propTypes = {
  data: PropTypes.object,
};
const Step6_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step6_Setting.propTypes = {
  children: PropTypes.node,
};
Step6_Setting.contents = ContentsForm;
Step6_Setting.preview = PreviewForm;

export default Step6_Setting;
