import Plotly from 'plotly.js-dist';

export const drawGraph = (rows, items, ref) => {
  items.some((v, i) => {
    const currentInfo = ref.graph_list.find((z) => z.name === v.type[0]);
    const currentScript = ref.function_graph_type.find((x) => {
      return currentInfo.type === 'user'
        ? x.name === currentInfo.name
        : x.type === currentInfo.type;
    }).script;
    const newFunc = new Function('return ' + currentScript)();
    const tmpObj = {};

    if (v.y_axis.length > 0) {
      v.y_axis.reduce((acc, v) => {
        acc[v] = Object.values(rows).map((z) => {
          if (z['No.'] === undefined || z['No.'] !== 'ALL') {
            return z[v];
          }
        });
        return acc;
      }, tmpObj);
    }

    const params = {
      type: v.type,
      x:
        v.x_axis.length === 0
          ? []
          : Object.values(rows).map((z) => {
              if (z['No.'] === undefined || z['No.'] !== 'ALL') {
                return z[v.x_axis];
              }
            }),
      y: tmpObj,
      z:
        v.z_axis.length === 0
          ? []
          : Object.values(rows).map((z) => {
              if (z['No.'] === undefined || z['No.'] !== 'ALL') {
                return z[v.z_axis];
              }
            }),
      title: v.title,
      range: {
        x: v.x_range_min !== '' ? [v.x_range_min, v.x_range_max] : [],
        y: v.y_range_min !== '' ? [v.y_range_min, v.y_range_max] : [],
        z: v.z_range_min !== '' ? [v.z_range_min, v.z_range_max] : [],
      },
    };
    newFunc(Plotly, document.getElementById(`graph_${i}`), params);
  });
};
