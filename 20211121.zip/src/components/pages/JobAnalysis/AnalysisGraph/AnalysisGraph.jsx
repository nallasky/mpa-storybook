import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Button, Empty, Popconfirm } from 'antd';
import {
  CloseCircleFilled,
  LineChartOutlined,
  SettingFilled,
} from '@ant-design/icons';
import * as sg from './styleGroup';
import GraphAddEdit from '../../../UI/organisms/GraphAddEdit/GraphAddEdit';
import { drawGraph } from './functionGroup';
import useResultInfo from '../../../../hooks/useResultInfo';

const AnalysisGraph = ({ rows, info, type }) => {
  const {
    analysisGraphInfo,
    setAnalysisGraphInfo,
    originalGraphInfo,
    setOriginalGraphInfo,
    visualization,
  } = useResultInfo();
  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState('');
  const [currentIdx, setCurrentIdx] = useState('');

  const onAddGraph = () => {
    setIsOpen(true);
    setMode('add');
  }

  const onEdit = (idx) => {
    setCurrentIdx(idx);
    setMode('edit');
    setIsOpen(true);
  };

  const onDelete = (idx) => {
    if (type === 'analysis') {
      setAnalysisGraphInfo(
        analysisGraphInfo.map((v, i) => {
          return i !== idx;
        }),
      );
    } else {
      setOriginalGraphInfo(
        originalGraphInfo.map((v, i) => {
          return i !== idx;
        }),
      );
    }
  };

  useEffect(() => {
    drawGraph(
      rows,
      type === 'analysis' ? analysisGraphInfo : originalGraphInfo,
      visualization,
    );
  }, [rows, type, visualization]);

  if (Object.keys(rows).length === 0) return '';

  return (
    <>
      <div css={sg.mainWrapper}>
        <div>
          <span>Visualization</span>
          <Button
            type="dashed"
            icon={<LineChartOutlined />}
            onClick={onAddGraph}
          >
            Add Graph
          </Button>
        </div>
        <div>
          <div css={info.length > 0 ? sg.graphBodyStyle : sg.emptyWrapper}>
            {info.length > 0 ? (
              info.map((k, i) => {
                return (
                  <div key={i} css={sg.graphWrapper}>
                    <div>
                      <Button
                        type="dashed"
                        shape="round"
                        icon={<SettingFilled />}
                        onClick={() => onEdit(i)}
                      >
                        Edit
                      </Button>
                      <Popconfirm
                        title="Are you sure you want to delete this graph?"
                        onConfirm={() => onDelete(i)}
                      >
                        <Button
                          type="dashed"
                          shape="round"
                          icon={<CloseCircleFilled />}
                        >
                          Delete
                        </Button>
                      </Popconfirm>
                    </div>
                    <div id={`graph_${i}`} />
                  </div>
                );
              })
            ) : (
              <Empty description="No graphs to display." />
            )}
          </div>
        </div>
      </div>
      <GraphAddEdit
        closer={() => setIsOpen(false)}
        isOpen={isOpen}
        mode={mode}
        index={currentIdx}
        type={type}
      />
    </>
  );
};
AnalysisGraph.propTypes = {
  rows: PropTypes.object.isRequired,
  info: PropTypes.array.isRequired,
  type: PropTypes.string,
};
AnalysisGraph.defaultProps = {
  type: 'analysis',
};

export default AnalysisGraph;
