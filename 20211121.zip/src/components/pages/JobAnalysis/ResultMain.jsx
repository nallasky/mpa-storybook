import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router';
import PropTypes from 'prop-types';
import dayjs from 'dayjs';
import { Tabs, Modal, Input, Form, Breadcrumb, Spin } from 'antd';
import Button from '../../UI/atoms/Button';
import {
  SaveOutlined,
  SlidersFilled,
  CloudDownloadOutlined,
  HomeOutlined,
} from '@ant-design/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChartBar, faTable } from '@fortawesome/free-solid-svg-icons';
import * as sg from './styleGroup';
import AnalysisTable from './AnalysisTable/AnalysisTable';
import AnalysisGraph from './AnalysisGraph/AnalysisGraph';
import useResultInfo from '../../../hooks/useResultInfo';
import {
  getAnalysisOptionInfo,
  getOriginalData,
  postHistoryData,
  postRequestExport,
} from '../../../lib/api/axios/requests';
import * as fn from './functionGroup';
import { RESPONSE_OK, DATE_FORMAT } from '../../../lib/api/Define/etc';

const { TabPane } = Tabs;

const ResultMain = () => {
  const {
    func_id,
    job_id,
    job_type,
    history_id,
    equipment_name,
  } = useLocation().state;
  const {
    setAnalysisInfo,
    setOriginalInfo,
    setOriginalFilteredRows,
    setVisualization,
    analysisData,
    originalData,
    originalFilteredRows,
    analysisGraphInfo,
    originalGraphInfo,
    selectedRow,
    initializing,
  } = useResultInfo();
  const [activeTab, setActiveTab] = useState('1');
  const [loadState, setLoadState] = useState(true);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [checkTable, setCheckTable] = useState(false);
  const [checkGraph, setCheckGraph] = useState(false);
  const [isRenderGraph, setIsRenderGraph] = useState(false);
  const [isOriginal, setIsOriginal] = useState(false);
  const [historyName, setHistoryName] = useState(dayjs().format(DATE_FORMAT));

  const changeTab = (v) => {
    setActiveTab(v);
  };

  const changeLoadState = (v) => {
    setLoadState(v);
  };

  useEffect(() => {
    const fetch = async () => {
      const data = await getAnalysisOptionInfo(
        func_id,
        job_type === 'history' ? history_id : job_id,
        job_type,
      );
      setAnalysisInfo({
        period: {
          ...data.period,
          start:
            data.period.start.length > 0
              ? dayjs(data.period.start).format(DATE_FORMAT)
              : '',
          end:
            data.period.end.length > 0
              ? dayjs(data.period.end).format(DATE_FORMAT)
              : '',
        },
        filter: data.filter,
        aggregation: data.aggregation,
        dispOrder: job_type === 'history' ? data.data.disp_order : [],
        dispGraph: job_type === 'history' ? data.data.disp_graph : [],
        data: job_type === 'history' ? data.data.row : {},
      });
      fn.createGraphItems(data.visualization, setVisualization);
      if (data.analysis_type === 'none') {
        setIsOriginal(true);
      }
    };
    fetch()
      .then(() => changeLoadState(false))
      .catch((e) => {
        console.log(e);
        changeLoadState(false);
      });
    return () => {
      initializing();
      const plotlyElement = document.getElementById('js-plotly-tester');
      if (plotlyElement) {
        plotlyElement.remove();
      }
      return null;
    };
  }, []);

  const clickData = async () => {
    changeLoadState(true);
    setOriginalInfo({
      period: {},
      filter: [],
      aggregation: {},
      dispOrder: [],
      dispGraph: [],
      data: {},
    });
    setOriginalFilteredRows({});
    const dateStr =
      analysisData.period.selected.length > 0
        ? analysisData.period.selected
        : [analysisData.period.start, analysisData.period.end];
    const param = {
      fId: func_id,
      rId: job_id,
      start: dateStr[0],
      end: dateStr[1],
      agMain:
        Object.keys(analysisData.aggregation).length > 0
          ? analysisData.aggregation.selected
          : '',
      agSub:
        analysisData.aggregation.selected.indexOf('all') === -1
          ? analysisData.aggregation.subItem[analysisData.aggregation.selected]
              .selected
          : '',
      filter: analysisData.filter,
      selected: selectedRow[0] === 'all' ? [] : selectedRow,
    };

    const { data, option } = await getOriginalData(param);
    setOriginalInfo({
      period: analysisData.period,
      filter: option.filter,
      aggregation: {},
      dispOrder: data.disp_order,
      dispGraph: data.disp_graph,
      data: data.row,
    });
    setOriginalFilteredRows(data.row);
    changeLoadState(false);

    if (Object.keys(data.row).length > 0) {
      changeTab('2');
    } else {
      fn.displayNotification({
        message: 'No Data',
        description: 'There is no data to display.',
        duration: 3,
        style: { borderLeft: '5px solid green' },
      });
    }
  };

  const saveHistory = async () => {
    setHistoryOpen(false);
    setLoadState(true);
    const tmpFilter = {};
    analysisData.filter.map((v) => {
      tmpFilter[v.target] =
        v.selected === undefined || v.selected === null ? '' : v.selected;
    });
    const tmpObj = {
      func_id: func_id,
      log_from: job_type,
      title: historyName,
      period: {
        start:
          analysisData.period.selected.length === 0
            ? analysisData.period.start
            : analysisData.period.selected[0],
        end:
          analysisData.period.selected.length === 0
            ? analysisData.period.end
            : analysisData.period.selected[1],
      },
      filter: tmpFilter,
      aggregation:
        analysisData.aggregation === undefined
          ? {}
          : {
              [analysisData.aggregation.selected]:
                analysisData.aggregation.selected.indexOf('all') === -1
                  ? analysisData.aggregation.subItem[
                      analysisData.aggregation.selected
                    ].selected
                  : '',
            },
      visualization: {
        function_graph_type: [],
        items: [],
      },
    };

    if (job_type === 'local') {
      tmpObj['local'] = {
        rid: job_id,
      };
    } else {
      tmpObj['remote'] = {
        rid: job_id,
        equipment_name: equipment_name,
      };
    }

    const { status } = await postHistoryData(tmpObj);
    setLoadState(false);
    fn.displayNotification({
      message:
        status === RESPONSE_OK
          ? 'History Save Successful'
          : 'History Save Failed',
      description:
        status === RESPONSE_OK
          ? 'Successfully saved history.'
          : 'Failed to save history. Please change the name and try again.',
      duration: 3,
      style:
        status === RESPONSE_OK
          ? { borderLeft: '5px solid green' }
          : { borderLeft: '5px solid red' },
    });
  };

  const executeExport = async () => {
    setExportOpen(false);
    setLoadState(true);
    const form = new FormData();

    if (checkTable) {
      form.append(
        'files',
        new File(
          [fn.getTableData(analysisData.data, analysisData.dispOrder)],
          'analysis.table.csv',
        ),
      );
      if (Object.keys(originalData.data).length > 0) {
        form.append(
          'files',
          new File(
            [fn.getTableData(originalData.data, originalData.dispOrder)],
            'data.table.csv',
          ),
        );
      }
    }

    if (checkGraph && isRenderGraph) {
      const imgData = await fn.createGraphImage(analysisData.dispGraph);
      imgData.map((v) => {
        form.append('files', new File([v.url], v.filename));
      });
    }

    await postRequestExport(form);
    setLoadState(false);
    setCheckGraph(false);
    setCheckTable(false);
  };

  const openExport = () => {
    setIsRenderGraph(
      document.querySelectorAll('div[class^="js-plotly-plot"]').length > 0,
    );
    setExportOpen(true);
  };

  const closeExport = () => {
    setCheckTable(false);
    setCheckGraph(false);
    setExportOpen(false);
  };

  return (
    <>
      <ResultModal
        title="Save History"
        open={historyOpen}
        ok={saveHistory}
        cancel={() => setHistoryOpen(false)}
        okText="Save"
      >
        <Form.Item label="Title" style={{ marginBottom: 0 }}>
          <Input
            value={historyName}
            onChange={(e) => setHistoryName(e.target.value)}
            maxLength="32"
          />
        </Form.Item>
      </ResultModal>
      <ResultModal
        title="Export"
        open={exportOpen}
        ok={executeExport}
        cancel={() => closeExport()}
        okText="Download"
        width={400}
      >
        <div
          css={[
            sg.exportModalWrapper,
            !isRenderGraph ? { gridTemplateColumns: 'auto' } : {},
          ]}
        >
          <input
            type="checkbox"
            id="table"
            checked={checkTable}
            onChange={() => setCheckTable(!checkTable)}
          />
          <label htmlFor="table">
            <svg viewBox="0 0 21 21">
              <polyline points="5 10.75 8.5 14.25 16 6" />
            </svg>
            <FontAwesomeIcon icon={faTable} size="2x" />
            <span>Table</span>
          </label>
          {isRenderGraph ? (
            <>
              <input
                type="checkbox"
                id="graph"
                checked={checkGraph}
                onChange={() => setCheckGraph(!checkGraph)}
              />
              <label htmlFor="graph">
                <svg viewBox="0 0 21 21">
                  <polyline points="5 10.75 8.5 14.25 16 6" />
                </svg>
                <FontAwesomeIcon icon={faChartBar} size="2x" />
                <span>Graph</span>
              </label>
            </>
          ) : (
            ''
          )}
        </div>
      </ResultModal>
      <div css={sg.mainWrapper} className={loadState ? 'loading' : ''}>
        <div css={sg.breadcrumbWrapper}>
          <Breadcrumb>
            <Breadcrumb.Item>
              <HomeOutlined /> Home
            </Breadcrumb.Item>
            <Breadcrumb.Item>Analysis</Breadcrumb.Item>
          </Breadcrumb>
        </div>
        <div css={sg.buttonWrapper}>
          <Button
            theme="white"
            style={{ fontWeight: 'normal' }}
            disabled={activeTab !== '1' || selectedRow.length === 0}
            onClick={clickData}
          >
            <SlidersFilled /> Show Data
          </Button>
          <Button
            theme="white"
            style={{ fontWeight: 'normal' }}
            onClick={() => setHistoryOpen(true)}
            disabled={
              Object.keys(analysisData.data).length === 0 ||
              job_type === 'history'
            }
          >
            <SaveOutlined /> Save History
          </Button>
          <Button
            theme="white"
            style={{ fontWeight: 'normal' }}
            onClick={openExport}
            disabled={Object.keys(analysisData.data).length === 0}
          >
            <CloudDownloadOutlined /> Export
          </Button>
        </div>
        <Spin size="large" tip="Loading..." spinning={loadState}>
          <Tabs activeKey={activeTab} onChange={changeTab}>
            <TabPane tab="Analysis" key="1">
              <div css={sg.tableWrapper}>
                <AnalysisTable
                  period={analysisData.period}
                  filter={analysisData.filter}
                  aggregation={analysisData.aggregation}
                  tableData={analysisData.data}
                  tableOrder={analysisData.dispOrder}
                  type={isOriginal ? 'original' : 'analysis'}
                  onLoad={changeLoadState}
                  useUpdate
                />
                <AnalysisGraph
                  rows={analysisData.data}
                  info={analysisGraphInfo}
                />
              </div>
            </TabPane>
            {originalData.data !== undefined &&
            Object.keys(originalData.data).length > 0 ? (
              <TabPane tab="Data" key="2">
                <div css={sg.tableWrapper}>
                  <AnalysisTable
                    period={originalData.period}
                    filter={originalData.filter}
                    aggregation={originalData.aggregation}
                    tableData={originalData.data}
                    tableOrder={originalData.dispOrder}
                    type="original"
                    onLoad={changeLoadState}
                    useUpdate={false}
                  />
                  <AnalysisGraph
                    rows={originalFilteredRows}
                    info={originalGraphInfo}
                    type="original"
                  />
                </div>
              </TabPane>
            ) : (
              ''
            )}
          </Tabs>
        </Spin>
      </div>
    </>
  );
};

const ResultModal = React.memo(
  ({ title, okText, open, ok, cancel, width, children }) => {
    return (
      <Modal
        title={title}
        visible={open}
        onOk={ok}
        onCancel={cancel}
        okText={okText ? okText : 'OK'}
        style={{ fontFamily: 'saira' }}
        width={width}
      >
        {children}
      </Modal>
    );
  },
);

ResultModal.displayName = 'ResultModal';
ResultModal.propTypes = {
  title: PropTypes.string.isRequired,
  okText: PropTypes.string,
  open: PropTypes.bool.isRequired,
  ok: PropTypes.func.isRequired,
  cancel: PropTypes.func.isRequired,
  width: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  children: PropTypes.node,
};

export default ResultMain;
