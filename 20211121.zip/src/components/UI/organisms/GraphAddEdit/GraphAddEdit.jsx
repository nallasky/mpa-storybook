import React, { useRef, useState, useEffect } from 'react';
import { Form, Select, Button, Input, DatePicker } from 'antd';
import { CSSTransition } from 'react-transition-group';
import Plotly from 'plotly.js-dist';
import PropTypes from 'prop-types';
import dayjs from 'dayjs';
import * as SG from './styleGroup';
import { backgroundStyle } from '../GraphManagement/styleGroup';
import useRuleSettingInfo from '../../../../hooks/useRuleSettingInfo';
import { DATE_FORMAT, E_STEP_5 } from '../../../../lib/api/Define/etc';
import { displayNotification } from '../../../pages/JobAnalysis/functionGroup';
import useResultInfo from '../../../../hooks/useResultInfo';

const { Option } = Select;
const { Item } = Form;
const { RangePicker } = DatePicker;
const defaultErrorMsg = `
  There is a problem with the script.
  Please check the settings again.
`;
const dateRegex = /^(2[0-9][0-9][0-9])-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[01])\s(0\d|1\d|2[0-3]):([0-5]\d)(:[0-5]\d)?(\.\d{1,4})?$/;
const regex = /^[-]?(\d{0,20})(\.\d{0,20})?$/;
const titleRegex = /^([a-zA-Z])$|^([a-zA-Z])[a-zA-Z0-9_]*([a-zA-Z])$/;

const dateValidateCheck = (date) => {
  return (
    dayjs(date, DATE_FORMAT).format(DATE_FORMAT) === date ||
    dayjs(date, 'YYYY-MM-DD').format('YYYY-MM-DD') === date
  );
};

const compareErrorCheck = (min, max) => {
  if (min.toString().length === 0 && max.toString().length === 0) return false;
  const parseMin =
    typeof min === 'number'
      ? min
      : min.indexOf('.') !== -1
      ? parseFloat(min)
      : parseInt(min);
  const parseMax =
    typeof max === 'number'
      ? max
      : max.indexOf('.') !== -1
      ? parseFloat(max)
      : parseInt(max);

  return isNaN(parseMin) || isNaN(parseMax) ? true : parseMax <= parseMin;
};

const GraphAddEdit = React.memo(({ closer, isOpen, mode, index, type }) => {
  const {
    visualStepInfo,
    updateVisualInfo,
    ruleStepConfig,
  } = useRuleSettingInfo();
  const {
    visualization,
    analysisData,
    originalData,
    originalFilteredRows,
    analysisGraphInfo,
    originalGraphInfo,
    setAnalysisGraphInfo,
    setOriginalGraphInfo,
  } = useResultInfo();
  const graphArea = useRef();
  const [graphData, setGraphData] = useState({
    type: [],
    x: '0',
    y: [],
    z: '0',
  });
  const [title, setTitle] = useState('');
  const [xRange, setXrange] = useState({
    min: '',
    max: '',
  });
  const [yRange, setYrange] = useState({
    min: '',
    max: '',
  });
  const [zRange, setZrange] = useState({
    min: '',
    max: '',
  });
  const [errorMsg, setErrorMsg] = useState('');
  const [isPreview, setIsPreview] = useState(false);

  const updateRangeInfo = (e, params) => {
    let tmpX = undefined,
      tmpY = undefined;

    if (e['xaxis.range[0]'] !== undefined || e['xaxis.autorange']) {
      if (
        !dateRegex.test(params.x[0]) &&
        !dateValidateCheck(params.x[0]) &&
        isNaN(parseInt(params.x[0]))
      ) {
        tmpX = {
          min: '',
          max: '',
        };
      } else {
        if (e['xaxis.autorange']) {
          if (params.x.length > 0) {
            const isDate =
              dateRegex.test(params.x[0]) || dateValidateCheck(params.x[0]);

            if (isDate) {
              params.x.sort();
            }

            tmpX = {
              min: isDate ? dayjs(params.x[0]) : Math.min(...params.x),
              max: isDate
                ? dayjs(params.x[params.x.length - 1])
                : Math.max(...params.x),
            };
          }
        } else {
          tmpX = {
            min:
              dateRegex.test(e['xaxis.range[0]']) ||
              dateValidateCheck(e['xaxis.range[0]'])
                ? dayjs(e['xaxis.range[0]'])
                : e['xaxis.range[0]'],
            max:
              dateRegex.test(e['xaxis.range[1]']) ||
              dateValidateCheck(e['xaxis.range[1]'])
                ? dayjs(e['xaxis.range[1]'])
                : e['xaxis.range[1]'],
          };
        }
      }
    }

    if (e['yaxis.range[0]'] !== undefined || e['yaxis.autorange']) {
      if (e['yaxis.autorange']) {
        const yaxisData = [];
        Object.values(params.y).map((v) => yaxisData.push(...v));
        tmpY = {
          min: Math.min(...yaxisData),
          max: Math.max(...yaxisData),
        };
      } else {
        tmpY = {
          min: e['yaxis.range[0]'],
          max: e['yaxis.range[1]'],
        };
      }
    }

    if (tmpX) {
      setXrange(tmpX);
    }
    if (tmpY) {
      setYrange(tmpY);
    }
  };

  const renderGraph = (info, init) => {
    try {
      const graphType =
        type === 'step'
          ? visualStepInfo.function_graph_type
          : visualization.function_graph_type;
      const currentRows =
        type === 'step'
          ? ruleStepConfig.find((v) => v.step === E_STEP_5).data.row
          : type === 'analysis'
          ? analysisData.data
          : originalFilteredRows;
      const currentScript = graphType.find((v) => {
        return info.graphInfo.type === 'user'
          ? v.name === info.graphInfo.name
          : v.type.trim() === info.graphInfo.type;
      }).script;
      const renderFunc = new Function('return ' + currentScript)();
      const tmpObj = {};

      info.y.reduce((acc, v) => {
        acc[v] = Object.values(currentRows).map((z) => {
          if (v['No.'] === undefined || v['No.'] === 'ALL') {
            return z[v];
          }
        });
        return acc;
      }, tmpObj);

      const params = {
        type: info.type,
        x:
          info.x === '0'
            ? []
            : Object.values(currentRows).map((v) => {
                if (v['No.'] === undefined || v['No.'] === 'ALL') {
                  return v[info.x];
                }
              }),
        y: tmpObj,
        z:
          info.z === '0'
            ? []
            : Object.values(currentRows).map((v) => {
                if (v['No.'] === undefined || v['No.'] === 'ALL') {
                  return v[info.z];
                }
              }),
        title: info.title,
        range: {
          x: [
            typeof info.xRange.min !== 'string' &&
            typeof info.xRange.min !== 'number'
              ? dayjs(info.xRange.min).format(DATE_FORMAT)
              : info.xRange.min,
            typeof info.xRange.max !== 'string' &&
            typeof info.xRange.max !== 'number'
              ? dayjs(info.xRange.max).format(DATE_FORMAT)
              : info.xRange.max,
          ],
          y: [info.yRange.min, info.yRange.max],
          z: [info.zRange.min, info.zRange.max],
        },
        func: (e) => updateRangeInfo(e, { x: params.x, y: params.y }),
      };

      renderFunc(Plotly, graphArea.current, params);
      setErrorMsg('');
      if (!init) {
        setIsPreview(true);
      }
    } catch (e) {
      console.log('gtpark e', e);
      setErrorMsg(defaultErrorMsg);
    }
  };

  const changeGraphData = (type, v) => {
    let newData = graphData;
    newData[type] = v;
    setGraphData(Object.assign({}, newData));
    if (type === 'x' && checkXrange(v)) {
      setXrange({
        min: '',
        max: '',
      });
    }
  };

  const checkXrange = (v) => {
    let totalData;
    if (type === 'step') {
      if (ruleStepConfig.find((x) => x.step === E_STEP_5)?.data?.row) {
        totalData = Object.values(
          ruleStepConfig.find((x) => x.step === E_STEP_5).data.row,
        ).map((z) => z[v]);
        return (
          v !== '0' &&
          (dateRegex.test(totalData[0]) || dateValidateCheck(totalData[0]))
        );
      } else {
        return true;
      }
    } else {
      const sourceData =
        type === 'analysis' ? analysisData.data : originalFilteredRows;
      totalData = Object.values(sourceData).map((z) => {
        if (z['No.'] !== 'ALL') {
          return z[v];
        }
      });
      return (
        v !== '0' &&
        (dateRegex.test(totalData[0]) || dateValidateCheck(totalData[0]))
      );
    }
  };

  const disablePreview = () => {
    return graphData.type.length === 0 || graphData.y.length === 0;
  };

  const closeAddEdit = () => {
    closer();
    setGraphData({
      type: [],
      x: '0',
      y: [],
      z: '0',
    });
    setTitle('');
    setXrange({
      min: '',
      max: '',
    });
    setYrange({
      min: '',
      max: '',
    });
    setZrange({
      min: '',
      max: '',
    });
    setIsPreview(false);
    graphArea.current.removeAttribute('class');
    graphArea.current.firstChild?.remove();
  };

  const onAddEdit = () => {
    let message =
        mode === 'add' ? 'Add graph completed' : 'Edit graph completed',
      description = '',
      style = { borderLeft: '8px solid green' };
    const graphList =
        type === 'step' ? visualStepInfo.graph_list : visualization.graph_list,
      graphType =
        type === 'step'
          ? visualStepInfo.function_graph_type
          : visualization.function_graph_type,
      itemsInfo =
        type === 'step'
          ? visualStepInfo.items
          : type === 'analysis'
          ? analysisGraphInfo
          : originalGraphInfo;

    if (graphData.type.length === 0) {
      description = 'Graph type is not set. Please check the graph type.';
    } else if (graphData.y.length === 0) {
      description =
        'No data has been selected for reference in the graph. Please select data.';
    } else if (
      graphArea.current.getElementsByClassName('plot-container').length === 0
    ) {
      description = `The graph has not been drawn yet. Please ${mode} again after the graph is drawn.`;
    } else if (title.length > 0 && !titleRegex.test(title)) {
      description = 'The title is incorrect. Please check the title setting.';
    } else if (
      xRange.min.length > 0 ||
      xRange.max.length > 0 ||
      yRange.min.length > 0 ||
      yRange.max.length > 0 ||
      zRange.min.length > 0 ||
      zRange.max.length > 0
    ) {
      if (
        ((typeof xRange.min === 'string' || typeof xRange.min === 'number') &&
          (!regex.test(xRange.min) ||
            !regex.test(xRange.max) ||
            compareErrorCheck(xRange.min, xRange.max))) ||
        !regex.test(yRange.min) ||
        !regex.test(yRange.max) ||
        compareErrorCheck(yRange.min, yRange.max) ||
        !regex.test(zRange.min) ||
        !regex.test(zRange.max) ||
        compareErrorCheck(zRange.min, zRange.max)
      ) {
        description =
          'The range setting is incorrect. Please check the range setting.';
      }
    } else if (mode === 'add' && !isPreview) {
      description =
        'Save is not executed because the graph has not been changed.';
    }

    if (description === '') {
      description =
        mode === 'add'
          ? 'Add a graph has been completed.'
          : 'Edit a graph has been completed.';
      const tmpInfo = graphList.find((v) => v.name === graphData.type[0]);
      const graphInfo = graphType.find((v) => {
        return tmpInfo.type === 'user'
          ? v.name === tmpInfo.name
          : v.type === tmpInfo.type;
      });

      const newItems = {
        id: mode === 'add' ? null : itemsInfo[index].id,
        type: graphData.type,
        x_axis: graphData.x === '0' ? '' : graphData.x,
        y_axis: graphData.y,
        z_axis: graphData.z === '0' ? '' : graphData.z,
        title: title,
        x_range_min:
          typeof xRange.min !== 'string' && typeof xRange.min !== 'number'
            ? xRange.min.format(DATE_FORMAT)
            : xRange.min,
        x_range_max:
          typeof xRange.max !== 'string' && typeof xRange.max !== 'number'
            ? xRange.max.format(DATE_FORMAT)
            : xRange.max,
        y_range_min: yRange.min,
        y_range_max: yRange.max,
        z_range_min: zRange.min,
        z_range_max: zRange.max,
        script_info: {
          script: graphInfo.script,
          type: graphInfo.type,
        },
      };

      if (type === 'step') {
        updateVisualInfo({
          ...visualStepInfo,
          items:
            mode === 'add'
              ? [...visualStepInfo.items, newItems]
              : visualStepInfo.items.map((v, i) => {
                  return i !== index ? v : newItems;
                }),
        });
      } else if (type === 'analysis') {
        setAnalysisGraphInfo(
          mode === 'add'
            ? [...analysisGraphInfo, newItems]
            : analysisGraphInfo.map((v, i) => {
                return i !== index ? v : newItems;
              }),
        );
      } else {
        setOriginalGraphInfo(
          mode === 'add'
            ? [...originalGraphInfo, newItems]
            : originalGraphInfo.map((v, i) => {
                return i !== index ? v : newItems;
              }),
        );
      }

      if (mode !== 'add') {
        closeAddEdit();
      } else {
        setIsPreview(false);
        setGraphData({
          ...graphData,
          type: [],
        });
        setXrange({
          min: '',
          max: '',
        });
        setYrange({
          min: '',
          max: '',
        });
        setZrange({
          min: '',
          max: '',
        });
        setTitle('');
        graphArea.current.removeAttribute('class');
        graphArea.current.firstChild?.remove();
      }
    } else {
      message = mode === 'add' ? 'Add graph failed' : 'Edit graph failed';
      style = { borderLeft: '8px solid red' };
    }

    displayNotification({
      message: message,
      description: description,
      duration: 3,
      style: style,
    });
  };

  useEffect(() => {
    if (mode !== 'add' && isOpen) {
      const currentInfo =
        type === 'step'
          ? visualStepInfo.items[index]
          : type === 'analysis'
          ? analysisGraphInfo[index]
          : originalGraphInfo[index];

      if (currentInfo) {
        setGraphData({
          type: currentInfo.type,
          x: currentInfo.x_axis === '' ? '0' : currentInfo.x_axis,
          y: currentInfo.y_axis,
          z: currentInfo.z_axis === '' ? '0' : currentInfo.z_axis,
        });
        setTitle(currentInfo.title);
        setXrange({
          min: dateRegex.test(currentInfo.x_range_min)
            ? dayjs(currentInfo.x_range_min)
            : currentInfo.x_range_min,
          max: dateRegex.test(currentInfo.x_range_max)
            ? dayjs(currentInfo.x_range_max)
            : currentInfo.x_range_max,
        });
        setYrange({
          min: currentInfo.y_range_min,
          max: currentInfo.y_range_max,
        });
        setZrange({
          min: currentInfo.z_range_min,
          max: currentInfo.z_range_max,
        });

        renderGraph(
          {
            graphInfo:
              type === 'step'
                ? visualStepInfo.graph_list.find(
                    (v) => v.name === currentInfo.type[0],
                  )
                : visualization.graph_list.find(
                    (v) => v.name === currentInfo.type[0],
                  ),
            type: currentInfo.type,
            x: currentInfo.x_axis,
            y: currentInfo.y_axis,
            z: currentInfo.z_axis,
            title: currentInfo.title,
            xRange: {
              min: currentInfo.x_range_min,
              max: currentInfo.x_range_max,
            },
            yRange: {
              min: currentInfo.y_range_min,
              max: currentInfo.y_range_max,
            },
            zRange: {
              min: currentInfo.z_range_min,
              max: currentInfo.z_range_max,
            },
          },
          true,
        );
      }
    }
  }, [mode, isOpen]);

  return (
    <CSSTransition in={isOpen} classNames="modal" unmountOnExit timeout={100}>
      <>
        <div css={backgroundStyle} />
        <div css={SG.mainStyle}>
          <div>
            <div>{mode === 'add' ? 'Add Graph' : 'Edit Graph'}</div>
            <div>
              <Button onClick={closeAddEdit}>Close</Button>
              <Button type="primary" onClick={onAddEdit}>
                {mode === 'add' ? 'Add' : 'Save'}
              </Button>
            </div>
          </div>
          <div>
            <div>
              <Form labelAlign="left">
                <AxisTypeOption
                  values={graphData}
                  options={{
                    type:
                      type === 'step'
                        ? visualStepInfo.graph_list
                        : visualization.graph_list,
                    x:
                      type === 'step'
                        ? ruleStepConfig.find((v) => v.step === E_STEP_5)?.data
                            .disp_order
                        : type === 'analysis'
                        ? analysisData.dispOrder
                        : originalData.dispOrder,
                    y:
                      type === 'step'
                        ? ruleStepConfig.find((v) => v.step === E_STEP_5)?.data
                            .disp_graph
                        : type === 'analysis'
                        ? analysisData.dispGraph
                        : originalData.dispGraph,
                    z:
                      type === 'step'
                        ? ruleStepConfig.find((v) => v.step === E_STEP_5)?.data
                            .disp_graph
                        : type === 'analysis'
                        ? analysisData.dispGraph
                        : originalData.dispGraph,
                  }}
                  changeFunc={changeGraphData}
                />
                <Item label="Title">
                  <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    maxLength="20"
                  />
                </Item>
                <Item label="X Range">
                  {checkXrange(graphData.x) === false ? (
                    <div className="multi-input">
                      <Input
                        value={xRange.min}
                        onChange={(e) =>
                          setXrange((prevState) => {
                            return { ...prevState, min: e.target.value };
                          })
                        }
                      />
                      <Input
                        value={xRange.max}
                        onChange={(e) =>
                          setXrange((prevState) => {
                            return { ...prevState, max: e.target.value };
                          })
                        }
                      />
                    </div>
                  ) : (
                    <RangePicker
                      showTime
                      allowClear={false}
                      style={{ width: '100%' }}
                      value={[xRange.min, xRange.max]}
                      onChange={(v) =>
                        setXrange({
                          min: v[0],
                          max: v[1],
                        })
                      }
                    />
                  )}
                </Item>
                <Item label="Y Range">
                  <div className="multi-input">
                    <Input
                      value={yRange.min}
                      onChange={(e) =>
                        setYrange((prevState) => {
                          return { ...prevState, min: e.target.value };
                        })
                      }
                    />
                    <Input
                      value={yRange.max}
                      onChange={(e) =>
                        setYrange((prevState) => {
                          return { ...prevState, max: e.target.value };
                        })
                      }
                    />
                  </div>
                </Item>
                <Item label="Z Range">
                  <div className="multi-input">
                    <Input
                      value={zRange.min}
                      onChange={(e) =>
                        setZrange((prevState) => {
                          return { ...prevState, min: e.target.value };
                        })
                      }
                    />
                    <Input
                      value={zRange.max}
                      onChange={(e) =>
                        setZrange((prevState) => {
                          return { ...prevState, max: e.target.value };
                        })
                      }
                    />
                  </div>
                </Item>
              </Form>
            </div>
            <div>
              <Button
                type="primary"
                disabled={disablePreview()}
                onClick={() =>
                  renderGraph(
                    {
                      graphInfo:
                        type === 'step'
                          ? visualStepInfo.graph_list.find(
                              (v) => v.name === graphData.type[0],
                            )
                          : visualization.graph_list.find(
                              (v) => v.name === graphData.type[0],
                            ),
                      x: graphData.x,
                      y: graphData.y,
                      z: graphData.z,
                      type: graphData.type,
                      title: title,
                      xRange: xRange,
                      yRange: yRange,
                      zRange: zRange,
                    },
                    false,
                  )
                }
              >
                Preview
              </Button>
              <div ref={graphArea}>{errorMsg.length > 0 ? errorMsg : ''}</div>
            </div>
          </div>
        </div>
      </>
    </CSSTransition>
  );
});

GraphAddEdit.propTypes = {
  closer: PropTypes.func.isRequired,
  isOpen: PropTypes.bool.isRequired,
  mode: PropTypes.string,
  index: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  type: PropTypes.string,
};
GraphAddEdit.defaultProps = {
  mode: 'add',
  type: 'step',
};

const AxisTypeOption = ({ values, options, changeFunc }) => {
  return (
    <>
      <Item label="Graph Type">
        <Select
          mode="multiple"
          value={values.type}
          onChange={(v) => changeFunc('type', v)}
          maxTagCount="responsive"
        >
          {options.type.map((v) => {
            return (
              <Option
                value={v.name}
                key={v.name}
                disabled={
                  values.type.length > 0 &&
                  ((options.type.find((z) => z.name === values.type[0]).type ===
                    'user' &&
                    v.type === 'system') ||
                    (options.type.find((z) => z.name === values.type[0])
                      .type === 'system' &&
                      v.type === 'user'))
                }
              >
                {v.name}
              </Option>
            );
          })}
        </Select>
      </Item>
      <Item label="Axis(X)">
        <Select value={values.x} onChange={(v) => changeFunc('x', v)}>
          <Option value="0">None</Option>
          {options.x.map((v) => {
            return (
              <Option value={v} key={v}>
                {v}
              </Option>
            );
          })}
        </Select>
      </Item>
      <Item label="Axis(Y)">
        <Select
          mode="multiple"
          value={values.y}
          onChange={(v) => changeFunc('y', v)}
          maxTagCount="responsive"
        >
          {options.y.map((v) => {
            return (
              <Option value={v} key={v}>
                {v}
              </Option>
            );
          })}
        </Select>
      </Item>
      <Item label="Axis(Z)">
        <Select value={values.z} onChange={(v) => changeFunc('z', v)}>
          <Option value="0">None</Option>
          {options.z.map((v) => {
            return (
              <Option value={v} key={v}>
                {v}
              </Option>
            );
          })}
        </Select>
      </Item>
    </>
  );
};
AxisTypeOption.propTypes = {
  values: PropTypes.object.isRequired,
  options: PropTypes.object.isRequired,
  changeFunc: PropTypes.func.isRequired,
};

export default GraphAddEdit;
