import { useState, useCallback } from 'react';
import {
  getValidPeriod,
  initialSettingAction,
  UpdateDurationReducer,
} from '../reducers/slices/SettingInfo';
import { useDispatch, useSelector } from 'react-redux';
import {
  getCurrentPath,
  getSupportUrl,
  UpdateCurrentPathReducer,
} from '../reducers/slices/BasicInfo';

export const initialState = {
  log_name: '',
  source: '',
  target_path: [],
  equipment_type: '',
};

const useFocusJob = () => {
  const [isOpenCreateJob, setCreateJob] = useState(true);
  const [isLoading, setLoading] = useState(false);
  const [isErrorStatus, setError] = useState(null);
  const [isSettingInfo, setSettingJobInfo] = useState(null);
  const [JobInfo, setJobInfo] = useState(initialState);
  const dispatch = useDispatch();
  const validPeriod = useSelector(getValidPeriod);
  const currentPath = useSelector(getCurrentPath);
  const urlList = useSelector(getSupportUrl);

  const setValidPeriod = useCallback(
    (value) => {
      dispatch(UpdateDurationReducer(value));
    },
    [dispatch],
  );
  const initValidPeriod = useCallback(() => {
    dispatch(initialSettingAction());
  }, [dispatch]);

  const setCurrentPath = useCallback(
    (value) => {
      dispatch(UpdateCurrentPathReducer(value));
    },
    [dispatch],
  );

  const openCreateJob = useCallback(() => {
    setCreateJob(true);
  }, [setCreateJob]);

  const closeCreateJob = useCallback(() => {
    setCreateJob(false);
  }, [setCreateJob]);

  const setErrorStatus = useCallback(
    (e) => {
      setError(e);
    },
    [setError],
  );

  const clearErrorStatus = useCallback(() => {
    setError(null);
  }, [setError]);

  const loadStart = useCallback(() => {
    setLoading(true);
    clearSettingInfo();
    clearErrorStatus();
  }, [setError, setLoading, setSettingJobInfo, setJobInfo]);

  const loadCompleted = useCallback(() => {
    setLoading(false);
  }, [setLoading]);

  const setSettingInfo = useCallback(
    (setting, func_id) => {
      setSettingJobInfo(setting);
      setJobInfo((prevState) => ({
        ...prevState,
        func_id: func_id,
      }));
    },
    [setSettingJobInfo],
  );
  const clearSettingInfo = useCallback(() => {
    setSettingJobInfo(null);
    initJobInfo();
  }, [setSettingJobInfo]);

  const initJobInfo = useCallback(() => {
    setJobInfo(initialState);
  }, [setJobInfo]);

  const updateJobInfo = useCallback(
    (info) => {
      console.log('before: ', JobInfo);
      console.log('After: ', info);
      setJobInfo(info);
    },
    [setJobInfo],
  );

  return {
    isOpenCreateJob,
    openCreateJob,
    closeCreateJob,
    isErrorStatus,
    setErrorStatus,
    clearErrorStatus,
    isLoading,
    loadStart,
    loadCompleted,
    isSettingInfo,
    setSettingInfo,
    clearSettingInfo,
    JobInfo,
    setJobInfo,
    updateJobInfo,
    validPeriod,
    setValidPeriod,
    initValidPeriod,
    currentPath,
    setCurrentPath,
    urlList,
  };
};

export default useFocusJob;
