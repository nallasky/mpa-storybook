import path from 'path'

import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default ({ mode }) => {
  const env = loadEnv(mode, process.cwd())

  return defineConfig({
    plugins: [react()],
    base: env.VITE_DEFAULT_URL,
    css: {
      modules: {
        localsConvention: 'camelCase',
      },
    },
    resolve: {
      alias: {
        '@app': path.resolve('src/app'),
        '@pages': path.resolve('src/pages'),
        '@widgets': path.resolve('src/widgets'),
        '@shared': path.resolve('src/shared'),
        '@features': path.resolve('src/features'),
      },
    },
  })
}
