import path from 'path'

import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import styleX from 'vite-plugin-stylex'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), styleX()],
  css: {
    modules: {
      localsConvention: 'camelCase',
    },
  },
  resolve: {
    alias: {
      '@app': path.resolve('src/app'),
      '@pages': path.resolve('src/pages'),
      '@widgets': path.resolve('src/widgets'),
      '@shared': path.resolve('src/shared'),
      '@features': path.resolve('src/features'),
    },
  },
})
