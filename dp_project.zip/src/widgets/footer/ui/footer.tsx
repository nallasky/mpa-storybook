import * as stylex from '@stylexjs/stylex'

export const Footer = () => {
  return (
    <footer>
      <div {...stylex.props(footerStyles.base)}>Copyright (c) 2024 CANON Inc. All rights reserved.</div>
    </footer>
  )
}

const footerStyles = stylex.create({
  base: {
    textAlign: 'right',
    padding: '1.5rem 0',
    width: '1680px',
    margin: '0 auto',
  },
})
