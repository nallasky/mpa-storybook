import styled from 'styled-components'

export const Footer = () => {
  return (
    <footer>
      <FooterContainer>
        Copyright (c) 2024 CANON Inc. All rights reserved.
      </FooterContainer>
    </footer>
  )
}

const FooterContainer = styled.footer`
  text-align: right;
  padding: 1.5rem 0;
  width: var(--default-page-width);
  margin: 0 auto;
`