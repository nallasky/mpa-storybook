import { useLocation } from 'react-router-dom'
import * as stylex from '@stylexjs/stylex'

export const Footer = () => {
  const location = useLocation()

  if (location.pathname === '/') {
    return
  }

  return (
    <footer>
      <div {...stylex.props(footerStyles.base)}>footer</div>
    </footer>
  )
}

const footerStyles = stylex.create({
  base: {
    display: 'flex',
    alignItems: 'center',
    padding: '1.5rem 0',
    width: '1680px',
    margin: '0 auto',
  },
})
