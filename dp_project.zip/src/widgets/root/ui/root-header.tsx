import * as stylex from '@stylexjs/stylex'

import { RootCalendarController, RootCalendarFilter } from '@features/root'

export const RootHeader = () => {
  return (
    <div {...stylex.props(rootHeaderStyles.base)}>
      <RootCalendarController />
      <RootCalendarFilter />
    </div>
  )
}

const rootHeaderStyles = stylex.create({
  base: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
})
