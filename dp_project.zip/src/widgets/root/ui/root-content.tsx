import * as stylex from '@stylexjs/stylex'

import { RootCalendar } from '@features/root'

export const RootContent = () => {
  return (
    <div {...stylex.props(roonContentStyles.base)}>
      <RootCalendar />
    </div>
  )
}

const roonContentStyles = stylex.create({
  base: {
    padding: '1rem 0',
  },
})
