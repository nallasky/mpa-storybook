import { useLocation } from 'react-router-dom'
import * as stylex from '@stylexjs/stylex'

import { NavbarUserInfo } from '@features/navbar'

export const Navbar = () => {
  const location = useLocation()

  if (location.pathname === '/') {
    return
  }

  return (
    <header {...stylex.props(navbarStyles.base)}>
      <div {...stylex.props(navbarStyles.container)}>
        <NavbarUserInfo />
      </div>
    </header>
  )
}

const navbarStyles = stylex.create({
  base: {
    position: 'sticky',
    backgroundColor: 'white',
    top: 0,
    zIndex: 1000,
  },
  container: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: '1.5rem 0',
    width: '1680px',
    margin: '0 auto',
  },
})
