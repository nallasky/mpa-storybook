import styled from 'styled-components'

import { NavbarUserInfo } from '@features/navbar'

export const Navbar = () => {
  return (
    <NavbarHeader>
      <div className="navbar-container">
        <NavbarUserInfo />
      </div>
    </NavbarHeader>
  )
}

const NavbarHeader = styled.header`
  position: sticky;
  background-color: white;
  top: 0;
  z-index: 1000;
  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.03), 0 1px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px 0 rgba(0, 0, 0, 0.02);
  backdrop-filter: blur(8px);
  .navbar-container {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 1.5rem 0;
    width: var(--default-page-width);
    margin: 0 auto;
  }
`
