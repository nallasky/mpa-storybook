import * as stylex from '@stylexjs/stylex'

import { NavbarUserInfo } from '@features/navbar'

export const Navbar = () => {
  return (
    <header {...stylex.props(navbarStyles.base)}>
      <div {...stylex.props(navbarStyles.container)}>
        <NavbarUserInfo />
      </div>
    </header>
  )
}

const navbarStyles = stylex.create({
  base: {
    position: 'sticky',
    backgroundColor: 'white',
    top: 0,
    zIndex: 1000,
    boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.03), 0 1px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px 0 rgba(0, 0, 0, 0.02)',
    backdropFilter: 'blur(8px)'
  },
  container: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: '1.5rem 0',
    width: '1680px',
    margin: '0 auto',
  },
})
