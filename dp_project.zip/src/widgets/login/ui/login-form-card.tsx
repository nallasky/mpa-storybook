import * as stylex from '@stylexjs/stylex'

import { Card } from '@shared/ui'
import { LoginForm } from '@features/login'

export const LoginFormCard = () => {
  return (
    <Card>
      <Card.Header
        title="Login"
        useBottomBorder={false}
        styles={headerStyles.base}
      />
      <Card.Content styles={contentStyles.base}>
        <LoginForm />
      </Card.Content>
    </Card>
  )
}

const headerStyles = stylex.create({
  base: {
    padding: '3rem 2rem',
  },
})

const contentStyles = stylex.create({
  base: {
    padding: '1rem 2rem 3rem',
  },
})
