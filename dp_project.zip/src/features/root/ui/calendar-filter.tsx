import { Select } from 'antd'

export const RootCalendarFilter = () => {
  return (
    <div>
      <Select
        size="large"
        style={{ width: '300px', marginRight: '1rem' }}
        defaultValue={'ドメインフィルター'}
      >
        <Select.Option>ドメインフィルター</Select.Option>
      </Select>
      <Select
        size="large"
        style={{ width: '300px' }}
        defaultValue={'チェック担当フィルター'}
      >
        <Select.Option>チェック担当フィルター</Select.Option>
      </Select>
    </div>
  )
}
