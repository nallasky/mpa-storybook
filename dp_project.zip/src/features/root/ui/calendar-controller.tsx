import { Button } from 'antd'
import { LeftOutlined, RightOutlined } from '@ant-design/icons'

export const RootCalendarController = () => {
  return (
    <div>
      <Button size="large" style={{ marginRight: '1rem' }}>
        今日
      </Button>
      <Button
        type="primary"
        size="large"
        shape="circle"
        icon={<LeftOutlined />}
        style={{ marginRight: '1rem' }}
      />
      <Button
        type="primary"
        size="large"
        shape="circle"
        icon={<RightOutlined />}
        style={{ marginRight: '1rem' }}
      />
      <Button size="large" style={{ marginRight: '1rem' }}>
        新規リリース作成
      </Button>
      <span>2024年 01月</span>
    </div>
  )
}
