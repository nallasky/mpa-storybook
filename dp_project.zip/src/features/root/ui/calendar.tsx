import { Calendar, dayjsLocalizer } from 'react-big-calendar'
import dayjs from 'dayjs'

const localizer = dayjsLocalizer(dayjs)

export const RootCalendar = () => {
  return (
    <Calendar
      localizer={localizer}
      toolbar={false}
      defaultView="week"
      startAccessor="start"
      endAccessor="end"
      timeslots={2}
      style={{ height: 'calc(100vh - 226px)' }}
    />
  )
}
