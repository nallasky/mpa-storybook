import { useNavigate } from 'react-router-dom'
import { css } from 'styled-components'
import { Form, Input, Button } from 'antd'
import { LockOutlined, UserOutlined } from '@ant-design/icons'

import { Card } from '@shared/ui'

export const LoginForm = () => {
  const [form] = Form.useForm()
  const navigate = useNavigate()

  return (
    <Card>
      <Card.Header
        title="Login"
        useBottomBorder={false}
        css={loginFormStyles.cardHeader}
      />
      <Card.Content css={loginFormStyles.cardContent}>
        <Form form={form} size="large" onFinish={() => navigate(`${import.meta.env.VITE_DEFAULT_URL}/home`, { unstable_viewTransition: true })}>
          <Form.Item
            name="username"
            rules={[
              { required: true, message: 'Please input your Username correctly.' },
            ]}
          >
            <Input
              size="large"
              placeholder="Username"
              prefix={<UserOutlined className="login-form-prefix-icon" />}
              style={{ padding: '1rem 11px' }}
            />
          </Form.Item>
          <Form.Item
            name="password"
            rules={[
              { required: true, message: 'Please input your Password correctly.' },
            ]}
          >
            <Input.Password
              size="large"
              placeholder="Password"
              prefix={<LockOutlined className="login-form-prefix-icon" />}
              style={{ padding: '1rem 11px' }}
            />
          </Form.Item>
          <Form.Item noStyle>
            <Button
              type="primary"
              size="large"
              htmlType="submit"
            >
              LOG IN
            </Button>
          </Form.Item>
        </Form>
      </Card.Content>
    </Card>
  )
}

const loginFormStyles = {
  cardHeader: css`
    padding: 3rem 2rem;
  `,
  cardContent: css`
    padding: 1rem 2rem 3rem;
    & input,
    & input::placeholder {
      font-family: 'Meiryo' !important;
    }
    & .login-form-prefix-icon {
      color: rgba(0, 0, 0, 0.25);
    }
    & > form > div {
      margin-bottom: 3rem;
    }
    & button {
      width: 100%;
      padding: 2rem 15px;
      line-height: 0;
      font-size: 20px;
      font-weight: bold;
    }
  `
}
