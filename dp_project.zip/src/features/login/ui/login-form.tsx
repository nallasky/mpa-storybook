import { useNavigate } from 'react-router-dom'
import { Form, Input, Button } from 'antd'
import { LockOutlined, UserOutlined } from '@ant-design/icons'

export const LoginForm = () => {
  const [form] = Form.useForm()
  const navigate = useNavigate()

  return (
    <Form form={form} size="large" onFinish={() => navigate('/home')}>
      <div>
        <Form.Item
          name="username"
          rules={[
            { required: true, message: 'Please input your Username correctly.' },
          ]}
          style={{ marginBottom: '3rem' }}
        >
          <Input
            size="large"
            placeholder="Username"
            prefix={<UserOutlined className="login-form-prefix-icon" />}
            style={{ padding: '1rem 11px' }}
          />
        </Form.Item>
        <Form.Item
          name="password"
          rules={[
            { required: true, message: 'Please input your Password correctly.' },
          ]}
          style={{ marginBottom: '3rem' }}
        >
          <Input.Password
            size="large"
            placeholder="Password"
            prefix={<LockOutlined className="login-form-prefix-icon" />}
            style={{ padding: '1rem 11px' }}
          />
        </Form.Item>
        <Form.Item noStyle>
          <Button
            type="primary"
            size="large"
            htmlType="submit"
            style={{
              width: '100%',
              padding: '2rem 15px',
              lineHeight: '0',
              fontSize: '20px',
              fontWeight: 'bold',
            }}
          >
            SUBMIT
          </Button>
        </Form.Item>
      </div>
    </Form>
  )
}
