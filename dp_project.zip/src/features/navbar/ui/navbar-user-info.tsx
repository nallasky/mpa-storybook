import { useNavigate } from 'react-router-dom'
import styled from 'styled-components'
import { Button } from 'antd'

export const NavbarUserInfo = () => {
  const navigate = useNavigate()

  return (
    <ComponentWrapper>
      <span className="navbar-user-info-user-name">Administrator</span>
      <Button size="large" onClick={() => navigate(`${import.meta.env.VITE_DEFAULT_URL}`, { unstable_viewTransition: true })}>
        Logout
      </Button>
    </ComponentWrapper>
  )
}

const ComponentWrapper = styled.div`
 & > .navbar-user-info-user-name {
  margin-right: 1rem;
 }
`
