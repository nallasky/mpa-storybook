import { useNavigate } from 'react-router-dom'
import * as stylex from '@stylexjs/stylex'
import { Button } from 'antd'

export const NavbarUserInfo = () => {
  const navigate = useNavigate()

  return (
    <div>
      <span {...stylex.props(usernameStyles.base)}>Administrator</span>
      <Button size="large" onClick={() => navigate('/')}>
        Logout
      </Button>
    </div>
  )
}

const usernameStyles = stylex.create({
  base: {
    marginRight: '1rem',
  },
})
