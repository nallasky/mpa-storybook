import { useEffect, useRef, Fragment } from 'react'
import {
  Select,
  Button,
  Drawer,
  Form,
  Input,
  Table,
  Radio,
  DatePicker,
  Space,
  Divider,
  type FormListFieldData,
  type FormListOperation,
} from 'antd'
import type { ColumnType } from 'antd/es/table'
import { DeleteOutlined } from '@ant-design/icons'
import styled from 'styled-components'

import { type GlobalModalDefaultProps } from '@shared/lib'

export const ReleaseDrawer = ({ open, onClose }: GlobalModalDefaultProps) => {
  const [form] = Form.useForm()

  useEffect(() => {
    form.setFieldsValue({
      releaseOption: 1,
      milestone: data,
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <Drawer
      width={1200}
      title="リリース情報"
      open={open}
      onClose={onClose}
      closeIcon={false}
      className="register-release-schedule-drawer"
      extra={<ReleaseDrawerExtra onClose={onClose} />}
      destroyOnClose
    >
      <Form layout="vertical" form={form}>
        <ReleaseDrawerSettingsWrapper>
          <div>
            <label className="release-drawer-release-type-label">リリース種別</label>
            <Form.Item name="releaseOption" noStyle>
              <Radio.Group options={releaseOptions} optionType="button" />
            </Form.Item>
          </div>
          <Divider />
          <div className="release-drawer-release-type-content">
            <Form.Item
              shouldUpdate={(pre, cur) => pre.releaseOption !== cur.releaseOption}
              noStyle
            >
              {() => {
                const releaseOption: number = form.getFieldValue('releaseOption')
                return (
                  <Fragment>
                    <PeriodicReleaseForm isShow={releaseOption === 1} />
                    <RunningChangeForm isShow={releaseOption === 2} />
                    <AdviceForm isShow={releaseOption === 3} />
                  </Fragment>
                )
              }}
            </Form.Item>
          </div>
        </ReleaseDrawerSettingsWrapper>
        <Divider />
        <ReleaseDrawerMilestoneTableWrapper>
          <Form.List name="milestone">
            {(milestone, { add, remove }) => (
              <ProcessHistoryTable milestone={milestone} add={add} remove={remove} />
            )}
          </Form.List>
        </ReleaseDrawerMilestoneTableWrapper>
      </Form>
    </Drawer>
  )
}

const ReleaseDrawerSettingsWrapper = styled.div`
  & .ant-form-item {
    margin-bottom: 0;
  }
  & .release-drawer-release-type-label {
    margin-right: 1rem;
  }
  & > .release-drawer-release-type-content {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
  }
`

const ReleaseDrawerMilestoneTableWrapper = styled.div`
  & table {
    font-size: 12px;
    font-family: 'Meiryo' !important;
  }
  & .rc-virtual-list-scrollbar-thumb {
    background: #ddd !important;
    border-radius: 2px !important;
  }
  & .ant-table-row > .ant-table-cell {
    padding: 1rem 0.5rem !important;
    & input {
      font-size: 12px;
      font-family: 'Meiryo' !important;
      padding: 0.25rem;
      border-color: transparent;
      &:hover,
      &:focus {
        border-color: #4096ff;
      }
    }
    &:last-of-type {
      text-align: center;
    }
  }
`

type ReleaseDrawerExtraProps = {
  onClose: () => void
}

const ReleaseDrawerExtra = ({ onClose }: ReleaseDrawerExtraProps) => (
  <Space>
    <Button onClick={onClose}>Cancel</Button>
    <Button type="primary" onClick={onClose}>
      Add
    </Button>
  </Space>
)

type ProcessHistoryTableProps = {
  milestone: FormListFieldData[],
  add: FormListOperation['add'],
  remove: FormListOperation['remove'],
}

const ProcessHistoryTable = ({ milestone, add, remove }: ProcessHistoryTableProps) => {
  const tableRef: Parameters<typeof Table>[0]['ref'] = useRef(null)

  const onAdd = () => {
    add();
    tableRef.current?.scrollTo({ index: milestone.length })
  }

  return (
    <Table
      tableLayout="fixed"
      dataSource={milestone}
      pagination={false}
      ref={tableRef}
      scroll={{ y: 325 }}
      footer={() => <Button type="primary" onClick={onAdd}>追加</Button>}
      bordered
      virtual
    >
      {columns.map(({ key, ...rest }) => (
        <Table.Column
          key={key}
          render={(_value, _row, index) => {
            if (key === 'delete') {
              return (
                <Button
                  shape="circle"
                  icon={<DeleteOutlined />}
                  onClick={() => remove(index)}
                />
              )
            }

            return (
              <Form.Item
                name={[index, key as string]}
                noStyle
              >
                <Input spellCheck={false} />
              </Form.Item>
            )
          }}
          {...rest}
        />
      ))}
    </Table>
  )
}

type ReleaseFormProps = {
  isShow: boolean
}

const PeriodicReleaseForm = ({ isShow }: ReleaseFormProps) => {
  if (!isShow) return

  return (
    <Fragment>
      <Form.Item label="リリース名">
        <Input />
      </Form.Item>
      <Form.Item label="担当ドメイン">
        <Select />
      </Form.Item>
      <Form.Item label="機種名">
        <Input />
      </Form.Item>
      <Form.Item label="リリース日">
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="リリースブランチ">
        <Select />
      </Form.Item>
      <Form.Item label="設計内リリースチェック担当者">
        <Select />
      </Form.Item>
      <Form.Item label="障害票プレフィクス">
        <Input />
      </Form.Item>
    </Fragment>
  )
}

const RunningChangeForm = ({ isShow }: ReleaseFormProps) => {
  if (!isShow) return

  return (
    <Fragment>
      <Form.Item label="リリース名">
        <Input />
      </Form.Item>
      <Form.Item label="機種名">
        <Input />
      </Form.Item>
      <Form.Item label="担当ドメイン">
        <Select />
      </Form.Item>
      <Form.Item label="リリース日">
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="リリースブランチ">
        <Select />
      </Form.Item>
      <Form.Item label="設計内リリースチェック担当者">
        <Select />
      </Form.Item>
      <Form.Item label="コミット解禁日">
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="コミット締め切り日">
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="品保評価終了予定日">
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="リリース予定のバージョン名">
        <Input />
      </Form.Item>
      <Form.Item label="障害票プレフィクス">
        <Input />
      </Form.Item>
      <Form.Item label="修正1件ごとの修正内容">
        <Input />
      </Form.Item>
    </Fragment>
  )
}

const AdviceForm = ({ isShow }: ReleaseFormProps) => {
  if (!isShow) return

  return (
    <Fragment>
      <Form.Item label="リリース名">
        <Input />
      </Form.Item>
      <Form.Item label="機種名">
        <Input />
      </Form.Item>
      <Form.Item label="担当ドメイン">
        <Select />
      </Form.Item>
      <Form.Item label="リリースブランチ">
        <Select />
      </Form.Item>
      <Form.Item label="設計内リリースチェック担当者">
        <Select />
      </Form.Item>
      <Form.Item label="修正ファーム送付締め切り日">
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="リリース日 (品保評価終了予定日)">
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item label="作製元ブランチ">
        <Select />
      </Form.Item>
      <Form.Item label="ベースとなるリビジョン">
        <Input />
      </Form.Item>
      <Form.Item label="リリース予定のバージョン名">
        <Input />
      </Form.Item>
      <Form.Item label="障害票プレフィクス">
        <Input />
      </Form.Item>
      <Form.Item label="修正1件ごとの修正内容">
        <Input />
      </Form.Item>
      <Form.Item label="リリースするTYPE">
        <Input />
      </Form.Item>
    </Fragment>
  )
}

interface DataType {
  itemName: string
  allocatedStaff: string
  probNumber: string
  allocatedDomain: string
  processingStep: string
  probStaff: string
}

const data: DataType[] = [
  {
    itemName: '脆弱性対応',
    allocatedStaff: '小林',
    probNumber: 'A382MFSF_11b_IT-0001',
    allocatedDomain: 'JCD-PDL, UI',
    processingStep: 'E:対策中',
    probStaff: 'kobayashi.shinsaku'
  },
  {
    itemName: 'セキュリティ対応',
    allocatedStaff: '熊橋',
    probNumber: 'A382MFSF_11b_IT-0002',
    allocatedDomain: 'JCD-PDL',
    processingStep: 'F:対策確認中',
    probStaff: 'kumahashi.shu'
  },
  {
    itemName: '仕様変更対応',
    allocatedStaff: '伊藤',
    probNumber: '',
    allocatedDomain: '',
    processingStep: '',
    probStaff: ''
  },
  {
    itemName: '自動化',
    allocatedStaff: '生野',
    probNumber: 'A382MFSF_11b_IT-0003',
    allocatedDomain: '',
    processingStep: 'D:割り当て中',
    probStaff: 'ikuno.takao'
  },
]

const columns: ColumnType<FormListFieldData>[] = [
  {
    title: '要件名',
    dataIndex: 'itemName',
    key: 'itemName'
  },
  {
    title: '割当担当者',
    dataIndex: 'allocatedStaff',
    key: 'allocatedStaff',
    width: 120,
  },
  {
    title: '障害票番号',
    dataIndex: 'probNumber',
    key: 'probNumber',
  },
  {
    title: '担当ドメイン',
    dataIndex: 'allocatedDomain',
    key: 'allocatedDomain'
  },
  {
    title: '障害票ステータス',
    dataIndex: 'processingStep',
    key: 'processingStep',
    width: 150
  },
  {
    title: 'ProB担当者',
    dataIndex: 'probStaff',
    key: 'probStaff',
  },
  {
    title: '削除',
    dataIndex: 'delete',
    key: 'delete',
    width: 70,
  }
]

const releaseOptions = [
  { label: '定期リリース', value: 1 },
  { label: 'ランチェン', value: 2 },
  { label: '商談', value: 3 }
]