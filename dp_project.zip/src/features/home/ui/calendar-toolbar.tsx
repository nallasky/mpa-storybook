import styled from 'styled-components'
import { Button, Select } from 'antd'
import { LeftOutlined, RightOutlined } from '@ant-design/icons'
import { ToolbarProps } from 'react-big-calendar'

import { useModal } from '@shared/lib'
import { ReleaseDrawer } from './release-drawer'

export const HomeCalendarToolbar = (props: ToolbarProps) => {
  const { openModal } = useModal()
  const { date, onNavigate } = props

  return (
    <HomeCalendarToolBarContainer>
      <div className="home-calendar-toolbar-menu">
        <Button size="large" onClick={() => onNavigate('TODAY')}>
          今日
        </Button>
        <Button
          type="primary"
          size="large"
          shape="circle"
          icon={<LeftOutlined />}
          onClick={() => onNavigate('PREV')}
        />
        <Button
          type="primary"
          size="large"
          shape="circle"
          icon={<RightOutlined />}
          onClick={() => onNavigate('NEXT')}
        />
        <Button
          size="large"
          onClick={() => openModal('register-release-drawer', ReleaseDrawer)}
        >
          新規リリース作成
        </Button>
        <span>{`${date.getFullYear()}年 ${date.getMonth() + 1}月`}</span>
      </div>
      <div className="home-calendar-toolbar-menu">
        <Select
          size="large"
          style={{ width: '300px' }}
          defaultValue={'ドメインフィルター'}
        >
          <Select.Option>ドメインフィルター</Select.Option>
        </Select>
        <Select
          size="large"
          style={{ width: '300px' }}
          defaultValue={'チェック担当フィルター'}
        >
          <Select.Option>チェック担当フィルター</Select.Option>
        </Select>
      </div>
    </HomeCalendarToolBarContainer>
  )
}

const HomeCalendarToolBarContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 0;
  & > .home-calendar-toolbar-menu {
    display: flex;
    align-items: center;
    column-gap: 1rem;
  }
`