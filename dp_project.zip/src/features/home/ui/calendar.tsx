import {
  Select,
  Button,
  Drawer,
  Form,
  Input,
  Table,
  Radio,
  DatePicker,
  Space,
  type TableProps
} from 'antd'
import { LeftOutlined, RightOutlined } from '@ant-design/icons'
import { Calendar, dayjsLocalizer, ToolbarProps, EventWrapperProps } from 'react-big-calendar'
import * as stylex from '@stylexjs/stylex'
import dayjs from 'dayjs'
import "dayjs/locale/ja"

import { useModal, type GlobalModalDefaultProps } from '@shared/lib'
import { Card } from '@shared/ui'

dayjs.locale('ja')
const localizer = dayjsLocalizer(dayjs)

export const HomeCalendar = () => {
  return (
    <Calendar
      localizer={localizer}
      defaultView="week"
      startAccessor="start"
      endAccessor="end"
      events={[
        {
          allDay: true,
          start: new Date(),
          end: new Date(),
          resource: {
            nickName: 'BEIGE',
            version: 'V00.03',
            description: 'a定期リリース'
          }
        },
        {
          allDay: true,
          start: new Date(),
          end: new Date(),
          resource: {
            nickName: 'FLORAL',
            version: 'V03.01',
            description: 'CDCA定期リリース'
          }
        },
      ]}
      components={{ toolbar: HomeCalendarToolbar, eventWrapper: EventWrapperComponent }}
      selectable
    />
  )
}

interface DataType {
  itemName: string
  allocatedStaff: string
  probNumber: string
  allocatedDomain: string
  processingStep: string
  probStaff: string
}

const columns: TableProps<DataType>['columns'] = [
  {
    title: '要件名',
    dataIndex: 'itemName',
    key: 'itemName'
  },
  {
    title: '割当担当者',
    dataIndex: 'allocatedStaff',
    key: 'allocatedStaff'
  },
  {
    title: '障害票番号',
    dataIndex: 'probNumber',
    key: 'probNumber'
  },
  {
    title: '担当ドメイン',
    dataIndex: 'allocatedDomain',
    key: 'allocatedDomain'
  },
  {
    title: '障害票ステータス',
    dataIndex: 'processingStep',
    key: 'processingStep'
  },
  {
    title: 'ProB担当者',
    dataIndex: 'probStaff',
    key: 'probStaff'
  },
]

const data: DataType[] = [
  {
    itemName: '脆弱性対応',
    allocatedStaff: '小林',
    probNumber: 'A382MFSF_11b_IT-0001',
    allocatedDomain: 'JCD-PDL, UI',
    processingStep: 'E:対策中',
    probStaff: 'kobayashi.shinsaku'
  },
  {
    itemName: 'セキュリティ対応',
    allocatedStaff: '熊橋',
    probNumber: 'A382MFSF_11b_IT-0002',
    allocatedDomain: 'JCD-PDL',
    processingStep: 'F:対策確認中',
    probStaff: 'kumahashi.shu'
  },
  {
    itemName: '仕様変更対応',
    allocatedStaff: '伊藤',
    probNumber: '',
    allocatedDomain: '',
    processingStep: '',
    probStaff: ''
  },
  {
    itemName: '自動化',
    allocatedStaff: '生野',
    probNumber: 'A382MFSF_11b_IT-0003',
    allocatedDomain: '',
    processingStep: 'D:割り当て中',
    probStaff: 'ikuno.takao'
  },
]

const releaseOptions = ['定期リリース', 'ランチェン', '商談']

const TestDrawer = ({ open, onClose }: GlobalModalDefaultProps) => {
  return (
    <Drawer
      width={1200}
      title="リリース情報"
      open={open}
      onClose={onClose}
      closeIcon={false}
      extra={
        <Space>
          <Button onClick={onClose}>Cancel</Button>
          <Button type="primary" onClick={onClose}>
            Add
          </Button>
        </Space>
      }
    >
      <Form layout="vertical">
        <div>
          <div>
            <label>リリース種別</label>
            <Form.Item noStyle>
              <Radio.Group options={releaseOptions} optionType="button" />
            </Form.Item>
          </div>
          <Form.Item label="リリース名" required>
            <Input />
          </Form.Item>
          <Form.Item label="機種名">
            <Input />
          </Form.Item>
          <Form.Item label="担当ドメイン">
            <Select />
          </Form.Item>
          <Form.Item label="リリースの目的">
            <Select />
          </Form.Item>
          <Form.Item label="リリースブランチ">
            <Select />
          </Form.Item>
          <Form.Item label="設計内リリースチェック担当者">
            <Select />
          </Form.Item>
          <Form.Item label="修正ファーム送付締め切り日">
            <DatePicker style={{ width: '100%' }} />
          </Form.Item>
          <Form.Item label="リリース日(品保評価終了予定日)">
            <DatePicker style={{ width: '100%' }} />
          </Form.Item>
          <Form.Item label="作製元ブランチ">
            <Select />
          </Form.Item>
          <Form.Item label="ベースとなるリビジョン">
            <Input />
          </Form.Item>
          <Form.Item label="リリース予定のバージョン名">
            <Input />
          </Form.Item>
          <Form.Item label="障害票プレフィクス">
            <Input />
          </Form.Item>
          <Form.Item label="修正1件ごとの修正内容">
            <Input />
          </Form.Item>
          <Form.Item label="リリースするTYPE">
            <Select />
          </Form.Item>
        </div>
        <div>
          <Table columns={columns} dataSource={data} pagination={false} bordered />
        </div>
      </Form>
    </Drawer>
  )
}

const EventWrapperComponent = (props: EventWrapperProps) => {
  const { event: { resource = {} } } = props

  return (
    <Card width='100%' useBoxShadow={false}>
      <Card.Content styles={eventWrapperStyles.defineBase(resource?.nickName)}>
        {Object.values(resource).map((v: any, i: number) => {
          return <p key={i} {...stylex.props(eventWrapperStyles.content)}>{v}</p>
        })}
      </Card.Content>
    </Card>
  )
}

const eventWrapperStyles = stylex.create({
  content: {
    margin: 0,
    textAlign: 'center'
  },
  defineBase: (nickname: string) => ({
    cursor: 'pointer',
    color: 'rgba(0, 0, 0, 0.88)',
    transition: 'all 0.2s',
    backgroundColor: {
      default: nickname === 'BEIGE' ? '#ffda95' : '#aace99',
      ':not(:disabled):hover': nickname === 'BEIGE' ? '#fde4b4' : '#bbe3a8',
    },
  })
})

const HomeCalendarToolbar = (props: ToolbarProps) => {
  const { openModal } = useModal()
  const { date, onNavigate } = props

  return (
    <div {...stylex.props(toolbarStyles.container)}>
      <div {...stylex.props(toolbarStyles.menu)}>
        <Button size="large" onClick={() => onNavigate('TODAY')}>
          今日
        </Button>
        <Button
          type="primary"
          size="large"
          shape="circle"
          icon={<LeftOutlined />}
          onClick={() => onNavigate('PREV')}
        />
        <Button
          type="primary"
          size="large"
          shape="circle"
          icon={<RightOutlined />}
          onClick={() => onNavigate('NEXT')}
        />
        <Button
          size="large"
          onClick={() => {
            openModal('test_modal', TestDrawer, {})
          }}
        >
          新規リリース作成
        </Button>
        <span>{`${date.getFullYear()}年 ${date.getMonth() + 1}月`}</span>
      </div>
      <div {...stylex.props(toolbarStyles.menu)}>
        <Select
          size="large"
          style={{ width: '300px' }}
          defaultValue={'ドメインフィルター'}
        >
          <Select.Option>ドメインフィルター</Select.Option>
        </Select>
        <Select
          size="large"
          style={{ width: '300px' }}
          defaultValue={'チェック担当フィルター'}
        >
          <Select.Option>チェック担当フィルター</Select.Option>
        </Select>
      </div>
    </div>
  )
}

const toolbarStyles = stylex.create({
  container: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '1rem 0'
  },
  menu: {
    display: 'flex',
    alignItems: 'center',
    columnGap: '1rem',
  }
})