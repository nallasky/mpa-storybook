import styled from 'styled-components'
import { Calendar, dayjsLocalizer } from 'react-big-calendar'
import dayjs from 'dayjs'
import "dayjs/locale/ja"

import { HomeCalendarToolbar } from './calendar-toolbar'
import { CalendarEvent } from './calendar-event'

dayjs.locale('ja')
const localizer = dayjsLocalizer(dayjs)

export const HomeCalendar = () => {
  return (
    <CalendarWrapper>
      <Calendar
        defaultView="week"
        startAccessor="start"
        endAccessor="end"
        localizer={localizer}
        events={[
          {
            allDay: true,
            start: new Date(),
            end: new Date(),
            resource: {
              nickName: 'BEIGE',
              version: 'V00.03',
              description: 'a定期リリース'
            }
          },
          {
            allDay: true,
            start: new Date(),
            end: new Date(),
            resource: {
              nickName: 'FLORAL',
              version: 'V03.01',
              description: 'CDCA定期リリース'
            }
          },
        ]}
        components={{ toolbar: HomeCalendarToolbar, eventWrapper: CalendarEvent }}
        selectable
      />
    </CalendarWrapper>
  )
}

const CalendarWrapper = styled.div`
  & .rbc-calendar > div:first-of-type {
    position: sticky;
    top: 88px;
    z-index: 100;
    background-color: white;
  }

  & .rbc-label,
  & .rbc-time-content {
    display: none !important;
  }

  & .rbc-time-header-content {
    border-left: none !important;
  }

  & .rbc-allday-cell {
    min-height: calc(100vh - 291px) !important;
  }

  & .rbc-time-header-cell,
  & .rbc-month-header {
    border-top: 1px solid #ddd;
    position: sticky;
    top: 160px;
    z-index: 100;
    background-color: white;
  }

  & .rbc-month-view {
    border-top: none;
  }

  .rbc-time-view {
    border-top: none;
    & > .rbc-row {
      min-height: unset !important;
    }
  }

  & .rbc-month-view {
    & > .rbc-month-row {
      flex-basis: calc(705px / 5) !important;
      & button {
        pointer-events: none;
      }
      & .rbc-current > button {
        font-weight: bold;
      }
    }
  }

  & .rbc-header {
    padding: 1rem 3px !important;
    & > button.rbc-button-link {
      pointer-events: none;
      & > span {
        font-size: 16px;
      }
    }
    &.rbc-today span {
      font-weight: bold;
    }
  }

  & .rbc-row-segment {
    padding: 0.5rem 0.25rem !important;
  }
`