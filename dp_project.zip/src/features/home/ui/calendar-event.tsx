import styled from 'styled-components'
import { EventWrapperProps } from 'react-big-calendar'

import { Card } from "@shared/ui"
import { useModal } from '@shared/lib'
import { ReleaseDrawer } from './release-drawer'

export const CalendarEvent = (props: EventWrapperProps) => {
  const { event: { resource = {} } } = props
  const { openModal } = useModal()

  return (
    <Card width="100%" useBoxShadow={false}>
      <Card.Content css={{ padding: 0 }}>
        <ContentWrapper $nickName={resource?.nickName ?? ''}>
          <button onClick={() => openModal('edit-release-drawer', ReleaseDrawer)}>
            {Object.values(resource).map((v: any, i: number) => (
              <p key={i}>{v}</p>
            ))}
          </button>
        </ContentWrapper>
      </Card.Content>
    </Card>
  )
}

const ContentWrapper = styled.div<{ $nickName: string }>`
  cursor: pointer;
  padding: 1rem;
  color: rgba(0, 0, 0, 0.88);
  transition: all 0.2s;
  background-color: ${({ $nickName }) => $nickName === 'BEIGE' ? '#ffda95' : '#aace99'};
  &:not(:disabled):hover {
    background-color: ${({ $nickName }) => $nickName === 'BEIGE' ? '#fde4b4' : '#bbe3a8'};
  }
  & > button {
    width: 100%;
    font-size: 16px;
    border: none;
    background-color: transparent;
    cursor: pointer;
    & > p {
      margin: 0;
      text-align: center;
    }
  }
`