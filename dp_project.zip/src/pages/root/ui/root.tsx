import * as stylex from '@stylexjs/stylex'

import { RootHeader, RootContent } from '@widgets/root'

export const Root = () => {
  return (
    <main>
      <section {...stylex.props(rootStyle.base)}>
        <RootHeader />
        <RootContent />
      </section>
    </main>
  )
}

const rootStyle = stylex.create({
  base: {
    width: '1680px',
    margin: '0 auto',
  },
})
