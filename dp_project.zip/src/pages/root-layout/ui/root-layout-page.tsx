import { Fragment } from "react"

import { Navbar } from "@widgets/navbar"
import { Footer } from "@widgets/footer"

export const RootLayoutPage = ({ children }: { children: React.ReactNode }) => {
  return (
    <Fragment>
      <Navbar />
      {children}
      <Footer />
    </Fragment>
  )
}