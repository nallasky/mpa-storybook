import * as stylex from '@stylexjs/stylex'

import { Card } from '@shared/ui'
import { LoginForm } from '@features/login'

export const Login = () => {
  return (
    <main {...stylex.props(loginStyles.base)}>
      <section {...stylex.props(loginStyles.container)}>
        <Card>
          <Card.Header
            title="Login"
            useBottomBorder={false}
            styles={loginStyles.cardHeader}
          />
          <Card.Content styles={loginStyles.cardContent}>
            <LoginForm />
          </Card.Content>
        </Card>
      </section>
    </main>
  )
}

const loginStyles = stylex.create({
  base: {
    width: '100%',
    backgroundColor: '#e7f8fb',
  },
  container: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '1680px',
    margin: '0 auto',
    minHeight: '100vh',
  },
  cardHeader: {
    padding: '3rem 2rem',
  },
  cardContent: {
    padding: '1rem 2rem 3rem',
  }
})
