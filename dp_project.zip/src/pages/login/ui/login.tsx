import styled from 'styled-components'

import { LoginForm } from '@features/login'

export const Login = () => {
  return (
    <PageWrapper>
      <section className="login-page-container">
        <LoginForm />
      </section>
    </PageWrapper>
  )
}

const PageWrapper = styled.main`
  width: 100%;
  background-color: #e7f8fb;
  & > .login-page-container {
    display: flex;
    align-items: center;
    justify-content: center;
    width: var(--default-page-width);
    margin: 0 auto;
    min-height: 100vh;
  }
`