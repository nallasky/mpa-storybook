import * as stylex from '@stylexjs/stylex'

import { LoginFormCard } from '@widgets/login'

export const Login = () => {
  return (
    <main {...stylex.props(mainStyles.base)}>
      <section {...stylex.props(sectionStyles.base)}>
        <LoginFormCard />
      </section>
    </main>
  )
}

const mainStyles = stylex.create({
  base: {
    width: '100%',
    backgroundColor: '#e7f8fb',
  },
})

const sectionStyles = stylex.create({
  base: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '1680px',
    margin: '0 auto',
    minHeight: '100vh',
  },
})
