import styled from 'styled-components'

import { RootLayoutPage } from '@pages/root-layout'
import { HomeCalendar } from '@features/home'

export const Home = () => {
  return (
    <RootLayoutPage>
      <main>
        <PageContainer>
          <HomeCalendar />
        </PageContainer>
      </main>
    </RootLayoutPage>
  )
}

const PageContainer = styled.section`
  width: var(--default-page-width);
  margin: 0 auto;
`
