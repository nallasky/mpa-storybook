import * as stylex from '@stylexjs/stylex'

import { HomeCalendar } from '@features/home'

export const Home = () => {
  return (
    <main>
      <section {...stylex.props(homeStyle.container)}>
        <HomeCalendar />
      </section>
    </main>
  )
}

const homeStyle = stylex.create({
  container: {
    width: '1680px',
    margin: '0 auto',
  },
})
