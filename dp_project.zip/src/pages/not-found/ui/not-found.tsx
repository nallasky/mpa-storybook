import { useNavigate } from 'react-router-dom'
import styled from 'styled-components'
import { Button } from 'antd'
import { UndoOutlined } from '@ant-design/icons'
import Lottie from 'react-lottie-player'

import lottieJson from '../constants/not-found-animation.json'

export const NotFound = () => {
  const navigate = useNavigate()

  return (
    <PageWrapper>
      <div className="not-found-page-content">
        <Lottie loop play animationData={lottieJson} style={{ width: 600 }} />
        <p className="description">Page not found.</p>
        <Button
          type="primary"
          size="large"
          style={{ width: 240 }}
          icon={<UndoOutlined />}
          onClick={() => {
            navigate(`${import.meta.env.VITE_DEFAULT_URL}/home`, { unstable_viewTransition: true })
          }}
        >
          Return to the Main page
        </Button>
      </div>
    </PageWrapper>
  )
}

const PageWrapper = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  & > .not-found-page-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    row-gap: 1rem;
    & > .description {
      font-size: 24px;
      font-weight: bold;
    }
  }
`