import { BrowserRouter, Routes, Route } from 'react-router-dom'

import { Login as LoginPage } from '@pages/login'
import { Root as RootPage } from '@pages/root'
import { Navbar } from '@widgets/navbar'
import { Footer } from '@widgets/footer'

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/main" element={<RootPage />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  )
}

export default App
