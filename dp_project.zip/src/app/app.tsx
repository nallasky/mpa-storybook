import { Fragment } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'

import { Login as LoginPage } from '@pages/login'
import { Home as HomePage } from '@pages/home'
import { Navbar } from '@widgets/navbar'
import { Footer } from '@widgets/footer'
import { GlobalModal } from '@shared/lib'

function App() {
  const location = useLocation()

  return (
    <Fragment>
      {location.pathname === '/home' && <Navbar />}
      <Routes>
        <Route path="*" element={<LoginPage />} />
        <Route path="/home" element={<HomePage />} />
      </Routes>
      {location.pathname === '/home' && <Footer />}
      <GlobalModal />
    </Fragment>
  )
}

export default App
