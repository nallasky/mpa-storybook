import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import { ConfigProvider } from 'antd'
import ja_JP from 'antd/es/locale/ja_JP'

import { Login as LoginPage } from '@pages/login'
import { Home as HomePage } from '@pages/home'
import { NotFound as NotFoundPage } from '@pages/not-found'
import { GlobalModal, GlobalModalProvider } from '@shared/lib'

const defaultUrl = import.meta.env.VITE_DEFAULT_URL

const router = createBrowserRouter([
  {
    path: defaultUrl,
    element: <LoginPage />,
  },
  {
    path: `${defaultUrl}/home`,
    element: <HomePage />
  },
  {
    path: '*',
    element: <NotFoundPage />
  },
])

function App() {
  return (
    <ConfigProvider locale={ja_JP}>
      <GlobalModalProvider>
        <RouterProvider router={router} />
        <GlobalModal />
      </GlobalModalProvider>
    </ConfigProvider>
  )
}

export default App
