import React from 'react'
import * as stylex from '@stylexjs/stylex'

// Card Global Value
const CARD_PADDING = '1rem'
const CARD_INNER_BORDER = '1px solid #f0f0f0'

// Card Container

type CardProps = {
  width?: number
  useRoundedRadius?: boolean
  useBoxShadow?: boolean
  styles?: stylex.StyleXStyles
  children: React.ReactNode
}

export const Card = ({
  width = 400,
  useBoxShadow = true,
  useRoundedRadius = true,
  styles = {},
  children,
}: CardProps) => {
  return (
    <div
      {...stylex.props(
        cardStyles.default,
        cardStyles.defineWidth(width),
        cardStyles.defineBoxShadow(useBoxShadow),
        cardStyles.defineBorderRadius(useRoundedRadius),
        styles,
      )}
    >
      {children}
    </div>
  )
}

const cardStyles = stylex.create({
  default: {
    backgroundColor: 'white',
  },
  defineWidth: (width: number) => ({
    width: `${width}px`,
  }),
  defineBorderRadius: (useRoundedRadius: boolean) => ({
    borderRadius: useRoundedRadius ? '4px' : '0px',
  }),
  defineBoxShadow: (useBoxShadow: boolean) => ({
    boxShadow: useBoxShadow
      ? '0 1px 2px 0 rgba(60, 64, 67, 0.3), 0 2px 6px 2px rgba(60, 64, 67, 0.15)'
      : 'none',
  }),
})

// Card Header

type CardHeaderProps = {
  fontSize?: number
  useBottomBorder?: boolean
  styles?: stylex.StyleXStyles
  title: string
}

const CardHeader = ({
  fontSize = 32,
  useBottomBorder = true,
  styles = {},
  title,
}: CardHeaderProps): React.ReactNode => {
  return (
    <div
      {...stylex.props(
        cardHeaderStyles.default,
        cardHeaderStyles.defineFontSize(fontSize),
        cardHeaderStyles.defineBorder(useBottomBorder),
        styles,
      )}
    >
      {title}
    </div>
  )
}

const cardHeaderStyles = stylex.create({
  default: {
    fontWeight: 'bold',
    padding: CARD_PADDING,
  },
  defineFontSize: (size: number) => ({
    fontSize: `${size}px`,
  }),
  defineBorder: (useBorder: boolean) => ({
    borderBottom: useBorder ? CARD_INNER_BORDER : 'none',
  }),
})

Card.Header = CardHeader

// Card Content

type CardContentProps = {
  styles?: stylex.StyleXStyles
  children: React.ReactNode
}

const CardContent = ({ styles = {}, children }: CardContentProps) => {
  return (
    <div {...stylex.props(cardContentStyles.default, styles)}>{children}</div>
  )
}

const cardContentStyles = stylex.create({
  default: {
    padding: CARD_PADDING,
  },
})

Card.Content = CardContent

// Card Footer

type CardFooterProps = {
  useTopBorder?: boolean
  styles?: stylex.StyleXStyles
  children: React.ReactNode
}

const CardFooter = ({
  useTopBorder = true,
  styles = {},
  children,
}: CardFooterProps) => {
  return (
    <div
      {...stylex.props(
        cardFooterStyles.default,
        cardFooterStyles.defineBorder(useTopBorder),
        styles,
      )}
    >
      {children}
    </div>
  )
}

const cardFooterStyles = stylex.create({
  default: {
    padding: CARD_PADDING,
  },
  defineBorder: (useBorder: boolean) => ({
    borderTop: useBorder ? CARD_INNER_BORDER : 'none',
  }),
})

Card.Footer = CardFooter
