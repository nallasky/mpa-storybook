import React from 'react'
import styled, { CSSProp } from 'styled-components'

// Card Global Value
const CARD_PADDING = '1rem'
const CARD_INNER_BORDER = '1px solid #f0f0f0'

// Card Container
type CardProps = {
  width?: number | string
  useRoundedRadius?: boolean
  useBoxShadow?: boolean
  css?: CSSProp,
  children: React.ReactNode
}

export const Card = ({ children, width, useRoundedRadius, useBoxShadow, css }: CardProps) => {
  return (
    <CardWrapper
      $width={width}
      $useRoundedRadius={useRoundedRadius}
      $useBoxShadow={useBoxShadow}
      $css={css}
    >
      {children}
    </CardWrapper>
  )
}

type CardWrapperProps = {
  $width?: number | string
  $useRoundedRadius?: boolean
  $useBoxShadow?: boolean
  $css?: CSSProp,
}

const CardWrapper = styled.div<CardWrapperProps>`
  background-color: white;
  width: ${({ $width = 400 }) => typeof $width === 'number' ? `${$width}px` : $width};
  border-radius: ${({ $useRoundedRadius = true }) => $useRoundedRadius ? '4px' : 0};
  box-shadow: ${({ $useBoxShadow = true }) =>
    $useBoxShadow
      ? '0 1px 2px 0 rgba(60, 64, 67, 0.3), 0 2px 6px 2px rgba(60, 64, 67, 0.15)'
      : 'none'
  };
  ${({ $css = '' }) => $css}
`
// Card Header

type CardHeaderProps = {
  fontSize?: number
  useBottomBorder?: boolean
  css?: CSSProp
  title: string
}

const CardHeader = ({ title, useBottomBorder, css, fontSize }: CardHeaderProps) => {
  return (
    <CardHeaderWrapper
      $fontSize={fontSize}
      $useBottomBorder={useBottomBorder}
      $css={css}
    >
      {title}
    </CardHeaderWrapper>
  )
}

type CardHeaderWrapperProps = {
  $fontSize?: number
  $useBottomBorder?: boolean
  $css?: CSSProp
}

const CardHeaderWrapper = styled.div<CardHeaderWrapperProps>`
  font-weight: bold;
  font-size: ${({ $fontSize = 32 }) => `${$fontSize}px`};
  border-bottom: ${({ $useBottomBorder = true }) => $useBottomBorder ? CARD_INNER_BORDER : 'none'};
  padding: ${CARD_PADDING};
  ${({ $css = '' }) => $css}
`

Card.Header = CardHeader

// Card Content
type CardContentProps = {
  css?: CSSProp
  children: React.ReactNode
}

const CardContent = ({ css = '', children }: CardContentProps) => {
  return (
    <CardContentWrapper $css={css}>{children}</CardContentWrapper>
  )
}

type CardContentWrapperProps = {
  $css?: CSSProp
}

const CardContentWrapper = styled.div<CardContentWrapperProps>`
  padding: ${CARD_PADDING};
  ${({ $css }) => $css}
`

Card.Content = CardContent

// Card Footer
type CardFooterProps = {
  useTopBorder?: boolean
  css?: CSSProp
  children: React.ReactNode
}

const CardFooter = ({ children, useTopBorder, css }: CardFooterProps) => {
  return (
    <CardFooterWrapper $useTopBorder={useTopBorder} $css={css}>
      {children}
    </CardFooterWrapper>
  )
}

type CardFooterWrapperProps = {
  $useTopBorder?: boolean
  $css?: CSSProp
}

const CardFooterWrapper = styled.div<CardFooterWrapperProps>`
  padding: ${CARD_PADDING};
  border-top: ${({ $useTopBorder = true }) => $useTopBorder ? CARD_INNER_BORDER : 'none'};
  ${({ $css = '' }) => $css}
`

Card.Footer = CardFooter
