import React, { useState, createContext } from 'react'
import { flushSync } from 'react-dom'
import { ModalProps, DrawerProps } from 'antd'

export type GlobalModalDefaultProps<T = object> = {
  open: boolean
  onClose: () => void
} & T


export type GlobalModalProps<T = any> = {
  Component: React.FunctionComponent<any>
  props?: ModalProps & T | DrawerProps & T
}

export type GlobalModalDispatchContextProps = {
  open: (key: string, Component: GlobalModalProps['Component'], props: GlobalModalProps['props']) => void
  close: (key: string) => void
}

export const GlobalModalDispatchContext = createContext<GlobalModalDispatchContextProps>({
  open: () => { },
  close: () => { },
});

export const GlobalModalStateContext = createContext(new Map<string, GlobalModalProps>());

export const GlobalModalProvider = ({ children }: { children: React.ReactNode }) => {
  const [openedModals, setOpenedModals] = useState<Map<string, GlobalModalProps>>(new Map())

  const open = (key: string, Component: GlobalModalProps['Component'], props?: GlobalModalProps['props']) => {
    setOpenedModals((prev) => new Map(prev).set(key, { Component, props: { ...props, open: true } }))
  };

  const close = (key: string) => {
    flushSync(() => {
      setOpenedModals((modals) => {
        const foundModal = modals.get(key)
        if (foundModal) {
          modals.set(key, { ...foundModal, props: { ...foundModal.props, open: false } })
        }
        return new Map(modals)
      });
    });

    setTimeout(() => {
      setOpenedModals((modals) => {
        modals.delete(key);
        return new Map(modals);
      });
    }, 350);
  };

  const dispatch = { open, close }

  return (
    <GlobalModalStateContext.Provider value={openedModals}>
      <GlobalModalDispatchContext.Provider value={dispatch}>{children}</GlobalModalDispatchContext.Provider>
    </GlobalModalStateContext.Provider>
  );
}