import { useContext } from 'react'

import { GlobalModalProps, GlobalModalDispatchContext } from '../modal-context'

export const useModal = () => {
  const { open, close } = useContext(GlobalModalDispatchContext) ?? {}

  if (!open || !close) {
    throw new Error('useModal must be used within a GlobalModalProvider')
  }

  const openModal = <T>(
    key: string,
    Component: GlobalModalProps<T>['Component'],
    props?: GlobalModalProps<T>['props'],
  ) => {
    open(key, Component, props ?? {})
  }

  const closeModal = (key: string) => {
    close(key)
  }

  return { openModal, closeModal }
}
