import { Fragment, useContext } from "react"
import { GlobalModalDispatchContext, GlobalModalStateContext } from "."

export const GlobalModal = () => {
  const openedModals = useContext(GlobalModalStateContext)
  const { close } = useContext(GlobalModalDispatchContext)

  return (
    <Fragment>
      {
        Array.from(openedModals).map(([key, value]) => {
          const { Component, props } = value;
          return (
            <Component
              {...props}
              key={key}
              onClose={() => close(key)}
            />
          );
        })
      }
    </Fragment>
  )
}