import React, { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router';
import PropTypes from 'prop-types';
import {
  Table,
  Button,
  DatePicker,
  Select,
  Checkbox,
  Input,
  Empty,
} from 'antd';
import dayjs from 'dayjs';
import { SettingOutlined, SyncOutlined } from '@ant-design/icons';
import { getAnalysisData } from '../../../../lib/api/axios/requests';
import { default as Btn } from '../../../UI/atoms/Button';
import { DATE_FORMAT } from '../../../../lib/api/Define/etc';
import useResultInfo from '../../../../hooks/useResultInfo';
import * as fn from './functionGroup';
import * as sg from './styleGroup';

const { RangePicker } = DatePicker;
const { Option } = Select;

const AnalysisTable = React.memo(
  ({
    period,
    filter,
    aggregation,
    tableOrder,
    tableData,
    type,
    onLoad,
    useUpdate,
  }) => {
    const {
      selectedRow,
      savedAnalysisAggregation,
      setSelectedRow,
    } = useResultInfo();
    const [columnData, setColumnData] = useState([]);
    const [rowData, setRowData] = useState([]);
    const [innerSelectedRow, setInnerSelectedRow] = useState([]);

    const changeRowData = useCallback((v) => {
      setRowData(v);
    }, []);

    const changeSelectedRow = useCallback(
      (v) => {
        const findKey =
          savedAnalysisAggregation.main.toLowerCase() === 'period'
            ? 'period'
            : savedAnalysisAggregation.main.toLowerCase().indexOf('all') === -1
            ? savedAnalysisAggregation.sub
            : undefined;
        setInnerSelectedRow(v);

        if (findKey !== undefined) {
          setSelectedRow(v.map((i) => tableData[i][findKey]));
        } else {
          setSelectedRow(['all']);
        }
      },
      [savedAnalysisAggregation, tableData],
    );

    useEffect(() => {
      setColumnData(fn.initColumnData(tableOrder));
    }, [JSON.stringify(tableOrder)]);

    useEffect(() => {
      setRowData(
        type === 'analysis' || useUpdate
          ? fn.createDataSource(tableData)
          : fn.filteringData(
              fn.createDataSource(tableData),
              fn.initFilterValue(filter),
            ),
      );
    }, [JSON.stringify(tableData), type, JSON.stringify(filter)]);

    useEffect(() => {
      if (selectedRow.length === 0) {
        setInnerSelectedRow([]);
      }
    }, [selectedRow]);

    return (
      <div css={sg.mainWrapper}>
        {filter !== undefined &&
        filter.length === 0 &&
        aggregation !== undefined &&
        Object.keys(aggregation).length === 0 &&
        period.start === null &&
        period.end === null &&
        period.select.length === 0 ? (
          ''
        ) : (
          <HeaderSetting
            period={period}
            filter={filter}
            aggregation={aggregation}
            type={type}
            loadingSet={onLoad}
            orgData={tableData}
            rowSet={
              type !== 'analysis' || !useUpdate ? changeRowData : undefined
            }
            useUpdate={useUpdate}
          />
        )}
        {rowData.length > 0 && columnData.length > 0 ? (
          <div className="table-wrapper">
            <div>
              {type === 'analysis' ? 'Analysis Result' : 'Original Data'}
            </div>
            <div>
              <Table
                pagination={false}
                scroll={{ x: 'max-content', y: 400 }}
                dataSource={rowData}
                columns={columnData}
                rowSelection={
                  type === 'analysis'
                    ? {
                        selectedRowKeys: innerSelectedRow,
                        getCheckboxProps: (v) => ({
                          disabled: v['No.'] === 'ALL',
                        }),
                        onChange: (v) => changeSelectedRow(v),
                      }
                    : undefined
                }
              />
            </div>
          </div>
        ) : (
          <div css={sg.emptyWrapper}>
            <Empty />
          </div>
        )}
      </div>
    );
  },
  (prevProps, nextProps) =>
    JSON.stringify(prevProps) === JSON.stringify(nextProps),
);

AnalysisTable.displayName = 'AnalysisTable';
AnalysisTable.propTypes = {
  period: PropTypes.object.isRequired,
  filter: PropTypes.array.isRequired,
  aggregation: PropTypes.object,
  tableOrder: PropTypes.array.isRequired,
  tableData: PropTypes.object.isRequired,
  type: PropTypes.string.isRequired,
  onLoad: PropTypes.func,
  useUpdate: PropTypes.bool.isRequired,
};

const HeaderSetting = React.memo(
  ({
    period,
    filter,
    aggregation,
    type,
    loadingSet,
    orgData,
    rowSet,
    useUpdate,
  }) => {
    const { func_id, job_id } = useLocation().state;
    const {
      setAnalysisInfo,
      setOriginalInfo,
      setOriginalFilteredRows,
      setSelectedRow,
      setSavedAnalysisAggregation,
    } = useResultInfo();
    const [periodVal, setPeriodVal] = useState(['', '']);
    const [showPopup, setShowPopup] = useState(false);
    const [filterVal, setFilterVal] = useState({});
    const [aggregationVal, setAggregationVal] = useState({});
    const [beforeInfo, setBeforeInfo] = useState({
      filter: {},
      aggregation: {},
    });

    const closeRangePicker = () => {
      if (showPopup) {
        setShowPopup(false);
      }
    };

    const closePopup = () => {
      setShowPopup(false);
      setFilterVal(beforeInfo.filter);
      setAggregationVal(beforeInfo.aggregation);
    };

    const changeFilter = (key, val) => {
      setFilterVal((prevState) => {
        return {
          ...prevState,
          [key]: val,
        };
      });
    };

    const changeAggregation = (key, val) => {
      setAggregationVal((prevState) => {
        if (key === 'main' && val.toLowerCase().indexOf('all') === -1) {
          return {
            main: val,
            sub: aggregation.subItem[val].selected,
          };
        } else {
          return {
            ...prevState,
            [key]: val,
          };
        }
      });
    };

    const changeAll = (key, index) => {
      if (filterVal[key] === undefined) {
        changeFilter(key, filter[index].options);
      } else {
        filterVal[key].length === filter[index].options.length
          ? changeFilter(key, [])
          : changeFilter(key, filter[index].options);
      }
    };

    const changePeriod = (date) => {
      setPeriodVal(date);
    };

    const applyFilter = async () => {
      setShowPopup(false);
      loadingSet(true);
      if (type === 'analysis' || useUpdate) {
        let isAggError = false;

        if (
          Object.keys(aggregation).length > 0 &&
          aggregationVal.main.indexOf('all') === -1 &&
          (aggregationVal.sub === null || aggregationVal.sub === '')
        ) {
          isAggError = true;
        }

        if (isAggError) {
          fn.displayError();
        } else {
          setAnalysisInfo({
            period: {},
            filter: [],
            aggregation: {},
            dispOrder: [],
            dispGraph: [],
            data: {},
          });
          setOriginalFilteredRows({});
          setOriginalInfo({
            period: {},
            filter: [],
            aggregation: {},
            dispOrder: [],
            dispGraph: [],
            data: {},
          });
          setSelectedRow([]);
          const param = {
            fId: func_id,
            rId: job_id,
            start:
              periodVal === null || periodVal[0].length === 0
                ? period.start
                : periodVal[0].format(DATE_FORMAT),
            end:
              periodVal === null || periodVal[1].length === 0
                ? period.end
                : periodVal[1].format(DATE_FORMAT),
            agMain: aggregationVal.main,
            agSub: aggregationVal.sub,
            filter: filterVal,
          };

          const { data, option } = await getAnalysisData(param);
          setAnalysisInfo({
            period: option.period,
            filter: option.filter,
            aggregation: option.aggregation ?? {},
            dispOrder: data.disp_order,
            dispGraph: data.disp_graph,
            data: data.row,
          });
        }
      } else {
        rowSet(fn.filteringData(fn.createDataSource(orgData), filterVal));
        setOriginalFilteredRows(
          fn.createGraphData(fn.createDataSource(orgData), filterVal),
        );
      }
      setBeforeInfo({
        filter: filterVal,
        aggregation: aggregationVal,
      });
      loadingSet(false);
    };

    const disabledDate = useCallback(
      (v) => {
        return Object.keys(period).length === 0
          ? false
          : v &&
              (dayjs(v).isBefore(dayjs(period.start), 'd') ||
                dayjs(v).isAfter(dayjs(period.end), 'd'));
      },
      [JSON.stringify(period)],
    );

    useEffect(() => {
      setPeriodVal(fn.initPeriod(period));
    }, [period]);

    useEffect(() => {
      const newFilter = fn.initFilterValue(filter);
      setFilterVal(newFilter);
      setBeforeInfo((prevState) => {
        return {
          ...prevState,
          filter: newFilter,
        };
      });
    }, [filter]);

    useEffect(() => {
      const newAgg = fn.initAggregation(aggregation);
      setAggregationVal(newAgg);
      setBeforeInfo((prevState) => {
        return {
          ...prevState,
          aggregation: newAgg,
        };
      });
      if (type === 'analysis') {
        setSavedAnalysisAggregation(newAgg);
      }
    }, [aggregation]);

    useEffect(() => {
      return () => {
        if (type !== 'analysis') {
          setOriginalFilteredRows({});
          setOriginalInfo({});
        }
        return null;
      };
    }, []);

    return (
      <div className="header-wrapper">
        <div className="popup-wrapper">
          <span>Period:</span>
          <RangePicker
            value={periodVal}
            onOpenChange={closeRangePicker}
            onChange={changePeriod}
            disabledDate={disabledDate}
            disabled={!useUpdate}
            showTime
            placeholder={[period.start, period.end]}
            inputReadOnly
          />
          {filter !== undefined &&
          filter.length === 0 &&
          aggregation !== undefined &&
          Object.keys(aggregation).length === 0 ? (
            ''
          ) : (
            <>
              <div className="filter-component">
                <Button
                  type="dashed"
                  shape="circle"
                  icon={<SettingOutlined />}
                  onClick={() => setShowPopup(true)}
                />
                <div>Filter Setting</div>
                <div
                  css={[
                    sg.popupBackground,
                    showPopup ? { display: 'block' } : '',
                  ]}
                  onClick={() => closePopup()}
                  onKeyDown={() => closePopup()}
                  role="button"
                  tabIndex="0"
                />
                <div
                  css={[sg.popupStyle, showPopup ? { display: 'block' } : '']}
                >
                  <div>Filter Setting</div>
                  <div>
                    {Array.isArray(filter) &&
                      filter.map((v, i) => {
                        return (
                          <div key={v.target}>
                            <div>{v.title + ':'}</div>
                            <div css={sg.selectWrapper}>
                              <Select
                                mode={v.mode === 'plural' ? 'multiple' : ''}
                                showArrow
                                maxTagCount="responsive"
                                value={filterVal[v.target]}
                                onChange={(val) => changeFilter(v.target, val)}
                                style={{ fontSize: '12px', width: '100%' }}
                              >
                                {v.options.map((v) => (
                                  <Option value={v} key={v}>
                                    {v}
                                  </Option>
                                ))}
                              </Select>
                              {v.mode === 'plural' ? (
                                <Checkbox
                                  checked={
                                    filterVal[v.target] === undefined ||
                                    filterVal[v.target] === null
                                      ? false
                                      : filterVal[v.target].length ===
                                        filter[i].options.length
                                  }
                                  onChange={() => changeAll(v.target, i)}
                                >
                                  All
                                </Checkbox>
                              ) : (
                                ''
                              )}
                            </div>
                          </div>
                        );
                      })}
                    {aggregation !== undefined &&
                    Object.keys(aggregation).length > 0 &&
                    Object.keys(aggregationVal).length > 0 ? (
                      <div>
                        <div>{aggregation.title + ':'}</div>
                        <div
                          css={
                            aggregationVal.main.toLowerCase().indexOf('all') !==
                            -1
                              ? sg.aggSingleItemWrapper
                              : sg.aggregationWrapper
                          }
                        >
                          <Select
                            value={aggregationVal.main}
                            style={{ fontSize: '12px', width: '100%' }}
                            onChange={(val) => changeAggregation('main', val)}
                          >
                            {aggregation.options.map((v) => (
                              <Option value={v} key={v}>
                                {v}
                              </Option>
                            ))}
                          </Select>
                          {aggregationVal.main.toLowerCase().indexOf('all') ===
                            -1 &&
                          aggregation.subItem[aggregationVal.main] !==
                            undefined ? (
                            aggregation.subItem[aggregationVal.main].type ===
                            'select' ? (
                              <Select
                                value={aggregationVal.sub}
                                style={{
                                  fontSize: '12px',
                                  width: '100%',
                                  marginLeft: '0.5rem',
                                }}
                                onChange={(val) =>
                                  changeAggregation('sub', val)
                                }
                              >
                                {aggregation.subItem[
                                  aggregationVal.main
                                ].options.map((v) => (
                                  <Option value={v} key={v}>
                                    {v}
                                  </Option>
                                ))}
                              </Select>
                            ) : (
                              <Input
                                value={aggregationVal.sub}
                                style={{
                                  fontSize: '12px',
                                  marginLeft: '0.5rem',
                                }}
                                onChange={(e) =>
                                  changeAggregation('sub', e.target.value)
                                }
                              />
                            )
                          ) : (
                            ''
                          )}
                        </div>
                      </div>
                    ) : (
                      ''
                    )}
                  </div>
                  <div>
                    <Button type="primary" onClick={applyFilter}>
                      {type === 'analysis' || useUpdate ? 'Save' : 'Apply'}
                    </Button>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
        <div>
          {type === 'analysis' || useUpdate ? (
            <Btn
              theme="white"
              style={{ fontWeight: 'normal' }}
              onClick={applyFilter}
            >
              <SyncOutlined /> Update
            </Btn>
          ) : (
            ''
          )}
        </div>
      </div>
    );
  },
  (prevProps, nextProps) =>
    JSON.stringify(prevProps) === JSON.stringify(nextProps),
);

HeaderSetting.displayName = 'HeaderSetting';
HeaderSetting.propTypes = {
  period: PropTypes.object.isRequired,
  filter: PropTypes.array.isRequired,
  aggregation: PropTypes.object,
  type: PropTypes.string.isRequired,
  loadingSet: PropTypes.func,
  orgData: PropTypes.object.isRequired,
  rowSet: PropTypes.func,
  useUpdate: PropTypes.bool.isRequired,
};

export default AnalysisTable;
