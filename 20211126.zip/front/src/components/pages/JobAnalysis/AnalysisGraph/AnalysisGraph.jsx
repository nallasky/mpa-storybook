import React, { useEffect, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { Button, Empty, Popconfirm } from 'antd';
import {
  CloseCircleFilled,
  LineChartOutlined,
  SettingFilled,
} from '@ant-design/icons';
import { drawGraph } from './functionGroup';
import GraphAddEdit from '../../../UI/organisms/GraphAddEdit/GraphAddEdit';
import useResultInfo from '../../../../hooks/useResultInfo';
import * as sg from './styleGroup';

const AnalysisGraph = React.memo(({ rows, info, type }) => {
  const {
    visualization,
    analysisGraphInfo,
    originalGraphInfo,
    setAnalysisGraphInfo,
    setOriginalGraphInfo,
  } = useResultInfo();
  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState('');
  const [currentIdx, setCurrentIdx] = useState('');

  const onAddGraph = useCallback(() => {
    setIsOpen(true);
    setMode('add');
  }, []);

  const onEdit = useCallback((idx) => {
    setCurrentIdx(idx);
    setMode('edit');
    setIsOpen(true);
  }, []);

  const onDelete = useCallback(
    (idx) => {
      if (type === 'analysis') {
        setAnalysisGraphInfo(
          analysisGraphInfo.filter((v, i) => {
            return i !== idx;
          }),
        );
      } else {
        setOriginalGraphInfo(
          originalGraphInfo.filter((v, i) => {
            return i !== idx;
          }),
        );
      }
    },
    [analysisGraphInfo, originalGraphInfo, type],
  );

  useEffect(() => {
    if (info.length > 0 && Object.keys(rows).length > 0) {
      drawGraph(rows, info, visualization, type);
    }
  }, [rows, info, visualization, type]);

  if (Object.keys(rows).length === 0) return '';

  return (
    <>
      <div css={sg.mainWrapper}>
        <div>
          <span>Visualization</span>
          <Button
            type="dashed"
            icon={<LineChartOutlined />}
            onClick={onAddGraph}
          >
            Add Graph
          </Button>
        </div>
        <div>
          <div css={info.length > 0 ? sg.graphBodyStyle : sg.emptyWrapper}>
            {info.length > 0 ? (
              info.map((k, i) => {
                return (
                  <div key={i} css={sg.graphWrapper}>
                    <div>
                      <Button
                        type="dashed"
                        shape="round"
                        icon={<SettingFilled />}
                        onClick={() => onEdit(i)}
                      >
                        Edit
                      </Button>
                      <Popconfirm
                        title="Are you sure you want to delete this graph?"
                        onConfirm={() => onDelete(i)}
                      >
                        <Button
                          type="dashed"
                          shape="round"
                          icon={<CloseCircleFilled />}
                        >
                          Delete
                        </Button>
                      </Popconfirm>
                    </div>
                    <div id={`${type}_graph_${i}`} />
                  </div>
                );
              })
            ) : (
              <Empty description="No graphs to display." />
            )}
          </div>
        </div>
      </div>
      <GraphAddEdit
        closer={() => setIsOpen(false)}
        isOpen={isOpen}
        mode={mode}
        index={currentIdx}
        type={type}
      />
    </>
  );
});
AnalysisGraph.propTypes = {
  rows: PropTypes.object.isRequired,
  info: PropTypes.array.isRequired,
  type: PropTypes.string,
};
AnalysisGraph.defaultProps = {
  type: 'analysis',
};
AnalysisGraph.displayName = 'AnalysisGraph';

export default AnalysisGraph;
