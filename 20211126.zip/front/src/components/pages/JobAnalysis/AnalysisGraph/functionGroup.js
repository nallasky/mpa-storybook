import Plotly from 'plotly.js-dist';

const createXZaxisData = (rows, key) => {
  const tmpArr = [];

  if (key !== '0' && key !== '' && key !== null) {
    Object.values(rows).some((v) => {
      if ((v['No.'] === undefined || v['No.'] !== 'ALL') && v[key]) {
        tmpArr.push(v[key]);
      }
    });
  }

  return tmpArr;
};

export const createAxisData = (rows, keys) => {
  const tmpObj = {};

  if (keys.y.length > 0) {
    keys.y.reduce((acc, v) => {
      const tmpArr = [];
      Object.values(rows).some((z) => {
        if ((z['No.'] === undefined || z['No.'] !== 'ALL') && z[v]) {
          tmpArr.push(z[v]);
        }
      });
      acc[v] = tmpArr;
      return acc;
    }, tmpObj);
  }

  return {
    xaxisData: createXZaxisData(rows, keys.x),
    yaxisData: tmpObj,
    zaxisData: createXZaxisData(rows, keys.z),
  };
};

export const drawGraph = (rows, items, ref, type) => {
  items.some((v, i) => {
    const currentInfo = ref.graph_list.find((z) => z.name === v.type[0]);
    const currentScript = ref.function_graph_type.find((x) => {
      return currentInfo.type === 'user'
        ? x.name === currentInfo.name
        : x.type === currentInfo.type;
    }).script;
    const newFunc = new Function('return ' + currentScript)();
    const { xaxisData, yaxisData, zaxisData } = createAxisData(rows, {
      x: v.x_axis,
      y: v.y_axis,
      z: v.z_axis,
    });

    const params = {
      type: v.type,
      x: xaxisData,
      y: yaxisData,
      z: zaxisData,
      title: v.title,
      range: {
        x: v.x_range_min !== '' ? [v.x_range_min, v.x_range_max] : [],
        y: v.y_range_min !== '' ? [v.y_range_min, v.y_range_max] : [],
        z: v.z_range_min !== '' ? [v.z_range_min, v.z_range_max] : [],
      },
    };
    newFunc(Plotly, document.getElementById(`${type}_graph_${i}`), params);
  });
};
