import { Button, Input, InputNumber, Popconfirm, Select } from 'antd';
import { MSG_CONFIRM_DELETE } from '../../../lib/api/Define/Message';
import { DeleteOutlined } from '@ant-design/icons';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
const { Option } = Select;

const DeleteComponent = ({ record, type, deleteHandler, disabled }) => {
  return (
    <>
      {' '}
      <Popconfirm
        title={MSG_CONFIRM_DELETE}
        onConfirm={() => deleteHandler(record.key, type)}
      >
        <Button
          type="dashed"
          icon={<DeleteOutlined />}
          disabled={disabled ?? false}
        />
      </Popconfirm>
    </>
  );
};
DeleteComponent.propTypes = {
  deleteHandler: PropTypes.func,
  record: PropTypes.object,
  type: PropTypes.string,
  disabled: PropTypes.bool,
};

const InputComponent = ({
  record,
  target,
  type,
  onChange,
  onClick,
  disabled,
  size,
}) => {
  const [sText, setText] = useState();

  useEffect(() => {
    setText(record[target]);
  }, [record[target]]);
  return (
    <Input
      value={sText}
      disabled={disabled ?? false}
      onClick={() => onClick({ record, target, type })}
      onChange={(e) => {
        setText(e.target.value);
        onChange({ record, target, type, value: e.target.value });
      }}
      style={{
        width: (size ?? 'small') === 'small' ? 120 : 200,
        margin: (size ?? 'small') === 'small' ? '0 4px' : '0 8px',
      }}
    />
  );
};
InputComponent.propTypes = {
  onChange: PropTypes.func.isRequired,
  onClick: PropTypes.func,
  record: PropTypes.object.isRequired,
  target: PropTypes.string.isRequired,
  type: PropTypes.string,
  disabled: PropTypes.bool,
  size: PropTypes.string,
};

const InputNumberComponent = ({
  record,
  target,
  type,
  onChange,
  disabled,
  size,
}) => {
  const [sNumber, setNumber] = useState(0);

  useEffect(() => {
    setNumber(record[target]);
  }, [record[target]]);
  return (
    <InputNumber
      min={1}
      size="small"
      max={10000000}
      value={sNumber}
      bordered={false}
      disabled={disabled ?? false}
      onChange={(e) => {
        setNumber(e);
        onChange({ record, target, type, value: e });
      }}
      style={{
        width: (size ?? 'small') === 'small' ? 60 : 80,
        margin: (size ?? 'small') === 'small' ? '0 4px' : '0 8px',
      }}
    />
  );
};
InputNumberComponent.propTypes = {
  onChange: PropTypes.func.isRequired,
  record: PropTypes.object.isRequired,
  target: PropTypes.string.isRequired,
  type: PropTypes.string,
  disabled: PropTypes.bool,
  size: PropTypes.string,
};

const SelectComponent = ({
  record,
  target,
  options,
  onChange,
  disabled,
  size,
  type,
  defaultValue,
}) => {
  return (
    <Select
      allowClear
      disabled={disabled ?? false}
      value={record[target]}
      defaultValue={defaultValue ?? record[target]}
      style={{
        width: (size ?? 'small') === 'small' ? 120 : 200,
        margin: (size ?? 'small') === 'small' ? '0 4px' : '0 8px',
      }}
      onChange={(value) => {
        onChange({ record, target, value, type });
      }}
    >
      {options?.map((item, idx) => {
        return (
          <Option key={idx} value={item}>
            {item}
          </Option>
        );
      }) ?? <></>}
    </Select>
  );
};

SelectComponent.propTypes = {
  onChange: PropTypes.func.isRequired,
  record: PropTypes.object.isRequired,
  options: PropTypes.array,
  target: PropTypes.string.isRequired,
  type: PropTypes.string,
  disabled: PropTypes.bool,
  size: PropTypes.string,
  defaultValue: PropTypes.string,
};

const TableComponent = ({ children }) => {
  return <>{children}</>;
};

TableComponent.propTypes = {
  children: PropTypes.node,
};

TableComponent.select = SelectComponent;
TableComponent.delete = DeleteComponent;
TableComponent.input = InputComponent;
TableComponent.inputNumber = InputNumberComponent;
export default TableComponent;
