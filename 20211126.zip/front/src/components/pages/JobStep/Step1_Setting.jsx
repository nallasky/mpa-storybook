import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import useRuleSettingInfo from '../../../hooks/useRuleSettingInfo';
import MainPageItem from '../../UI/molecules/MainPageItem';
import { css } from '@emotion/react';
import {
  MSG_STEP1_BUTTON,
  MSG_STEP1_CATEGORY,
  MSG_STEP1_MAIN_TITLE,
} from '../../../lib/api/Define/Message';
import { useParams } from 'react-router';
import { E_STEP_1 } from '../../../lib/api/Define/etc';
import { getParseData } from '../../../lib/util/Util';
import InputForm from '../../UI/atoms/Input/InputForm';
import { E_JOBSTEP } from '../../../lib/api/Define/JobStepEnum';

const itemWrapper = css`
  word-break: break-word;
  margin: 2rem 0;
  display: flex;
  & > div + div {
    margin-left: 4.9rem;
  }
`;

const nextClick = (funcStepInfo) => {
  return Boolean(
    (funcStepInfo?.category?.selected ?? false) &&
      (funcStepInfo?.title ?? false),
  );
};
const previewCheck = () => {
  return false;
};
const ContentsForm = ({ onChange }) => {
  const { updateFuncInfo, funcStepInfo, ruleStepConfig } = useRuleSettingInfo();
  const [stepInfo, setStepInfo] = useState({});
  const [categories, setCategories] = useState({});
  const { category_id } = useParams();

  useEffect(() => {
    const clone = { ...funcStepInfo };
    const ruleConfig = ruleStepConfig.find((item) => item.step === E_STEP_1);

    if (ruleConfig?.config ?? false) {
      if (Object.keys(stepInfo).length === 0) {
        const { category } = ruleConfig.config;
        const category_selected =
          category?.selected ?? category_id ?? category.options[0].category_id;
        if (Object.keys(clone).length === 0) {
          console.log('clone empty', clone);
        } else {
          setStepInfo(clone);
        }
        const findObj = category.options.find(
          (item) => item.category_id === parseInt(category_selected),
        );
        setCategories({
          original: category.options,
          options: category.options.map((obj) => obj.title),
          title: findObj?.title ?? category.options[0].title,
        });
        if (findObj) onChange({ category_id: findObj.title });
      }
    }
  }, [ruleStepConfig]);

  useEffect(() => {
    updateFuncInfo(stepInfo);
  }, [stepInfo]);

  const ChangeFunc = (e) => {
    const obj = getParseData(e);
    if (obj.id === E_JOBSTEP.STEP1_CATEGORY_ID) {
      const { original } = categories;
      console.log('ChangeFunc', e);
      const findObj = original?.find((item) => item.title === obj.value) ?? {};

      if (findObj.title !== categories.title || (stepInfo?.selected ?? true)) {
        setStepInfo((prevState) => ({
          ...prevState,
          category: {
            ...prevState.category,
            selected: parseInt(findObj.category_id),
          },
        }));
        setCategories((prevState) => ({
          ...prevState,
          title: obj.value,
        }));
      }
    } else {
      setStepInfo({ ...stepInfo, ...e });
    }
  };
  if (
    Object.keys(categories).length === 0 ||
    Object.keys(funcStepInfo).length === 0
  )
    return <></>;
  return (
    <div style={{ width: '400px', margin: '26px 0px' }}>
      <InputForm.select
        formName={E_JOBSTEP.STEP1_CATEGORY_ID}
        formLabel={MSG_STEP1_CATEGORY}
        options={categories?.options ?? []}
        defaultV={categories?.title ?? ''}
        changeFunc={(e) => ChangeFunc(e)}
        required={true}
      />
      <InputForm.input
        formName={E_JOBSTEP.STEP1_TITLE}
        formLabel={MSG_STEP1_MAIN_TITLE}
        changeFunc={(e) => ChangeFunc(e)}
        required={true}
        value={funcStepInfo?.title ?? ''}
        maxLength={20}
      />
    </div>
  );
};
ContentsForm.propTypes = {
  onChange: PropTypes.func,
};

const PreviewForm = () => {
  const { funcStepInfo } = useRuleSettingInfo();
  if (funcStepInfo === undefined) return <></>;

  return (
    <div css={itemWrapper}>
      <MainPageItem
        isEditMode={false}
        mainText={funcStepInfo?.title ?? ''}
        subText={''}
        buttonText={MSG_STEP1_BUTTON}
        onClick={(e) => e.preventDefault()}
      />
    </div>
  );
};
const Step1_Setting = ({ children }) => {
  return <div>{children}</div>;
};

Step1_Setting.propTypes = {
  children: PropTypes.node,
};

Step1_Setting.check_next = nextClick;
Step1_Setting.check_preview = previewCheck;
Step1_Setting.view_contents = ContentsForm;
Step1_Setting.view_preview = PreviewForm;

export default Step1_Setting;
