import { Suspense } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { ErrorBoundary } from "react-error-boundary";

import { URL_CAR_LIST_PAGE } from "./constants/url";
import CarList from "./pages/carList/carList";
import { PageError } from "./pages/error/pageError";
import { PageLoading } from "./pages/loading/pageLoading";

import "./App.css";

function App() {
  return (
    <Router>
      <ErrorBoundary FallbackComponent={PageError}>
        <Suspense fallback={<PageLoading />}>
          <Routes>
            <Route path="/" element={<Navigate to={URL_CAR_LIST_PAGE} replace />} />
            <Route path={URL_CAR_LIST_PAGE} element={<CarList />} />
          </Routes>
        </Suspense>
      </ErrorBoundary>
    </Router>
  );
}

export default App;
