import * as Constant from "./constant";

const CAR_FILTER_MODEL_DETAIL_VALUE = [
  Constant.CAR_MODEL_SMALL,
  Constant.CAR_MODEL_MEDIUM,
  Constant.CAR_MODEL_LARGE,
  Constant.CAR_MODEL_IMPORT,
  Constant.CAR_MODEL_SUV
] as const;

const CAR_FILTER_REGION_DETAIL_VALUE = [
  Constant.CAR_REGION_SEOUL,
  Constant.CAR_REGION_BUSAN,
  Constant.CAR_REGION_JEJU,
  Constant.CAR_REGION_DAEGU,
  Constant.CAR_REGION_DAEJEON,
  Constant.CAR_REGION_GWANGJU,
] as const;

const CAR_FILTER_PRICE_DETAIL_VALUE = [
  Constant.CAR_PRICE_LOW,
  Constant.CAR_PRICE_HIGH,
] as const;

const CAR_FILTER_DETAIL_VALUE = [
  ...CAR_FILTER_MODEL_DETAIL_VALUE,
  ...CAR_FILTER_REGION_DETAIL_VALUE,
  ...CAR_FILTER_PRICE_DETAIL_VALUE
] as const ;

const CAR_TYPE_TAG_VALUE = [
  Constant.CAR_FILTER_HOT,
  Constant.CAR_FILTER_SPECIAL_PRICE,
  Constant.CAR_FILTER_GOOD_CONDITION,
  Constant.CAR_FILTER_FAST_RENTAL
] as const;

const CAR_FILTER_ALL_VALUE = [
  ...CAR_FILTER_DETAIL_VALUE,
  ...CAR_TYPE_TAG_VALUE,
] as const;

const CAR_FILTER_DETAIL_TITLE_INFO = [
  Constant.CAR_FILTER_MODEL,
  Constant.CAR_FILTER_REGION,
  Constant.CAR_FILTER_PRICE
] as const;

const CAR_FILTER_DETAIL_KEY_INFO = [
  Constant.CAR_FILTER_MODEL_KEY,
  Constant.CAR_FILTER_REGION_KEY,
  Constant.CAR_FILTER_PRICE_KEY
] as const;

const CAR_FILTER_TITLE_INFO = [
  ...CAR_FILTER_DETAIL_TITLE_INFO,
  ...CAR_TYPE_TAG_VALUE
] as const;

const CAR_FILTER_KEY_INFO = [
  ...CAR_FILTER_DETAIL_KEY_INFO,
  Constant.CAR_FILTER_TYPE_TAG_KEY
] as const;

export type TCarFilterDetailModelValue = typeof CAR_FILTER_MODEL_DETAIL_VALUE[number];
export type TCarFilterDetailRegionValue = typeof CAR_FILTER_REGION_DETAIL_VALUE[number];
export type TCarFilterDetailPriceValue = typeof CAR_FILTER_PRICE_DETAIL_VALUE[number];
export type TCarTypeTagValue = typeof CAR_TYPE_TAG_VALUE[number];
export type TCarFilterAllValue = typeof CAR_FILTER_ALL_VALUE[number];

export type TCarFilterDetailKey = typeof CAR_FILTER_DETAIL_KEY_INFO[number];
export type TCarFilterDetailValueList =  Array<TCarFilterDetailModelValue | TCarFilterDetailRegionValue | TCarFilterDetailPriceValue>;

export type TCarFilterKey = typeof CAR_FILTER_KEY_INFO[number];
export type TCarFilterTitle = typeof CAR_FILTER_TITLE_INFO[number];
export type TCarFilterDetailValue = typeof CAR_FILTER_DETAIL_VALUE[number];

export type TCarSavedFilterValue = Array<TCarFilterDetailModelValue | TCarFilterDetailRegionValue | TCarFilterDetailPriceValue | TCarTypeTagValue>;

export interface IChangeSavedFilter {
  key: TCarFilterKey,
  value: TCarSavedFilterValue
}

export interface ICarFilterItem {
  title: TCarFilterTitle,
  key: TCarFilterKey,
}

export interface ICarFilterDetailData {
  [Constant.CAR_FILTER_MODEL_KEY]: TCarFilterDetailModelValue[],
  [Constant.CAR_FILTER_REGION_KEY]: TCarFilterDetailRegionValue[],
  [Constant.CAR_FILTER_PRICE_KEY]: TCarFilterDetailPriceValue[],
}

export interface ISavedFilter extends ICarFilterDetailData {
  [Constant.CAR_FILTER_TYPE_TAG_KEY]: TCarTypeTagValue[]
}