export const CAR_FILTER_MODEL_KEY = 'carModel';
export const CAR_FILTER_REGION_KEY = 'regionGroups';
export const CAR_FILTER_PRICE_KEY = 'price';
export const CAR_FILTER_TYPE_TAG_KEY = 'carTypeTags';

export const CAR_FILTER_MODEL = '차종';
export const CAR_FILTER_REGION = '대여지역';
export const CAR_FILTER_PRICE = '가격'
export const CAR_FILTER_HOT = '인기';
export const CAR_FILTER_SPECIAL_PRICE = '특가';
export const CAR_FILTER_GOOD_CONDITION = '신차급';
export const CAR_FILTER_FAST_RENTAL = '빠른대여';

export const CAR_MODEL_SMALL = '경형/소형';
export const CAR_MODEL_MEDIUM = '준중형';
export const CAR_MODEL_LARGE = '중형/대형';
export const CAR_MODEL_IMPORT = '수입';
export const CAR_MODEL_SUV = 'SUV';

export const CAR_REGION_SEOUL = '서울/경기/인천';
export const CAR_REGION_BUSAN = '부산/창원';
export const CAR_REGION_JEJU = '제주';
export const CAR_REGION_DAEGU = '대구/경북';
export const CAR_REGION_DAEJEON = '대전';
export const CAR_REGION_GWANGJU = '광주';

export const CAR_PRICE_LOW = '낮은 가격순';
export const CAR_PRICE_HIGH = '높은 가격순';


