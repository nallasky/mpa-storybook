import { useMemo } from "react";
import { shallow } from "zustand/shallow";
import { useQuery } from "@tanstack/react-query";
import { v4 as uuidv4 } from 'uuid';

import { fetchCarClasses } from "../../api/carList/api";
import { ICarClassResponse } from "../../types/response";
import { TCarFilterAllValue, TCarFilterKey, TCarSavedFilterValue } from "./type";
import useFilterStore, { initialFilterStoreState } from "../../store/filter/filter";
import { CAR_FILTER_PRICE_KEY, CAR_PRICE_LOW, CAR_FILTER_TYPE_TAG_KEY } from "./constant";
import { savedArrIndexInitialState } from "../../components/carList/carListItems/constant";
import { calculatePrice } from "../../util/commonFunction";
import CarListFilter from "../../components/carList/carListFilter/carListFilter";
import ListPage from "../../components/layout/listPage";
import CarListItems from "../../components/carList/carListItems/carListItems";


export default function CarList () {
  const { data } = useQuery(
    ['carClasses'],
    fetchCarClasses,
    { suspense: true }
  );

  const savedFilter = useFilterStore((state) => state.savedFilter, shallow);

  const filteredData: ICarClassResponse[] = useMemo(() => {
    let result: ICarClassResponse[] = [];

    if (data || JSON.stringify(savedFilter) !== JSON.stringify(initialFilterStoreState)) {
      const beforeSortData: ICarClassResponse[] = data.filter((item: ICarClassResponse) => {
        let isValid: boolean = true;

        for (const [key, value] of Object.entries(savedFilter)) {
          const tmpKey: TCarFilterKey = key as TCarFilterKey;
          if (!value.length || tmpKey === CAR_FILTER_PRICE_KEY) continue;

          if (Array(item[tmpKey])) {
            const tmpData = item[tmpKey] as TCarSavedFilterValue;
            isValid = tmpKey !== CAR_FILTER_TYPE_TAG_KEY
              ? !!value.find((v: TCarFilterAllValue) => tmpData.includes(v))
              : value.filter((v: TCarFilterAllValue) => tmpData.includes(v)).length === value.length;
          } else {
            isValid = !!value.includes(item[tmpKey]);
          }

          if (!isValid) {
            break;
          }
        }

        return isValid;
      });

      if (!savedFilter[CAR_FILTER_PRICE_KEY].length) {
        result = beforeSortData;
      } else {
        result = beforeSortData.sort((a: ICarClassResponse, b: ICarClassResponse) => {
          const { price: prevPrice, discountPercent: prevDiscount } = a;
          const { price: nextPrice, discountPercent: nextDiscount } = b;

          const prevCalculatePrice: number = calculatePrice(prevPrice, prevDiscount);
          const nextCalculatePrice: number = calculatePrice(nextPrice, nextDiscount);

          return savedFilter[CAR_FILTER_PRICE_KEY][0] === CAR_PRICE_LOW
            ? prevCalculatePrice - nextCalculatePrice
            : nextCalculatePrice - prevCalculatePrice;
        });
      }
    }

    return result.map((v: ICarClassResponse, index: number) => ({ ...v, index }));
  }, [data, savedFilter]);

  return (
    <ListPage
      title="차량 리스트"
      header={<CarListFilter />}
    >
      <CarListItems key={uuidv4()} data={filteredData} indexArr={savedArrIndexInitialState} />
    </ListPage>
  );
};