import { PageLayout, LoadingAndErrorWrapper } from "../../styles/common";
import { Loader } from "./style";

export const PageLoading = () => {
  return (
    <PageLayout>
      <LoadingAndErrorWrapper>
        <Loader />
        <p>페이지를 불러오고 있습니다.</p>
      </LoadingAndErrorWrapper>
    </PageLayout>
  );
};

export default PageLoading;

