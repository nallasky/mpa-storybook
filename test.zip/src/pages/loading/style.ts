import styled from "styled-components";

export const Loader = styled.div`
  width: 64px;
  height: 64px;
  border-radius: 50%;
  border: 12px solid var(--default-blue-color);
  border-top-color: white;
  animation: spinning 1s infinite linear;
`;