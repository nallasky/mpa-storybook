import styled from "styled-components";

export const RefreshButton = styled.button`
  outline: none;
  background-color: var(--default-gray-color);
  border: var(--default-border);
  padding: 0.5rem;
  border-radius: 4px;
  cursor: pointer;
 `;