import styled from "styled-components";

export const PageLayout = styled.main`
  position: relative;
  width: var(--default-page-width);
  min-height: 100vh;
  margin: 0 auto;
  border: var(--default-border);
`;

export const LoadingAndErrorWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 100%;
  height: 100vh;
`;