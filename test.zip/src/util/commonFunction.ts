export const translateDistance = (distance: number) => {
  if (distance < 1000) {
    return distance;
  }
  if (distance >= 10000) {
    return `${distance / 10000}만`;
  }
  return `${distance / 1000}천`;
};

export const calculatePrice = (price: number, discount: number) => {
  if (!discount) {
    return Math.round(price / 10) * 10;
  }
  return Math.round((price - (price * (discount / 100))) / 10) * 10;
};