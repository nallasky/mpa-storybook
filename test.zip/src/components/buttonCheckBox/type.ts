export interface IButtonCheckBox {
  title: string,
  checked: boolean,
  onChangeHandler: (checked: boolean) => void
}