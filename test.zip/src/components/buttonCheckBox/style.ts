import styled from "styled-components";

export const CheckBoxWrapper = styled.label`
  cursor: pointer;
  & > input[type="checkbox"] {
    display: none;
    &:checked + .checkbox-title {
      background-color: #dadada;
    }
  }
  & > .checkbox-title {
    display: block;
    border: var(--default-border);
    padding: 0.25rem 0;
    user-select: none;
  }
`;