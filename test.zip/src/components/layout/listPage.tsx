import { IPageLayout } from "./type";
import { PageLayout } from "../../styles/common";
import { ListPageHeader, ListPageBody } from "./style";

const ListPage = ({ title, header = <></>, children }: IPageLayout) => {
  return (
    <PageLayout>
      <ListPageHeader>
        <h1>{title}</h1>
        {header}
      </ListPageHeader>
      <ListPageBody>
        {children}
      </ListPageBody>
    </PageLayout>
  );
};

export default ListPage;
