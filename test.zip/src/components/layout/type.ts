import { ReactNode } from "react";

export interface IPageLayout {
  title: string,
  header?: ReactNode,
  children: ReactNode
}