import styled from "styled-components";

export const TagWrapper = styled.span`
  display: inline-block;
  border: var(--default-border);
  padding: 0.25rem;
  white-space: pre;
`;
