export interface ITag {
  title: string,
}