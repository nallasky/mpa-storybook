import styled from "styled-components";

export const ActiveTagWrapper = styled.div<{ checked: boolean }>`
  display: flex;
  align-item: center;
  column-gap: 0.5rem;
  padding: 0.25rem 0.5rem;
  border: var(--default-border);
  user-select: none;
  background-color: ${(props) => (props.checked ? '#dfdfdf' : 'white')};
  & > .title {
    white-space: pre;
  }
  & > .close-button {
    line-height: 1.1;
    color: #9b9b9b;
  }
`;