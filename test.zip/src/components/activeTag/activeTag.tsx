import { ActiveTagWrapper } from "./style";
import { IActiveTag } from "./type";

const ActiveTag = ({
  title,
  disableCloseButton = false,
  onTagClickHandler,
  onCloseHandler,
}: IActiveTag) => {
  return (
    <ActiveTagWrapper checked={!disableCloseButton}>
      <a
        className="title"
        href="#"
        role="button"
        onClick={onTagClickHandler}
      >
        {title}
      </a>
      {!disableCloseButton &&
        <a
          className="close-button"
          href="#"
          role="button"
          onClick={onCloseHandler}
        >
          x
        </a>
      }
    </ActiveTagWrapper>
  );
};

export default ActiveTag;