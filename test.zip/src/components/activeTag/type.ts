export interface IActiveTag {
  title: string,
  disableCloseButton?: boolean,
  onTagClickHandler: () => void,
  onCloseHandler?: () => void,
}