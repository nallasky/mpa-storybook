import {
  TCarSavedFilterValue,
  TCarFilterDetailValueList
} from "../../../pages/carList/type";

export interface ICarListFilterPopup {
  multiple: boolean,
  data: TCarFilterDetailValueList,
  checkedInfo: TCarFilterDetailValueList,
  onCloseHandler: (value: TCarSavedFilterValue) => void,
}