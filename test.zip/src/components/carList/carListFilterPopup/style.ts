import styled from "styled-components";

export const CarListFilterPopupWrapper = styled.div`
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  background-color: white;
  z-index: 1000;
  border: var(--default-border);
  & > .car-list-filter-popup__content {
    display: flex;
    padding: 0.5rem;
    column-gap: 0.5rem;
    & > .car-list-filter-popup__content__list {
      flex-grow: 2;
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 0.5rem;
    }
    & > .car-list-filter-popup__content__close-button {
      align-self: self-start;
      font-size: 16px;
      white-space: pre;
      font-size: 20px;
      font-weight: bold;
      color: #9b9b9b;
      cursor: pointer;
    }
  }
`;

export const CarListFilterPopupBg = styled.div`
  position: fixed;
  top: 0;
  width: var(--default-page-width);
  height: 100%;
  z-index: 999;
  background-color: rgba(0,0,0,0.25);
`;
