import { useState } from "react";

import { CarListFilterPopupWrapper, CarListFilterPopupBg } from "./style";
import { TCarFilterDetailValue } from "../../../pages/carList/type";
import { ICarListFilterPopup } from "./type";
import ButtonCheckBox from "../../buttonCheckBox/buttonCheckBox";

const CarListFilterPopup = ({
  multiple,
  data,
  checkedInfo,
  onCloseHandler,
}: ICarListFilterPopup) => {
  const [innerCheckedInfo, setInnerCheckedInfo] = useState<TCarFilterDetailValue[]>(checkedInfo);

  const onChangeHandler = (checked: boolean, title: TCarFilterDetailValue) => {
    if (multiple) {
      const newInnerCheckedInfo: TCarFilterDetailValue[] = checked
        ? innerCheckedInfo.filter((v: TCarFilterDetailValue) => v !== title)
        : [...innerCheckedInfo, title];
      setInnerCheckedInfo(newInnerCheckedInfo);
    } else {
      setInnerCheckedInfo(checked ? [] : [title]);
    }
  };

  return (
    <>
      <CarListFilterPopupWrapper>
        <div className="car-list-filter-popup__content">
          <ul className="car-list-filter-popup__content__list">
            {data.map((v: TCarFilterDetailValue, i: number) => {
              const checked: boolean = innerCheckedInfo.includes(v);
              return (
                <li key={i}>
                  <ButtonCheckBox
                    title={v}
                    checked={checked}
                    onChangeHandler={() => {
                      onChangeHandler(checked, v);
                    }}
                  />
                </li>
              )
            })}
          </ul>
          <a
            className="car-list-filter-popup__content__close-button"
            href="#"
            role="button"
            onClick={() => onCloseHandler(innerCheckedInfo)}
          >
            X
          </a>
        </div>
      </CarListFilterPopupWrapper>
      <CarListFilterPopupBg onClick={() => onCloseHandler(innerCheckedInfo)} />
    </>
  );
};

export default CarListFilterPopup;