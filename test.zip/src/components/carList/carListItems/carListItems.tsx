import { useMemo, useState } from "react";

import { CarListItemsWrapper } from "./style";
import { ICarClassResponse } from "../../../types/response";
import { ICarListItems, ISavedArrIndex } from "./type";
import CarInfoCard from "../carInfoCard/carInfoCard";
import { HiddenCarInfoCard } from "./function";
import ItemNotFound from "../itemNotFound/itemNotFound";

const CarListItems = ({ data, indexArr }: ICarListItems) => {
  const [savedArrIndex, setSavedArrIndex] = useState<ISavedArrIndex>(indexArr);

  const showingCars: ICarClassResponse[] = useMemo(() => {
    if (!data.length) return [];

    const { start, end } = savedArrIndex;

    return data.slice(start, end);
  }, [data, savedArrIndex]);

  const topHiddenCar: JSX.Element = useMemo(() => {
    const { start } = savedArrIndex;

    if (!data.length || !start) return <></>;

    return <HiddenCarInfoCard {...data[start]} />;
  }, [data, savedArrIndex.start]);

  const bottomHiddenCar: JSX.Element = useMemo(() => {
    const { end } = savedArrIndex;

    if (!data.length || end >= data.length) return <></>;

    return <HiddenCarInfoCard {...data[end]} />;
  }, [data, savedArrIndex.end]);

  const changeSavedArrIndex = (classId: number) => {
    const findIndex: number = data.findIndex(({ carClassId }: ICarClassResponse) => carClassId === classId);
    setSavedArrIndex(prev => {
      return findIndex + 1 === prev.end ? {
        start: prev.start - 1 <= 0 ? 0 : prev.start - 1,
        end: findIndex
      } : {
        start: findIndex + 1,
        end: prev.end + 1 >= data.length ? data.length : prev.end + 1,
      }
    });
  };

  if (!data.length) {
    return <ItemNotFound />;
  }

  return (
    <CarListItemsWrapper>
      {topHiddenCar}
      {showingCars.map((item: ICarClassResponse) => {
        const { carModel, carClassId, ...rest } = item;
        return (
          <CarInfoCard
            key={carClassId}
            onHiddenCallback={() => changeSavedArrIndex(carClassId)}
            {...rest}
          />
        );
      })}
      {bottomHiddenCar}
    </CarListItemsWrapper>
  )
};

export default CarListItems;
