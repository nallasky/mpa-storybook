import { ICarClassResponse } from "../../../types/response";

export interface ISavedArrIndex {
  start: number,
  end: number
}

export interface ICarListItems {
  data: ICarClassResponse[],
  indexArr: ISavedArrIndex,
}