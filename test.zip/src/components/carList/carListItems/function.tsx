import { ICarClassResponse } from "../../../types/response";
import CarInfoCard from "../carInfoCard/carInfoCard";

export const HiddenCarInfoCard = (item: ICarClassResponse) => {
  const { carModel, carClassId,  ...rest } = item;
  return <CarInfoCard key={carClassId} disableIntersectionObserver {...rest} />;
}