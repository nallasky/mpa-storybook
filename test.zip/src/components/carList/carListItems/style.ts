import styled from "styled-components";

export const CarListItemsWrapper = styled.ul`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
  & > li {
    width: 100%;
  }
`;