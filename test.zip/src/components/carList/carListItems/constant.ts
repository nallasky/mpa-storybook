import { ISavedArrIndex } from "./type";

export const MAX_SHOW_CAR_ITEM_VALUE: number = 6;
export const savedArrIndexInitialState: ISavedArrIndex = {
  start: 0,
  end: MAX_SHOW_CAR_ITEM_VALUE,
};