import React, { useState, useMemo } from "react";
import { shallow } from 'zustand/shallow';

import {
  ICarFilterItem,
  TCarFilterKey,
  TCarSavedFilterValue,
  TCarTypeTagValue,
  TCarFilterTitle,
  TCarFilterDetailKey,
  TCarFilterDetailValueList
} from "../../../pages/carList/type";
import { CAR_FILTER_TYPE_TAG_KEY, CAR_FILTER_PRICE_KEY } from "../../../pages/carList/constant";
import { CarListFilterWrapper, CarListFilterItems } from "./style";
import { FILTER_DATA, FILTER_DETAIL_DATA } from "./constant";
import CarListFilterPopup from "../carListFilterPopup/carListFilterPopup";
import ActiveTag from "../../activeTag/activeTag";
import useFilterStore, { initialFilterStoreState } from "../../../store/filter/filter";


const CarListFilter = () => {
  const savedFilter = useFilterStore((state) => state.savedFilter, shallow);
  const { changeSavedFilter, initializeSavedFilter } = useFilterStore();

  const [selectedDetailFilter, setSelectedDetailFilter] = useState<TCarFilterDetailKey | null>(null);

  const detailFilterData: TCarFilterDetailValueList = useMemo(() => {
    if (selectedDetailFilter) {
      return FILTER_DETAIL_DATA[selectedDetailFilter];
    }
    return [];
  }, [selectedDetailFilter]);

  const changeSelectedFilter = (key: TCarFilterDetailKey) => {
    setSelectedDetailFilter(key);
    document.body.style.overflow = "hidden";
  };

  const changeTypeTag = (tag: TCarFilterTitle) => {
    const tagType: TCarTypeTagValue = tag as TCarTypeTagValue;
    const savedTypeTag: TCarTypeTagValue[] = savedFilter[CAR_FILTER_TYPE_TAG_KEY];
    const alreadySaved: boolean = savedTypeTag.includes(tagType);

    changeSavedFilter({
      key: CAR_FILTER_TYPE_TAG_KEY,
      value: alreadySaved
        ? savedTypeTag.filter((v: TCarTypeTagValue) => v !== tagType)
        : [...savedTypeTag, tagType]
    });
  };

  const unselectFilter = (key: TCarFilterKey) => {
    changeSavedFilter({
      key,
      value: []
    });
  };

  const onClosePopup = (value: TCarSavedFilterValue) => {
    changeSavedFilter({
      key: selectedDetailFilter as TCarFilterKey,
      value
    });
    setSelectedDetailFilter(null);
    document.body.style.overflow = "unset";
  };

  return (
    <CarListFilterWrapper>
      <CarListFilterItems>
        {JSON.stringify(savedFilter) !== JSON.stringify(initialFilterStoreState) && (
          <li>
            <ActiveTag title="초기화" disableCloseButton onTagClickHandler={() => initializeSavedFilter()} />
          </li>
        )}
        {FILTER_DATA.map((v: ICarFilterItem, i: number) => {
          const { key, title } = v;
          return (
            <li key={i}>
              <ActiveTag
                title={title}
                onTagClickHandler={() => {
                  if (key === CAR_FILTER_TYPE_TAG_KEY) {
                    changeTypeTag(title);
                  } else {
                    changeSelectedFilter(key)
                  }
                }}
                disableCloseButton={
                  key === CAR_FILTER_TYPE_TAG_KEY
                    ? !savedFilter[key].includes(title as TCarTypeTagValue)
                    : !savedFilter[key].length
                }
                onCloseHandler={() => {
                  if (key === CAR_FILTER_TYPE_TAG_KEY) {
                    changeTypeTag(title);
                  } else {
                    unselectFilter(key);
                  }
                }}
              />
            </li>
          );
        })}
      </CarListFilterItems>
      {selectedDetailFilter && (
        <CarListFilterPopup
          multiple={selectedDetailFilter !== CAR_FILTER_PRICE_KEY}
          data={detailFilterData}
          checkedInfo={savedFilter[selectedDetailFilter]}
          onCloseHandler={onClosePopup}
        />
      )}
    </CarListFilterWrapper>
  )
};

export default CarListFilter;