import styled from "styled-components";

export const CarListFilterWrapper = styled.div`
  position: relative;
  border-top: var(--default-border);
  border-bottom: var(--default-border);
`;


export const CarListFilterItems = styled.ul`
  display: flex;
  align-items: center;
  margin: 0;
  padding: 0.5rem;
  column-gap: 0.5rem;
  overflow-x: auto;
`;
