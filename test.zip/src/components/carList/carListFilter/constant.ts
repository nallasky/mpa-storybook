import * as Constant from "../../../pages/carList/constant";
import {
  ICarFilterItem,
  ICarFilterDetailData
} from "../../../pages/carList/type";

export const FILTER_DATA: ICarFilterItem[] = [
  {
    title: Constant.CAR_FILTER_MODEL,
    key: Constant.CAR_FILTER_MODEL_KEY
  },
  {
    title: Constant.CAR_FILTER_REGION,
    key: Constant.CAR_FILTER_REGION_KEY
  },
  {
    title: Constant.CAR_FILTER_PRICE,
    key: Constant.CAR_FILTER_PRICE_KEY
  },
  {
    title: Constant.CAR_FILTER_HOT,
    key: Constant.CAR_FILTER_TYPE_TAG_KEY
  },
  {
    title: Constant.CAR_FILTER_SPECIAL_PRICE,
    key: Constant.CAR_FILTER_TYPE_TAG_KEY
  },
  {
    title: Constant.CAR_FILTER_GOOD_CONDITION,
    key: Constant.CAR_FILTER_TYPE_TAG_KEY
  },
  {
    title: Constant.CAR_FILTER_FAST_RENTAL,
    key: Constant.CAR_FILTER_TYPE_TAG_KEY
  },
];

export const FILTER_DETAIL_DATA: ICarFilterDetailData = {
  [Constant.CAR_FILTER_MODEL_KEY]: [
    Constant.CAR_MODEL_SMALL,
    Constant.CAR_MODEL_MEDIUM,
    Constant.CAR_MODEL_LARGE,
    Constant.CAR_MODEL_IMPORT,
    Constant.CAR_MODEL_SUV
  ],
  [Constant.CAR_FILTER_REGION_KEY]: [
    Constant.CAR_REGION_SEOUL,
    Constant.CAR_REGION_BUSAN,
    Constant.CAR_REGION_JEJU,
    Constant.CAR_REGION_DAEGU,
    Constant.CAR_REGION_DAEJEON,
    Constant.CAR_REGION_GWANGJU,
  ],
  [Constant.CAR_FILTER_PRICE_KEY]: [
    Constant.CAR_PRICE_LOW,
    Constant.CAR_PRICE_HIGH,
  ]
};