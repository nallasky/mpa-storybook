import { ItemNotFoundWrapper } from "./style";

export const ItemNotFound = () => {
  return (
    <ItemNotFoundWrapper>
      <p>선택하신 조건에 맞는 차량이 없습니다.</p>
      <p>준비된 다른 차량을 확인해 보세요!</p>
    </ItemNotFoundWrapper>
  )
};

export default ItemNotFound;