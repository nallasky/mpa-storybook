import styled from "styled-components";

export const CarInfoCardWrapper = styled.li`
  & > .car-info-card {
    text-align: left;
    border: var(--default-border);
    border-radius: 4px;
    & > div + div {
      margin-top: 0.25rem;
    }
    & > .car-info-card__image {
      position: relative;
      overflow: hidden;
      width: 100%;
      padding-top: 50%;
      border-bottom: var(--default-border);
      & > img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: contain;   
      }
    }
    & > .car-info-card__text {
      padding: 0.5rem;
      & > div + div {
        margin-top: 0.5rem;
      }
      & > .car-info-card__text__name-and-tag {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        row-gap: 0.25rem;
        & > .car-info-card__text__name-and-tag__name {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        & > .car-info-card__text__name-and-tag__tag {
          display: flex;
          column-gap: 0.25rem;
        }
      }
    }
  }
`;