import { TCarTypeTagValue } from "../../../pages/carList/type";
import { ICarInfoCard } from "./type";
import { CarInfoCardWrapper } from "./style";
import { calculatePrice, translateDistance } from "../../../util/commonFunction";
import useIntersectionObserver from "../../../hooks/useIntersectionObserver";
import Tag from "../../tag/tag";

const CarInfoCard = ({
  carClassName,
  image,
  drivingDistance,
  year,
  price,
  discountPercent,
  regionGroups,
  carTypeTags,
  disableIntersectionObserver = false,
  onHiddenCallback,
}: ICarInfoCard) => {
  const onIntersect: IntersectionObserverCallback = ([{ isIntersecting }]) => {
    if (!isIntersecting && onHiddenCallback) {
      onHiddenCallback();
    }
  };

  const { setTarget } = useIntersectionObserver({ onIntersect, rootMargin: '-162px 0px -20px 0px' });

  return (
    <CarInfoCardWrapper ref={!disableIntersectionObserver ? setTarget : undefined}>
      <div className="car-info-card">
        <div className="car-info-card__image">
          <img src={image} alt="car_image" />
        </div>
        <div className="car-info-card__text">
          <div className="car-info-card__text__name-and-tag">
            <div className="car-info-card__text__name-and-tag__name">{carClassName}</div>
            <div className="car-info-card__text__name-and-tag__tag">
              {carTypeTags.map((title: TCarTypeTagValue, i: number) => {
                return (
                  <Tag key={i} title={title} />
                );
              })}
            </div>
          </div>
          <div className="car-info-card__text__price">
            {`${calculatePrice(price, discountPercent).toLocaleString()}원 ${!!discountPercent ? `(~${discountPercent}%)` : ''}`}
          </div>
          <div className="car-info-card__text__etc">
            {`${year}년 | ${translateDistance(drivingDistance)}km | ${regionGroups.join(', ')}`}
          </div>
        </div>
      </div>
    </CarInfoCardWrapper>
  )
};

export default CarInfoCard;