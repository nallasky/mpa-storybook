import { ICarClassDefault } from "../../../types/response";

export interface ICarInfoCard extends ICarClassDefault {
  disableIntersectionObserver?: boolean,
  onHiddenCallback?: () => void
}