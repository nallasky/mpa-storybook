import { create } from 'zustand';
import { persist } from "zustand/middleware";

import {IChangeSavedFilter, ISavedFilter} from "../../pages/carList/type";
import { IFilterStore, IFilterStorePersist } from "./type";
import {
  CAR_FILTER_MODEL_KEY,
  CAR_FILTER_PRICE_KEY,
  CAR_FILTER_REGION_KEY,
  CAR_FILTER_TYPE_TAG_KEY,
} from "../../pages/carList/constant";

export const initialFilterStoreState: ISavedFilter = {
  [CAR_FILTER_MODEL_KEY]: [],
  [CAR_FILTER_REGION_KEY]: [],
  [CAR_FILTER_PRICE_KEY]: [],
  [CAR_FILTER_TYPE_TAG_KEY]: []
};

const useFilterStore = create<IFilterStore>(
  (persist as IFilterStorePersist)(
    (set) => ({
      savedFilter: { ...initialFilterStoreState },
      changeSavedFilter: (info: IChangeSavedFilter) => {
        set((state: IFilterStore) => {
          const { key, value } = info;
          return {
            savedFilter: {
              ...state.savedFilter,
              [key]: [...value]
            }
          };
        })
      },
      initializeSavedFilter: () => {
        set(() => {
          return {
            savedFilter: { ...initialFilterStoreState }
          }
        })
      }
    }),
    {
      name: 'filter-storage',
      partialize: (state) => ({ savedFilter: state.savedFilter }),
    }
  )
);

export default useFilterStore;