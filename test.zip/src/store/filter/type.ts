import { StateCreator } from "zustand";
import { PersistOptions } from "zustand/middleware";

import { IChangeSavedFilter, ISavedFilter } from "../../pages/carList/type";

export interface IFilterStoreStates {
  savedFilter: ISavedFilter
}

export interface IFilterStoreActions {
  changeSavedFilter: (info: IChangeSavedFilter) => void,
  initializeSavedFilter: () => void,
}

export interface IFilterStore extends IFilterStoreStates, IFilterStoreActions {}

export type IFilterStorePersist =
  (config: StateCreator<IFilterStore>, options: PersistOptions<IFilterStoreStates>) => StateCreator<IFilterStore>;