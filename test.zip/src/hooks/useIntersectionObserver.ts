import { useEffect, useState } from "react";

interface IUseIntersectionObserver {
  rootMargin?: string,
  threshold?: number,
  onIntersect: IntersectionObserverCallback,
}

const useIntersectionObserver = ({
  rootMargin = '0px',
  threshold = 0,
  onIntersect,
}: IUseIntersectionObserver) => {
  const [target, setTarget] = useState<HTMLElement | null | undefined>(null);

  useEffect(() => {
    if (!target) return;
    const observer: IntersectionObserver = new IntersectionObserver(
      onIntersect,
      { rootMargin, threshold }
    );
    observer.observe(target);
    return () => observer.unobserve(target);
  }, [rootMargin, target, threshold])

  return { setTarget };
}

export default useIntersectionObserver;