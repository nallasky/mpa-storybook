import type {
  TCarFilterDetailModelValue,
  TCarFilterDetailRegionValue,
  TCarTypeTagValue
} from "../pages/carList/type";

export interface ICarClassDefault {
  carClassName: string,
  image: string,
  drivingDistance: number,
  year: number,
  price: number,
  discountPercent: number,
  regionGroups: TCarFilterDetailRegionValue[],
  carTypeTags: TCarTypeTagValue[],
}

export interface ICarClassResponse extends ICarClassDefault {
  carClassId: number,
  carModel: TCarFilterDetailModelValue
}