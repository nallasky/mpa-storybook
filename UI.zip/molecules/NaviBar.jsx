import React from 'react';
import { Menu } from 'antd';
import { HomeOutlined} from '@ant-design/icons';
import SubMenu from "antd/es/menu/SubMenu";
import { css } from '@emotion/react';

const MainBoxCss = css`
  background: #061178;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 26px 26px 10px 10px;
	display: flex;
	flex-wrap: no-wrap;
	justify-content: center;
`;

const MenuItemCss = css`
	padding: 0 4.5rem !important;
`;

const NaviBar = () => {
    return (
        <div css={MainBoxCss} >
            <Menu theme="dark" mode="horizontal" defaultSelectedKeys="home" style={{ background: "transparent" }}>
                <Menu.Item key="home" icon={<HomeOutlined />} css={MenuItemCss}>HOME</Menu.Item>
                <Menu.Item key="tact" disabled css={MenuItemCss}>TACT</Menu.Item>
                <Menu.Item key="overlay" disabled css={MenuItemCss}>OVERLAY</Menu.Item>
                <SubMenu key="focus" title={"FOCUS"} css={MenuItemCss}>
                    <Menu.Item key="afc">Auto Focus Compensation (AFC)</Menu.Item>
                    <Menu.Item key="preScan">Pre Scan Compensation</Menu.Item>
                    <Menu.Item key="lips">LIPS Focus</Menu.Item>
                    <Menu.Item key="tilt">Tilt Measurement</Menu.Item>
                    <Menu.Item key="mount">Mount Press</Menu.Item>
                </SubMenu>
                <Menu.Item key="arcnet" css={MenuItemCss}>ARCNET</Menu.Item>
            </Menu>
        </div>
    );
}
export default NaviBar;

/*
NaviBar.propTypes = {
     mode: React.String,
    list: PropTypes.string,
    initValue:PropTypes.string,
};
*/
