import React from 'react';
import PropTypes from "prop-types";
import { css } from "@emotion/react";
import Divider from '../../atoms/Divider/Divider';
import { BulbTwoTone } from '@ant-design/icons';

const TitleBar = ({ icon, text }) => {
	return (
    <div css={wrapperStyle}>
      <div css={iconTextStyle}>
        {icon}
        <label css={labelStyle}>{text}</label>
      </div>
      <Divider style={{ height: 0 }}/>
    </div>
	);
};

TitleBar.displayName = 'TitleBar';
TitleBar.propTypes = {
	icon: PropTypes.element,
	text: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
};
TitleBar.defaultProps = {
	icon: <BulbTwoTone style={{ fontSize: "30px", display: "flex", alignItems: "center" }} />,
	text: 'Title'
};

const wrapperStyle = css`
  font-family: Saira, "Nurito Sans";
  display: flex;
  align-items: center;
  position: relative;
  margin: 1rem 0;
`;

const iconTextStyle = css`
  position: absolute;
  background: #F5F5F5;
  display: flex;
`;

const labelStyle = css`
  padding: 0 3.5rem;
  color: #096dd9;
  font-size: 30px;
  font-weight: 600;
  text-shadow: 0 3px 2px rgba(0,0,0,.2);
`;

export default TitleBar;