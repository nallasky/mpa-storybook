import React from 'react';
import PropTypes from "prop-types";
import { css } from "@emotion/react";
import ItemCard from '../../atoms/ItemCard/ItemCard';
import Button from '../../atoms/Button/Button';

const MainPageItem = ({ mainText, subText, buttonText, onClick }) => {
	return (
		<ItemCard>
			<div css={contentStyle}>
				<p css={mainTextStyle}>{mainText}</p>
				<p css={subTextStyle}>{subText}</p>
			</div>
			<Button width={"80%"} onClick={onClick}>{buttonText}</Button>
		</ItemCard>
	);
};

MainPageItem.displayName = 'MainPageItem';
MainPageItem.propTypes = {
	mainText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
	subText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
	buttonText: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
	onClick: PropTypes.func
};
MainPageItem.defaultProps = {
	mainText: 'Main text',
	subText: 'Sub text',
	buttonText: 'Button'
};

const mainTextStyle = css`
  text-align: center;
  font-size: 24px;
  font-weight: 600;
  color: #002766;
`;

const subTextStyle = css`
  text-align: center;
  font-size: 18px;
  font-weight: 600;
  color: #1890ff;
`;

const contentStyle = css`
	padding: 0 25px;
`;

export default MainPageItem;