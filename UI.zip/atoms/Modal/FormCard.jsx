import React from 'react';
import PropTypes from "prop-types";
import { css } from "@emotion/react";

const FormCard = ({ title, children, formStyle, titleStyle }) => {
	return (
		<div css={[ formMainStyle, formStyle ]}>
			<p css={[ formTitleStyle, titleStyle ]}>{title}</p>
			{children}
		</div>
	);
};

FormCard.displayName = 'FormCard';
FormCard.propTypes = {
	title: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
	children: PropTypes.node,
	formStyle: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
	titleStyle: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
};
FormCard.defaultProps = {
	title: 'Form Title'
};

const formMainStyle = css`
	padding: 1rem;
	background: #f0f5ff;
`;

const formTitleStyle = css`
	color: #1890ff;
	font-weight: 600;
`;

export default FormCard;