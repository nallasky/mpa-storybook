import React from 'react';
import PropTypes from "prop-types";
import { css } from "@emotion/react";

const Button = ({ children, onClick, theme, size, disabled, width, iconOnly, style }) => {
	return (
		<button
			css={[
				defaultStyle,
				themes[theme],
				sizes[size],
				{ width },
				iconOnly && [iconOnlyStyle, iconOnlySizes[size]],
				style
			]}
			onClick={onClick}
			disabled={disabled}
		>
			{children}
		</button>
	);
};

Button.displayName = 'Button';
Button.propTypes = {
	children: PropTypes.node.isRequired,
	onClick: PropTypes.func,
	theme: PropTypes.oneOf(['blue', 'green', 'orange', 'white']),
	size: PropTypes.oneOf(['sm', 'md', 'lg']),
	disabled: PropTypes.bool,
	width: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
	iconOnly: PropTypes.bool,
	style: PropTypes.oneOfType([PropTypes.object, PropTypes.array])
};
Button.defaultProps = {
	theme: 'blue',
	size: 'sm'
};

const defaultStyle = css`
	outline: none;
	border: none;
	color: white;
	box-sizing: border-box;
	border-radius: .5rem;
  height: 2rem;
  font-family: Saira, "Nunito Sans";
  font-size: 0.875rem;
  padding: 0 1rem;
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  justify-content: center;
	box-shadow: 0px 3px 3px rgba(0,0,0,0.25);
	&:active:enabled {
    transform: translateY(2px);
    box-shadow: none;
	}
	&:hover:enabled {
		cursor: pointer;
	}
	&:disabled {
    cursor: not-allowed;
	}
  svg {
    fill: white;
    width: 1em;
    margin-right: 1em;
  }
`;

const themes = {
	blue: css`
		background: rgb(24, 144, 255);
		&:hover:enabled {
			background: rgba(24, 144, 255, .8);
		}
		&:disabled {
			background: rgba(24, 144, 255, .4);
		}
  `,
  green: css`
	  background: rgb(60, 191, 100);
	  &:hover:enabled {
	    background: rgba(60, 191, 100, .8);
	  }
	  &:disabled {
	    background: rgba(60, 191, 100, .4);
	  }
  `,
  orange: css`
	  background: rgb(232, 92, 25);
	  &:hover:enabled {
	    background: rgba(232, 92, 25, .8);
	  }
	  &:disabled {
	    background: rgba(232, 92, 25, .4);
	  }
  `,
  white: css`
    background: white;
    color: black;
    border: 1px solid rgba(0,0,0,.1);
    box-shadow: 0px 3px 3px rgba(0,0,0,0.1);
	  &:hover:enabled {
	    background: rgba(0, 0, 0, .05);
	  }
    &:disabled {
      color: rgba(0, 0, 0, .2);
      background: rgba(0, 0, 0, .04);
      svg {
        fill: rgba(0, 0, 0, .2);
      }
    }
    svg {
      fill: black;
    }
  `
};

const sizes = {
  sm: css`
	  height: 1.75rem;
	  font-size: 0.75rem;
	  padding: 0 0.875rem;
  `,
  md: css`
	  height: 2.5rem;
	  font-size: 1rem;
	  padding: 0 1rem;
  `,
  lg: css`
	  height: 3rem;
	  font-size: 1.125rem;
	  padding: 0 1.5rem;
  `
};

const iconOnlyStyle = css`
  padding: 0;
  border-radius: 50%;
  svg {
    margin: 0;
  }
`;

const iconOnlySizes = {
  sm: css`
    width: 1.75rem;
  `,
  md: css`
    width: 2.5rem;
  `,
  lg: css`
    width: 3rem;
  `
};

export default Button;